#include "common.cuh"
#include "ssm-conv.cuh"
#include "unary.cuh"
#include "convert.cuh"

// Metadata-only qualification of the actual SSM carrier; sizing has no addresses.
bool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst) {
    if (!dst || dst->op != GGML_OP_SSM_CONV || dst->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const x = dst->src[0], * const w = dst->src[1];
    if (!x || !w || (x->type != GGML_TYPE_BF16 && x->type != GGML_TYPE_F32) || w->type != GGML_TYPE_F32) return false;
    const int64_t W = x->ne[0], C = x->ne[1], B = x->ne[2], K = w->ne[0];
    if (W <= 0 || C <= 0 || C % 128 || B <= 0 || x->ne[3] != 1 ||
        (K != 3 && K != 4 && K != 5 && K != 9 && K != 15) || W < K ||
        w->ne[1] != C || w->ne[2] != 1 || w->ne[3] != 1 ||
        dst->ne[0] != C || dst->ne[1] != W - K + 1 || dst->ne[2] != B || dst->ne[3] != 1) return false;
    // Prove the kernel's signed offsets and all span calculations first.
    const ggml_tensor * const tensors[] = {x, w, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        uint64_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 || tensor->nb[axis] > uint64_t(INT64_MAX) ||
                tensor->nb[axis] % element) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    if (C > INT64_MAX / int64_t(sizeof(float)) / K ||
        C > INT64_MAX / int64_t(sizeof(float)) / dst->ne[1] / B) return false;
    if (w->nb[0] != sizeof(float) || w->nb[1] < uint64_t(K) * sizeof(float) ||
        dst->nb[0] != sizeof(float) || (dst->ne[1] > 1 && dst->nb[1] < uint64_t(C) * sizeof(float))) return false;
    const uint64_t output_batch_bytes = uint64_t(dst->ne[1] - 1) * dst->nb[1] + uint64_t(C) * sizeof(float);
    if (B > 1 && dst->nb[2] < output_batch_bytes) return false;
    if (x->type == GGML_TYPE_F32) {
        // Preserve the old F32 carrier's exact time-contiguous layout domain.
        return x->nb[0] == sizeof(float) && x->nb[1] == uint64_t(W) * sizeof(float) &&
            (B == 1 || x->nb[2] >= uint64_t(W) * uint64_t(C) * sizeof(float));
    }
    const uint64_t channel_bytes = uint64_t(C) * sizeof(nv_bfloat16);
    // Native BF16 [W,C,B] is the permutation of channel-contiguous rows.
    // Padding is legal, broadcast/overlapping time or batch rows are not.
    if (x->nb[1] != sizeof(nv_bfloat16) || x->nb[0] < channel_bytes ||
        uint64_t(W - 1) > (uint64_t(INT64_MAX) - channel_bytes) / x->nb[0]) return false;
    const uint64_t batch_bytes = uint64_t(W - 1) * x->nb[0] + channel_bytes;
    return (B == 1 || x->nb[2] >= batch_bytes) && ggml_is_contiguous(dst);
}


template <bool apply_silu, size_t split_d_inner, size_t d_conv, typename TX>
static __global__ void ssm_conv_f32(const TX * src0_ptr, const float * src1_ptr,
                                    const float * bias_ptr,
                                    const int64_t src0_nb0, const int64_t src0_nb1, const int64_t src0_nb2, const int64_t src1_nb1,
                                    float * dst_ptr, const int64_t dst_nb0, const int64_t dst_nb1, const int64_t dst_nb2,
                                    const int64_t n_t) {
    ggml_cuda_pdl_lc();
    const TX * GGML_CUDA_RESTRICT src0 = src0_ptr;
    const float * GGML_CUDA_RESTRICT src1 = src1_ptr;
    const float * GGML_CUDA_RESTRICT bias = bias_ptr;
    float       * GGML_CUDA_RESTRICT dst  = dst_ptr;
    const int tid  = threadIdx.x;
    const int bidx = blockIdx.x;
    const int bidy = blockIdx.y;

    const TX * x_block = (const TX *) ((const char *) src0 + bidx * src0_nb2 + bidy * split_d_inner * src0_nb1);
    const float * w_block = (const float *) ((const char *) src1 + bidy * split_d_inner * src1_nb1);
    float *       y_block = (float *) ((char *) dst + bidx * dst_nb2 + bidy * split_d_inner * dst_nb0);

    const int64_t stride_x = src0_nb1 / sizeof(TX);
    const int64_t stride_t = src0_nb0 / sizeof(TX);
    const int64_t stride_w = src1_nb1 / sizeof(float);
    const int64_t stride_y = dst_nb1 / sizeof(float);

    float x[d_conv] = { 0.0f };
    float w[d_conv] = { 0.0f };

    ggml_cuda_pdl_sync();
#pragma unroll
    for (size_t j = 0; j < d_conv; j++) {
        w[j] = w_block[tid * stride_w + j];
    }

    float b = bias != nullptr ? bias[bidy * split_d_inner + tid] : 0.0f;

    for (int64_t i = 0; i < n_t; i++) {
        float sumf = 0.0f;

        if (i == 0) {
            for (size_t j = 0; j < d_conv; j++) {
                x[j] = ggml_cuda_cast<float>(x_block[tid * stride_x + j * stride_t]);
            }
        } else {
            x[(i - 1) % d_conv] = ggml_cuda_cast<float>(x_block[tid * stride_x + (i + d_conv - 1) * stride_t]);
        }

#pragma unroll
        for (size_t j = 0; j < d_conv; j++) {
            sumf += x[(i + j) % d_conv] * w[j];
        }
        sumf += b;
        y_block[i * stride_y + tid] = apply_silu ? ggml_cuda_op_silu_single(sumf) : sumf;
    }
}

template <bool apply_silu, size_t split_d_inner, size_t d_conv, int64_t split_n_t, typename TX>
static __global__ void ssm_conv_long_token_f32(const TX * __restrict__ src0, const float * __restrict__ src1,
                                               const float * __restrict__ bias,
                                               const int64_t src0_nb0, const int64_t src0_nb1, const int64_t src0_nb2,
                                               const int64_t src1_nb1, float * __restrict__ dst, const int64_t dst_nb0,
                                               const int64_t dst_nb1, const int64_t dst_nb2, const int64_t n_t) {
    const int tid  = threadIdx.x;
    const int bidx = blockIdx.x;
    const int bidy = blockIdx.y;
    const int bidz = blockIdx.z;

    const TX * x_block = (const TX *) ((const char *) src0 + bidx * src0_nb2 + bidy * split_d_inner * src0_nb1 +
                                             bidz * split_n_t * src0_nb0);
    const float * w_block = (const float *) ((const char *) src1 + bidy * split_d_inner * src1_nb1);
    float *       y_block =
        (float *) ((char *) dst + bidx * dst_nb2 + bidz * split_n_t * dst_nb1 + bidy * split_d_inner * dst_nb0);

    const int64_t stride_x = src0_nb1 / sizeof(TX);
    const int64_t stride_t = src0_nb0 / sizeof(TX);
    const int64_t stride_w = src1_nb1 / sizeof(float);
    const int64_t stride_y = dst_nb1 / sizeof(float);

    const int64_t local_n_t = min(split_n_t, n_t - bidz * split_n_t);
    const int     n_cols    = d_conv - 1 + split_n_t;

    extern __shared__ float smem[];

    constexpr int load_cols   = d_conv - 1 + split_n_t;
    constexpr int total_elems = split_d_inner * load_cols;
    if constexpr (std::is_same_v<TX, nv_bfloat16>) {
        // BF16 samples are channel-contiguous. Adjacent lanes load adjacent
        // channels, then fill the same F32 shared cells as the legacy loader.
#pragma unroll
        for (int col = 0; col < load_cols; ++col) {
            smem[tid * n_cols + col] = col < local_n_t + d_conv - 1
                ? ggml_cuda_cast<float>(x_block[tid * stride_x + int64_t(col) * stride_t]) : 0.0f;
        }
    } else {
        int row = tid / load_cols;
        int col = tid % load_cols;
    #pragma unroll
        for (int idx = 0; idx < total_elems; idx += split_d_inner) {
            if (row < (int)split_d_inner) {
                // The last tile only owns local_n_t + K - 1 source samples.
                // Zero-fill unused columns; every valid MAC input is unchanged.
                smem[row * n_cols + col] = col < local_n_t + d_conv - 1
                    ? ggml_cuda_cast<float>(x_block[row * stride_x + int64_t(col) * stride_t]) : 0.0f;
            }

            col += split_d_inner;
            row += col / load_cols;
            col  = col % load_cols;
            if (idx >= total_elems - tid - split_d_inner) {
                break;
            }
        }
    }
    __syncthreads();

    // Load weights into registers (done once, small)
    float w[d_conv] = { 0.0f };
#pragma unroll
    for (size_t j = 0; j < d_conv; j++) {
        w[j] = w_block[tid * stride_w + j];
    }

    float b = bias != nullptr ? bias[bidy * split_d_inner + tid] : 0.0f;

    // Compute from shared memory
    for (int64_t i = 0; i < local_n_t; i++) {
        float sumf = 0.0f;
#pragma unroll
        for (size_t j = 0; j < d_conv; j++) {
            sumf += smem[tid * n_cols + i + j] * w[j];
        }
        sumf += b;
        y_block[i * stride_y + tid] = apply_silu ? ggml_cuda_op_silu_single(sumf) : sumf;
    }
}

template <bool apply_silu, typename TX>
static void ssm_conv_f32_cuda(const TX * src0, const float * src1, const float * bias, const int64_t src0_nb0, const int64_t src0_nb1,
                              const int64_t src0_nb2, const int64_t src1_nb1, float * dst, const int64_t dst_nb0, const int64_t dst_nb1,
                              const int64_t dst_nb2, const int64_t nc, const int64_t nr, const int64_t n_t,
                              const int64_t n_s, cudaStream_t stream) {
    const int threads = 128;
    GGML_ASSERT(nr % threads == 0);

    auto launch_kernel = [&](auto NC) {
        constexpr int kNC = decltype(NC)::value;
        if (n_t <= 32) {
            const dim3 blocks(n_s, (nr + threads - 1) / threads, 1);
            const ggml_cuda_kernel_launch_params launch_params = ggml_cuda_kernel_launch_params(blocks, threads, 0, stream);
            ggml_cuda_kernel_launch(ssm_conv_f32<apply_silu, threads, kNC, TX>, launch_params, src0, src1, bias, src0_nb0, src0_nb1,
                                                                        src0_nb2, src1_nb1, dst, dst_nb0, dst_nb1, dst_nb2, n_t);
        } else {
            const int64_t split_n_t = 32;
            dim3          blocks(n_s, (nr + threads - 1) / threads, (n_t + split_n_t - 1) / split_n_t);
            const size_t  smem_size = threads * (kNC - 1 + split_n_t) * sizeof(float);
            ssm_conv_long_token_f32<apply_silu, threads, kNC, split_n_t, TX><<<blocks, threads, smem_size, stream>>>(
                src0, src1, bias, src0_nb0, src0_nb1, src0_nb2, src1_nb1, dst, dst_nb0, dst_nb1, dst_nb2, n_t);
        }
    };

    switch (nc) {
        case 3:  launch_kernel(std::integral_constant<int, 3 >{}); break;
        case 4:  launch_kernel(std::integral_constant<int, 4 >{}); break;
        case 5:  launch_kernel(std::integral_constant<int, 5 >{}); break;
        case 9:  launch_kernel(std::integral_constant<int, 9 >{}); break;
        case 15: launch_kernel(std::integral_constant<int, 15>{}); break;
        default: GGML_ABORT("Only support kernel sizes 3, 4, 5, 9, 15 right now.");
    }
}

template <typename TX>
static void ggml_cuda_op_ssm_conv_impl(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * bias_add_node, ggml_tensor * silu_dst) {
    const struct ggml_tensor * src0 = dst->src[0];  // conv_x
    const struct ggml_tensor * src1 = dst->src[1];  // conv1d.weight
    const bool fuse_bias = bias_add_node != nullptr;
    const bool fuse_silu = silu_dst != nullptr;

    // bias always comes with silu.
    GGML_ASSERT(!fuse_bias || fuse_silu);

    // The bias (when fused) is the non-conv operand of the ADD node.
    const struct ggml_tensor * bias = fuse_bias ? (bias_add_node->src[0] == dst ? bias_add_node->src[1] : bias_add_node->src[0]) : nullptr;

    // When fusing, write to silu_dst (the node downstream references).
    const struct ggml_tensor * out = fuse_silu ? silu_dst : dst;

    const int64_t nc  = src1->ne[0];                // d_conv
    const int64_t nr  = src0->ne[1];                // d_inner
    const int64_t n_t = out->ne[1];                 // tokens per sequence
    const int64_t n_s = out->ne[2];                 // number of sequences in the batch

    GGML_ASSERT(out->ne[0] == nr);
    if constexpr (std::is_same_v<TX, float>) {
        GGML_ASSERT(src0->nb[0] == sizeof(float));
        GGML_ASSERT(src0->nb[1] == src0->ne[0] * sizeof(float));
    }
    GGML_ASSERT(src1->nb[0] == sizeof(float));

    const TX * src0_d = (const TX *) src0->data;
    const float * src1_d = (const float *) src1->data;
    const float * bias_d = fuse_bias ? (const float *) bias->data : nullptr;
    float *       dst_d  = (float *) out->data;
    cudaStream_t  stream = ctx.stream();

    GGML_ASSERT(src0->type == (std::is_same_v<TX, float> ? GGML_TYPE_F32 : GGML_TYPE_BF16));
    GGML_ASSERT(out->type == GGML_TYPE_F32);
    if (fuse_bias) {
        GGML_ASSERT(bias->type == GGML_TYPE_F32);
        GGML_ASSERT(ggml_is_contiguous(bias));
        GGML_ASSERT(ggml_nelements(bias) == nr);
    }

    if (fuse_silu) {
        ssm_conv_f32_cuda<true>(src0_d, src1_d, bias_d, src0->nb[0], src0->nb[1], src0->nb[2], src1->nb[1], dst_d, out->nb[0], out->nb[1],
                          out->nb[2], nc, nr, n_t, n_s, stream);
    } else {
        ssm_conv_f32_cuda<false>(src0_d, src1_d, bias_d, src0->nb[0], src0->nb[1], src0->nb[2], src1->nb[1], dst_d, out->nb[0], out->nb[1],
                          out->nb[2], nc, nr, n_t, n_s, stream);
    }
}


void ggml_cuda_op_ssm_conv(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
        ggml_tensor * bias_add_node, ggml_tensor * silu_dst) {
    if (dst->src[0]->type == GGML_TYPE_BF16) {
        if (!ggml_cuda_supports_ssm_conv(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed SSM convolution metadata");
        }
        ggml_cuda_op_ssm_conv_impl<nv_bfloat16>(ctx, dst, bias_add_node, silu_dst);
    } else {
        ggml_cuda_op_ssm_conv_impl<float>(ctx, dst, bias_add_node, silu_dst);
    }
}
