#pragma once
#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-d09406b4be8cc51e"
