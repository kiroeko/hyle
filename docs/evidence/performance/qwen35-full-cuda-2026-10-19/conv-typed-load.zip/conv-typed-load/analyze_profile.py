"""Offline current Conv physical evidence from official Nsight SQLite and CSV."""
from pathlib import Path
import collections
import csv
import hashlib
import importlib.util
import json
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
OUT = STAGE / 'profile'
spec = importlib.util.spec_from_file_location('conv_symbol_helpers', ARCH / 'cuda-stable-silu/profile-analysis-stable.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def conversion(name):
    args = a.template_arguments(name, 'cpy_scalar_contiguous')
    if len(args) != 2:
        return None
    source, destination = map(a.dtype, args)
    if (source, destination) == ('bf16', 'f32'):
        return 'BF16_to_F32'
    if (source, destination) == ('f32', 'bf16'):
        return 'F32_to_BF16'
    return None


def symbol_details(name):
    args = a.template_arguments(name, 'gated_delta_net_cuda')
    if args:
        return dict(family='GDN', template_arguments=args,
            V_dtype=a.dtype(args[3]) if len(args) >= 5 else 'unresolved',
            beta_dtype=a.dtype(args[4]) if len(args) >= 5 else 'unresolved')
    for kernel, index in (('ssm_conv_f32', 3), ('ssm_conv_long_token_f32', 4)):
        args = a.template_arguments(name, kernel)
        if args:
            # Legacy baseline templates have only compile-time geometry and
            # a float* signature; current templates append the actual TX type.
            kind = a.dtype(args[index]) if len(args) > index else (
                'f32' if '(const float *' in name else 'unresolved')
            return dict(family='Conv', kernel=kernel, template_arguments=args, input_dtype=kind)
    args = a.template_arguments(name, 'rms_norm_f32')
    if args:
        flag = re.sub(r'\s+', '', args[1]) if len(args) > 1 else 'unresolved'
        weighted = False if flag in ('false','0','(bool)0','(bool)false') else (
            True if flag in ('true','1','(bool)1','(bool)true') else None)
        return dict(family='RMS', template_arguments=args, weighted=weighted,
            input_dtype=a.dtype(args[3]) if len(args) >= 5 else 'unresolved',
            output_dtype=a.dtype(args[4]) if len(args) >= 5 else 'unresolved')
    args = a.template_arguments(name, 'cpy_scalar_transpose')
    if args:
        return dict(family='transpose', template_arguments=args, input_dtype=a.dtype(args[0]))
    return dict(family='other')


COUNT_KEYS = ('kernels','BF16_to_F32','F32_to_BF16','transpose_F32','Conv','Conv_BF16',
              'GDN','GDN_V_BF16_beta_BF16','RMS_unscaled_BF16_BF16')


def inventory(symbols):
    counts = collections.Counter(kernels=sum(symbols.values()))
    types = {key: collections.Counter() for key in ('Conv','GDN','RMS_unscaled')}
    for name, number in symbols.items():
        cast = conversion(name)
        if cast:
            counts[cast] += number
        info = symbol_details(name)
        family = info['family']
        if family == 'GDN':
            counts['GDN'] += number
            types['GDN'][info['V_dtype'] + '/' + info['beta_dtype']] += number
            if info['V_dtype'] == info['beta_dtype'] == 'bf16':
                counts['GDN_V_BF16_beta_BF16'] += number
        elif family == 'Conv':
            counts['Conv'] += number
            types['Conv'][info['input_dtype']] += number
            if info['input_dtype'] == 'bf16':
                counts['Conv_BF16'] += number
        elif family == 'RMS' and info['weighted'] is False:
            types['RMS_unscaled'][info['input_dtype'] + '/' + info['output_dtype']] += number
            if info['input_dtype'] == info['output_dtype'] == 'bf16':
                counts['RMS_unscaled_BF16_BF16'] += number
        elif family == 'transpose' and info['input_dtype'] == 'f32':
            counts['transpose_F32'] += number
    return dict(**{key:counts[key] for key in COUNT_KEYS},
        input_type_counts={key:dict(value) for key,value in types.items()},
        conversion_symbols={name:n for name,n in symbols.items() if conversion(name)},
        per_symbol=dict(symbols))


def summarize(kernels):
    result = inventory(collections.Counter(row['name'] for row in kernels))
    for family in ('GDN','Conv','RMS'):
        result[family + '_instances'] = [dict(**row, **info) for row in kernels
            if (info := symbol_details(row['name']))['family'] == family]
    return result


def startup_mappings(con, tables, kernels, runtime, anchor, first_token_end):
    """Follow graph-node lineage, never kernel correlationId to GraphLaunch."""
    if 'CUDA_GRAPH_NODE_EVENTS' not in tables:
        return dict(available=False, reason='No CUDA_GRAPH_NODE_EVENTS in export')
    by_node = collections.defaultdict(list)
    for row in con.execute('SELECT * FROM CUDA_GRAPH_NODE_EVENTS'):
        by_node[row['graphNodeId']].append(dict(row))
    runtime = [row for row in runtime if row['table'] == 'CUPTI_ACTIVITY_KIND_RUNTIME']
    output = {}
    for role, predicate in (
        ('GDN', lambda name:'gated_delta_net_cuda<' in name),
        ('Conv', lambda name:symbol_details(name)['family'] == 'Conv'),
        ('FlashInfer', lambda name:'BatchPrefillWithRaggedKVCacheKernel' in name),
        ('ATen_Softplus', lambda name:'at::native::vectorized_elementwise_kernel' in name and 'softplus_kernel' in name)):
        kernel = next((row for row in kernels if anchor < row['start'] < first_token_end and predicate(row['name'])), None)
        if kernel is None:
            output[role] = dict(mapped=False, reason='No matching physical kernel in prefill anchor interval')
            continue
        node, chain, seen, origin, reason = kernel.get('graphNodeId'), [], set(), None, None
        while node:
            if node in seen:
                reason = 'Cycle in graph-node lineage'
                break
            seen.add(node)
            events = by_node.get(node, [])
            if not events:
                reason = 'Graph-node events absent for node ' + str(node)
                break
            chain.append(dict(node=node, events=events))
            parents = {row['originalGraphNodeId'] for row in events if row['originalGraphNodeId'] is not None}
            if not parents:
                origin = min(events, key=lambda row:row['start'])
                break
            if len(parents) != 1:
                reason = 'Ambiguous graph-node parent'
                break
            node = parents.pop()
        calls = [] if origin is None else [row for row in runtime if
            row['globalTid'] == origin['globalTid'] and row['start'] <= origin['start'] <= row['end']
            and row['name'].startswith('cudaLaunchKernel')]
        if len(calls) != 1:
            output[role] = dict(mapped=False, reason=reason or 'Original-node creation did not resolve to exactly one recording launch',
                kernel=kernel, original_node_chain=chain, recording_launch_candidates=calls)
            continue
        launch = calls[0]
        output[role] = dict(mapped=True, kernel=kernel, original_node_chain=chain,
            recording_launch=launch, preceding_same_thread_APIs=[row for row in runtime
                if row['globalTid'] == launch['globalTid'] and row['end'] <= launch['start']][-7:])
    return dict(available=True, first_instances=output,
        method='Actual kernel graphNodeId follows originalGraphNodeId to creation event; same-thread cudaLaunchKernel interval must contain that creation. Kernel correlationId is not used as a recording-launch correlation.',
        limit='Preceding attribute calls are temporal observations; SQLite does not reveal their function/module arguments. Recording-call duration is not GPU execution duration or unprofiled throughput.')


def analyze():
    plan = json.loads((OUT / 'plan.json').read_text())
    for tag in ('profile', 'export', 'stats'):
        result = json.loads((OUT / (tag + '.result.json')).read_text())
        assert result['exit'] == 0 and result['terminal']
    database = OUT / 'capture.sqlite'
    con = sqlite3.connect('file:' + database.resolve().as_posix() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    strings = dict(con.execute('SELECT id,value FROM StringIds'))
    kernels = []
    for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start'):
        original = dict(row)
        name = strings[original['demangledName']]
        kernels.append(dict(**original, name=name, duration_ns=original['end'] - original['start']))
    csv_path = OUT / 'capture_cuda_gpu_kern_sum.csv'
    with csv_path.open(encoding='utf-8-sig', newline='') as handle:
        official = collections.Counter()
        for row in csv.DictReader(handle):
            official[row['Name']] += int(row['Instances'].replace(',', ''))
    actual = collections.Counter(row['name'] for row in kernels)
    csv_equal = actual == official
    diagnostics = [dict(row) for row in con.execute('SELECT * FROM DIAGNOSTIC_EVENT')] if 'DIAGNOSTIC_EVENT' in tables else []
    save(OUT / 'diagnostics.json', diagnostics)
    streams = {}
    if 'ProcessStreams' in tables:
        for row in con.execute('SELECT * FROM ProcessStreams'):
            filename = strings[row['filenameId']]
            if '/streams/' in filename.replace('\\', '/'):
                streams['stderr' if 'stderr_' in filename else 'stdout'] = strings[row['contentId']]
    elif 'ANALYSIS_FILE' in tables:
        for row in con.execute('SELECT * FROM ANALYSIS_FILE'):
            if '/streams/' in row['filename'].replace('\\', '/'):
                streams['stderr' if 'stderr_' in row['filename'] else 'stdout'] = strings[row['contentId']]
    assert 'stdout' in streams and 'stderr' in streams
    for kind, content in streams.items():
        (OUT / ('target.' + kind + '.log')).write_text(content, encoding='utf-8')
    target = a.parse_target(streams['stdout'], streams['stderr'])
    result = target['output']
    assert result and result['source_id'] == plan['source_id']
    assert result['generated_ids'] == plan['expected_generated_ids']
    assert result['decode_input_ids'] == plan['fixed']['decode_input_ids']
    assert result['fixed_decode'] and result['visible_tokens'] == 159 and result['text_tensors'] == 320
    assert target['phase_labels'] == ['prefill'] + ['decode' + str(i) for i in range(1, 32)]
    copies = [dict(row) for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY end')]
    tokens = [row for row in copies if row['copyKind'] == 2 and row['bytes'] == 4]
    assert len(tokens) == 32 and len({row['end'] for row in tokens}) == 32
    # Each consumer waits for this four-byte token before advancing the fixed
    # tape. Decode7 is index7 after prefill, between token6 and token7 end.
    phases, d7 = [], []
    for index in range(1, 32):
        lo, hi = tokens[index - 1]['end'], tokens[index]['end']
        selected = [row for row in kernels if lo < row['start'] and row['end'] <= hi]
        crossing = [row for row in kernels if row['start'] < hi and row['end'] > lo
                    and not (lo < row['start'] and row['end'] <= hi)]
        assert not crossing, 'Kernel crosses consumer phase boundary'
        counts = summarize(selected)
        phases.append(dict(phase='decode' + str(index), index=index, lo_ns=lo, hi_ns=hi,
            **{key:counts[key] for key in COUNT_KEYS}))
        if index == 7:
            d7 = selected
    observation = summarize(d7)
    expected = plan['expected_not_asserted']
    observed_counts = dict(decode7_kernels=observation['kernels'],
        **{key:observation[key] for key in COUNT_KEYS if key != 'kernels'})
    expectation_matches = {key:observed_counts[key] == value for key,value in expected.items()}
    baseline_path = Path(plan['baseline_analysis']['path'])
    assert identity(baseline_path) == plan['baseline_analysis']
    baseline = inventory(collections.Counter(json.loads(baseline_path.read_text())['decode7']['per_symbol']))
    baseline_comparison = dict(source=plan['baseline_analysis'], decode7_counts={key:baseline[key] for key in COUNT_KEYS},
        current_minus_baseline={key:observation[key]-baseline[key] for key in COUNT_KEYS},
        note='Retained same-input baseline physical category counts only; no baseline reprofile or subtraction of profiling durations.')
    runtime = []
    for table in ('CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_DRIVER'):
        if table in tables:
            for row in con.execute('SELECT * FROM ' + table + ' ORDER BY start'):
                item = dict(row)
                runtime.append(dict(**item, table=table, name=strings[item['nameId']], duration_ns=item['end']-item['start']))
    # Same source-defined128-token upload anchor as the earlier cold analysis.
    uploads = [row for row in copies if row['copyKind'] == 1 and row['bytes'] == 512][-2:]
    assert len(uploads) == 2
    upload_apis = []
    for copy in uploads:
        matching = [row for row in runtime if row['table'] == 'CUPTI_ACTIVITY_KIND_RUNTIME' and row['correlationId'] == copy['correlationId']]
        assert len(matching) == 1
        upload_apis.extend(matching)
    anchor = max(row['end'] for row in upload_apis)
    prefill_apis = [row for row in runtime if row['table'] == 'CUPTI_ACTIVITY_KIND_RUNTIME' and anchor <= row['start'] < tokens[0]['end']]
    interesting = [row for row in prefill_apis if any(term in row['name'] for term in ('FuncSetAttribute','FuncGetAttributes','GraphInstantiate','StreamBeginCapture','StreamEndCapture','GraphLaunch'))]
    mapped_startup = startup_mappings(con, tables, kernels, runtime, anchor, tokens[0]['end'])
    d7_interval = phases[6]
    d7_launches = [row for row in runtime if row['table'] == 'CUPTI_ACTIVITY_KIND_RUNTIME' and
        'GraphLaunch' in row['name'] and d7_interval['lo_ns'] < row['start'] < d7_interval['hi_ns']]
    report = dict(passed=csv_equal, physical_expectations_met=all(expectation_matches.values()),
        checks=dict(collection_exit_zero=True, official_CSV_SQLite_per_symbol_equal=csv_equal,
            token_D2H_phase_anchors32=True, fixed_inputs_and_predictions_same=True, phase_boundaries_complete=True),
        expected_not_asserted=expected, observed_counts=observed_counts, expectation_matches=expectation_matches,
        decode7=observation, decode_phase_counts=phases, baseline_comparison=baseline_comparison,
        warm_decode7_31_same_counts=all(all(row[key] == observation[key] for key in COUNT_KEYS)
                                      for row in phases if row['index'] >= 7),
        phase_anchor=dict(method='Actual32 four-byte device-to-host token copy completion timestamps; decode7 is (token6.end,token7.end].',
                          decode7_before_token=tokens[6], decode7_after_token=tokens[7],
                          prefill_prompt_position_uploads=uploads, prefill_host_anchor_ns=anchor),
        decode7_graph_launch_apis=d7_launches,
        prefill_counts=summarize([row for row in kernels if anchor < row['start'] and row['end'] <= tokens[0]['end']]),
        prefill_diagnostic=dict(interesting_runtime_apis=interesting,
            longest20_runtime_apis=sorted(prefill_apis,key=lambda r:r['duration_ns'],reverse=True)[:20],
            original_node_recording_launches=mapped_startup,
            consumer_log_lines=[line for line in streams['stderr'].splitlines() if line.startswith(('prepared T=128 ', 'prefill '))]),
        sqlite=identity(database), official_kernel_csv=identity(csv_path),
        official_SQLite_kernel_count=len(kernels), official_CSV_kernel_count=sum(official.values()),
        CSV_SQLite_differences=[dict(name=name,SQLite=actual[name],CSV=official[name]) for name in actual.keys()|official.keys() if actual[name]!=official[name]],
        target=result, capture_reports=target['capture_counts'], diagnostics=identity(OUT/'diagnostics.json'),
        collector_warnings=[row for row in diagnostics if row.get('severity',0)>=2],
        input_dtype_evidence='Conv TX and GDN TV/TB plus unscaled RMS input/output types are decoded from full demangled templates, tied to frozen sources. Nsight does not record actual input pointer payloads or prove arithmetic by symbol name alone; source/numerical proof remains separate.',
        limits=['One current all-API trace; timings are instrumented observations, never throughput or stable speed evidence.',
            'Expected668/55+54/0transpose/18BF16Conv plus retained18typedGDN/18typedRMS values are hypotheses checked against actual counts, not assumptions used to repair results.',
            'Cold first-launch/attribute API observations do not identify internal driver/module work, and unmarked gaps are not assigned to CPU subfunctions.',
            'CSV/SQLite symbol agreement and fixed predictions are not independent numerical-quality acceptance; the completed64vector regression is separate.'],
        throughput_claim=False, new_model_processes=1)
    con.close()
    save(OUT / 'analysis.json', report)
    save(OUT / 'summary.json', dict(passed=csv_equal, physical_expectations_met=report['physical_expectations_met'],
        observed_counts=observed_counts, expectation_matches=expectation_matches,
        analysis=identity(OUT/'analysis.json'), fresh_model_processes=1, throughput_claim=False))
    if not csv_equal:
        raise ValueError('Official CSV and SQLite counts differ; raw evidence retained')
    print('CONV_PHYSICAL_OBSERVATION', observed_counts, 'expectations_met=',report['physical_expectations_met'], flush=True)


if __name__ == '__main__':
    analyze()
