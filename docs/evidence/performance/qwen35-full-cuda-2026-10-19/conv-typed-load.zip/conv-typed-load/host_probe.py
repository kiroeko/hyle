"""One diagnostic model per image with five host timing boundaries; not a speed window."""
from pathlib import Path
import importlib.util
import statistics as st
import sys
import re
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
OUT=STAGE/'host-probe'
spec=importlib.util.spec_from_file_location('conv_probe_helpers',STAGE/'build.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,c=m.b,m.c

def replace(code,old,new):
    assert code.count(old)==1,old[:100]
    return code.replace(old,new,1)

def prepare():
    assert not OUT.exists(); OUT.mkdir(); (OUT/'tmp').mkdir()
    base=ARCH/'decode-next-cold/checks/20261019T155819/29-qwen35_text-main-identity.json'
    recipe=c.read(base)
    actual=b.identity(ROOT/'tools/qwen35_text/main.cc')
    assert actual==recipe['source'],'Diagnostic requires unchanged actual consumer source'
    code=Path(actual['path']).read_text(encoding='utf-8')
    code=replace(code,'    Clock::time_point start;','    Clock::time_point start;\n    std::array<Clock::time_point, 5> host_probe{};')
    code=replace(code,'      std::array<g::batch::NodeLayout, 6> layouts;',
        '      host_probe[0] = Clock::now();\n      std::array<g::batch::NodeLayout, 6> layouts;')
    code=replace(code,'      check(run.bind(phase.token_port, phase.tokens.read()));',
        '      host_probe[1] = Clock::now();\n      check(run.bind(phase.token_port, phase.tokens.read()));')
    code=replace(code,'      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));',
        '      host_probe[2] = Clock::now();\n      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));\n      host_probe[3] = Clock::now();')
    code=replace(code,'      cold_batch_seconds = std::chrono::duration<double>(Clock::now() - cold_start).count();',
        '      host_probe[4] = Clock::now();\n      cold_batch_seconds = std::chrono::duration<double>(host_probe[4] - cold_start).count();')
    code=replace(code,'    std::cerr << "prepared T=" << ids.size()',
        '    std::cerr << "host_probe phase=" << name;\n    auto host_probe_before = cold_start;\n    for (const auto host_probe_after : host_probe) {\n      std::cerr << " part=" << std::chrono::duration<double>(host_probe_after - host_probe_before).count();\n      host_probe_before = host_probe_after;\n    }\n    std::cerr << \'\\n\';\n    std::cerr << "prepared T=" << ids.size()')
    source=OUT/'main.cc'; source.write_text(code,encoding='utf-8')
    command=b.host_command(recipe['command'],source,'probe',OUT)
    current=c.read(STAGE/'latest-check.json')['plan']; current=Path(current)
    links={}
    for arm,path in [('baseline',ARCH/'gdn-region-suffix/checks/20261019T165656/qwen-link-plan.json'),
                     ('current',current.parent/'qwen-link-plan.json')]:
        link=c.read(path)
        image=OUT/(arm+'.exe')
        args=[str(OUT/'probe.obj') if c.key(x)==c.key(recipe['object']['path']) else x for x in link['command']
            if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        assert str(OUT/'probe.obj') in args
        args += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        links[arm]=dict(command=args,original_link=b.identity(path),original_inputs=link['inputs'],image=str(image))
    plan=dict(source=b.identity(source),original_source=actual,recipe=b.identity(base),compile=command,links=links,
        part_names=['layout_version','batch_prepare_and_layout_list','all_external_binds','prepare_replay','replay_report'],
        exact_math_or_call_order_changes=False,model_processes_planned=2,throughput_claim=False,
        limits='Five steady-clock markers per phase plus one stderr line after completion. These perturb execution and give only narrow caller-boundary attribution, never a new speed result. No internal function is inferred from unmarked subintervals.')
    c.save(OUT/'plan.json',plan)
    return plan

def run():
    plan=prepare()
    link=plan['links']['current']; paths=[r['path'] for r in link['original_inputs']]
    env,_=b.environment(link['command'],paths,OUT)
    c.execute('probe-compile',plan['compile'],env,OUT)
    data=c.read(OUT/'probe-deps.json')['Data']
    c.save(OUT/'probe-identity.json',dict(command=plan['compile'],source=plan['source'],object=b.identity(OUT/'probe.obj'),
        dependencies=[b.identity(p) for p in [data['Source'],*data['Includes']]]))
    requests=c.read(STAGE/'performance-prepared/plan.json')['requests']
    ids=c.read(STAGE/'correctness/summary.json')['observation']['generated_ids']
    groups={}
    for arm,link in plan['links'].items():
        env,runtime=b.environment(link['command'],[r['path'] for r in link['original_inputs']],OUT)
        c.execute(arm+'-link',link['command'],env,OUT); c.save(OUT/(arm+'-image.json'),b.identity(Path(link['image'])))
        command=next(r['command'] for r in requests if r['arm']==arm).copy(); command[0]=link['image']
        c.execute(arm,command,env,OUT)
        target=c.read(OUT/(arm+'.result.json')); assert target['exit']==0
        output=c.read(OUT/(arm+'.stdout.log')); assert output['generated_ids']==ids
        rows=[]
        for line in (OUT/(arm+'.stderr.log')).read_text().splitlines():
            if not line.startswith('host_probe phase='): continue
            phase=line.split()[1].split('=',1)[1]
            values=[float(x) for x in re.findall(r' part=([0-9.eE+\-]+)',line)]
            assert len(values)==5; rows.append(dict(phase=phase,seconds=values))
        assert len(rows)==32
        warm=rows[7:32]
        groups[arm]=dict(all_phases=rows,warm_mean_us={name:st.mean(r['seconds'][i] for r in warm)*1e6 for i,name in enumerate(plan['part_names'])},
            runtime=runtime,image=b.identity(Path(link['image'])))
    c.save(OUT/'summary.json',dict(groups=groups,processes=2,one_process_per_image=True,throughput_claim=False,
        limits=plan['limits'],no_profiler=True,new_product_edits=False))
    print({arm:g['warm_mean_us'] for arm,g in groups.items()},flush=True)

if __name__=='__main__': run()
