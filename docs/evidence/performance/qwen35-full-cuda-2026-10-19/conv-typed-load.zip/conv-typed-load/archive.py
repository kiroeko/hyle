"""Archive this completed Conv batch once; never builds, runs or deletes."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/conv-typed-load.zip'
PREFIX = 'conv-typed-load/'
OMIT = {'.exe', '.obj', '.o', '.map', '.lib', '.a', '.exp', '.pdb', '.dll',
        '.pyc', '.tmp', '.bf16', '.f16', '.f32', '.bin', '.npy', '.zip'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def check(row, path=None):
    actual = identity(path or row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256')), (row, actual)
    return actual


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def eligible(path, base):
    parts = {part.lower() for part in path.relative_to(base).parts}
    return (path.suffix.lower() not in OMIT and
            not parts.intersection({'tmp', '__pycache__', 'sdk', 'cache'}) and
            path.name not in {'archive-receipt.json', 'archive-source-index.json',
                              'archive-scope.json', 'archive-support.json'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path, required=True)
    args = parser.parse_args()
    plan_path = args.build_plan.resolve()
    assert plan_path.is_relative_to(STAGE / 'checks')
    plan = read(plan_path)
    build = read(plan_path.parent / 'summary.json')
    assert build['passed'] and build['host_TUs'] == 4 and build['native_TUs'] == 2
    assert not build['SDK_build']
    assert len(plan['compile']) == 6
    assert sum(row['kind']=='host' for row in plan['compile']) == 4
    assert sum(row['kind']=='native' for row in plan['compile']) == 2
    plan_identity = identity(plan_path)

    tests = read(STAGE / 'tests/summary.json')
    process = read(STAGE / 'tests/conv.result.json')
    cases = ET.parse(STAGE / 'tests/results.xml').findall('.//testcase')
    names = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases]
    required = {
        'GgmlCudaConvTypedLoad.OriginalMathAndTypedBoundariesAcrossSlotsAndLongTiles',
        'GgmlCudaConvTypedLoad.PublishedSampleCastKeepsF32Output',
        'GgmlCudaConvTypedLoad.ExtraSampleCastReaderKeepsF32Value',
        'GgmlCudaGdnTypedLoad.IndependentVAndBetaMatchOriginalAcrossTokensAndSnapshots',
        'GgmlCudaGdnTypedLoad.PublishedCastAndExtraReaderRetainF32Values',
        'GgmlCudaGdnTypedLoad.RecurrentKeepsF32SigmoidAfterRawBetaWiden'}
    assert tests['passed'] and tests['cases'] == len(cases) == 6 and tests['skipped'] == 0
    assert len(set(names)) == 6 and set(names) == set(tests['exact_filters']) == required
    assert not any(x.find('failure') is not None or x.find('error') is not None or
                   x.find('skipped') is not None for x in cases)
    assert process['exit'] == 0 and process['pid'] > 0
    assert tests['build_plan'] == plan_identity
    assert tests['image'] == read(plan_path.parent/'conv-image.json')

    model = read(STAGE / 'correctness/summary.json')
    observation = model['observation']
    assert model['passed'] and observation['equal_vectors'] == 64
    assert observation['all_outputs_finite'] and observation['same_greedy_ids_as_reference']
    assert observation['same_fixed_decode_inputs'] and len(observation['vectors']) == 64
    assert len(observation['generated_ids']) == 32 and len(observation['decode_input_ids']) == 31
    assert model['route'] == 'hybrid' and model['single_outer_range_32_phases']
    assert observation['image'] == read(plan_path.parent/'qwen-image.json')
    assert read(STAGE/'correctness/inputs.json')['plan'] == plan_identity
    for row in observation['vectors']:
        assert row['byte_equal'] and row['actual']['bytes'] == row['reference']['bytes']
        assert row['actual']['sha256'] == row['reference']['sha256']
    perf = read(STAGE / 'performance-rotation/summary.json')
    runs = read(STAGE / 'performance-rotation/runs.json')
    assert perf['terminal_zero'] == len(runs) == 9 and not perf['profiler']
    assert [row['arm'] for row in runs] == perf['order']
    assert all(row['exit'] == 0 and row['decode_input_ids'] == observation['decode_input_ids'] for row in runs)
    assert all(len(perf['groups'][arm]['full31_seconds']['samples']) == 3
               for arm in ('baseline', 'current', 'llama'))

    profile_path = STAGE / 'profile/summary.json'
    profile = read(profile_path)
    analysis = read(STAGE/'profile/analysis.json')
    profile_ready = profile.get('passed') is True and analysis.get('passed') is True
    assert profile_ready, 'Final profile/summary.json and analysis.json are not ready/passed'
    assert all((STAGE / 'profile' / name).is_file() for name in
               ('capture.nsys-rep', 'capture.sqlite', 'capture_cuda_gpu_kern_sum.csv'))
    assert read(STAGE/'profile/plan.json')['build_plan'] == plan_identity
    for tag in ('profile','export','stats'):
        assert read(STAGE/'profile'/(tag+'.result.json'))['exit'] == 0
    profile_state = dict(ready=profile_ready, summary=profile,
        note='Collection/phase/CSV checks and observed typed symbols are distinct from physical_expectations_met. Counts remain actual observations even when a hypothesis misses.')

    # Payload table also copies exact sources outside this stage, without SDKs.
    payloads, source_rows = {}, []
    def add(path, name):
        path = Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT), path
        old = payloads.get(name)
        assert old is None or old == path, name
        payloads[name] = path

    host = read(STAGE / 'host-source-freeze.json')
    assert len(host['files']) == 4
    assert sum(row['before']['exists'] for row in host['files']) == 3
    for row in host['files']:
        rel = Path(row['path'])
        after = row.get('after',row)
        current = check(after, ROOT / rel)
        check(after, STAGE / 'host-source' / rel)
        source_rows.append(dict(kind='host-after', **current))
        if row['before']['exists']:
            source_rows.append(dict(kind='host-before', **check(row['before'], STAGE / 'host-before' / rel)))
    for row in read(STAGE / 'tests-source-freeze.json')['files']:
        check(row, ROOT / row['path'])
    native = read(STAGE / 'native-source-freeze.json')
    assert len(native['files']) == 3 and native['all_mixed_CPU_IQ1_CUDA_edits_replayed']
    assert len(native['product_files']) == 3
    for row in native['files']:
        for version in ('before', 'after'):
            source_rows.append(dict(kind='native-' + version, **check(row[version])))
    for row in native['product_files']:
        for version in ('before', 'after'):
            record = check(row[version])
            if version == 'after':
                add(record['path'], PREFIX + 'product-after/' + row['path'])
            source_rows.append(dict(kind='product-' + version, **record))

    closure = read(STAGE / 'native-header-closure.json')
    assert closure['header_count'] == len(closure['headers']) == 89
    retained_header_paths = set()
    for row in closure['headers']:
        # Current89 are fully closed in this batch. Do not recursively copy an
        # older native include tree just because a fallback -I remains literal.
        path = STAGE / 'native-source' / row['path']
        check(row, path)
        retained_header_paths.add(path.resolve())
    prior_native = ARCH/'gdn-typed-load'
    gdn_freeze = read(prior_native/'native-source-freeze.json')
    retained_gdn = []
    for row in gdn_freeze['files']:
        if row['path'].endswith(('/gated_delta_net.cu','/gated_delta_net.cuh')):
            source = check(row['after'])
            retained_gdn.append(source)
            if row['path'].endswith('.cu'):
                add(source['path'],PREFIX+'retained-gdn-v23/'+row['path'])
            else:
                check(source,STAGE/'native-source'/row['path'])
    assert len(retained_gdn)==2
    gdn_owner_path=prior_native/'checks/20261019T163125/native-gdn-identity.json'
    gdn_owner=read(gdn_owner_path)
    assert gdn_owner['source'] in retained_gdn
    qwen_link=read(plan_path.parent/'qwen-link-plan.json')
    assert gdn_owner['object'] in qwen_link['inputs']
    add(gdn_owner_path,PREFIX+'retained-gdn-v23/native-gdn-identity.json')
    add(prior_native/'native-source-freeze.json',PREFIX+'retained-gdn-v23/native-source-freeze.json')
    # Cached neighboring GDN test TU is genuinely executed in the6-case image.
    conv_link=read(plan_path.parent/'conv-link-plan.json')
    gdn_test_object=next(row for row in conv_link['inputs'] if Path(row['path']).name=='gdn-test.obj')
    gdn_test_receipt=Path(gdn_test_object['path']).with_name('gdn-test-identity.json')
    cached_test=read(gdn_test_receipt)
    assert cached_test['object']==gdn_test_object
    check(cached_test['source'])
    add(gdn_test_receipt,PREFIX+'retained-gdn-v23/gdn-test-identity.json')
    add(cached_test['source']['path'],PREFIX+'retained-gdn-v23/gdn_typed_load_test.cc')

    support, owners = set(), []
    local_deps = {}
    for row in plan['frozen']:
        path = Path(row['path']).resolve()
        if path.suffix.lower() in OMIT:
            continue
        check(row)
        # Actual89 header contents are already closed above. Older fallback
        # paths remain in literal command/dependency receipts, without payloads.
        old_header_root=ARCH/'cuda-fusion-precision/native-source'
        if path.is_relative_to(old_header_root):
            continue
        if not path.is_relative_to(STAGE) and path not in retained_header_paths:
            support.add(path)
    for owner in plan['compile']:
        record_path = plan_path.parent / (owner['tag'] + '-identity.json')
        record = read(record_path)
        assert record['command'] == owner['command']
        check(owner['source'])
        snapshot = plan_path.parent / 'compiled-source' / Path(owner['source']['path']).resolve().relative_to(ROOT)
        check(owner['source'], snapshot)
        for row in [record['source'], *record['dependencies']]:
            path = Path(row['path']).resolve()
            if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('src', 'include', 'tests', 'third_party', 'cmake'):
                check(row)
                previous = local_deps.get(str(path).casefold())
                assert previous is None or previous['sha256'] == row['sha256'], path
                local_deps[str(path).casefold()] = row
        check(owner['recipe'])
        support.add(Path(owner['recipe']['path']).resolve())
        owners.append(dict(tag=owner['tag'], source=record['source'], object=record['object'], receipt=identity(record_path)))
    for row in local_deps.values():
        path = Path(row['path']).resolve()
        add(path, PREFIX+'dependency-source/' + path.relative_to(ROOT).as_posix())

    # Follow only literal small Python helper dependencies, not prior stages.
    pending, seen = list(STAGE.rglob('*.py')), set()
    while pending:
        path = pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts:
            continue
        assert path.is_file() and path.is_relative_to(ROOT), path
        seen.add(path)
        code = path.read_text(encoding='utf-8')
        for variable, base in (('ARCH', ARCH), ('STAGE', path.parent), ('ROOT', ROOT)):
            pending += [base / value for value in re.findall(variable + r"\s*/\s*['\"]([^'\"]+\.py)['\"]", code)]
        if not path.is_relative_to(STAGE):
            support.add(path)
    inputs = read(STAGE / 'correctness/inputs.json')
    for key in ('manifest', 'prompt', 'decode'):
        check(inputs[key])
        support.add(Path(inputs[key]['path']).resolve())
    support.add(ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
    # Refer to already-established raw-vector provenance; never rehash the
    # model/64 equal tensors or recursively qualify old archives here.
    for rel in ('gdn-typed-load/archive-receipt.json', 'gdn-region-suffix/archive-receipt.json',
                'batch-graph-capture/archive-receipt.json',
                'batch-graph-capture/correctness-final/summary.json',
                'batch-graph-capture/correctness-final/inputs.json'):
        support.add(ARCH / rel)
    for rel in ('docs/architecture/compute-design.md', 'docs/implementation/model-operators.md', 'docs/developer/current-work.md',
                'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
        support.add(ROOT / rel)
    for path in sorted(support):
        assert path.suffix.lower() not in OMIT
        add(path, PREFIX+'support/' + path.relative_to(ROOT).as_posix())

    for path in STAGE.rglob('*'):
        if path.is_file() and eligible(path, STAGE):
            add(path, PREFIX + path.relative_to(STAGE).as_posix())
    scope = dict(native_version=native['version'], source_id=native['source_id'],
        host_TUs=4, native_TUs=2, tests=names, equal_vectors=64,
        unprofiled_processes=9, profile=profile_state, owners=owners,
        source_freezes=source_rows, native_header_count=89,
        unchanged_GDN_v23=dict(sources=retained_gdn,compiled_owner=gdn_owner,
            native_archive_receipt=read(prior_native/'archive-receipt.json'),
            selected_region_archive_receipt=read(ARCH/'gdn-region-suffix/archive-receipt.json')),
        local_dependencies=list(local_deps.values()),
        reference_evidence='support/.scratch/architecture-refactor-2026-10-18/batch-graph-capture/{archive-receipt.json,correctness-final/summary.json,correctness-final/inputs.json}',
        limits='Fixed-tape exact equality and directed primitive regressions only. No independent quality, cross-platform or statistically established speed claim. All raw failures are retained without promotion to pass.',
        excluded='SDK/model/object/image/debug/tmp/cache payloads, duplicate64raw hidden/logit tensors and redundant older89header/source trees; literal identities/commands remain. CachedGDN v23 CU and owner/test receipts are retained narrowly.',
        cleanup_executed=False)
    scope_bytes = (json.dumps(scope, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    manifest = {name: identity(path) for name, path in sorted(payloads.items())}
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payloads.items()):
            archive.write(path, name)
        archive.writestr('archive-scope.json', scope_bytes)
        archive.writestr('payload-sha256.json', manifest_bytes)
    expected = {name: row['sha256'] for name, row in manifest.items()}
    expected.update({'archive-scope.json': digest(scope_bytes), 'payload-sha256.json': digest(manifest_bytes)})
    # Exactly one decompressed pass verifies every payload's CRC32 and SHA256.
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist()) == len(expected)
        for info in archive.infolist():
            h, crc, size = hashlib.sha256(), 0, 0
            with archive.open(info) as handle:
                while chunk := handle.read(1024 * 1024):
                    h.update(chunk)
                    crc, size = zlib.crc32(chunk, crc), size + len(chunk)
            assert size == info.file_size and crc & 0xffffffff == info.CRC, info.filename
            assert h.hexdigest() == expected[info.filename], info.filename
    receipt = dict(**identity(DEST), entries=len(expected), payloads=len(manifest),
        crc_verified=True, payload_sha256_verified=True, verification_passes=1,
        build_plan=identity(plan_path), source_id=native['source_id'],
        host_TUs=4, native_TUs=2, tests=6, equal_vectors=64,
        unprofiled_processes=9, profile_ready=profile_ready,
        physical_expectations_met=profile.get('physical_expectations_met'),
        CRC_and_every_payload_SHA_verified=True,
        duplicate_raw_vectors_omitted=True, cleanup_executed=False)
    save(STAGE / 'archive-receipt.json', receipt)
    save(DEST.with_name('conv-typed-load-archive.json'), receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
