"""Prepare or collect one current Nsight trace; --analyze repeats offline only."""
from pathlib import Path
import argparse
import collections
import importlib.util
import json
import sys
import traceback

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('rope_profile_build', STAGE / 'build.py')
b, c = build.b, build.c
a = load('rope_phase_helpers', ARCH / 'cuda-stable-silu/profile-analysis-stable.py')


def analyze(out):
    stem = out / 'qwen-scalar-l2-trace'
    a.PROFILE = out  # Keep reused helper diagnostics/embedded logs inside this new stage.
    current = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'), candidate=True)
    old_stem = ARCH / 'cuda-explicit-rope/profile/qwen-explicit-rope-trace'
    old = a.load(Path(str(old_stem) + '.sqlite'), Path(str(old_stem) + '_cuda_gpu_kern_sum.csv'))
    phases, previous = a.phases(current), a.phases(old)
    checks = {'valid_phase_binning': phases['valid'] and previous['valid'],
        'official_csv_sqlite_equal': current['receipt']['csv_sqlite_per_symbol_counts_equal'],
        'no_graph_api_errors': not current['receipt']['graph_api_failures']}
    if not all(checks.values()):
        raise ValueError('Trace cannot establish valid physical counts')
    def bins(data, report):
        ends = [x['token_D2H_end_ns'] for x in report['phases']]
        return [[k for k in data['kernels'] if (ends[i - 1] if i else 0) < k['start'] <= ends[i]] for i in range(32)]
    now_bins, old_bins = bins(current, phases), bins(old, previous)
    counts = [{'phase': p['phase'], 'explicit_rope': sum('hyle_explicit_rope<' in x['name'] for x in rows),
        'l2_scalar_float_output': sum('hyle_bf16_l2_core<float,' in x['name'] and ('(bool)1>' in x['name'] or 'true>' in x['name']) for x in rows),
        'l2_all': sum('hyle_bf16_l2_core' in x['name'] for x in rows),
        'physical_kernels': p['physical_kernel_count'], 'GraphLaunch': p['graph_launch_count']}
        for p, rows in zip(phases['phases'], now_bins)]
    def average_symbols(rows):
        counter = collections.Counter(k['name'] for phase in rows[7:] for k in phase)
        return {k: v / 25 for k, v in counter.items()}
    now, before = average_symbols(now_bins), average_symbols(old_bins)
    deltas = [{'symbol': name, 'v17_per_warm_step': before.get(name, 0),
        'current_per_warm_step': now.get(name, 0), 'delta': now.get(name, 0) - before.get(name, 0)}
        for name in sorted(now.keys() | before.keys()) if now.get(name, 0) != before.get(name, 0)]
    result = {'checks': checks, 'analysis_runner': b.identity(Path(__file__)), 'receipt': current['receipt'], 'phases': phases,
        'v17_phases': previous, 'comparison': a.compare(current, old, phases, previous),
        'actual_counts_by_phase': counts, 'all_decode_steps_have12_explicit_rope': all(x['explicit_rope'] == 12 for x in counts[1:]),
        'warm_symbol_deltas': deltas,
        'profile_inputs': c.read(out / 'inputs.json'), 'throughput_claim': False, 'quality_acceptance': False,
        'limits': ['Only raw physical symbols establish this carrier hit, not cold route membership.',
            'The v17 and current trace durations are not a matched performance experiment.',
            'Profiler/driver warnings are retained; no total memory peak is inferred.']}
    c.save(out / 'analysis.json', result)
    print('PHYSICAL_ANALYSIS', out / 'analysis.json', 'explicit_rope_counts', [x['explicit_rope'] for x in counts], flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan', type=Path)
    p.add_argument('--run', action='store_true')
    p.add_argument('--analyze', action='store_true')
    p.add_argument('--out', type=Path, default=STAGE / 'profile')
    args = p.parse_args()
    out = args.out.resolve()
    if args.analyze:
        if args.run:
            raise ValueError('Offline analysis never recollects a trace')
        analyze(out)
        return
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    build.check(plan)
    image = b.identity(plan['links']['qwen']['image'])
    if image != c.read(plan_path.parent / 'qwen-image.json'):
        raise ValueError('Current image drift')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    original = c.read(ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    index = original.index('--inputs') - 1
    stem = out / 'qwen-scalar-l2-trace'
    command = [('--output=' + str(stem)) if x.startswith('--output=') else x for x in original[:index]] + [image['path']] + original[index + 1:]
    commands = {'profile': command, 'export': [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        'stats': [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum', '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite']}
    c.save(out / 'inputs.json', {'image': image, 'plan': b.identity(plan_path), 'sources': plan['frozen'],
        'runner': b.identity(Path(__file__)),
        'phase_helper': b.identity(ARCH / 'cuda-stable-silu/profile-analysis-stable.py'),
        'commands': commands, 'profiler_runs_planned': 1, 'execution_requested': args.run,
        'throughput_claim': False, 'quality_acceptance': False})
    print('PROFILE_PLAN', out / 'inputs.json', flush=True)
    if not args.run:
        return
    try:
        env, _ = b.environment(plan['links']['qwen']['command'], [x['path'] for x in plan['cached_inputs']], out)
        for tag, command in commands.items():
            c.execute(tag, command, env, out)
        analyze(out)
    except Exception as error:
        c.save(out / 'failure.json', {'error': str(error), 'GPU_retries': 0})
        (out / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise


if __name__ == '__main__':
    main()
