"""Represent scalar-left F32 division as a readonly native broadcast view."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
RELATIVE = 'src/compute_provider_ggml_cuda/tensor_program.cc'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    source = ROOT / RELATIVE
    snapshot = STAGE / 'before' / RELATIVE
    before = (snapshot if snapshot.is_file() else source).read_bytes()
    text = before.decode('utf-8').replace('\r\n', '\n')
    anchor = 'ggml_tensor *expand_broadcast(ggml_context *context, ggml_tensor *value,\n'
    helper = '''// binbcast's first input is read through its actual strides. A readonly
// scalar view supplies the output shape without a repeated tensor payload.
// Construct the original one-element view before expanding its metadata;
// ggml's dense view constructors would otherwise overstate its byte range.
ggml_tensor *scalar_broadcast_view(
    ggml_context *context, ggml_tensor *scalar,
    std::span<const std::int64_t, GGML_MAX_DIMS> shape) {
  auto *view = ggml_view_1d(context, scalar, 1, 0);
  for (std::size_t i = 0; i < GGML_MAX_DIMS; ++i) {
    view->ne[i] = shape[i];
    view->nb[i] = 0;
  }
  return view;
}

'''
    old_rsqrt = '''      result = ggml_div(context, ggml_repeat(context, one, a),
                        ggml_sqrt(context, a));'''
    new_rsqrt = '''      result = ggml_div(context,
                        scalar_broadcast_view(context, one,
                            std::span<const std::int64_t, GGML_MAX_DIMS>(
                                a->ne, GGML_MAX_DIMS)),
                        ggml_sqrt(context, a));'''
    old_binary = '''    auto *a =
        expand_broadcast(context, operand(0), recipe.values[node.inputs[0]], output);'''
    new_binary = '''    auto *left = operand(0);
    const std::array<std::int64_t, GGML_MAX_DIMS> shape{
        columns(output), rows(output), 1, 1};
    // Keep other operations' existing fusion/layout domains. Division has
    // an original stride-aware carrier for this F32 scalar-left case.
    auto *a = binary->kind == BinaryKind::kDivide &&
                      left->type == GGML_TYPE_F32 && ggml_nelements(left) == 1
                  ? scalar_broadcast_view(context, left, shape)
                  : expand_broadcast(context, left,
                                     recipe.values[node.inputs[0]], output);'''
    for old, new in ((anchor, helper + anchor), (old_rsqrt, new_rsqrt), (old_binary, new_binary)):
        if text.count(old) != 1:
            raise ValueError('Unexpected provider context')
        text = text.replace(old, new, 1)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(before)
    overlay = STAGE / 'provider-overlay' / RELATIVE
    overlay.parent.mkdir(parents=True, exist_ok=True)
    overlay.write_text(text, encoding='utf-8', newline='\n')
    (STAGE / 'provider-change.diff').write_text(''.join(difflib.unified_diff(
        before.decode().splitlines(True), text.splitlines(True), fromfile='a/' + RELATIVE,
        tofile='b/' + RELATIVE)), encoding='utf-8')
    record = {'source': RELATIVE, 'before_sha256': sha(before), 'overlay': str(overlay),
        'after_sha256': sha(overlay.read_bytes()), 'status': 'source_overlay_only',
        'scope': 'CUDA scalar-left F32 Divide and Rsqrt numerator; no model dimensions or public API',
        'other_binary_fusion_domains_changed': False}
    (STAGE / 'provider-source-freeze.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2), flush=True)


if __name__ == '__main__':
    main()
