"""Offline retained v17/peer review; no device, build or profiler execution."""
from pathlib import Path
import collections
import importlib.util
import re
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


a = module('retained_phase_reader', ARCH / 'cuda-stable-silu/profile-analysis-stable.py')
r = module('retained_family_reader', ARCH / 'cuda-bf16-dual-projection/residual_review.py')


def stats(values):
    values = list(values)
    return dict(min=min(values), median=statistics.median(values), max=max(values))


def family(name):
    return 'explicit_frequency_RoPE' if 'hyle_explicit_rope<' in name else r.family(name)


def review(stem):
    path = Path(str(stem) + '.sqlite')
    data = a.load(path, Path(str(stem) + '_cuda_gpu_kern_sum.csv'))
    phases = a.phases(data)
    assert phases['valid'] and data['receipt']['csv_sqlite_per_symbol_counts_equal']
    assert not data['receipt']['graph_api_failures']
    ends = [p['token_D2H_end_ns'] for p in phases['phases']]
    bins = [[k for k in data['kernels'] if ends[i-1] < k['start'] <= ends[i]] for i in range(7, 32)]
    kernels = [k for rows in bins for k in rows]
    total = sum(k['end'] - k['start'] for k in kernels)
    groups = []
    for name in sorted({family(k['name']) for k in kernels}):
        selected = [k for k in kernels if family(k['name']) == name]
        groups.append(dict(family=name, dispatches_per_warm_step=stats(
            sum(family(k['name']) == name for k in rows) for rows in bins),
            percent_of_own_summed_kernel_duration=100 * sum(k['end']-k['start'] for k in selected)/total))
    groups.sort(key=lambda g: -g['percent_of_own_summed_kernel_duration'])
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True) as con:
        apis = [dict(start=s, end=e, name=n, result=v) for s,e,n,v in con.execute(
            'select a.start,a.end,s.value,a.returnValue from CUPTI_ACTIVITY_KIND_RUNTIME a '
            'join StringIds s on s.id=a.nameId order by a.start')]
    calls = [api for api in apis if ends[6] < api['start'] <= ends[31]]
    api_names = {api['name'] for api in calls}
    api_groups = [dict(name=name, count_per_warm_step=sum(c['name']==name for c in calls)/25,
        own_host_API_duration_sum_us_per_warm_step=sum(c['end']-c['start'] for c in calls if c['name']==name)/25000)
        for name in api_names]
    api_groups.sort(key=lambda g: -g['own_host_API_duration_sum_us_per_warm_step'])
    return dict(sqlite=data['receipt']['sqlite'], official_csv=data['receipt']['official_csv'],
        phase_binning=phases['method'], csv_per_symbol_equal=True,
        physical_dispatches=stats(len(rows) for rows in bins),
        graph_node_dispatches=stats(sum(bool(k['graphNodeId']) for k in rows) for rows in bins),
        GraphLaunch_calls=stats(sum(ends[i-1]<c['start']<=ends[i] for c in data['launches']) for i in range(7,32)),
        own_summed_kernel_duration_us=stats(sum(k['end']-k['start'] for k in rows)/1000 for rows in bins),
        families=groups, top_runtime_API_intervals=api_groups[:10],
        warm_runtime_API_error_count=sum(c['result'] != 0 for c in calls),
        API_crosses_token_endpoint_count=sum(c['end']>ends[i] for i in range(7,32) for c in calls if ends[i-1]<c['start']<=ends[i]),
        warnings=[row['text'] for row in data['receipt']['warnings']])


def host_fields():
    path = ARCH / 'cuda-explicit-rope/profile/stable-silu-target-stderr.log'
    text = path.read_text(encoding='utf-8')
    prepared = [dict(cold_batch_seconds=float(t), recorded=int(n), reused=int(m)) for t,n,m in re.findall(
        r'cold_batch_seconds=([\d.e+-]+) capture_recorded=(\d+) capture_reused=(\d+)', text)]
    steps = [dict(phase=p, submit_seconds=float(s), step_seconds=float(t)) for p,s,t in re.findall(
        r'^(prefill|decode\d+) tokens=.*?submit_seconds=([\d.e+-]+) step_seconds=([\d.e+-]+)', text, re.M)]
    assert len(prepared) == len(steps) == 32
    return dict(log=a.identity(path), first_three=[dict(**steps[i], **prepared[i]) for i in range(3)],
        warm_decode7_31={key:stats(row[key] for row in rows[7:]) for rows,keys in
            ((prepared,('cold_batch_seconds',)),(steps,('submit_seconds','step_seconds'))) for key in keys},
        capture_recorded_total=sum(row['recorded'] for row in prepared),
        capture_reused_total=sum(row['reused'] for row in prepared),
        measured_boundaries='main.cc:497..536 cold_batch includes layout version, batch prepare, binds and prepare_replay; '
            '537..539 submit includes run.submit but excludes done.wait; 491..545 step includes uploads, prepare, submit, wait, ID readback. '
            'compile prepare(ids.size()) at490 precedes step_start; host stderr at546+ follows finished.')


def main():
    output = dict(scope='Retained v17 explicit-RoPE image and separately acquired peer; warm decode7..31 only.',
        script=a.identity(Path(__file__)),
        hyle=review(ARCH/'cuda-explicit-rope/profile/qwen-explicit-rope-trace'),
        peer=review(ARCH/'cuda-gdn-l2-fusion/peer-profile/peer-trace'),
        hyle_instrumented_host_fields=host_fields(),
        limits=['Each duration share uses only its own acquisition kernel-duration sum, not wall time; no cross-run subtraction or speedup estimate.',
            'Hyle/peer mathematical precision, projection fusion, activation and layout contracts differ; dispatch counts are not equal-work units.',
            'Runtime API intervals are host calls, can include waits and overlap GPU execution; nested driver calls are not added.',
            'Token endpoint bins include host work between steps and do not isolate CPU critical path or all prepare/capture cost. No CPU sampling/NVTX maps individual preparation functions.',
            'Logged profiled cold_batch/submit/step durations are descriptive only; capture records are real7 ranges per first3 phases, then reused.',
            'Physical symbol counts cannot alone map each cast/binary to a model value. New L2 epilogue needs fresh actual-hit/numeric evidence.'],
        product_changes=False, GPU_runs=0, builds=0, performance_claim=False)
    path=STAGE/'hotspots-review.json'
    a.save(path, output)
    print(path)
    for name in ('hyle','peer'):
        row=output[name]
        print(name, 'kernels',row['physical_dispatches'], 'GraphLaunch',row['GraphLaunch_calls'])
        print([(f['family'],f['dispatches_per_warm_step']['median'],round(f['percent_of_own_summed_kernel_duration'],3)) for f in row['families'][:6]])
    print('host',output['hyle_instrumented_host_fields']['warm_decode7_31'])


if __name__ == '__main__':
    main()
