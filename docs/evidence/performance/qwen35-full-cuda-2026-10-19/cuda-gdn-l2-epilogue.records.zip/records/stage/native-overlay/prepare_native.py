from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
MAIN_BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-explicit-rope/native-source'
NORM_BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-gdn-l2-fusion/native-source'

def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()

files = []
patch = ''
def emit(relative, before, after, source):
    global patch
    path = STAGE / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(after, encoding='utf-8', newline='\n')
    old_lines, new_lines = before.splitlines(True), after.splitlines(True)
    context = 3
    while True:
        edits = []
        for group in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_grouped_opcodes(context):
            edits.append({'before': ''.join(old_lines[group[0][1]:group[-1][2]]),
                          'after': ''.join(new_lines[group[0][3]:group[-1][4]])})
        replayed = before
        for edit in edits:
            if not edit['before'] or replayed.count(edit['before']) != 1:
                break
            replayed = replayed.replace(edit['before'], edit['after'], 1)
        else:
            if replayed == after:
                break
        context *= 2
        assert context < max(len(old_lines), len(new_lines)) * 2
    files.append({'path': relative, 'before_path': str(source.relative_to(ROOT)),
                  'before_sha256': sha(before), 'after_sha256': sha(after),
                  'after_bytes': len(after.encode()), 'edits': edits})
    patch += ''.join(difflib.unified_diff(old_lines, new_lines, fromfile='a/' + relative, tofile='b/' + relative))

path = MAIN_BASE / 'src/ggml-cuda/ggml-cuda.cu'
main = path.read_text(encoding='utf-8')
assert sha(main) == 'ec7294c0c2fd335f1e8402023751dc4229744809f2f33df5561534bdd30cb7e2'
after = main
old = '''struct ggml_cuda_bf16_l2_core_match {
    const ggml_tensor * x = nullptr;
    const ggml_tensor * epsilon = nullptr;
    const ggml_tensor * numerator = nullptr;
    ggml_tensor * dst = nullptr;
    int count = 0;
};'''
new = old.replace('    int count = 0;', '    bool scalar_numerator = false;\n    int count = 0;')
assert after.count(old) == 1
after = after.replace(old, new, 1)
start = after.index('static bool ggml_cuda_match_bf16_l2_core(')
end = after.index('\n#endif', start)
matcher = after[start:end]
old = '''    if (!numerator || numerator->type != GGML_TYPE_F32 ||
        !ggml_is_contiguous(numerator) || !rows_like(numerator)) {
        return false;
    }
    const ggml_tensor * rounded_inverse = cast(GGML_TYPE_BF16, inverse);'''
new = '''    if (!numerator || numerator->type != GGML_TYPE_F32 || !rows_like(numerator)) {
        return false;
    }
    const ggml_tensor * numerator_input = numerator;
    bool scalar_numerator = false;
    // A readonly scalar broadcast is a real zero-stride VIEW, not a producer
    // to elide. Keep all metadata/source readers and original use counts.
    if (numerator->op == GGML_OP_VIEW && numerator->view_src && !numerator->view_offs &&
        numerator->src[0] && numerator->src[0]->type == GGML_TYPE_F32 &&
        ggml_is_contiguous(numerator->src[0]) && ggml_nelements(numerator->src[0]) == 1 &&
        numerator->data == numerator->src[0]->data) {
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (numerator->nb[axis] != 0) {
                return false;
            }
        }
        for (int s = 1; s < GGML_MAX_SRC; ++s) {
            if (numerator->src[s]) {
                return false;
            }
        }
        const ggml_tensor * root = numerator->src[0];
        while (root->view_src) {
            if (root->view_offs || root->type != root->view_src->type ||
                root->data != root->view_src->data) {
                return false;
            }
            root = root->view_src;
        }
        if (numerator->view_src != root) {
            return false;
        }
        numerator_input = numerator->src[0];
        scalar_numerator = true;
    } else if (!ggml_is_contiguous(numerator)) {
        return false;
    }
    const ggml_tensor * rounded_inverse = cast(GGML_TYPE_BF16, inverse);'''
assert matcher.count(old) == 1
matcher = matcher.replace(old, new, 1)
old = '''        if (graph->nodes[i] == x || graph->nodes[i] == epsilon || graph->nodes[i] == numerator) {
            return false;
        }
    }
    if (!ggml_cuda_private_fusion_closed(graph, begin, next - begin) ||
        !ggml_cuda_rms_cast_input_safe(dst, x) ||
        !ggml_cuda_rms_cast_disjoint(dst, epsilon) ||
        !ggml_cuda_rms_cast_disjoint(dst, numerator)) {
        return false;
    }
    match = {x, epsilon, numerator, dst, next - begin};
    return true;'''
new = '''        if (graph->nodes[i] == x || graph->nodes[i] == epsilon || graph->nodes[i] == numerator_input) {
            return false;
        }
    }
    const auto eligible = [&](ggml_tensor * output, int count) {
        // F32's wider storage cannot reuse the BF16 input's exact mapping.
        return ggml_cuda_private_fusion_closed(graph, begin, count) &&
            (output->type == GGML_TYPE_BF16 ? ggml_cuda_rms_cast_input_safe(output, x)
                                          : ggml_cuda_rms_cast_disjoint(output, x)) &&
            ggml_cuda_rms_cast_disjoint(output, epsilon) &&
            ggml_cuda_rms_cast_disjoint(output, numerator_input);
    };
    // Keep the BF16 RNE boundary even when its sole reader is this exact cast.
    // A published/extra-read product keeps its old BF16 carrier and cast.
    if (next < graph->n_nodes) {
        ggml_tensor * wide = graph->nodes[next];
        if (wide->op == GGML_OP_CPY && wide->type == GGML_TYPE_F32 &&
            wide->src[0] == dst && wide->src[1] == wide && !wide->view_src &&
            ggml_is_contiguous(wide) && ggml_are_same_shape(wide, dst) &&
            eligible(wide, next + 1 - begin)) {
            match = {x, epsilon, numerator_input, wide, scalar_numerator, next + 1 - begin};
            return true;
        }
    }
    if (!eligible(dst, next - begin)) {
        return false;
    }
    match = {x, epsilon, numerator_input, dst, scalar_numerator, next - begin};
    return true;'''
assert matcher.count(old) == 1
matcher = matcher.replace(old, new, 1)
after = after[:start] + matcher + after[end:]
old = '''            ggml_cuda_op_bf16_l2_core_fused(*cuda_ctx, l2.x, l2.epsilon, l2.numerator, l2.dst);'''
new = '''            ggml_cuda_op_bf16_l2_core_fused(*cuda_ctx, l2.x, l2.epsilon, l2.numerator,
                                           l2.dst, l2.scalar_numerator);'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
emit('src/ggml-cuda/ggml-cuda.cu', main, after, path)

path = NORM_BASE / 'src/ggml-cuda/norm.cuh'
header = path.read_text(encoding='utf-8')
assert sha(header) == '17db866063e3082e5b8e96f44af714ef5f9f81326b21864163df273e71134998'
begin = header.index('// Dense BF16 square')
after = header[:begin] + '''// Dense BF16 square -> F32 SUM_ROWS -> BF16 sum/add -> strict F32 sqrt ->
// fast F32 div -> BF16 scale/multiply, preserving every original BF16 RNE.
// Optional F32 output is the exact widening of that final BF16 result.
// x/BF16 dst may be disjoint or exact same dense mapping; F32 dst must be
// disjoint. epsilon is one runtime BF16 scalar. numerator is either the
// original F32 row vector [1,x.ne[1],x.ne[2],x.ne[3]], or (only when its
// readonly zero-stride VIEW broadcasts it) one runtime F32 scalar. Neither input
// may overlap dst. Matcher owns private-reader/control closure and memory
// eligibility; the original carrier validates actual bindings before launch.
void ggml_cuda_op_bf16_l2_core_fused(ggml_backend_cuda_context & ctx,
                                     const ggml_tensor * x,
                                     const ggml_tensor * epsilon,
                                     const ggml_tensor * numerator,
                                     ggml_tensor * dst,
                                     bool scalar_numerator);
'''
emit('src/ggml-cuda/norm.cuh', header, after, path)

path = NORM_BASE / 'src/ggml-cuda/norm.cu'
norm = path.read_text(encoding='utf-8')
assert sha(norm) == 'e42fedea9866cdc7244fa38bf0d1f65c803927248f042fa9a667cc137d5c8000'
after = norm
old = '''// HYLE's composed BF16 L2 core, not GGML_OP_L2_NORM. Keep the original
// REPEAT numerator and the final public cast outside this carrier.'''
new = '''// HYLE's composed BF16 L2 core, not GGML_OP_L2_NORM. Optional private
// scalar broadcast and final BF16->F32 widening keep the same arithmetic.'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
old = '''static __global__ void hyle_bf16_l2_core(
        const nv_bfloat16 * x, const nv_bfloat16 * epsilon,
        const float * numerator, nv_bfloat16 * dst, const int ncols) {'''
new = '''template <typename Dst, bool scalar_numerator>
static __global__ void hyle_bf16_l2_core(
        const nv_bfloat16 * x, const nv_bfloat16 * epsilon,
        const float * numerator, Dst * dst, const int ncols) {'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
old = '''        // FTZ behavior. The runtime REPEAT output remains an actual input.
        row_scale = __bfloat162float(__float2bfloat16_rn(numerator[row] / root));'''
new = '''        // FTZ behavior. Scalar mode reads the actual runtime source, not 1.
        row_scale = __bfloat162float(__float2bfloat16_rn(numerator[scalar_numerator ? 0 : row] / root));'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
old = '''        dst[index] = __float2bfloat16_rn(__bfloat162float(x[index]) * row_scale);'''
new = '''        const nv_bfloat16 rounded = __float2bfloat16_rn(__bfloat162float(x[index]) * row_scale);
        if constexpr (std::is_same_v<Dst, float>) {
            dst[index] = __bfloat162float(rounded);
        } else {
            dst[index] = rounded;
        }'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
begin = after.index('void ggml_cuda_op_bf16_l2_core_fused(')
after = after[:begin] + '''void ggml_cuda_op_bf16_l2_core_fused(ggml_backend_cuda_context & ctx,
                                     const ggml_tensor * x,
                                     const ggml_tensor * epsilon,
                                     const ggml_tensor * numerator,
                                     ggml_tensor * dst,
                                     bool scalar_numerator) {
    const auto invalid = []() {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
            "invalid BF16 composed L2 bindings");
    };
    if (!x || !epsilon || !numerator || !dst || x->type != GGML_TYPE_BF16 ||
        (dst->type != GGML_TYPE_BF16 && dst->type != GGML_TYPE_F32) ||
        epsilon->type != GGML_TYPE_BF16 || ggml_nelements(epsilon) != 1 ||
        numerator->type != GGML_TYPE_F32 || numerator->ne[0] != 1 ||
        !ggml_is_contiguous(x) || !ggml_is_contiguous(dst) ||
        !ggml_is_contiguous(epsilon) || !ggml_is_contiguous(numerator) ||
        !ggml_are_same_shape(x, dst) ||
        x->ne[0] <= 0 || x->ne[0] > INT_MAX ||
        ggml_nrows(x) <= 0 || ggml_nrows(x) > INT_MAX) {
        invalid();
    }
    if (scalar_numerator) {
        if (ggml_nelements(numerator) != 1) {
            invalid();
        }
    } else {
        for (int axis = 1; axis < GGML_MAX_DIMS; ++axis) {
            if (numerator->ne[axis] != x->ne[axis]) {
                invalid();
            }
        }
    }
    const ggml_tensor * tensors[] = {x, epsilon, numerator, dst};
    uintptr_t begin[4] = {}, end[4] = {};
    for (int i = 0; i < 4; ++i) {
        begin[i] = reinterpret_cast<uintptr_t>(tensors[i]->data);
        const size_t bytes = ggml_nbytes(tensors[i]);
        if (!begin[i] || begin[i] % ggml_type_size(tensors[i]->type) || bytes > UINTPTR_MAX - begin[i]) {
            invalid();
        }
        end[i] = begin[i] + bytes;
    }
    for (int i = 0; i < 3; ++i) {
        const bool overlaps = begin[i] < end[3] && begin[3] < end[i];
        const bool exact_x = i == 0 && dst->type == GGML_TYPE_BF16 &&
            begin[0] == begin[3] && ggml_are_same_layout(x, dst);
        if (overlaps && !exact_x) {
            invalid();
        }
    }

#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const int ncols = int(x->ne[0]);
    const int nrows = int(ggml_nrows(x));
    const int id = ggml_cuda_get_device();
    if (id < 0 || id >= ggml_cuda_info().device_count ||
        !GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[id].cc) ||
        ggml_cuda_info().devices[id].nsm <= 0) {
        invalid();
    }
    const int nsm = ggml_cuda_info().devices[id].nsm;
    // Match sumrows.cu exactly: changing this selection changes the FP32 tree.
    const dim3 blocks_num(nrows, 1, 1);
    const dim3 block_dims((nrows / nsm) < 2 ? 512 : (ncols < 1024 ? 32 : 128), 1, 1);
    const ggml_cuda_kernel_launch_params launch_params =
            ggml_cuda_kernel_launch_params(blocks_num, block_dims, 0, ctx.stream());
    const auto launch = [&](auto * typed_dst) {
        using Dst = std::remove_pointer_t<decltype(typed_dst)>;
        if (scalar_numerator) {
            ggml_cuda_kernel_launch(hyle_bf16_l2_core<Dst, true>, launch_params,
                (const nv_bfloat16 *) x->data, (const nv_bfloat16 *) epsilon->data,
                (const float *) numerator->data, typed_dst, ncols);
        } else {
            ggml_cuda_kernel_launch(hyle_bf16_l2_core<Dst, false>, launch_params,
                (const nv_bfloat16 *) x->data, (const nv_bfloat16 *) epsilon->data,
                (const float *) numerator->data, typed_dst, ncols);
        }
    };
    if (dst->type == GGML_TYPE_F32) {
        launch(static_cast<float *>(dst->data));
    } else {
        launch(static_cast<nv_bfloat16 *>(dst->data));
    }
#else
    GGML_UNUSED(ctx);
    invalid();
#endif
}
'''
emit('src/ggml-cuda/norm.cu', norm, after, path)

(STAGE / 'changes.diff').write_text(patch, encoding='utf-8', newline='\n')
(STAGE / 'replacements.json').write_text(json.dumps({'files': files}, indent=2) + '\n', encoding='utf-8', newline='\n')
freeze = {'state': 'Scratch-only BF16 L2 carrier extension, no product manifest/lock, no compile/GPU.',
          'files': [{k: v for k, v in file.items() if k != 'edits'} for file in files],
          'precision': 'Original eight partials, block reduction, launch selection and all five BF16 RNE boundaries; strict sqrt; original fast division/FTZ. Optional output F32 widens the rounded BF16 value.',
          'closure': 'Readonly scalar VIEW is only an input with exact source/root/offset/stride proof, never skipped; optional adjacent exact BF16->F32 CPY suffix. Existing CPY self, metadata/view/output readers and use counts unchanged; original dense row numerator remains supported.'}
(STAGE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'files': len(files), 'freeze_sha256': hashlib.sha256((STAGE / 'source-freeze.json').read_bytes()).hexdigest()}))
