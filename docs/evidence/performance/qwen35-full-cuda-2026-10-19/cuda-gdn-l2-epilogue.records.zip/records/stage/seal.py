"""Apply the reviewed scalar representation and typed L2 carrier increment."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('l2_retained_seal', STAGE.parent / 'cuda-explicit-rope/seal.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
s = prior.s


def main():
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    before = STAGE / 'before-seal'
    before.mkdir(exist_ok=False)
    for name, path in (('patches.json', vendor / 'patches.json'), ('NOTICE.md', vendor / 'NOTICE.md'),
                       ('dependency-lock.json', ROOT / 'cmake/HyleDependencyLock.json')):
        (before / name).write_bytes(path.read_bytes())
    manifest = s.read(vendor / 'patches.json')
    native = s.read(STAGE / 'native-overlay/source-freeze.json')
    expected = {row['path']: row for row in native['files']}
    for change in s.read(STAGE / 'native-overlay/replacements.json')['files']:
        row = next((r for r in manifest['files'] if r['path'] == change['path']), None)
        if row is None:
            row = {'path': change['path'], 'before_sha256': s.sha((s.UPSTREAM / change['path']).read_bytes().replace(b'\r\n', b'\n')), 'edits': []}
            manifest['files'].append(row)
        row['edits'].extend(change['edits'])
        row['after_sha256'] = s.sha(prior.replay(row))
    proposed = STAGE / 'patches.draft.json'
    s.save(proposed, manifest)
    runtime = ROOT / 'src/compute_ggml_runtime'
    mixed, combined = STAGE / 'mixed-cpu-manifest.json', STAGE / 'combined-manifest.json'
    s.load('l2_mixed_cpu', runtime / 'prepare_mixed_cpu_manifest.py').derive(s.UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    s.load('l2_cuda_iq1', runtime / 'prepare_cuda_iq1_manifest.py').derive(s.UPSTREAM, mixed,
        proposed, vendor / 'iq1-patches.json', combined)
    outputs = {}
    for row in s.read(combined)['files']:
        data = prior.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Mixed source replay differs')
        if row['path'] in expected:
            if s.sha(data) != expected[row['path']]['after_sha256']:
                raise ValueError('Reviewed native source differs: ' + row['path'])
            outputs[row['path']] = data
    if len(outputs) != 3:
        raise ValueError('Expected main/norm/header only')
    provider = s.read(STAGE / 'provider-source-freeze.json')
    source = ROOT / provider['source']
    if s.sha(source.read_bytes()) != provider['before_sha256']:
        raise ValueError('Provider source drift')
    tests = ROOT / 'tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc'
    overlay_test = STAGE / 'test-overlay/tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc'
    if s.sha(tests.read_bytes()) != '8e5cf2db3d6dffd40c14693e7586db89ac04f5bfd5126b663ac7e365a091c6fb' or s.sha(overlay_test.read_bytes()) != '6ab8c7e710d3379173d90eff861ec30fb2f1c1ec90f62201c08c6b207142ad22':
        raise ValueError('Test source differs from reviewed overlay')
    (before / tests.name).write_bytes(tests.read_bytes())
    # All reviewed source compositions succeeded before applying product files.
    for relative, data in outputs.items():
        target = STAGE / 'native-source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    (vendor / 'patches.json').write_bytes(proposed.read_bytes())
    source.write_bytes(Path(provider['overlay']).read_bytes())
    tests.write_bytes(overlay_test.read_bytes())
    notice = vendor / 'NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip() + '''

The composed BF16 L2 implementation shares its original reduction with optional
F32 output and scalar numerator variants. F32 output explicitly widens the final
BF16-rounded product; scalar mode reads the real input behind a readonly exact
zero-stride view. The private closure and output/input range checks protect
published BF16 intermediates and other readers. F32 output must be disjoint from
BF16 input; the original BF16 exact-in-place case remains valid. Generic F32
scalar-left division and Rsqrt preparation use the same native broadcast view
without a repeated payload. Other binary fusion/layout domains are unchanged.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v18'
    cuda['vendored']['tree_sha256'] = s.tree(vendor)
    for item in cuda['license']['files']:
        if item['root'] == 'hyle' and item['path'].endswith('NOTICE.md'):
            item['sha256'] = s.sha(notice.read_bytes())
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    s.save(STAGE / 'native-source-freeze.json', {'version': cuda['version'], 'source_id': source_id,
        'vendor_tree_sha256': cuda['vendored']['tree_sha256'],
        'sources': {relative: s.sha(data) for relative, data in outputs.items()},
        'all_mixed_CPU_IQ1_CUDA_edits_replayed': True, 'SDK_modified': False,
        'public_API_changed': False, 'numerical_contract_changed': False})
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED', source_id, flush=True)


if __name__ == '__main__':
    main()
