param([switch]$ReclaimExplicitRope)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimExplicitRope) { throw 'Use -ReclaimExplicitRope for this batch.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18/cuda-explicit-rope'))
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes) { throw "Target changed: $resolved" }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
@{targets=$targets;bytes=($targets | Measure-Object bytes -Sum).Sum;recursive=$false;objects_retained=$true;latest_three_images_retained=$true} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskRoot 'reclaim-receipt.json') -Encoding utf8
