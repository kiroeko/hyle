"""Prepare, or --run exactly two fixed-input Qwen journeys; no quality verdict."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import sys
import traceback

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
V16 = ARCH / 'cuda-explicit-rope'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('rope_check_build', STAGE / 'build.py')
n = load('rope_retained_numeric_helpers', ARCH / 'cuda-bf16-dual-projection/compare_numerics.py')
b, c = build.b, build.c


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan', type=Path)
    p.add_argument('--run', action='store_true')
    p.add_argument('--out', type=Path)
    args = p.parse_args()
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if plan['native_source_id'] != '971b3d4968812a0f' or not c.read(plan_path.parent / 'summary.json')['passed']:
        raise ValueError('Expected successful v18 scalar/L2 build')
    out = args.out.resolve() if args.out else STAGE / 'correctness' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    reference = V16 / 'correctness/current'
    prior = c.read(V16 / 'checks/20261019T100154/qwen-link-plan.json')
    if [c.key(x) for x in plan['links']['baseline']['inputs']] != [c.key(x['path']) for x in prior['inputs']]:
        raise ValueError('Baseline does not use the exact v17 current object closure')
    vectors = {x.relative_to(reference / 'trace'): n.identity(x)
        for x in sorted((reference / 'trace').rglob('*')) if x.suffix in ('.bf16', '.f32')}
    expected = {Path(phase) / name for phase in n.PHASES for name in ('hidden.bf16', 'logits.f32')}
    if set(vectors) != expected:
        raise ValueError('Expected exact v17 current64 hidden/logits observations')
    result = n.final_json(reference / 'qwen.stdout.log')
    old = c.read(reference / 'qwen.command.json')['command']
    inputs = Path(old[old.index('--inputs') + 1])
    decode = Path(old[old.index('--decode-ids') + 1])
    manifest = inputs / 'weights.tsv'
    lines = manifest.read_text(encoding='utf-8').splitlines()
    inventory_path = ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json'
    inventory = c.read(inventory_path)
    model = Path(lines[1])
    record = next(x for x in inventory['files'] if x['path'] == model.name)
    if lines[0] != 'HYLE_QWEN35_TEXT_V1' or lines[2] != inventory['artifact_identity_sha256'] or len(lines[3:]) != 320:
        raise ValueError('Local model inventory differs')
    images = {arm: b.identity(plan['links'][key]['image']) for arm, key in (('baseline', 'baseline'), ('current', 'qwen'))}
    for arm, key in (('baseline', 'baseline'), ('current', 'qwen')):
        if images[arm] != c.read(plan_path.parent / (key + '-image.json')):
            raise ValueError('Image drift: ' + arm)
    commands = {}
    for arm in images:
        command = list(old)
        command[0] = images[arm]['path']
        command[command.index('--trace') + 1] = str(out / arm / 'trace')
        commands[arm] = command
    report = {'schema': 'hyle.qwen.scalar_l2_checks.v1', 'status': 'prepared_not_run',
        'native_source_id': plan['native_source_id'], 'images': images, 'commands': commands,
        'inputs': {'model': {'path': str(model), 'bytes': record['size_bytes'], 'sha256': record['sha256']},
            'inventory': b.identity(inventory_path), 'manifest': b.identity(manifest),
            'prompt': b.identity(inputs / 'prompt.ids'), 'decode': b.identity(decode),
            'reference_result': b.identity(reference / 'qwen.stdout.log'), 'reference_vectors': list(vectors.values()),
            'plan': b.identity(plan_path), 'runner': b.identity(Path(__file__)), 'sources': plan['frozen']},
        'arms': {}, 'quality_acceptance': False, 'throughput_claim': False}
    c.save(out / 'plan.json', report)
    print('PLAN', out / 'plan.json', flush=True)
    if not args.run:
        return
    try:
        if b.identity(model) != report['inputs']['model']:
            raise ValueError('Actual model differs from its shard inventory')
        for arm in ('baseline', 'current'):
            run = out / arm
            run.mkdir()
            (run / 'tmp').mkdir()
            build.check(plan)
            if b.identity(images[arm]['path']) != images[arm]:
                raise ValueError('Image changed before execution')
            env, _ = b.environment(plan['links']['qwen']['command'], [x['path'] for x in plan['cached_inputs']], run)
            c.execute('qwen', commands[arm], env, run)
            observed = n.analyze_arm(arm, images[arm], run, vectors, result)
            report['arms'][arm] = observed
            c.save(out / 'summary.json', report)
            if arm == 'baseline' and observed['equal_vectors'] != 64:
                raise ValueError('Baseline differs from exact v17 current64 payloads')
        checks = {}
        for arm, observed in report['arms'].items():
            checks[arm] = {'equal64': observed['equal_vectors'] == 64,
                'same32_ids': observed['same_greedy_ids_as_reference'],
                'same31_inputs': observed['same_fixed_decode_inputs'],
                'capture32x7': observed['capture_32_phases_with_7_ranges'],
                'finite': observed['all_outputs_finite'],
                'model': observed['source_id'] == lines[2] and observed['text_tensors'] == 320 and observed['fixed_decode'],
                'workspace_reported': {x['tokens'] for x in observed['workspace']} == {1, 128}}
        report.update(status='two_journeys_terminal_zero', checks=checks,
            passed=all(all(x.values()) for x in checks.values()), numerical_quality_acceptance=False)
        c.save(out / 'summary.json', report)
        print('CORRECTNESS', out / 'summary.json', 'passed', report['passed'], flush=True)
        if not report['passed']:
            raise ValueError('Exact replacement observation differs; full diagnostics retained')
    except Exception as error:
        report.update(error=str(error), passed=False)
        c.save(out / 'summary.json', report)
        (out / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise


if __name__ == '__main__':
    main()
