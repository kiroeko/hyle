from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('recipe',Path(__file__).with_name('build.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=m.read(m.OUT/'run-plan.json')
assert not any(x['tag']=='consumer-tests-run' for x in m.read(m.OUT/'commands.json'))
m.command('consumer-tests-run',plan['command'])
