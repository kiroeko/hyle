from pathlib import Path
import hashlib,json,os,subprocess,sys,time,difflib
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
TEMPLATE=read(ARCH/'cuda-admitted-ggml-stream-implementation/provider-test-identity.json')['command']
BASE_PATH=ARCH/'ggml-cuda-caller-workspace/candidate-link-plan.json';BASE=read(BASE_PATH)['command']
ENV=windows_compiler_environment({'CMAKE_CXX_COMPILER':TEMPLATE[0]});ENV['VSLANG']='1033'
ENV['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE if Path(v).is_absolute() and v.lower().endswith('.lib')))+os.pathsep+ENV['PATH']
MIGRATION=read(ARCH/'ggml-cuda-caller-workspace-consumers/summary.json')
SOURCES=[(path,str(Path(path).parent.name)+'--'+Path(path).stem.replace('_','-')) for path in MIGRATION['minimal_current_cuda_owner_tus']]
TESTS=MIGRATION['suggested_minimum_cuda_filter'].split(':')

def command(tag,argv):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}';row=dict(tag=tag,command=list(map(str,argv)),cwd=str(ROOT),started=time.time(),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log');rows.append(row);save(OUT/'commands.json',rows)
 print('START',stem,flush=True)
 with (OUT/row['stdout']).open('wb') as so,(OUT/row['stderr']).open('wb') as se:
  proc=subprocess.Popen(row['command'],cwd=ROOT,env=ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=proc.pid;save(OUT/'live.json',row);save(OUT/'commands.json',rows);row['exit']=proc.wait()
 row['seconds']=time.time()-row['started'];row['terminal']=True;save(OUT/'commands.json',rows);save(OUT/'live.json',row)
 print('END',stem,row['exit'],round(row['seconds'],3),flush=True)
 if row['exit']:
  print((OUT/row['stdout']).read_text(errors='replace')[-7000:]);print((OUT/row['stderr']).read_text(errors='replace')[-5000:]);raise SystemExit(row['exit'])

def compile_one(source,name):
 src=ROOT/source;before=ident(src);dst=OUT/'candidate'/source;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
 receipt=OUT/(name+'-identity.json')
 if receipt.exists():
  old=read(receipt)
  assert old['source']==before and ident(old['object']['path'])==old['object']
  assert all(ident(x['path'])==x for x in old['hyle_dependencies'])
  print('REUSE current freshly compiled',name,flush=True);return
 argv=[x for x in TEMPLATE if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 argv += ['/I'+str(ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows/src')]
 argv+=['/sourceDependencies',str(OUT/(name+'-deps.json')),str(src),'/Fo'+str(OUT/(name+'.obj'))]
 command(name+'-compile',argv);assert ident(src)==before
 deps=read(OUT/(name+'-deps.json'))['Data']['Includes'];hyle=[ident(v) for v in deps if Path(v).resolve().is_relative_to(ROOT.resolve())]
 save(OUT/(name+'-identity.json'),dict(source=before,object=ident(OUT/(name+'.obj')),command=argv,hyle_dependencies=hyle))

def build():
 direct=read(ARCH/'ggml-cuda-caller-workspace-consumers/source-identities.json')
 for row in direct:
  x=ident(ROOT/row['path']);assert x['bytes']==row['bytes'] and x['sha256']==row['sha256'],row['path']
 provider=ARCH/'ggml-cuda-caller-workspace/provider.obj';adapter=ARCH/'ggml-cuda-caller-workspace/adapter.obj'
 product=[ident(p) for p in [provider,adapter,ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',ROOT/'src/compute_provider_ggml_cuda/program.h',ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc']]
 assert BASE.count(str(provider))==BASE.count(str(adapter))==1
 for source,name in SOURCES:compile_one(source,name)
 assert all(ident(x['path'])==x for x in product)
 consumer=str(ARCH/'qwen-gpu-comparison/hyle-consumer.obj');assert BASE.count(consumer)==1
 argv=[x for x in BASE if x!=consumer and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 argv[6:6]=[str(OUT/(n+'.obj')) for _,n in SOURCES]
 argv += [str(ROOT/'.scratch/build-compute-v2-dev/lib'/n) for n in ['gtest_main.lib','gtest.lib']]
 argv += ['/OUT:'+str(OUT/'consumer-tests.exe'),'/MAP:'+str(OUT/'consumer-tests.map'),'/IMPLIB:'+str(OUT/'consumer-tests.lib')]
 assert all(Path(x).is_file() for x in argv if Path(x).is_absolute() and Path(x).suffix.lower() in {'.obj','.lib'})
 save(OUT/'link-plan.json',dict(command=argv,base=ident(BASE_PATH),product=product,only_changes=['replace qwen consumer by 8 fresh test TUs','gtest libraries','output paths']))
 command('consumer-tests-link',argv)
 maptext=(OUT/'consumer-tests.map').read_text(errors='replace')
 selected=[OUT/(n+'.obj') for _,n in SOURCES]+[provider,adapter]
 save(OUT/'map-owners.json',dict(map=ident(OUT/'consumer-tests.map'),selected=[dict(object=ident(p),map_mentions=sum(Path(p).name in line for line in maptext.splitlines())) for p in selected]))
 rows={}
 for _,name in SOURCES:
  rec=read(OUT/(name+'-identity.json'))
  for before in [rec['source'],*rec['hyle_dependencies']]:
   now=ident(before['path']);rows[now['path']]=dict(**now,matched=now==before)
 check=dict(checked=len(rows),drift=[x for x in rows.values() if not x['matched']],rows=list(rows.values()));assert not check['drift'];save(OUT/'dependency-check.json',check)
 plan=dict(command=[str(OUT/'consumer-tests.exe'),'--gtest_filter='+':'.join(TESTS),'--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')],cwd=str(ROOT),path_prepend=list(dict.fromkeys(str(Path(v).parent) for v in BASE if Path(v).is_absolute() and v.lower().endswith('.lib'))),not_run=True,scope='8 exact migration tests; no full suite; 8 fresh CUDA test owners including 2 shared fixture users')
 save(OUT/'run-plan.json',plan)
 save(OUT/'build-summary.json',dict(status='8_test_TUs_compiled_linked_not_run',source=ident(ROOT/SOURCES[0][0]),fresh_tests=[read(OUT/(name+'-identity.json'))['object'] for _,name in SOURCES],product=product,dependency_check=ident(OUT/'dependency-check.json'),image=ident(OUT/'consumer-tests.exe'),commands=len(read(OUT/'commands.json')),tests=TESTS,no_native_or_sdk_build=True))
 save(OUT/'cleanup-windows.json',dict(root=str(OUT.resolve()),files=[ident(OUT/n) for n in ['consumer-tests.exe','consumer-tests.map','consumer-tests.exp','consumer-tests.lib'] if (OUT/n).exists()],retain=[ident(OUT/(n+'.obj')) for _,n in SOURCES]))
 for row in direct:
  source=ROOT/row['path'];dest=OUT/'candidate'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes())
 save(OUT/'migration-source-identities.json',[ident(ROOT/row['path']) for row in direct])

if __name__=='__main__':
 assert sys.argv[1:] == ['build']
 build()
