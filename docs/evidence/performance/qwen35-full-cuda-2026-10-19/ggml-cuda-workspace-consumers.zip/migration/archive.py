"""Archive the frozen consumer migration and its bounded CUDA validation."""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
VALIDATION = STAGE.parent / "ggml-cuda-caller-workspace-consumer-validation"
REVIEW = STAGE.parent / "ggml-cuda-cold-pack-review.json"
OUTPUT = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-workspace-consumers.zip"
ALLOWED = {".json", ".diff", ".h", ".cc", ".py", ".log", ".xml"}
GENERATED = {"archive-inventory.json", "archive-receipt.json"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    summary_bytes = (VALIDATION / "summary.json").read_bytes()
    assert digest(summary_bytes) == "274b17412af9b1e63809869c7dbc913a06f6a1e3ae1e6d065fb1d64e07dda419"
    summary = json.loads(summary_bytes)
    assert summary["run"]["exit"] == 0 and len(summary["run"]["tests"]) == 8
    assert len(summary["fresh_test_owners"]) == 8
    assert summary["dependencies"] == dict(summary["dependencies"], checked=83, drift=0)
    cases = list(ET.parse(VALIDATION / "tests.xml").getroot().iter("testcase"))
    assert len(cases) == 8
    assert all(not list(case) for case in cases)
    for source in json.loads((STAGE / "source-identities.json").read_bytes()):
        assert digest((ROOT / source["path"]).read_bytes()) == source["sha256"]
    payloads = {}
    excluded = []
    for prefix, folder in [("migration", STAGE), ("validation", VALIDATION)]:
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            name = prefix + "/" + path.relative_to(folder).as_posix()
            if path.name in GENERATED or path.suffix.lower() not in ALLOWED or "__pycache__" in path.parts:
                excluded.append({"path": name, "bytes": path.stat().st_size})
                continue
            payloads[name] = (path, path.read_bytes())
    payloads["reviews/ggml-cuda-cold-pack-review.json"] = (REVIEW, REVIEW.read_bytes())
    entries = [{"path": name, "bytes": len(data), "sha256": digest(data)}
               for name, (_, data) in sorted(payloads.items())]
    inventory = {
        "output": str(OUTPUT), "payload_files": len(entries),
        "payload_bytes": sum(item["bytes"] for item in entries),
        "files": entries, "excluded": excluded,
        "validation": {"fresh_test_owner_tus": 8, "cuda_cases_passed": 8,
                       "failed": 0, "skipped": 0, "dependency_drift": 0,
                       "cpu_shared_fixture_branches_run": False},
        "cold_pack": "Source-confirmed synchronous-factory retirement contract gap; not reproduced UAF; not fixed.",
        "exclusions": "No object, executable, map, import/static library, SDK, model, old ZIP or Python bytecode payloads.",
    }
    manifest = encoded(inventory)
    (STAGE / "archive-inventory.json").write_bytes(manifest)
    if not args.write:
        print(json.dumps({"inventory": str(STAGE / "archive-inventory.json"),
                          "payload_files": len(entries), "payload_bytes": inventory["payload_bytes"]}))
        return
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (_, data) in sorted(payloads.items()):
            archive.writestr(name, data)
        archive.writestr("archive-manifest.json", manifest)
    verified = 0
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(entries) + 1
        assert archive.read("archive-manifest.json") == manifest
        for item in entries:
            data = archive.read(item["path"])
            assert len(data) == item["bytes"] and digest(data) == item["sha256"]
            verified += 1
    for _, (path, data) in payloads.items():
        assert digest(path.read_bytes()) == digest(data), str(path)
    packed = OUTPUT.read_bytes()
    receipt = {"archive": str(OUTPUT), "bytes": len(packed), "sha256": digest(packed),
               "entries": len(entries) + 1, "payload_files": len(entries),
               "payload_bytes": inventory["payload_bytes"], "crc_checked": True,
               "payload_sha256_verified": verified, "source_drift": 0,
               "validation_summary_sha256": digest(summary_bytes),
               "cleanup_plan": str(VALIDATION / "cleanup-windows.json"),
               "deleted": False, "objects_retained": True}
    (STAGE / "archive-receipt.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
