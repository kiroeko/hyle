"""Audit the single converted file's metadata/mapping and small F32 exceptions, without another conversion."""
from collections import Counter
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source/gguf-py'))
import gguf
import numpy as np
import torch
from safetensors import safe_open

def save(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

reader=gguf.GGUFReader(str(ROOT/'Qwen3.5-2B-text-BF16.gguf'))
by_name={t.name:t for t in reader.tensors}
header=json.loads((ROOT/'conversion-tensor-header.json').read_text())
mapper=gguf.get_tensor_name_map(gguf.MODEL_ARCH.QWEN35,24)
selected=[r for r in header if r['group']=='text']
mapping=[]
with safe_open('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors',framework='pt',device='cpu') as source:
    for row in selected:
        original=row['name']
        name=original.replace('language_model.','')
        if name.endswith('.dt_bias'):
            name=name.rpartition('.dt_bias')[0]+'.dt_proj.bias'
        target=mapper.get_name(name,try_suffixes=('.weight','.bias'))
        assert target in by_name,(original,name,target)
        tensor=by_name[target]
        expected_shape=[n for n in row['shape'] if n!=1] if '.conv1d.' in original else row['shape']
        assert list(tensor.shape)==list(reversed(expected_shape)),(original,tensor.shape,expected_shape)
        assert tensor.n_elements==np.prod(row['shape']),(original,tensor.n_elements,row['shape'])
        transforms=[]
        if name.endswith('.A_log'):
            transforms.append('F32 -exp(A_log)')
        if name.endswith('norm.weight') and not name.endswith('linear_attn.norm.weight'):
            transforms.append('F32 checkpoint delta + 1')
        if '.conv1d.' in original:
            transforms.append('squeeze singleton axis only')
        checked=None
        if tensor.tensor_type==gguf.GGMLQuantizationType.F32:
            expected=source.get_tensor(original).to(torch.float32)
            if name.endswith('.A_log'):
                expected=-torch.exp(expected)
            elif name.endswith('norm.weight') and not name.endswith('linear_attn.norm.weight'):
                expected=expected+1
            if '.conv1d.' in original:
                expected=expected.squeeze()
            actual=np.asarray(tensor.data).view(np.uint32).reshape(-1)
            exp=expected.contiguous().numpy().view(np.uint32).reshape(-1)
            mismatches=int(np.count_nonzero(actual!=exp))
            assert mismatches==0,(original,target,mismatches)
            checked=dict(points=int(exp.size),bit_mismatches=mismatches,
                         interpretation='BF16 to F32 promotion is exact; named architecture algebra applied in F32 before comparison')
        mapping.append(dict(source=original,gguf=target,source_dtype=row['dtype'],
            source_shape=row['shape'],gguf_ne=list(map(int,tensor.shape)),
            output_type=tensor.tensor_type.name,bytes=tensor.n_bytes,
            transforms=transforms,data_transpose=False,
            shape_note='GGUF ne[] reverses conventional shape; no physical matrix transpose for these checkpoint tensors.',
            f32_exception_check=checked))
assert len(mapping)==len(by_name)==320
assert len({r['gguf'] for r in mapping})==320
metadata={}
for name in ('general.architecture','general.file_type','general.name','qwen35.block_count',
             'qwen35.attention.head_count','qwen35.attention.head_count_kv',
             'qwen35.ssm.conv_kernel','qwen35.ssm.state_size','qwen35.ssm.group_count',
             'qwen35.ssm.time_step_rank','qwen35.ssm.inner_size',
             'tokenizer.ggml.add_bos_token','tokenizer.ggml.add_eos_token','qwen35.nextn_predict_layers'):
    field=reader.fields.get(name)
    metadata[name]=field.contents() if field else None
dtype_counts=dict(Counter(t.tensor_type.name for t in reader.tensors))
roles=Counter(re.sub(r'^blk\.\d+\.', 'blk.*.', t.name) for t in reader.tensors)
f32=[r for r in mapping if r['output_type']=='F32']
save('converted-tensor-mapping.json',mapping)
save('converted-model-audit.json',dict(tensors=len(reader.tensors),all_source_text_tensors_mapped=True,
    unmatched_gguf_tensors=sorted(set(by_name)-{r['gguf'] for r in mapping}),
    types=dtype_counts,role_counts=dict(roles),metadata=metadata,
    payload_bytes=sum(t.n_bytes for t in reader.tensors),
    f32_exception_tensors=len(f32),f32_exception_points=sum(r['f32_exception_check']['points'] for r in f32),
    f32_exception_bit_mismatches=0,bf16_source_promoted_to_f32=sum(r['source_dtype']=='BF16' for r in f32),
    text_vision_mtp='320 text tensors only; no multimodal/MTP tensor is present.',
    head_reorder='Checkpoint linear K-head and V-head counts are both 16, so the converter V-head permutation condition is false for this 2B model.',
    equality_boundary='Name/shape/dtype and all F32 exception values verified; no assertion of whole-file bytes or runtime intermediate equality with Hyle.'))
log=(ROOT/'011-model-n2-exact-prompt-bf16-cache.stderr.log').read_text(errors='replace')
ids=[int(n) for n in re.findall(r'^.*?\bI\s+(\d+) -> ',log,flags=re.MULTILINE)]
expected=json.loads((ROOT/'science-prompt-identity.json').read_text())['prompt_ids']
assert ids==expected,(ids,expected)
save('model-smoke-audit.json',dict(exit_code=0,actual_prompt_ids=ids,expected_prompt_ids=expected,
    exact_prompt_match=True,requested_context=64,actual_context=256,
    offload_line=next(s for s in log.splitlines() if 'offloaded 25/25 layers' in s),
    kv_line=next(s for s in log.splitlines() if 'K (bf16)' in s and 'V (bf16)' in s),
    recurrent_line=next(s for s in log.splitlines() if 'R (f32)' in s and 'S (f32)' in s),
    flash_attention_enabled='Flash Attention enabled' in log,
    native_graph_policy='peer default, compiled USE_GRAPHS=1; n2 is not evidence of steady-state reuse',
    generated_text=(ROOT/'011-model-n2-exact-prompt-bf16-cache.stdout.log').read_text(),
    n_predict=2,scope='Functional smoke only, not a timing comparison or numerical acceptance.'))
print(json.dumps(dict(tensors=len(mapping),types=dtype_counts,f32_checks=len(f32),prompt_ids_exact=True),indent=2))
