"""Build only official llama host targets against the retained, matched ABI2 math group."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/public/project-hyle/llama.cpp')
COMMIT = 'd9e03f1074dbd2979126d91dce1b5d304ec8394e'
WORKSPACE = ROOT.parents[2]
MATH = WORKSPACE / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
NATIVE = MATH / 'src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
CUDA = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
VC = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717')
CMAKE = 'C:/Program Files/CMake/bin/cmake.exe'
NINJA = 'C:/Program Files/Python312/Scripts/ninja.exe'

def save(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

def identity(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def msvc_environment():
    script = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Auxiliary/Build/vcvars64.bat')
    output = subprocess.check_output('cmd.exe /d /s /c "call "'+str(script)+'" >nul && set"', text=True)
    result = os.environ.copy()
    for line in output.splitlines():
        if '=' in line and not line.startswith('='):
            key, value = line.split('=', 1)
            result[key] = value
    result['PATH'] = str(CUDA/'bin')+';'+result['PATH']
    return result

def run(tag, command, env=None, cwd=None):
    records = json.loads((ROOT/'commands.json').read_text()) if (ROOT/'commands.json').exists() else []
    stem = f'{len(records)+1:03d}-{tag}'
    print('START', stem, flush=True)
    start = time.monotonic()
    with (ROOT/(stem+'.stdout.log')).open('wb') as out, (ROOT/(stem+'.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=cwd or ROOT, env=env, stdout=out, stderr=err)
        rc = process.wait()
    row = dict(tag=tag, command=command, cwd=str(cwd or ROOT), exit_code=rc,
               seconds=time.monotonic()-start, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    records.append(row)
    save('commands.json', records)
    print('END', stem, rc, round(row['seconds'], 2), flush=True)
    if rc:
        for suffix in ('.stdout.log', '.stderr.log'):
            print((ROOT/(stem+suffix)).read_text(errors='replace')[-9000:], flush=True)
    return rc

def prepare():
    assert NATIVE.is_dir(), NATIVE
    paths = ['CMakeLists.txt', 'LICENSE', 'cmake', 'include', 'src', 'common', 'tools', 'vendor',
             'conversion', 'gguf-py', 'convert_hf_to_gguf.py', 'requirements', 'requirements.txt', 'scripts']
    actual = subprocess.check_output(['git','-C',str(REPO),'ls-tree','--name-only',COMMIT], text=True).splitlines()
    paths = [p for p in paths if p in actual] + ['ggml/cmake']
    archive = subprocess.check_output(['git','-C',str(REPO),'archive',COMMIT,'--',*paths])
    destination = ROOT/'source'
    destination.mkdir(exist_ok=True)
    written = []
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar:
            target = (destination/member.name).resolve()
            assert target.is_relative_to(destination.resolve()), member.name
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif member.isfile():
                content = tar.extractfile(member).read()
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    assert target.read_bytes() == content, target
                else:
                    target.write_bytes(content)
                written.append(dict(path=member.name, bytes=len(content), sha256=hashlib.sha256(content).hexdigest()))
            else:
                raise RuntimeError('Unexpected archive member: '+member.name)
    save('host-snapshot.json', dict(repository=str(REPO), commit=COMMIT,
         ggml_pin='456172ec733a135778adcd32d00e576a58232e45', selected_paths=paths,
         archive_sha256=hashlib.sha256(archive).hexdigest(), files=written))
    package = ROOT/'ggml-package'
    package.mkdir(exist_ok=True)
    lines = ['# Scratch imported package; no native source targets are defined.', 'find_package(Threads REQUIRED)']
    for name in ('ggml-base','ggml-cpu','ggml-cuda','ggml'):
        lines.extend([f'add_library(ggml::{name} STATIC IMPORTED GLOBAL)',
            f'set_target_properties(ggml::{name} PROPERTIES IMPORTED_LOCATION "{(MATH/"bin"/(name+".lib")).as_posix()}"',
            f'  INTERFACE_INCLUDE_DIRECTORIES "{(NATIVE/"include").as_posix()};{(NATIVE/"src").as_posix()}")'])
    lines.extend([
        'set_property(TARGET ggml::ggml-cpu PROPERTY INTERFACE_LINK_LIBRARIES "ggml::ggml-base;Threads::Threads")',
        'set_property(TARGET ggml::ggml-cuda PROPERTY INTERFACE_LINK_LIBRARIES',
        f'  "ggml::ggml-base;{(CUDA/"lib/x64/cudart.lib").as_posix()};{(CUDA/"lib/x64/cublas.lib").as_posix()};{(CUDA/"lib/x64/cuda.lib").as_posix()}")',
        'set_property(TARGET ggml::ggml PROPERTY INTERFACE_LINK_LIBRARIES "ggml::ggml-cpu;ggml::ggml-cuda;ggml::ggml-base")',
        'set_property(TARGET ggml::ggml PROPERTY INTERFACE_COMPILE_DEFINITIONS "GGML_USE_CPU;GGML_USE_CUDA")',
        'set_property(TARGET ggml::ggml PROPERTY INTERFACE_LINK_OPTIONS "/NODEFAULTLIB:LIBCMT")',
        'foreach(name ggml-base ggml-cpu ggml-cuda)',
        '  add_library(${name} ALIAS ggml::${name})',
        'endforeach()',
        'set(ggml_FOUND TRUE)',
    ])
    (package/'ggml-config.cmake').write_text('\n'.join(lines)+'\n', encoding='utf-8', newline='\n')
    libraries = [identity(MATH/'bin'/(name+'.lib')) for name in ('ggml','ggml-base','ggml-cpu','ggml-cuda')]
    headers = []
    for name in ('include/ggml.h','include/ggml-backend.h','include/ggml-cpu.h','include/ggml-cuda.h',
                 'src/ggml-backend-impl.h','src/ggml-impl.h'):
        raw = subprocess.check_output(['git','-C',str(REPO),'show',f'{COMMIT}:ggml/{name}'])
        selected = identity(NATIVE/name)
        assert selected['sha256'] == hashlib.sha256(raw).hexdigest(), name
        headers.append(dict(relative_path=name, selected=selected, raw_llama_commit_sha256=hashlib.sha256(raw).hexdigest(), byte_equal=True))
    save('math-input-identities.json', dict(libraries=libraries, abi_headers=headers,
        compile_database=identity(MATH/'compile_commands.json'), cmake_cache=identity(MATH/'CMakeCache.txt'),
        toolchain=dict(cl=identity(VC/'bin/Hostx64/x64/cl.exe'),cmake=identity(CMAKE),ninja=identity(NINJA)),
        properties=dict(backend_api=2,ggml_type_count=43,cpu='baseline: original commands contain no AVX2 flags',
        cuda='13.3 sm89-real, original -use_fast_math, native CUDA graphs compiled in',
        patched_scope='Retained source4e1a resource/error handling in ggml.c, ggml-cpu.c, CUDA main/common; no per-kernel math replacement')))
    print('Prepared',len(written),'host/converter files;',sum(r['bytes'] for r in written),'bytes; 4 native libraries reused',flush=True)

def configure():
    command = [CMAKE,'-S',str(ROOT/'source'),'-B',str(ROOT/'build'),'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_MAKE_PROGRAM='+NINJA,
        '-DCMAKE_C_COMPILER='+str(VC/'bin/Hostx64/x64/cl.exe'),
        '-DCMAKE_CXX_COMPILER='+str(VC/'bin/Hostx64/x64/cl.exe'),
        '-DLLAMA_USE_SYSTEM_GGML=ON','-Dggml_DIR='+str(ROOT/'ggml-package'),
        '-DBUILD_SHARED_LIBS=OFF','-DLLAMA_BUILD_COMMON=ON','-DLLAMA_BUILD_TOOLS=ON',
        '-DLLAMA_BUILD_TESTS=OFF','-DLLAMA_BUILD_EXAMPLES=OFF','-DLLAMA_BUILD_SERVER=OFF',
        '-DLLAMA_BUILD_APP=OFF','-DLLAMA_BUILD_UI=OFF','-DLLAMA_OPENSSL=OFF','-DLLAMA_LLGUIDANCE=OFF',
        '-DLLAMA_TOOLS_INSTALL=OFF','-DLLAMA_BUILD_NUMBER=0','-DLLAMA_BUILD_COMMIT='+COMMIT,
        '-DGGML_CPU=ON','-DGGML_CUDA=ON','-DGGML_BACKEND_DL=OFF',
        '-DCMAKE_EXE_LINKER_FLAGS=/MAP']
    raise SystemExit(run('configure', command, msvc_environment()))

def build():
    commands = subprocess.check_output([NINJA,'-C',str(ROOT/'build'),'-t','commands','llama-completion','llama-bench'], text=True)
    assert not any('.cu ' in line or '.cu"' in line or 'nvcc.exe' in line for line in commands.splitlines())
    (ROOT/'selected-host-commands.txt').write_text(commands, encoding='utf-8', newline='\n')
    raise SystemExit(run('host-build',[CMAKE,'--build',str(ROOT/'build'),'--target','llama-completion','llama-bench','-j','4'],msvc_environment()))

def smoke():
    env = msvc_environment()
    exe = ROOT/'build/bin/llama-completion.exe'
    for tag,args in [('completion-version',['--version']),('completion-help',['--help']),('completion-devices',['--list-devices'])]:
        rc = run(tag,[str(exe),*args],env)
        if rc:
            raise SystemExit(rc)
    rc = run('bench-help',[str(ROOT/'build/bin/llama-bench.exe'),'--help'],env)
    raise SystemExit(rc)

def conversion_help():
    import sys
    env=os.environ.copy()
    env['HF_HUB_OFFLINE']='1'
    env['TRANSFORMERS_OFFLINE']='1'
    raise SystemExit(run('converter-help',[sys.executable,str(ROOT/'source/convert_hf_to_gguf.py'),'--help'],env))

def convert():
    plan=json.loads((ROOT/'conversion-plan.json').read_text())
    output=Path(plan['command'][-1])
    assert not output.exists(), 'Do not overwrite an existing model artifact'
    env=os.environ.copy()
    env['HF_HUB_OFFLINE']='1'
    env['TRANSFORMERS_OFFLINE']='1'
    rc=run('convert-bf16-text-no-mtp',plan['command'],env)
    if rc==0:
        save('converted-file-identity.json',identity(output))
    raise SystemExit(rc)

def model_smoke():
    from tokenizers import Tokenizer
    model=Path('C:/Users/kiro/Downloads/Qwen3.5-2B')
    fixed_path=ROOT.parent/'qwen-fixed-decode/fixed-inputs.json'
    fixed=json.loads(fixed_path.read_text())
    tokenizer=Tokenizer.from_file(str(model/'tokenizer.json'))
    prompt=tokenizer.decode(fixed['prompt_ids'],skip_special_tokens=False)
    recovered=tokenizer.encode(prompt,add_special_tokens=False).ids
    assert recovered==fixed['prompt_ids'], (recovered,fixed['prompt_ids'])
    prompt_path=ROOT/'science-prompt.txt'
    prompt_path.write_bytes(prompt.encode('utf-8'))
    save('science-prompt-identity.json',dict(source=identity(fixed_path),tokenizer=identity(model/'tokenizer.json'),
        prompt_file=identity(prompt_path),prompt=prompt,prompt_ids=recovered,
        note='Decoded the full fixed 21-token chat-formatted prompt, including special tokens; not the raw science sentence.'))
    command=[str(ROOT/'build/bin/llama-completion.exe'),'-m',str(ROOT/'Qwen3.5-2B-text-BF16.gguf'),
        '-bf',str(prompt_path),'--no-conversation','--override-kv',
        'tokenizer.ggml.add_bos_token=bool:false,tokenizer.ggml.add_eos_token=bool:false',
        '--verbose-prompt','--no-display-prompt','--ignore-eos','--temp','0','-s','0',
        '-n','2','-ngl','999','--device','CUDA0','-c','64','-b','64','-ub','64',
        '--cache-type-k','bf16','--cache-type-v','bf16','--flash-attn','auto','--log-verbosity','5']
    env=msvc_environment()
    env.pop('GGML_CUDA_DISABLE_GRAPHS',None)
    save('smoke-environment.json',dict(cuda_graphs='peer default; GGML_CUDA_DISABLE_GRAPHS absent',
        native_math='Original selected source4e1a 13.3/sm89/-use_fast_math cache',
        hardware=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],text=True).strip()))
    raise SystemExit(run('model-n2-exact-prompt-bf16-cache',command,env))

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','configure','build','smoke','conversion_help','convert','model_smoke'])
    args=parser.parse_args()
    globals()[args.action]()
