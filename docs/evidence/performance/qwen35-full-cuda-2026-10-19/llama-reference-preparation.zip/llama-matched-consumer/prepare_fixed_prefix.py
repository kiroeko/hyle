"""Emit the one-host-TU build recipe and exact public-API timing contract; do not compile/run."""
import json
from pathlib import Path
import build_host as b

root=b.ROOT
source=root/'fixed_prefix.cpp'
obj=root/'fixed-prefix.obj'
image=root/'fixed-prefix.exe'
compile_command=[str(b.VC/'bin/Hostx64/x64/cl.exe'),'/nologo','/c','/TP','/EHsc','/O2','/Ob2','/DNDEBUG',
    '/MD','/std:c++17','/utf-8','/bigobj','/DWIN32','/D_WINDOWS','/DGGML_USE_CPU','/DGGML_USE_CUDA',
    '/I'+str(root/'source/include'),'/I'+str(root/'source/vendor'),'/I'+str(b.NATIVE/'include'),
    str(source),'/Fo'+str(obj)]
libraries=[root/'build/src/llama.lib',*[b.MATH/'bin'/(name+'.lib') for name in ('ggml','ggml-cpu','ggml-cuda','ggml-base')],
    *[b.CUDA/'lib/x64'/(name+'.lib') for name in ('cudart','cublas','cuda')]]
link_command=[str(b.VC/'bin/Hostx64/x64/link.exe'),'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO',
    '/NODEFAULTLIB:LIBCMT','/OUT:'+str(image),'/MAP:'+str(root/'fixed-prefix.map'),str(obj),*map(str,libraries),
    'kernel32.lib','user32.lib','gdi32.lib','winspool.lib','shell32.lib','ole32.lib','oleaut32.lib','uuid.lib',
    'comdlg32.lib','advapi32.lib','ws2_32.lib']
inputs=root.parent/'qwen-fixed-decode/fixed-inputs.json'
run_command=[str(image),str(root/'Qwen3.5-2B-text-BF16.gguf'),str(inputs),str(root/'fixed-prefix-default.json')]
b.save('fixed-prefix-recipes.json',dict(status='Prepared only; not compiled or run',
    environment='Original build_host.msvc_environment() MSVC14.50 + CUDA13.3 bin; no SDK copies',
    compile=compile_command,link=link_command,run_default=run_command,
    run_disabled_graphs=dict(command=[*run_command[:-1],str(root/'fixed-prefix-no-graphs.json')],
        environment_add={'GGML_CUDA_DISABLE_GRAPHS':'1'}),
    source=b.identity(source),libraries=[b.identity(p) for p in libraries],fixed_inputs=b.identity(inputs)))
review=dict(status='Prepared only, pending parent review; zero new compilation or GPU run',
    consumer='fixed_prefix.cpp',api_sources=[
        dict(path='source/include/llama.h',purpose='Public model/context/batch/sync/last-logit/sampler lifetime contracts',identity=b.identity(root/'source/include/llama.h')),
        dict(path='source/src/llama-sampler.cpp',lines='895-978,1048-1118',purpose='Public sample uses chain reusable candidate buffer; original greedy selection; no custom sampler math',identity=b.identity(root/'source/src/llama-sampler.cpp')),
        dict(path='source/src/llama-context.cpp',lines='119,3618,3861',purpose='ordinary default nextn masked false; synchronize and result access',identity=b.identity(root/'source/src/llama-context.cpp')),
        dict(path='source/src/models/qwen35.cpp',lines='154-216',purpose='Default full prompt-row last FFN/final norm before final output row selection',identity=b.identity(root/'source/src/models/qwen35.cpp'))],
    actual_work=dict(prompt_tokens=21,fixed_decode_input_tokens=31,observations=32,visible_lengths='21..52',
        outputs='Only last input token requests logits. Predictions recorded but never fed back; same fixed prefix each run.',
        context=256,batch=64,ubatch=64,sequence=0,cache='BF16 K/V, original F32 recurrent state',
        model='all24 layers/offload999/CUDA0, original default model loading/runtime',
        flash_attention='ENABLED',threads=24,embeddings_nextn='Unchanged ordinary default false; no early row masking',
        greedy='Public llama_sampler_chain_init + init_greedy + sampler_sample. Backend sampling stays default off; full-logit D2H and original CPU greedy are included.',
        no_eos_filter='Fixed inputs run all32 observations even if a prediction is EOS. No logit bias/temperature/filter is inserted.'),
    timings=[
        ['input_prepare_seconds','start before batch writes -> batch ready'],
        ['decode_return_seconds','batch ready -> llama_decode returns; includes original scheduling, shape/graph maintenance, upload/enqueue and any internal waits'],
        ['synchronize_seconds','decode return -> llama_synchronize return; remaining actual work/readback wait'],
        ['logits_access_seconds','sync return -> public last-token logits obtained'],
        ['greedy_selection_seconds','logits obtained -> original public greedy sampled token selected on host, including candidate buffer preparation'],
        ['step_seconds','before all batch input preparation -> host-visible selected token']],
    excluded='Input JSON/file I/O, original backend/model/context/batch/sampler construction. Reports/JSON/file output are after all measured phases.',
    warmup='No synthetic warmup/reset. First graph/capture/chain capacity costs remain in measured phases. Future stable comparison may select phases7..31 (visibleL28..52), excluding prefill and decode1..6 on both sides.',
    ownership='Original model+context own all GDN/KV/logits. Batch allocated once by public API. Chain owns its original candidate scratch. Context destroyed before chain/model/backend; synchronize precedes token read. No shadow output/state, observer, executor, math/model wrapper.',
    limitation='decode/sync partition is API-observable wall time, not disjoint GPU kernel timing. Original decode may synchronize internally; only their summed endpoint-complete step is compared. Original CPU greedy is a peer-default policy difference from Hyle GPU argmax, reported separately.',
    gpu_sampler_future='Public experimental cparams.samplers can attach original greedy_argmax via backend sampler. Not enabled here; do not silently substitute it for default-policy evidence.')
b.save('fixed-prefix-timing-contract.json',review)
print(json.dumps(dict(source=b.identity(source),recipe=b.identity(root/'fixed-prefix-recipes.json'),review=b.identity(root/'fixed-prefix-timing-contract.json')),indent=2))
