"""Record actual reused native compile/source/link scope. No native source is built or changed."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
import build_host as b

ROOT=b.ROOT
db=json.loads((b.MATH/'compile_commands.json').read_text())
prefix='C:/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/'
native={r['file'][len(prefix):]:r for r in db if r['file'].startswith(prefix)}
archive=subprocess.check_output(['git','-C',str(b.REPO),'archive',b.COMMIT,'--','ggml'])
selected_names=set(native)|{'src/ggml-cuda/common.cuh'}
raw={}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for item in tar:
        name=item.name.removeprefix('ggml/')
        if name in selected_names and item.isfile():
            raw[name]=tar.extractfile(item).read()
changed=[]
diff=[]
for name in sorted(selected_names):
    old=raw[name]
    current=(b.NATIVE/name).read_bytes()
    if old!=current:
        changed.append(dict(path=name,raw_sha256=hashlib.sha256(old).hexdigest(),
            retained_sha256=hashlib.sha256(current).hexdigest(),compiled_tu=name in native))
        diff.extend(difflib.unified_diff(old.decode().splitlines(True),current.decode().splitlines(True),
            fromfile='d9e03:ggml/'+name,tofile='retained-source4e1a/'+name))
assert {r['path'] for r in changed}=={'src/ggml.c','src/ggml-cpu/ggml-cpu.c','src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/common.cuh'}
(ROOT/'retained-native-resource.patch').write_text(''.join(diff),encoding='utf-8',newline='\n')
picked={}
for name in ('src/ggml-cpu/ops.cpp','src/ggml-cpu/ggml-cpu.cpp','src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/norm.cu'):
    picked[name]=native[name]
b.save('native-reuse-audit.json',dict(compiled_native_unique_tus=len(native),
    compared_to=dict(llama_commit=b.COMMIT,raw_ggml_pin='456172ec733a135778adcd32d00e576a58232e45'),
    exact_raw_native_tus=len(native)-3,changed_sources=changed,original_selected_recipes=picked,
    original_paths_note='Original compile paths are historical metadata only; no C-root directory was created.',
    resources_only_scope=['ggml_init recoverable OOM and size-only integer address arithmetic',
        'CPU threadpool recoverable creation/cleanup; unchanged CPU operator math',
        'CUDA VMM OOM/cleanup, failure bridge and exception-safe graph/capture cleanup; unchanged individual math kernels'],
    native_graphs=dict(compiled=True,runtime_disable='Presence of GGML_CUDA_DISABLE_GRAPHS disables native graphs; even value 0 disables.',
        evidence='retained common.cuh:1300; this is a process-wide first-use environment snapshot'),
    important_limits=['CPU math is baseline without AVX2, while CUDA native is sm89 fast-math.',
        'No claim of bit equivalence to current Hyle CPU/CUDA mathematical patches or Torch eager intermediates.',
        'The retained resource-patched native group is not represented as an untouched upstream binary.']))
env=b.msvc_environment()
dumpbin=b.VC/'bin/Hostx64/x64/dumpbin.exe'
for target in ('llama-completion','llama-bench'):
    assert b.run(target+'-dependents',[str(dumpbin),'/DEPENDENTS',str(ROOT/'build/bin'/(target+'.exe'))],env)==0
    mapfile=ROOT/'build/bin'/(target+'.map')
    text=mapfile.read_text(errors='replace')
    # MSVC map module column is library:member. All actual math owners must be one of the four selected libraries.
    modules=sorted(set(re.findall(r'\s([^\s]+:[^\s]+\.obj)\s*$',text,re.MULTILINE)))
    math_modules=[m for m in modules if m.startswith(('ggml:','ggml-base:','ggml-cpu:','ggml-cuda:'))]
    assert math_modules,(target,'no native archive owners in map')
    assert not any('hyle_' in m for m in modules),(target,'unexpected Hyle host archive owner')
    b.save(target+'-link-owners.json',dict(image=b.identity(ROOT/'build/bin'/(target+'.exe')),
        map=b.identity(mapfile),actual_native_modules=math_modules,
        unexpected_hyle_modules=[],all_archive_modules=modules,
        actual_cuda_runtime='cudart_static archive modules are present in map; executable imports cublas64_13.dll but no cudart DLL',
        selected_math_libraries=json.loads((ROOT/'math-input-identities.json').read_text())['libraries'],
        host_target_command_locator='selected-host-commands.txt; official CMake/Ninja, imported native libraries only'))
print('Native comparison and both actual map owners recorded.')
