"""Read only the safetensors JSON header and local package metadata; do not convert."""
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import struct
import sys

ROOT=Path(__file__).resolve().parent
MODEL=Path('C:/Users/kiro/Downloads/Qwen3.5-2B')
weights=MODEL/'model.safetensors-00001-of-00001.safetensors'
with weights.open('rb') as stream:
    header_size=struct.unpack('<Q',stream.read(8))[0]
    raw=stream.read(header_size)
header=json.loads(raw)
groups={}
rows=[]
for name,item in header.items():
    if name=='__metadata__':
        continue
    kind='vision' if any(s in name for s in ('visual.','vision.','audio.')) else ('mtp' if 'mtp.' in name else 'text')
    shape=item['shape']
    count=math.prod(shape)
    # Converter's mostly-BF16 policy keeps scalar/vector norms, conv, and non-weight parameters F32.
    force_f32=len(shape)<=1 or name.endswith('norm.weight') or '.conv1d.' in name or not name.endswith('.weight')
    output_bytes=count*(4 if force_f32 else 2)
    row=dict(name=name,shape=shape,dtype=item['dtype'],original_bytes=item['data_offsets'][1]-item['data_offsets'][0],
             estimated_output_dtype='F32' if force_f32 else 'BF16',estimated_output_bytes=output_bytes)
    rows.append(dict(group=kind,**row))
    group=groups.setdefault(kind,dict(tensors=0,parameters=0,source_payload_bytes=0,estimated_output_payload_bytes=0))
    group['tensors']+=1;group['parameters']+=count
    group['source_payload_bytes']+=row['original_bytes'];group['estimated_output_payload_bytes']+=output_bytes
packages={}
for name in ('torch','numpy','transformers','tokenizers','sentencepiece','safetensors','protobuf','huggingface-hub','gguf'):
    try:
        packages[name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        packages[name]=None
command=[sys.executable,str(ROOT/'source/convert_hf_to_gguf.py'),str(MODEL),
         '--outtype','bf16','--no-mtp','--outfile',str(ROOT/'Qwen3.5-2B-text-BF16.gguf')]
report=dict(model=str(MODEL),source_weight_path=str(weights),source_file_bytes=weights.stat().st_size,
    source_weight_sha256_from_existing_inventory='aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1',
    safetensors_header_bytes=header_size,safetensors_header_sha256=hashlib.sha256(raw).hexdigest(),
    groups=groups,packages=packages,python=sys.executable,command=command,
    output_estimate_note='Text payload estimate from actual tensor shapes + converter F32 exceptions; GGUF tokenizer/metadata/alignment add several MB. No payload was read or copied.',
    conversion_semantics=['Default TEXT filters visual/vision/audio; --no-mtp filters MTP.',
        'Mostly BF16 is not all-BF16: scalar/vector norms, conv kernels, and non-weight parameters are F32.',
        'Converter performs native name mapping and V-head permutation; norm weights receive architecture-specific +1.',
        'No low-bit quantization. Runtime accumulation/intermediate dtypes follow peer implementation, not Hyle bit-equivalence.'],
    status='recipe prepared; conversion not executed')
(ROOT/'conversion-plan.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(ROOT/'conversion-tensor-header.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
