# Scratch imported package; no native source targets are defined.
find_package(Threads REQUIRED)
add_library(ggml::ggml-base STATIC IMPORTED GLOBAL)
set_target_properties(ggml::ggml-base PROPERTIES IMPORTED_LOCATION "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/bin/ggml-base.lib"
  INTERFACE_INCLUDE_DIRECTORIES "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/include;C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src")
add_library(ggml::ggml-cpu STATIC IMPORTED GLOBAL)
set_target_properties(ggml::ggml-cpu PROPERTIES IMPORTED_LOCATION "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/bin/ggml-cpu.lib"
  INTERFACE_INCLUDE_DIRECTORIES "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/include;C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src")
add_library(ggml::ggml-cuda STATIC IMPORTED GLOBAL)
set_target_properties(ggml::ggml-cuda PROPERTIES IMPORTED_LOCATION "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/bin/ggml-cuda.lib"
  INTERFACE_INCLUDE_DIRECTORIES "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/include;C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src")
add_library(ggml::ggml STATIC IMPORTED GLOBAL)
set_target_properties(ggml::ggml PROPERTIES IMPORTED_LOCATION "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/bin/ggml.lib"
  INTERFACE_INCLUDE_DIRECTORIES "C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/include;C:/public/project-hyle/hyle/.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/src")
set_property(TARGET ggml::ggml-cpu PROPERTY INTERFACE_LINK_LIBRARIES "ggml::ggml-base;Threads::Threads")
set_property(TARGET ggml::ggml-cuda PROPERTY INTERFACE_LINK_LIBRARIES
  "ggml::ggml-base;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/lib/x64/cudart.lib;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/lib/x64/cublas.lib;C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/lib/x64/cuda.lib")
set_property(TARGET ggml::ggml PROPERTY INTERFACE_LINK_LIBRARIES "ggml::ggml-cpu;ggml::ggml-cuda;ggml::ggml-base")
set_property(TARGET ggml::ggml PROPERTY INTERFACE_COMPILE_DEFINITIONS "GGML_USE_CPU;GGML_USE_CUDA")
set_property(TARGET ggml::ggml PROPERTY INTERFACE_LINK_OPTIONS "/NODEFAULTLIB:LIBCMT")
foreach(name ggml-base ggml-cpu ggml-cuda)
  add_library(${name} ALIAS ggml::${name})
endforeach()
set(ggml_FOUND TRUE)
