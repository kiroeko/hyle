"""Small local receipt only; retain all artifacts and never delete/move them."""
import json
from pathlib import Path
import build_host as b

ROOT=b.ROOT
commands=json.loads((ROOT/'commands.json').read_text())
converted=json.loads((ROOT/'converted-file-identity.json').read_text())
audit=json.loads((ROOT/'converted-model-audit.json').read_text())
smoke=json.loads((ROOT/'model-smoke-audit.json').read_text())
inputs=json.loads((ROOT/'math-input-identities.json').read_text())
native=json.loads((ROOT/'native-reuse-audit.json').read_text())
summary=dict(status='Official host + single BF16 text-only conversion + exact-prompt n2 CUDA functional smoke complete',
    upstream_llama_commit=b.COMMIT,ggml_pin='456172ec733a135778adcd32d00e576a58232e45',
    product_files_modified=[],source_snapshot=dict(file='host-snapshot.json',files=1579,bytes=25244936,
        note='Selected official host/converter source and GGML CMake modules only, not a copied native SDK'),
    host_build=dict(targets=['llama-completion','llama-bench'],observed_build_steps=108,exit_code=0,
        compiler='MSVC19.50.35728, /MD /O2 Release, official CMake host-only',
        no_native_build=True,commands='selected-host-commands.txt',
        warning='Official completion.cpp emitted existing C4804 bool comparison warning; no /WX claim.'),
    native_reuse=dict(libraries=inputs['libraries'],abi='All six complete public/core ABI headers byte-equal to d9e/raw456, API2, TYPE_COUNT43',
        compiled_native_tus_compared=native['compiled_native_unique_tus'],raw_native_tus=native['exact_raw_native_tus'],
        differences='retained-native-resource.patch: 3 source TUs + common.cuh resource/error/capture cleanup; no individual math kernel patched',
        original_math_flags='CUDA13.3, sm89-real, -use_fast_math, native graphs compiled. CPU original baseline, no AVX2.',
        actual_runtime='MSVC maps contain cudart_static modules; imports cublas64_13.dll. No Hyle host library is linked.'),
    converted_model=converted,model_audit='converted-model-audit.json',tensor_mapping='converted-tensor-mapping.json',
    conversion=dict(source_tensors=320,gguf_tensors=audit['tensors'],types=audit['types'],
        payload_bytes=audit['payload_bytes'],f32_exception_points=audit['f32_exception_points'],
        f32_exception_bit_mismatches=0,vision=False,mtp=False,quantized_to_low_bits=False,
        dependencies='Existing Python packages used; no install/download. Version differences from recommended requirements recorded in conversion-plan.json.',
        algebra='Official norm delta+1 and A_log -exp in F32, conv singleton squeeze; no V-head permutation for this model because 16 K heads = 16 V heads.'),
    smoke=smoke,
    retained_nonmatching_control=dict(command_tag='model-n2-smoke',exit_code=0,
        difference='Official -f pops one trailing LF: last prompt token198 instead of expected271. Not represented as a matched input run.'),
    precision_boundary='Identical source BF16 checkpoint is not a claim of identical runtime intermediates/accumulation, kernel policy, or numerical acceptance.',
    future_comparison=dict(prompt='science-prompt.txt + official -bf; --verbose-prompt must reproduce exact21 IDs',
        generation='Official completion supports greedy fixed n32/ignore-eos; no explicit token-ID input. n32 outputs correspond to prefill +31 decode forwards.',
        graph_groups=['Peer default environment (GGML_CUDA_DISABLE_GRAPHS absent)',
                      'Native graphs disabled with GGML_CUDA_DISABLE_GRAPHS=1 for cost attribution only'],
        timing='Use parent Hyle step_seconds; prior submit-only seconds is not comparable. No benchmark comparison has been executed in this stage.'),
    not_run=['n32 continuation or throughput comparison','llama-bench model execution','Any full numerical acceptance comparison'],
    commands='commands.json',native_source_review='native-reuse-audit.json',map_owners=['llama-completion-link-owners.json','llama-bench-link-owners.json'])
b.save('summary.json',summary)
images=[]
for target in ('llama-completion','llama-bench'):
    for suffix in ('.exe','.map'):
        images.append(b.identity(ROOT/'build/bin'/(target+suffix)))
b.save('cleanup-plan.json',dict(root=str(ROOT),status='Candidates only. Keep current CLI images for the upcoming parent-authorized comparison; no deletion performed.',
    files=images,retain=[converted,*inputs['libraries']],
    preserve='All source snapshots, host object/static library/build cache, commands/results, source differences, token/mapping metadata and the single GGUF remain. Native SDK was not copied.'))
metadata=['summary.json','math-input-identities.json','native-reuse-audit.json','retained-native-resource.patch',
    'host-snapshot.json','conversion-plan.json','converted-file-identity.json','converted-model-audit.json',
    'converted-tensor-mapping.json','science-prompt-identity.json','model-smoke-audit.json',
    'llama-completion-link-owners.json','llama-bench-link-owners.json','commands.json','cleanup-plan.json',
    'build_host.py','audit_reuse.py','audit_converted.py','conversion_review.py','freeze_metadata.py']
b.save('receipt.json',dict(metadata=[b.identity(ROOT/name) for name in metadata],
    current_host_objects=[b.identity(p) for p in sorted((ROOT/'build').rglob('*.obj'))],
    no_gpu_process_live=True,no_product_edits=True))
print(json.dumps(dict(summary=b.identity(ROOT/'summary.json'),receipt=b.identity(ROOT/'receipt.json'),images=len(images)),indent=2))
