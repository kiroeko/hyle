// Measurement consumer only: public llama/ggml APIs, original model/runtime/math.
// Teacher-forced input tokens keep all 32 observations on the same fixed prefix.
#include "llama.h"
#include "ggml-backend.h"
#include "nlohmann/json.hpp"

#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using json = nlohmann::ordered_json;
using Clock = std::chrono::steady_clock;
using Point = Clock::time_point;

struct Backend {
    Backend() { llama_backend_init(); }
    ~Backend() { llama_backend_free(); }
};
struct Batch {
    llama_batch value = llama_batch_init(64, 0, 1);
    ~Batch() { llama_batch_free(value); }
};
struct Step {
    int index = 0, input_count = 0, visible_tokens = 0;
    llama_token predicted = LLAMA_TOKEN_NULL;
    double input_prepare = 0, decode_return = 0, synchronize = 0;
    double logits_access = 0, greedy_select = 0, total = 0;
};
static double seconds(Point end, Point start) {
    return std::chrono::duration<double>(end - start).count();
}

static int run(const char * model_path, const char * fixed_path, const char * output_path) {
    std::ifstream input(fixed_path);
    if (!input) throw std::runtime_error("cannot open fixed inputs");
    const auto fixed = json::parse(input);
    const auto prompt = fixed.at("prompt_ids").get<std::vector<llama_token>>();
    const auto decode = fixed.at("decode_input_ids").get<std::vector<llama_token>>();
    const auto targets = fixed.at("target_ids").get<std::vector<llama_token>>();
    if (prompt.size() != 21 || decode.size() != 31 || targets.size() != 32)
        throw std::runtime_error("expected 21 prompt IDs, 31 fixed decode IDs, 32 target IDs");

    Backend backend;
    auto * device = ggml_backend_dev_by_name("CUDA0");
    if (!device || ggml_backend_dev_type(device) != GGML_BACKEND_DEVICE_TYPE_GPU)
        throw std::runtime_error("CUDA0 GPU is required");
    ggml_backend_dev_t devices[] = {device, nullptr};
    auto model_params = llama_model_default_params();
    model_params.devices = devices;
    model_params.n_gpu_layers = 999;
    using Model = std::unique_ptr<llama_model, decltype(&llama_model_free)>;
    Model model(llama_model_load_from_file(model_path, model_params), &llama_model_free);
    if (!model || llama_model_n_layer(model.get()) != 24)
        throw std::runtime_error("expected the full 24-layer Qwen3.5-2B model");

    // Original public chain reuses its candidate buffer after the first sample.
    // Backend sampling stays at its normal default (off); selection is original CPU greedy.
    using Sampler = std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)>;
    Sampler sampler(llama_sampler_chain_init(llama_sampler_chain_default_params()), &llama_sampler_free);
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());
    auto context_params = llama_context_default_params();
    context_params.n_ctx = 256;
    context_params.n_batch = 64;
    context_params.n_ubatch = 64;
    context_params.n_seq_max = 1;
    context_params.n_threads = 24;
    context_params.n_threads_batch = 24;
    context_params.type_k = GGML_TYPE_BF16;
    context_params.type_v = GGML_TYPE_BF16;
    context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    // Do not enable nextn/embedding taps or masked early row slicing.
    using Context = std::unique_ptr<llama_context, decltype(&llama_free)>;
    Context context(llama_init_from_model(model.get(), context_params), &llama_free);
    if (!context || llama_n_ctx(context.get()) != 256)
        throw std::runtime_error("context creation did not preserve capacity 256");
    const auto * vocab = llama_model_get_vocab(model.get());
    const int vocabulary = llama_vocab_n_tokens(vocab);
    for (const auto & ids : {prompt, decode})
        for (const auto token : ids)
            if (token < 0 || token >= vocabulary) throw std::runtime_error("input token out of vocabulary");

    Batch batch;
    std::array<Step, 32> steps{};
    int position = 0;
    for (int phase = 0; phase != 32; ++phase) {
        const int count = phase == 0 ? int(prompt.size()) : 1;
        const auto start = Clock::now(); // before any input batch preparation
        batch.value.n_tokens = count;
        for (int i = 0; i != count; ++i) {
            batch.value.token[i] = phase == 0 ? prompt[size_t(i)] : decode[size_t(phase - 1)];
            batch.value.pos[i] = position + i;
            batch.value.n_seq_id[i] = 1;
            batch.value.seq_id[i][0] = 0;
            batch.value.logits[i] = i == count - 1;
        }
        const auto prepared = Clock::now();
        const auto status = llama_decode(context.get(), batch.value);
        const auto decoded = Clock::now();
        if (status != 0) throw std::runtime_error("llama_decode failed: " + std::to_string(status));
        llama_synchronize(context.get());
        const auto synchronized = Clock::now();
        if (!llama_get_logits_ith(context.get(), -1)) throw std::runtime_error("no last-token logits");
        const auto logits = Clock::now();
        const auto predicted = llama_sampler_sample(sampler.get(), context.get(), -1);
        const auto selected = Clock::now(); // actual greedy token already selected on host
        position += count;
        steps[size_t(phase)] = Step{phase, count, position, predicted,
            seconds(prepared, start), seconds(decoded, prepared), seconds(synchronized, decoded),
            seconds(logits, synchronized), seconds(selected, logits), seconds(selected, start)};
    }

    // Reporting and all filesystem I/O occur outside the measured step windows.
    json result;
    result["llama_commit"] = "d9e03f1074dbd2979126d91dce1b5d304ec8394e";
    result["model"] = model_path;
    result["fixed_inputs"] = fixed_path;
    result["device"] = ggml_backend_dev_name(device);
    result["device_description"] = ggml_backend_dev_description(device);
    result["context_capacity"] = llama_n_ctx(context.get());
    result["kv_dtype"] = "BF16";
    result["flash_attention"] = "enabled";
    result["sampler"] = "original public CPU greedy chain; full logits readback and selection included";
    result["cuda_disable_graphs_env"] = std::getenv("GGML_CUDA_DISABLE_GRAPHS") ? std::getenv("GGML_CUDA_DISABLE_GRAPHS") : "<absent>";
    result["prefix_mode"] = "fixed teacher-forced inputs; predictions never feed the next input";
    result["step_boundary"] = "before batch preparation -> greedy token selected on host";
    result["cold_boundary"] = "input JSON parsing, backend/model/context/batch/sampler creation excluded; no synthetic warmup";
    result["prompt_ids"] = prompt;
    result["decode_input_ids"] = decode;
    result["target_ids"] = targets;
    result["predicted_ids"] = json::array();
    result["phases"] = json::array();
    for (const auto & step : steps) {
        result["predicted_ids"].push_back(step.predicted);
        result["phases"].push_back({{"phase", step.index}, {"input_tokens", step.input_count},
            {"visible_tokens", step.visible_tokens}, {"predicted_id", step.predicted},
            {"input_prepare_seconds", step.input_prepare}, {"decode_return_seconds", step.decode_return},
            {"synchronize_seconds", step.synchronize}, {"logits_access_seconds", step.logits_access},
            {"greedy_selection_seconds", step.greedy_select}, {"step_seconds", step.total},
            {"stable_window_candidate", step.index >= 7}});
    }
    llama_perf_context_print(context.get());
    std::ofstream output(output_path, std::ios::binary);
    if (!output) throw std::runtime_error("cannot open result output");
    output << result.dump(2) << '\n';
    if (!output) throw std::runtime_error("failed writing result output");
    return 0;
}

int main(int argc, char ** argv) {
    if (argc != 4) {
        std::cerr << "usage: fixed-prefix model.gguf fixed-inputs.json result.json\n";
        return 2;
    }
    try { return run(argv[1], argv[2], argv[3]); }
    catch (const std::exception & error) { std::cerr << error.what() << '\n'; return 1; }
}
