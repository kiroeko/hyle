"""Archive only the bounded peer-preparation text evidence. Never collect binary/model payloads."""
import hashlib
import json
from pathlib import Path
import zipfile
import zlib

HERE=Path(__file__).resolve().parent
ARCH=HERE.parent
WORKSPACE=ARCH.parents[1]
HOST=ARCH/'llama-matched-consumer'
DEST=WORKSPACE/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/llama-reference-preparation.zip'

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
def identity(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=digest(data))

assert not DEST.exists(),'Do not replace an existing evidence archive'
entries={}
def add(path,name=None):
    path=Path(path)
    assert path.is_file(),path
    assert path.suffix.lower() not in ('.exe','.dll','.lib','.a','.obj','.o','.pdb','.map','.exp','.gguf','.safetensors','.zip')
    name=name or path.relative_to(ARCH).as_posix()
    assert name not in entries and not name.startswith(('/', '\\')) and '..' not in Path(name).parts,name
    entries[name]=path.read_bytes()

# Bounded top-level text only. Do not recurse into the source snapshot, build cache, or SDK.
for root in (HOST,HERE):
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix.lower() in ('.json','.log','.py','.cpp','.txt','.patch','.diff'):
            if path.name in ('live.json','analyze_pair.py','archive-preparation-receipt.json'):
                continue
            add(path)
add(HERE/'before/fixed_prefix.cpp')
add(HOST/'ggml-package/ggml-config.cmake')

# Selected upstream source facts only; the full1579-file tree is deliberately excluded.
for relative in ('CMakeLists.txt','LICENSE','src/CMakeLists.txt','common/CMakeLists.txt',
        'tools/completion/CMakeLists.txt','tools/llama-bench/CMakeLists.txt',
        'include/llama.h','src/models/qwen35.cpp','src/llama-sampler.cpp','src/llama-context.cpp',
        'src/llama-model-loader.cpp','convert_hf_to_gguf.py','conversion/base.py','conversion/qwen.py'):
    add(HOST/'source'/relative)

# Independent actual evidence for full-CUDA embedding/sampling and the corrected30/32 result.
comparison=ARCH/'qwen-gpu-comparison'
add(comparison/'peer-actual-review.json','actual-review/peer-actual-review.json')
for relative in ('command.json','result.json','peer-result.json','stderr.log'):
    add(comparison/'02-llama'/relative,'actual-review/02-llama/'+relative)

model=read(HOST/'converted-file-identity.json')
native=read(HOST/'math-input-identities.json')
retention=dict(
    single_converted_gguf=model,
    original_checkpoint='C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors (referenced by original identity; not copied)',
    retained_native_libraries=native['libraries'],
    official_host_cache=str(HOST/'build'),
    official_source_snapshot=str(HOST/'source'),
    local_git_repository='C:/public/project-hyle/llama.cpp; existing commit d9e03f1074dbd2979126d91dce1b5d304ec8394e',
    measurement_objects=[str(p.resolve()) for p in sorted(HERE.glob('*.obj'))],
    flexible128_object=str(comparison/'128-prefill/peer-benchmark.obj'),
    performance_evidence='qwen-gpu-comparison is archived separately by root, including the128-token harness/input/14 actual runs. No performance payload is copied by reference.',
    rebuildable_images='CLI/measurement exe+map cleanup candidates remain on disk until root exact test.ps1 cleanup. No deletion or move by this script.')
entries['RETAINED-EXTERNAL-INPUTS.json']=(json.dumps(retention,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
entries['ARCHIVE_README.txt']=(
    'Peer preparation and actual full-CUDA evidence only.\n'
    'Official llama commit d9e03f1074dbd2979126d91dce1b5d304ec8394e; GGML456172ec733a135778adcd32d00e576a58232e45.\n'
    'The retained native group has resource/error/capture patches, not an untouched upstream-binary claim.\n'
    'Selected source/ABI identities, conversion recipe/audit, exact prompt controls, public-API measurement variants and build logs are included.\n'
    'Actual peer backend greedy and CUDA embedding are verified. Four short peer runs are identical and equal Hyle/reference30/32, not32/32.\n'
    'The original peer still reads back sampled logits; no4B-only total transfer or mathematical bit-equivalence claim.\n'
    'Historical first -f prompt control lost one LF and is retained as nonmatching; the corrected official -bf control exactly matched21 IDs.\n'
    'Full source tree, SDK, host cache, binaries, maps, objects and the single3.77GB GGUF are excluded.\n'
    'Referenced files are never recursively copied. Keep the external inputs listed in RETAINED-EXTERNAL-INPUTS.json.\n'
    'ZIP timestamps are normalized; content SHA256 and CRC32 in MANIFEST.json are authoritative.\n').encode('utf-8')
manifest=dict(schema='hyle.text-evidence-archive.v1',
    archive='llama-reference-preparation.zip',
    scope='Two peer-preparation stages, selected upstream facts and bounded actual review; no binary/SDK/model payload',
    excluded=['Complete1579-file source tree','Host build cache and all native SDK files','Images/maps/importlibs/objects','3.77GB GGUF and original safetensors'],
    entries=[dict(path=name,bytes=len(data),sha256=digest(data),crc32=f'{zlib.crc32(data)&0xffffffff:08x}') for name,data in sorted(entries.items())])
manifest_bytes=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted({**entries,'MANIFEST.json':manifest_bytes}.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,19,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None,'ZIP CRC failure'
    assert len(archive.infolist())==len(entries)+1
    for row in manifest['entries']:
        data=archive.read(row['path'])
        assert len(data)==row['bytes'] and digest(data)==row['sha256']
        assert f'{archive.getinfo(row["path"]).CRC:08x}'==row['crc32']
    assert archive.read('MANIFEST.json')==manifest_bytes
raw=DEST.read_bytes()
receipt=dict(archive=identity(DEST),archive_crc32=f'{zlib.crc32(raw)&0xffffffff:08x}',
    entries=len(entries)+1,manifest_entries=len(entries),uncompressed_bytes=sum(len(v) for v in entries.values())+len(manifest_bytes),
    manifest_sha256=digest(manifest_bytes),crc_and_every_entry_sha256_verified=True,
    excluded_binary_and_model_payload=True,no_deletion_or_move=True,retained_external_inputs=retention)
(HERE/'archive-preparation-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='retained_external_inputs'},indent=2))
