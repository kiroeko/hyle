"""Derive an explicit original-public-backend-sampling variant, retaining CPU-greedy source/image."""
import difflib
from pathlib import Path
import run_pair as r

OUT=r.OUT
HOST=r.HOST
cpu=HOST/'fixed_prefix.cpp'
assert r.identity(cpu)['sha256']=='13da7cc3a1f2ff2231e2024014a069a45b189cbdf612115750cf5e03b1669211'
text=cpu.read_text()
original=text
def replace(before,after):
    global text
    assert text.count(before)==1,(before,text.count(before))
    text=text.replace(before,after)
replace('// Backend sampling stays at its normal default (off); selection is original CPU greedy.',
    '// Original public backend sampling attaches this chain before native context reserve.')
replace('double logits_access = 0, greedy_select = 0, total = 0;',
    'double logits_access = 0, greedy_select = 0, total = 0;\n    std::uint32_t sampled_logits_count = 0;')
replace('context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;',
    'context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;\n'
    '    llama_sampler_seq_config sampler_config{0, sampler.get()};\n'
    '    context_params.samplers = &sampler_config;\n'
    '    context_params.n_samplers = 1;')
replace('if (!llama_get_logits_ith(context.get(), -1)) throw std::runtime_error("no last-token logits");\n        const auto logits = Clock::now();',
    'const auto backend_token = llama_get_sampled_token_ith(context.get(), -1);\n'
    '        if (backend_token == LLAMA_TOKEN_NULL) throw std::runtime_error("backend greedy did not produce a token; CPU fallback rejected");\n'
    '        const auto token_access = Clock::now();')
replace('const auto predicted = llama_sampler_sample(sampler.get(), context.get(), -1);',
    'const auto predicted = llama_sampler_sample(sampler.get(), context.get(), -1);\n'
    '        if (predicted != backend_token) throw std::runtime_error("public sample differs from backend token");')
replace('seconds(logits, synchronized), seconds(selected, logits), seconds(selected, start)};',
    'seconds(token_access, synchronized), seconds(selected, token_access), seconds(selected, start)};\n'
    '        // Metadata query after the endpoint-complete timer; decode already synchronized all readbacks.\n'
    '        steps[size_t(phase)].sampled_logits_count = llama_get_sampled_logits_count_ith(context.get(), -1);')
replace('result["sampler"] = "original public CPU greedy chain; full logits readback and selection included";',
    'result["sampler"] = "original public backend greedy chain; native ggml_argmax and public sampled_token fast path";\n'
    '    result["sampling_transfer_scope"] = "Original d9e backend greedy leaves data.logits active; engine also copies sampled_logits. Observed element counts reported per phase. Consumer never requests raw logits or does CPU argmax.";')
replace('{"logits_access_seconds", step.logits_access}',
    '{"token_access_seconds", step.logits_access}')
replace('{"greedy_selection_seconds", step.greedy_select}',
    '{"sample_fastpath_seconds", step.greedy_select}, {"sampled_logits_elements", step.sampled_logits_count}')
source=OUT/'fixed_prefix_gpu_greedy.cpp'
source.write_text(text,encoding='utf-8',newline='\n')
(OUT/'peer-gpu-greedy.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),
    fromfile='peer-full-cuda-cpu-greedy/fixed_prefix.cpp',tofile='peer-full-cuda-greedy/fixed_prefix_gpu_greedy.cpp')),
    encoding='utf-8',newline='\n')
assert 'llama_get_logits_ith' not in text
base=r.read(OUT/'peer-full-cuda-plan.json')
obj=OUT/'peer-full-cuda-greedy.obj'
image=OUT/'peer-full-cuda-greedy.exe'
compile_command=[]
for arg in base['compile']:
    if arg==str(cpu):arg=str(source)
    elif arg.startswith('/Fo'):arg='/Fo'+str(obj)
    compile_command.append(arg)
link_command=[]
for arg in base['link']:
    if arg.startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.startswith('/MAP:'):arg='/MAP:'+str(OUT/'peer-full-cuda-greedy.map')
    elif arg==str(OUT/'peer-full-cuda.obj'):arg=str(obj)
    link_command.append(arg)
plan=dict(status='Explicit GPU-greedy variant prepared; not run',source=r.identity(source),
    retained_cpu_greedy_source=r.identity(cpu),retained_cpu_greedy_image=r.read(OUT/'peer-full-cuda-image.json'),
    compile=compile_command,link=link_command,
    example_run=[str(image),str(HOST/'Qwen3.5-2B-text-BF16.gguf'),str(r.ARCH/'qwen-fixed-decode/fixed-inputs.json'),
        str(OUT/'peer-full-cuda-greedy-result.json')],
    model_identity_reference=base['model_identity_reference'],native_libraries=base['native_libraries'],
    source_qualification=dict(
        public_api='include/llama.h:411 context.samplers/n_samplers, seq0 public greedy chain; same setup as common/common.cpp:1384 --backend-sampling.',
        native_math='llama-sampler.cpp:1077 backend greedy uses original ggml_argmax. Retained native CUDA supports ARGMAX and includes original argmax.cu.',
        fast_path='llama-sampler.cpp:895 reads original sampled_token first and returns it without CPU candidate scanning. Harness asserts non-NULL backend token and equality to public sampler_sample.',
        lifetime='Original sampler+seq config remain alive throughout context; context explicitly destroyed first. No new sampling math/owner/executor.',
        transfer_limit='Greedy backend_apply leaves data.logits non-null; graph.cpp:3841 exposes sampled_logits and context.cpp:1976 copies it. Original full sampled-logit transfer remains, distinct from consumer requested raw logits. No claim of 4B-only total D2H.',
        observation='Each phase reports original public sampled_logits_count after its completed timer; no extra data copy or model evaluation.',
        dtype='F32 logits -> original GPU ARGMAX -> I32 selected token. Ties/NaNs follow unchanged native kernel policy, not a new sampler implementation.'),
    unchanged='All loading/memory/first-token/step endpoints, BF16 KV, FA enabled, capacity256, fullCUDA embedding override and fixed prefixes remain identical to CPU-greedy variant.',
    no_upstream_modifications=True,no_sdk_rebuild=True,no_gpu_run=True)
r.save('peer-full-cuda-greedy-plan.json',plan)
print('Prepared',source.name,plan['source']['sha256'])
