"""Prepare the full-CUDA measurement variant. No compile/run, no large model rehash."""
import difflib
import json
from pathlib import Path
import run_pair as r

OUT=r.OUT
HOST=r.HOST
original=r.read(HOST/'fixed-prefix-recipes.json')
obj=OUT/'peer-full-cuda.obj'
image=OUT/'peer-full-cuda.exe'
compile_command=[('/Fo'+str(obj)) if a.startswith('/Fo') else a for a in original['compile']]
link_command=[]
for arg in original['link']:
    if arg.startswith('/OUT:'):arg='/OUT:'+str(image)
    elif arg.startswith('/MAP:'):arg='/MAP:'+str(OUT/'peer-full-cuda.map')
    elif arg==str(HOST/'fixed-prefix.obj'):arg=str(obj)
    link_command.append(arg)
source=HOST/'fixed_prefix.cpp'
before=OUT/'before/fixed_prefix.cpp'
(OUT/'peer-loading-memory.diff').write_text(''.join(difflib.unified_diff(
    before.read_text().splitlines(True),source.read_text().splitlines(True),
    fromfile='before/fixed_prefix.cpp',tofile='full-cuda/fixed_prefix.cpp')),encoding='utf-8',newline='\n')
sources={name:r.identity(HOST/'source'/name) for name in (
    'include/llama.h','src/models/qwen35.cpp','src/llama-model-loader.cpp','src/llama-model.cpp')}
plan=dict(status='Prepared source/recipe only; full-CUDA version not compiled or run',
    source=r.identity(source),before=r.identity(before),compile=compile_command,link=link_command,
    example_run=[str(image),str(HOST/'Qwen3.5-2B-text-BF16.gguf'),
        str(r.ARCH/'qwen-fixed-decode/fixed-inputs.json'),str(OUT/'peer-full-cuda-result.json')],
    model_identity_reference=r.read(HOST/'converted-file-identity.json'),
    native_libraries=r.read(HOST/'math-input-identities.json')['libraries'],
    source_qualification=dict(
        default_input_cpu='llama-model.cpp:1510 always assigns input-layer CPU; original n2 default run retained its CPU_Mapped970MiB embedding.',
        override='Public llama_model_tensor_buft_override pattern ^token_embd\\.weight$ uses ggml_backend_dev_buffer_type(CUDA0); terminator is null.',
        decoder='Actual retained native CUDA supports GGML_OP_GET_ROWS with GGML_TYPE_BF16 (ggml-cuda.cu:5220). No new kernel/route/math.',
        tied='qwen35.cpp:40/48 creates original token embedding then TENSOR_DUPLICATED for missing output. Both names match override; loader:1364 gets same buffer-type context and returns existing ggml_get_tensor pointer, so input/output share original tensor/backing by construction.',
        qualification_scope='Source-level qualification complete. Actual all-CUDA allocation/offload and sharing-size logs require the upcoming parent-controlled run; not yet claimed as observed.',
        sources=sources),
    loading=dict(
        model_load_seconds='Around original llama_model_load_from_file. Loader:1747 synchronizes actual async upload events before returning. Normal mmap/lazy behavior preserved; not all CPU mmap pages promised resident.',
        context_prepare_seconds='Around original llama_init_from_model, includes its native graph/memory reserve behavior.',
        startup_to_ready_seconds='run entry before JSON read -> backend/model/context/sampler/batch/override ready; includes preceding snapshot cost, no synthetic math warmup.',
        first_token_elapsed_seconds='run entry -> phase0 original greedy token selected; includes model/context cold preparation and first real math.',
        step_seconds='Unchanged endpoint-complete per-phase batch-preparation -> original host-visible selected token.'),
    memory=dict(
        process='Windows GetProcessMemoryInfo. WorkingSet/PeakWorkingSet=resident process RAM; PrivateUsage/PeakPagefileUsage=commit charge.',
        device_crosscheck='Original public ggml_backend_dev_memory(CUDA0), device-global total/free/used only. Not private process VRAM.',
        external='Parent uses one shared PDH process dedicated/shared GPU + RAM sampler; no new NVML worker/framework.',
        snapshots=['run_entry (RAM only)','backend_ready_before_model','model_loaded','ready_before_prefill','prefill_complete','inference_complete','model_context_released_backend_alive'],
        overhead='Each snapshot including its marker reports snapshot_seconds and Unix-ms correlation. All snapshots outside step windows.',
        baseline='The first device query can initialize CUDA context; its cost is visible in startup-to-ready/snapshot cost. Root external PDH includes process startup. No cold-disk/cache-eviction claim.'),
    no_upstream_modifications=True,no_sdk_rebuild=True,no_gpu_run=True)
r.save('peer-full-cuda-plan.json',plan)
print(json.dumps(dict(source=plan['source'],plan=r.identity(OUT/'peer-full-cuda-plan.json')),indent=2))
