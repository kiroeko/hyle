"""One host TU and link only, preserving both previous variants. Never launch the GPU here."""
import run_pair as r

plan=r.read(r.OUT/'peer-full-cuda-greedy-plan.json')
assert r.identity(plan['source']['path'])==plan['source']
env=r.b.msvc_environment()
status=r.call('007-peer-gpu-greedy-compile',plan['compile'],env)
if status:raise SystemExit(status)
status=r.call('008-peer-gpu-greedy-link',plan['link'],env)
if status:raise SystemExit(status)
r.save('peer-full-cuda-greedy-image.json',dict(source=plan['source'],
    object=r.identity(r.OUT/'peer-full-cuda-greedy.obj'),image=r.identity(r.OUT/'peer-full-cuda-greedy.exe'),
    map=r.identity(r.OUT/'peer-full-cuda-greedy.map'),model_identity_reference=plan['model_identity_reference'],
    native_libraries=plan['native_libraries'],gpu_run=False))
