"""Compile/link only the one approved public-API measurement TU; no GPU execution."""
import run_pair as r

plan=r.read(r.OUT/'peer-full-cuda-plan.json')
assert r.identity(plan['source']['path'])==plan['source'],'Source changed after recipe freeze'
environment=r.b.msvc_environment()
status=r.call('005-peer-full-cuda-compile',plan['compile'],environment)
if status:raise SystemExit(status)
status=r.call('006-peer-full-cuda-link',plan['link'],environment)
if status:raise SystemExit(status)
r.save('peer-full-cuda-image.json',dict(source=plan['source'],
    object=r.identity(r.OUT/'peer-full-cuda.obj'),image=r.identity(r.OUT/'peer-full-cuda.exe'),
    map=r.identity(r.OUT/'peer-full-cuda.map'),model_identity_reference=plan['model_identity_reference'],
    native_libraries=plan['native_libraries'],gpu_run=False))
