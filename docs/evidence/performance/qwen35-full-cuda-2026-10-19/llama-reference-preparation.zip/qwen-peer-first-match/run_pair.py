"""One sequential, fixed-prefix pair. Host build only until the parent releases the GPU window."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ARCH=OUT.parent
HOST=ARCH/'llama-matched-consumer'
sys.path.insert(0,str(HOST))
import build_host as b

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

def identity(path):
    path=Path(path).resolve()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def call(tag,command,environment):
    assert not (OUT/(tag+'.result.json')).exists(),'No implicit repeated run: '+tag
    row=dict(argv=list(map(str,command)),started=time.time(),cwd=str(b.WORKSPACE))
    save(tag+'.command.json',row)
    print('START',tag,flush=True)
    with (OUT/(tag+'.stdout.log')).open('wb') as stdout,(OUT/(tag+'.stderr.log')).open('wb') as stderr:
        process=subprocess.Popen(row['argv'],cwd=b.WORKSPACE,env=environment,stdout=stdout,stderr=stderr)
        row['pid']=process.pid;save('live.json',row)
        row['exit_code']=process.wait()
    row.update(finished=time.time(),seconds=time.time()-row['started'],terminal=True)
    save(tag+'.result.json',row);save('live.json',row)
    print('END',tag,row['exit_code'],round(row['seconds'],3),flush=True)
    if row['exit_code']:
        print((OUT/(tag+'.stdout.log')).read_text(errors='replace')[-8000:])
        print((OUT/(tag+'.stderr.log')).read_text(errors='replace')[-8000:])
    return row['exit_code']

def build():
    original=read(HOST/'fixed-prefix-recipes.json')
    obj=OUT/'fixed-prefix.obj'
    compile_command=[('/Fo'+str(obj)) if arg.startswith('/Fo') else arg for arg in original['compile']]
    link_command=[]
    for arg in original['link']:
        if arg.startswith('/OUT:'):arg='/OUT:'+str(OUT/'fixed-prefix.exe')
        elif arg.startswith('/MAP:'):arg='/MAP:'+str(OUT/'fixed-prefix.map')
        elif arg==str(HOST/'fixed-prefix.obj'):arg=str(obj)
        link_command.append(arg)
    save('matched-host-build-plan.json',dict(compile=compile_command,link=link_command,
        original_recipe=identity(HOST/'fixed-prefix-recipes.json'),source=identity(HOST/'fixed_prefix.cpp'),
        public_abi=identity(HOST/'source/include/llama.h'),native_inputs=read(HOST/'math-input-identities.json'),
        model_identity_reference=read(HOST/'converted-file-identity.json'),
        model_note='The already audited 3.77GB GGUF is referenced, not rehashed or copied.',
        current_llama=identity(HOST/'build/src/llama.lib')))
    env=b.msvc_environment()
    rc=call('001-peer-host-compile',compile_command,env)
    if rc:return rc
    rc=call('002-peer-host-link',link_command,env)
    if rc:return rc
    save('peer-image-identities.json',dict(object=identity(obj),image=identity(OUT/'fixed-prefix.exe'),map=identity(OUT/'fixed-prefix.map')))
    return 0

def hyle():
    env=b.msvc_environment()
    original=read(ARCH/'qwen-native-graph-observation/matched-link-plan.json')
    directories=[str(Path(x).parent) for x in original['command'] if x.lower().endswith('.lib')]
    env['PATH']=os.pathsep.join(dict.fromkeys(directories))+os.pathsep+env['PATH']
    env.pop('GGML_CUDA_DISABLE_GRAPHS',None)
    image=ARCH/'qwen-native-graph-observation/qwen-observe.exe'
    command=[str(image),'--inputs',str(ARCH/'qwen-fixed-decode/science-inputs'),
        '--decode-ids',str(ARCH/'qwen-fixed-decode/science-decode.ids'),'--capacity','256','--progress','direct']
    save('hyle-input-identities.json',dict(image=identity(image),image_link_source=identity(ARCH/'qwen-native-graph-observation/matched-link-plan.json'),
        input=identity(ARCH/'qwen-fixed-decode/fixed-inputs.json'),decode_tape=identity(ARCH/'qwen-fixed-decode/science-decode.ids'),
        manifest=identity(ARCH/'qwen-fixed-decode/science-inputs/weights.tsv'),capacity=256,trace=False,
        gpu_environment=dict(GGML_CUDA_DISABLE_GRAPHS='<absent>'),selected_library_path_directories=directories))
    return call('003-hyle-direct32',command,env)

def peer():
    assert read(OUT/'003-hyle-direct32.result.json')['exit_code']==0,'Run Hyle first; do not overlap'
    env=b.msvc_environment()
    env.pop('GGML_CUDA_DISABLE_GRAPHS',None)
    command=[str(OUT/'fixed-prefix.exe'),str(HOST/'Qwen3.5-2B-text-BF16.gguf'),
        str(ARCH/'qwen-fixed-decode/fixed-inputs.json'),str(OUT/'peer-result.json')]
    save('peer-run-policy.json',dict(capacity=256,cache='BF16 K/V',flash_attention='enabled',
        graph_policy='Native default, GGML_CUDA_DISABLE_GRAPHS absent',
        sampler='Original public CPU greedy chain; token readback included in complete step',
        activation_precision='Original peer F32/BF16 intermediates, not asserted equal to Hyle',
        teacher_forced=True,phases=32,trace=False))
    return call('004-peer-fixed32',command,env)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['build','hyle','peer'])
    raise SystemExit(globals()[parser.parse_args().action]())
