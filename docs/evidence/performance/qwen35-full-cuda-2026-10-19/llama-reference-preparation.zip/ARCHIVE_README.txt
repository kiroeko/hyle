Peer preparation and actual full-CUDA evidence only.
Official llama commit d9e03f1074dbd2979126d91dce1b5d304ec8394e; GGML456172ec733a135778adcd32d00e576a58232e45.
The retained native group has resource/error/capture patches, not an untouched upstream-binary claim.
Selected source/ABI identities, conversion recipe/audit, exact prompt controls, public-API measurement variants and build logs are included.
Actual peer backend greedy and CUDA embedding are verified. Four short peer runs are identical and equal Hyle/reference30/32, not32/32.
The original peer still reads back sampled logits; no4B-only total transfer or mathematical bit-equivalence claim.
Historical first -f prompt control lost one LF and is retained as nonmatching; the corrected official -bf control exactly matched21 IDs.
Full source tree, SDK, host cache, binaries, maps, objects and the single3.77GB GGUF are excluded.
Referenced files are never recursively copied. Keep the external inputs listed in RETAINED-EXTERNAL-INPUTS.json.
ZIP timestamps are normalized; content SHA256 and CRC32 in MANIFEST.json are authoritative.
