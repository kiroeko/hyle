"""Three paired real-model runs, or one official Nsight trace. No downloads."""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import statistics as stat
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
def metrics(path):
 text=path.read_text()
 step=re.findall(r'^(prefill|decode\d+) tokens=(\d+).*?step_seconds=([0-9.e+-]+)',text,re.M)
 if len(step)!=32:raise ValueError('Expected full128 prompt and31 decode phases')
 decode=[float(v) for name,_,v in step if name.startswith('decode')]
 result={'prefill_tokens_per_second':128/float(step[0][2]),
         'full31_tokens_per_second':31/sum(decode),
         'warm7_31_tokens_per_second':25/sum(decode[6:])}
 for key in ('weights_load_seconds','shape_prepare_seconds','startup_to_ready_seconds','first_token_elapsed_seconds'):
  found=re.findall(r'\b'+key+r'=([0-9.e+-]+)',text)
  result[key]=float(found[0]) if found else None
 for tokens,bytes in re.findall(r'compiled T=(\d+) steps=\d+ workspace/slot=(\d+)',text):
  result['workspace_T'+tokens+'_bytes']=int(bytes)
 return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan',type=Path)
 p.add_argument('mode',choices=['performance','profile']);args=p.parse_args()
 plan=c.read(args.plan);candidate=Path(plan['links']['qwen']['image'])
 if c.read(args.plan.parent/'run-qwen/summary.json')['equal_vectors']!=64:raise ValueError('Numerical proof missing')
 out=STAGE/args.mode;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
 env,_=b.b.environment(plan['links']['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
 original=c.read(b.ARCH/'cuda-reshape-reuse/profile-qwen.command.json')['command']
 model=original[original.index('--inputs')-1:]
 model[0]=str(candidate)
 if args.mode=='profile':
  stem=out/'qwen-constant-trace'
  command=original[:original.index('--inputs')-1]
  command=[('--output='+str(stem)) if a.startswith('--output=') else a for a in command]
  command+=model
  c.save(out/'inputs.json',{'image':b.b.identity(candidate),'command':command,'full_step_performance':False})
  c.execute('profile',command,env,out)
  nsys=original[0]
  c.execute('export',[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],env,out)
  c.execute('stats',[nsys,'stats','--report=cuda_gpu_kern_sum,cuda_api_sum','--format=csv','--output='+str(stem),str(stem)+'.nsys-rep'],env,out)
  c.save(out/'summary.json',{'image':b.b.identity(candidate),'trace_stem':str(stem),'terminal':True,'throughput_claim':False})
  print('PROFILE_COMPLETE',stem,flush=True);return
 baseline=out/'baseline.exe'
 prior=c.read(b.ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/qwen-link-plan.json')
 for row in prior['inputs']:
  if not b.b.same(row):raise ValueError('Baseline retained object drift: '+row['path'])
 command=[a for a in prior['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command+=['/OUT:'+str(baseline),'/MAP:'+str(baseline.with_suffix('.map')),'/IMPLIB:'+str(baseline.with_suffix('.lib'))]
 c.save(out/'baseline-link-plan.json',dict(prior,command=command))
 c.execute('baseline-link',command,env,out)
 c.save(out/'baseline-image.json',b.b.identity(baseline))
 expected=json.loads((b.ARCH/'cuda-reshape-reuse/correctness-candidate.stdout.log').read_text().splitlines()[-1])
 order=['baseline','candidate','candidate','baseline','baseline','candidate']
 c.save(out/'inputs.json',{'order':order,'baseline':b.b.identity(baseline),'candidate':b.b.identity(candidate),
             'prompt':128,'decode':31,'capacity':256,'profiler':False,'memory_monitor':False,
             'timing':'consumer step_seconds including upload/layout/binding/capture preparation/submit/wait'})
 runs=[]
 for index,arm in enumerate(order):
  argv=model.copy();argv[0]=str(baseline if arm=='baseline' else candidate)
  tag=f'{index+1:02d}-{arm}';c.execute(tag,argv,env,out)
  output=json.loads((out/(tag+'.stdout.log')).read_text().splitlines()[-1])
  if output['generated_ids']!=expected['generated_ids'] or output['decode_input_ids']!=expected['decode_input_ids']:raise ValueError('Fixed journey differs')
  runs.append({'arm':arm,'tag':tag,**metrics(out/(tag+'.stderr.log'))})
  c.save(out/'runs.json',runs)
 keys=[key for key in runs[0] if key not in ('arm','tag')]
 groups={arm:{key:{'samples':[r[key] for r in runs if r['arm']==arm],
                       'median':stat.median(r[key] for r in runs if r['arm']==arm)} for key in keys} for arm in ('baseline','candidate')}
 result={'groups':groups,'ratios':{key:groups['candidate'][key]['median']/groups['baseline'][key]['median'] for key in keys},
         'all_ids_equal':True,'statistical_significance':False,'quality_acceptance':False}
 c.save(out/'summary.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':
 try:main()
 except (ValueError,RuntimeError,OSError,KeyError) as error:
  print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
