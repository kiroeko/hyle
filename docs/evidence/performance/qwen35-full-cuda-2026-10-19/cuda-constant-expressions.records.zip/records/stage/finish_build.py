"""Finish the exact first build: add its missing Vulkan host owner and fix a test assumption."""
from pathlib import Path
import importlib.util
import datetime as dt
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
c=b.c
old=STAGE/'checks/20261019T060757-4cda26e4'
value=c.read(old/'plan.json')
changed=b.ROOT/'tests/graph_provider_ggml_cuda/constant_expression_test.cc'
for row in value['frozen']+value['cached_inputs']:
 if c.key(row['path'])!=c.key(changed) and not b.b.same(row):raise ValueError('Unrelated source/input drift: '+row['path'])
for row in value['compile']:
 ident=c.read(old/(row['tag']+'-identity.json'))
 if not b.b.same(ident['object']):raise ValueError('First-build object drift')
out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
out.mkdir();(out/'tmp').mkdir()
env,_=b.b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
compiles=[]
for tag,source,template in [
 ('native-ragged',b.ROOT/'src/graph_route_vulkan/native_ragged_region.cc',
  next(r['command'] for r in value['compile'] if r['tag']=='117-graph_route_vulkan-native_region')),
 ('constant-expression-test',changed,
  next(r['command'] for r in value['compile'] if r['tag']=='constant-expression-test'))]:
 command=c.compile_command(template,source,tag,out)
 row={'tag':tag,'command':command,'source':b.b.identity(source),'object':str(out/(tag+'.obj'))}
 compiles.append(row);c.execute(tag,command,env,out)
 c.save(out/(tag+'-identity.json'),dict(row,object=b.b.identity(row['object'])))
links={}
for name,original in value['links'].items():
 if name=='qwen':
  links[name]=original;c.save(out/'qwen-image.json',c.read(old/'qwen-image.json'));continue
 command=[arg for arg in original['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 if name=='cuda':command=[compiles[1]['object'] if c.key(arg)==c.key(old/'constant-expression-test.obj') else arg for arg in command]
 else:command.append(compiles[0]['object'])
 image=out/(name+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.execute(name+'-link',command,env,out)
 inputs=[arg for arg in command if not arg.startswith('/') and Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
 links[name]={'command':command,'inputs':inputs,'image':str(image),'base':original['base']}
 c.save(out/(name+'-link-plan.json'),{'command':command,'inputs':[b.b.identity(arg) for arg in inputs]})
 c.save(out/(name+'-image.json'),b.b.identity(image))
value['links']=links;value['compile']+=compiles
value['frozen']=[b.b.identity(r['path']) for r in value['frozen']]
value['first_attempt']=b.b.identity(old/'plan.json')
value['corrections']=['Add current native_ragged_region host TU required by the newly compiled Vulkan adapter; no native math build.',
 'One multi-output cold expression owns three results; test must not require three separate artifacts.']
c.save(out/'plan.json',value)
c.save(out/'summary.json',{'passed':True,'host_TUs':len(value['compile']),'links':3,'tests_run':False,'first_cpu_link_failed':True})
print('BUILD_COMPLETE',out,flush=True)
