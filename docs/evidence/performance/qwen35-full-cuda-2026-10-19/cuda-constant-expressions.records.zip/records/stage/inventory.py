from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[3]
ARCH = ROOT / '.scratch/architecture-refactor-2026-10-18'
STAGE = Path(__file__).resolve().parent
BASES = {
    'qwen': ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/qwen-link-plan.json',
    'cuda': ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/cuda-tests-link-plan.json',
    'cpu': ARCH/'cold-copy-retirement/checks/20261019T053001-df70e294/link.result.json',
}
HEADERS = {
    str((ROOT / name).resolve()).casefold() for name in (
        'include/hyle/graph/region_provider.h', 'src/graph/constant_artifact.h',
        'src/graph/plan_state.h', 'src/compute_provider_ggml_cuda/program.h',
    )
}
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def objects(command):
    return [Path(arg).resolve() for arg in command if not arg.startswith('/')
            and Path(arg).is_absolute() and Path(arg).suffix.lower() == '.obj']
def rows(value):
    if isinstance(value, dict):
        if isinstance(value.get('command'), list): yield value
        elif isinstance(value.get('argv'), list): yield {'command':value['argv']}
        for child in value.values(): yield from rows(child)
    elif isinstance(value, list):
        for child in value: yield from rows(child)
def output(command):
    for arg in command:
        if arg.lower().startswith('/fo'):
            return str(Path(arg[3:]).resolve()).casefold()
    return None
def local_headers(source, command):
    search = [ROOT/'include',ROOT/'src/compute']
    search += [Path(arg[2:]) for arg in command if arg.startswith('/I')]
    visited = set()
    def visit(path):
        path = path.resolve()
        if path in visited or not path.is_file() or not path.is_relative_to(ROOT): return
        visited.add(path)
        if path.suffix not in ('.cc','.h','.inc','.hpp','.cpp'): return
        for name in re.findall(r'^\s*#\s*include\s*[<\"]([^>\"]+)[>\"]',path.read_text(encoding='utf-8-sig'),re.M):
            found = next((p/name for p in [path.parent]+search if (p/name).is_file()),None)
            if found is not None: visit(found)
    visit(Path(source))
    return [str(p) for p in visited if p != Path(source).resolve()]
def main():
    plans = {name: read(path) for name,path in BASES.items()}
    members = {}
    for name,plan in plans.items():
        for path in objects(plan['command']): members.setdefault(path,[]).append(name)
    metadata = {}
    deps = {}
    for parent in sorted({path.parent for path in members}):
        for path in parent.glob('*.json'):
            if path.stat().st_size > 5_000_000: continue
            try: document = read(path)
            except (ValueError, OSError): continue
            if isinstance(document,dict) and isinstance(document.get('Data'),dict):
                deps[str(path.resolve()).casefold()] = document['Data']
            for row in rows(document):
                command = row['command']
                if not command or not isinstance(command[0],str): continue
                old = output(command)
                if old: metadata.setdefault(old,(path,command))
    result = []
    for path,closures in members.items():
        recipe = metadata.get(str(path).casefold())
        row = {'object':str(path),'closures':closures,'recipe':None,'source':None,
               'headers':[],'must_rebuild':False}
        if recipe:
            origin,command = recipe
            row['recipe'] = str(origin); row['command'] = command
            source = [arg for arg in command if arg.lower().endswith(('.cc','.cu','.cpp','.c'))]
            row['source'] = source[0] if len(source)==1 else source
            for index,arg in enumerate(command):
                if arg.lower() == '/sourcedependencies':
                    dep_path = str(Path(command[index+1]).resolve()).casefold()
                    data = deps.get(dep_path)
                    if data is None and Path(command[index+1]).is_file():
                        data = read(Path(command[index+1])).get('Data')
                    if data:
                        row['headers'] = data.get('Includes',[])
            row['must_rebuild'] = any(str(Path(h).resolve()).casefold() in HEADERS for h in row['headers'])
            if not row['headers'] and isinstance(row['source'],str):
                row['headers'] = local_headers(row['source'],command)
                row['dependency_basis'] = 'conservative repository-only literal include traversal'
                row['must_rebuild'] = any(str(Path(h).resolve()).casefold() in HEADERS for h in row['headers'])
        result.append(row)
    target = STAGE/'object-inventory.json'
    target.write_text(json.dumps({'bases':{k:str(v) for k,v in BASES.items()},'objects':result},indent=2),encoding='utf-8')
    for row in result:
        if row['must_rebuild']: print('REBUILD',row['closures'],row['source'])
    print('unmapped',sum(r['recipe'] is None for r in result),'total',len(result),'path',target)
if __name__ == '__main__': main()
