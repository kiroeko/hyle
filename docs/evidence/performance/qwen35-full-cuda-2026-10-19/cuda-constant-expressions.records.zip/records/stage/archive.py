"""Archive necessary source, raw observations and failures; no SDK/object payload."""
from pathlib import Path
import importlib.util
import hashlib
import json
import sys
import zipfile
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
DEST=b.ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-constant-expressions.zip'
PRODUCTS=[
 'include/hyle/graph/region_provider.h','src/graph/constant_artifact.h','src/graph/constant_artifact.cc',
 'src/graph/plan_state.h','src/graph/executable.cc',
 'src/compute_provider_ggml_cuda/program.h','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
 'src/graph_provider_ggml_cuda/constant_expressions.h','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
 'tests/graph/constant_artifact_cache_test.cc','tests/graph/region_provider_test.cc',
 'tests/graph_provider_ggml_cuda/constant_expression_test.cc','tests/graph_provider_ggml_cuda/CMakeLists.txt',
 'docs/architecture/compute-design.md','docs/developer/current-work.md','docs/implementation/model-operators.md',
 'test.ps1']
def prepare():
 files=[b.b.identity(p) for p in STAGE.rglob('*') if p.is_file() and p.suffix.lower() in ('.exe','.map','.lib','.exp')]
 c.save(STAGE/'reclaim-targets.json',files)
 c.save(STAGE/'source-freeze.json',[b.b.identity(b.ROOT/name) for name in PRODUCTS])
 print('PREPARED reclaim files',len(files),'bytes',sum(p['bytes'] for p in files),flush=True)
def archive():
 if DEST.exists():raise ValueError('Archive already exists')
 allowed={'.json','.py','.log','.xml','.csv','.sqlite','.nsys-rep','.bf16','.f32','.tsv','.diff'}
 payload={}
 for path in STAGE.rglob('*'):
  if path.is_file() and path.suffix.lower() in allowed and path.name not in ('archive-verification.json','reclaim-receipt.json'):
   payload['stage/'+path.relative_to(STAGE).as_posix()]=path
 for row in c.read(STAGE/'source-freeze.json'):
  path=Path(row['path'])
  if not b.b.same(row):raise ValueError('Product/source drift: '+row['path'])
  payload['source/'+path.relative_to(b.ROOT).as_posix()]=path
 final=c.read(STAGE/'checks/20261019T061424-1fb66e89/plan.json')
 # Complete repository-owned ABI headers used by this increment; third-party
 # SDKs remain referenced by identity/command in the retained plans.
 for row in final['frozen']:
  path=Path(row['path'])
  if path.is_relative_to(b.ROOT) and not path.is_relative_to(b.ROOT/'.scratch'):
   payload.setdefault('source/'+path.relative_to(b.ROOT).as_posix(),path)
 manifest=[]
 with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,path in sorted(payload.items()):
   data=path.read_bytes();z.writestr(name,data)
   manifest.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  z.writestr('manifest.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(DEST) as z:
  if z.testzip() is not None:raise ValueError('Archive CRC failure')
  for row in manifest:
   data=z.read(row['name'])
   if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('Archive payload mismatch')
 proof=dict(b.b.identity(DEST),entries=len(manifest),CRC_and_payload_SHA_verified=True,
            reclaim_manifest=b.b.identity(STAGE/'reclaim-targets.json'))
 c.save(STAGE/'archive-verification.json',proof);print(json.dumps(proof),flush=True)
if __name__=='__main__':
 if sys.argv[1:]==['--prepare']:prepare()
 elif sys.argv[1:]==['--archive']:archive()
 else:raise SystemExit('Use --prepare then --archive')
