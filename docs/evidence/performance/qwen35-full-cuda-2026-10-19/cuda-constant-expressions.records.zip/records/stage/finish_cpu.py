from pathlib import Path
import importlib.util
import datetime as dt
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
first=STAGE/'checks/20261019T060757-4cda26e4'
second=STAGE/'checks/20261019T061047-d197f686'
value=c.read(first/'plan.json')
out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);out.mkdir();(out/'tmp').mkdir()
env,_=b.b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
source=b.ROOT/'src/compute_route_vulkan/vulkan_batch.cc'
receipt=c.read(b.ARCH/'native-ragged-graph/validation/windows/compile-vulkan_batch.result.json')
command=c.compile_command(receipt['argv'],source,'vulkan-batch',out)
c.execute('vulkan-batch',command,env,out)
compiled={'tag':'vulkan-batch','command':command,'source':b.b.identity(source),'object':str(out/'vulkan-batch.obj')}
c.save(out/'vulkan-batch-identity.json',dict(compiled,object=b.b.identity(compiled['object'])))
inventory=c.read(STAGE/'object-inventory.json')
old=next(r['object'] for r in inventory['objects'] if r['source'] and isinstance(r['source'],str) and c.key(r['source'])==c.key(source) and 'cpu' in r['closures'])
argv=c.read(second/'cpu-link.command.json')['command']
argv=[compiled['object'] if c.key(a)==c.key(old) else a for a in argv if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cpu.exe';argv+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.execute('cpu-link',argv,env,out)
inputs=[a for a in argv if not a.startswith('/') and Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
value['links']['cpu']={'command':argv,'inputs':inputs,'image':str(image),'base':value['links']['cpu']['base']}
c.save(out/'cpu-link-plan.json',{'command':argv,'inputs':[b.b.identity(a) for a in inputs]})
c.save(out/'cpu-image.json',b.b.identity(image))
for name,folder in [('qwen',first),('cuda',second)]:
 prior=c.read(folder/(name+'-link-plan.json'))
 value['links'][name]={'command':prior['command'],'inputs':[r['path'] for r in prior['inputs']],
   'image':str(folder/(name+'.exe')),'base':value['links'][name]['base']}
 c.save(out/(name+'-image.json'),b.b.identity(value['links'][name]['image']))
value['compile'] += [c.read(second/(tag+'-identity.json')) for tag in ('native-ragged','constant-expression-test')]
value['compile'].append(compiled)
value['frozen']=[b.b.identity(r['path']) for r in value['frozen']]
value['frozen'].append(b.b.identity(source))
value['first_cpu_link_failures']=[str(first/'cpu-link.result.json'),str(second/'cpu-link.result.json')]
value['corrections']=['Missing current native_ragged_region and vulkan_batch host owners in old CPU closure.',
 'Multi-output expression has one artifact owner; exact count of separate owners is not an output contract.']
c.save(out/'plan.json',value)
c.save(out/'summary.json',{'passed':True,'host_TUs':28,'links':3,'tests_run':False,'retained_cpu_link_failures':2})
print('BUILD_COMPLETE',out,flush=True)
