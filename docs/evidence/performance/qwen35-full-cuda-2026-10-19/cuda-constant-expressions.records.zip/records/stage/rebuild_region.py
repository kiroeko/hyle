"""Rebuild only the CUDA region after preserving identical Cast storage sharing."""
from pathlib import Path
import importlib.util
import datetime as dt
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
prior=Path(sys.argv[1]).resolve();value=c.read(prior)
changed=b.ROOT/'src/graph_provider_ggml_cuda/constant_expressions.h'
for row in value['frozen']+value['cached_inputs']:
 if c.key(row['path'])!=c.key(changed) and not b.b.same(row):raise ValueError('Unrelated input drift: '+row['path'])
out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);out.mkdir();(out/'tmp').mkdir()
origin=next(r for r in value['compile'] if r['tag']=='77-graph_provider_ggml_cuda-ggml_cuda_region')
source=b.ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'
command=c.compile_command(origin['command'],source,'region',out)
env,_=b.b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
c.execute('region',command,env,out)
fresh={'tag':'region','command':command,'source':b.b.identity(source),'object':str(out/'region.obj')}
c.save(out/'region-identity.json',dict(fresh,object=b.b.identity(fresh['object'])))
for name in ('qwen','cuda'):
 old=value['links'][name]
 argv=[fresh['object'] if c.key(a)==c.key(origin['object']) else a for a in old['command']
       if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 image=out/(name+'.exe');argv+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.execute(name+'-link',argv,env,out)
 inputs=[a for a in argv if not a.startswith('/') and Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
 value['links'][name]={'command':argv,'inputs':inputs,'image':str(image),'base':old['base']}
 c.save(out/(name+'-link-plan.json'),{'command':argv,'inputs':[b.b.identity(a) for a in inputs]})
 c.save(out/(name+'-image.json'),b.b.identity(image))
c.save(out/'cpu-image.json',b.b.identity(value['links']['cpu']['image']))
value['compile'].append(fresh);value['frozen']=[b.b.identity(r['path']) for r in value['frozen']]
value['prior_build']=b.b.identity(prior)
c.save(out/'plan.json',value);c.save(out/'summary.json',{'passed':True,'new_host_TUs':1,'links':2,'tests_run':False})
print('BUILD_COMPLETE',out,flush=True)
