"""Increment only the retained host ABI closure; no SDK/native math rebuild."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import sys
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('projection_build', ARCH/'cuda-projection-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c

def plan():
    inventory = c.read(STAGE/'object-inventory.json')
    out = STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    compiles, replacements, frozen = [], {}, {}
    for index,row in enumerate(inventory['objects']):
        if not row['must_rebuild']: continue
        source = Path(row['source'])
        tag = str(index)+'-'+source.parent.name+'-'+source.stem
        command = c.compile_command(row['command'],source,tag,out)
        obj = str(out/(tag+'.obj'))
        replacements[c.key(row['object'])] = obj
        compiles.append({'tag':tag,'command':command,'object':obj,'source':b.identity(source),
                         'old_object':b.identity(row['object']),'basis':b.identity(row['recipe'])})
        for path in [source]+[Path(p) for p in row['headers']]:
            if path.is_relative_to(ROOT) and not path.is_relative_to(ROOT/'.scratch'):
                frozen[str(path)] = b.identity(path)
    test_source = ROOT/'tests/graph_provider_ggml_cuda/constant_expression_test.cc'
    template = c.read(ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/plan.json')
    test_command = next(row['command'] for row in template['compile'] if row['tag']=='bfloat-matvec-test')
    test_command = c.compile_command(test_command,test_source,'constant-expression-test',out)
    compiles.append({'tag':'constant-expression-test','command':test_command,
                     'object':str(out/'constant-expression-test.obj'),'source':b.identity(test_source)})
    for relative in ('src/graph_provider_ggml_cuda/constant_expressions.h',
                     'tests/graph_provider_ggml_cuda/constant_expression_test.cc'):
        frozen[str(ROOT/relative)] = b.identity(ROOT/relative)
    links, cached = {}, {}
    for name,base in inventory['bases'].items():
        original = c.read(base)
        command = [replacements.get(c.key(arg),arg) if not arg.startswith('/') else arg
                   for arg in original['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if name=='cuda': command.append(str(out/'constant-expression-test.obj'))
        image = out/(name+'.exe')
        command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
                    '/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs = [arg for arg in command if not arg.startswith('/') and Path(arg).is_absolute()
                  and Path(arg).suffix.lower() in ('.obj','.lib')]
        for arg in original['command']:
            if not arg.startswith('/') and Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib'):
                cached[arg] = b.identity(arg)
        links[name] = {'command':command,'inputs':inputs,'image':str(image),'base':b.identity(base)}
    env,runtime = b.environment(links['qwen']['command'],list(cached),out)
    value = {'schema':'hyle.constant_expression.host_increment.v1','compile':compiles,'links':links,
             'frozen':list(frozen.values()),'cached_inputs':list(cached.values()),
             'runtime_path_directories':runtime,'SDK_build':False,'native_math_build':False,
             'dependency_or_object_copy':False,'dependency_inventory':b.identity(STAGE/'object-inventory.json')}
    target = out/'plan.json'; c.save(target,value)
    print('PLAN',target,'host_TUs',len(compiles),'links',len(links),flush=True)
    return target

def check(value):
    for row in value['frozen']+value['cached_inputs']:
        if not b.same(row): raise ValueError('Source/header/object drift: '+row['path'])
    for row in value['links'].values():
        if not b.same(row['base']): raise ValueError('Base link plan drift')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',action='store_true');p.add_argument('--plan',type=Path)
    args=p.parse_args(); target=args.plan.resolve() if args.plan else plan()
    value=c.read(target);check(value)
    if not args.build:return
    out=target.parent;(out/'tmp').mkdir(exist_ok=True)
    env,_=b.environment(value['links']['qwen']['command'],
                         [row['path'] for row in value['cached_inputs']],out)
    for row in value['compile']:
        check(value);c.execute(row['tag'],row['command'],env,out)
        c.save(out/(row['tag']+'-identity.json'),{'command':row['command'],
               'source':b.identity(row['source']['path']),'object':b.identity(row['object'])})
    for name,row in value['links'].items():
        check(value);c.execute(name+'-link',row['command'],env,out)
        c.save(out/(name+'-link-plan.json'),{'command':row['command'],
               'inputs':[b.identity(arg) for arg in row['inputs']]})
        c.save(out/(name+'-image.json'),b.identity(row['image']))
    c.save(out/'summary.json',{'host_TUs':len(value['compile']),'links':len(value['links']),
                              'passed':True,'tests_run':False})
    print('BUILD_COMPLETE',out,flush=True)
if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
