"""Offline physical-count comparison; profiled durations are not speed claims."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent;ARCH=STAGE.parent
spec=importlib.util.spec_from_file_location('retained_analysis',ARCH/'cuda-stable-silu/profile-analysis-stable.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def main():
 stem=STAGE/'profile/qwen-constant-trace';old=ARCH/'cuda-reshape-reuse/profile/qwen-reshape-trace'
 current=a.load(Path(str(stem)+'.sqlite'),Path(str(stem)+'_cuda_gpu_kern_sum.csv'))
 before=a.load(Path(str(old)+'.sqlite'),Path(str(old)+'_cuda_gpu_kern_sum.csv'))
 cp,bp=a.phases(current),a.phases(before)
 comparison=a.compare(current,before,cp,bp)
 checks={'current_phase_binning':cp['valid'],'old_phase_binning':bp['valid'],
         'official_csv_sqlite_equal':current['receipt']['csv_sqlite_per_symbol_counts_equal'],
         'no_graph_api_error':not current['receipt']['graph_api_failures'],
         'profile_exit_zero':a.read(STAGE/'profile/profile.result.json')['exit']==0,
         'same_generated_ids':current['target']['output']['generated_ids']==before['target']['output']['generated_ids']}
 deltas=[]
 for row in comparison['warm_kernel_symbol_deltas']:
  deltas.append({'name':row['name'],'baseline_per_step':row['baseline']/25,
                'candidate_per_step':row['candidate']/25,'delta_per_step':row['delta']/25})
 result={'schema':'hyle.constant_expression.physical_counts.v1','checks':checks,
         'current_image':a.read(STAGE/'profile/inputs.json')['image'],
         'current_receipt':current['receipt'],'old_receipt':before['receipt'],
         'current_warm':cp['warm_decode7_31'],'old_warm':bp['warm_decode7_31'],
         'deltas':deltas,'warm_phase_deltas':comparison['warm_phase_delta'],
         'performance':a.read(STAGE/'performance/summary.json'),
         'limits':['Old trace is the retained reshape image, not a new same-window baseline profile.',
                   'Only separate unprofiled AB/BA/AB process pairs establish throughput observations.',
                   'Prefill phase bin includes new cold-preparation kernels; no pure-prefill kernel count is claimed.',
                   'External constant View->Cast, typed RMS/GDN L2 and complete projection fusion remain incomplete.',
                   'Three pairs provide no statistical significance or model quality acceptance.']}
 a.save(STAGE/'profile-analysis.json',result)
 print(json.dumps({'checks':checks,'old_warm_kernels':bp['warm_decode7_31']['physical_kernel_count'],
                   'current_warm_kernels':cp['warm_decode7_31']['physical_kernel_count'],
                   'deltas':deltas},ensure_ascii=False,indent=2))
 if not all(checks.values()):raise SystemExit(1)
if __name__=='__main__':main()
