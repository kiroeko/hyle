"""Exact CPU/CUDA regressions or one real Qwen correctness replay."""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
c=b.c
CASES={
'cpu':[
'GraphRegions.ReadyOnlyConstantsShareOwnedOutputsAcrossSlotsAndOldResults',
'GraphRegions.ReadyOnlyRegionCarriesControlDependenciesWithoutItsOwnQueue',
'GraphRegions.ReadyOnlyRegionAndViewsExecuteWithoutAnyQueue',
'GraphRegions.ZeroDispatchRejectsIncompletePreparedOutputs',
'GraphRegions.ZeroDispatchRejectsEffectsEvenWithEveryOutputPrepared',
'GraphRegions.ZeroDispatchNeverElidesAnOutputlessResourceEffect',
'GraphRegions.ZeroDispatchCountIsMalformedNotZeroWork',
'ConstantArtifactCache.OpaqueKeyOwnsTemporaryBytesAndComparesExactContents',
'GraphRegions.ConstantCopiesWaitForAcceptedFailuresWithoutRetryingThem',
'GraphRegions.UnknownMaterializationObservationRetainsOwnersUntilNativeRetirement',
'GraphRegions.QueuedMaterializationRejectsRawSourceBeforeCopy',
'GraphPacking.UnknownPreparationObservationRetainsOwnersUntilNativeRetirement',
'CanonicalConstantCache.ReadyOwnersKeepExactResourcesAndDescriptions'],
'cuda':[
'GgmlCudaConstantExpression.RankOneKeysAndNativeExpPreserveSlotsAndRounding',
'GgmlCudaConstantExpression.RankOneRootPreparesWholeRegionWithoutWarmQueue',
'GgmlCudaConstantExpression.PublishedCastViewsAndDynamicWeightsKeepTheirContracts',
'GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs',
'GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable',
'GgmlCudaGraph.SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable',
'CudaDefaultGraph.ImmutableBfloatCastFeedsOriginalGemmRoute',
'CudaDefaultGraph.PreparedCastKeepsIncomingControlForDataOnlyConsumer',
'GgmlCudaBfloatMatvec.ExactRoundingForAlignedAndOddInnerWithBothRhsLayouts',
'GgmlCudaBfloatMatvec.Float32SourceAndOutputKeepTheirPrecision']}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan',type=Path)
 p.add_argument('mode',choices=['cpu','cuda','qwen']);args=p.parse_args()
 plan=c.read(args.plan);out=args.plan.resolve().parent
 if not c.read(out/'summary.json')['passed']:raise ValueError('Build not successful')
 image=Path(plan['links'][args.mode]['image'])
 identity=b.b.identity(image)
 if identity!=c.read(out/(args.mode+'-image.json')):raise ValueError('Image drift')
 run=out/('run-'+args.mode);run.mkdir(exist_ok=False);(run/'tmp').mkdir()
 env,_=b.b.environment(plan['links']['qwen']['command'],
                       [r['path'] for r in plan['cached_inputs']],run)
 if args.mode in CASES:
  cases=CASES[args.mode];xml=run/'tests.xml'
  c.execute('tests',[str(image),'--gtest_color=no','--gtest_filter='+':'.join(cases),
                    '--gtest_output=xml:'+str(xml)],env,run)
  doc=ET.parse(xml).getroot();actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in doc.findall('.//testcase')]
  if set(actual)!=set(cases) or doc.findall('.//failure') or doc.findall('.//skipped'):raise ValueError('Missing/failed/skipped exact regression')
  c.save(run/'summary.json',{'cases':actual,'failures':0,'skipped':0,'image':identity})
  print('PASS',args.mode,len(actual),flush=True);return
 prior=b.ARCH/'cuda-reshape-reuse'
 trace=run/'trace'
 argv=c.read(prior/'correctness-candidate.command.json')['command']
 argv[0]=str(image);argv[argv.index('--trace')+1]=str(trace)
 c.execute('qwen',argv,env,run)
 before=prior/'correctness-candidate/trace'
 paths=sorted(p.relative_to(before) for p in before.rglob('*') if p.suffix in ('.bf16','.f32'))
 actual=sorted(p.relative_to(trace) for p in trace.rglob('*') if p.suffix in ('.bf16','.f32'))
 if len(paths)!=64 or actual!=paths:raise ValueError('Qwen observation set differs')
 vectors=[];different=[]
 for path in paths:
  old,new=b.b.identity(before/path),b.b.identity(trace/path)
  equal=(old['sha256']==new['sha256'] and old['bytes']==new['bytes'])
  vectors.append({'path':path.as_posix(),'bytes':new['bytes'],'sha256':new['sha256'],'byte_equal':equal})
  if not equal:different.append(path.as_posix())
 previous=json.loads((prior/'correctness-candidate.stdout.log').read_text().splitlines()[-1])
 current=json.loads((run/'qwen.stdout.log').read_text().splitlines()[-1])
 capture=re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)',(run/'qwen.stderr.log').read_text())
 result={'vectors':vectors,'equal_vectors':64-len(different),'different':different,
         'same_generated_ids':current['generated_ids']==previous['generated_ids'],
         'same_decode_input_ids':current['decode_input_ids']==previous['decode_input_ids'],
         'capture_counts':capture,'image':identity,'throughput_claim':False}
 c.save(run/'summary.json',result)
 if different or not result['same_generated_ids'] or not result['same_decode_input_ids']:raise ValueError('Qwen output differs; inspect summary before accepting math')
 print('PASS qwen 64 byte-identical vectors and 32 IDs',flush=True)
if __name__=='__main__':
 try:main()
 except (ValueError,RuntimeError,OSError,KeyError) as error:
  print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
