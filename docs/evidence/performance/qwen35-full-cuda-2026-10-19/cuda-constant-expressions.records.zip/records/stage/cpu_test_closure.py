"""Link the CPU-only test consumer without unrelated Vulkan implementations."""
from pathlib import Path
import importlib.util
import datetime as dt
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_build',STAGE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
first=STAGE/'checks/20261019T060757-4cda26e4'
second=STAGE/'checks/20261019T061047-d197f686'
third=STAGE/'checks/20261019T061131-593edeaf'
value=c.read(first/'plan.json');inventory=c.read(STAGE/'object-inventory.json')
sources={c.key(r['object']):r['source'] for r in inventory['objects'] if isinstance(r['source'],str)}
for row in value['compile']:sources[c.key(row['object'])]=row['source']['path']
remove={}
prefixes=('src/compute_route_vulkan/','src/graph_route_vulkan/',
          'src/compute_provider_ggml_vulkan/','src/compute_provider_iree_vulkan/')
for obj,source in sources.items():
 path=Path(source)
 relative=path.relative_to(b.ROOT).as_posix()
 if relative.startswith(prefixes) or any(word in relative for word in (
    'vulkan-highdim/ggml-vulkan.candidate','native-row-cache-padded/shaders/',
    'iree-grouped-inline-product/generated/')):remove[obj]=source
out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);out.mkdir();(out/'tmp').mkdir()
env,_=b.b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
command=[a for a in value['links']['cpu']['command'] if c.key(a) not in remove and
         not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'removed-unrelated-host-objects.json',remove)
c.execute('cpu-link',command,env,out)
inputs=[a for a in command if not a.startswith('/') and Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
value['links']['cpu']={'command':command,'inputs':inputs,'image':str(image),'base':value['links']['cpu']['base']}
c.save(out/'cpu-link-plan.json',{'command':command,'inputs':[b.b.identity(a) for a in inputs]})
c.save(out/'cpu-image.json',b.b.identity(image))
for name,folder in [('qwen',first),('cuda',second)]:
 prior=c.read(folder/(name+'-link-plan.json'))
 value['links'][name]={'command':prior['command'],'inputs':[r['path'] for r in prior['inputs']],
   'image':str(folder/(name+'.exe')),'base':value['links'][name]['base']}
 c.save(out/(name+'-image.json'),b.b.identity(value['links'][name]['image']))
value['compile'] += [c.read(second/(tag+'-identity.json')) for tag in ('native-ragged','constant-expression-test')]
value['compile'].append(c.read(third/'vulkan-batch-identity.json'))
value['frozen']=[b.b.identity(r['path']) for r in value['frozen']]
value['first_cpu_link_failures']=[str(folder/'cpu-link.result.json') for folder in (first,second,third)]
value['removed_unrelated_objects']=remove
value['corrections']=['CPU regression consumer references no Vulkan API; exclude unrelated optional GPU implementation objects from its explicit host closure.',
 'Retain three old CPU-closure link failures; they are not product/test passes.',
 'Multi-output cold expression owns one artifact, not necessarily one owner per result.']
c.save(out/'plan.json',value)
c.save(out/'summary.json',{'passed':True,'host_TUs':28,'links':3,'tests_run':False,'cpu_only_test_closure':True,'retained_cpu_link_failures':3})
print('BUILD_COMPLETE',out,'pruned',len(remove),'cpu_inputs',len(inputs),flush=True)
