"""Extend existing raw paired observations offline; never repeats a GPU run."""
from pathlib import Path
import importlib.util
import statistics as stat
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('constant_experiment',STAGE/'experiment.py')
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
out=STAGE/'performance';runs=e.c.read(out/'runs.json')
for row in runs:row.update(e.metrics(out/(row['tag']+'.stderr.log')))
keys=[k for k in runs[0] if k not in ('arm','tag')]
groups={arm:{key:{'samples':[r[key] for r in runs if r['arm']==arm],
                 'median':stat.median(r[key] for r in runs if r['arm']==arm)} for key in keys} for arm in ('baseline','candidate')}
value=e.c.read(out/'summary.json');value['groups']=groups
value['ratios']={key:groups['candidate'][key]['median']/groups['baseline'][key]['median'] for key in keys}
value['added_metrics_are_offline']=True
e.c.save(out/'runs.json',runs);e.c.save(out/'summary.json',value)
print({key:[groups[arm][key]['median'] for arm in ('baseline','candidate')] for key in keys})
