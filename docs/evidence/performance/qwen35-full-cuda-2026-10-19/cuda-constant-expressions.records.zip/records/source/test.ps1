param([switch]$ReclaimConstantExpressions)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimConstantExpressions) { throw 'Use -ReclaimConstantExpressions for reviewed exact targets.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18/cuda-normalization-review'))
$receipt = Join-Path $taskRoot 'reclaim-receipt.json'
if (Test-Path -LiteralPath $receipt) { throw 'Reclaim already recorded.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'archive-verification.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $proof.path -Algorithm SHA256).Hash -ne $proof.sha256) { throw 'Archive changed.' }
if ((Get-FileHash -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Algorithm SHA256).Hash -ne $proof.reclaim_manifest.sha256) { throw 'Reclaim plan changed.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
@{targets=$targets;archive=$proof;recursive=$false;objects_retained=$true;raw_vectors_retained=$true} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receipt -Encoding utf8
