#include "hyle/graph/providers/ggml_cuda.h"

#include <algorithm>
#include <array>
#include <exception>
#include <limits>
#include <new>
#include <vector>

#include "hyle/graph/region_provider.h"
#include "hyle/compute/model_ops.h"
#include "../graph_ggml_shared/constant_packing.h"
#include "../graph/region_discovery.h"
#include "program.h"
#include "constant_expressions.h"

namespace hyle::graph::ggml_cuda {
namespace native = compute::ggml_cuda::internal;
namespace {

inline constexpr compute::RoutePolicyId kGgmlCudaRegionPolicy{
    0x48594c4547474355ULL, 1, 1};
inline constexpr compute::RoutePolicyId kGgmlCudaSiluMultiplyPolicy{
    0x48594c4547474355ULL, 2, 1};
inline constexpr std::uint32_t kGgmlCudaSiluMultiplyPreference = 200;

Result<bool> supported_node(void *context, const Graph &graph,
                            NodeId node) noexcept {
  auto operation = graph.operation(node);
  if (!operation)
    return false; // Symbolic metadata views are not this exact native domain.
  auto input_count = graph.node_input_count(node);
  auto output_count = graph.node_output_count(node);
  auto effects = graph.node_resource_count(node);
  if (!input_count || !output_count || !effects)
    return std::unexpected(
        Status::InvalidArgument("ggml CUDA region node is invalid"));
  if (*output_count == 0 || *effects != 0)
    return false;
  try {
    std::vector<compute::TensorDesc> inputs(*input_count);
    std::vector<compute::TensorDesc> outputs(*output_count);
    for (std::size_t i = 0; i < *input_count; ++i) {
      auto id = graph.node_input(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      inputs[i] = *description;
    }
    for (std::size_t i = 0; i < *output_count; ++i) {
      auto id = graph.result(node, i);
      if (!id)
        return std::unexpected(std::move(id).error());
      auto description = graph.value_description(*id);
      if (!description)
        return false;
      outputs[i] = *description;
    }
    return native::supports(context, *operation, inputs, outputs);
  } catch (const std::bad_alloc &) {
    return std::unexpected(Status::ResourceExhausted(
        "ggml CUDA region descriptor allocation failed"));
  }
}

bool single_constant_expert(const Graph &graph, NodeId node) noexcept {
  const auto operation = graph.operation(node);
  if (!operation || !operation->custom_as<compute::model_ops::GroupedMatMul>())
    return false;
  const auto weight = graph.node_input(node, 0);
  if (!weight || weight->kind() != ValueKind::kConstant) return false;
  const auto description = graph.value_description(*weight);
  return description && description->is_plain() && description->is_dense() &&
         description->rank() == 3 &&
         description->data_type() == compute::DataType::kBFloat16;
}

bool single_constant_preparation(const Graph &graph, NodeId node) noexcept {
  if (single_constant_expert(graph, node)) return true;
  const auto operation = graph.operation(node);
  if (!operation) return false;
  const auto traits = compute::operation_traits(*operation);
  if (traits.effect != compute::EffectKind::kPure || traits.resource_count != 0 ||
      traits.alias == compute::AliasPolicy::kMustAliasInput0)
    return false;
  const auto inputs = graph.node_input_count(node).value();
  if (inputs == 0) return false;
  for (std::size_t port = 0; port < inputs; ++port)
    if (graph.node_input(node, port)->kind() != ValueKind::kConstant) return false;
  for (std::size_t port = 0; port < graph.node_output_count(node).value(); ++port) {
    const auto value = graph.result(node, port).value();
    const auto description = graph.value_description(value).value();
    if (!description.is_plain() || !description.is_dense() ||
        ggml_shared::published_view_of(graph, value)) return false;
  }
  return true;
}

// One discovery-local use index. It proves that delaying SiLU until the
// multiply's other producer is ready cannot hide another data/control reader.
// It is not retained by the native recipe or queried during submit.
struct SiluMultiplyUses final {
  static constexpr std::uint64_t kNone = UINT64_MAX;
  static constexpr std::uint64_t kMany = UINT64_MAX - 1;
  container::SmallVector<std::uint8_t, 16, mem::AllocatorRef> uses;
  container::SmallVector<std::uint64_t, 16, mem::AllocatorRef> control_readers;

  explicit SiluMultiplyUses(mem::AllocatorRef allocator) noexcept
      : uses(allocator), control_readers(allocator) {}

  Status initialize(const Graph &graph) noexcept {
    if (!uses.try_resize(graph.value_count()) ||
        !control_readers.try_resize(graph.node_count()))
      return Status::ResourceExhausted("ggml CUDA fusion use metadata failed");
    std::ranges::fill(uses, std::uint8_t{0});
    std::ranges::fill(control_readers, kNone);
    for (std::size_t i = 0; i < graph.node_count(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
      HYLE_ASSIGN_OR_RETURN(auto count, graph.node_input_count(node));
      for (std::size_t port = 0; port < count; ++port) {
        HYLE_ASSIGN_OR_RETURN(auto value, graph.node_input(node, port));
        auto &readers = uses[value.ordinal()];
        if (readers < 2) ++readers;
      }
      HYLE_ASSIGN_OR_RETURN(auto dependencies, graph.node_dependency_count(node));
      for (std::size_t index = 0; index < dependencies; ++index) {
        HYLE_ASSIGN_OR_RETURN(auto before, graph.node_dependency(node, index));
        auto &reader = control_readers[before.ordinal()];
        if (reader == kNone) reader = node.ordinal();
        else if (reader != node.ordinal()) reader = kMany;
      }
    }
    for (std::size_t i = 0; i < graph.output_count(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto value, graph.output_id(i));
      uses[value.ordinal()] = 2;
    }
    return Status::Ok();
  }
};

template <class CanElide>
Result<bool> matches_silu_multiply(void *context, const Graph &graph,
                                   std::span<const NodeId> nodes,
                                   CanElide can_elide) noexcept {
  if (nodes.size() != 2) return false;
  const auto silu = graph.operation(nodes[0]);
  const auto multiply = graph.operation(nodes[1]);
  if (!silu || !multiply) return false;
  const auto *unary = silu->get_if<compute::Unary>();
  const auto *binary = multiply->get_if<compute::Binary>();
  if (!unary || unary->kind != compute::UnaryKind::kSilu || !binary ||
      binary->kind != compute::BinaryKind::kMultiply)
    return false;
  HYLE_ASSIGN_OR_RETURN(auto silu_inputs, graph.node_input_count(nodes[0]));
  HYLE_ASSIGN_OR_RETURN(auto mul_inputs, graph.node_input_count(nodes[1]));
  HYLE_ASSIGN_OR_RETURN(auto silu_outputs, graph.node_output_count(nodes[0]));
  HYLE_ASSIGN_OR_RETURN(auto mul_outputs, graph.node_output_count(nodes[1]));
  if (silu_inputs != 1 || mul_inputs != 2 || silu_outputs != 1 || mul_outputs != 1)
    return false;
  HYLE_ASSIGN_OR_RETURN(auto gate, graph.node_input(nodes[0], 0));
  HYLE_ASSIGN_OR_RETURN(auto intermediate, graph.result(nodes[0]));
  HYLE_ASSIGN_OR_RETURN(auto left, graph.node_input(nodes[1], 0));
  HYLE_ASSIGN_OR_RETURN(auto right, graph.node_input(nodes[1], 1));
  if ((left != intermediate && right != intermediate) || left == right ||
      !can_elide(nodes[0], nodes[1], intermediate))
    return false;
  HYLE_ASSIGN_OR_RETURN(auto output, graph.result(nodes[1]));
  HYLE_ASSIGN_OR_RETURN(auto description, graph.value_description(gate));
  const auto type = description.data_type();
  if (!description.is_plain() || !description.is_dense() ||
      (type != compute::DataType::kFloat32 &&
       type != compute::DataType::kBFloat16))
    return false;
  for (const auto value : {intermediate, left, right, output}) {
    HYLE_ASSIGN_OR_RETURN(auto actual, graph.value_description(value));
    if (actual != description) return false;
  }
  for (const auto node : nodes) {
    HYLE_ASSIGN_OR_RETURN(auto supported, supported_node(context, graph, node));
    if (!supported) return false;
  }
  return true;
}

Status propose(void *context, const RegionDiscoveryRequest &request, mem::AllocatorRef allocator,
               RegionProposalWriter &writer) noexcept {
  const auto &graph = request.graph;
  if ((!request.allowed_nodes.empty() && request.allowed_nodes.size() != graph.node_count()) ||
      (!request.leaf_preferences.empty() && request.leaf_preferences.size() != graph.node_count()))
    return Status::InvalidArgument("ggml CUDA discovery mask size differs");
  if (graph.node_count() == 0)
    return Status::Ok();
  // Ordinary islands preserve admitted leaf preferences. A specific fusion
  // may cross a nonpreferred leaf because it offers a different implementation.
  constexpr std::uint8_t kSupported = 1, kOrdinary = 2;
  container::SmallVector<std::uint8_t, 16, mem::AllocatorRef> eligible(allocator);
  if (!eligible.try_resize(graph.node_count()))
    return Status::ResourceExhausted("ggml CUDA discovery eligibility failed");
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    eligible[i] = 0;
    if (!request.allowed_nodes.empty() && !request.allowed_nodes[i]) continue;
    HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
    HYLE_ASSIGN_OR_RETURN(auto supported, supported_node(context, graph, node));
    if (!supported) continue;
    eligible[i] = kOrdinary;
    if (!request.leaf_preferences.empty()) {
      const auto &facts = request.leaf_preferences[i];
      if (facts.provider && facts.best && *facts.provider > *facts.best) {
        eligible[i] = kSupported;
      }
    }
  }
  SiluMultiplyUses uses(allocator);
  HYLE_RETURN_IF_ERROR(uses.initialize(graph));
  // Follow the multiply's actual operands, independent of insertion adjacency.
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    if (!eligible[i]) continue;
    HYLE_ASSIGN_OR_RETURN(auto multiply, graph.node_id(i));
    const auto operation = graph.operation(multiply);
    const auto *binary = operation ? operation->get_if<compute::Binary>() : nullptr;
    if (!binary || binary->kind != compute::BinaryKind::kMultiply) continue;
    for (std::size_t port = 0; port < 2; ++port) {
      HYLE_ASSIGN_OR_RETURN(auto value, graph.node_input(multiply, port));
      if (value.kind() != ValueKind::kNodeOutput) continue;
      HYLE_ASSIGN_OR_RETURN(auto silu, graph.producer(value));
      if (!eligible[silu.ordinal()]) continue;
      const std::array nodes{silu, multiply};
      HYLE_ASSIGN_OR_RETURN(auto matches, matches_silu_multiply(context, graph, nodes,
          [&](NodeId first, NodeId last, ValueId intermediate) noexcept {
            const auto control = uses.control_readers[first.ordinal()];
            return uses.uses[intermediate.ordinal()] == 1 &&
                   (control == SiluMultiplyUses::kNone || control == last.ordinal());
          }));
      if (!matches) continue;
      HYLE_ASSIGN_OR_RETURN(auto more, writer.try_add({
          .nodes = nodes,
          .cost = {.workspace = std::nullopt, .persistent_bytes = std::nullopt,
                   .copy_bytes = std::nullopt, .repack_bytes = std::nullopt,
                   .synchronization_count = 2, .dispatch_count = 1},
          .route = 2,
          .replay_class = compute::ProviderReplayClass::kManaged,
          .implementation = compute::ProviderImplementationId{3},
          .policy = kGgmlCudaSiluMultiplyPolicy,
          .preference = kGgmlCudaSiluMultiplyPreference}));
      if (!more) return Status::Ok();
      break;
    }
  }
  const auto emit = [&](std::span<const NodeId> nodes) -> Result<bool> {
    // Immutable preparation also applies to a single ordinary operation;
    // dynamic singleton operations retain their ordinary provider ranks.
    if (nodes.empty() || (nodes.size() == 1 && !single_constant_preparation(graph, nodes[0])))
      return true;
    std::uint32_t preference = 0;
    bool has_math = false;
    for (const auto node : nodes) {
      // The actual supported public View is metadata, not an unranked
      // mathematical provider alternative. Do not invent a provider rank for it.
      const auto operation = graph.operation(node);
      if (operation && operation->get_if<compute::View>()) continue;
      has_math = true;
      if (request.leaf_preferences.empty() ||
          !request.leaf_preferences[node.ordinal()].provider) {
        preference = UINT32_MAX;
        break;
      }
      preference = std::max(preference, *request.leaf_preferences[node.ordinal()].provider);
    }
    if (!has_math) preference = UINT32_MAX;
    return writer.try_add(
        {.nodes = nodes,
         .cost = {.workspace = std::nullopt,
                  .persistent_bytes = std::nullopt,
                  .copy_bytes = std::nullopt,
                  .repack_bytes = std::nullopt,
                  .synchronization_count = 2,
                  .dispatch_count = 1},
         .route = 1,
         .replay_class = compute::ProviderReplayClass::kManaged,
         .implementation = compute::ProviderImplementationId{2},
         .policy = kGgmlCudaRegionPolicy,
         .preference = preference});
  };
  return detail::discover_regions(graph, allocator,
      [&](NodeId node) -> Result<bool> {
        return eligible[node.ordinal()] == kOrdinary;
      }, emit);
}

Status qualify(void *context, const RegionCompileRequest &request) noexcept {
  if (!request.graph || (request.route != 1 && request.route != 2) || request.nodes.empty() ||
      request.outputs.empty() || request.has_unknown_effects ||
      !request.effect_accesses.empty())
    return Status::Unimplemented("ggml CUDA region boundary is not admitted");
  if (request.route == 2) {
    HYLE_ASSIGN_OR_RETURN(auto matches, matches_silu_multiply(
        context, *request.graph, request.nodes,
        [&](NodeId, NodeId, ValueId intermediate) noexcept {
          // Common boundary discovery exposes every published/externally read
          // value. Its contraction already preserves all control dependencies.
          return std::ranges::find(request.outputs, intermediate) == request.outputs.end();
        }));
    return matches ? Status::Ok()
                   : Status::Unimplemented("ggml CUDA SiLU multiply boundary is not admitted");
  }
  if (request.nodes.size() == 1 &&
      !single_constant_preparation(*request.graph, request.nodes.front()))
    return Status::Unimplemented("ggml CUDA singleton has no immutable preparation");
  for (const auto node : request.nodes) {
    auto supported = supported_node(context, *request.graph, node);
    if (!supported)
      return std::move(supported).error();
    if (!*supported)
      return Status::Unimplemented(
          "ggml CUDA region contains an unsupported node");
  }
  return Status::Ok();
}
Status resources(void *context, const RegionCompileRequest &request,
                 mem::AllocatorRef,
                 std::span<RegionInputRequirement> inputs,
                 std::span<RegionOutputRequirement> outputs,
                 RegionResourceProposal *proposal) noexcept {
  *proposal = {};
  HYLE_RETURN_IF_ERROR(qualify(context, request));
  std::ranges::fill(inputs, RegionInputRequirement{.resource = native::kBinding});
  std::ranges::fill(outputs, RegionOutputRequirement{.resource = native::kBinding});
  for (auto &binding : inputs)
    binding.resource.minimum_alignment = 1;
  for (auto &binding : outputs)
    binding.resource.minimum_alignment = 1;
  for (const auto node : request.nodes) {
    const auto operation = request.graph->operation(node).value();
    const auto require = [&](ValueId id) {
      const auto type = request.graph->value_description(id)->data_type();
      const auto alignment = native::boundary_alignment(operation, type);
      // Published values may also be read by another native node. Its input
      // requirement is part of the external output's binding contract too.
      for (std::size_t i = 0; i < request.inputs.size(); ++i)
        if (request.inputs[i] == id)
          inputs[i].resource.minimum_alignment =
              std::max(inputs[i].resource.minimum_alignment, alignment);
      for (std::size_t i = 0; i < request.outputs.size(); ++i)
        if (request.outputs[i] == id)
          outputs[i].resource.minimum_alignment =
              std::max(outputs[i].resource.minimum_alignment, alignment);
    };
    for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
         ++i)
      require(request.graph->node_input(node, i).value());
    for (std::size_t i = 0;
         i < request.graph->node_output_count(node).value(); ++i)
      require(request.graph->result(node, i).value());
  }
  *proposal = {.runtime = native::kRuntime,
               .workspace_resource = native::kBinding};
  return Status::Ok();
}

struct Artifact final {
  compute::detail::ProviderPrepared native;
};
void destroy(void *value, mem::AllocatorRef allocator) noexcept {
  auto *artifact = static_cast<Artifact *>(value);
  if (!artifact)
    return;
  if (artifact->native.vtable)
    artifact->native.vtable->destroy_prepared(artifact->native.state, allocator);
  artifact->~Artifact();
  allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
}
compute::AliasSupport alias(void *, std::size_t, std::size_t) noexcept {
  return {};
}
Status create_invocation(void *value, mem::AllocatorRef allocator,
                         mem::BufferView workspace, void **output) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  if (!artifact.vtable) { *output = nullptr; return Status::Ok(); }
  return artifact.vtable->create_invocation(artifact.state, allocator,
                                            workspace, output);
}
// Both Direct and Graph use the same invocation callbacks; this table keeps
// only an immutable pointer to that table, never a second execution program.
struct Invocation final {
  const compute::detail::ProviderPreparedVTable *vtable = nullptr;
  void *state = nullptr;
  std::vector<compute::ConstTensorView> input_bindings;
};
Status create_region_invocation(void *value, mem::AllocatorRef allocator,
                                mem::BufferView workspace,
                                void **output) noexcept {
  *output = nullptr;
  const auto &artifact = static_cast<Artifact *>(value)->native;
  if (!artifact.vtable) return Status::Ok();
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage)
    return Status::ResourceExhausted(
        "ggml CUDA region invocation allocation failed");
  auto *invocation = ::new (storage) Invocation{artifact.vtable, nullptr, {}};
  *output = invocation;
  return create_invocation(value, allocator, workspace, &invocation->state);
}
void destroy_region_invocation(void *value,
                               mem::AllocatorRef allocator) noexcept {
  auto *invocation = static_cast<Invocation *>(value);
  if (!invocation)
    return;
  if (invocation->vtable)
    invocation->vtable->destroy_invocation(invocation->state, allocator);
  invocation->~Invocation();
  allocator.deallocate(invocation, sizeof(Invocation), alignof(Invocation));
}
compute::detail::EnqueueResult
submit(void *value, void *lane, compute::detail::QueueSequence &sequence,
       std::span<const compute::ConstTensorView> inputs,
       std::span<const compute::TensorView> outputs) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  if (!artifact.vtable) return compute::detail::EnqueueResult::no_op();
  return artifact.vtable->shared_submit(artifact.state,
                                        static_cast<Invocation *>(lane)->state,
                                        sequence, inputs, outputs);
}
Status prepare_bindings(void *value, void *lane,
                        std::span<const RegionValue> inputs,
                        std::span<const compute::TensorView> outputs) noexcept {
  const auto &artifact = static_cast<Artifact *>(value)->native;
  if (!artifact.vtable) return Status::Ok();
  auto &invocation = *static_cast<Invocation *>(lane);
  try {
    invocation.input_bindings.resize(inputs.size());
    for (std::size_t i = 0; i < inputs.size(); ++i)
      invocation.input_bindings[i] = inputs[i].tensor;
  } catch (...) {
    return Status::ResourceExhausted("ggml CUDA cold region bindings failed");
  }
  return artifact.vtable->prepare_bindings(
      artifact.state, invocation.state, invocation.input_bindings, outputs);
}
const ProviderRegionPreparedVTable kPrepared{
    .destroy_prepared = &destroy,
    .alias_support = &alias,
    .create_invocation = &create_region_invocation,
    .destroy_invocation = &destroy_region_invocation,
    .shared_submit = &submit,
    .prepare_bindings = &prepare_bindings};

compute::ProviderPrepareOutcome
compile(void *context, const RegionCompileRequest &request,
        mem::AllocatorRef allocator, ProviderRegionPrepared *output) noexcept {
  *output = {};
  auto status = qualify(context, request);
  if (!status.ok())
    return status.IsUnimplemented()
        ? compute::ProviderPrepareOutcome::unsupported(std::move(status))
        : compute::ProviderPrepareOutcome::error(std::move(status));
  try {
    native::Recipe recipe;
    std::vector<ValueId> values(request.inputs.begin(), request.inputs.end());
    for (std::uint32_t i = 0; i < values.size(); ++i)
      recipe.inputs.push_back(i);
    for (const auto node : request.nodes)
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        values.push_back(request.graph->result(node, port).value());
    const auto local = [&](ValueId value) -> std::uint32_t {
      return static_cast<std::uint32_t>(std::ranges::find(values, value) -
                                        values.begin());
    };
    for (const auto id : values)
      recipe.values.push_back(request.graph->value_description(id).value());
    for (const auto node : request.nodes) {
      native::Node lowered{request.graph->operation(node).value(), {}, {}};
      for (std::size_t port = 0;
           port < request.graph->node_output_count(node).value(); ++port)
        lowered.outputs.push_back(
            local(request.graph->result(node, port).value()));
      for (std::size_t i = 0; i < request.graph->node_input_count(node).value();
           ++i) {
        const auto id = local(request.graph->node_input(node, i).value());
        if (id >= values.size())
          return compute::ProviderPrepareOutcome::error(Status::InvalidArgument(
              "ggml CUDA region misses an input boundary"));
        lowered.inputs.push_back(id);
      }
      recipe.nodes.push_back(std::move(lowered));
    }
    for (const auto id : request.outputs)
      recipe.outputs.push_back(local(id));
    const auto constants = constant_expressions::prepare(context, request, values, recipe);
    if (constants.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return constants;
    const auto packing = ggml_shared::pack_constants(context, request, values, recipe,
        &native::widen_bfloat_constant, &native::pack_matrix_constant);
    if (packing.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return packing;
    std::size_t checked_copy_bytes = 0;
    std::uint32_t dispatches = 1;
    const auto add_checked_copy = [&](const compute::TensorDesc &description) {
      const auto bytes = description.required_bytes().value();
      if (bytes > SIZE_MAX - checked_copy_bytes ||
          dispatches == std::numeric_limits<std::uint32_t>::max())
        return false;
      checked_copy_bytes += bytes;
      if (bytes != 0) ++dispatches;
      return true;
    };
    bool checked = false;
    for (const auto &node : recipe.nodes) {
      const auto *gather = node.operation.get_if<compute::Gather>();
      const auto elements = node.operation.custom_as<compute::model_ops::GatherElements>();
      const bool grouped = node.operation.custom_as<compute::model_ops::GroupedMatMul>().has_value();
      if (!grouped && !(gather && gather->bounds == compute::IndexBoundsPolicy::kChecked) &&
          !(elements && elements->bounds == compute::IndexBoundsPolicy::kChecked))
        continue;
      checked = true;
      if (!add_checked_copy(recipe.values[node.inputs[grouped ? 2 : 1]]))
        return compute::ProviderPrepareOutcome::error(
            Status::OutOfRange("ggml CUDA checked copy cost overflows"));
    }
    if (checked)
      for (const auto id : recipe.outputs)
        if (!add_checked_copy(recipe.values[id]))
          return compute::ProviderPrepareOutcome::error(
              Status::OutOfRange("ggml CUDA checked output cost overflows"));
    void *storage = allocator.allocate(sizeof(Artifact), alignof(Artifact));
    if (!storage)
      return compute::ProviderPrepareOutcome::error(
          Status::ResourceExhausted(
              "ggml CUDA region artifact allocation failed"));
    auto *artifact = ::new (storage) Artifact;
    if (recipe.nodes.empty()) {
      // All original outputs have ready artifact bindings. Keep a metadata
      // region for the logical producer/control edges, with no native program,
      // workspace, invocation work or placeholder Queue command.
      *output = {.vtable = &kPrepared, .state = artifact,
          .properties = {.workspace = {}, .persistent_bytes = sizeof(Artifact),
                         .copy_bytes = 0,
                         .synchronization_count = 0, .dispatch_count = 0,
                         .runtime = native::kRuntime, .invocation_private_bytes = 0}};
      return compute::ProviderPrepareOutcome::prepared();
    }
    const auto outcome = native::compile(context, std::move(recipe), allocator,
                                         &artifact->native);
    if (!artifact->native.state) {
      artifact->~Artifact();
      allocator.deallocate(artifact, sizeof(Artifact), alignof(Artifact));
      return outcome;
    }
    *output = {.vtable = &kPrepared,
               .state = artifact,
               .properties = {.workspace = artifact->native.workspace,
                              .persistent_bytes = std::nullopt,
                              // Indexed consumers use private safe IDs and
                              // publish all outputs only after device checks.
                              // Native auxiliary pools/materialization remain unknown.
                              .copy_bytes = checked_copy_bytes,
                              .synchronization_count = 2,
                              .dispatch_count = dispatches,
                              .runtime = artifact->native.runtime,
                              .invocation_private_bytes = std::nullopt}};
    return outcome;
  } catch (const std::bad_alloc &) {
    return compute::ProviderPrepareOutcome::error(
        Status::ResourceExhausted("ggml CUDA region recipe allocation failed"));
  } catch (const std::exception &error) {
    return compute::ProviderPrepareOutcome::error(
        Status::Internal(error.what()));
  }
}
const RegionProviderVTable kRegion{
    .propose = &propose, .propose_resources = &resources, .compile = &compile};
} // namespace

compute::Provider provider() noexcept {
  return native::with_extension(kRegionProviderExtensionId, &kRegion);
}
} // namespace hyle::graph::ggml_cuda
