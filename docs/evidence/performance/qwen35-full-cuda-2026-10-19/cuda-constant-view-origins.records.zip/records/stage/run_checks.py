"""Reuse the prior exact CPU/CUDA/Qwen checks; invoke only an explicit mode."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
b=load('immutable_alias_current_build',STAGE/'build_current.py')
prior=load('normalization_exact_checks',b.ARCH/'cuda-normalization-review/run_checks.py')
prior.STAGE=STAGE;prior.b=b;prior.c=b.c
prior.CASES['cpu'] += [
    'ConstantArtifactCache.AliasOriginsSeparateEqualDescriptionsByRootAndOffset',
    'GraphRegions.ImmutableConstantViewsPreserveDenseReshapeAndSliceBindings',
    'GraphRegions.ConstantViewOffsetsSeparateFiniteVariantArtifacts',
    'GraphRegions.ConstantViewPreparationKeepsEachPhysicalRootOwner',
    'GraphRegions.DynamicAndUnownedViewsDoNotAcquireQueuedArtifacts',
    'GraphRegions.DomainConstantViewChecksActualPortAlignmentBeforeEnqueue']
prior.CASES['cuda'] += [
    'GgmlCudaConstantExpression.ImmutableViewsKeepOffsetsAndRepeatedExpressionsDistinct',
    'GgmlCudaConstantExpression.ExternalViewSingletonCastNeedsNoWarmQueue']
if __name__=='__main__':
    try:prior.main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
