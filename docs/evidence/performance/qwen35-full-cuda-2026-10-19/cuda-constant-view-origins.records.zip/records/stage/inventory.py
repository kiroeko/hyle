"""Refresh only the retained explicit host-object ABI dependency inventory."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('normalization_inventory',
    ARCH/'cuda-normalization-review/inventory.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
read, objects, rows, output = prior.read, prior.objects, prior.rows, prior.output
BASES = {
    'qwen': ARCH/'cuda-normalization-review/checks/20261019T061424-1fb66e89/qwen-link-plan.json',
    'cuda': ARCH/'cuda-normalization-review/checks/20261019T061424-1fb66e89/cuda-link-plan.json',
    'cpu': ARCH/'cuda-normalization-review/checks/20261019T061224-1bdf98d3/cpu-link-plan.json',
}
CHANGED_HEADERS = [ROOT/name for name in (
    'include/hyle/graph/region_provider.h', 'src/graph/constant_artifact.h',
    'src/graph_provider_ggml_cuda/constant_expressions.h')]
EXPLICIT_SOURCES = [ROOT/name for name in (
    'src/graph/executable.cc', 'src/graph/constant_artifact.cc',
    'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'tests/graph/region_provider_test.cc',
    'tests/graph/constant_artifact_cache_test.cc',
    'tests/graph_provider_ggml_cuda/constant_expression_test.cc')]

def key(path): return str(Path(path).resolve()).casefold()

def link_inputs(command):
    return [Path(arg).resolve() for arg in command if not arg.startswith('/')
            and Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]

def main():
    plans = {name: read(path) for name,path in BASES.items()}
    closure, members = {}, {}
    for name,plan in plans.items():
        inputs = link_inputs(plan['command'])
        missing = [str(path) for path in inputs if not path.is_file()]
        closure[name] = {'path':str(BASES[name]), 'absolute_inputs':len(inputs),
            'objects':sum(p.suffix.lower()=='.obj' for p in inputs), 'missing':missing}
        if missing: raise ValueError('Missing retained '+name+' inputs: '+str(missing))
        if name == 'cpu' and len(inputs) != 111:
            raise ValueError('Use only the pruned 111-input CPU closure')
        for path in objects(plan['command']): members.setdefault(path,[]).append(name)
    metadata = {}
    for parent in sorted({path.parent for path in members}):
        for path in parent.glob('*.json'):
            if path.stat().st_size > 8_000_000: continue
            try: document = read(path)
            except (ValueError,OSError): continue
            for row in rows(document):
                command = row['command']
                if not command or not isinstance(command[0],str): continue
                old = output(command)
                if old: metadata.setdefault(old,(path,command))
    changed = {key(path) for path in CHANGED_HEADERS}
    explicit = {key(path) for path in EXPLICIT_SOURCES}
    result = []
    for path,closures in members.items():
        row = {'object':str(path), 'closures':closures, 'recipe':None,
               'source':None, 'headers':[], 'must_rebuild':False}
        recipe = metadata.get(key(path))
        if recipe:
            origin,command = recipe
            source = [arg for arg in command if arg.lower().endswith(('.cc','.cpp','.cu','.c'))]
            row.update(recipe=str(origin),command=command)
            if len(source) != 1: raise ValueError('Ambiguous recipe source: '+str(origin))
            row['source'] = str(Path(source[0]).resolve())
            sourcedeps = set()
            for index,arg in enumerate(command):
                if arg.lower() == '/sourcedependencies':
                    dep = Path(command[index+1])
                    if dep.is_file():
                        row['sourcedeps'] = str(dep)
                        sourcedeps.update(read(dep).get('Data',{}).get('Includes',[]))
            # Union the old actual includes and today's literal include graph:
            # a newly introduced header cannot appear in an old compiler report.
            literal = prior.local_headers(row['source'],command)
            row['headers'] = sorted({str(Path(p).resolve()) for p in sourcedeps}|set(literal))
            row['dependency_basis'] = 'cached sourceDependencies union current repository literal include traversal'
            touched = sorted({str(Path(h).resolve()) for h in row['headers'] if key(h) in changed})
            row['changed_header_dependencies'] = touched
            row['explicit_source_change'] = key(row['source']) in explicit
            row['must_rebuild'] = bool(touched) or row['explicit_source_change']
            if row['must_rebuild'] and Path(row['source']).suffix.lower() == '.cu':
                raise ValueError('Unexpected native ABI consumer; do not rebuild SDK implicitly')
        result.append(row)
    missing_sources = [str(p) for p in EXPLICIT_SOURCES
        if not any(r['source'] and key(r['source']) == key(p) for r in result)]
    if missing_sources: raise ValueError('Explicit source not in retained closure: '+str(missing_sources))
    value = {'schema':'hyle.immutable_alias.explicit_object_inventory.v1',
        'bases':{k:str(v) for k,v in BASES.items()}, 'closures':closure,
        'changed_headers':[str(p) for p in CHANGED_HEADERS],
        'explicit_sources':[str(p) for p in EXPLICIT_SOURCES], 'objects':result,
        'limitations':'Dependency inventory covers explicit object inputs; retained libraries keep their existing exact owners. Unmapped native-only objects are recorded, never silently rebuilt.',
        'SDK_build':False,'GPU_run':False}
    target = STAGE/'object-inventory.json'
    target.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    for row in result:
        if row['must_rebuild']: print('REBUILD',','.join(row['closures']),row['source'])
    print('CLOSURES',json.dumps(closure),'UNMAPPED',sum(r['recipe'] is None for r in result),
          'HOST_TUS',sum(r['must_rebuild'] for r in result),'INVENTORY',target,flush=True)

if __name__ == '__main__': main()
