"""One original-argument Nsight trace after this exact image's numerical proof.

No performance pairs, baseline relink, downloads or extra inference process.
"""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('immutable_profile_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan',type=Path);args=parser.parse_args()
    path=args.plan.resolve();plan=c.read(path);build=path.parent
    if not c.read(build/'summary.json')['passed']:raise ValueError('Build has not passed')
    proof=c.read(build/'run-qwen/summary.json')
    candidate=Path(plan['links']['qwen']['image']);image=b.b.identity(candidate)
    if image!=c.read(build/'qwen-image.json') or image!=proof['image']:
        raise ValueError('Profile image differs from the exact correctness probe')
    if proof['equal_vectors']!=64 or not proof['same_generated_ids'] or not proof['same_decode_input_ids']:
        raise ValueError('The 64-vector/32-ID numerical proof is incomplete')
    original_path=b.ARCH/'cuda-reshape-reuse/profile-qwen.command.json'
    original=c.read(original_path)['command'];image_index=original.index('--inputs')-1
    stem=STAGE/'profile/qwen-immutable-alias-trace';out=stem.parent
    if any(a in ('--trace','--monitor-memory') for a in original[image_index+1:]):
        raise ValueError('The inherited profile command must not dump vectors or monitor memory')
    out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    command=[('--output='+str(stem)) if a.startswith('--output=') else a
             for a in original[:image_index]]+[str(candidate)]+original[image_index+1:]
    env,_=b.b.environment(plan['links']['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
    c.save(out/'inputs.json',{'image':image,'command':command,
        'original_profile_recipe':b.b.identity(original_path),'correctness_proof':b.b.identity(build/'run-qwen/summary.json'),
        'profiler_runs':1,'performance_pairs':False,'throughput_claim':False})
    c.execute('profile',command,env,out)
    nsys=original[0]
    c.execute('export',[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],env,out)
    c.execute('stats',[nsys,'stats','--report=cuda_gpu_kern_sum,cuda_api_sum','--format=csv',
        '--output='+str(stem),str(stem)+'.nsys-rep'],env,out)
    c.save(out/'summary.json',{'image':image,'trace_stem':str(stem),'terminal':True,
        'profiler_runs':1,'throughput_claim':False})
    print('PROFILE_COMPLETE',stem,flush=True)

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
