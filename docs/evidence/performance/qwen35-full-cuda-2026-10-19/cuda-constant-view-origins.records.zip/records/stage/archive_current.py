"""Preserve current source, exact commands and observations without SDK/object copies."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alias_build', STAGE/'build_current.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c
DEST = b.ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-constant-view-origins.zip'
PRODUCTS = (
    'include/hyle/graph/region_provider.h', 'src/graph/constant_artifact.h',
    'src/graph/constant_artifact.cc', 'src/graph/executable.cc',
    'src/graph_provider_ggml_cuda/constant_expressions.h',
    'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'tests/graph/constant_artifact_cache_test.cc', 'tests/graph/region_provider_test.cc',
    'tests/graph_provider_ggml_cuda/constant_expression_test.cc',
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/implementation/model-operators.md', 'test.ps1')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=('prepare', 'archive'))
    p.add_argument('plan', type=Path)
    args = p.parse_args()
    plan_path = args.plan.resolve()
    if not plan_path.is_relative_to(STAGE/'checks'):
        raise ValueError('Only this stage is eligible')
    plan = c.read(plan_path)
    if not c.read(plan_path.parent/'summary.json')['passed']:
        raise ValueError('Successful current build required')
    if args.mode == 'prepare':
        targets = [b.b.identity(path) for path in (STAGE/'checks').rglob('*')
                   if path.is_file() and path.suffix.lower() in ('.exe','.map','.lib','.exp')]
        c.save(STAGE/'reclaim-targets-current.json', targets)
        c.save(STAGE/'source-freeze-current.json', [b.b.identity(b.ROOT/name) for name in PRODUCTS])
        print('PREPARED', len(targets), 'files', sum(row['bytes'] for row in targets), 'bytes')
        return
    if DEST.exists():
        raise ValueError('Do not overwrite a retained archive')
    suffixes = {'.json','.py','.log','.xml','.csv','.sqlite','.nsys-rep','.bf16','.f32','.tsv','.diff'}
    current_files = {'inventory.py','build_current.py','run_checks.py','profile_current.py',
        'finish_profile.py','finish_fixtures.py',
        'analyze_current_profile.py','archive_current.py','object-inventory.json',
        'tests-before.json','tests-after.json','tests-change.diff','tests-plan.json',
        'profile-analysis-current.json','reclaim-targets-current.json','source-freeze-current.json'}
    payload = {'stage/'+path.relative_to(STAGE).as_posix(): path
        for path in STAGE.rglob('*') if path.is_file() and path.suffix.lower() in suffixes
        and (path.is_relative_to(STAGE/'checks') or path.is_relative_to(STAGE/'profile')
             or (path.parent == STAGE and path.name in current_files))
        and path.name not in ('archive-verification-current.json','reclaim-receipt-current.json')}
    for row in c.read(STAGE/'source-freeze-current.json') + plan['frozen']:
        path = Path(row['path'])
        if not b.b.same(row):
            raise ValueError('Source drift: '+str(path))
        if path.is_relative_to(b.ROOT) and not path.is_relative_to(b.ROOT/'.scratch'):
            payload['source/'+path.relative_to(b.ROOT).as_posix()] = path
    manifest = []
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payload.items()):
            data = path.read_bytes()
            archive.writestr(name, data)
            manifest.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        archive.writestr('manifest.json', json.dumps(manifest, indent=2))
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC mismatch')
        for row in manifest:
            data = archive.read(row['name'])
            if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                raise ValueError('Archive payload mismatch')
    result = dict(b.b.identity(DEST), entries=len(manifest), CRC_and_payload_SHA_verified=True,
        reclaim_manifest=b.b.identity(STAGE/'reclaim-targets-current.json'))
    c.save(STAGE/'archive-verification-current.json', result)
    print(json.dumps(result))

if __name__ == '__main__':
    main()
