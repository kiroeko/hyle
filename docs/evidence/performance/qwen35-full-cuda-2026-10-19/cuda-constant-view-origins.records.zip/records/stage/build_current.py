"""Increment the exact current host ABI closure; default only freezes a dry-run plan.

Run inventory.py first. --build [--plan PATH] compiles selected existing host
owners and links CPU/CUDA/Qwen. No native math, SDK, CMake or dependency copies.
Historical build.py in this directory remains untouched.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('retained_projection_build',ARCH/'cuda-projection-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c

def inputs(command):
    return [arg for arg in command if not arg.startswith('/') and Path(arg).is_absolute()
            and Path(arg).suffix.lower() in ('.obj','.lib')]

def make_plan():
    inventory_path = STAGE/'object-inventory.json'
    inventory = c.read(inventory_path)
    out = STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    compiles, replacements, frozen = [], {}, {}
    for index,row in enumerate(inventory['objects']):
        if not row['must_rebuild']: continue
        source = Path(row['source'])
        if source.suffix.lower() != '.cc': raise ValueError('Only cached C++ host recipes are selected')
        tag = str(index)+'-'+source.parent.name+'-'+source.stem
        command = c.compile_command(row['command'],source,tag,out)
        obj = str(out/(tag+'.obj'))
        if not Path(command[0]).is_file(): raise ValueError('Missing cached compiler')
        if '/W4' not in command or '/WX' not in command:
            raise ValueError('Keep the strict cached host recipe: '+str(source))
        replacements[c.key(row['object'])] = obj
        compiles.append({'tag':tag,'command':command,'object':obj,'source':b.identity(source),
            'old_object':b.identity(row['object']),'basis':b.identity(row['recipe']),
            'closures':row['closures'],'reason':row.get('changed_header_dependencies',[])})
        for path in [source]+[Path(p) for p in row['headers']]:
            if path.is_file() and path.is_relative_to(ROOT):
                frozen[str(path)] = b.identity(path)
        for arg in row['command']:
            if arg.lower().startswith('/fi'):
                path=Path(arg[3:]); frozen[str(path)]=b.identity(path)
    for path in inventory['changed_headers']:
        frozen[path]=b.identity(path)
    links, cached = {}, {}
    for name,base in inventory['bases'].items():
        original = c.read(base)
        old_inputs = inputs(original['command'])
        if name == 'cpu' and len(old_inputs) != 111: raise ValueError('Wrong CPU base closure')
        expected = {c.key(row['path']):row for row in original.get('inputs',[]) if isinstance(row,dict)}
        for arg in old_inputs:
            current = b.identity(arg)
            if c.key(arg) in expected and current != {k:expected[c.key(arg)][k] for k in ('path','bytes','sha256')}:
                raise ValueError('Cached base input identity drift: '+arg)
            cached[arg] = current
        command = [replacements.get(c.key(arg),arg) if not arg.startswith('/') else arg
            for arg in original['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        # Every selected source is already an explicit object owner. In
        # particular constant_expression_test must be replaced, never appended.
        image=out/(name+'.exe')
        command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
                    '/IMPLIB:'+str(image.with_suffix('.lib'))]
        new_inputs=inputs(command)
        if len(new_inputs)!=len(old_inputs): raise ValueError('The input closure grew unexpectedly')
        objs=[c.key(p) for p in new_inputs if Path(p).suffix.lower()=='.obj']
        if len(objs)!=len(set(objs)): raise ValueError('Duplicate explicit object input')
        links[name]={'command':command,'inputs':new_inputs,'image':str(image),
            'absolute_input_count':len(new_inputs),'base':b.identity(base)}
    for old,new in replacements.items():
        for name in next(r['closures'] for r in inventory['objects'] if c.key(r['object'])==old):
            if sum(c.key(p)==c.key(new) for p in links[name]['inputs'])!=1:
                raise ValueError('Expected one exact replacement: '+old)
    env,runtime=b.environment(links['qwen']['command'],list(cached),out)
    sdk=c.sdk_libraries(links['qwen']['command'],env)
    if any(r['resolved'] is None for r in sdk): raise ValueError('Missing named Windows SDK library')
    plan={'schema':'hyle.immutable_alias.host_increment.v1','compile':compiles,'links':links,
        'frozen':list(frozen.values()),'cached_inputs':list(cached.values()),
        'runtime_path_directories':runtime,'named_sdk_libraries':sdk,
        'dependency_inventory':b.identity(inventory_path),'SDK_build':False,'native_math_build':False,
        'CMake_run':False,'dependency_or_object_copy':False,
        'source_freeze':'Exact current snapshots; replan after any product/fixture edit. Rechecked before and after every compiler/link command.'}
    target=out/'plan.json';c.save(target,plan)
    print('PLAN',target,'host_TUs',len(compiles),'inputs',
          {k:len(v['inputs']) for k,v in links.items()},flush=True)
    return target

def check(value):
    for row in value['frozen']+value['cached_inputs']:
        if not b.same(row): raise ValueError('Source/header/object drift: '+row['path'])
    for row in value['compile']:
        if not b.same(row['basis']): raise ValueError('Recipe identity drift')
    for row in value['links'].values():
        if not b.same(row['base']): raise ValueError('Base link plan drift')
    if not b.same(value['dependency_inventory']): raise ValueError('Inventory changed; make a new plan')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',action='store_true');p.add_argument('--plan',type=Path)
    args=p.parse_args();target=args.plan.resolve() if args.plan else make_plan()
    if target.name!='plan.json' or not target.is_relative_to(STAGE/'checks'):
        raise ValueError('Plan must belong to this current stage/checks')
    value=c.read(target);check(value)
    if not args.build:return
    out=target.parent
    if any(out.glob('*.command.json')): raise ValueError('Preserve this attempt; make a new plan for retry')
    (out/'tmp').mkdir(exist_ok=False)
    env,_=b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
    for row in value['compile']:
        check(value);c.execute(row['tag']+'-compile',row['command'],env,out);check(value)
        c.save(out/(row['tag']+'-identity.json'),{'command':row['command'],
            'source':row['source'],'object':b.identity(row['object']),'recipe':row['basis']})
    for name,row in value['links'].items():
        check(value)
        c.save(out/(name+'-link-plan.json'),{'command':row['command'],
            'inputs':[b.identity(arg) for arg in row['inputs']],'base':row['base']})
        c.execute(name+'-link',row['command'],env,out);check(value)
        c.save(out/(name+'-image.json'),b.identity(row['image']))
    c.save(out/'summary.json',{'host_TUs':len(value['compile']),'links':len(value['links']),
        'passed':True,'tests_run':False,'GPU_run':False})
    print('BUILD_COMPLETE',out,flush=True)

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
