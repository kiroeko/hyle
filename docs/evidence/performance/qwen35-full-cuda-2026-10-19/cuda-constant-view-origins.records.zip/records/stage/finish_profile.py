"""Read the completed official SQLite export, without re-running the profiler."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alias_profile_finish', STAGE/'build_current.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
out = STAGE/'profile'
stem = out/'qwen-immutable-alias-trace'
for tag in ('profile','export'):
    if c.read(out/(tag+'.result.json'))['exit'] != 0:
        raise ValueError('The actual trace/export did not complete')
inputs = c.read(out/'inputs.json')
env, _ = b.b.environment(plan['links']['qwen']['command'],
    [row['path'] for row in plan['cached_inputs']], out)
c.execute('stats-sqlite', [inputs['command'][0], 'stats',
    '--report=cuda_gpu_kern_sum,cuda_api_sum','--format=csv',
    '--output='+str(stem), str(stem)+'.sqlite'], env, out)
c.save(out/'summary.json', {'image': inputs['image'], 'trace_stem': str(stem),
    'terminal': True, 'profiler_runs': 1, 'throughput_claim': False,
    'stats_input': 'existing official SQLite export',
    'prior_stats_failure': 'nsys-rep/SQLite modification-time check; retained original failure'})
print('PROFILE_REPORTS_COMPLETE', stem, flush=True)
