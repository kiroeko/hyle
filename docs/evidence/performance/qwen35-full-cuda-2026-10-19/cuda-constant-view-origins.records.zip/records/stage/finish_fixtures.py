"""Refresh only two CPU fixtures and relink CPU; retain Qwen/CUDA images.

Default writes a dry-run plan. --build [--plan PATH] performs the two cached
compiles and one CPU link. First-attempt failures and successful images remain.
"""
from pathlib import Path
import argparse
import copy
import datetime as dt
import importlib.util
import sys
import uuid

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('immutable_fixture_build',STAGE/'build_current.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
b,c=d.b,d.c
BASE=STAGE/'checks/20261019T063301-1d108b74/plan.json'
FIXTURES={c.key(d.ROOT/name) for name in (
    'tests/graph/region_provider_test.cc',
    'tests/graph/constant_artifact_cache_test.cc')}

def make_plan():
    old=c.read(BASE);first=BASE.parent
    if not c.read(first/'summary.json')['passed']:
        raise ValueError('The original 19-host build/link did not finish')
    for row in old['frozen']+old['cached_inputs']:
        if c.key(row['path']) not in FIXTURES and not b.same(row):
            raise ValueError('Non-fixture source/header/input drift: '+row['path'])
    for row in old['compile']:
        receipt=c.read(first/(row['tag']+'-identity.json'))
        if not b.same(receipt['object']):raise ValueError('Successful first-build object drift')
    stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]
    out=STAGE/'checks'/stamp;out.mkdir(parents=True,exist_ok=False)
    compiles=[];replacements={}
    for row in old['compile']:
        if c.key(row['source']['path']) not in FIXTURES:continue
        tag='fixture-'+Path(row['source']['path']).stem
        obj=str(out/(tag+'.obj'))
        basis=first/(row['tag']+'-identity.json')
        compiles.append({'tag':tag,'command':c.compile_command(row['command'],
            Path(row['source']['path']),tag,out),'object':obj,
            'source':b.identity(row['source']['path']),'old_object':b.identity(row['object']),
            'basis':b.identity(basis),'closures':['cpu']})
        replacements[c.key(row['object'])]=obj
    if len(compiles)!=2:raise ValueError('Expected exactly two existing CPU fixture objects')
    links={};cached={};reused={}
    for name in ('qwen','cuda','cpu'):
        base=first/(name+'-link-plan.json');original=c.read(base)
        for row in original['inputs']:
            if not b.same(row):raise ValueError('First-build closure drift: '+row['path'])
        if name=='cpu':
            command=[replacements.get(c.key(arg),arg) if not arg.startswith('/') else arg
                for arg in original['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
            image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
                '/IMPLIB:'+str(image.with_suffix('.lib'))]
        else:
            command=original['command'];image=Path(old['links'][name]['image'])
            reused[name]=c.read(first/(name+'-image.json'))
            if b.identity(image)!=reused[name]:raise ValueError('Retained image identity differs')
        current_inputs=d.inputs(command)
        if len(current_inputs)!=len(original['inputs']):raise ValueError('Unexpected closure growth')
        for arg in current_inputs:
            if c.key(arg) not in {c.key(v) for v in replacements.values()}:
                cached[arg]=b.identity(arg)
        links[name]={'command':command,'inputs':current_inputs,'image':str(image),
            'absolute_input_count':len(current_inputs),'base':b.identity(base)}
    for new in replacements.values():
        if links['cpu']['inputs'].count(new)!=1:raise ValueError('Fixture object must replace exactly one owner')
    value=copy.deepcopy(old)
    value.update(schema='hyle.immutable_alias.fixture_finish.v1',compile=compiles,links=links,
        frozen=[b.identity(r['path']) if c.key(r['path']) in FIXTURES else r for r in old['frozen']],
        cached_inputs=list(cached.values()),original_successful_build=b.identity(BASE),
        reused_images=reused,fixture_only_changes=True,product_and_ABI_unchanged=True,
        retained_failure=str(first/'run-cpu/tests.result.json'))
    target=out/'plan.json';c.save(target,value)
    print('PLAN',target,'host_TUs',len(compiles),'CPU_link_only',True,flush=True)
    return target

def check(value):
    d.check(value)
    if not b.same(value['original_successful_build']):raise ValueError('Original build plan drift')
    for name,image in value['reused_images'].items():
        if not b.same(image):raise ValueError('Reused '+name+' image drift')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true');parser.add_argument('--plan',type=Path)
    args=parser.parse_args();target=args.plan.resolve() if args.plan else make_plan()
    if target.name!='plan.json' or not target.is_relative_to(STAGE/'checks'):
        raise ValueError('Plan must be inside this stage/checks')
    value=c.read(target);check(value)
    if not args.build:return
    out=target.parent
    if any(out.glob('*.command.json')):raise ValueError('Keep this attempt; generate a new plan to retry')
    (out/'tmp').mkdir(exist_ok=False)
    env,_=b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
    for row in value['compile']:
        check(value);c.execute(row['tag']+'-compile',row['command'],env,out);check(value)
        c.save(out/(row['tag']+'-identity.json'),{'command':row['command'],
            'source':row['source'],'object':b.identity(row['object']),'recipe':row['basis']})
    row=value['links']['cpu'];check(value)
    c.save(out/'cpu-link-plan.json',{'command':row['command'],
        'inputs':[b.identity(arg) for arg in row['inputs']],'base':row['base']})
    c.execute('cpu-link',row['command'],env,out);check(value)
    c.save(out/'cpu-image.json',b.identity(row['image']))
    for name,image in value['reused_images'].items():
        c.save(out/(name+'-image.json'),image)  # JSON only; no image/object copy.
        original=c.read(value['links'][name]['base']['path'])
        c.save(out/(name+'-link-plan.json'),original)
    c.save(out/'summary.json',{'passed':True,'host_TUs':2,'links':1,'tests_run':False,
        'reused_images':value['reused_images'],'reused_qwen_cuda_sources_unchanged':True,
        'product_and_ABI_unchanged':True,'retained_failure':value['retained_failure'],'GPU_run':False})
    print('FIXTURES_BUILT',out,flush=True)

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
