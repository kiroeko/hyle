#pragma once

#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <expected>
#include <limits>
#include <mutex>
#include <new>
#include <type_traits>
#include <utility>

#include "hyle/core/compiler.h"
#include "hyle/error/result.h"
#include "hyle/error/status.h"
#include "hyle/mem/allocator.h"
#include "hyle/core/environment.h" // HYLE_OS_WINDOWS (Mutex backend split)
#include "hyle/sched/waker.h"
#include "hyle/time/clock.h"
#include "hyle/util/spin_lock.h"
#include "hyle/visibility.h"

// Scheduler synchronization primitives. Long waits use the common wake spine;
// Mutex deliberately remains a short-section OS-thread lock.
//
// WHY they exist: a std::mutex / std::condition_variable blocks the WORKER OS
// THREAD. On an M:N scheduler that strands every OTHER fiber pinned to that
// core
// -- the whole point of fibers is defeated. The fix is "on contention, YIELD
// the fiber (it leaves the run loop), and on release RE-INJECT it" -- which is
// just another completion/wake through the same Waker spine.
//
// Convergence (marl's lesson, adopted): do NOT write a bespoke wake mechanism
// for waitgroup / channel / latch / event. Build ONE fiber-aware
// ConditionVariable and layer long-wait facilities on it. Mutex is not a
// long-wait facility and uses the platform lock path described below.
//
// Dual-mode (REQUIRED, not optional): a waiter may be a fiber (yield +
// re-inject) OR a bare OS thread (fall back to platform::Parker). HYLE's
// cross-process federation and external-thread submission paths hand work to
// the scheduler from threads that are NOT fibers; assuming "all waiters are
// fibers" would deadlock them. The CV picks the mode per-wait from whether it
// runs inside a worker fiber.
//
// TIMED WAITS (wait_for/wait_until): a bare
// (non-fiber) waiter parks with a bounded platform::Parker::park_for and
// retracts its own node on the deadline; the notify-vs-timeout race is
// arbitrated under the CV monitor lock via the node's `linked` flag (whoever
// acts first wins, the loser reports the other's outcome so no wake is lost).
// This covers external submitters and cross-process federation threads.
//
// Fiber mode uses the per-worker timer queue plus a per-episode temporary pin:
// notify and timer arbitrate through one atomic winner byte; the winning wake
// returns to the queue owner, where a still-armed loser timer is cancelled
// O(1). This mirrors folly fibers Baton (atomic timeout-vs-post arbitration)
// without a cross-worker timer mutation.

namespace hyle::time {
class TimerEntry;
}

namespace hyle::sched {

// The common fiber-aware long-wait primitive; the long-wait/message facilities
// below build on it. Mutex is the deliberate exception: it is a short-section
// OS-thread lock, documented separately below. Mirrors
// std::condition_variable_any: wait() takes ANY BasicLockable (the monitor
// lock), releases it while blocked, and re-acquires it before returning (Mesa
// semantics -- always re-check the predicate in a loop).
//
// API macro is on the methods, not the class: the SpinLock member holds a
// std::atomic, so exporting the whole class would drag it across the DLL seam
// (MSVC C4251). Method-level export keeps the layout client-side (same pattern
// as Fiber / Parker / Scheduler).
class ConditionVariable {
public:
  ConditionVariable() noexcept = default;
  ConditionVariable(const ConditionVariable &) = delete;
  ConditionVariable &operator=(const ConditionVariable &) = delete;
  ConditionVariable(ConditionVariable &&) = delete;
  ConditionVariable &operator=(ConditionVariable &&) = delete;

  // Atomically release `lock` and block until notified, then re-acquire `lock`.
  // Precondition: the caller holds `lock`. Spurious wakeups are possible only
  // via the predicate overload; the bare overload returns exactly once per
  // notify.
  template <class Lock> void wait(Lock &lock) {
    Waiter node;
    const bool fiber = prepare_wait_(&node); // enqueue under internal lock
    lock.unlock();                           // release the monitor lock
    finish_wait_(fiber, node.token);         // fiber: suspend(); thread: park()
    lock.lock();                             // re-acquire before returning
  }

  // Wait until `stop()` holds, immune to spurious/lost wakeups (the standard
  // predicate loop). `stop` is evaluated with `lock` held.
  template <class Lock, class Pred> void wait(Lock &lock, Pred stop) {
    while (!stop())
      wait(lock);
  }

  // Timed wait. Atomically release `lock` and block until notified
  // OR `timeout` elapses, then re-acquire `lock`. Returns whether it returned
  // because of the timeout. Deadline keys on time::MonotonicClock.
  //
  // Bare threads use Parker::park_for. Fibers arm their current worker's
  // timer queue and are temporarily pinned to that worker for this wait
  // episode, so the notify winner resumes on the queue owner and cancels in
  // O(1). An atomic winner state prevents timer+notify from waking the same
  // episode twice.
  enum class CvStatus { kNoTimeout, kTimeout };

  template <class Lock> CvStatus wait_for(Lock &lock, time::Duration timeout) {
    Waiter node;
    const bool fiber = prepare_wait_(&node);
    lock.unlock();
    const CvStatus st = fiber ? finish_wait_timed_fiber_(&node, timeout)
                              : finish_wait_timed_(&node, timeout);
    lock.lock();
    return st;
  }

  // Predicate form: loops re-checking `stop()` until it holds or the deadline
  // passes. Returns stop() -- true if the condition was met, false on timeout.
  // Recomputes the remaining time each iteration so spurious wakes don't extend
  // the total wait (deadline captured once from now + timeout).
  template <class Lock, class Pred>
  bool wait_for(Lock &lock, time::Duration timeout, Pred stop) {
    return wait_until(lock, time::deadline_after(timeout), stop);
  }

  // Absolute monotonic deadline variants, mirroring std::cv wait_until without
  // accepting wall-clock time points.
  template <class Lock>
  CvStatus wait_until(Lock &lock, time::MonotonicTimePoint deadline) {
    return wait_for(lock, time::remaining(deadline));
  }

  template <class Lock, class Pred>
  bool wait_until(Lock &lock, time::MonotonicTimePoint deadline, Pred stop) {
    while (!stop()) {
      if (wait_until(lock, deadline) == CvStatus::kTimeout) {
        return stop(); // last check: the predicate may have become true at the
                       // wire
      }
    }
    return true;
  }

  // Wake one / all blocked waiters. Safe to call from any thread or fiber. The
  // caller should hold whatever lock guards the predicate the waiters test (so
  // a state change + notify is not split by a sleeping waiter -- classic
  // monitor discipline); notify itself takes only the CV's own internal lock.
  // Fast-path: when no waiter is parked, returns without touching the internal
  // lock (the `waiters_` count is published under the monitor lock by a parking
  // waiter, so a notifier holding that same monitor lock sees a non-zero count
  // -- no missed wake). This is what keeps an uncontended Mutex::unlock cheap.
  HYLE_SCHED_API void notify_one() noexcept;
  HYLE_SCHED_API void notify_all() noexcept;

private:
  // One waiter, allocated on the blocking fiber/thread's own stack and linked
  // into the FIFO list while parked. `waker` names the fiber to re-inject
  // (valid iff fiber-mode); `token` points at a thread-local park token
  // (non-null iff thread-mode). Fields are read by the notifier under the
  // internal lock BEFORE the waiter is woken (after which the node may be
  // destroyed). The list is DOUBLY linked so a timed-out waiter can unlink
  // itself in O(1) (it holds its own node but not its predecessor); `linked`
  // makes that removal idempotent against a concurrent notify that already
  // popped it.
  struct Waiter {
    Waiter *next;
    Waiter *prev;
    Waker waker;
    void *token;
    bool linked; // true while in the list; guarded by mu_
    // 0 waiting, 1 notify won, 2 timeout won. Used only by fiber timed waits.
    std::atomic<unsigned char> timed_state{0};
    bool fiber_timed = false;
  };
  struct TimedContext {
    ConditionVariable *cv;
    Waiter *node;
  };

  // Capture mode (fiber vs thread), set up `node`, and link it onto the FIFO
  // tail under the internal lock. Returns true iff this is a fiber waiter. Must
  // run while the caller still holds the monitor lock (closes the lost-wakeup
  // window).
  HYLE_SCHED_API bool prepare_wait_(Waiter *node) noexcept;

  // Block until woken: fiber -> suspend() (leaves the run loop, re-injected by
  // the Waker); thread -> park() loop on the thread-local token.
  HYLE_SCHED_API static void finish_wait_(bool fiber, void *token) noexcept;

  // Timed thread-mode block: park the OS thread with a bounded park_for
  // until the node's token is notified or the deadline elapses. On timeout it
  // retracts `node` from the list (remove_waiter_) so a later notify can't pop
  // a dead node. Returns whether it timed out. (Out-of-line: pulls in time/ +
  // platform futex, kept out of this header.)
  HYLE_SCHED_API CvStatus finish_wait_timed_(Waiter *node,
                                             time::Duration timeout) noexcept;
  HYLE_SCHED_API CvStatus
  finish_wait_timed_fiber_(Waiter *node, time::Duration timeout) noexcept;
  HYLE_SCHED_API static void
  timed_fiber_fire_(hyle::time::TimerEntry *entry) noexcept;

  // Unlink `node` from the list if still linked (idempotent). Caller must hold
  // mu_. Used by a timed waiter that woke on its deadline before a notify
  // reached it -- it retracts its own node so a later notify can't pop a dead
  // stack node.
  HYLE_SCHED_API void remove_waiter_(Waiter *node) noexcept;

  util::SpinLock mu_;      // guards the waiter list (tiny critical sections)
  Waiter *head_ = nullptr; // FIFO: notify pops head
  Waiter *tail_ = nullptr; // FIFO: prepare_wait appends here
  // Count of parked waiters, so notify can skip the lock when none. Mutated
  // under mu_ (++ in prepare_wait_, -= when popped by notify); read lock-free
  // on the notify fast-path. Correctness rests on the monitor-lock handoff, not
  // on this count alone (the under-lock head_ check is still authoritative).
  std::atomic<int> waiters_{0};
};

// ---- Mutex ------------------------------------------------------------------
// A futex-based mutex (Drepper's 3-state lock), built on HYLE's own
// platform::wait_on_address (futex / WaitOnAddress / __ulock) -- NOT on the
// fiber CV. Uncontended lock/unlock is a single atomic CAS, matching std::mutex
// / marl (which is std::mutex). On contention the WORKER thread parks on the
// futex word; it does NOT yield the fiber.
//
// WHY not fiber-aware (this is the SOTA call, learned from marl): a mutex
// guards SHORT critical sections. Yielding the fiber (suspend + re-inject,
// ~100ns of context switch) is far costlier than briefly parking on a futex
// while the holder -- running on another worker -- finishes its few-instruction
// section. marl deliberately keeps its mutex == std::mutex for exactly this
// reason; an earlier fiber-aware HYLE Mutex measured 5.8x SLOWER than marl on
// contention. For genuinely LONG / cross-yield waits, use ConditionVariable
// (fiber-aware) -- that is where yielding pays off. Contract (same as
// marl/std): do not hold a Mutex across a blocking call or a fiber yield; use a
// CV for that.
//
// state_: 0 = unlocked, 1 = locked (no waiters), 2 = locked (waiters possible).
// Satisfies BasicLockable/Lockable (composes with std::lock_guard).
//
// PLATFORM SPLIT (2026-07-03, measured): on Windows the contended lock
// delegates to the OS SRWLOCK -- the SAME primitive std::mutex/marl use, and
// measured 2.66x FASTER than a hand-rolled Drepper futex over WaitOnAddress
// under contention (SRWLOCK has kernel-assisted adaptive spinning;
// WaitOnAddress park is heavier, and a userspace pre-park spin can't be used
// over an M:N fiber scheduler -- it burns the worker thread the lock holder's
// fiber may be queued on). On Linux the Drepper futex over the futex syscall
// matches glibc (measured a statistical tie vs marl/std::mutex, so no OS-lock
// win to chase there). SRWLOCK is pointer-sized and zero-init (==
// SRWLOCK_INIT), stored opaquely here as void* and cast in the .cc so this
// header pulls in no <windows.h>.
//
// macOS falls in the #else (Drepper futex over os_sync_wait_on_address, which
// is correct + works). macOS has os_unfair_lock (its SRWLOCK-equivalent fast OS
// lock)
// -- a likely win there too, but UNMEASURED (no mac to bench), so not added:
// adding an untested platform branch would violate "write+verify". Revisit with
// a mac.
#if HYLE_OS_WINDOWS
class Mutex {
public:
  Mutex() noexcept = default;
  Mutex(const Mutex &) = delete;
  Mutex &operator=(const Mutex &) = delete;
  Mutex(Mutex &&) = delete;
  Mutex &operator=(Mutex &&) = delete;

  // All out-of-line: SRWLOCK's own acquire/release ARE function calls (same as
  // std::mutex, which wraps AcquireSRWLockExclusive) -- so this is
  // apples-to-apples.
  HYLE_SCHED_API void lock() noexcept;
  HYLE_SCHED_API bool try_lock() noexcept;
  HYLE_SCHED_API void unlock() noexcept;

private:
  void *srw_ = nullptr; // RTL_SRWLOCK{PVOID Ptr}; nullptr == SRWLOCK_INIT
};
#else
class Mutex {
public:
  Mutex() noexcept = default;
  Mutex(const Mutex &) = delete;
  Mutex &operator=(const Mutex &) = delete;
  Mutex(Mutex &&) = delete;
  Mutex &operator=(Mutex &&) = delete;

  void lock() noexcept {
    std::uint32_t expected = 0;
    // Fast path: claim a free lock with one CAS (0 -> 1).
    if (!state_.compare_exchange_strong(expected, 1, std::memory_order_acquire,
                                        std::memory_order_relaxed)) {
      lock_slow(expected); // contended: mark waiters + futex-park
    }
  }

  bool try_lock() noexcept {
    std::uint32_t expected = 0;
    return state_.compare_exchange_strong(
        expected, 1, std::memory_order_acquire, std::memory_order_relaxed);
  }

  void unlock() noexcept {
    // Publish unlocked in one RMW.  The old Drepper fetch_sub(2 -> 1) followed
    // by unlock_slow's store(0) performed two writes on every contended
    // handoff; exchange keeps the same 0/1/2 protocol with one cache-line
    // transition.
    if (state_.exchange(0, std::memory_order_release) == 2) {
      unlock_slow();
    }
  }

private:
  // Out-of-line so the header carries no futex dependency; the hot path above
  // is pure inline atomics.
  HYLE_SCHED_API void lock_slow(std::uint32_t c) noexcept;
  HYLE_SCHED_API void unlock_slow() noexcept;

  std::atomic<std::uint32_t> state_{0};
};
#endif

// ---- WaitGroup --------------------------------------------------------------
// Go-style "wait until N tasks have finished". add(n) before spawning, done()
// per finished task, wait() blocks (fiber-aware) until the count hits zero.
class WaitGroup {
public:
  WaitGroup() noexcept = default;
  explicit WaitGroup(long initial) noexcept : count_(initial) {
    HYLE_FATAL_ASSERT(initial >= 0);
  }
  WaitGroup(const WaitGroup &) = delete;
  WaitGroup &operator=(const WaitGroup &) = delete;
  WaitGroup(WaitGroup &&) = delete;
  WaitGroup &operator=(WaitGroup &&) = delete;

  bool try_add(long n = 1) noexcept {
    // add is the uncommon control-plane operation and remains serialized with
    // wait's predicate check. done() is the data-plane operation: all non-final
    // completions avoid this lock.
    mu_.lock();
    const long count = count_.load(std::memory_order_relaxed);
    if (n < 0 || count > (std::numeric_limits<long>::max)() - n) {
      mu_.unlock();
      return false;
    }
    count_.store(count + n, std::memory_order_release);
    mu_.unlock();
    return true;
  }

  void add(long n = 1) noexcept { HYLE_FATAL_ASSERT(try_add(n)); }

  bool try_done() noexcept {
    long count = count_.load(std::memory_order_acquire);
    do {
      if (count <= 0)
        return false;
    } while (!count_.compare_exchange_weak(count, count - 1,
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire));
    if (count == 1) {
      // Pair with wait's predicate-check + waiter publication under mu_. Taking
      // the lock only on 1 -> 0 prevents a final completion from notifying in
      // the gap between the waiter's check and ConditionVariable::wait linking
      // its node, without charging every preceding done() for that lock.
      mu_.lock();
      mu_.unlock();
      cv_.notify_all();
    }
    return true;
  }

  void done() noexcept { HYLE_FATAL_ASSERT(try_done()); }

  void wait() noexcept {
    mu_.lock();
    while (count_.load(std::memory_order_acquire) > 0)
      cv_.wait(mu_);
    mu_.unlock();
  }

private:
  util::SpinLock mu_;
  ConditionVariable cv_;
  std::atomic<long> count_{0};
};

// ---- Latch ------------------------------------------------------------------
// One-shot countdown (std::latch shape). Constructed with a count; count_down()
// decrements; wait() blocks (fiber-aware) until it reaches zero. Unlike
// WaitGroup, the count only ever goes down -- no add().
class Latch {
public:
  explicit Latch(long count) noexcept : count_(count) {
    HYLE_FATAL_ASSERT(count >= 0);
  }
  Latch(const Latch &) = delete;
  Latch &operator=(const Latch &) = delete;
  Latch(Latch &&) = delete;
  Latch &operator=(Latch &&) = delete;

  bool try_count_down(long n = 1) noexcept {
    long count = count_.load(std::memory_order_acquire);
    do {
      if (n < 0 || count < n)
        return false;
    } while (!count_.compare_exchange_weak(count, count - n,
                                           std::memory_order_acq_rel,
                                           std::memory_order_acquire));
    if (count == n) {
      mu_.lock();
      mu_.unlock();
      cv_.notify_all();
    }
    return true;
  }

  void count_down(long n = 1) noexcept { HYLE_FATAL_ASSERT(try_count_down(n)); }

  bool try_wait() const noexcept {
    return count_.load(std::memory_order_acquire) == 0;
  }

  void wait() noexcept {
    mu_.lock();
    while (count_.load(std::memory_order_acquire) > 0)
      cv_.wait(mu_);
    mu_.unlock();
  }

  void arrive_and_wait(long n = 1) noexcept {
    count_down(n);
    wait();
  }

private:
  mutable util::SpinLock mu_;
  ConditionVariable cv_;
  std::atomic<long> count_;
};

// ---- Event ------------------------------------------------------------------
// Binary notification state for one-shot readiness and repeated control-plane
// signals. Auto-reset releases one waiter per signal and consumes the signal;
// manual-reset releases all waiters and remains signalled until reset(). This
// is the fiber-aware equivalent of Marl Event / Win32 event semantics.
enum class EventResetMode : std::uint8_t {
  kAuto = 0,
  kManual = 1,
};

class Event {
public:
  explicit Event(EventResetMode mode = EventResetMode::kAuto,
                 bool signaled = false) noexcept
      : mode_(mode), signaled_(signaled) {
    HYLE_FATAL_ASSERT(mode == EventResetMode::kAuto ||
                      mode == EventResetMode::kManual);
  }
  Event(const Event &) = delete;
  Event &operator=(const Event &) = delete;
  Event(Event &&) = delete;
  Event &operator=(Event &&) = delete;

  HYLE_SCHED_API void signal() noexcept;
  HYLE_SCHED_API void reset() noexcept;
  HYLE_SCHED_API bool is_signaled() const noexcept;
  HYLE_SCHED_API void wait() noexcept;
  HYLE_SCHED_API bool wait_for(time::Duration timeout) noexcept;
  HYLE_SCHED_API bool wait_until(time::MonotonicTimePoint deadline) noexcept;

private:
  mutable util::SpinLock mu_;
  ConditionVariable cv_;
  EventResetMode mode_;
  bool signaled_;
};

// ---- Barrier ----------------------------------------------------------------
// Fixed-participant reusable phase barrier. arrive_and_wait() returns true to
// exactly one participant (the phase completer), which is useful for rotating
// shared inference scratch or publishing phase statistics without a second
// election. arrive_and_drop() permanently removes one participant after its
// arrival in the current phase.
class Barrier {
public:
  explicit Barrier(std::size_t participants) noexcept
      : expected_(participants), remaining_(participants) {
    HYLE_FATAL_ASSERT(participants > 0);
  }
  Barrier(const Barrier &) = delete;
  Barrier &operator=(const Barrier &) = delete;
  Barrier(Barrier &&) = delete;
  Barrier &operator=(Barrier &&) = delete;

  HYLE_SCHED_API bool arrive_and_wait() noexcept;
  HYLE_SCHED_API void arrive_and_drop() noexcept;
  HYLE_SCHED_API std::size_t participants() const noexcept;

private:
  mutable util::SpinLock mu_;
  ConditionVariable cv_;
  std::size_t expected_;
  std::size_t remaining_;
  std::size_t generation_ = 0;
};

// ---- Channel ----------------------------------------------------------------
// Bounded MPMC channel of T, fiber-aware on both ends. Producers block (yield)
// when full, consumers when empty, via two CVs over one SpinLock + a ring
// buffer. close() wakes everyone: subsequent send() fails, recv() drains then
// fails.
//
// The queue performs value construction while holding its monitor. Requiring a
// non-throwing move and destructor is therefore part of the concurrency
// contract, not a benchmark restriction: an exception escaping that critical
// section would strand every waiter behind a permanently-held SpinLock. The
// output-parameter overloads additionally require non-throwing move assignment;
// the value-returning overloads support move-construct-only values.
namespace detail {

template <class T>
concept ChannelValue = std::is_nothrow_move_constructible_v<T> &&
                       std::is_nothrow_destructible_v<T>;

template <class T>
concept OneshotValue = ChannelValue<T>;

template <class T>
concept WatchValue = ChannelValue<T> && std::is_nothrow_move_assignable_v<T> &&
                     std::is_copy_constructible_v<T>;

template <class T>
concept BroadcastValue = WatchValue<T>;

} // namespace detail

enum class ChannelSendFailure : std::uint8_t {
  kFull,
  kTimeout,
  kClosed,
  kInvalid,
};

// Failed admission always returns ownership of the caller's value. A producer
// can retry, reroute or drop deliberately instead of losing a message merely
// because a bounded try/timed send did not win capacity.
template <detail::ChannelValue T> class ChannelSendError {
public:
  ChannelSendError(ChannelSendFailure reason, T value) noexcept
      : reason_(reason), value_(std::move(value)) {}

  ChannelSendFailure reason() const noexcept { return reason_; }
  T &value() & noexcept { return value_; }
  const T &value() const & noexcept { return value_; }
  T &&value() && noexcept { return std::move(value_); }
  Status status() const noexcept {
    switch (reason_) {
    case ChannelSendFailure::kFull:
      return Status(StatusCode::Unavailable);
    case ChannelSendFailure::kTimeout:
      return Status(StatusCode::DeadlineExceeded);
    case ChannelSendFailure::kClosed:
      return Status(StatusCode::Cancelled);
    case ChannelSendFailure::kInvalid:
      return Status(StatusCode::ResourceExhausted);
    }
    HYLE_UNREACHABLE();
  }

private:
  ChannelSendFailure reason_;
  T value_;
};

template <detail::ChannelValue T>
using ChannelSendResult = std::expected<void, ChannelSendError<T>>;

// Storage comes from the injected allocator (charter: no hidden heap). Built on
// the same CV foundation -- demonstrates it composes.
template <detail::ChannelValue T> class Channel {
public:
  enum class RecvStatus { kValue, kEmptyOrTimeout, kClosed };

  Channel(mem::AllocatorRef alloc, std::size_t capacity)
      : alloc_(alloc) {
    Status status;
    init_(capacity, &status);
    HYLE_FATAL_ASSERT(status.ok());
  }

  // Recoverable construction for untrusted capacity or allocator exhaustion.
  // On failure status is non-OK and valid()==false; the object remains safely
  // destructible and operations return typed errors.
  Channel(mem::AllocatorRef alloc, std::size_t capacity, Status *status) noexcept
      : alloc_(alloc) {
    init_(capacity, status);
  }

  ~Channel() {
    if (buf_ == nullptr)
      return;
    while (size_ > 0) { // destroy anything still buffered
      buf_[head_].~T();
      head_ = (head_ + 1) % cap_;
      --size_;
    }
    alloc_.deallocate(buf_, sizeof(T) * cap_, alignof(T));
  }

  Channel(const Channel &) = delete;
  Channel &operator=(const Channel &) = delete;
  Channel(Channel &&) = delete;
  Channel &operator=(Channel &&) = delete;

  // A recoverably-constructed channel may be invalid. Check once after
  // construction; send/recv also fail safely.
  bool valid() const noexcept { return buf_ != nullptr; }

  // Enqueue `v`, blocking the fiber while the buffer is full. Every failure
  // returns the unsent value in ChannelSendError.
  ChannelSendResult<T> send(T v) noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kInvalid, std::move(v)));
    mu_.lock();
    while (size_ == cap_ && !closed_)
      not_full_.wait(mu_);
    if (closed_) {
      mu_.unlock();
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kClosed, std::move(v)));
    }
    new (&buf_[tail_]) T(std::move(v));
    tail_ = (tail_ + 1) % cap_;
    ++size_;
    mu_.unlock();
    not_empty_.notify_one();
    return {};
  }

  ChannelSendResult<T> try_send(T v) noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kInvalid, std::move(v)));
    mu_.lock();
    if (closed_) {
      mu_.unlock();
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kClosed, std::move(v)));
    }
    if (size_ == cap_) {
      mu_.unlock();
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kFull, std::move(v)));
    }
    new (&buf_[tail_]) T(std::move(v));
    tail_ = (tail_ + 1) % cap_;
    ++size_;
    mu_.unlock();
    not_empty_.notify_one();
    return {};
  }

  ChannelSendResult<T> send_for(T v, time::Duration timeout) noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kInvalid, std::move(v)));
    mu_.lock();
    const bool ready = not_full_.wait_for(
        mu_, timeout, [&] { return size_ != cap_ || closed_; });
    if (closed_) {
      mu_.unlock();
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kClosed, std::move(v)));
    }
    if (!ready) {
      mu_.unlock();
      return std::unexpected(
          ChannelSendError(ChannelSendFailure::kTimeout, std::move(v)));
    }
    new (&buf_[tail_]) T(std::move(v));
    tail_ = (tail_ + 1) % cap_;
    ++size_;
    mu_.unlock();
    not_empty_.notify_one();
    return {};
  }

  // Dequeue a value, blocking the fiber while empty. Cancelled means the
  // channel is closed and drained; ResourceExhausted means construction had
  // failed (the latter can also be checked once via valid()). Moving the result
  // does not hold the channel lock.
  Result<T> recv() noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          Status::ResourceExhausted("channel storage allocation failed"));
    mu_.lock();
    while (size_ == 0 && !closed_)
      not_empty_.wait(mu_);
    if (size_ == 0) { // closed and drained
      mu_.unlock();
      return std::unexpected(Status::Cancelled("channel closed"));
    }
    T out(std::move(buf_[head_]));
    buf_[head_].~T();
    head_ = (head_ + 1) % cap_;
    --size_;
    mu_.unlock();
    not_full_.notify_one();
    return out;
  }

  Result<T> try_recv() noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          Status::ResourceExhausted("channel storage allocation failed"));
    mu_.lock();
    if (size_ == 0) {
      const bool closed = closed_;
      mu_.unlock();
      return std::unexpected(closed ? Status::Cancelled("channel closed")
                                    : Status::NotFound("channel empty"));
    }
    T out(std::move(buf_[head_]));
    buf_[head_].~T();
    head_ = (head_ + 1) % cap_;
    --size_;
    mu_.unlock();
    not_full_.notify_one();
    return out;
  }

  Result<T> recv_for(time::Duration timeout) noexcept {
    if (buf_ == nullptr)
      return std::unexpected(
          Status::ResourceExhausted("channel storage allocation failed"));
    mu_.lock();
    const bool ready = not_empty_.wait_for(
        mu_, timeout, [&] { return size_ != 0 || closed_; });
    if (size_ == 0) {
      const bool closed = closed_;
      mu_.unlock();
      return std::unexpected(
          closed ? Status::Cancelled("channel closed")
                 : Status::DeadlineExceeded("channel receive timeout"));
    }
    HYLE_FATAL_ASSERT(ready);
    T out(std::move(buf_[head_]));
    buf_[head_].~T();
    head_ = (head_ + 1) % cap_;
    --size_;
    mu_.unlock();
    not_full_.notify_one();
    return out;
  }

  // Reuse caller-owned storage when that is useful on a hot path. These are
  // adapters over the natural value-returning API, so value assignment happens
  // after the monitor is released.
  bool recv(T &out) noexcept
    requires std::is_nothrow_move_assignable_v<T>
  {
    auto result = recv();
    if (!result)
      return false;
    out = std::move(*result);
    return true;
  }

  RecvStatus try_recv(T &out) noexcept
    requires std::is_nothrow_move_assignable_v<T>
  {
    auto result = try_recv();
    if (result) {
      out = std::move(*result);
      return RecvStatus::kValue;
    }
    return result.error().IsNotFound() ? RecvStatus::kEmptyOrTimeout
                                       : RecvStatus::kClosed;
  }

  RecvStatus recv_for(T &out, time::Duration timeout) noexcept
    requires std::is_nothrow_move_assignable_v<T>
  {
    auto result = recv_for(timeout);
    if (result) {
      out = std::move(*result);
      return RecvStatus::kValue;
    }
    return result.error().IsDeadlineExceeded() ? RecvStatus::kEmptyOrTimeout
                                               : RecvStatus::kClosed;
  }

  // Close the channel: wakes all blocked senders/receivers. Idempotent.
  void close() {
    if (buf_ == nullptr)
      return;
    mu_.lock();
    closed_ = true;
    mu_.unlock();
    not_empty_.notify_all();
    not_full_.notify_all();
  }

private:
  void init_(std::size_t capacity, Status *status) noexcept {
    HYLE_FATAL_ASSERT(status != nullptr);
    *status = Status{};
    if (!alloc_.valid()) {
      *status =
          Status::InvalidArgument("channel requires a complete allocator");
      return;
    }
    if (capacity == 0 ||
        capacity >
            (std::numeric_limits<std::size_t>::max)() / sizeof(T)) {
      *status = Status::InvalidArgument("invalid channel capacity");
      return;
    }
    cap_ = capacity;
    buf_ = static_cast<T *>(alloc_.allocate(sizeof(T) * cap_, alignof(T)));
    if (buf_ == nullptr) {
      *status = Status::ResourceExhausted(
          "channel storage allocation failed");
    }
  }

  mem::AllocatorRef alloc_;
  util::SpinLock mu_;           // guards the ring + closed_ (short holds)
  ConditionVariable not_empty_; // consumers wait here
  ConditionVariable not_full_;  // producers wait here
  T *buf_ = nullptr;
  std::size_t cap_ = 0;
  std::size_t head_ = 0;
  std::size_t tail_ = 0;
  std::size_t size_ = 0;
  bool closed_ = false;
};

// ---- Semaphore --------------------------------------------------------------
// Fiber-aware counting semaphore: `permits` tokens; acquire(n) blocks (yields
// the fiber) until n are available, release(n) hands them back. The standard
// async rate-limiter (cap in-flight connections/requests, gate a buffer pool).
// Built on the CV foundation (marl's lesson: one wake mechanism, everything
// layers on it).
//
// SEMANTICS (tokio batch_semaphore, adopted): STRICT FIFO with NO head-of-line
// skip -- a waiter that wants n permits sits at the queue head and accumulates
// permits across release()s; releases NEVER skip past it to satisfy a smaller
// later waiter. This is what prevents large-request starvation (and is exactly
// why RwLock's writer -- which wants ALL permits -- can't be starved by a
// stream of readers). Tradeoff: deliberate head-of-line blocking, chosen for
// fairness.
//
// Each waiter owns its own CV on its stack, so release() wakes EXACTLY the head
// waiter it just satisfied (no thundering herd re-checking a shared predicate).
// The waiter list is intrusive + doubly linked so a timed acquire can unlink in
// O(1); the node lives on the blocking fiber/thread stack
// and stays linked only while parked (same discipline as ConditionVariable).
class Semaphore {
public:
  explicit Semaphore(std::size_t permits) noexcept : permits_(permits) {}
  Semaphore(const Semaphore &) = delete;
  Semaphore &operator=(const Semaphore &) = delete;
  Semaphore(Semaphore &&) = delete;
  Semaphore &operator=(Semaphore &&) = delete;

  // Acquire `n` permits, blocking (fiber-aware) until available. Returns
  // Cancelled if the semaphore closes before n can be granted (permits already
  // handed to this waiter are returned to the pool). n may exceed the initial
  // permit count. Acquiring zero is an immediate success unless closed.
  HYLE_SCHED_API Result<void> acquire(std::size_t n = 1) noexcept;

  // Non-blocking: take `n` permits iff all are available right now. Returns
  // Unavailable when permits/FIFO order prevent acquisition, or Cancelled when
  // closed. Never queues. Acquiring zero succeeds unless closed.
  HYLE_SCHED_API Result<void> try_acquire(std::size_t n = 1) noexcept;

  // Timed FIFO acquire. An expired deadline still performs one immediate
  // acquisition attempt. A timed-out queued request unlinks itself in O(1),
  // then makes any newly-unblocked follower eligible without waiting for a new
  // release. Returns DeadlineExceeded on timeout and Cancelled on close.
  HYLE_SCHED_API Result<void> try_acquire_for(time::Duration timeout,
                                              std::size_t n = 1) noexcept;
  HYLE_SCHED_API Result<void> try_acquire_until(
      time::MonotonicTimePoint deadline, std::size_t n = 1) noexcept;

  // Return `n` permits to the pool, waking FIFO-front waiters whose full
  // request is thereby satisfied. Wakes are delivered after the internal lock
  // is dropped.
  HYLE_SCHED_API bool try_release(std::size_t n = 1) noexcept;
  void release(std::size_t n = 1) noexcept {
    HYLE_FATAL_ASSERT(try_release(n));
  }

  // Close: wake every waiter (their acquire returns Cancelled). Post-close
  // acquire/try_acquire also return Cancelled. Idempotent. Permits already in
  // the pool stay.
  HYLE_SCHED_API void close() noexcept;

  // Available permits right now (racy snapshot; for diagnostics/tests).
  HYLE_SCHED_API std::size_t available() const noexcept;

  // RAII permit: holds `n` permits and returns them to the pool on destruction.
  // The ergonomic limiter usage -- `auto p = sem.acquire_guard(); ...` frees
  // the slot automatically on scope exit, even on early return. Failure stays
  // in Result rather than being collapsed into an empty Permit.
  class Permit {
  public:
    Permit() noexcept = default;
    Permit(Semaphore *s, std::size_t n) noexcept : sem_(s), n_(n) {}
    Permit(Permit &&o) noexcept
        : sem_(std::exchange(o.sem_, nullptr)), n_(o.n_) {}
    Permit &operator=(Permit &&o) noexcept {
      if (this != &o) {
        reset();
        sem_ = std::exchange(o.sem_, nullptr);
        n_ = o.n_;
      }
      return *this;
    }
    Permit(const Permit &) = delete;
    Permit &operator=(const Permit &) = delete;
    ~Permit() { reset(); }
    bool owns() const noexcept { return sem_ != nullptr; }

    // Consume the permit WITHOUT returning it: permanently removes `n` permits
    // from the semaphore (tokio SemaphorePermit::forget) -- used to shrink
    // capacity.
    void forget() noexcept { sem_ = nullptr; }

  private:
    void reset() noexcept {
      if (sem_ != nullptr)
        sem_->release(n_);
      sem_ = nullptr;
    }
    Semaphore *sem_ = nullptr;
    std::size_t n_ = 0;
  };

  // Acquire an RAII permit while preserving the exact failure reason.
  Result<Permit> acquire_guard(std::size_t n = 1) noexcept {
    auto result = acquire(n);
    if (!result) return std::unexpected(std::move(result).error());
    return Permit(this, n);
  }
  Result<Permit> try_acquire_guard(std::size_t n = 1) noexcept {
    auto result = try_acquire(n);
    if (!result) return std::unexpected(std::move(result).error());
    return Permit(this, n);
  }
  Result<Permit> try_acquire_guard_for(time::Duration timeout,
                                       std::size_t n = 1) noexcept {
    auto result = try_acquire_for(timeout, n);
    if (!result) return std::unexpected(std::move(result).error());
    return Permit(this, n);
  }
  Result<Permit> try_acquire_guard_until(time::MonotonicTimePoint deadline,
                                         std::size_t n = 1) noexcept {
    auto result = try_acquire_until(deadline, n);
    if (!result) return std::unexpected(std::move(result).error());
    return Permit(this, n);
  }

private:
  // One queued acquirer. `need` is how many permits it still wants; `granted` +
  // its own CV are how release() hands control back to exactly this waiter.
  struct Waiter {
    Waiter *next = nullptr;
    Waiter *prev = nullptr;
    std::size_t need = 0; // permits still required before this waiter proceeds
    bool granted = false; // set by release(): request fully satisfied
    bool cancelled = false; // set by close(): acquire returns Cancelled
    bool linked = false;  // guarded by mu_; enables O(1) timeout unlink
    ConditionVariable cv; // this waiter blocks here; woken 1:1
  };

  HYLE_SCHED_API void unlink_waiter_locked_(Waiter *waiter) noexcept;
  HYLE_SCHED_API Waiter *grant_waiters_locked_() noexcept;
  HYLE_SCHED_API static void notify_waiters_(Waiter *waiters) noexcept;

  mutable util::SpinLock mu_;
  std::size_t permits_;
  Waiter *head_ = nullptr; // FIFO front: release satisfies this one first
  Waiter *tail_ = nullptr;
  bool closed_ = false;
};

// ---- RwLock -----------------------------------------------------------------
// Fiber-aware readers-writer lock, WRITE-PREFERRING (no writer starvation).
// Built directly on Semaphore, tokio's design: the lock IS a Semaphore
// initialized with kMaxReaders permits; a read holds 1 permit, a write holds
// ALL of them. Because Semaphore never skips its FIFO head, a queued writer
// (wanting all permits) makes subsequent readers (wanting 1) queue BEHIND it
// instead of stealing the lock -- fairness for free, no hand-rolled
// reader/writer counters.
//
// CONTRACT (same as std::shared_mutex / tokio): do not acquire a write lock
// while holding a read lock on the same RwLock from the same fiber
// (self-deadlock -- the write waits for all permits including the one your read
// holds). Guards are RAII; unlock on scope exit.
class RwLock {
public:
  RwLock() noexcept : sem_(kMaxReaders) {}
  RwLock(const RwLock &) = delete;
  RwLock &operator=(const RwLock &) = delete;
  RwLock(RwLock &&) = delete;
  RwLock &operator=(RwLock &&) = delete;

  // RAII read guard: holds 1 permit; releases it on destruction.
  class ReadGuard {
  public:
    ReadGuard() noexcept = default;
    explicit ReadGuard(RwLock *rw) noexcept : rw_(rw) {}
    ReadGuard(ReadGuard &&o) noexcept : rw_(std::exchange(o.rw_, nullptr)) {}
    ReadGuard &operator=(ReadGuard &&o) noexcept {
      if (this != &o) {
        reset();
        rw_ = std::exchange(o.rw_, nullptr);
      }
      return *this;
    }
    ReadGuard(const ReadGuard &) = delete;
    ReadGuard &operator=(const ReadGuard &) = delete;
    ~ReadGuard() { reset(); }
    bool owns_lock() const noexcept { return rw_ != nullptr; }

  private:
    void reset() noexcept {
      if (rw_ != nullptr)
        rw_->sem_.release(1);
      rw_ = nullptr;
    }
    RwLock *rw_ = nullptr;
  };

  // RAII write guard: holds all kMaxReaders permits; releases them on
  // destruction.
  class WriteGuard {
  public:
    WriteGuard() noexcept = default;
    explicit WriteGuard(RwLock *rw) noexcept : rw_(rw) {}
    WriteGuard(WriteGuard &&o) noexcept : rw_(std::exchange(o.rw_, nullptr)) {}
    WriteGuard &operator=(WriteGuard &&o) noexcept {
      if (this != &o) {
        reset();
        rw_ = std::exchange(o.rw_, nullptr);
      }
      return *this;
    }
    WriteGuard(const WriteGuard &) = delete;
    WriteGuard &operator=(const WriteGuard &) = delete;
    ~WriteGuard() { reset(); }
    bool owns_lock() const noexcept { return rw_ != nullptr; }

    // Atomically downgrade to a read lock: release all but ONE permit, keeping
    // the last one so the lock is NEVER fully free during the transition -- a
    // queued writer (which needs ALL permits) therefore cannot slip in between,
    // so no other writer can observe a gap. The retained permit becomes the
    // read guard. Consumes this WriteGuard (owns_lock() becomes false).
    // std::shared_mutex has no downgrade; tokio's RwLockWriteGuard::downgrade
    // is the model.
    ReadGuard downgrade() noexcept {
      HYLE_FATAL_ASSERT(rw_ != nullptr);
      RwLock *rw = rw_;
      rw_ = nullptr; // this write guard no longer owns anything
      rw->sem_.release(kMaxReaders -
                       1); // drop all but one -> now a single reader
      return ReadGuard(rw);
    }

  private:
    void reset() noexcept {
      if (rw_ != nullptr)
        rw_->sem_.release(kMaxReaders);
      rw_ = nullptr;
    }
    RwLock *rw_ = nullptr;
  };

  // Block (fiber-aware) until the lock is held; return an RAII guard.
  ReadGuard read() noexcept {
    lock_read();
    return ReadGuard(this);
  }
  WriteGuard write() noexcept {
    lock_write();
    return WriteGuard(this);
  }

  // Non-blocking. The guard's owns_lock() is false if the lock wasn't taken.
  ReadGuard try_read() noexcept {
    return sem_.try_acquire(1) ? ReadGuard(this) : ReadGuard();
  }
  WriteGuard try_write() noexcept {
    return sem_.try_acquire(kMaxReaders) ? WriteGuard(this) : WriteGuard();
  }

  // Raw lock/unlock pairs for generic guard/erased runtime integration.
  void lock_read() noexcept { (void)sem_.acquire(1); }
  bool try_lock_read() noexcept { return sem_.try_acquire(1).has_value(); }
  void unlock_read() noexcept { sem_.release(1); }
  void lock_write() noexcept { (void)sem_.acquire(kMaxReaders); }
  bool try_lock_write() noexcept {
    return sem_.try_acquire(kMaxReaders).has_value();
  }
  void unlock_write() noexcept { sem_.release(kMaxReaders); }

private:
  // Max concurrent readers. Matches tokio's u32::MAX>>3 headroom idea, sized to
  // std::size_t here; a write acquires all of them for exclusivity.
  static constexpr std::size_t kMaxReaders =
      (static_cast<std::size_t>(1) << 32);
  Semaphore sem_;
};

// ---- oneshot ----------------------------------------------------------------
// Single-value, single-producer single-consumer channel: a Sender sends ONE
// value (once), a Receiver receives it (once). The canonical "spawn a task, get
// its one result back" primitive (pairs with JoinHandle) and a request/response
// reply slot. Move-only Sender/Receiver over a refcounted shared state
// (charter: from an injected AllocatorRef, no hidden heap). Fiber-aware: recv()
// yields the fiber until the value arrives or the Sender is dropped.
//
// SEMANTICS (tokio oneshot, adopted):
//  - send(v) consumes the Sender; recv() consumes the Receiver (single-shot).
//  - Sender dropped without send -> recv() returns Cancelled (the sender is
//  gone).
//  - Receiver dropped -> send() returns the value back in an error (nobody
//  home).
//  - Sender::is_closed() lets a producer learn the Receiver went away and abort
//    expensive work before computing the value (the cancellation hook).
namespace detail {

template <class T> struct OneshotState {
  mem::AllocatorRef alloc;
  util::SpinLock mu;
  ConditionVariable cv;         // receiver blocks here for value/close
  ConditionVariable closed_cv;  // sender blocks here in closed() (rx gone)
  std::atomic<int> refcount{2}; // Sender + Receiver
  bool value_set = false;       // a value is stored (sender did send)
  bool rx_alive = true;         // Receiver not yet dropped (set under mu)
  bool tx_alive = true;         // Sender not yet dropped (set under mu) --
                                // the close signal recv() waits on. Must be
                                // flipped UNDER mu (not inferred from the
                                // lock-free refcount): a waiter re-checks the
                                // predicate under mu, so the state change that
                                // frees it has to serialize with that check,
                                // or the notify races ahead of the flag and
                                // the receiver parks forever (lost wakeup).
  alignas(T) unsigned char storage[sizeof(T)];

  void release() noexcept {
    if (refcount.fetch_sub(1, std::memory_order_acq_rel) == 1) {
      if (value_set)
        reinterpret_cast<T *>(storage)->~T(); // unreceived value
      mem::AllocatorRef a = alloc;
      this->~OneshotState();
      a.deallocate(this, sizeof(OneshotState), alignof(OneshotState));
    }
  }
};

} // namespace detail

template <detail::OneshotValue T> class OneshotReceiver;

// The only send failure is a dropped receiver. As with Tokio's SendError<T>,
// the error arm is the original unsent value; no status allocation or value
// loss is introduced on this ownership path.
template <detail::OneshotValue T>
using OneshotSendResult = std::expected<void, T>;

template <detail::OneshotValue T> class OneshotSender {
public:
  OneshotSender() noexcept = default;
  explicit OneshotSender(detail::OneshotState<T> *s) noexcept : state_(s) {}
  OneshotSender(OneshotSender &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)) {}
  OneshotSender &operator=(OneshotSender &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
    }
    return *this;
  }
  OneshotSender(const OneshotSender &) = delete;
  OneshotSender &operator=(const OneshotSender &) = delete;
  ~OneshotSender() { reset_(); }

  // Send the one value. Returns the value back (as an error payload) if the
  // Receiver has already been dropped. Consumes the send capability (state_ is
  // released after), so a second send is impossible.
  OneshotSendResult<T> send(T v) noexcept {
    HYLE_FATAL_ASSERT(state_ != nullptr);
    detail::OneshotState<T> *s = state_;
    state_ = nullptr; // consume: this Sender is spent regardless of outcome
    s->mu.lock();
    if (!s->rx_alive) {
      s->mu.unlock();
      s->release(); // our ref; receiver already gone
      return std::unexpected(std::move(v));
    }
    new (s->storage) T(std::move(v));
    s->value_set = true;
    s->tx_alive = false; // the send capability is consumed successfully
    s->mu.unlock();
    s->cv.notify_one(); // wake a blocked receiver
    s->release();
    return {};
  }

  // True once the Receiver has been dropped (cancellation hook: stop
  // computing).
  bool is_closed() const noexcept {
    state_->mu.lock();
    const bool closed = !state_->rx_alive;
    state_->mu.unlock();
    return closed;
  }

  // Block (fiber-aware) until the Receiver is dropped -- the async cancellation
  // hook: a producer awaits this and, when it fires, abandons an expensive
  // computation whose result nobody will read. Returns immediately if the
  // Receiver is already gone. (Separate CV from recv()'s: sender waits for "rx
  // gone", receiver waits for "value/tx gone" -- tokio's two independent
  // slots.)
  void closed() noexcept {
    state_->mu.lock();
    state_->closed_cv.wait(state_->mu, [&] { return !state_->rx_alive; });
    state_->mu.unlock();
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      // Dropped without sending: flip the close flag UNDER mu (so a receiver
      // re-checking the predicate under mu sees it -- flipping it via the
      // lock-free refcount would race the notify and lose the wakeup), THEN
      // notify.
      state_->mu.lock();
      state_->tx_alive = false;
      state_->mu.unlock();
      state_->cv.notify_one(); // wake the receiver so recv() returns Cancelled
      state_->release();
      state_ = nullptr;
    }
  }
  detail::OneshotState<T> *state_ = nullptr;
};

template <detail::OneshotValue T> class OneshotReceiver {
public:
  OneshotReceiver() noexcept = default;
  explicit OneshotReceiver(detail::OneshotState<T> *s) noexcept : state_(s) {}
  OneshotReceiver(OneshotReceiver &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)) {}
  OneshotReceiver &operator=(OneshotReceiver &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
    }
    return *this;
  }
  OneshotReceiver(const OneshotReceiver &) = delete;
  OneshotReceiver &operator=(const OneshotReceiver &) = delete;
  ~OneshotReceiver() { reset_(); }

  // Block (fiber-aware) until the value arrives or the Sender is dropped.
  // Consumes the receive capability. Returns the value, or Cancelled if the
  // sender dropped without sending.
  Result<T> recv() noexcept {
    detail::OneshotState<T> *s = state_;
    state_ = nullptr;
    s->mu.lock();
    // Wait until a value is set OR the sender dropped without sending. Both
    // flags are written under mu (tx_alive by the sender's reset_, value_set by
    // send), so the predicate re-check under mu can't miss either -- no lost
    // wakeup.
    s->cv.wait(s->mu, [&] { return s->value_set || !s->tx_alive; });
    if (s->value_set) {
      T *p = reinterpret_cast<T *>(s->storage);
      T out = std::move(*p);
      p->~T();
      s->value_set = false; // consumed; release() won't double-destroy
      s->mu.unlock();
      s->release();
      return out;
    }
    s->mu.unlock();
    s->release();
    return std::unexpected(Status::Cancelled("oneshot sender dropped"));
  }

  // Non-blocking: value if present, else NotFound (empty) / Cancelled (sender
  // gone).
  Result<T> try_recv() noexcept {
    state_->mu.lock();
    if (state_->value_set) {
      T *p = reinterpret_cast<T *>(state_->storage);
      T out = std::move(*p);
      p->~T();
      state_->value_set = false;
      state_->mu.unlock();
      return out;
    }
    const bool sender_gone =
        !state_->tx_alive; // flipped under mu by sender drop
    state_->mu.unlock();
    return std::unexpected(sender_gone
                               ? Status::Cancelled("oneshot sender dropped")
                               : Status::NotFound("oneshot empty"));
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      state_->mu.lock();
      state_->rx_alive =
          false; // tell the sender (is_closed/closed) nobody's home
      state_->mu.unlock();
      state_->closed_cv.notify_all(); // wake a sender blocked in closed()
      state_->release();
      state_ = nullptr;
    }
  }
  detail::OneshotState<T> *state_ = nullptr;
};

// Create a linked oneshot Sender/Receiver pair over allocator-backed shared
// state.
template <detail::OneshotValue T>
Result<std::pair<OneshotSender<T>, OneshotReceiver<T>>>
try_make_oneshot(mem::AllocatorRef alloc) noexcept {
  using detail::OneshotState;
  if (!alloc.valid())
    return std::unexpected(
        Status::InvalidArgument("oneshot requires a complete allocator"));
  auto *s = static_cast<OneshotState<T> *>(
      alloc.allocate(sizeof(OneshotState<T>), alignof(OneshotState<T>)));
  if (s == nullptr)
    return std::unexpected(
        Status::ResourceExhausted("oneshot state allocation failed"));
  new (s) OneshotState<T>{};
  s->alloc = alloc;
  return std::pair<OneshotSender<T>, OneshotReceiver<T>>{OneshotSender<T>(s),
                                                         OneshotReceiver<T>(s)};
}

template <detail::OneshotValue T>
std::pair<OneshotSender<T>, OneshotReceiver<T>>
make_oneshot(mem::AllocatorRef alloc) noexcept {
  auto result = try_make_oneshot<T>(alloc);
  HYLE_FATAL_ASSERT(result.has_value());
  return std::move(*result);
}

// ---- watch ------------------------------------------------------------------
// Latest-value broadcast: a Sender publishes a value that every Receiver can
// observe; Receivers see only the MOST RECENT value (no accumulation), and can
// block in changed() until it moves. The canonical config-hot-reload /
// shutdown- signal primitive: a late subscriber immediately sees the current
// value, and changed() wakes every waiter on each update. Distinct from a
// Channel (which queues every item) -- watch keeps exactly one cell + a version
// counter.
//
// SEMANTICS (tokio watch, adopted):
//  - Receivers are COPYABLE (subscribe many); each caches the version it has
//  seen.
//  - changed() blocks until the stored version != the receiver's seen version,
//    then updates the seen version. Uses notify-before-recheck ordering (the CV
//    predicate re-reads version under the lock) so an update can't be missed.
//  - borrow() returns a COPY of the current value under the lock (no long-held
//  Ref
//    across a suspend point -- that would block the sender; we copy instead).
//  - close (all Senders dropped) makes changed() return Cancelled.
namespace detail {

template <class T> struct WatchState {
  mem::AllocatorRef alloc;
  util::SpinLock mu;
  ConditionVariable cv;
  std::atomic<int> refcount{0}; // senders + receivers; last drop frees
  std::atomic<int> senders{0}; // >0 while any Sender alive (handle bookkeeping)
  std::atomic<int> receivers{0}; // live Receiver count (send() checks for 0)
  bool closed = false;           // all senders gone; set UNDER mu (changed()'s
                       // close predicate -- flipping via the lock-free
                       // senders count would race the notify and lose
                       // the wakeup, so the flag is mu-guarded)
  std::uint64_t version = 0; // bumped on each send; receivers track it
  alignas(T) unsigned char storage[sizeof(T)]; // the single current value

  T &value() noexcept { return *reinterpret_cast<T *>(storage); }
  void add_ref() noexcept { refcount.fetch_add(1, std::memory_order_relaxed); }
  // A new Receiver handle: bump BOTH the total refcount and the receiver count.
  void add_receiver() noexcept {
    refcount.fetch_add(1, std::memory_order_relaxed);
    receivers.fetch_add(1, std::memory_order_relaxed);
  }
  void release() noexcept {
    if (refcount.fetch_sub(1, std::memory_order_acq_rel) == 1) {
      value().~T();
      mem::AllocatorRef a = alloc;
      this->~WatchState();
      a.deallocate(this, sizeof(WatchState), alignof(WatchState));
    }
  }
};

} // namespace detail

template <detail::WatchValue T> class WatchReceiver {
public:
  WatchReceiver() noexcept = default;
  WatchReceiver(detail::WatchState<T> *s, std::uint64_t seen) noexcept
      : state_(s), seen_(seen) {}
  WatchReceiver(const WatchReceiver &o) noexcept
      : state_(o.state_), seen_(o.seen_) {
    if (state_)
      state_->add_receiver(); // another subscriber
  }
  WatchReceiver &operator=(const WatchReceiver &o) noexcept {
    if (this != &o) {
      reset_();
      state_ = o.state_;
      seen_ = o.seen_;
      if (state_)
        state_->add_receiver();
    }
    return *this;
  }
  WatchReceiver(WatchReceiver &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)), seen_(o.seen_) {}
  WatchReceiver &operator=(WatchReceiver &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
      seen_ = o.seen_;
    }
    return *this;
  }
  ~WatchReceiver() { reset_(); }

  // A COPY of the current value (does not mark it seen -- use changed() to
  // consume the update signal). Cheap to call repeatedly (config read on every
  // request).
  T borrow() const noexcept(std::is_nothrow_copy_constructible_v<T>) {
    std::lock_guard lock(state_->mu);
    T v = state_->value(); // copy under the lock
    return v;
  }

  // A COPY of the current value AND mark this version seen (so the next
  // changed() waits for the NEXT update). Use this -- not borrow() -- inside a
  // changed() loop: it aligns `seen_` to the version observed under the lock in
  // the same critical section as the read, so a send racing between changed()
  // returning and this read can't make you process the same logical value twice
  // (tokio's borrow_and_update contract).
  T borrow_and_update() noexcept(std::is_nothrow_copy_constructible_v<T>) {
    std::lock_guard lock(state_->mu);
    T v = state_->value();
    seen_ = state_->version; // align seen to the version we just read
    return v;
  }

  // Block (fiber-aware) until the value changes since this receiver last saw
  // it, then mark it seen. Returns Cancelled if all Senders have dropped (no
  // more updates will ever come). A pending change already present returns at
  // once.
  Result<void> changed() noexcept {
    state_->mu.lock();
    // version and closed are both written under mu (send bumps version, the
    // last sender's reset_ sets closed) -> the predicate re-check can't miss
    // either.
    state_->cv.wait(state_->mu,
                    [&] { return state_->version != seen_ || state_->closed; });
    const bool changed = (state_->version != seen_);
    seen_ = state_->version; // mark seen (even on close, so we don't spin)
    state_->mu.unlock();
    if (changed)
      return {};
    return std::unexpected(Status::Cancelled("watch senders dropped"));
  }

  // True if the value has changed since last seen (non-blocking peek).
  bool has_changed() const noexcept {
    state_->mu.lock();
    const bool c = (state_->version != seen_);
    state_->mu.unlock();
    return c;
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      // Last receiver gone -> wake a sender blocked in closed() (via notify on
      // the shared cv, whose closed() predicate re-checks receivers==0).
      if (state_->receivers.fetch_sub(1, std::memory_order_acq_rel) == 1) {
        state_->cv.notify_all();
      }
      state_->release(); // (receivers already decremented above)
      state_ = nullptr;
    }
  }
  detail::WatchState<T> *state_ = nullptr;
  std::uint64_t seen_ = 0;
};

template <detail::WatchValue T> class WatchSender {
public:
  WatchSender() noexcept = default;
  explicit WatchSender(detail::WatchState<T> *s) noexcept : state_(s) {}
  WatchSender(const WatchSender &o) noexcept : state_(o.state_) {
    if (state_) {
      state_->add_ref();
      state_->senders.fetch_add(1, std::memory_order_relaxed);
    }
  }
  WatchSender &operator=(const WatchSender &o) noexcept {
    if (this != &o) {
      reset_();
      state_ = o.state_;
      if (state_) {
        state_->add_ref();
        state_->senders.fetch_add(1, std::memory_order_relaxed);
      }
    }
    return *this;
  }
  WatchSender(WatchSender &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)) {}
  WatchSender &operator=(WatchSender &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
    }
    return *this;
  }
  ~WatchSender() { reset_(); }

  // Publish a new value TO CONSUMERS: replace the cell, bump the version, wake
  // every waiter. Returns Cancelled if there are no receivers (the value is
  // still stored, but nobody is listening -- the "deliver to a consumer"
  // semantics). Use send_replace/send_modify to update the shared state
  // regardless of listeners.
  Result<void> send(T v) noexcept {
    if (state_->receivers.load(std::memory_order_acquire) == 0)
      return std::unexpected(Status::Cancelled("watch has no receivers"));
    state_->mu.lock();
    state_->value() = std::move(v);
    ++state_->version; // under mu_: a receiver seeing the new version reads
                       // this v
    state_->mu.unlock();
    state_->cv.notify_all();
    return {};
  }

  // Replace the value unconditionally (even with no receivers -- watch as a
  // shared "latest state" register) and RETURN THE OLD VALUE. Always bumps +
  // notifies.
  T send_replace(T v) noexcept {
    state_->mu.lock();
    T old = std::move(state_->value());
    state_->value() = std::move(v);
    ++state_->version;
    state_->mu.unlock();
    state_->cv.notify_all();
    return old;
  }

  // Apply `f` to the value in place under the lock, then unconditionally bump
  // the version + notify. For mutate-in-place updates (avoids a copy). f:
  // void(T&).
  template <class F>
    requires std::is_nothrow_invocable_r_v<void, F, T &>
  void send_modify(F &&f) noexcept {
    state_->mu.lock();
    std::forward<F>(f)(state_->value());
    ++state_->version;
    state_->mu.unlock();
    state_->cv.notify_all();
  }

  // Apply `f` to the value in place; f returns whether it changed anything.
  // Only if it returns true do we bump the version + notify (a "silent" false
  // edit is visible via borrow() but wakes no waiter). f: bool(T&).
  template <class F>
    requires std::is_nothrow_invocable_r_v<bool, F, T &>
  void send_if_modified(F &&f) noexcept {
    state_->mu.lock();
    const bool changed = std::forward<F>(f)(state_->value());
    if (changed)
      ++state_->version;
    state_->mu.unlock();
    if (changed)
      state_->cv.notify_all();
  }

  // A COPY of the current value (sender-side peek).
  T borrow() const noexcept(std::is_nothrow_copy_constructible_v<T>) {
    std::lock_guard lock(state_->mu);
    T v = state_->value();
    return v;
  }

  // How many Receivers currently exist (a hint: races with concurrent drops).
  std::size_t receiver_count() const noexcept {
    return static_cast<std::size_t>(
        state_->receivers.load(std::memory_order_acquire));
  }

  // Subscribe a new Receiver that has ALREADY SEEN the current value (so its
  // next changed() waits for the next send, not the current value). Matches
  // tokio.
  WatchReceiver<T> subscribe() const noexcept {
    state_->mu.lock();
    const std::uint64_t v = state_->version;
    state_->mu.unlock();
    state_->add_receiver();
    return WatchReceiver<T>(state_, v);
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      // Decide "last sender" and flip `closed` UNDER mu, so a receiver
      // re-checking changed()'s predicate under mu observes closed before it
      // re-parks (flipping via the lock-free senders count alone would let the
      // notify race ahead of the flag -> lost wakeup -> permanent hang after
      // all senders gone).
      state_->mu.lock();
      const bool last =
          (state_->senders.fetch_sub(1, std::memory_order_acq_rel) == 1);
      if (last)
        state_->closed = true;
      state_->mu.unlock();
      if (last)
        state_->cv
            .notify_all(); // wake receivers -> changed() returns Cancelled
      state_->release();
      state_ = nullptr;
    }
  }
  detail::WatchState<T> *state_ = nullptr;
};

// Create a watch channel seeded with `initial`. The returned Receiver has NOT
// yet seen a change (its changed() waits for the first send after
// construction), but borrow() returns `initial` immediately -- so a late
// subscriber / shutdown flag reads the current state without waiting.
template <detail::WatchValue T>
Result<std::pair<WatchSender<T>, WatchReceiver<T>>>
try_make_watch(mem::AllocatorRef alloc, T initial) noexcept {
  using detail::WatchState;
  if (!alloc.valid())
    return std::unexpected(
        Status::InvalidArgument("watch requires a complete allocator"));
  auto *s = static_cast<WatchState<T> *>(
      alloc.allocate(sizeof(WatchState<T>), alignof(WatchState<T>)));
  if (s == nullptr)
    return std::unexpected(
        Status::ResourceExhausted("watch state allocation failed"));
  new (s) WatchState<T>{};
  s->alloc = alloc;
  new (s->storage) T(std::move(initial));
  s->refcount.store(2, std::memory_order_relaxed); // 1 sender + 1 receiver
  s->senders.store(1, std::memory_order_relaxed);
  s->receivers.store(1, std::memory_order_relaxed); // the returned Receiver
  return std::pair<WatchSender<T>, WatchReceiver<T>>{
      WatchSender<T>(s), WatchReceiver<T>(s, /*seen=*/0)};
}

template <detail::WatchValue T>
std::pair<WatchSender<T>, WatchReceiver<T>> make_watch(mem::AllocatorRef alloc,
                                                       T initial) noexcept {
  auto result = try_make_watch<T>(alloc, std::move(initial));
  HYLE_FATAL_ASSERT(result.has_value());
  return std::move(*result);
}

// ---- broadcast --------------------------------------------------------------
// Multi-consumer fan-out: every Receiver observes EVERY value a Sender sends
// (unlike watch, which keeps only the latest). A bounded ring holds the last
// `capacity` values; a slow Receiver that falls more than `capacity` behind
// gets a Lagged error naming how many it missed, then resumes at the oldest
// retained value (tokio's overwrite-oldest policy -- senders NEVER block on a
// slow reader).
//
// SEMANTICS (tokio broadcast, adopted, simplified to one lock):
//  - Receivers COPYABLE (subscribe many); each has its own monotonic read
//  cursor.
//  - send() overwrites the oldest slot, bumps the write position, wakes all
//    receiver waiters. Never blocks.
//  - recv() blocks (fiber-aware) until its cursor < write position; if the
//  cursor
//    fell behind the retained window it returns Lagged and fast-forwards.
//  - New subscribers start at the current write position (future messages
//  only).
//  - All Senders dropped + ring drained -> recv() returns Cancelled (closed).
//
// One SpinLock guards the whole ring (not tokio's per-slot mutex): correct and
// simple; the per-slot-lock throughput refinement is deferred until a real
// high-fanout consumer needs it (charter: no speculative complexity). Copying a
// value may throw; receive holds the monitor through std::unique_lock so the
// channel remains usable and its cursor remains unchanged on that failure.
namespace detail {

template <class T> struct BroadcastState {
  mem::AllocatorRef alloc;
  util::SpinLock mu;
  ConditionVariable cv;         // receivers block here for the next value
  std::atomic<int> refcount{0}; // senders + receivers; last drop frees
  std::atomic<int> senders{0}; // >0 while any Sender alive (handle bookkeeping)
  std::atomic<int> receivers{0}; // live Receiver count (for receiver_count())
  bool closed = false;         // all senders gone; set UNDER mu (recv()'s close
                               // predicate -- mu-guarded, not inferred from the
                               // lock-free senders count, to avoid lost wakeup)
  std::size_t cap;             // ring capacity (number of retained values)
  std::uint64_t write_pos = 0; // monotonic id of the NEXT value to be written
  T *buf = nullptr;            // ring of `cap` slots (index = pos % cap)
  bool *occupied = nullptr;    // whether slot i currently holds a live T

  void add_ref() noexcept { refcount.fetch_add(1, std::memory_order_relaxed); }
  // A new Receiver handle: bump both the total refcount and the receiver count.
  void add_receiver() noexcept {
    refcount.fetch_add(1, std::memory_order_relaxed);
    receivers.fetch_add(1, std::memory_order_relaxed);
  }
  void release() noexcept {
    if (refcount.fetch_sub(1, std::memory_order_acq_rel) == 1) {
      for (std::size_t i = 0; i < cap; ++i)
        if (occupied[i])
          buf[i].~T();
      mem::AllocatorRef a = alloc;
      const std::size_t c = cap;
      T *b = buf;
      bool *o = occupied;
      this->~BroadcastState();
      a.deallocate(b, sizeof(T) * c, alignof(T));
      a.deallocate(o, sizeof(bool) * c, alignof(bool));
      a.deallocate(this, sizeof(BroadcastState), alignof(BroadcastState));
    }
  }
};

} // namespace detail

// A broadcast receive can fail like an ordinary HYLE Result and, for lag, also
// carries the exact number of overwritten messages. Keeping the count in the
// error arm leaves the success path identical to returning T and lets consumers
// make a retry/drop/disconnect decision without parsing diagnostic text.
class BroadcastRecvError {
public:
  explicit BroadcastRecvError(Status status, std::uint64_t missed = 0) noexcept
      : status_(std::move(status)), missed_(missed) {
    HYLE_FATAL_ASSERT(!status_.ok());
  }

  const Status &status() const noexcept { return status_; }
  StatusCode code() const noexcept { return status_.code(); }
  bool lagged() const noexcept {
    return status_.IsUnavailable() && missed_ != 0;
  }
  std::uint64_t missed() const noexcept { return missed_; }

private:
  Status status_;
  std::uint64_t missed_ = 0;
};

template <detail::BroadcastValue T>
using BroadcastRecvResult = std::expected<T, BroadcastRecvError>;

template <detail::BroadcastValue T> class BroadcastReceiver {
public:
  BroadcastReceiver() noexcept = default;
  BroadcastReceiver(detail::BroadcastState<T> *s, std::uint64_t cursor) noexcept
      : state_(s), cursor_(cursor) {}
  BroadcastReceiver(const BroadcastReceiver &o) noexcept
      : state_(o.state_), cursor_(o.cursor_) {
    if (state_)
      state_->add_receiver();
  }
  BroadcastReceiver &operator=(const BroadcastReceiver &o) noexcept {
    if (this != &o) {
      reset_();
      state_ = o.state_;
      cursor_ = o.cursor_;
      if (state_)
        state_->add_receiver();
    }
    return *this;
  }
  BroadcastReceiver(BroadcastReceiver &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)), cursor_(o.cursor_) {}
  BroadcastReceiver &operator=(BroadcastReceiver &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
      cursor_ = o.cursor_;
    }
    return *this;
  }
  ~BroadcastReceiver() { reset_(); }

  // Block (fiber-aware) until a value at/after this receiver's cursor is
  // available. Returns:
  //  - the value (cursor advances by 1);
  //  - BroadcastRecvError{Unavailable, missed} if the cursor fell behind the
  //    retained window (the cursor fast-forwards; retry recv() to get the
  //    value);
  //  - Cancelled if all senders dropped AND nothing remains to read.
  BroadcastRecvResult<T>
  recv() noexcept(std::is_nothrow_copy_constructible_v<T>) {
    auto *s = state_;
    std::unique_lock lock(s->mu);
    // write_pos (send) and closed (last sender's reset_) are both written under
    // mu, so the predicate re-check can't miss a value or the close -> no lost
    // wakeup.
    s->cv.wait(lock, [&] { return cursor_ < s->write_pos || s->closed; });
    // Closed and fully drained.
    if (cursor_ >= s->write_pos) {
      return std::unexpected(
          BroadcastRecvError(Status::Cancelled("broadcast closed")));
    }
    // Lag check: the oldest retained value has pos == write_pos - cap (once the
    // ring has wrapped). If our cursor is older than that, we missed some.
    const std::uint64_t oldest =
        s->write_pos > s->cap ? s->write_pos - s->cap : 0;
    if (cursor_ < oldest) {
      const std::uint64_t missed = oldest - cursor_;
      cursor_ = oldest; // fast-forward to the oldest still-retained value
      return std::unexpected(BroadcastRecvError(
          Status::Unavailable("broadcast receiver lagged"), missed));
    }
    T out = s->buf[cursor_ % s->cap]; // copy the value for this receiver
    ++cursor_;
    lock.unlock();
    return out;
  }

  // Non-blocking counterpart to recv(): NotFound means no new value yet,
  // Unavailable means lagged (cursor fast-forwards), and Cancelled means closed
  // and drained.
  BroadcastRecvResult<T>
  try_recv() noexcept(std::is_nothrow_copy_constructible_v<T>) {
    auto *s = state_;
    std::unique_lock lock(s->mu);
    if (cursor_ >= s->write_pos) {
      const bool closed = s->closed;
      return std::unexpected(
          BroadcastRecvError(closed ? Status::Cancelled("broadcast closed")
                                    : Status::NotFound("broadcast empty")));
    }
    const std::uint64_t oldest =
        s->write_pos > s->cap ? s->write_pos - s->cap : 0;
    if (cursor_ < oldest) {
      const std::uint64_t missed = oldest - cursor_;
      cursor_ = oldest;
      return std::unexpected(BroadcastRecvError(
          Status::Unavailable("broadcast receiver lagged"), missed));
    }
    T out = s->buf[cursor_ % s->cap];
    ++cursor_;
    lock.unlock();
    return out;
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      state_->receivers.fetch_sub(1, std::memory_order_acq_rel);
      state_->release();
      state_ = nullptr;
    }
  }
  detail::BroadcastState<T> *state_ = nullptr;
  std::uint64_t cursor_ = 0;
};

template <detail::BroadcastValue T> class BroadcastSender {
public:
  BroadcastSender() noexcept = default;
  explicit BroadcastSender(detail::BroadcastState<T> *s) noexcept : state_(s) {}
  BroadcastSender(const BroadcastSender &o) noexcept : state_(o.state_) {
    if (state_) {
      state_->add_ref();
      state_->senders.fetch_add(1, std::memory_order_relaxed);
    }
  }
  BroadcastSender &operator=(const BroadcastSender &o) noexcept {
    if (this != &o) {
      reset_();
      state_ = o.state_;
      if (state_) {
        state_->add_ref();
        state_->senders.fetch_add(1, std::memory_order_relaxed);
      }
    }
    return *this;
  }
  BroadcastSender(BroadcastSender &&o) noexcept
      : state_(std::exchange(o.state_, nullptr)) {}
  BroadcastSender &operator=(BroadcastSender &&o) noexcept {
    if (this != &o) {
      reset_();
      state_ = std::exchange(o.state_, nullptr);
    }
    return *this;
  }
  ~BroadcastSender() { reset_(); }

  // Publish `v` to all receivers (overwrites the oldest slot if the ring is
  // full; never blocks). Wakes every waiting receiver.
  void send(T v) noexcept {
    state_->mu.lock();
    const std::size_t idx = state_->write_pos % state_->cap;
    if (state_->occupied[idx]) {
      state_->buf[idx] = std::move(v); // overwrite oldest
    } else {
      new (&state_->buf[idx]) T(std::move(v));
      state_->occupied[idx] = true;
    }
    ++state_->write_pos;
    state_->mu.unlock();
    state_->cv.notify_all();
  }

  // Subscribe a new Receiver starting at the current write position (future
  // messages only -- it does not replay history already in the ring).
  BroadcastReceiver<T> subscribe() const noexcept {
    state_->mu.lock();
    const std::uint64_t pos = state_->write_pos;
    state_->mu.unlock();
    state_->add_receiver();
    return BroadcastReceiver<T>(state_, pos);
  }

  // Live handle counts (hints: race with concurrent clone/drop).
  std::size_t receiver_count() const noexcept {
    return static_cast<std::size_t>(
        state_->receivers.load(std::memory_order_acquire));
  }
  std::size_t sender_count() const noexcept {
    return static_cast<std::size_t>(
        state_->senders.load(std::memory_order_acquire));
  }

private:
  void reset_() noexcept {
    if (state_ != nullptr) {
      // Flip `closed` UNDER mu when the last sender leaves (see recv()'s
      // predicate) so a blocked receiver observes it before re-parking -- no
      // lost wakeup.
      state_->mu.lock();
      const bool last =
          (state_->senders.fetch_sub(1, std::memory_order_acq_rel) == 1);
      if (last)
        state_->closed = true;
      state_->mu.unlock();
      if (last)
        state_->cv.notify_all(); // unblock receivers -> recv() returns closed
      state_->release();
      state_ = nullptr;
    }
  }
  detail::BroadcastState<T> *state_ = nullptr;
};

// Create a broadcast channel retaining the last `capacity` values. Returns a
// Sender + one Receiver (subscribe() more from the Sender). capacity >= 1.
template <detail::BroadcastValue T>
Result<std::pair<BroadcastSender<T>, BroadcastReceiver<T>>>
try_make_broadcast(mem::AllocatorRef alloc, std::size_t capacity) noexcept {
  using detail::BroadcastState;
  if (!alloc.valid())
    return std::unexpected(
        Status::InvalidArgument("broadcast requires a complete allocator"));
  if (capacity == 0 ||
      capacity > (std::numeric_limits<std::size_t>::max)() / sizeof(T))
    return std::unexpected(
        Status::InvalidArgument("invalid broadcast capacity"));
  auto *s = static_cast<BroadcastState<T> *>(
      alloc.allocate(sizeof(BroadcastState<T>), alignof(BroadcastState<T>)));
  if (s == nullptr)
    return std::unexpected(
        Status::ResourceExhausted("broadcast state allocation failed"));
  new (s) BroadcastState<T>{};
  s->alloc = alloc;
  s->cap = capacity;
  s->buf = static_cast<T *>(alloc.allocate(sizeof(T) * capacity, alignof(T)));
  s->occupied = static_cast<bool *>(
      alloc.allocate(sizeof(bool) * capacity, alignof(bool)));
  if (s->buf == nullptr || s->occupied == nullptr) {
    if (s->buf != nullptr)
      alloc.deallocate(s->buf, sizeof(T) * capacity, alignof(T));
    if (s->occupied != nullptr)
      alloc.deallocate(s->occupied, sizeof(bool) * capacity, alignof(bool));
    s->~BroadcastState<T>();
    alloc.deallocate(s, sizeof(BroadcastState<T>), alignof(BroadcastState<T>));
    return std::unexpected(
        Status::ResourceExhausted("broadcast ring allocation failed"));
  }
  for (std::size_t i = 0; i < capacity; ++i)
    s->occupied[i] = false;
  s->refcount.store(2, std::memory_order_relaxed); // 1 sender + 1 receiver
  s->senders.store(1, std::memory_order_relaxed);
  s->receivers.store(1, std::memory_order_relaxed); // the returned Receiver
  return std::pair<BroadcastSender<T>, BroadcastReceiver<T>>{
      BroadcastSender<T>(s), BroadcastReceiver<T>(s, /*cursor=*/0)};
}

template <detail::BroadcastValue T>
std::pair<BroadcastSender<T>, BroadcastReceiver<T>>
make_broadcast(mem::AllocatorRef alloc, std::size_t capacity) noexcept {
  auto result = try_make_broadcast<T>(alloc, capacity);
  HYLE_FATAL_ASSERT(result.has_value());
  return std::move(*result);
}

} // namespace hyle::sched
