from pathlib import Path
import hashlib
import json
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-decode-investigation-reclaim.zip'
assert not DEST.exists(), 'Do not overwrite a frozen archive'


def digest(data):
    return hashlib.sha256(data).hexdigest()


receipt = json.loads((OUT / 'cleanup-receipt.json').read_text(encoding='utf-8-sig'))
assert receipt['complete'] and receipt['files'] == 23 and receipt['bytes'] == 808658511
assert len(receipt['retained_objects']) == 10 and len(receipt['retained_raw_traces']) == 8
assert len(receipt['archives_verified']) == 4
assert digest((OUT / 'exact-test.ps1').read_bytes()) == receipt['script_sha256']
entries = []
for path in sorted(OUT.iterdir()):
    if not path.is_file() or path.name in {'archive-receipt.json', 'archive-inventory.json'}:
        continue
    assert path.suffix.lower() not in {'.obj', '.exe', '.dll', '.lib', '.exp', '.map', '.zip'}
    entries.append((path.name, path.read_bytes()))
manifest = dict(schema='hyle.cuda.decode-investigation.reclaim.archive.v1',
    scope='Executed exact23-file cleanup receipt, approved plan, exact root script, previous script, '
          'default preview records and original small compatibility failure. No new build/GPU/deletion.',
    files_deleted=23, reclaimed_bytes=808658511, retained_objects=10, retained_raw_traces=8,
    entries=[dict(path=name, bytes=len(data), sha256=digest(data),
                  crc32=f'{zlib.crc32(data)&0xffffffff:08x}') for name, data in entries])
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in entries:
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(entries)+1
    for row in manifest['entries']:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert f'{zlib.crc32(data)&0xffffffff:08x}' == row['crc32']
data = DEST.read_bytes()
final = dict(path=str(DEST), bytes=len(data), sha256=digest(data),
    crc32=f'{zlib.crc32(data)&0xffffffff:08x}', entries=len(entries)+1,
    zip_crc_and_all_payload_sha_verified=True, deleted_files=23, reclaimed_bytes=808658511,
    retained_objects=10, retained_raw_traces=8, deletion_executed_by_parent=True,
    no_additional_validation_build_gpu_or_deletion=True)
(OUT / 'archive-receipt.json').write_text(json.dumps(final, indent=2)+'\n')
(OUT / 'archive-inventory.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(final, indent=2))
