param([switch]$ReclaimGgmlWorkspaceConsumers)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/ggml-cuda-workspace-consumers-reclaim'
$imageDirectory = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/ggml-cuda-caller-workspace-consumer-validation'
$archivePath = Join-Path $workspace 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-workspace-consumers.zip'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json

function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    if ([string]$entry.sha256 -cnotmatch '^[0-9a-f]{64}$') { throw "Invalid SHA256 identity: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne [long]$entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $path" }
}

if ($plan.workspace -ne $workspace -or $plan.expected_archive_path -ne $archivePath) { throw 'Plan workspace/archive does not match this task' }
if (@($plan.allowed_parent_directories).Count -ne 1 -or $plan.allowed_parent_directories[0] -ne $imageDirectory) { throw 'Unexpected image directory' }
if (@($plan.targets).Count -ne 4 -or $plan.files -ne 4 -or @($plan.retained_objects).Count -ne 8) { throw 'Expected exactly four images and eight retained objects' }
if (($plan.targets | Measure-Object -Property bytes -Sum).Sum -ne $plan.bytes) { throw 'Plan byte total changed' }

$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($object in $plan.retained_objects) {
    $path = [IO.Path]::GetFullPath([string]$object.path)
    if ([IO.Path]::GetDirectoryName($path) -ne $imageDirectory -or [IO.Path]::GetExtension($path) -ne '.obj') { throw "Unexpected retained object: $path" }
    if (-not $seen.Add($path)) { throw "Duplicate path: $path" }
    Assert-Identity $object
}
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    $extension = [IO.Path]::GetExtension($path)
    if ([IO.Path]::GetDirectoryName($path) -ne $imageDirectory -or @('.exe', '.map', '.lib', '.exp') -notcontains $extension -or [IO.Path]::GetFileNameWithoutExtension($path) -ne 'consumer-tests') { throw "Not an exact completed consumer image: $path" }
    if (-not $seen.Add($path)) { throw "Duplicate or retained target: $path" }
    Assert-Identity $entry
}
if ($plan.archive_ready) {
    if (@($plan.archives).Count -ne 1 -or $plan.archives[0].path -ne $archivePath) { throw 'Expected the exact final consumer archive' }
    Assert-Identity $plan.archives[0]
} elseif (@($plan.archives).Count -ne 0) { throw 'Pending archive must not contain a provisional identity' }

if (-not $ReclaimGgmlWorkspaceConsumers) {
    [pscustomobject]@{ preview = $true; files = $plan.files; bytes = $plan.bytes; archive_ready = $plan.archive_ready; retained_objects = $plan.retained_objects.Count }
    return
}
if (-not $plan.archive_ready) { throw 'Final archive identity has not been recorded; no files were deleted' }
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup already has a receipt; do not replay deletions' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Assert-Identity $entry
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{
        deleted = $deleted.ToArray(); files = $deleted.Count; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum
        archives_verified = $true; retained_objects = $plan.retained_objects; complete = ($deleted.Count -eq $plan.targets.Count)
        script_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    } | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($object in $plan.retained_objects) { Assert-Identity $object }
[pscustomobject]@{ deleted_files = $deleted.Count; reclaimed_bytes = $plan.bytes; retained_objects = $plan.retained_objects.Count }
