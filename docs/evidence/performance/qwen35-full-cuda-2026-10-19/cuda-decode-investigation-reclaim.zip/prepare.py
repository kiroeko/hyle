from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


before = OUT / 'before-test.ps1'
if before.exists():
    assert before.read_bytes() == (ROOT / 'test.ps1').read_bytes(), 'Original backup already preserved'
else:
    before.write_bytes((ROOT / 'test.ps1').read_bytes())
save('before-script-identity.json', ident(before))
manifests = [ARCH / name for name in ['qwen-decode-native-route/cleanup-windows.json',
    'cuda-native-matvec/cleanup-windows.json', 'cuda-bfloat-elementwise-build/cleanup-candidates.json',
    'cuda-bfloat-elementwise-tests/cleanup-windows.json']]
baseline, vector, bf16, tests = [read(path) for path in manifests]
targets = baseline['files'] + vector['files'] + bf16['files']
assert len(targets) == 23
assert {row['path']: row for row in tests['files']} == {
    row['path']: row for row in bf16['files'] if Path(row['path']).parent == ARCH / 'cuda-bfloat-elementwise-tests'}
assert len({row['path'].lower() for row in targets}) == 23
for row in targets:
    actual = ident(row['path'])
    assert all(actual[key] == row[key] for key in ['path', 'bytes', 'sha256'])
retained = vector['retain_objects'] + bf16['retain']
assert len(retained) == 10
for row in retained:
    assert ident(row['path']) == row
for stage, stems in [('qwen-decode-native-route', ['hyle', 'peer']),
                     ('qwen-decode-native-route-candidate', ['candidate']),
                     ('cuda-bfloat-elementwise-trace', ['candidate'])]:
    for stem in stems:
        for suffix in ['.nsys-rep', '.sqlite']:
            retained.append(ident(ARCH / stage / (stem+'-trace'+suffix)))
assert len(retained) == 18
archive_receipts = [ARCH / name for name in ['qwen-decode-native-route/archive-receipt.json',
    'cuda-native-matvec/archive-receipt.json', 'cuda-bfloat-elementwise/archive-receipt.json',
    'cuda-bfloat-elementwise-trace/archive-receipt.json']]
archives = []
for path in archive_receipts:
    receipt = read(path)
    receipt = receipt.get('archive', receipt)
    actual = ident(receipt['path'])
    assert all(actual[key] == receipt[key] for key in ['path', 'bytes', 'sha256'])
    archives.append(actual)
header = next(row for row in targets if Path(row['path']).suffix == '.h')
snapshot = ARCH / 'cuda-vector-matmul/candidate/tests/cuda_vector_matmul_test.h'
assert header['sha256'] == ident(snapshot)['sha256']
plan = dict(schema='hyle.cuda.decode-investigation.reclaim.v1', workspace=str(ROOT),
    allowed_image_directories=[str(ARCH / name) for name in ['qwen-decode-native-route',
        'cuda-native-matvec', 'cuda-bfloat-elementwise-build', 'cuda-bfloat-elementwise-tests']],
    expected_archive_paths=[row['path'] for row in archives], archive_ready=True,
    archives=archives, archive_receipts=[ident(path) for path in archive_receipts],
    source_manifests=[ident(path) for path in manifests],
    targets=targets, files=len(targets), bytes=sum(row['bytes'] for row in targets),
    header=dict(identity=header, frozen_snapshot=ident(snapshot)),
    retained_objects=retained[:10], retained_raw_traces=retained[10:],
    retention_scope='All objects, source snapshots, raw decision data, Nsight/SQLite traces, '
        'SDK caches and model files remain. Exactly one rejected unused source header is removed.',
    superseded_retention='Earlier vector manifest retained baseline hyle.exe for BF16 A/B. '
        'The parent now explicitly authorized baseline cleanup after those A/B runs completed.',
    default_preview=True, deletions_executed=False)
save('cleanup-plan.json', plan)
print(json.dumps(dict(files=plan['files'], bytes=plan['bytes'], archives=len(archives),
                     retained_objects=10, retained_raw_traces=8), indent=2))
