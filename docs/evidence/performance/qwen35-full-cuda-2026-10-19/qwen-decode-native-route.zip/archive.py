from pathlib import Path
import hashlib,json,zipfile,zlib
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/qwen-decode-native-route.zip'
assert not DEST.exists(), 'Do not overwrite frozen evidence'
def digest(data):return hashlib.sha256(data).hexdigest()
entries=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts:continue
 if p.suffix.lower() in {'.obj','.exe','.dll','.lib','.exp','.map','.zip','.pyc'} or p.name=='archive-receipt.json':continue
 data=p.read_bytes();entries.append((p.relative_to(OUT).as_posix(),data))
assert sum(n.endswith('.nsys-rep') for n,b in entries)==2
assert sum(n.endswith('.sqlite') for n,b in entries)==2
manifest=dict(schema='hyle.qwen.decode-native-route.archive.v1',scope='Exact single software trace per engine plus official SQLite/API/kernel exports; retained raw data, no SDK/model/objects/images/maps. Profiled durations are not fair benchmark results.',entries=[dict(path=n,bytes=len(b),sha256=digest(b),crc32=f'{zlib.crc32(b)&0xffffffff:08x}') for n,b in entries])
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in entries:z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(DEST) as z:
 assert z.testzip() is None
 assert len(z.infolist())==len(entries)+1
 for row in manifest['entries']:
  data=z.read(row['path']);assert len(data)==row['bytes'] and digest(data)==row['sha256'] and f'{zlib.crc32(data)&0xffffffff:08x}'==row['crc32']
b=DEST.read_bytes();receipt=dict(path=str(DEST.resolve()),bytes=len(b),sha256=digest(b),crc32=f'{zlib.crc32(b)&0xffffffff:08x}',entries=len(entries)+1,payload_entries=len(entries),zip_crc_and_all_entry_sha_verified=True,raw_nsight_reports=2,sqlite_exports=2,no_models_sdk_images_maps_objects=True,cleanup_manifest=str((OUT/'cleanup-windows.json').resolve()),deletions_executed=False)
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
