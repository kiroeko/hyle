from pathlib import Path
import collections,csv,hashlib,json,sqlite3,statistics
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
def union_ns(intervals):
 if not intervals:return 0
 intervals=sorted(intervals);a,b=intervals[0];total=0
 for x,y in intervals[1:]:
  if x>b:total+=b-a;a,b=x,y
  else:b=max(b,y)
 return total+b-a
def group(name):
 if 'internal::gemvx' in name:return 'cuBLAS_gemvx'
 if 'mul_mat_vec_f<' in name:return 'ggml_mmvf'
 if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name:return 'scalar_BF16_to_F32'
 if 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name:return 'scalar_F32_to_BF16'
 if 'rms_norm' in name:return 'RMSNorm'
 if 'gated_delta_net' in name:return 'GatedDeltaNet'
 if 'flash_attn' in name or 'flashinfer' in name or 'BatchPrefill' in name:return 'attention_named'
 if 'gemm' in name.lower():return 'GEMM_named'
 if 'op_mul' in name:return 'binary_multiply'
 if 'op_add' in name:return 'binary_add'
 return 'other'
engines={}
for engine in ['hyle','peer']:
 c=sqlite3.connect((OUT/(engine+'-trace.sqlite')).resolve().as_uri()+'?mode=ro',uri=True)
 diagnostics=[dict(timestamp_ns=t,severity=s,text=text) for t,s,text in c.execute('select timestamp,severity,text from DIAGNOSTIC_EVENT')]
 streams=[]
 for filename,contents in c.execute('select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
  if '/streams/' not in filename:continue
  path=OUT/(engine+'-target-'+('stderr' if 'stderr_' in filename else 'stdout')+'.log');path.write_text(contents,encoding='utf-8');streams.append(ident(path))
 save(OUT/(engine+'-diagnostics.json'),dict(events=diagnostics,streams=streams))
 kernels=[dict(start=a,end=b,name=n,graph_node=bool(g)) for a,b,n,g in c.execute('select a.start,a.end,s.value,a.graphNodeId from CUPTI_ACTIVITY_KIND_KERNEL a join StringIds s on s.id=a.demangledName order by a.start')]
 copies=[dict(start=a,end=b,bytes=n,kind=k) for a,b,n,k in c.execute('select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start')]
 memset=[dict(start=a,end=b,bytes=n) for a,b,n in c.execute('select start,end,bytes from CUPTI_ACTIVITY_KIND_MEMSET order by start')]
 apis=[dict(start=a,end=b,name=n,return_value=r) for a,b,n,r in c.execute('select a.start,a.end,s.value,a.returnValue from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId order by a.start')]
 dtoh=[x for x in copies if x['kind']==2]
 if engine=='hyle':assert len(dtoh)==32 and all(x['bytes']==4 for x in dtoh);ends=[x['end'] for x in dtoh]
 else:
  assert collections.Counter(x['bytes'] for x in dtoh)=={4:32,993280:32}
  ends=[x['end'] for x in dtoh if x['bytes']==993280]
  for i,end in enumerate(ends):assert dtoh[2*i]['bytes']==4 and dtoh[2*i+1]['bytes']==993280 and end==dtoh[2*i+1]['end']
 phases=[];previous=-1
 for i,end in enumerate(ends):
  ks=[x for x in kernels if previous<x['start']<=end]
  ms=[x for x in copies+memset if previous<x['start']<=end]
  aa=[x for x in apis if previous<x['start']<=end]
  counts=collections.Counter(group(x['name']) for x in ks)
  intervals=[(x['start'],x['end']) for x in ks+ms]
  first=min(a for a,b in intervals);last=max(b for a,b in intervals)
  active=union_ns(intervals);span=last-first
  selected=collections.Counter(x['name'] for x in aa if any(t in x['name'] for t in ['GraphLaunch','GraphInstantiate','GraphExecUpdate','StreamBeginCapture','StreamEndCapture']))
  phases.append(dict(phase='prefill' if i==0 else 'decode'+str(i),boundary_end_ns=end,readback_to_readback_ns=None if i==0 else end-previous,kernel_count=len(ks),graph_node_kernel_count=sum(x['graph_node'] for x in ks),kernel_group_counts=dict(counts),selected_api_calls=dict(selected),device_activity_first_ns=first,device_activity_last_ns=last,observed_device_activity_span_ns=span,union_kernel_copy_memset_active_ns=active,union_kernel_only_active_ns=union_ns([(x['start'],x['end']) for x in ks]),observed_intra_span_without_target_activity_ns=span-active,observed_gap_before_first_activity_ns=None if i==0 else first-previous,kernel_duration_sum_ns=sum(x['end']-x['start'] for x in ks),dtoh_bytes=sum(x['bytes'] for x in ms if x.get('kind')==2)))
  previous=end
 stable=phases[7:]
 numeric={}
 for key in ['kernel_count','graph_node_kernel_count','observed_device_activity_span_ns','union_kernel_copy_memset_active_ns','observed_intra_span_without_target_activity_ns','readback_to_readback_ns','observed_gap_before_first_activity_ns']:
  vals=[p[key] for p in stable];numeric[key]=dict(min=min(vals),median=statistics.median(vals),max=max(vals))
 summaries=list(csv.DictReader((OUT/(engine+'-trace_cuda_gpu_kern_sum.csv')).open()))
 official_instances=sum(int(x['Instances']) for x in summaries);assert official_instances==len(kernels)
 save(OUT/(engine+'-phases.json'),dict(method='32 observed final device-to-host readbacks; Hyle4B token, peer4B token followed by993280B sampled_logits. Phase0 includes loading/cold setup. Decode bins include inter-step host work and preparation; no added NVTX or callbacks.',phases=phases,stable_decode7_through31=numeric))
 baseline_path=ARCH/('ggml-cuda-caller-workspace/perf128-02-candidate/stdout.log' if engine=='hyle' else 'qwen-gpu-comparison/128-prefill/02-llama/peer-result.json')
 actual=read(OUT/'hyle-target-stdout.log') if engine=='hyle' else read(OUT/'peer-result.json')
 baseline=read(baseline_path)
 ids=actual['generated_ids'] if engine=='hyle' else actual['predicted_ids'];old_ids=baseline['generated_ids'] if engine=='hyle' else baseline['predicted_ids']
 assert len(ids)==32 and ids==old_ids
 fixed=read(ARCH/'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
 assert actual['decode_input_ids']==fixed['decode_input_ids']
 if engine=='peer':assert actual['prompt_ids']==fixed['prompt_ids']
 graphlaunch=[x for x in apis if 'GraphLaunch' in x['name']]
 engines[engine]=dict(profile_exit=read(OUT/(engine+'-profile.result.json'))['exit'],stats_exit=read(OUT/(engine+'-stats.result.json'))['exit'],kernel_instances=len(kernels),kernel_group_counts=dict(collections.Counter(group(x['name']) for x in kernels)),graph_launch_count=len(graphlaunch),all_graph_launch_api_returns_zero=all(x['return_value']==0 for x in graphlaunch),stable_decode7_through31=numeric,stable_structures=sorted({(p['kernel_count'],p['graph_node_kernel_count'],sum(v for k,v in p['selected_api_calls'].items() if 'GraphLaunch' in k)) for p in stable}),first_8_phase_structure=[dict(phase=p['phase'],kernels=p['kernel_count'],graph_node_kernels=p['graph_node_kernel_count'],groups=p['kernel_group_counts'],apis=p['selected_api_calls']) for p in phases[:8]],same_engine_unprofiled_predictions_32_equal=True,predicted_ids=ids,baseline_result=ident(baseline_path),dtoh_bytes=sum(x['bytes'] for x in dtoh),diagnostics=ident(OUT/(engine+'-diagnostics.json')),phase_details=ident(OUT/(engine+'-phases.json')),main_kernel_entries=summaries[:12])
summary=dict(schema='hyle.qwen.decode-native-route.v1',status='two_single_profile_processes_and_official_exports_terminal_success',scope='Baseline current caller-workspace Hyle and previously matched llama; same128 prompt and31 fixed decode inputs, capacity256, allCUDA. No source/product/SDK/native compilation. Exactly one software trace per engine.',engines=engines,source_freeze=ident(OUT/'baseline-freeze.json'),input_closure=ident(OUT/'link-input-identities.json'),trace_config='cuda / no CPU sampling / no CPU context switches / node:host-only; changed graph->node granularity to retain native graph kernel activities.',structural_findings=['All25 stable Hyle decode bins:2400 kernels,187 cuBLAS gemvx projections,401 native CUDA graph launches,2106 graph-node kernels.','All25 stable peer decode bins:558 kernels,163 ggml mmvf projections,1 native CUDA graph launch,558 graph-node kernels.','The peer native projection family is mmvf, rather than the same cuBLAS gemvx route. Kernel counts alone do not map every physical projection to identical logical nodes.','Hyle stable bins retain801 scalar BF16->F32 and427 scalar F32->BF16 copy kernels; these are actual arithmetic/storage boundaries, not automatically removable copies.','The24 projection difference is compatible with peer native up/gate fusion support, but no per-logical-node graph export was collected here, so this trace alone does not prove the exact24 mapping.'],limits=['Profiled durations/spans are software-instrumented observations, not a fair speed/throughput comparison or a new performance winner claim.','Driver reports CUDA13.4 while Nsight uses13.3 collection libraries; both traces retain this compatibility warning and explicit legacy software-trace fallback.','Activity union includes observed target kernels/copies/memsets only. Missing activity is not proof the whole GPU was idle; other GUI processes, untraced work and profiler overhead are outside this inference.','Readback-to-readback bins are observed envelopes, not exact consumer step_start boundaries; prefill includes loading/cold setup.','Same-engine32 predicted IDs match their unprofiled baselines. No new raw tensor trace or independent numerical accuracy acceptance.','No second profiling attempt, alternate tracing configuration, GPU benchmark or kernel/SDK recompilation.'],gpu_window_released=True)
save(OUT/'summary.json',summary)
images=[ident(OUT/(name+ext)) for name in ['hyle','peer'] for ext in ['.exe','.map','.lib','.exp'] if (OUT/(name+ext)).exists()]
save(OUT/'cleanup-windows.json',dict(root=str(OUT.resolve()),files=images,bytes=sum(x['bytes'] for x in images),retain=['all original objects/libraries and model refs','both nsight reports and SQLite exports','all CSV/JSON/source snapshots/logs/scripts'],delete_executed=False))
print(json.dumps({e:engines[e]['stable_decode7_through31'] for e in engines},indent=2))
print('CLEANUP',len(images),sum(x['bytes'] for x in images))
