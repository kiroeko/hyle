from pathlib import Path
import json,hashlib,collections,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
BASE=ARCH/'ggml-cuda-caller-workspace/candidate-link-plan.json';argv=read(BASE)['command']
selected=[Path(x) for x in argv if Path(x).is_absolute() and Path(x).suffix.lower() in {'.obj','.lib'}]
current={str(x):identity(x) for x in selected};save(OUT/'link-input-identities.json',list(current.values()))
old={x['path']:x for x in read(ARCH/'qwen-fixed-decode/matched-link-plan.json')['inputs']}
retained=[dict(expected=old[k],actual=v,matched=old[k]==v) for k,v in current.items() if k in old]
assert all(x['matched'] for x in retained)
closure=read(ARCH/'ggml-cuda-caller-workspace/closure-identities.json')
for x in closure['files']:assert identity(x['path'])==x,x['path']
# Restrict receipt inventory to the parents of selected objects and explicit
# original closure records. This does not scan SDK/source caches recursively.
parents={p.parent for p in selected if p.suffix.lower()=='.obj'}
metafiles=set()
for parent in parents:
 for p in parent.glob('*.json'):
  if p.stat().st_size<15*1024*1024 and any(s in p.name for s in ['identit','recipe','link','command','source','inputs','manifest']):metafiles.add(p)
metafiles.update([ARCH/'strided-reshape/qwen-link.json',ARCH/'qwen-alias-source-journey/link-plan.json'])
pairs={};seen_sources={}
def collect(x,origin):
 if isinstance(x,list):
  for v in x:collect(v,origin)
 elif isinstance(x,dict):
  s=x.get('source');o=x.get('object')
  if isinstance(s,dict) and isinstance(o,dict) and all(k in s for k in ['path','bytes','sha256']) and all(k in o for k in ['path','bytes','sha256']):
   if o['path'] in current and current[o['path']]==o:pairs.setdefault(o['path'],[]).append(dict(source=s,object=o,receipt=str(origin)))
  elif isinstance(s,str) and isinstance(o,dict) and all(k in o for k in ['path','bytes','sha256']):
   sha=x.get('source_sha256')
   if sha and o['path'] in current and current[o['path']]==o:
    p=Path(s);pairs.setdefault(o['path'],[]).append(dict(source=dict(path=str(p),sha256=sha),object=o,receipt=str(origin)))
  for v in x.values():
   if isinstance(v,(dict,list)):collect(v,origin)
for p in sorted(metafiles):
 try:collect(read(p),p)
 except (ValueError,KeyError,UnicodeError):pass
rows=[]
for obj,values in pairs.items():
 for v in values:
  s=v['source'];p=Path(s['path'])
  if p.is_file():
   a=seen_sources.setdefault(str(p),identity(p));v['actual_source']=a;v['source_matches']=a['sha256']==s['sha256'];rows.append(v)
latest=[]
for obj in pairs:
 matches=[v for v in rows if v['object']['path']==obj]
 good=[v for v in matches if v['source_matches']]
 if good:latest.append(good[0])
 elif matches:latest.append(matches[0])
save(OUT/'source-owner-check.json',dict(selected_objects=sum(p.suffix.lower()=='.obj' for p in selected),matched_receipted_owners=len(latest),source_drift=[x for x in latest if not x['source_matches']],owners=latest,unmapped_objects=[str(p) for p in selected if p.suffix.lower()=='.obj' and str(p) not in pairs]))
save(OUT/'preflight.json',dict(base=identity(BASE),selected_file_inputs=len(current),baseline_identity_matches=len(retained),new_or_replaced_inputs=[v for k,v in current.items() if k not in old],caller_workspace_closure=closure,source_owners_checked=len(latest),source_drift=[x for x in latest if not x['source_matches']],nsys=identity(Path(r'C:\Program Files\NVIDIA Corporation\Nsight Systems 2026.1.3\target-windows-x64\nsys.exe')),no_sdk_native_or_product_compilation=True))
print('selected',len(current),'baseline matched',len(retained),'source owners',len(latest))
print('NEW',[(Path(x['path']).name,x['bytes'],x['sha256']) for x in current.values() if x['path'] not in old])
print('DRIFT',[(x['source']['path'],x['source']['sha256'],x['actual_source']['sha256']) for x in latest if not x['source_matches']])
print('UNMAPPED',[str(p) for p in selected if p.suffix.lower()=='.obj' and str(p) not in pairs])
