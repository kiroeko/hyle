from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
NSYS=Path(r'C:\Program Files\NVIDIA Corporation\Nsight Systems 2026.1.3\target-windows-x64\nsys.exe')

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
HYLE=read(ARCH/'ggml-cuda-caller-workspace/candidate-link-plan.json')['command']
PEER=read(ARCH/'qwen-gpu-comparison/128-prefill/build-plan.json')['link']
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
ENV=windows_compiler_environment({'CMAKE_CXX_COMPILER':HYLE[0].replace('link.exe','cl.exe')})
ENV['VSLANG']='1033';ENV['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in HYLE+PEER if v.lower().endswith('.lib') and Path(v).is_absolute()))+os.pathsep+ENV['PATH']
assert not ENV.get('GGML_CUDA_DISABLE_GRAPHS')
CASE=ARCH/'qwen-gpu-comparison/128-prefill'

def call(tag,args):
 assert not (OUT/(tag+'.command.json')).exists(),'No implicit retry: '+tag
 row=dict(argv=list(map(str,args)),cwd=str(ROOT),started=time.time(),exit=None)
 save(OUT/(tag+'.command.json'),row)
 with (OUT/(tag+'.stdout.log')).open('wb') as so,(OUT/(tag+'.stderr.log')).open('wb') as se:
  proc=subprocess.Popen(row['argv'],cwd=ROOT,env=ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=proc.pid;save(OUT/'live.json',dict(tag=tag,**row));print('START',tag,'PID',proc.pid,flush=True)
  row['exit']=proc.wait()
 row.update(terminal=True,finished=time.time());save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',dict(tag=tag,**row));print('END',tag,'exit',row['exit'],'seconds',round(row['finished']-row['started'],3),flush=True)
 if row['exit']:
  print((OUT/(tag+'.stdout.log')).read_text(errors='replace')[-5000:],flush=True);print((OUT/(tag+'.stderr.log')).read_text(errors='replace')[-5000:],flush=True)
 return row

def link():
 for name,base in [('hyle',HYLE),('peer',PEER)]:
  argv=[v for v in base if not v.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
  assert all(Path(v).is_file() for v in argv if Path(v).is_absolute() and Path(v).suffix.lower() in {'.obj','.lib'})
  argv+=['/OUT:'+str(OUT/(name+'.exe')),'/MAP:'+str(OUT/(name+'.map')),'/IMPLIB:'+str(OUT/(name+'.lib'))]
  save(OUT/(name+'-link-plan.json'),dict(command=argv,only_changes=['OUT','MAP','IMPLIB'],base=str(ARCH/('ggml-cuda-caller-workspace/candidate-link-plan.json' if name=='hyle' else 'qwen-gpu-comparison/128-prefill/build-plan.json'))))
  row=call(name+'-link',argv)
  if row['exit']:raise SystemExit(row['exit'])
 fixed=read(CASE/'fixed-inputs.json')
 assert len(fixed['prompt_ids'])==128 and len(fixed['decode_input_ids'])==31
 assert list(map(int,(CASE/'inputs/prompt.ids').read_text().split()))==fixed['prompt_ids']
 assert list(map(int,(CASE/'decode.ids').read_text().split()))==fixed['decode_input_ids']
 source_freeze=[]
 for relative in ['src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_route_cuda/default_policy.cc','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc','src/compute_provider_ggml_cuda/program.h','tools/qwen35_text/main.cc']:
  source=ROOT/relative;dest=OUT/'baseline-source'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes());source_freeze.append(ident(source))
 model=ARCH/'llama-matched-consumer/Qwen3.5-2B-text-BF16.gguf'
 expected=read(CASE/'build-plan.json')['model_identity_reference'];assert model.stat().st_size==expected['bytes']
 save(OUT/'baseline-freeze.json',dict(status='two_exact_baseline_links_terminal_frozen',hyle=ident(OUT/'hyle.exe'),peer=ident(OUT/'peer.exe'),source_snapshots=source_freeze,source_drift_exceptions=['batch_layout.cc and paged_arena.cc whitespace-only split lines from Linux port; original objects unchanged','public ggml_cuda.h lifetime documentation comment only'],model_reference=expected,model_copied=False,model_rehashed=False,input_identities=[ident(CASE/p) for p in ['fixed-inputs.json','inputs/prompt.ids','inputs/weights.tsv','decode.ids']],nsys=ident(NSYS),trace_flags=['--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node:host-only','--discard-environment=true'],config_difference='graph to node granularity to observe internal CUDA graph kernels; software overhead, not a timing comparison'))
 print('BASELINE FROZEN both links terminal',flush=True)

def profile(name):
 assert name in ['hyle','peer'];assert read(OUT/'baseline-freeze.json')['status']=='two_exact_baseline_links_terminal_frozen'
 if name=='hyle':target=[OUT/'hyle.exe','--inputs',CASE/'inputs','--decode-ids',CASE/'decode.ids','--capacity','256','--progress','direct']
 else:target=[OUT/'peer.exe',ARCH/'llama-matched-consumer/Qwen3.5-2B-text-BF16.gguf',CASE/'fixed-inputs.json',OUT/'peer-result.json']
 argv=[NSYS,'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(OUT/(name+'-trace')),*target]
 return call(name+'-profile',argv)['exit']

def export(name):
 assert read(OUT/(name+'-profile.result.json'))['exit']==0
 return call(name+'-stats',[NSYS,'stats','--report','cuda_api_sum,cuda_gpu_kern_sum','--format','csv','--output',OUT/(name+'-trace'),OUT/(name+'-trace.nsys-rep')])['exit']

if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='link':link()
 elif mode=='profile':raise SystemExit(profile(sys.argv[2]))
 elif mode=='export':raise SystemExit(export(sys.argv[2]))
 else:raise SystemExit('link/profile/export')
