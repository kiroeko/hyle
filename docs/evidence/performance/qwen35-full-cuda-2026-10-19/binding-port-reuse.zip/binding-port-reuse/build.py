"""One actual executable.cc host refresh; retain CPU115/Qwen129 closures."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
BASE=ARCH/'prepare-replay-cold-index/checks/20261019T173829'
spec=importlib.util.spec_from_file_location('binding_reuse_previous',ARCH/'prepare-replay-cold-index/build.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
b,c=previous.b,previous.c
EXACT_TESTS=previous.EXACT_TESTS+['Invocation.RejectsForeignInternalConstOutputAndWrongShapeBindings']


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):raise ValueError('Source/header/recipe changed:'+row['path'])


def prepare(out):
    seal_path=STAGE/'source-freeze.json';seal=c.read(seal_path)
    assert len(seal['files'])==1 and seal['files'][0]['source']=='src/graph/executable.cc'
    source=ROOT/'src/graph/executable.cc';actual=b.identity(source)
    assert all(actual[k]==seal['files'][0]['after'][k]for k in ('bytes','sha256'))
    recipe_path=BASE/'00-graph-executable-identity.json';recipe=c.read(recipe_path)
    assert all(recipe['source'][k]==seal['files'][0]['before'][k]for k in ('bytes','sha256'))
    frozen=[b.identity(p)for p in [Path(__file__),STAGE/'run_tests.py',seal_path,recipe_path,source]]
    dependencies=[]
    for row in recipe['dependencies']:
        path=Path(row['path'])
        if c.key(path)==c.key(source):continue
        if any(path.is_relative_to(ROOT/p)for p in ('src','include')):
            current=b.identity(path)
            if current!=row:raise ValueError('Unchanged actual owner header differs:'+str(path))
            dependencies.append(current);frozen.append(current)
    header=next(r for r in dependencies if c.key(r['path'])==c.key(ROOT/'src/graph/plan_state.h'))
    assert header['sha256']=='1f0f3e1e6d5d35320306f262ac8f4267c0bb3d023d71e16e2f08790b584b0697'
    tag='00-graph-executable';command=b.host_command(recipe['command'],source,tag,out)
    row=dict(tag=tag,kind='host',source=actual,recipe=b.identity(recipe_path),previous_source=recipe['source'],
        old_object=recipe['object'],object=str(out/(tag+'.obj')),command=command,arms=['cpu','qwen'])
    snapshot=out/'compiled-source/src/graph/executable.cc';snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes());frozen.append(b.identity(snapshot))
    bases={arm:c.read(BASE/(arm+'-link-plan.json'))for arm in ('cpu','qwen')}
    cached={c.key(r['path']):r for link in bases.values()for r in link['inputs']}
    assert cached[c.key(recipe['object']['path'])]==recipe['object']
    links={}
    for arm,base in bases.items():
        assert recipe['object']in base['inputs']
        args=[row['object']if c.key(x)==c.key(recipe['object']['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        image=out/(arm+'.exe');args+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[x for x in args if Path(x).is_absolute()and x.lower().endswith(('.obj','.lib'))and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        assert len(inputs)==len(set(map(c.key,inputs)))==(115 if arm=='cpu' else 129)
        links[arm]=dict(command=args,image=str(image),inputs=inputs,replacements=1,new_link_inputs=0)
        frozen.append(b.identity(BASE/(arm+'-link-plan.json')))
    return dict(compile=[row],links=links,cached_inputs=list(cached.values()),frozen=list({c.key(r['path']):r for r in frozen}.values()),
        baseline_images={arm:c.read(BASE/(arm+'-image.json'))for arm in ('cpu','qwen')},
        unchanged_PlanState=header,actual_product_dependencies=dependencies,host_TUs=1,native_TUs=0,
        public_ABI_changed=False,private_header_changed=False,fixtures_refreshed=0,SDK_build=False,GPU_run=False,
        exact_tests=EXACT_TESTS,scope='Reference binding comparison and conditional submission-view writes only; preserve exact descriptions, leases, native carriers, preparation and owner gates.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--build',action='store_true');parser.add_argument('--resume',type=Path);args=parser.parse_args()
    if args.resume:path=args.resume.resolve();out=path.parent;plan=c.read(path)
    else:
        out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S');out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir();plan=prepare(out);path=out/'plan.json';c.save(path,plan)
    print('PLAN',path,flush=True)
    if not args.build:return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row):raise ValueError('Cached link input changed:'+row['path'])
    identities={c.key(r['path']):r for r in plan['cached_inputs']}
    env,_=b.environment(plan['links']['qwen']['command'],[r['path']for r in plan['cached_inputs']],out)
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command']and b.same(old['object'])and all(b.same(d)for d in old['dependencies']):identities[c.key(old['object']['path'])]=old['object'];continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt),row['command'],env,out);check(plan)
        data=c.read(out/(row['tag']+'-deps.json'))['Data'];deps=[b.identity(p)for p in [data['Source'],*data['Includes']]]
        assert plan['unchanged_PlanState']in deps
        record=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=deps);c.save(receipt,record);identities[c.key(record['object']['path'])]=record['object']
    for arm,link in plan['links'].items():
        receipt=out/(arm+'-image.json')
        if receipt.exists()and b.same(c.read(receipt)):continue
        env,_=b.environment(link['command'],link['inputs'],out)
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')))
        c.execute(arm+'-link-'+str(attempt),link['command'],env,out);check(plan)
        c.save(out/(arm+'-link-plan.json'),dict(command=link['command'],inputs=[identities[c.key(p)]for p in link['inputs']]))
        c.save(receipt,b.identity(link['image']))
    for row in plan['cached_inputs']:
        if not b.same(row):raise ValueError('Cached input changed during build:'+row['path'])
    c.save(out/'summary.json',dict(passed=True,host_TUs=1,native_TUs=0,SDK_build=False,GPU_run=False,fixtures_refreshed=0))
    c.save(STAGE/'latest-check.json',dict(plan=str(path)));print('BUILD_COMPLETE',path,flush=True)


if __name__=='__main__':main()
