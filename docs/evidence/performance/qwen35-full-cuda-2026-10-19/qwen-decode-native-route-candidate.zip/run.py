from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
NSYS=Path(r'C:\Program Files\NVIDIA Corporation\Nsight Systems 2026.1.3\target-windows-x64\nsys.exe')
CASE=ARCH/'qwen-gpu-comparison/128-prefill';IMAGE=ARCH/'cuda-native-matvec/candidate.exe'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
BASE=read(ARCH/'ggml-cuda-caller-workspace/candidate-link-plan.json')['command']
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
ENV=windows_compiler_environment({'CMAKE_CXX_COMPILER':BASE[0].replace('link.exe','cl.exe')});ENV['VSLANG']='1033'
ENV['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE if v.lower().endswith('.lib') and Path(v).is_absolute()))+os.pathsep+ENV['PATH'];assert not ENV.get('GGML_CUDA_DISABLE_GRAPHS')
def call(tag,args):
 assert not (OUT/(tag+'.command.json')).exists(),'No implicit retry'
 row=dict(argv=list(map(str,args)),cwd=str(ROOT),started=time.time(),exit=None)
 save(OUT/(tag+'.command.json'),row)
 with (OUT/(tag+'.stdout.log')).open('wb') as so,(OUT/(tag+'.stderr.log')).open('wb') as se:
  proc=subprocess.Popen(row['argv'],cwd=ROOT,env=ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=proc.pid;save(OUT/'live.json',dict(tag=tag,**row));print('START',tag,'PID',proc.pid,flush=True);row['exit']=proc.wait()
 row.update(terminal=True,finished=time.time());save(OUT/(tag+'.result.json'),row);save(OUT/'live.json',dict(tag=tag,**row));print('END',tag,'exit',row['exit'],'seconds',round(row['finished']-row['started'],3),flush=True)
 if row['exit']:print((OUT/(tag+'.stderr.log')).read_text(errors='replace'),flush=True)
 return row['exit']
def profile():
 receipts=[read(ARCH/'cuda-native-matvec'/n) for n in ['tensor-program-identity.json','default-policy-identity.json']]
 for r in receipts:
  assert ident(r['object']['path'])==r['object']
  assert ident(r['source']['path'])==r['source']
 save(OUT/'input-identities.json',dict(image=ident(IMAGE),new_host_owners=receipts,link_plan=ident(ARCH/'cuda-native-matvec/candidate-link-2-plan.json'),baseline=ident(ARCH/'qwen-decode-native-route/summary.json'),inputs=[ident(CASE/p) for p in ['fixed-inputs.json','inputs/prompt.ids','inputs/weights.tsv','decode.ids']],compiled=False,relinked=False,sdk_copied=False))
 return call('candidate-profile',[NSYS,'profile','--trace=cuda','--sample=none','--cpuctxsw=none','--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(OUT/'candidate-trace'),IMAGE,'--inputs',CASE/'inputs','--decode-ids',CASE/'decode.ids','--capacity','256','--progress','direct'])
def export():
 assert read(OUT/'candidate-profile.result.json')['exit']==0
 return call('candidate-stats',[NSYS,'stats','--report','cuda_api_sum,cuda_gpu_kern_sum','--format','csv','--output',OUT/'candidate-trace',OUT/'candidate-trace.nsys-rep'])
if __name__=='__main__':raise SystemExit(profile() if sys.argv[1]=='profile' else export())
