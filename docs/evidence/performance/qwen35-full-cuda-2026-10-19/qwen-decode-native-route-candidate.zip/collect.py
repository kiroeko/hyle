from pathlib import Path
import hashlib
import json
import shutil
import sqlite3

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')


def ident(p):
    p = Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


inputs = read(OUT / 'input-identities.json')
sources = []
for owner in inputs['new_host_owners']:
    original = Path(owner['source']['path'])
    relative = original.relative_to(ROOT)
    frozen = ARCH / 'cuda-native-matvec/candidate' / relative
    assert ident(frozen)['sha256'] == owner['source']['sha256']
    assert frozen.stat().st_size == owner['source']['bytes']
    destination = OUT / 'source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(frozen, destination)
    sources.append(dict(compile_source_receipt=owner['source'], frozen_source=ident(frozen),
                        snapshot=str(destination.relative_to(OUT)).replace('\\', '/'),
                        canonical_after_profile=ident(original)))
save(OUT / 'source-identities.json', dict(owners=sources,
    explanation='At profile launch the two canonical sources and objects matched compile receipts. '
                'Root subsequently restored product source; archive snapshots therefore come from '
                'the existing frozen candidate copies with the exact compiled hashes. '
                'No canonical source or old stage was overwritten. No repeated global closure audit.'))
for name in ['candidate-link-2-plan.json', 'tensor-program-identity.json', 'default-policy-identity.json']:
    shutil.copyfile(ARCH / 'cuda-native-matvec' / name, OUT / name)
con = sqlite3.connect((OUT / 'candidate-trace.sqlite').as_uri() + '?mode=ro', uri=True)
con.row_factory = sqlite3.Row
save(OUT / 'environment.json', dict(source='actual candidate Nsight SQLite, no new hardware probe',
    gpu=[dict(x) for x in con.execute('select * from TARGET_INFO_GPU')],
    devices=[dict(x) for x in con.execute('select * from TARGET_INFO_CUDA_DEVICE')]))
summary = read(OUT / 'summary.json')
review = read(OUT / 'candidate-matrix-review.json')
summary['matrix_review'] = ident(OUT / 'candidate-matrix-review.json')
summary['source_identity'] = ident(OUT / 'source-identities.json')
summary['environment'] = ident(OUT / 'environment.json')
summary['findings'].extend([
    'All stable candidate bins have output-row grids16x36,512x12,2048x66,4096x6,6144x66,248320x1. '
    'Peer matches all row counts except6144:18 nonfused plus24 fused kernels instead of66 nonfused. '
    'The exact24-launch difference is localized to this grid/fusion group, without per-node argument capture.',
    'The final projection in every bin has grid248320; actual embedding weight is BF16[248320,2048] '
    'and the frozen consumer computes logits from that weight. This identifies the LM-head projection.',
    'LM-head software-profile kernel median: candidate2.107723ms, original Hyle2.101962ms, '
    'peer2.111434ms. Candidate LM-head is27.0775% of summed projection kernel durations '
    '(not wall time or critical-path share).',
    'Other candidate mmvf per-instance median observations by output-row grid: '
    '16:1.344us,512:5.824us,2048:19.295us,4096:36.320us,6144:54.3835us.',
    'Scalar cast summed-duration per-bin medians: BF16->F32 candidate0.835694ms versus baseline0.686794ms; '
    'F32->BF16 candidate0.481339ms versus baseline0.331131ms. These instrumented observations '
    'do not establish an unprofiled cost delta or additive critical-path time.'
])
summary['limits'].append('The archived old mmvf.cu source explains row-grid and fusion-template rules, '
    'but its existing materialized snapshot is not a newly verified source-to-linked-library receipt. '
    'LM-head identification also uses the actual trace ordering, weight shape and frozen consumer.')
save(OUT / 'summary.json', summary)
print('Frozen candidate source snapshots:', len(sources))
print('Hardware:', read(OUT / 'environment.json')['gpu'][0]['name'])
