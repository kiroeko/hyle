from pathlib import Path
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run():
    assert not(OUT/'run.result.json').exists()
    original=read(ARCH/'qwen-fixed-decode/matched-link-plan.json')
    sys.path.insert(0,str(ROOT/'scripts'))
    from hyle_environment import windows_compiler_environment
    env=windows_compiler_environment({'CMAKE_CXX_COMPILER':original['command'][0].replace('link.exe','cl.exe')})
    libraries=[Path(x)for x in original['command']if x.endswith('.lib')and Path(x).is_absolute()and Path(x).is_file()]
    env['PATH']=os.pathsep.join(dict.fromkeys(str(x.parent)for x in libraries))+os.pathsep+env['PATH']
    exe=ARCH/'qwen-native-graph-observation/qwen-observe.exe';inputs=ARCH/'qwen-fixed-decode/science-inputs'
    argv=[str(exe),'--inputs',str(inputs),'--steps','64','--capacity','256','--progress','direct']
    row=dict(argv=argv,started=time.time(),binary=ident(exe),prompt=read(ARCH/'qwen-fixed-decode/fixed-inputs.json')['prompt'],prompt_ids=read(ARCH/'qwen-fixed-decode/fixed-inputs.json')['prompt_ids'],fixed_decode=False,tensor_trace=False,reference_or_oracle_loaded=False)
    save(OUT/'run.command.json',row)
    with(OUT/'stdout.log').open('wb')as so,(OUT/'stderr.log').open('wb')as se:
        p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid;save(OUT/'live.json',row);row['exit']=p.wait()
    row.update(terminal=True,finished=time.time());save(OUT/'run.result.json',row);save(OUT/'live.json',row)
    print('normal-greedy',row['exit'],round(row['finished']-row['started'],3),flush=True)
    if row['exit']:print((OUT/'stderr.log').read_text(errors='replace')[-6000:]);raise SystemExit(1)
    result=json.loads((OUT/'stdout.log').read_text().splitlines()[-1]);assert result['fixed_decode']is False and not result['decode_input_ids']
    save(OUT/'generation.json',result)
def decode():
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained('C:/Users/kiro/Downloads/Qwen3.5-2B',local_files_only=True,trust_remote_code=False)
    result=read(OUT/'generation.json');tokens=result['generated_ids'];text=tokenizer.decode(tokens,skip_special_tokens=True)
    (OUT/'generated.txt').write_text(text,encoding='utf-8')
    rows=[]
    for line in(OUT/'stderr.log').read_text().splitlines():
        if not(line.startswith('prefill ')or line.startswith('decode')):continue
        values=line.split();r={'phase':values[0]}
        for value in values[1:]:
            key,val=value.split('=',1);r[key]=val if key=='progress'else float(val)if 'seconds'in key else int(val)
        rows.append(r)
    decodes=rows[1:];warm=[r for r in decodes if int(r['phase'].removeprefix('decode'))>=7]
    save(OUT/'summary.json',dict(prompt=read(OUT/'run.command.json')['prompt'],text=text,generated_token_count=len(tokens),decode_steps=len(decodes),finished_at_eos=bool(tokens and tokens[-1]==248044),limit=64,visible_tokens=result['visible_tokens'],resident_text_tensors=result['text_tensors'],resident_text_weight_bytes=3763655360,all_model_math_cuda_context=True,normal_greedy=True,forced_input_tape=False,reference_loaded=False,prefill=rows[0],decode_step_seconds=sum(r['step_seconds']for r in decodes),decode_tokens_per_second=len(decodes)/sum(r['step_seconds']for r in decodes)if decodes else None,post_warmup_decode_steps=len(warm),post_warmup_tokens_per_second=len(warm)/sum(r['step_seconds']for r in warm)if warm else None,tokenizer_only_cpu=True,not_a_fair_comparative_benchmark=True,phases=rows))
    print(text,flush=True)
    print('tokens',len(tokens),'decodes',len(decodes),'eos',bool(tokens and tokens[-1]==248044),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='run':run()
    elif sys.argv[1]=='decode':decode()
    else:raise ValueError(sys.argv[1])
