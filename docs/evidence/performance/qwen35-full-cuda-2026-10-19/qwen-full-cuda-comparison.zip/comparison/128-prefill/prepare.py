"""Prepare exact128 benchmark inputs and one flexible public-API host artifact; never run inference."""
import difflib
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
ARCH=OUT.parents[1]
sys.path.insert(0,str(ARCH/'qwen-peer-first-match'))
import run_pair as helpers

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def ident(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

def prepare():
    parent=ARCH/'qwen-peer-first-match/fixed_prefix_gpu_greedy.cpp'
    assert ident(parent)['sha256']=='1985c71cfe9d0cce4dfec3a8aecad6e8b1f20807dd892c2e64b04927b6cd412e'
    text=parent.read_text();before=text
    edits=[
        ('#include <array>','#include <algorithm>\n#include <array>'),
        ('llama_batch value = llama_batch_init(64, 0, 1);',
         'llama_batch value;\n    explicit Batch(int32_t capacity) : value(llama_batch_init(capacity, 0, 1)) {}'),
        ('const auto targets = fixed.at("target_ids").get<std::vector<llama_token>>();\n'
         '    if (prompt.size() != 21 || decode.size() != 31 || targets.size() != 32)\n'
         '        throw std::runtime_error("expected 21 prompt IDs, 31 fixed decode IDs, 32 target IDs");',
         'const auto targets = fixed.value("target_ids", std::vector<llama_token>{});\n'
         '    if (prompt.empty() || prompt.size() > 224 || decode.size() != 31 || (!targets.empty() && targets.size() != 32))\n'
         '        throw std::runtime_error("expected 1..224 prompt IDs, 31 fixed decode IDs and optional 32 target IDs");\n'
         '    const auto batch_capacity = static_cast<std::uint32_t>(std::max<std::size_t>(64, prompt.size()));'),
        ('context_params.n_batch = 64;\n    context_params.n_ubatch = 64;',
         'context_params.n_batch = batch_capacity;\n    context_params.n_ubatch = batch_capacity;'),
        ('Batch batch;','Batch batch(static_cast<int32_t>(batch_capacity));'),
        ('result["context_capacity"] = actual_context;',
         'result["context_capacity"] = actual_context;\n    result["configured_batch_capacity"] = batch_capacity;\n'
         '    result["quality_targets_available"] = !targets.empty();'),
    ]
    for a,b in edits:
        assert text.count(a)==1,(a,text.count(a))
        text=text.replace(a,b)
    source=OUT/'peer_benchmark.cpp'
    source.write_text(text,encoding='utf-8',newline='\n')
    (OUT/'peer-benchmark.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),
        fromfile='retained-short/fixed_prefix_gpu_greedy.cpp',tofile='flexible/peer_benchmark.cpp')),encoding='utf-8',newline='\n')
    original=read(ARCH/'qwen-peer-first-match/peer-full-cuda-greedy-plan.json')
    obj=OUT/'peer-benchmark.obj';image=OUT/'peer-benchmark.exe'
    cc=[str(source) if a==str(parent) else '/Fo'+str(obj) if a.startswith('/Fo') else a for a in original['compile']]
    link=[]
    for arg in original['link']:
        if arg.startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.startswith('/MAP:'):arg='/MAP:'+str(OUT/'peer-benchmark.map')
        elif arg==str(ARCH/'qwen-peer-first-match/peer-full-cuda-greedy.obj'):arg=str(obj)
        link.append(arg)
    save('build-plan.json',dict(source=ident(source),parent_source=ident(parent),compile=cc,link=link,
        native_libraries=original['native_libraries'],model_identity_reference=original['model_identity_reference'],
        only_changes='Flexible1..224 prompt; original decode31/steps32; optional targets; batch/ubatch=max64,promptRows. Original GPU greedy, loading/memory/step endpoints and math unchanged.',
        run_recipe=[str(image),original['example_run'][1],str(OUT/'fixed-inputs.json'),str(OUT/'peer-result.json')],
        inference_run=False))

def inputs():
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    from transformers import AutoTokenizer
    model=Path('C:/Users/kiro/Downloads/Qwen3.5-2B')
    tokenizer=AutoTokenizer.from_pretrained(str(model),local_files_only=True,trust_remote_code=False)
    text=(
        'Plants capture energy from sunlight through photosynthesis. Chlorophyll pigments absorb photons and transfer '
        'excitation energy to reaction centers. Water supplies electrons, and oxygen is released when water molecules '
        'are split. Electron transport builds a proton gradient across a membrane, allowing an enzyme to produce ATP. '
        'Other reactions supply reducing power that helps convert carbon dioxide into organic compounds. The carbon '
        'cycle connects these cellular reactions with ecosystems, soils, and the atmosphere. Temperature, water, light, '
        'and mineral availability can each limit plant growth. A controlled experiment changes one condition while '
        'keeping the others comparable, and repeated measurements help distinguish a consistent response from random '
        'variation. Researchers also measure respiration because cells consume stored chemical energy during the day '
        'and at night. Leaves are therefore active chemical systems rather than simple collectors of sunlight. Their '
        'internal structures balance energy capture, gas exchange, transport, and protection against environmental stress.'
    )
    encoded=tokenizer.encode(text,add_special_tokens=False)
    assert len(encoded)>=128
    ids=encoded[:128]
    decoded=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    fixed=read(ARCH/'qwen-fixed-decode/fixed-inputs.json')
    decoded_ids=fixed['decode_input_ids'];assert len(decoded_ids)==31
    path=OUT/'inputs';path.mkdir(exist_ok=True)
    manifest=ARCH/'qwen-fixed-decode/science-inputs/weights.tsv'
    (path/'weights.tsv').write_bytes(manifest.read_bytes())
    (path/'prompt.ids').write_text(' '.join(map(str,ids))+'\n',encoding='ascii',newline='\n')
    (OUT/'decode.ids').write_text(' '.join(map(str,decoded_ids))+'\n',encoding='ascii',newline='\n')
    (OUT/'source-text.txt').write_text(text+'\n',encoding='utf-8',newline='\n')
    (OUT/'prompt-128-text.txt').write_text(decoded,encoding='utf-8',newline='\n')
    save('fixed-inputs.json',dict(prompt=decoded,prompt_ids=ids,decode_input_ids=decoded_ids,target_ids=[],
        benchmark_only=True,not_a_quality_prompt=True,
        construction='First128 tokens of a newly written scientific paragraph, no chat template or BOS insertion. Same original science31 fixed decode inputs; not a coherent-answer quality evaluation.',
        source_text=str(OUT/'source-text.txt')))
    save('input-receipt.json',dict(tokenizer=dict(path=str(model),class_name=type(tokenizer).__name__,
        is_fast=tokenizer.is_fast,transformers=importlib.metadata.version('transformers'),
        tokenizers=importlib.metadata.version('tokenizers'),tokenizer_json=ident(model/'tokenizer.json'),
        local_files_only=True,trust_remote_code=False),
        source_text=ident(OUT/'source-text.txt'),source_token_count=len(encoded),prefix_tokens=128,
        prompt_ids=ids,decode_inputs=decoded_ids,visible_lengths='128..159',context_capacity=256,
        decoded_text_roundtrip=tokenizer.encode(decoded,add_special_tokens=False)==ids,
        prompt_file=ident(path/'prompt.ids'),fixed_inputs=ident(OUT/'fixed-inputs.json'),decode_file=ident(OUT/'decode.ids'),
        manifest=ident(path/'weights.tsv'),original_manifest=ident(manifest),
        weights_copied=False,quality_targets_supplied=False,inference_run=False))
    print('Prepared exact128 prompt from',len(encoded),'tokens;',type(tokenizer).__name__,'no weights copied')

def build():
    plan=read(OUT/'build-plan.json');assert ident(plan['source']['path'])==plan['source']
    env=helpers.b.msvc_environment()
    for tag,command in [('001-peer-benchmark-compile',plan['compile']),('002-peer-benchmark-link',plan['link'])]:
        assert not (OUT/(tag+'.result.json')).exists()
        started=time.time();save(tag+'.command.json',dict(argv=command,started=started))
        with (OUT/(tag+'.stdout.log')).open('wb') as stdout,(OUT/(tag+'.stderr.log')).open('wb') as stderr:
            process=subprocess.Popen(command,cwd=helpers.b.WORKSPACE,env=env,stdout=stdout,stderr=stderr)
            rc=process.wait()
        save(tag+'.result.json',dict(argv=command,exit=rc,seconds=time.time()-started,terminal=True))
        print(tag,rc,round(time.time()-started,3),flush=True)
        if rc:
            print((OUT/(tag+'.stdout.log')).read_text(errors='replace'))
            print((OUT/(tag+'.stderr.log')).read_text(errors='replace'))
            raise SystemExit(rc)
    save('peer-benchmark-image.json',dict(source=plan['source'],object=ident(OUT/'peer-benchmark.obj'),
        image=ident(OUT/'peer-benchmark.exe'),map=ident(OUT/'peer-benchmark.map'),
        model_identity_reference=plan['model_identity_reference'],native_libraries=plan['native_libraries'],
        batch128_is_single_ubatch=True,inference_run=False))

if __name__=='__main__':
    {'prepare':prepare,'inputs':inputs,'build':build}[sys.argv[1]]()
