"""Package completed measurements only. No inference, rebuild, copy of weights, or cleanup."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/qwen-full-cuda-comparison.zip'
ALLOWED = {'.py', '.json', '.md', '.cc', '.cpp', '.h', '.tsv', '.txt', '.ids', '.log', '.csv', '.diff', '.ps1'}
EXCLUDED = {'.exe', '.map', '.lib', '.exp', '.obj', '.pyc', '.pdb', '.dll', '.so', '.a', '.o', '.gguf', '.zip'}

def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    assert sys.argv[1:] == ['--write']
    # Every receipt is from an already terminal process; do not infer completion from stdout.
    terminals = []
    for case, count in [(STAGE, 8), (STAGE / '128-prefill', 6)]:
        for index in range(1, count + 1):
            matches = list(case.glob(f'{index:02d}-*/result.json'))
            assert len(matches) == 1, (case, index)
            row = read(matches[0])
            assert row['terminal'] and row['exit'] == 0, str(matches[0])
            terminals.append(str(matches[0].relative_to(STAGE)))
    summary = read(STAGE / 'comparison-summary.json')
    assert summary['short_prompt']['predicted_token_agreements'] == 30
    assert summary['prefill128']['predicted_token_agreements'] == 32
    assert not DEST.exists(), 'Never overwrite an existing evidence archive'
    selected = {}
    for directory, prefix in [(STAGE, 'comparison'), (STAGE.parent / 'qwen-gpu-generation', 'normal-generation')]:
        for path in sorted(directory.rglob('*')):
            if '__pycache__' in path.parts or not path.is_file() or path.name == 'archive-receipt.json':
                continue
            assert not path.is_symlink(), str(path)
            if path.suffix.lower() in EXCLUDED:
                continue
            assert path.suffix.lower() in ALLOWED, str(path)
            selected[prefix + '/' + path.relative_to(directory).as_posix()] = path
    # Include the exact short input recipe; referenced safetensors remain external.
    original = STAGE.parent / 'qwen-fixed-decode'
    for name in ['fixed-inputs.json', 'science-decode.ids', 'science-inputs/prompt.ids', 'science-inputs/weights.tsv']:
        selected['short-inputs/' + name] = original / name
    selected['product-consumer/main.cc'] = ROOT / 'tools/qwen35_text/main.cc'
    selected['product-consumer/README.md'] = ROOT / 'tools/qwen35_text/README.md'
    assert (ROOT / 'tools/qwen35_text/main.cc').read_bytes() == (STAGE / 'candidate/main.cc').read_bytes()
    manifest = dict(schema='hyle.qwen.full-cuda-comparison.archive.v1',
        scope='Two prompt lengths; three paired fresh-process runs each; short extra no-monitor pair; one normal greedy generation. No profiler throughput, quality acceptance, or binary/model copies.',
        completed_measurement_receipts=terminals, missing_receipts=0,
        inputs='Same source BF16 text weights, own state, exact fixed prefix; intermediate precision differs.',
        entries=[dict(name=name, source=str(path), **identity(path.read_bytes())) for name, path in sorted(selected.items())],
        omitted_extensions=sorted(EXCLUDED),
        receipt='archive-receipt.json is written after exclusive archive creation and verification')
    total = sum(row['bytes'] for row in manifest['entries'])
    assert total < 20 * 1024**2, total
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for row in manifest['entries']:
            data = selected[row['name']].read_bytes()
            assert identity(data) == {k: row[k] for k in ['bytes', 'sha256']}, row['name']
            archive.writestr(row['name'], data)
        archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(manifest['entries']) + 1
        for row in manifest['entries']:
            expected = {k: row[k] for k in ['bytes', 'sha256']}
            assert identity(archive.read(row['name'])) == expected, row['name']
            assert identity(selected[row['name']].read_bytes()) == expected, row['name']
    receipt = dict(path=str(DEST), **identity(DEST.read_bytes()), entries=len(manifest['entries'])+1,
        raw_payload_bytes=total, terminal_runs=len(terminals), crc_verified=True, all_sha256_verified=True,
        source_drift=False, binaries_models_objects_copied=False, deleted_files=0)
    (STAGE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
    main()
