from pathlib import Path
import json,statistics
OUT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def stats(values):
    return dict(median=statistics.median(values),min=min(values),max=max(values),values=values)
def summarize(folder):
    rows=[]
    for stage in sorted(folder.glob('0[1-6]-*')):
        r=read(stage/'metrics.json');run=read(stage/'result.json');mem=read(stage/'memory.json')
        r['trial']=stage.name;r['process_wall_seconds']=(run['finished_perf_ns']-run['popen_perf_ns'])/1e9
        for name,key in [('ready_before_prefill','process_to_ready_seconds'),('prefill_complete','process_to_first_token_seconds')]:
            mark=next(x for x in run['markers']if x['name']==name);r[key]=(mark['timestamp_ns']-run['popen_perf_ns'])/1e9
        begin=next(x['timestamp_ns']for x in run['markers']if x['name']=='prefill_complete')
        end=next(x['timestamp_ns']for x in run['markers']if x['name']=='inference_complete')
        samples=[x for x in mem['samples']if begin<=x['timestamp_ns']<=end and x.get('process_running')and x.get('gpu_dedicated_available')and x.get('psapi_available')]
        assert samples,stage
        r['inference_memory_sample_window']=dict(samples=len(samples),scope='after first-token marker through final-token marker, excluding post-exit samples',working_set_bytes=stats([x['working_set_bytes']for x in samples]),private_commit_bytes=stats([x['private_commit_bytes']for x in samples]),gpu_dedicated_bytes=stats([x['gpu_dedicated_bytes']for x in samples]),gpu_shared_bytes=stats([x['gpu_shared_bytes']for x in samples]))
        rows.append(r)
    assert len(rows)==6
    engines={}
    for name in ['hyle','llama']:
        own=[r for r in rows if r['engine']==name];assert len(own)==3
        assert all(r['predicted_ids']==own[0]['predicted_ids']for r in own)
        keys=['prefill_tokens_per_second','decode_tokens_per_second','stable_decode_tokens_per_second','process_to_ready_seconds','process_to_first_token_seconds']
        engines[name]={k:stats([r[k]for r in own])for k in keys}
        engines[name]['loading']={k:stats([r['loading'][k]for r in own])for k in ['model_load_seconds','startup_to_ready_seconds','first_token_elapsed_seconds']}
        engines[name]['memory_peak_bytes']={k:stats([r['memory_peaks'][k]for r in own])for k in own[0]['memory_peaks']}
        engines[name]['inference_current_memory_bytes']={k:stats([r['inference_memory_sample_window'][k]['median']for r in own])for k in ['working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes']}
        payload=3763655360 if name=='hyle'else 3764747520
        engines[name]['effective_payload_GiB_per_second']=payload/(1024**3)/engines[name]['loading']['model_load_seconds']['median']
    a=next(r for r in rows if r['engine']=='hyle')['predicted_ids'];b=next(r for r in rows if r['engine']=='llama')['predicted_ids']
    result=dict(prompt_tokens=rows[0]['prompt_tokens'],decode_steps=31,stable_window='decode7..31, excludes first six real decode steps; no synthetic warmup',stable_decode_steps=25,context_capacity=256,engines=engines,predicted_token_agreements=sum(x==y for x,y in zip(a,b)),mismatches=[dict(phase=i,visible_tokens=rows[0]['prompt_tokens']+i,hyle=x,llama=y)for i,(x,y)in enumerate(zip(a,b))if x!=y],trials=rows)
    result['ratios_hyle_over_llama']={k:engines['hyle'][k]['median']/engines['llama'][k]['median']for k in ['prefill_tokens_per_second','decode_tokens_per_second','stable_decode_tokens_per_second','process_to_ready_seconds']}
    save(folder/'summary.json',result);return result
result={'short_prompt':summarize(OUT)}
if(OUT/'128-prefill/06-llama/metrics.json').is_file():result['prefill128']=summarize(OUT/'128-prefill')
save(OUT/'comparison-summary.json',result)
for case,report in result.items():
    print(case,report['prompt_tokens'],'tokens')
    for name,row in report['engines'].items():
        print(name,'load',row['loading']['model_load_seconds']['median'],'process_ready',row['process_to_ready_seconds']['median'],'pp',row['prefill_tokens_per_second']['median'],'decode',row['decode_tokens_per_second']['median'],'stable',row['stable_decode_tokens_per_second']['median'],'GPU_GiB',row['memory_peak_bytes']['sampled_peak_gpu_dedicated_bytes']['median']/1024**3,'peak_WS_GiB',row['memory_peak_bytes']['observed_os_peak_working_set_bytes']['median']/1024**3)
