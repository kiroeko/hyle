from pathlib import Path
import hashlib,json,os,re,subprocess,sys,threading,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
sys.path.insert(0,str(OUT/'memory-probe'))
from memory_probe import MemoryProbe
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
base=read(OUT/'hyle-link-plan.json')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':base['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent)for x in base['command']if x.endswith('.lib')and Path(x).is_absolute()))+os.pathsep+env['PATH']
assert not env.get('GGML_CUDA_DISABLE_GRAPHS'),'native graphs unexpectedly disabled'
LONG=len(sys.argv)>1 and sys.argv[1].startswith('long-')
CASE=OUT/'128-prefill'if LONG else OUT
FIXED=CASE/'fixed-inputs.json'if LONG else ARCH/'qwen-fixed-decode/fixed-inputs.json'
def marker(line):
    if line.startswith('weights_load_seconds='):return 'model_loaded'
    if line.startswith('initialized '):return 'ready_before_prefill'
    if line.startswith('prefill tokens='):return 'prefill_complete'
    if line.startswith('decode31 tokens='):return 'inference_complete'
    if line.startswith('measure_memory '):
        match=re.search(r'\bname=(\S+)',line)
        if match:return match.group(1)
    return None
def trial(index,engine,monitor=True):
    stage=CASE/(f'{index:02d}-'+engine);stage.mkdir(exist_ok=False)
    if engine=='hyle':
        inputs=CASE/'inputs'if LONG else ARCH/'qwen-fixed-decode/science-inputs'
        tape=CASE/'decode.ids'if LONG else ARCH/'qwen-fixed-decode/science-decode.ids'
        argv=[OUT/'hyle-qwen.exe','--inputs',inputs,'--decode-ids',tape,'--capacity','256','--progress','direct']
    else:
        image=CASE/'peer-benchmark.exe'if LONG else ARCH/'qwen-peer-first-match/peer-full-cuda-greedy.exe'
        argv=[image,ARCH/'llama-matched-consumer/Qwen3.5-2B-text-BF16.gguf',FIXED,stage/'peer-result.json']
    assert Path(argv[0]).is_file(),argv[0]
    row=dict(engine=engine,argv=list(map(str,argv)),binary=ident(argv[0]),fixed_inputs=ident(FIXED),memory_monitor=monitor,started=time.time(),markers=[])
    save(stage/'command.json',row)
    def reader(stream,output):
        for raw in iter(stream.readline,b''):
            output.write(raw)
            line=raw.decode('utf-8',errors='replace').rstrip()
            kind=marker(line)
            if kind:row['markers'].append(dict(name=kind,timestamp_ns=time.perf_counter_ns(),unix_time_ns=time.time_ns(),line=line))
    with MemoryProbe(interval_s=.05)as memory,(stage/'stdout.log').open('wb')as so,(stage/'stderr.log').open('wb')as se:
        row['popen_perf_ns']=time.perf_counter_ns();row['popen_unix_ns']=time.time_ns()
        p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid;save(CASE/'live.json',dict(**row,stage=str(stage)))
        thread=threading.Thread(target=reader,args=(p.stderr,se),daemon=True);thread.start()
        if monitor:memory.start(p.pid)
        row['exit']=p.wait();thread.join()
        if monitor:memory.stop();save(stage/'memory.json',memory.result())
        row['finished_perf_ns']=time.perf_counter_ns()
    row.update(terminal=True,finished=time.time());save(stage/'result.json',row);save(CASE/'live.json',row)
    print(index,engine,'exit',row['exit'],'wall',round(row['finished']-row['started'],3),flush=True)
    if row['exit']:
        print((stage/'stderr.log').read_text(errors='replace')[-6000:]);raise SystemExit(1)
    result=analyze_trial(stage,engine)
    print('  ready',round(result['loading']['startup_to_ready_seconds'],4),'pp',round(result['prefill_tokens_per_second'],2),'decode',round(result['decode_tokens_per_second'],2),'warm',round(result['stable_decode_tokens_per_second'],2),flush=True)
def analyze_trial(stage,engine):
    if engine=='hyle':
        raw=json.loads((stage/'stdout.log').read_text().splitlines()[-1]);phases=[];loading={}
        for line in(stage/'stderr.log').read_text().splitlines():
            if line.startswith('weights_load_seconds='):loading['model_load_seconds']=float(line.split('=',1)[1])
            if line.startswith('first_token_elapsed_seconds='):loading['first_token_elapsed_seconds']=float(line.split('=',1)[1])
            if line.startswith('initialized '):loading.update({k:float(v)for k,v in(item.split('=',1)for item in line.split()[1:])})
            if not re.match(r'^(prefill|decode\d+)\s+tokens=',line):continue
            parts=line.split();fields=dict(item.split('=',1)for item in parts[1:]);index=0 if parts[0]=='prefill'else int(parts[0][6:])
            phases.append(dict(phase=index,input_tokens=int(fields['tokens']),visible_tokens=int(fields['visible']),predicted_id=int(fields['next']),step_seconds=float(fields['step_seconds']),submit_to_token_seconds=float(fields['seconds']),submit_seconds=float(fields['submit_seconds'])))
        ids=raw['generated_ids'];assert raw['fixed_decode']and raw['decode_input_ids']==read(FIXED)['decode_input_ids']
    else:
        raw=read(stage/'peer-result.json');phases=raw['phases'];loading=raw['loading'];ids=raw['predicted_ids']
        assert raw['prompt_ids']==read(FIXED)['prompt_ids']and raw['decode_input_ids']==read(FIXED)['decode_input_ids']
        assert raw['context_capacity']==256
    assert len(phases)==len(ids)==32
    prompt_count=len(read(FIXED)['prompt_ids'])
    assert [r['visible_tokens']for r in phases]==list(range(prompt_count,prompt_count+32))
    assert all(r['step_seconds']>0 for r in phases)
    decode=phases[1:];stable=phases[7:]
    result=dict(engine=engine,loading=loading,prompt_tokens=prompt_count,decode_steps=31,stable_decode_steps=25,context_capacity=256,prefill_seconds=phases[0]['step_seconds'],prefill_tokens_per_second=prompt_count/phases[0]['step_seconds'],decode_seconds=sum(r['step_seconds']for r in decode),decode_tokens_per_second=len(decode)/sum(r['step_seconds']for r in decode),stable_decode_seconds=sum(r['step_seconds']for r in stable),stable_decode_tokens_per_second=len(stable)/sum(r['step_seconds']for r in stable),predicted_ids=ids,phases=phases)
    if(stage/'memory.json').is_file():result['memory_peaks']=read(stage/'memory.json')['peaks']
    save(stage/'metrics.json',result);return result
if __name__=='__main__':
    action=sys.argv[1].removeprefix('long-')
    if action=='first':trial(1,'hyle');trial(2,'llama')
    elif action=='remaining':
        for index,engine in [(3,'llama'),(4,'hyle'),(5,'hyle'),(6,'llama')]:trial(index,engine)
    elif action=='unmonitored':trial(7,'hyle',False);trial(8,'llama',False)
    else:raise ValueError(sys.argv[1])
