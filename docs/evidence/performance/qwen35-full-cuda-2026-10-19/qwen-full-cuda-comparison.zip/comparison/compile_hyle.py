from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];ARCH=OUT.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
base=read(ARCH/'qwen-fixed-decode/matched-link-plan.json')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':base['command'][0].replace('link.exe','cl.exe')})
env['PATH']=os.pathsep.join(dict.fromkeys(str(Path(x).parent)for x in base['command']if x.endswith('.lib')and Path(x).is_absolute()))+os.pathsep+env['PATH']
def call(tag,argv,outputs):
    assert not(OUT/(tag+'.result.json')).exists()
    row=dict(argv=list(map(str,argv)),started=time.time());save(OUT/(tag+'.command.json'),row)
    with(OUT/(tag+'.stdout.log')).open('wb')as so,(OUT/(tag+'.stderr.log')).open('wb')as se:
        p=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid']=p.pid;save(OUT/'build-live.json',row);row['exit']=p.wait()
    row.update(terminal=True,finished=time.time(),outputs=[ident(p)for p in outputs if Path(p).is_file()]);save(OUT/(tag+'.result.json'),row)
    print(tag,row['exit'],round(row['finished']-row['started'],3),flush=True)
    if row['exit']:print((OUT/(tag+'.stdout.log')).read_text(errors='replace')[-6000:]);print((OUT/(tag+'.stderr.log')).read_text(errors='replace')[-6000:]);raise SystemExit(1)
sources=[];diff=[]
for name in ['main.cc','README.md']:
    src=ROOT/'tools/qwen35_text'/name;before=OUT/'before'/name;after=OUT/'candidate'/name
    after.parent.mkdir(exist_ok=True);after.write_bytes(src.read_bytes())
    sources.append(dict(relative='tools/qwen35_text/'+name,before=ident(before),candidate=ident(after)))
    diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),after.read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='candidate/'+name))
save(OUT/'hyle-source-identities.json',sources);(OUT/'hyle-source.diff').write_text(''.join(diff),encoding='utf-8')
argv=read(ARCH/'qwen-fixed-decode/compile-consumer.command.json')['argv']
argv=[x for x in argv if not x.lower().startswith('/fo')]
i=argv.index('/sourceDependencies');argv[i+1]=str(OUT/'hyle-consumer.deps.json');argv.append('/Fo'+str(OUT/'hyle-consumer.obj'))
call('compile-hyle',argv,[OUT/'hyle-consumer.obj',OUT/'hyle-consumer.deps.json'])
argv=[str(OUT/'hyle-consumer.obj')if x==str(ARCH/'qwen-fixed-decode/consumer.obj')else x for x in base['command']]
assert str(OUT/'hyle-consumer.obj')in argv
argv=[x for x in argv if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
argv+=['/OUT:'+str(OUT/'hyle-qwen.exe'),'/MAP:'+str(OUT/'hyle-qwen.map'),'/IMPLIB:'+str(OUT/'hyle-qwen.lib')]
save(OUT/'hyle-link-plan.json',dict(command=argv,base=str(ARCH/'qwen-fixed-decode/matched-link-plan.json')))
call('link-hyle',argv,[OUT/('hyle-qwen'+s)for s in ['.exe','.map','.lib','.exp']])
