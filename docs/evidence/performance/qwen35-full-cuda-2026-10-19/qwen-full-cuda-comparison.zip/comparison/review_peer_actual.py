"""Read only completed local results and sources; no inference, build, or product edits."""
import hashlib
import json
from pathlib import Path
import re

OUT=Path(__file__).resolve().parent
ARCH=OUT.parent
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def ident(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
fixed=read(ARCH/'qwen-fixed-decode/fixed-inputs.json')
binary=read(ARCH/'qwen-peer-first-match/peer-full-cuda-greedy-image.json')
summary=[]
peer_predictions=[]
for name in ('02-llama','03-llama','06-llama','08-llama'):
    directory=OUT/name
    result=read(directory/'peer-result.json');run=read(directory/'result.json')
    text=(directory/'stderr.log').read_text()
    assert run['exit']==0 and run['binary']==binary['image']
    assert result['prompt_ids']==fixed['prompt_ids'] and result['decode_input_ids']==fixed['decode_input_ids']
    peer_predictions.append(result['predicted_ids'])
    differences=[dict(phase=i,phase_name='prefill' if i==0 else 'decode'+str(i),visible_tokens=21+i,
        hyle_reference_id=target,peer_id=actual) for i,(target,actual) in enumerate(zip(fixed['target_ids'],result['predicted_ids'])) if target!=actual]
    assert [p['visible_tokens'] for p in result['phases']]==list(range(21,53))
    assert len(result['phases'])==32 and result['context_capacity']==256
    assert 'offloaded 25/25 layers to GPU' in text
    assert text.count('buffer type overridden to CUDA0')==2
    assert not re.search(r'CPU(?:_Mapped|_Host)? model buffer',text)
    kv=[int(n) for n in re.findall(r'llama_kv_cache: layer\s+(\d+): dev = CUDA0',text)]
    recurrent=[int(n) for n in re.findall(r'llama_memory_recurrent, layer\s+(\d+): dev = CUDA0',text)]
    assert kv==[3,7,11,15,19,23]
    assert recurrent==[i for i in range(24) if i%4!=3]
    assert text.count('Skipping CPU samplers')==32
    assert 'cannot be offloaded to the backend' not in text
    assert {p['sampled_logits_elements'] for p in result['phases']}=={248320}
    residual=max(abs(p['step_seconds']-sum(p[k] for k in ('input_prepare_seconds','decode_return_seconds',
        'synchronize_seconds','token_access_seconds','sample_fastpath_seconds'))) for p in result['phases'])
    assert residual<1e-12
    summary.append(dict(run=name,exit=0,image_sha256=run['binary']['sha256'],phases=32,
        exact_fixed_input=True,predicted_ids_equal_target=32-len(differences),prediction_differences=differences,visible_lengths='21..52',
        gpu_layers='25/25',embedding='Two token_embd creation requests explicitly overridden to CUDA0',
        model_buffers=[s for s in text.splitlines() if 'model buffer size' in s],
        kv_gpu_layers=kv,recurrent_gpu_layers=recurrent,kv_dtype='BF16',recurrent_RS_dtype='F32',
        gpu_greedy_fastpath_observations=32,observed_sampled_logits_elements=248320,
        extra_sampled_logits_bytes_per_step=248320*4,phase_segment_sum_max_error_seconds=residual,
        memory_monitor=run['memory_monitor'],snapshot_overhead_seconds=sum(s['snapshot_seconds'] for s in result['memory']),
        loading=result['loading'],raw=ident(directory/'peer-result.json'),log=ident(directory/'stderr.log')))
hyle=[]
assert all(prediction==peer_predictions[0] for prediction in peer_predictions),'Peer runs differ'
for name in ('01-hyle','04-hyle','05-hyle','07-hyle'):
    directory=OUT/name;data=json.loads((directory/'stdout.log').read_text().strip())
    assert data['generated_ids']==fixed['target_ids'] and data['decode_input_ids']==fixed['decode_input_ids']
    hyle.append(dict(run=name,predictions_equal_peer=sum(a==b for a,b in zip(data['generated_ids'],peer_predictions[0])),
        predictions_equal_reference=32,source_id=data['source_id']))
images=[]
for base in (ARCH/'qwen-peer-first-match',ARCH/'llama-matched-consumer/build/bin'):
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix.lower() in ('.exe','.map','.lib','.exp','.pdb'):
            images.append(ident(path))
objects=[ident(p) for p in sorted((ARCH/'qwen-peer-first-match').glob('*.obj'))]
receipt=read(ARCH/'llama-matched-consumer/receipt.json')
converted=read(ARCH/'llama-matched-consumer/converted-model-audit.json')
review=dict(status='Four actual peer runs verified; no further GPU run or product change',
    peer_runs=summary,hyle_prefix_crosschecks=hyle,
    residency=dict(tied='Original loader1364 returns existing token_embd tensor in the same CUDA buffer-type context. One3590.35MiB model buffer corroborates no duplicate970MiB GPU copy.',
        qualification='Model/embedding/KV/recurrent and greedy assignment supported by actual original logs; no CPU sampler fallback. This is not a claim of zero host scheduling, metadata, or readback work.'),
    timing_review=dict(material_work_omissions_found=False,
        common_endpoint='Both full step_seconds cover per-step input preparation through host-visible selected token; old Hyle seconds and peer internal t_eval are not used.',
        hyle='Positions/uploads, owned layout prepare, per-slot/state binding, prepare_replay, submit/wait and4B selected-token read are inside step. Cached shape lookup/ID validation precede start; their actual cold creation is included in startup_to_ready.',
        peer='Batch writes, original decode (including native graph maintenance), sync/all original readbacks, token access and original backend sample fastpath are inside step. Per-phase sampled_logits_count validation and memory snapshots are outside.',
        loading='Hyle weights-load subset and peer model-load API have distinct frontend/meta/preprocessing work; use startup_to_ready and first_token_elapsed as well, not isolated load_seconds as a whole-application result.',
        caveats=['Each engine retains its own logging/native reserve behavior; stdout/JSON reports are outside hot windows. The unmonitored07/08 controls are retained.',
            'These are process/warm-filesystem-cache measurements; no cache eviction or cold-storage bandwidth claim.',
            'Device-global free/total cross-checks are not per-process VRAM. Use root unified WDDM PDH per-process counters; PSAPI working set and private commit are different quantities.']),
    math_and_version=dict(checkpoint='Same canonical HF15852e8c16360a2fea060d615a32b45270f8a8fc; text320 only, no vision/MTP, no low-bit quantization.',
        peer_llama_commit='d9e03f1074dbd2979126d91dce1b5d304ec8394e',peer_ggml_pin='456172ec733a135778adcd32d00e576a58232e45',
        peer_storage_types=converted['types'],peer_conversion='Original mostly-BF16 converter keeps133F32 tensors, applies norm delta+1/A_log -exp inF32 and conv squeeze; head permutation not triggered because K/V head counts both16.',
        hyle='Original checkpoint BF16/F32 payloads and current Hyle engine F32/BF16 activation/accumulation policy; not asserted equal to peer intermediates.',
        native_group='Peer retained source4e1a4libs, API2/TYPE_COUNT43 matched byte-identical public/core headers.166/169 native TU source bytes raw;3 resource/error/capture TUs +common.cuh patched, individual math kernels unchanged. CUDA13.3 sm89 -use_fast_math; CPU baseline(noAVX2).',
        current_hyle='Current Hyle providers/current patched ggml CUDA math and route assembly are a different build/implementation; no raw-native mathematical bit-equivalence is claimed.',
        result_limit='All four Hyle runs equal the fixed reference32/32. All four peer runs are internally identical but equal Hyle/reference30/32: decode23(L44):13 vs9476; decode29(L50):1831 vs33170. Fixed teacher-forced input prefixes remain identical, preventing divergence from contaminating timing. No full-logit precision acceptance or general-model quality claim.'),
    transfer_fact='GPU greedy fastpath is real, but original peer still copies248320 sampled F32 logits (~993280B) per step in addition to token. No4B-only total-D2H claim.',
    cleanup_candidates=dict(files=images,deletion_performed=False,
        scope='Only owned peer CLI/measurement images and maps, not Hyle image. Root must add exact paths to test.ps1 before cleanup.'),
    retain=dict(measurement_objects=objects,official_host_object_count=len(receipt['current_host_objects']),
        official_host_cache='llama-matched-consumer/build: retain host.obj/staticlibs/source/CMakeCache/recipes; existing native4libs+SDK unchanged.',
        single_gguf_identity_reference=read(ARCH/'llama-matched-consumer/converted-file-identity.json'),
        model_note='Retain exactly this single converted GGUF for reproduction; no rehash/copy or new model variant performed in review.',
        small_evidence='Sources/diffs, ABI/header/library receipts, commands/logs/results/token mapping and model conversion audit retained.'))
(OUT/'peer-actual-review.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(review=ident(OUT/'peer-actual-review.json'),peer_runs=len(summary),cleanup_files=len(images),objects=len(objects)),indent=2))
