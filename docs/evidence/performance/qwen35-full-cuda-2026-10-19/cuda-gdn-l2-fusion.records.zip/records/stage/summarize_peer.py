"""Keep fresh process pairs, loading boundaries and reporting changes separate."""
from pathlib import Path
import json
import statistics
STAGE=Path(__file__).resolve().parent
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def main():
    path=STAGE/'peer-comparison-reporting';summary=read(path/'summary.json');runs=read(path/'runs.json')
    hyle=[row['metrics'] for row in runs if row['engine']=='hyle']
    peer=[read(path/(row['tag']+'-peer-result.json')) for row in runs if row['engine']=='peer']
    keys=('weights_load_seconds','shape_prepare_seconds','startup_to_ready_seconds','first_token_elapsed_seconds')
    result={'performance':summary['groups'],'hyle_over_peer':summary['hyle_over_peer'],
        'hyle_loading':{key:statistics.median(row[key] for row in hyle) for key in keys},
        'peer_loading':{key:statistics.median(row['loading'][key] for row in peer)
            for key in ('model_load_seconds','context_prepare_seconds','startup_to_ready_seconds','first_token_elapsed_seconds')},
        'boundaries':{'hyle':'Startup includes weight files/upload and both shape compilations; step begins before input upload and includes batch/bind/replay/submit/wait/token, reporting after endpoint.',
            'peer':'Original model/context preparation; decode graph upkeep is in step. Original backend GPU greedy and sampled-logit readback are retained.',
            'prefill':'Hyle shapes are compiled before the step; first-step tokens/s alone does not compare complete cold-prefill work.',
            'quality':'Same-source transformed BF16 weights and equal 32 predictions; intermediate numerical boundaries differ. No independent quality acceptance.',
            'reporting':'Earlier peer-comparison is retained with Hyle prepared output inside the timer. Do not attribute the entire cross-window change to moving logs.'},
        'fresh_pairs':3,'same_inputs_and_32_predictions':summary['same32_ids_and_inputs']}
    (STAGE/'peer-comparison-reporting/interpretation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
