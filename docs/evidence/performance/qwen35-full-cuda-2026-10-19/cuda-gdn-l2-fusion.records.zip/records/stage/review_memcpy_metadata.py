"""Read-only SQLite audit of replay memcpy byte metadata and graph identity."""
import bisect
import collections
import hashlib
import json
from pathlib import Path
import sqlite3

STAGE = Path(__file__).resolve().parent


def inspect(path):
    connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        tables = [r[0] for r in connection.execute("select name from sqlite_master where type='table'")]
        copies = [dict(r) for r in connection.execute("select * from CUPTI_ACTIVITY_KIND_MEMCPY order by start")]
        events = collections.defaultdict(list)
        for row in connection.execute("select * from CUDA_GRAPH_NODE_EVENTS"):
            events[row["graphNodeId"]].append(dict(row))
        apis = [dict(r) for r in connection.execute("select a.*,s.value as name from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId")]
        api_by_correlation = {r["correlationId"]: r for r in apis}
        endpoints = [r["end"] for r in copies if r["copyKind"] == 2 and r["bytes"] == 4]
        assert len(endpoints) == 32
        node_rows = collections.defaultdict(list)
        for row in copies:
            if row["graphNodeId"]:
                node_rows[row["graphNodeId"]].append(row)
        varying = {n: rs for n, rs in node_rows.items() if len({r["bytes"] for r in rs}) > 1}
        parent_sets = {n: {r["originalGraphNodeId"] for r in rs if r["originalGraphNodeId"] is not None} for n, rs in events.items()}
        assert all(len(parent_sets[n]) <= 1 for n in varying)
        examples = []
        for node in (562640715824, 562640715846, 575525617677):
            if node not in varying:
                continue
            rows = varying[node]
            parent = next(iter(parent_sets[node]))
            creation = events[parent][0]
            capture_api = [r for r in apis if r["globalTid"] == creation["globalTid"] and r["start"] <= creation["start"] <= r["end"]]
            examples.append({
                "graphNodeId": node, "originalGraphNodeId": parent,
                "creation_events": events[node],
                "creation_after_first_execution": sum(r["start"] > rows[0]["start"] for r in events[node]),
                "bytes_by_decode_phase": [{"decode": bisect.bisect_left(endpoints, r["start"]), "bytes": r["bytes"], "correlationId": r["correlationId"], "copyCount": r["copyCount"]} for r in rows[:4]],
                "all_replays_grouped": [{"bytes": k, "rows": v} for k, v in sorted(collections.Counter(r["bytes"] for r in rows).items())],
                "replay_correlation_api_names": sorted({api_by_correlation[r["correlationId"]]["name"] for r in rows}),
                "root_creation_containing_host_api": [{k: r[k] for k in ("name", "correlationId", "start", "end", "returnValue")} for r in capture_api],
            })
        kernel_nodes = {r[0] for r in connection.execute("select distinct graphNodeId from CUPTI_ACTIVITY_KIND_KERNEL")}
        identical = collections.Counter(tuple(r.values()) for r in copies)
        graph_apis = collections.Counter(r["name"] for r in apis if "Graph" in r["name"])
        result = {
            "input": {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()},
            "memcpy_activity_tables": [t for t in tables if "MEMCPY" in t and not t.startswith("ENUM_")],
            "rows": len(copies), "raw_sum_bytes": sum(r["bytes"] for r in copies),
            "raw_sum_bytes_times_copyCount": sum(r["bytes"] * r["copyCount"] for r in copies),
            "copyCount_distribution": dict(collections.Counter(r["copyCount"] for r in copies)),
            "nonunit_copyCount_signatures": [{"copyKind": k[0], "bytes": k[1], "copyCount": k[2], "rows": v} for k, v in sorted(collections.Counter((r["copyKind"], r["bytes"], r["copyCount"]) for r in copies if r["copyCount"] != 1).items())],
            "identical_duplicate_memcpy_rows": sum(n - 1 for n in identical.values() if n > 1),
            "graph_nodes_with_multiple_reported_byte_sizes": len(varying),
            "varying_size_patterns": [{"bytes": list(k), "nodes": v} for k, v in sorted(collections.Counter(tuple(sorted({r["bytes"] for r in rs})) for rs in varying.values()).items())],
            "varying_nodes_with_creation_after_first_execution": sum(any(e["start"] > rs[0]["start"] for e in events[n]) for n, rs in varying.items()),
            "varying_nodes_with_multiple_original_parent_ids": sum(len(parent_sets[n]) > 1 for n in varying),
            "varying_nodes_also_used_by_kernel_records": len(set(varying) & kernel_nodes),
            "runtime_graph_API_counts": dict(sorted(graph_apis.items())),
            "recorded_graph_parameter_update_APIs": {k: v for k, v in graph_apis.items() if "Params" in k or "Update" in k},
            "runtime_columns": [r[1] for r in connection.execute("pragma table_info(CUPTI_ACTIVITY_KIND_RUNTIME)")],
            "graph_node_event_columns": [r[1] for r in connection.execute("pragma table_info(CUDA_GRAPH_NODE_EVENTS)")],
            "examples": examples,
        }
        return result
    finally:
        connection.close()


def main():
    baseline = inspect(STAGE.parent / "cuda-rms-inplace/profile/qwen-rms-inplace-trace.sqlite")
    current = inspect(STAGE / "profile/qwen-gdn-l2-trace.sqlite")
    result = {
        "scope": "Offline audit only; no new GPU/build and no product changes.",
        "baseline": baseline, "current": current,
        "raw_whole_trace_byte_sum_delta": current["raw_sum_bytes"] - baseline["raw_sum_bytes"],
        "raw_whole_trace_byte_times_copyCount_sum_delta": current["raw_sum_bytes_times_copyCount"] - baseline["raw_sum_bytes_times_copyCount"],
        "findings": [
            "Current graphNodeIds change reported byte sizes between first decode and later same-slot replays; baseline has no varying-byte graphNodeIds. The current node creation records do not show later re-creation or multiple original parent IDs for those IDs.",
            "All example execution rows correlate to cudaGraphLaunch, not to a direct memcpy API. Original capture-node creation timestamps fall inside cudaMemcpyAsync, not cudaMemcpy2DAsync. This odd-slot state-copy metadata is separate from the T128 duplicate-CONT 2Dcopy removal.",
            "There is one physical MEMCPY activity table, no identical duplicate rows. Graph creation rows sometimes occur twice for clone/original linkage and must not be joined as extra executed copies.",
            "No GraphExec*SetParams/Update APIs are recorded; however this alone cannot prove no parameter update occurred because the profiler schema/API coverage is limited.",
            "Runtime and graph-node-event tables contain no memcpy src/dst/width/height/pitch/size argument descriptors. Therefore actual graph parameters and an exporter/profiler identity/metadata problem cannot be distinguished from this export alone.",
        ],
        "limits": [
            "Do not attribute the odd-slot byte substitutions to matrix cache or treat raw SUM(bytes) as proven increased physical transfer volume/bandwidth regression.",
            "The nonunit copyCount signatures and weighted total are reported for accounting completeness; they are equal between traces and do not explain the raw byte delta.",
            "No byte-value normalization or correction is applied. Kernel and graph-launch counts remain independently verified by official CSV/SQLite and token-D2H phase bins.",
            "Existing Nsight driver13.4/tool13.3 fallback warning further limits conclusions about this metadata anomaly.",
        ],
    }
    destination = STAGE / "memcpy-metadata-review.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"path": str(destination), "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                      "varying_nodes": [baseline["graph_nodes_with_multiple_reported_byte_sizes"], current["graph_nodes_with_multiple_reported_byte_sizes"]]}))


if __name__ == "__main__":
    main()
