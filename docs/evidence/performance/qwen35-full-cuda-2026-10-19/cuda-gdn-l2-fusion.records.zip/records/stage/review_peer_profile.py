"""Offline fresh-peer versus Hyle physical counts; distinguish both D2H outputs."""
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("physical_counts", STAGE.parent / "cuda-stable-silu/profile-analysis-stable.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def trace(stem):
    data = a.load(Path(str(stem) + ".sqlite"), Path(str(stem) + "_cuda_gpu_kern_sum.csv"))
    phases = a.phases(data)
    assert phases["valid"] and data["receipt"]["csv_sqlite_per_symbol_counts_equal"]
    con = sqlite3.connect(Path(str(stem) + ".sqlite").resolve().as_uri() + "?mode=ro", uri=True)
    try:
        errors = con.execute("select s.value,a.returnValue,count(*) from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId where a.returnValue!=0 group by s.value,a.returnValue").fetchall()
    finally:
        con.close()
    assert not errors and not data["receipt"]["graph_api_failures"]
    return data, phases


def summary(data, phases):
    warm = phases["warm_decode7_31"]
    keys = ("physical_kernel_count", "graph_node_kernel_count", "graph_launch_count")
    return {
        "receipt": data["receipt"],
        "phase_binning_valid": phases["valid"],
        "endpoint_count": phases["endpoint_count"],
        "kernel_crosses_endpoint": phases["kernel_crosses_token_endpoint_count"],
        "unassigned_kernels": phases["unassigned_kernel_count"],
        "first_bin_including_cold_work": {k: phases["phases"][0][k] for k in keys},
        "warm_decode7_31": {k: warm[k] for k in keys},
    }


def main():
    peer, pp = trace(STAGE / "peer-profile/peer-trace")
    hyle, hp = trace(STAGE / "profile/qwen-gdn-l2-trace")
    for phases, values in ((pp, (558, 558, 1)), (hp, (1054, 1037, 7))):
        for metric, value in zip(("physical_kernel_count", "graph_node_kernel_count", "graph_launch_count"), values):
            assert phases["warm_decode7_31"][metric]["samples"] == [value] * 25
    token = sorted((r for r in peer["copies"] if r["copyKind"] == 2 and r["bytes"] == 4), key=lambda r: r["end"])
    logits = sorted((r for r in peer["copies"] if r["copyKind"] == 2 and r["bytes"] == 993280), key=lambda r: r["end"])
    assert len(token) == len(logits) == len({r["end"] for r in token}) == len({r["end"] for r in logits}) == 32
    assert sum(r["copyKind"] == 2 for r in peer["copies"]) == 64
    assert all(t["end"] < l["start"] and (i == 31 or l["end"] < token[i+1]["start"]) for i, (t, l) in enumerate(zip(token, logits)))
    kernels_between = [sum(t["end"] < k["start"] <= l["end"] for k in peer["kernels"]) for t, l in zip(token, logits)]
    assert kernels_between == [0] * 32
    # Validate that choosing the later sampled-logit endpoints yields exactly
    # the same kernel/GraphLaunch bins. Never mix both sets into64 endpoints.
    later = dict(peer, copies=[dict(r, bytes=4) for r in logits])
    lp = a.phases(later)
    metrics = ("physical_kernel_count", "graph_node_kernel_count", "graph_launch_count")
    assert lp["valid"] and all(all(x[k] == y[k] for k in metrics) for x, y in zip(pp["phases"], lp["phases"]))
    peer_result_path = STAGE / "peer-profile/peer-result.json"
    peer_result = a.read(peer_result_path)
    fixed_path = Path(peer_result["fixed_inputs"])
    fixed = a.read(fixed_path)
    command = a.read(STAGE / "profile/inputs.json")["command"]
    hyle_prompt_path = Path(command[command.index("--inputs") + 1]) / "prompt.ids"
    hyle_decode_path = Path(command[command.index("--decode-ids") + 1])
    hyle_prompt = [int(v) for v in hyle_prompt_path.read_text().split()]
    hyle_decode = [int(v) for v in hyle_decode_path.read_text().split()]
    checks = {
        "peer_phases32": len(peer_result["phases"]) == 32,
        "phase_identity_and_visible_lengths": all(p["phase"] == i and p["input_tokens"] == (128 if i == 0 else 1) and p["visible_tokens"] == 128+i for i, p in enumerate(peer_result["phases"])),
        "sampled_logits248320_elements_all32": all(p["sampled_logits_elements"] == 248320 for p in peer_result["phases"]),
        "prompt_ids_all_equal": peer_result["prompt_ids"] == fixed["prompt_ids"] == hyle_prompt,
        "decode_input_ids_all_equal": peer_result["decode_input_ids"] == fixed["decode_input_ids"] == hyle_decode,
        "predicted32_ids_equal_hyle": peer_result["predicted_ids"] == hyle["target"]["output"]["generated_ids"],
        "both_profile_exit_zero": a.read(STAGE / "peer-profile/profile.result.json")["exit"] == a.read(STAGE / "profile/profile.result.json")["exit"] == 0,
    }
    assert all(checks.values())
    result = {
        "scope": "Offline fresh-peer physical kernel and GraphLaunch counts versus the retained current Hyle v14 profile; no GPU rerun or performance claim.",
        "checks": checks,
        "input_id_sources": {"fixed": a.identity(fixed_path), "hyle_prompt": a.identity(hyle_prompt_path), "hyle_decode": a.identity(hyle_decode_path), "peer_result": a.identity(peer_result_path)},
        "peer_D2H_endpoint_audit": {
            "token": {"bytes_each": 4, "events": 32, "unique_endpoints": 32},
            "sampled_logits": {"bytes_each": 993280, "elements_each": 248320, "events": 32, "unique_endpoints": 32},
            "paired_order": "Each4B token copy completes before its sampled-logits copy starts; sampled logits completes before next token copy starts.",
            "kernel_count_between_token_end_and_logits_end_all32": 0,
            "token_anchor_and_logits_anchor_kernel_and_GraphLaunch_bins_identical": True,
            "method": "Use only32 token4B endpoints for kernel bins; sampled-logit copies are separately classified, never extra phase endpoints.",
        },
        "peer": summary(peer, pp), "hyle": summary(hyle, hp),
        "warm25_comparison": {
            "peer_kernels_per_step": 558, "hyle_kernels_per_step": 1054, "hyle_minus_peer": 496,
            "peer_graph_node_kernels_per_step": 558, "hyle_graph_node_kernels_per_step": 1037,
            "peer_GraphLaunch_per_step": 1, "hyle_GraphLaunch_per_step": 7,
            "peer_warm_total_kernels": 13950, "hyle_warm_total_kernels": 26350,
            "all25_samples_equal_the_reported_values": True,
        },
        "peer_capture_start": "prefill930 kernels and decode1=558 have no graph-node kernels/GraphLaunch; decode2..31 each558 graph-node kernels and1 GraphLaunch, total30 launches.",
        "runtime_nonzero_returns": {"peer": 0, "hyle": 0},
        "limits": [
            "First bins include cold preparation; they are not pure-prefill kernel or latency statistics.",
            "The peer's public backend sampler also transfers993280B sampled logits each phase, despite its4B sampled token fast path. Physical kernel counts do not remove that transfer from its consumer wall boundary.",
            "Matching prompt/decode inputs and32 predicted IDs is not full-vector/bit-equivalence or quality acceptance across the two engines/weight representations.",
            "Both traces retain the existing Nsight driver13.4/tool13.3 fallback warning; runtime return values and GraphLaunch errors are independently zero.",
            "Hyle source image/profile here precedes the stderr timing-boundary fix. These are physical counts; old performance logs remain original evidence and must not be silently relabeled as the upcoming corrected timing pairs.",
        ],
    }
    destination = STAGE / "peer-profile/physical-counts.json"
    a.save(destination, result)
    print(json.dumps({"output": a.identity(destination), "checks": checks, "warm_peer": 558, "warm_hyle": 1054}))


if __name__ == "__main__":
    main()
