"""Offline physical-event comparison, including the cold-prepare/prefill bin."""
import bisect
import collections
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("physical_counts", STAGE.parent / "cuda-stable-silu/profile-analysis-stable.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def load(stem):
    data = a.load(Path(str(stem) + ".sqlite"), Path(str(stem) + "_cuda_gpu_kern_sum.csv"))
    phases = a.phases(data)
    assert phases["valid"] and data["receipt"]["csv_sqlite_per_symbol_counts_equal"]
    ends = [p["token_D2H_end_ns"] for p in phases["phases"]]
    kernels = [collections.Counter() for _ in ends]
    copies = [collections.Counter() for _ in ends]
    for row in data["kernels"]:
        kernels[bisect.bisect_left(ends, row["start"])][row["name"]] += 1
    for row in data["copies"]:
        index = bisect.bisect_left(ends, row["start"])
        if index < len(ends):
            copies[index][row["copyKind"], row["bytes"]] += 1
    con = sqlite3.connect(Path(str(stem) + ".sqlite").resolve().as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        physical_512k = [dict(r) for r in con.execute(
            "select * from CUPTI_ACTIVITY_KIND_MEMCPY where start<=? and copyKind=8 and bytes=524288", [ends[0]])]
        runtime_errors = [dict(r) for r in con.execute(
            "select s.value as name,a.returnValue,count(*) as count from CUPTI_ACTIVITY_KIND_RUNTIME a "
            "join StringIds s on s.id=a.nameId where a.returnValue!=0 group by s.value,a.returnValue")]
        memcpy_2d_apis = con.execute(
            "select count(*) from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId "
            "where a.start<=? and s.value like '%cudaMemcpy2DAsync%'", [ends[0]]).fetchone()[0]
    finally:
        con.close()
    return dict(data=data, phases=phases, kernels=kernels, copies=copies,
                copies_512k=physical_512k, runtime_errors=runtime_errors, memcpy_2d_apis=memcpy_2d_apis)


def delta(before, after):
    return {k: after[k] - before[k] for k in before.keys() | after.keys() if after[k] != before[k]}


def main():
    old = load(STAGE.parent / "cuda-rms-inplace/profile/qwen-rms-inplace-trace")
    new = load(STAGE / "profile/qwen-gdn-l2-trace")
    pre_delta = delta(old["kernels"][0], new["kernels"][0])
    assert sum(pre_delta.values()) == -324
    assert all(delta(old["kernels"][i], new["kernels"][i]) == pre_delta for i in range(1, 32))
    assert delta(old["copies"][0], new["copies"][0]) == {(8, 524288): -72}
    assert not old["runtime_errors"] and not new["runtime_errors"]
    carriers = [k for k in new["data"]["kernels"] if "hyle_bf16_l2_core" in k["name"]]
    endpoints = [p["token_D2H_end_ns"] for p in new["phases"]["phases"]]
    carrier_bins = collections.Counter(bisect.bisect_left(endpoints, k["start"]) for k in carriers)
    assert carrier_bins == collections.Counter({i: 36 for i in range(32)})
    whole_copy_before = sum(old["copies"], collections.Counter())
    whole_copy_after = sum(new["copies"], collections.Counter())
    total_d2d_delta = sum(size * count for (kind, size), count in delta(whole_copy_before, whole_copy_after).items() if kind == 8)
    warm = []
    for i in range(7, 32):
        changes = delta(old["copies"][i], new["copies"][i])
        assert changes in ({}, {(8, 36864): -3, (8, 1048576): 3})
        if changes:
            warm.append(i)
    result = {
        "scope": "Offline official SQLite/CSV comparison. The first token-D2H bin includes all preceding cold preparation and prefill, not pure prefill.",
        "inputs": {"baseline": old["data"]["receipt"]["sqlite"], "current": new["data"]["receipt"]["sqlite"]},
        "checks": {
            "both_phase_binnings_valid": True, "both_official_csv_sqlite_per_symbol_counts_equal": True,
            "all32_phases_have_identical_exact_kernel_symbol_delta": True,
            "all32_phases_have36_l2_carriers": True,
            "runtime_nonzero_return_records": {"baseline": 0, "current": 0},
            "graph_launch_nonzero_returns": {"baseline": 0, "current": 0},
            "generated_ids_equal": old["data"]["target"]["output"]["generated_ids"] == new["data"]["target"]["output"]["generated_ids"],
        },
        "raw_physical_kernel_totals": {"baseline": len(old["data"]["kernels"]), "current": len(new["data"]["kernels"]), "delta": -10368},
        "cold_prepare_plus_prefill_first_bin": {
            "physical_kernels": {"baseline": 1904, "current": 1580, "delta": -324},
            "graph_node_kernels": {"baseline": 1505, "current": 1181, "delta": -324},
            "GraphLaunch": {"baseline": 7, "current": 7},
            "l2_carriers": {"baseline": 0, "current": 36, "grid": [2048, 1, 1], "block": [32, 1, 1]},
            "kernel_symbol_deltas": [{"name": name, "baseline": old["kernels"][0][name], "current": new["kernels"][0][name], "delta": value} for name, value in sorted(pre_delta.items())],
            "physical_D2D_memcpy_512KiB": {
                "baseline": len(old["copies_512k"]), "current": len(new["copies_512k"]),
                "event_delta": -72, "payload_byte_delta": -37748736,
                "all_have_nonzero_graphNodeId": all(r["graphNodeId"] for d in (old, new) for r in d["copies_512k"]),
                "all_copyCount_equal_one": all(r["copyCount"] == 1 for d in (old, new) for r in d["copies_512k"]),
                "unique_graphNodeIds": {"baseline": len({r["graphNodeId"] for r in old["copies_512k"]}), "current": len({r["graphNodeId"] for r in new["copies_512k"]})},
                "stream": 13,
                "all_other_copykind_size_signature_counts_equal": True,
            },
            "runtime_cudaMemcpy2DAsync_calls": {"baseline": old["memcpy_2d_apis"], "current": new["memcpy_2d_apis"], "delta": -72,
                "limit": "Host API/capture calls are corroboration only; physical counts above come from CUPTI memcpy events, not these calls."},
        },
        "warm_decode7_31": {
            "steps": 25, "physical_kernels_per_step": {"baseline": 1378, "current": 1054, "delta": -324},
            "graph_node_kernels_per_step": {"baseline": 1361, "current": 1037},
            "GraphLaunch_per_step": {"baseline": 7, "current": 7}, "l2_carriers_per_step": 36,
            "l2_carrier_grid_block": {"grid": [16, 1, 1], "block": [512, 1, 1]},
            "exact_kernel_symbol_delta_same_as_first_bin": True,
            "memcpy_events_per_step": {"baseline": 101, "current": 101},
            "D2D_memcpy_events_per_step": {"baseline": 97, "current": 97},
            "copy_size_changes": {"affected_decode_steps": warm, "per_affected_step": {"36864B_events": -3, "1048576B_events": 3},
                                  "warm25_D2D_payload_byte_delta": len(warm) * 3 * (1048576 - 36864), "attribution": "Not identified by node/ValueId in these traces."},
        },
        "whole_trace_memcpy_signature_deltas": [{"copyKind": k[0], "bytes": k[1], "baseline": whole_copy_before[k], "current": whole_copy_after[k], "delta": v} for k, v in sorted(delta(whole_copy_before, whole_copy_after).items())],
        "whole_trace_D2D_reported_byte_delta": total_d2d_delta,
        "GraphLaunch_whole_trace": {"baseline": len(old["data"]["launches"]), "current": len(new["data"]["launches"])},
        "interpretation": [
            "The 36 T128 carriers prove the complete L2 core reaches the fused path; the -324 kernels are exactly36*(10-1), independent of copy counts.",
            "The separate physical reduction of72*512KiB D2D copies numerically matches36 chains*(3 CONT-1 CONT), supported by the retained raw T128 triple-CONT graph and the ValueId matrix cache source change.",
            "Same-type matching-shape CONT may use cudaMemcpy2DAsync rather than a copy kernel: pinned ggml src/ggml-cuda/cpy.cu:389-397 and :476-478. Hence no CONT kernel symbol delta is expected for that route.",
            "No node/ValueId/NVTX mapping identifies each removed memcpy event individually. The association is supported by exact count/bytes/layout and source/diagnostic evidence, not model-name labeling.",
        ],
        "limits": [
            "Do not label the first bin pure-prefill. It includes startup/cold constant preparation, capture preparation and the first128-token execution.",
            "Retained preceding-image baseline is a physical-count comparison, not a simultaneous timing pair. No latency, bandwidth, throughput, workspace or peak-memory claim follows.",
            "The prefill-bin36MiB reported copy reduction is not a whole-trace byte reduction: unattributed copy-size metadata substitutions exist, and the raw SUM(bytes) D2D difference is+7778304 here. The same graphNodeId changes reported bytes across replay; see memcpy-metadata-review.json before interpreting this as actual transfer volume.",
            "Nsight records the existing driver13.4/tool13.3 fallback warning. Both traces have zero nonzero runtime return records and zero graph launch errors; this does not turn the profiler warning into an error-free-tool claim.",
        ],
    }
    destination = STAGE / "physical-copy-review.json"
    a.save(destination, result)
    print(json.dumps({"output": a.identity(destination), "prefill_copy_events_delta": -72, "warm_kernel_delta": -324, "whole_D2D_byte_delta": total_d2d_delta}))


if __name__ == "__main__":
    main()
