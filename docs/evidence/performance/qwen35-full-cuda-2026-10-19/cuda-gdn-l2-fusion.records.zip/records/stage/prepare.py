"""Replay the locked patches and add the exact composed BF16 L2 core."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
UPSTREAM=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST=ROOT/'third_party/ggml_cuda_runtime/patches.json'
OLD=STAGE.parent/'cuda-rms-inplace/native-source'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def apply(data,edits):
    for edit in edits:
        old,new=edit['before'].encode(),edit['after'].encode()
        if data.count(old)!=1:raise ValueError('Nonunique native context')
        data=data.replace(old,new,1)
    return data

def main():
    before=STAGE/'patches.before.json'
    if before.exists():raise ValueError('Preserve original patch attempt')
    before.write_bytes(MANIFEST.read_bytes());manifest=json.loads(before.read_text())
    rows={row['path']:row for row in manifest['files']}
    kernel=STAGE/'native-source/src/ggml-cuda/norm.cu'
    header=STAGE/'native-source/src/ggml-cuda/norm.cuh'
    raw_norm=rows['src/ggml-cuda/norm.cu']
    old_kernel=(OLD/'src/ggml-cuda/norm.cu').read_bytes()
    new_kernel=kernel.read_bytes()
    old_head=(OLD/'src/ggml-cuda/norm.cuh').read_bytes();new_head=header.read_bytes()
    # Norm has no CPU/IQ1 composition; append only the new carrier.
    if not new_kernel.startswith(old_kernel.replace(b'#include <cstdint>',b'#include <cstdint>\n#include <climits>')):
        raise ValueError('Unexpected change to original norm implementation')
    include={'before':'#include <cstdint>','after':'#include <cstdint>\n#include <climits>'}
    marker='\n// HYLE\'s composed BF16 L2 core'
    tail=new_kernel.decode().split(marker,1)
    if len(tail)!=2:raise ValueError('New kernel tail missing')
    end='    l2_norm_f32_cuda(src0_d, dst_d, ne00, ne01, ne02, ne03, s01, s02, s03, eps, stream);\n}\n'
    additions={
        'src/ggml-cuda/norm.cu':[include,{'before':end,'after':end+marker+tail[1]}],
        'src/ggml-cuda/norm.cuh':[]}
    if not new_head.startswith(old_head):raise ValueError('Original norm header changed')
    # The existing header ends in the last original entry declaration.
    old_last=old_head.decode().splitlines(keepends=True)[-1]
    additions['src/ggml-cuda/norm.cuh']=[{'before':old_last,'after':old_last+new_head[len(old_head):].decode()}]
    matcher=(STAGE/'l2-matcher.txt').read_text()
    hook='''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        ggml_cuda_bf16_l2_core_match l2;
        if (ggml_cuda_match_bf16_l2_core(cgraph, i, l2)) {
            ggml_cuda_op_bf16_l2_core_fused(*cuda_ctx, l2.x, l2.epsilon, l2.numerator, l2.dst);
            return l2.count - 1;
        }
#endif
'''
    anchor='static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {'
    call='    if (node->op == GGML_OP_MUL) {\n        ggml_cuda_moe_weighted_reduction_match match;'
    additions['src/ggml-cuda/ggml-cuda.cu']=[
        {'before':anchor,'after':'#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)\n'+matcher+'#endif\n\n'+anchor},
        {'before':call,'after':'    if (node->op == GGML_OP_MUL) {\n'+hook+'        ggml_cuda_moe_weighted_reduction_match match;'}]
    changes=[]
    for path,edits in additions.items():
        row=rows[path];original=(UPSTREAM/path).read_bytes().replace(b'\r\n',b'\n')
        if sha(original)!=row['before_sha256']:raise ValueError('Upstream drift')
        old=apply(original,row['edits'])
        if sha(old)!=row['after_sha256']:raise ValueError('Existing replay differs')
        new=apply(old,edits);row['edits']+=edits;row['after_sha256']=sha(new)
        if path.endswith('norm.cu') and new!=new_kernel:raise ValueError('Kernel composition differs')
        if path.endswith('norm.cuh') and new!=new_head:raise ValueError('Header composition differs')
        changes.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),
            fromfile='v13/'+path,tofile='v14/'+path))
    save(MANIFEST,manifest);(STAGE/'native-change.diff').write_text(''.join(changes),encoding='utf-8')
    print('PATCH_PREPARED',flush=True)

if __name__=='__main__':main()
