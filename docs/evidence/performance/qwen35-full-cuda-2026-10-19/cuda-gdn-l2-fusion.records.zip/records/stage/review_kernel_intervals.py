"""Offline kernel-family intervals/union/gaps; never an end-to-end attribution."""
import collections
import importlib.util
import json
from pathlib import Path
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("physical_counts", STAGE.parent / "cuda-stable-silu/profile-analysis-stable.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def family(name):
    if "internal::gemvx" in name:
        return "projection"
    if "mul_mat_vec_f<" in name:
        return "projection"
    if "gated_delta_net" in name:
        return "GDN"
    if "ssm_conv" in name:
        return "convolution"
    if "flashinfer" in name or "flash_attn" in name:
        return "attention_and_merge"
    if "rms_norm" in name or "hyle_bf16_l2_core" in name:
        return "normalization_RMS_and_L2"
    if "cpy_scalar_contiguous" in name:
        return "conversion"
    if "cpy_" in name:
        return "layout_copy_kernel"
    if "op_repeat" in name:
        return "repeat_broadcast"
    if "k_bin_bcast" in name or "unary_op_kernel" in name or "unary_gated_op_kernel" in name or "act_kernel<" in name or "softplus_kernel" in name or "scale_f32" in name:
        return "elementwise_and_activation"
    if "concat_" in name:
        return "concat"
    if "single_update<" in name or "k_set_rows<" in name:
        return "cache_update_kernel"
    if "GatherOutput<" in name or "k_get_rows" in name:
        return "gather_indexing"
    if "collectives" in name or "argmax_f32" in name or "pad_f32" in name:
        return "token_selection_and_padding"
    if "rope_multi" in name:
        return "rotary_named_kernel"
    raise AssertionError("Unclassified symbol: " + name)


def merged(rows):
    result = []
    for row in sorted(rows, key=lambda r: r["start"]):
        if result and row["start"] <= result[-1][1]:
            if row["end"] > result[-1][1]:
                result[-1][1], result[-1][3] = row["end"], row
        else:
            result.append([row["start"], row["end"], row, row])
    return result


def stats_us(values):
    return {k: round(f(values) / 1000, 4) for k, f in (("min", min), ("median", statistics.median), ("mean", statistics.mean), ("max", max))}


def analyze(stem):
    data = a.load(Path(str(stem) + ".sqlite"), Path(str(stem) + "_cuda_gpu_kern_sum.csv"))
    phases = a.phases(data)
    assert phases["valid"] and data["receipt"]["csv_sqlite_per_symbol_counts_equal"]
    ends = [r["token_D2H_end_ns"] for r in phases["phases"]]
    con = sqlite3.connect(Path(str(stem) + ".sqlite").resolve().as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        extra = [dict(r) for table in ("CUPTI_ACTIVITY_KIND_MEMCPY", "CUPTI_ACTIVITY_KIND_MEMSET") for r in con.execute("select start,end from " + table)]
    finally:
        con.close()
    values = collections.defaultdict(list)
    gap_sums, gap_counts = collections.Counter(), collections.Counter()
    counts, durations = collections.Counter(), collections.Counter()
    symbols = collections.defaultdict(lambda: [0, 0])
    streams = collections.Counter()
    delay = []
    for i in range(7, 32):
        kernels = [k for k in data["kernels"] if ends[i-1] < k["start"] <= ends[i]]
        union = merged(kernels)
        lo, hi = union[0][0], union[-1][1]
        active = sum(r[1] - r[0] for r in union)
        duration_sum = sum(k["end"] - k["start"] for k in kernels)
        others = [dict(start=max(lo, r["start"]), end=min(hi, r["end"])) for r in extra if r["end"] > lo and r["start"] < hi]
        combined = merged(kernels + others)
        all_active = sum(r[1] - r[0] for r in combined)
        for key, value in {
            "kernel_duration_sum": duration_sum, "kernel_union": active,
            "kernel_interval_overlap": duration_sum - active,
            "first_to_last_kernel_span": hi - lo, "intra_span_without_kernel": hi - lo - active,
            "nonkernel_GPU_activity_covering_kernel_gaps": all_active - active,
            "intra_span_without_recorded_kernel_memcpy_memset": hi - lo - all_active,
            "previous_token_end_to_first_kernel": lo - ends[i-1],
            "last_kernel_end_to_token_end": ends[i] - hi,
            "token_endpoint_interval": ends[i] - ends[i-1],
        }.items():
            values[key].append(value)
        launches = [x for x in data["launches"] if ends[i-1] < x["start"] <= ends[i]]
        values["GraphLaunch_API_duration_sum"].append(sum(x["end"] - x["start"] for x in launches))
        for launch in launches:
            selected = [k for k in kernels if k["correlationId"] == launch["correlationId"]]
            if selected:
                delay.append(min(k["start"] for k in selected) - launch["end"])
        for left, right in zip(union, union[1:]):
            l, r = left[3], right[2]
            bucket = "touches_uncaptured_kernel" if not (l["graphNodeId"] and r["graphNodeId"]) else "within_same_GraphLaunch" if l["correlationId"] == r["correlationId"] else "between_GraphLaunches"
            gap_sums[bucket] += right[0] - left[1]
            gap_counts[bucket] += 1
        for kernel in kernels:
            group = family(kernel["name"])
            duration = kernel["end"] - kernel["start"]
            counts[group] += 1
            durations[group] += duration
            streams[kernel["streamId"]] += 1
            symbols[kernel["name"]][0] += 1
            symbols[kernel["name"]][1] += duration
    result = {
        "sqlite": data["receipt"]["sqlite"],
        "official_csv_sqlite_per_symbol_counts_equal": True,
        "warm_steps": 25,
        "physical_kernels_per_step": {k: phases["warm_decode7_31"]["physical_kernel_count"][k] for k in ("min", "median", "max")},
        "GraphLaunch_per_step": {k: phases["warm_decode7_31"]["graph_launch_count"][k] for k in ("min", "median", "max")},
        "stream_kernel_counts_all25": dict(streams),
        "timing_us_per_step": {k: stats_us(v) for k, v in values.items()},
        "gap_buckets_mean_us_per_step": {k: round(v / 25000, 4) for k, v in gap_sums.items()},
        "gap_buckets_mean_events_per_step": {k: v / 25 for k, v in gap_counts.items()},
        "GraphLaunch_API_end_to_first_kernel_us": stats_us(delay),
        "family": {k: {"kernels_per_step": counts[k] / 25, "duration_sum_mean_us_per_step": round(durations[k] / 25000, 4)} for k in sorted(counts)},
    }
    return result, symbols


def main():
    hyle, hs = analyze(STAGE / "profile/qwen-gdn-l2-trace")
    peer, ps = analyze(STAGE / "peer-profile/peer-trace")
    families = sorted(hyle["family"].keys() | peer["family"].keys())
    category = []
    for key in families:
        h = hyle["family"].get(key, {"kernels_per_step": 0, "duration_sum_mean_us_per_step": 0})
        p = peer["family"].get(key, {"kernels_per_step": 0, "duration_sum_mean_us_per_step": 0})
        category.append({"family": key, "hyle": h, "peer": p,
                         "H_minus_peer_duration_sum_us": round(h["duration_sum_mean_us_per_step"] - p["duration_sum_mean_us_per_step"], 4)})
    category.sort(key=lambda r: -r["H_minus_peer_duration_sum_us"])
    projection_h = hyle["family"]["projection"]["duration_sum_mean_us_per_step"]
    projection_p = peer["family"]["projection"]["duration_sum_mean_us_per_step"]
    total_h = hyle["timing_us_per_step"]["kernel_duration_sum"]["mean"]
    total_p = peer["timing_us_per_step"]["kernel_duration_sum"]["mean"]
    del hyle["family"], peer["family"]  # Kept once, in the side-by-side table.
    result = {
        "scope": "Offline warm decode7..31 recorded intervals from separate Hyle and fresh-peer Nsight runs. These are profiling clues, not an attribution of the separately measured wall-time gap.",
        "hyle": hyle, "peer": peer,
        "family_duration_comparison": category,
        "projection_summary_us": {"hyle_187_cuBLAS_kernels": projection_h, "peer_163_MMVF_kernels": projection_p,
                                  "difference": round(projection_h - projection_p, 4),
                                  "remaining_nonprojection_sum_difference": round((total_h - projection_h) - (total_p - projection_p), 4)},
        "source_and_symbol_qualifications": [
            "Families classify native symbols, not exact model nodes; generic binary/gather/copy kernels are not assigned to a specific role without node mapping.",
            "Peer163 MMVF launches include54 has_fusion=true instances, while Hyle uses187 separate cuBLAS BF16 GEMVs. This is not a one-to-one projection/epilogue comparison or permission to change Hyle RNE contracts.",
            "Peer convolution uses ssm_conv_f32<true> (apply_silu) and Hyle<false>; pinned src/ggml-cuda/ssm-conv.cu:5,56 confirms fusion. Hyle separately records18 BF16 SGLang SiLU kernels. Conv-only duration comparisons omit that distinction.",
            "The normalization category combines Hyle79 RMS+36 L2-core kernels and peer115 RMS-family kernels; equal counts do not prove identical normalization mathematics or rounding.",
            "Kernel duration sum counts overlapping intervals twice; union merges them. Single reported stream per engine does not eliminate the measured small interval overlaps.",
        ],
        "timing_limits": [
            "Recorded kernel intervals can include scheduling/preemption/profiler effects and are not pure arithmetic execution. Neither GPU interval sum nor union is submit/wait wall time.",
            "Inter-kernel gaps covered by memcpy/memset are separated from uncovered gaps. Uncovered does not mean CPU work or removable launch latency; other processes, dependencies and instrumentation may contribute.",
            "Hyle7 launches plus uncaptured kernels and peer1 launch differ structurally. GraphLaunch API duration overlaps queued GPU execution; API-end-to-first-kernel delay includes backlog, not a standalone launch cost. These numbers are nonadditive.",
            "Token-to-first-kernel includes consumer preparation/uploads and previous sampled-logits transfer in peer. The first/last boundary gaps must not be interpreted as pure CPU or GPU time.",
            "Both traces use the retained pre-stderr-fix Hyle profile image or the separately sampled peer image. They are different capture periods, not the same-window unprofiled85.74/93.31tokens/s pair (~0.946ms/token difference). No causal fraction or speedup follows.",
            "Nsight has the existing driver13.4/tool13.3 fallback warning. The memcpy byte-label anomaly is documented separately; interval coverage here uses timestamps, not those byte totals.",
        ],
    }
    destination = STAGE / "kernel-interval-review.json"
    a.save(destination, result)
    print(json.dumps({"output": a.identity(destination), "projection": result["projection_summary_us"],
                      "top_family_deltas": category[:5]}))


if __name__ == "__main__":
    main()
