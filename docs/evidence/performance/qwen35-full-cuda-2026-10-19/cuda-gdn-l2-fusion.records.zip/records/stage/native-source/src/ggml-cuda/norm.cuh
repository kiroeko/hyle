#include "common.cuh"

void ggml_cuda_op_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_group_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_rms_norm_cast_fused(ggml_backend_cuda_context & ctx,
                                      const ggml_tensor * x,
                                      const ggml_tensor * norm,
                                      const ggml_tensor * mul,
                                      ggml_tensor * dst);

void ggml_cuda_op_rms_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_rms_norm_fused(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * mul_tensor);

void ggml_cuda_op_rms_norm_fused_add(ggml_backend_cuda_context & ctx,
                                     ggml_tensor *               dst,
                                     ggml_tensor *               mul_tensor,
                                     ggml_tensor *               add_tensor);

void ggml_cuda_op_rms_norm_back(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_l2_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

// Dense BF16 square -> F32 SUM_ROWS -> BF16 sum/add -> strict F32 sqrt ->
// fast F32 div -> BF16 scale/multiply, preserving every original BF16 RNE.
// x/dst may be disjoint or exact same dense mapping; partial overlap is not
// allowed. epsilon is one runtime BF16 scalar. numerator is the unchanged
// contiguous F32 REPEAT result, shape [1,x.ne[1],x.ne[2],x.ne[3]]. Neither
// scalar input may overlap dst. The native matcher owns all graph-use,
// published-output, control, device, operation and memory-overlap eligibility.
void ggml_cuda_op_bf16_l2_core_fused(ggml_backend_cuda_context & ctx,
                                     const ggml_tensor * x,
                                     const ggml_tensor * epsilon,
                                     const ggml_tensor * numerator,
                                     ggml_tensor * dst);
