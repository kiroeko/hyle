"""Summarize the retained one-shot L2 native graph metadata; no device use."""
import collections
import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
RUN = STAGE / "checks/20261019T072429-db379337/run"
LOG = RUN / "qwen.stderr.log"
PREFIX = "HYLE_GDN_L2_DIAG "
CORE = ["MUL:bf16", "CPY:f32", "RESHAPE:f32", "SUM_ROWS:f32", "CPY:bf16",
        "ADD:bf16", "CPY:f32", "SQRT:f32", "DIV:f32", "CPY:bf16", "MUL:bf16"]


def source(graph, tensor, slot=0):
    return graph["tensors"][next(s["ptr"] for s in tensor["src"] if s["slot"] == slot)]


def overlap(a, b):
    a0, a1, b0, b1 = (int(t[k], 16) for t, k in ((a, "data"), (a, "end"), (b, "data"), (b, "end")))
    assert a0 and b0 and not a["overflow"] and not b["overflow"]
    return "same_span" if (a0, a1) == (b0, b1) else "partial" if a0 < b1 and b0 < a1 else "disjoint"


def descriptor(t):
    return t["dtype"], t["ne"], t["nb"]


def span(t):
    return {k: t[k] for k in ("i", "data", "end", "bytes", "ne", "nb")}


def main():
    graphs = {}
    rows = []
    phase = "T128"
    boundary = None
    for line_number, line in enumerate(LOG.read_text().splitlines(), 1):
        if line.startswith("prepared T=128 "):
            boundary, phase = line_number, "T1"
        if not line.startswith(PREFIX):
            continue
        row = json.loads(line[len(PREFIX):])
        row.update(line=line_number, phase=phase)
        rows.append(row)
        if row["event"] == "graph":
            graphs[row["id"]] = {"header": row, "tensors": {}}
        elif row["event"] == "tensor":
            graphs[row["id"]]["tensors"][row["ptr"]] = row
        elif row["event"] == "graph_end":
            graphs[row["id"]]["end"] = row
        else:
            raise AssertionError(row)
    assert len(graphs) == 72 and all("end" in g for g in graphs.values())
    assert list(graphs) == list(range(72))
    receipt = json.loads((RUN / "qwen.result.json").read_text())
    assert receipt["terminal"] and receipt["exit"] == 0
    result = {
        "scope": "One existing diagnostic --steps 2 run; native metadata only, no new GPU/build or timing claim.",
        "log": {"path": str(LOG), "bytes": LOG.stat().st_size, "sha256": hashlib.sha256(LOG.read_bytes()).hexdigest()},
        "receipt": str(RUN / "qwen.result.json"), "exit": 0,
        "coverage": {"graphs": 72, "complete_graph_end": 72, "truncated": False,
                     "parse_errors": 0, "cap_bytes": 1048576, "phase_boundary_line": boundary,
                     "events": dict(collections.Counter(r["event"] for r in rows))},
        "core_native_sequence": CORE,
        "core_uses": [1, 2, 1, 1, 2, 1, 2, 1, 1, 2, 1],
        "phases": {},
    }
    for phase in ("T128", "T1"):
        chosen = [g for g in graphs.values() if g["header"]["phase"] == phase]
        assert len(chosen) == 36
        alias_counts = collections.defaultdict(collections.Counter)
        example = None
        for graph in chosen:
            nodes = sorted((t for t in graph["tensors"].values() if t["i"] >= 0), key=lambda t: t["i"])
            start = 7 if phase == "T128" else 1
            core = nodes[start:start+11]
            assert [t["op"] + ":" + t["dtype"] for t in core] == CORE
            assert [t["uses"] for t in core] == result["core_uses"]
            assert all(t["flags"] == 16 and not t["overflow"] and not t["view_limit"] for t in core)
            assert len(nodes) == (20 if phase == "T128" else 13)
            x, lhs, rhs = source(graph, core[-1]), source(graph, core[0]), source(graph, core[0], 1)
            eps, numerator = source(graph, core[5], 1), source(graph, core[8])
            assert eps["op"] == "NONE" and eps["dtype"] == "bf16" and eps["ne"] == [1, 1, 1, 1]
            assert numerator["op"] == "REPEAT" and numerator["dtype"] == "f32" and numerator["ne"][0] == 1
            assert source(graph, numerator)["op"] == "NONE"
            assert source(graph, numerator)["dtype"] == "f32"
            assert source(graph, numerator)["ne"] == [1, 1, 1, 1]
            assert descriptor(x) == descriptor(lhs) == descriptor(rhs)
            if phase == "T1":
                assert x["ptr"] == lhs["ptr"] == rhs["ptr"] and x["op"] == "NONE"
            else:
                copies = [source(graph, t) for t in (x, lhs, rhs)]
                assert len({t["ptr"] for t in copies}) == 3
                assert all(t["op"] == "RESHAPE" and t["view_offs"] == 0 for t in (x, lhs, rhs))
                assert all(t["op"] == "CONT" for t in copies)
                assert all(descriptor(t) == descriptor(copies[0]) for t in copies)
                assert len({source(graph, t)["ptr"] for t in copies}) == 1
            for t in (core[1], core[4], core[6], core[9], nodes[start+11]):
                assert source(graph, t, 1)["ptr"] == t["ptr"]
            reshape = core[2]
            assert reshape["view_offs"] == 0 and reshape["view_src"] == core[1]["ptr"]
            assert descriptor(reshape) == descriptor(core[1]) and overlap(reshape, core[1]) == "same_span"
            elided = {t["ptr"] for t in core[:-1]}
            outside_readers = [(t["i"], s["slot"]) for t in nodes if t["ptr"] not in {v["ptr"] for v in core}
                               for s in t["src"] if s["ptr"] in elided]
            assert outside_readers == []
            targets = {"x_final": x, "square_lhs": lhs, "square_rhs": rhs,
                       "sum_f32": core[3], "sum_bf16": core[4], "eps_add": core[5],
                       "rsqrt_wide": core[6], "sqrt": core[7], "div": core[8],
                       "scale_bf16": core[9], "numerator": numerator, "epsilon": eps}
            for name, tensor in targets.items():
                alias_counts[name][overlap(core[-1], tensor)] += 1
            alias_counts["numerator_vs_div"][overlap(numerator, core[8])] += 1
            if example is None:
                example = {"graph_id": graph["header"]["id"], "log_line": graph["header"]["line"],
                           "spans": {name: span(t) for name, t in {"x_final": x, "square_lhs": lhs,
                               "square_rhs": rhs, "sum_f32": core[3], "epsilon": eps,
                               "numerator": numerator, "dst": core[-1]}.items()}}
        result["phases"][phase] = {
            "graphs": 36, "nodes_per_graph": 20 if phase == "T128" else 13,
            "native_core_span_inclusive": [7, 17] if phase == "T128" else [1, 11],
            "core_nodes": 11, "core_actual_dispatches": 10,
            "retained_prefix": ["CONT:bf16", "RESHAPE:bf16", "REPEAT:f32", "CONT:bf16", "RESHAPE:bf16", "CONT:bf16", "RESHAPE:bf16"] if phase == "T128" else ["REPEAT:f32"],
            "retained_suffix": ["CPY:f32", "RESHAPE:f32"] if phase == "T128" else ["CPY:f32"],
            "square_input_identity": "Three distinct CONT copies with same source leaf and exact same CONT descriptor, followed by dense zero-offset flatten reshapes; no physical-pointer equality." if phase == "T128" else "Both square operands and final Mul x are the exact same BF16 external tensor pointer.",
            "elided_nodes_published": 0, "elided_nodes_with_outside_src_readers": 0,
            "final_bf16_mul_uses": 1, "final_f32_cast_output_flag": True,
            "dst_alias_counts": {k: dict(v) for k, v in alias_counts.items()}, "example": example,
        }
    result["matcher_constraints"] = [
        "Match generic types/edges/descriptors, never model names. The core is 11 native nodes but 10 kernels because the F32 RESHAPE is metadata only.",
        "The retained REPEAT is DIV.src0. Pass its actual F32 output to the kernel; do not infer or host-read a constant 1. Keep final BF16-to-F32 CPY/public output and optional rank-restoring RESHAPE.",
        "Use final Mul's x as the actual fused read. T128 square lhs/rhs buffers partially overlap dst in all36 graphs; final Mul x, epsilon and retained numerator are disjoint from dst in all72 graphs.",
        "T128 equivalence requires exact same source tensor and CONT descriptor plus safe zero-offset dense flatten metadata; reject arbitrary noncontiguous reshape/permutation/slice equivalence. CONT operations remain executed.",
        "All core flags are COMPUTE=16, none OUTPUT=2. CPY.src1 is self; expected usecount includes self. Retain private F32 RESHAPE through an exact descriptor/span/root check; do not weaken global view/public/multireader guards.",
        "Require all elided readers inside the checked core, reject published/shared intermediates and unsupported mappings; check actual kernel external read spans including OP_NONE epsilon/numerator/x and reject unsafe partial alias.",
        "Epsilon is one BF16 runtime leaf here; value was not read. Preserve dynamic scalar arithmetic and reject unsupported epsilon broadcast shapes rather than assume the Qwen literal.",
    ]
    destination = STAGE / "findings.json"
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(destination), "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
