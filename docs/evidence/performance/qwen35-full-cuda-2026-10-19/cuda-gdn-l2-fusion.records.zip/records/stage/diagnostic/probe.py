"""One diagnostic native TU and a two-step Qwen journey. No product edits or timing claims."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parents[1]
spec=importlib.util.spec_from_file_location('projection_tools',ARCH/'cuda-projection-fusion/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
BASE=ARCH/'cuda-rms-inplace/checks/20261019T071441-877cffe6/qwen-link-plan.json'
RECIPE=ARCH/'cuda-rms-inplace/checks/20261019T071441-877cffe6/ggml-cuda-identity.json'
SOURCE=STAGE/'native-source/src/ggml-cuda/ggml-cuda.cu'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',action='store_true');p.add_argument('--run',type=Path)
    p.add_argument('--seal-build',type=Path)
    p.add_argument('--run-name',default='run')
    args=p.parse_args()
    if args.seal_build:
        path=args.seal_build.resolve();plan=c.read(path);out=path.parent
        for tag in ('main-diag-compile','qwen-link'):
            result=c.read(out/(tag+'.result.json'))
            if result['exit']!=0:raise ValueError('Build command failed: '+tag)
        for row in plan['frozen']+plan['cached']:
            if not b.same(row):raise ValueError('Build input drift')
        seal(plan,out);print('BUILD_SEALED',path,flush=True);return
    if args.run:
        path=args.run.resolve();plan=c.read(path);out=path.parent
        if not c.read(out/'build-summary.json')['passed']:raise ValueError('Diagnostic build failed')
        image=Path(plan['image'])
        if b.identity(image)!=c.read(out/'image.json'):raise ValueError('Diagnostic image drift')
        if Path(args.run_name).name!=args.run_name:raise ValueError('Run name must be a directory basename')
        run=out/args.run_name;run.mkdir(exist_ok=False);(run/'tmp').mkdir()
        env,_=b.environment(plan['link'],[row['path'] for row in plan['cached']],run)
        env['HYLE_GDN_L2_DIAG']='1'
        original=c.read(ARCH/'cuda-reshape-reuse/profile-qwen.command.json')['command']
        index=original.index('--inputs')-1
        command=[str(image)]+original[index+1:]
        command[command.index('--steps')+1]='2'
        decode=Path(command[command.index('--decode-ids')+1]);ids=decode.read_text().split()
        if len(ids)!=31:raise ValueError('Unexpected original decode input')
        short_ids=run/'decode-one.ids';short_ids.write_text(ids[0]+'\n',encoding='utf-8')
        command[command.index('--decode-ids')+1]=str(short_ids)
        c.execute('qwen',command,env,run)
        c.save(run/'summary.json',{'image':b.identity(image),'steps':2,
            'latency_claim':False,'quality_acceptance':False,'diagnostic_only':True})
        print('DIAGNOSTIC_COMPLETE',run,flush=True);return
    out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    base=c.read(BASE);recipe=c.read(RECIPE)
    cached=base['inputs']
    if not all(b.same(row) for row in cached):raise ValueError('Retained input drift')
    old=[row['path'] for row in cached if Path(row['path']).name=='ggml-cuda.obj']
    if len(old)!=1:raise ValueError('Expected one native main owner')
    template=[];skip=False
    for item in recipe['command']:
        if skip:skip=False;continue
        if item=='-ccbin':skip=True;continue
        template.append(item)
    compile=b.native_command(template,SOURCE,'main-diag',out)
    obj=out/'main-diag.obj';image=out/'qwen-diag.exe'
    link=[str(obj) if c.key(item)==c.key(old[0]) else item for item in base['command']
        if not item.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
        '/IMPLIB:'+str(image.with_suffix('.lib'))]
    frozen=[b.identity(SOURCE),b.identity(BASE),b.identity(RECIPE)]
    plan={'compile':compile,'link':link,'image':str(image),'cached':cached,
        'source':b.identity(SOURCE),'frozen':frozen,'native_TUs':1,'SDK_build':False,
        'product_edits':False,'diagnostic_only':True}
    path=out/'plan.json';c.save(path,plan);print('PLAN',path,flush=True)
    if not args.build:return
    (out/'tmp').mkdir();env,_=b.environment(link,[row['path'] for row in cached],out)
    for row in frozen+cached:
        if not b.same(row):raise ValueError('Input drift')
    c.execute('main-diag-compile',compile,env,out)
    c.save(out/'main-diag-identity.json',{'command':compile,'object':b.identity(obj),'source':b.identity(SOURCE)})
    c.execute('qwen-link',link,env,out)
    seal(plan,out)
    print('BUILD_COMPLETE',path,flush=True)

def seal(plan,out):
    c.save(out/'qwen-link-plan.json',{'command':plan['link'],'inputs':[b.identity(item) for item in plan['link']
        if not item.startswith('/') and Path(item).is_absolute() and Path(item).suffix.lower() in ('.obj','.lib')]})
    c.save(out/'image.json',b.identity(plan['image']))
    c.save(out/'build-summary.json',{'passed':True,'native_TUs':1,'tests_run':False})

if __name__=='__main__':main()
