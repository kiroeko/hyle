"""Generate one scratch-only v13 native main with bounded graph metadata logging."""
from pathlib import Path
import difflib
import hashlib
import json


REPO = Path(__file__).resolve().parents[4]
STAGE = Path(__file__).resolve().parent
BASE_STAGE = REPO / ".scratch/architecture-refactor-2026-10-18/cuda-rms-inplace"
HEADER_STAGE = REPO / ".scratch/architecture-refactor-2026-10-18/cuda-rms-cast-fusion"
RELATIVE = "src/ggml-cuda/ggml-cuda.cu"
SOURCE = BASE_STAGE / "native-source" / RELATIVE
DESTINATION = STAGE / "native-source" / RELATIVE
EXPECTED = "041fd4f88afaca02b2223f246981e3415fa960b2762d9fc50af3775838213135"

HELPERS = r'''
// BEGIN HYLE_GDN_L2_DIAG: scratch-only host metadata, no payload/device reads.
struct hyle_gdn_l2_diag_state {
    std::mutex mutex;
    std::vector<const ggml_cgraph *> seen;
    size_t bytes = 0;
    unsigned next_id = 0;
    bool truncated = false;
};

static bool hyle_gdn_l2_diag_enabled() {
    static const bool enabled = [] {
        const char * value = std::getenv("HYLE_GDN_L2_DIAG");
        return value && std::atoi(value) != 0;
    }();
    return enabled;
}

// Called only under the one diagnostic mutex, including the cap notice.
static bool hyle_gdn_l2_diag_line(hyle_gdn_l2_diag_state & state, const char * format, ...) {
    if (state.truncated) return false;
    constexpr size_t cap = 1024 * 1024;
    constexpr const char prefix[] = "HYLE_GDN_L2_DIAG ";
    char record[4096];
    va_list args;
    va_start(args, format);
    const int length = std::vsnprintf(record, sizeof(record), format, args);
    va_end(args);
    if (length < 0 || size_t(length) >= sizeof(record) ||
        size_t(length) + sizeof(prefix) + 1 + state.bytes > cap - 256) {
        const int emitted = std::fprintf(stderr,
            "HYLE_GDN_L2_DIAG {\"event\":\"truncated\",\"cap_bytes\":1048576,\"bytes_before\":%llu,\"reason\":\"%s\"}\n",
            (unsigned long long) state.bytes,
            length < 0 || size_t(length) >= sizeof(record) ? "record_format" : "total_cap");
        if (emitted > 0) state.bytes += size_t(emitted) + 1; // Reserve possible Windows CRLF translation.
        state.truncated = true;
        return false;
    }
    const int emitted = std::fprintf(stderr, "%s%s\n", prefix, record);
    if (emitted > 0) state.bytes += size_t(emitted) + 1; // Conservative physical byte accounting.
    return emitted > 0;
}

static int hyle_gdn_l2_diag_index(const ggml_cgraph * graph, const ggml_tensor * tensor) {
    if (!tensor) return -1;
    for (int i = 0; i < graph->n_nodes; ++i) if (graph->nodes[i] == tensor) return i;
    return -1;
}

static int hyle_gdn_l2_diag_leaf(const ggml_cgraph * graph, const ggml_tensor * tensor) {
    if (!tensor) return -1;
    for (int i = 0; i < graph->n_leafs; ++i) if (graph->leafs[i] == tensor) return i;
    return -1;
}

static int hyle_gdn_l2_diag_uses(const ggml_cgraph * graph, const ggml_tensor * tensor) {
    if (!tensor) return -1;
    const size_t slot = ggml_hash_find(&graph->visited_hash_set, tensor);
    if (slot == GGML_HASHSET_FULL || !ggml_bitset_get(graph->visited_hash_set.used, slot)) return -1;
    return graph->use_counts[slot];
}

static bool hyle_gdn_l2_diag_tensor(hyle_gdn_l2_diag_state & state, unsigned id,
                                   const ggml_cgraph * graph, const ggml_tensor * tensor) {
    char sources[1536] = "";
    size_t used = 0;
    bool first = true;
    for (int slot = 0; slot < GGML_MAX_SRC; ++slot) {
        const ggml_tensor * source = tensor->src[slot];
        if (!source) continue;
        const int written = std::snprintf(sources + used, sizeof(sources) - used,
            "%s{\"slot\":%d,\"i\":%d,\"leaf\":%d,\"ptr\":\"%p\"}", first ? "" : ",",
            slot, hyle_gdn_l2_diag_index(graph, source), hyle_gdn_l2_diag_leaf(graph, source),
            (const void *) source);
        if (written < 0 || size_t(written) >= sizeof(sources) - used) {
            return hyle_gdn_l2_diag_line(state,
                "{\"event\":\"source_format_error\",\"id\":%u,\"tensor\":\"%p\"}", id, (const void *) tensor);
        }
        used += size_t(written);
        first = false;
    }
    const ggml_tensor * root = tensor;
    int depth = 0;
    bool view_limit = false;
    while (root->view_src) {
        if (root->view_src == root || depth == 64) { view_limit = true; break; }
        root = root->view_src;
        ++depth;
    }
    const size_t bytes = ggml_nbytes(tensor);
    const uintptr_t start = (uintptr_t) tensor->data;
    const bool overflow = bytes > UINTPTR_MAX - start;
    return hyle_gdn_l2_diag_line(state,
        "{\"event\":\"tensor\",\"id\":%u,\"i\":%d,\"leaf\":%d,\"ptr\":\"%p\","
        "\"op\":\"%s\",\"dtype\":\"%s\",\"uses\":%d,\"flags\":%u,"
        "\"ne\":[%lld,%lld,%lld,%lld],\"nb\":[%llu,%llu,%llu,%llu],"
        "\"view_src\":\"%p\",\"view_offs\":%llu,\"view_root\":\"%p\",\"view_depth\":%d,\"view_limit\":%s,"
        "\"data\":\"%p\",\"end\":\"%p\",\"bytes\":%llu,\"overflow\":%s,\"src\":[%s]}",
        id, hyle_gdn_l2_diag_index(graph, tensor), hyle_gdn_l2_diag_leaf(graph, tensor), (const void *) tensor,
        ggml_op_name(tensor->op), ggml_type_name(tensor->type), hyle_gdn_l2_diag_uses(graph, tensor),
        (unsigned) tensor->flags,
        (long long) tensor->ne[0], (long long) tensor->ne[1], (long long) tensor->ne[2], (long long) tensor->ne[3],
        (unsigned long long) tensor->nb[0], (unsigned long long) tensor->nb[1],
        (unsigned long long) tensor->nb[2], (unsigned long long) tensor->nb[3],
        (const void *) tensor->view_src, (unsigned long long) tensor->view_offs, (const void *) root,
        depth, view_limit ? "true" : "false", tensor->data, (void *) (overflow ? 0 : start + bytes),
        (unsigned long long) bytes, overflow ? "true" : "false", sources);
}

static void hyle_gdn_l2_diag_dump(const ggml_cgraph * graph) {
    if (!hyle_gdn_l2_diag_enabled() || !graph) return;
    int sum_rows = 0, sqrt_count = 0, div_count = 0;
    for (int i = 0; i < graph->n_nodes; ++i) {
        sum_rows += graph->nodes[i]->op == GGML_OP_SUM_ROWS;
        sqrt_count += graph->nodes[i]->op == GGML_OP_SQRT;
        div_count += graph->nodes[i]->op == GGML_OP_DIV;
    }
    if (!sum_rows || !sqrt_count || !div_count) return;
    static hyle_gdn_l2_diag_state state;
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.truncated || std::find(state.seen.begin(), state.seen.end(), graph) != state.seen.end()) return;
    state.seen.push_back(graph);
    const unsigned id = state.next_id++;
    if (!hyle_gdn_l2_diag_line(state,
        "{\"event\":\"graph\",\"id\":%u,\"ptr\":\"%p\",\"nodes\":%d,\"leafs\":%d,\"sum_rows\":%d,\"sqrt\":%d,\"div\":%d}",
        id, (const void *) graph, graph->n_nodes, graph->n_leafs, sum_rows, sqrt_count, div_count)) return;
    std::vector<const ggml_tensor *> external;
    const auto add_external = [&](const ggml_tensor * tensor) {
        if (tensor && hyle_gdn_l2_diag_index(graph, tensor) < 0 &&
            std::find(external.begin(), external.end(), tensor) == external.end()) external.push_back(tensor);
    };
    for (int i = 0; i < graph->n_nodes; ++i) {
        const ggml_tensor * tensor = graph->nodes[i];
        for (int slot = 0; slot < GGML_MAX_SRC; ++slot) add_external(tensor->src[slot]);
        add_external(tensor->view_src);
        if (!hyle_gdn_l2_diag_tensor(state, id, graph, tensor)) return;
    }
    for (size_t i = 0; i < external.size(); ++i) {
        const ggml_tensor * tensor = external[i];
        for (int slot = 0; slot < GGML_MAX_SRC; ++slot) add_external(tensor->src[slot]);
        add_external(tensor->view_src);
        if (!hyle_gdn_l2_diag_tensor(state, id, graph, tensor)) return;
    }
    hyle_gdn_l2_diag_line(state,
        "{\"event\":\"graph_end\",\"id\":%u,\"nodes\":%d,\"external\":%llu,\"complete\":true}",
        id, graph->n_nodes, (unsigned long long) external.size());
}
// END HYLE_GDN_L2_DIAG

'''


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    assert identity(SOURCE)["sha256"] == EXPECTED
    original = SOURCE.read_text()
    anchor = "static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {\n"
    assert original.count(anchor) == 1
    # The graph walk skips metadata/no-op nodes before try_fuse. Hook before
    # that filter so a leading View cannot hide the graph from one-shot logging.
    walk = "    for (int i = 0; i < cgraph->n_nodes; i++) {\n        ggml_tensor * node = cgraph->nodes[i];\n        if (is_concurrent_event_active) {\n"
    assert original.count(walk) == 1
    instrumented_walk = walk.replace("        if (is_concurrent_event_active) {\n", "        if (i == 0) hyle_gdn_l2_diag_dump(cgraph);\n        if (is_concurrent_event_active) {\n")
    generated = original.replace(anchor, HELPERS + anchor).replace(walk, instrumented_walk)
    assert generated.replace(HELPERS, "", 1).replace(instrumented_walk, walk, 1) == original
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    DESTINATION.write_text(generated, encoding="utf-8", newline="\n")
    (STAGE / "native-change.diff").write_text("".join(difflib.unified_diff(
        original.splitlines(keepends=True), generated.splitlines(keepends=True),
        fromfile=str(SOURCE), tofile=str(DESTINATION))), encoding="utf-8", newline="\n")
    freeze = {
        "scope": "Scratch-only L2 graph metadata diagnostics; product manifest/source predicates unchanged; no build/GPU/latency claim.",
        "prepare_script": identity(Path(__file__).resolve()),
        "input": identity(SOURCE), "output": identity(DESTINATION),
        "required_header": identity(HEADER_STAGE / "native-source/src/ggml-cuda/norm.cuh"),
        "prepend_include_directories": [str(HEADER_STAGE / "native-source/src"), str(HEADER_STAGE / "native-source/src/ggml-cuda")],
        "include_note": "This stage contains only the main TU; prepend both v12 header directories before cached original sources, preserving the existing v13 main compile recipe otherwise.",
        "environment": {"HYLE_GDN_L2_DIAG": "1"},
        "run_boundary": "One root-controlled --steps 2 diagnostic run; do not use this image for performance measurements.",
        "stderr_prefix": "HYLE_GDN_L2_DIAG ", "cap_bytes": 1048576,
        "selection": "At graph walk i==0 before metadata/View filtering that precedes try_fuse, graph contains SUM_ROWS and SQRT and DIV; dump each matching graph pointer once.",
        "records": "All native nodes and recursively referenced external tensors: op/type/ne/nb/usecount/flags/src slots with graph and leaf indexes/pointers/view source+offset+root/data byte spans; graph_end marks complete.",
        "no_payload_or_device_reads": True, "predicate_changes": False,
        "unverified": ["Compilation", "Runtime coverage", "Actual L2 shape/edge matching"],
    }
    (STAGE / "source-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": freeze["output"], "script": freeze["prepare_script"]}))


if __name__ == "__main__":
    main()
