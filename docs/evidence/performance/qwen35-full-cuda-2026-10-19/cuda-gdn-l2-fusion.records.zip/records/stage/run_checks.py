"""Run the 17 retained plus two GDN cases, or one byte-exact Qwen replay."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def main():
    if len(sys.argv)!=3 or sys.argv[2] not in ('cuda','qwen'):raise ValueError('Usage: plan.json {cuda|qwen}')
    b=load('gdn_current_build',STAGE/'build_current.py');path=Path(sys.argv[1]).resolve();plan=b.c.read(path);b.check(plan)
    retained=b.c.read(b.BASE/'run-cuda/summary.json')['cases']
    cases=retained+plan['directed_tests']
    if len(cases)!=19 or len(set(cases))!=19:raise ValueError('Expected nineteen distinct CUDA cases')
    runner=load('gdn_retained_checks',b.ARCH/'cuda-normalization-review/run_checks.py')
    runner.STAGE=STAGE;runner.b=b;runner.c=b.c;runner.CASES={'cuda':cases}
    runner.main()
if __name__=='__main__':main()
