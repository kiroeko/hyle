"""Two native and three host TUs against the retained v13 closure; no SDK build."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import re
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=STAGE.parents[2]
spec=importlib.util.spec_from_file_location('gdn_increment_base',ARCH/'cuda-projection-fusion/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
BASE=ARCH/'cuda-rms-inplace/checks/20261019T071441-877cffe6'
V12=ARCH/'cuda-rms-cast-fusion/checks/20261019T065214-eb0b4c02'
TENSOR_RECIPE=ARCH/'cuda-normalization-review/checks/20261019T060757-4cda26e4/78-compute_provider_ggml_cuda-tensor_program-identity.json'

def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
def check(plan):
    for row in plan['frozen']+plan['cached_inputs']:
        if not b.same(row):raise ValueError('Input drift: '+row['path'])
def stripped_native(template):
    command=[];skip=False
    for item in template:
        if skip:skip=False;continue
        if item=='-ccbin':skip=True;continue
        command.append(item)
    return command

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',action='store_true');args=p.parse_args()
    out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    freeze=c.read(STAGE/'native-source-freeze.json');header=STAGE/'provider-version.h'
    frozen=[b.identity(x) for x in (Path(__file__),STAGE/'run_checks.py',header,STAGE/'native-source-freeze.json',
        ROOT/'third_party/ggml_cuda_runtime/patches.json',ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT/'cmake/HyleDependencyLock.json',ROOT/'src/compute_provider_ggml_cuda/tensor_program.h',
        ROOT/'tests/graph_provider_ggml_cuda/CMakeLists.txt')]
    compiles=[];replacements={}
    for tag,recipe_path in (('ggml-cuda',BASE/'ggml-cuda-identity.json'),('norm',V12/'norm-identity.json')):
        recipe=c.read(recipe_path);source=STAGE/'native-source/src/ggml-cuda'/(tag+'.cu')
        if b.identity(source)['sha256']!=freeze['sources']['src/ggml-cuda/'+tag+'.cu']:raise ValueError('Native source differs')
        command=b.native_command(stripped_native(recipe['command']),source,tag,out)
        command[1:1]=['-I'+str(source.parent.parent),'-I'+str(source.parent)]
        compiles.append({'tag':tag,'command':command,'source':b.identity(source),'object':str(out/(tag+'.obj'))})
        replacements[c.key(recipe['object']['path'])]=str(out/(tag+'.obj'))
        frozen.extend((b.identity(source),b.identity(recipe_path)))
    frozen.append(b.identity(STAGE/'native-source/src/ggml-cuda/norm.cuh'))
    for tag,relative,recipe_path in (
        ('provider','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',BASE/'provider-identity.json'),
        ('tensor-program','src/compute_provider_ggml_cuda/tensor_program.cc',TENSOR_RECIPE),
        ('gdn-l2-test','tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc',BASE/'rms-cast-test-identity.json')):
        recipe=c.read(recipe_path);template=recipe['command']
        if tag=='provider':template=['/FI'+str(header) if x.lower().startswith('/fi') else x for x in template]
        source=ROOT/relative;command=b.host_command(template,source,tag,out)
        compiles.append({'tag':tag,'command':command,'source':b.identity(source),'object':str(out/(tag+'.obj'))})
        if tag!='gdn-l2-test':replacements[c.key(recipe['object']['path'])]=str(out/(tag+'.obj'))
        frozen.extend((b.identity(source),b.identity(recipe_path)))
        frozen.extend(b.identity(x) for x in b.host_dependencies(template) if x.is_file())
    cases=['.'.join(x) for x in re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',
        (ROOT/'tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc').read_text())]
    if len(cases)!=2 or len(set(cases))!=2:raise ValueError('Expected two GDN cases')
    links={};cached={}
    for name,count in (('qwen',123),('cuda',130)):
        path=BASE/(name+'-link-plan.json');base=c.read(path);frozen.append(b.identity(path))
        if len(base['inputs'])!=count:raise ValueError('Retained closure differs')
        for row in base['inputs']:cached[row['path']]=row
        for key in replacements:
            if sum(c.key(x['path'])==key for x in base['inputs'])!=1:raise ValueError('Replacement owner missing')
        command=[replacements.get(c.key(x),x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if name=='cuda':command[1:1]=[str(out/'gdn-l2-test.obj')]
        image=out/(name+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        if len(inputs(command))!=count+(name=='cuda'):raise ValueError('New closure differs')
        links[name]={'command':command,'image':str(image),'inputs':inputs(command)}
    plan={'compile':compiles,'links':links,'frozen':list({x['path']:x for x in frozen}.values()),
        'cached_inputs':list(cached.values()),'directed_tests':cases,'native_source_id':freeze['source_id'],
        'native_TUs':2,'host_TUs':3,'SDK_build':False,'CMake_run':False}
    target=out/'plan.json';c.save(target,plan);check(plan);print('PLAN',target,flush=True)
    if not args.build:return
    (out/'tmp').mkdir();env,_=b.environment(links['qwen']['command'],list(cached),out)
    for item in compiles:
        c.execute(item['tag']+'-compile',item['command'],env,out);check(plan)
        c.save(out/(item['tag']+'-identity.json'),{'command':item['command'],'source':item['source'],'object':b.identity(item['object'])})
    for name,link in links.items():
        c.save(out/(name+'-link-plan.json'),{'command':link['command'],'inputs':[b.identity(x) for x in link['inputs']]})
        c.execute(name+'-link',link['command'],env,out);check(plan);c.save(out/(name+'-image.json'),b.identity(link['image']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':2,'host_TUs':3,'GPU_run':False})
    print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
