"""One consumer TU: move diagnostics after the endpoint-complete step timer."""
from pathlib import Path
import datetime as dt
import importlib.util
import json
import sys
import difflib
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('timing_build_base',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
BASE=STAGE/'checks/20261019T073103-c4e59236/plan.json'
RECIPE=b.ARCH/'cold-constant-retirement/cuda-checks/20261019T051553-817e50eb/consumer-identity.json'

def main():
    base=c.read(BASE);b.check(base)
    old=c.read(RECIPE);source=b.ROOT/'tools/qwen35_text/main.cc'
    before=STAGE/'timing-boundary/main.before.cc'
    if b.b.identity(before)['sha256']!=old['source']['sha256']:raise ValueError('Original consumer source differs from retained object')
    out=STAGE/'checks'/('timing-report-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
    out.mkdir(exist_ok=False)
    command=b.b.host_command(old['command'],source,'consumer',out)
    cached=c.read(BASE.parent/'qwen-link-plan.json')['inputs']
    old_obj=old['object']['path']
    if sum(c.key(row['path'])==c.key(old_obj) for row in cached)!=1:raise ValueError('Expected one consumer owner')
    image=out/'qwen.exe'
    link=[str(out/'consumer.obj') if c.key(x)==c.key(old_obj) else x for x in base['links']['qwen']['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    frozen=base['frozen']+[b.b.identity(x) for x in (source,before,RECIPE,Path(__file__))]
    frozen.extend(b.b.identity(x) for x in b.b.host_dependencies(old['command']) if x.is_file())
    plan=dict(base,compile=[{'tag':'consumer','command':command,'source':b.b.identity(source),'object':str(out/'consumer.obj')}],
        frozen=list({row['path']:row for row in frozen}.values()),
        cached_inputs=list({row['path']:row for row in base['cached_inputs']+cached}.values()),
        links=dict(base['links'],qwen={'command':link,'image':str(image),'inputs':b.inputs(link)}),
        native_TUs=0,host_TUs=1,timing_only=True,math_and_library_objects_unchanged=True,base_plan=b.b.identity(BASE))
    target=out/'plan.json';c.save(target,plan);b.check(plan)
    print('PLAN',target,flush=True)
    (out/'tmp').mkdir();env,_=b.b.environment(link,[row['path'] for row in plan['cached_inputs']],out)
    c.execute('consumer-compile',command,env,out);b.check(plan)
    c.save(out/'consumer-identity.json',{'command':command,'source':b.b.identity(source),'object':b.b.identity(out/'consumer.obj')})
    c.execute('qwen-link',link,env,out);b.check(plan)
    c.save(out/'qwen-link-plan.json',{'command':link,'inputs':[b.b.identity(x) for x in b.inputs(link)]})
    c.save(out/'qwen-image.json',b.b.identity(image))
    c.save(out/'summary.json',{'passed':True,'native_TUs':0,'host_TUs':1,'links':1,'math_unchanged':True,'tests_run':False})
    (STAGE/'timing-boundary/reporting-change.diff').write_text(''.join(difflib.unified_diff(
        before.read_text().splitlines(True),source.read_text().splitlines(True),fromfile='before/main.cc',tofile='after/main.cc')),encoding='utf-8')
    print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
