"""Retained llama peer relink + three fresh pairs, or one separate peer trace."""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


b = load('gdn_peer_build', STAGE / 'build_current.py')
c = b.c
metrics = load('gdn_peer_metrics', b.ARCH / 'cuda-normalization-review/experiment.py').metrics
PEER_PLAN = b.ARCH / 'cuda-current-peer/peer-link-plan.json'
FAIR_PLAN = b.ARCH / 'cuda-current-peer/run-plan.json'
MODEL_RECEIPT = b.ARCH / 'llama-matched-consumer/converted-file-identity.json'
PEER_COMMIT = 'd9e03f1074dbd2979126d91dce1b5d304ec8394e'
KEYS = ('prefill_tokens_per_second', 'full31_tokens_per_second', 'warm7_31_tokens_per_second')


def execute(tag, command, env, out):
    if any(out.glob(tag + '.*')):
        raise ValueError('Refusing overwrite or implicit retry: ' + tag)
    try:
        return c.execute(tag, list(map(str, command)), env, out)
    finally:
        result = out / (tag + '.result.json')
        attempted = out / (tag + '.command.json')
        if attempted.is_file():
            path = out / 'commands.json'
            rows = c.read(path) if path.is_file() else []
            rows.append(c.read(result if result.is_file() else attempted))
            c.save(path, rows)


def last_json(path):
    return json.loads(path.read_text().splitlines()[-1])


def checked_peer(path, fixed, expected_ids):
    result = c.read(path)
    phases = result['phases']
    if (result['llama_commit'] != PEER_COMMIT or result['context_capacity'] != 256 or
            result['configured_batch_capacity'] != 128 or result['kv_dtype'] != 'BF16' or
            result['flash_attention'] != 'enabled' or result['cuda_disable_graphs_env'] != '<absent>' or
            result['prompt_ids'] != fixed['prompt_ids'] or
            result['decode_input_ids'] != fixed['decode_input_ids'] or
            result['predicted_ids'] != expected_ids):
        raise ValueError('Peer reference policy, inputs or 32 predictions differ')
    if ([row['phase'] for row in phases] != list(range(32)) or
            [row['input_tokens'] for row in phases] != [128] + [1] * 31 or
            [row['visible_tokens'] for row in phases] != list(range(128, 160)) or
            any(row['sampled_logits_elements'] != 248320 for row in phases)):
        raise ValueError('Peer phase/transfer contract differs')
    seconds = [row['step_seconds'] for row in phases]
    if any(value <= 0 for value in seconds):
        raise ValueError('Nonpositive peer step')
    return {'prefill_tokens_per_second': 128 / seconds[0],
        'full31_tokens_per_second': 31 / sum(seconds[1:]),
        'warm7_31_tokens_per_second': 25 / sum(seconds[7:])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', type=Path)
    parser.add_argument('mode', choices=('run', 'profile'))
    args = parser.parse_args()
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    image = Path(plan['links']['qwen']['image'])
    proof_path = plan_path.parent / 'run-qwen/summary.json'
    proof = c.read(proof_path)
    if (proof['equal_vectors'] != 64 or not proof['same_generated_ids'] or
            not proof['same_decode_input_ids'] or b.b.identity(image) != proof['image']):
        raise ValueError('Current Hyle image has no matching 64-vector numerical proof')
    expected = last_json(plan_path.parent / 'run-qwen/qwen.stdout.log')
    captures = [tuple(map(int, pair)) for pair in proof['capture_counts']]
    if len(expected['generated_ids']) != 32 or captures != [(7, 0)] * 3 + [(0, 7)] * 29:
        raise ValueError('Expected complete 32-ID and capture proof')
    fair, peer = c.read(FAIR_PLAN), c.read(PEER_PLAN)
    if len(peer['inputs']) != 9 or len({row['path'] for row in peer['inputs']}) != 9:
        raise ValueError('Expected the exact nine-input retained peer closure')
    for row in peer['inputs']:
        if not b.b.same(row):
            raise ValueError('Retained peer input drift: ' + row['path'])
    fixture_rows = [fair[key] for key in ('prompt', 'fixed_inputs', 'tape')]
    model = c.read(MODEL_RECEIPT)
    for row in fixture_rows + [model]:
        if not b.b.same(row):
            raise ValueError('Fixed model/input drift: ' + row['path'])
    fixed = c.read(fair['fixed_inputs']['path'])
    if (len(fixed['prompt_ids']) != 128 or len(fixed['decode_input_ids']) != 31 or
            list(map(int, Path(fair['prompt']['path']).read_text().split())) != fixed['prompt_ids'] or
            list(map(int, Path(fair['tape']['path']).read_text().split())) != fixed['decode_input_ids'] or
            expected['decode_input_ids'] != fixed['decode_input_ids']):
        raise ValueError('Prompt/tape do not describe the same 128+31 journey')
    hyle = next(row['argv'][:] for row in fair['requests'] if row['engine'] == 'hyle')
    hyle[0] = str(image)
    if hyle[1:] != ['--inputs', str(Path(fair['prompt']['path']).parent), '--decode-ids',
            fair['tape']['path'], '--steps', '32', '--capacity', '256', '--progress', 'direct',
            '--replay', 'prefer-capture']:
        raise ValueError('Unexpected Hyle flags; no vectors/route/profiler in fair steps')
    run = STAGE / 'peer-comparison'
    out = run if args.mode == 'run' else STAGE / 'peer-profile'
    out.mkdir(exist_ok=False)  # Failed attempts are retained; never resume/retry implicitly.
    (out / 'tmp').mkdir()
    env, runtime = b.b.environment(plan['links']['qwen']['command'],
        [row['path'] for row in plan['cached_inputs']] + [row['path'] for row in peer['inputs']], out)
    for key in ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION', 'GGML_CUDA_GRAPH_OPT'):
        if env.get(key):
            raise ValueError('Retained reference requires absent ' + key)
    identity = b.b.identity(image)
    c.save(out / 'inputs.json', {'mode': args.mode, 'current_plan': b.b.identity(plan_path),
        'hyle_image': identity, 'proof': b.b.identity(proof_path), 'peer_plan': b.b.identity(PEER_PLAN),
        'peer_inputs': peer['inputs'], 'model': model, 'fixed_inputs': fixture_rows,
        'prompt': 128, 'decode': 31, 'capacity': 256, 'runtime_paths': runtime,
        'source_or_SDK_compilations': 0, 'external_memory_monitor': False})
    peer_image = run / 'peer.exe'
    positional = [str(peer_image), model['path'], fair['fixed_inputs']['path']]
    if args.mode == 'profile':
        if (c.read(run / 'summary.json')['status'] != 'six_unprofiled_processes_terminal_zero' or
                b.b.identity(peer_image) != c.read(run / 'peer-image.json') or
                c.read(run / 'inputs.json')['hyle_image'] != identity):
            raise ValueError('Profile requires completed pairs using these exact images')
        original = c.read(b.ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
        prefix = original[:original.index('--inputs') - 1]
        stem = out / 'peer-trace'
        command = [('--output=' + str(stem)) if value.startswith('--output=') else value
            for value in prefix] + positional + [str(out / 'peer-result.json')]
        c.save(out / 'profile-inputs.json', {'peer_image': b.b.identity(peer_image), 'command': command,
            'profiler_runs': 1, 'token_D2H_bytes': 4, 'sampled_logits_D2H_bytes': 993280,
            'phase_analysis': 'No Hyle 4B-only phase splitter; classify token and sampled-logit copies separately'})
        execute('profile', command, env, out)
        execute('export', [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite',
            str(stem) + '.nsys-rep'], env, out)
        execute('stats', [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum',
            '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'], env, out)
        checked_peer(out / 'peer-result.json', fixed, expected['generated_ids'])
        c.save(out / 'summary.json', {'terminal': True, 'profiler_runs': 1, 'trace_stem': str(stem),
            'peer_image': b.b.identity(peer_image), 'same32_ids_and_inputs': True, 'throughput_claim': False})
        print('PEER_PROFILE_COMPLETE', out, flush=True)
        return
    command = [value for value in peer['command']
        if not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(peer_image), '/MAP:' + str(peer_image.with_suffix('.map')),
        '/IMPLIB:' + str(peer_image.with_suffix('.lib'))]
    c.save(out / 'peer-link-plan.json', {'command': command, 'inputs': peer['inputs'],
        'change': 'Only output metadata flags; nine original object/library inputs, no compilation'})
    execute('peer-link', command, env, out)
    c.save(out / 'peer-image.json', b.b.identity(peer_image))
    order = ['hyle', 'peer', 'peer', 'hyle', 'hyle', 'peer']
    runs = []
    for index, engine in enumerate(order, 1):
        if b.b.identity(image) != identity or b.b.identity(peer_image) != c.read(out / 'peer-image.json'):
            raise ValueError('A compared image changed')
        tag = f'{index:02d}-{engine}'
        output = out / (tag + '-peer-result.json')
        row = execute(tag, hyle if engine == 'hyle' else positional + [str(output)], env, out)
        if engine == 'hyle':
            observed = last_json(out / (tag + '.stdout.log'))
            text = (out / (tag + '.stderr.log')).read_text()
            actual_capture = [tuple(map(int, pair)) for pair in re.findall(
                r'capture_recorded=(\d+) capture_reused=(\d+)', text)]
            phases = re.findall(r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+)', text, re.M)
            if (observed['generated_ids'] != expected['generated_ids'] or
                    observed['decode_input_ids'] != fixed['decode_input_ids'] or not observed['fixed_decode'] or
                    observed['source_id'] != expected['source_id'] or observed['visible_tokens'] != 159 or
                    actual_capture != captures or
                    phases != [('prefill', '128', '128')] + [('decode' + str(i), '1', str(128 + i)) for i in range(1, 32)]):
                raise ValueError('Hyle IDs, inputs, phases or capture counts differ')
            values = metrics(out / (tag + '.stderr.log'))
        else:
            values = checked_peer(output, fixed, expected['generated_ids'])
        runs.append({'engine': engine, 'tag': tag, 'pid': row['pid'], 'exit': row['exit'], 'metrics': values})
        c.save(out / 'runs.json', runs)
    groups = {engine: {key: {'samples': [row['metrics'][key] for row in runs if row['engine'] == engine],
        'median': statistics.median(row['metrics'][key] for row in runs if row['engine'] == engine)}
        for key in KEYS} for engine in ('hyle', 'peer')}
    summary = {'status': 'six_unprofiled_processes_terminal_zero', 'order': order,
        'pair_order': ['H/L', 'L/H', 'H/L'], 'groups': groups,
        'hyle_over_peer': {key: groups['hyle'][key]['median'] / groups['peer'][key]['median'] for key in KEYS},
        'hyle_image': identity, 'peer_image': c.read(out / 'peer-image.json'),
        'same32_ids_and_inputs': True, 'hyle_capture_counts_match_correctness': True,
        'profiler': False, 'external_memory_monitor': False, 'statistical_significance': False,
        'quality_acceptance': False, 'scope': 'Full input-preparation-to-host-token step; same-source weights, unequal intermediate numerical boundaries',
        'limitations': ['Hyle shape compile precedes step; peer decode graph maintenance is inside step',
            'Peer retains original GPU greedy and 248320 F32 sampled-logit readback per phase',
            'Historical peer throughput is not used in these ratios']}
    c.save(out / 'summary.json', summary)
    print('PEER_PAIRS_COMPLETE', json.dumps(groups), flush=True)


if __name__ == '__main__':
    main()
