from pathlib import Path
import hashlib
import json
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bfloat-elementwise-trace.zip'
assert not DEST.exists(), 'Do not overwrite frozen evidence'


def digest(data):
    return hashlib.sha256(data).hexdigest()


entries = []
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    if path.suffix.lower() in {'.obj', '.exe', '.dll', '.lib', '.exp', '.map', '.zip', '.pyc'}:
        continue
    if path.name == 'archive-receipt.json':
        continue
    entries.append((path.relative_to(OUT).as_posix(), path.read_bytes()))
assert sum(name.endswith('.nsys-rep') for name, data in entries) == 1
assert sum(name.endswith('.sqlite') for name, data in entries) == 1
manifest = dict(schema='hyle.cuda.bfloat-elementwise.trace.archive.v1',
    scope='Exactly one typed BF16 candidate software trace, same128+31 inputs, official SQLite/API/kernel exports, '
          'read-only structure comparison with two frozen baselines. No product compile/link, '
          'SDK/model/images/maps/objects. Durations are not fair benchmark results.',
    entries=[dict(path=name, bytes=len(data), sha256=digest(data),
                  crc32=f'{zlib.crc32(data)&0xffffffff:08x}') for name, data in entries])
DEST.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in entries:
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(entries) + 1
    for row in manifest['entries']:
        data = archive.read(row['path'])
        assert len(data) == row['bytes']
        assert digest(data) == row['sha256']
        assert f'{zlib.crc32(data)&0xffffffff:08x}' == row['crc32']
data = DEST.read_bytes()
receipt = dict(path=str(DEST.resolve()), bytes=len(data), sha256=digest(data),
    crc32=f'{zlib.crc32(data)&0xffffffff:08x}', entries=len(entries)+1,
    payload_entries=len(entries), zip_crc_and_all_entry_sha_verified=True,
    raw_nsight_reports=1, sqlite_exports=1, no_models_sdk_images_maps_objects=True,
    cleanup_manifest=str(OUT / 'cleanup-windows.json'), deletions_executed=False)
(OUT / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
