from pathlib import Path
import collections
import csv
import hashlib
import json
import sqlite3
import statistics

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
BASE = ARCH / 'qwen-decode-native-route'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, obj):
    Path(p).write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')


def ident(p):
    p = Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def stats(values):
    return dict(min=min(values), median=statistics.median(values), max=max(values))


def union_ns(intervals):
    if not intervals:
        return 0
    intervals = sorted(intervals)
    a, b = intervals[0]
    total = 0
    for x, y in intervals[1:]:
        if x > b:
            total += b - a
            a, b = x, y
        else:
            b = max(b, y)
    return total + b - a


def group(name):
    if 'k_bin_bcast<&op_add, __nv_bfloat16' in name:
        return 'BF16_native_add'
    if 'k_bin_bcast<&op_mul, __nv_bfloat16' in name:
        return 'BF16_native_multiply'
    if 'unary_op_kernel<&op_sigmoid, __nv_bfloat16>' in name:
        return 'BF16_native_sigmoid'
    if 'internal::gemvx' in name:
        return 'cuBLAS_gemvx'
    if 'mul_mat_vec_f<' in name:
        return 'ggml_mmvf'
    if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name:
        return 'scalar_BF16_to_F32'
    if 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name:
        return 'scalar_F32_to_BF16'
    if 'rms_norm' in name:
        return 'RMSNorm'
    if 'gated_delta_net' in name:
        return 'GatedDeltaNet'
    if 'flash_attn' in name or 'flashinfer' in name or 'BatchPrefill' in name:
        return 'attention_named'
    if 'gemm' in name.lower():
        return 'GEMM_named'
    if 'op_mul' in name:
        return 'binary_multiply'
    if 'op_add' in name:
        return 'binary_add'
    return 'other'


def load_engine(engine):
    folder = OUT if engine == 'candidate' else BASE
    db = folder / (engine + '-trace.sqlite')
    con = sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True)
    if engine == 'candidate':
        diagnostics = [dict(timestamp_ns=t, severity=s, text=v) for t, s, v in
                       con.execute('select timestamp,severity,text from DIAGNOSTIC_EVENT')]
        for filename, contents in con.execute(
                'select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
            if '/streams/' in filename:
                suffix = 'stderr' if 'stderr_' in filename else 'stdout'
                (OUT / ('candidate-target-' + suffix + '.log')).write_text(contents, encoding='utf-8')
        save(OUT / 'candidate-diagnostics.json', dict(events=diagnostics))
    kernels = [dict(start=a, end=b, name=n, graph_node=bool(g), grid=[x, y, z],
                    block=[bx, by, bz]) for a, b, n, g, x, y, z, bx, by, bz in con.execute(
        'select a.start,a.end,s.value,a.graphNodeId,a.gridX,a.gridY,a.gridZ,'
        'a.blockX,a.blockY,a.blockZ from CUPTI_ACTIVITY_KIND_KERNEL a '
        'join StringIds s on s.id=a.demangledName order by a.start')]
    copies = [dict(start=a, end=b, bytes=n, kind=k) for a, b, n, k in con.execute(
        'select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start')]
    memset = [dict(start=a, end=b, bytes=n) for a, b, n in con.execute(
        'select start,end,bytes from CUPTI_ACTIVITY_KIND_MEMSET order by start')]
    apis = [dict(start=a, end=b, name=n, return_value=r) for a, b, n, r in con.execute(
        'select a.start,a.end,s.value,a.returnValue from CUPTI_ACTIVITY_KIND_RUNTIME a '
        'join StringIds s on s.id=a.nameId order by a.start')]
    dtoh = [x for x in copies if x['kind'] == 2]
    if engine == 'peer':
        assert collections.Counter(x['bytes'] for x in dtoh) == {4: 32, 993280: 32}
        ends = [x['end'] for x in dtoh if x['bytes'] == 993280]
    else:
        assert len(dtoh) == 32 and all(x['bytes'] == 4 for x in dtoh)
        ends = [x['end'] for x in dtoh]
    phases = []
    previous = -1
    for i, end in enumerate(ends):
        ks = [x for x in kernels if previous < x['start'] <= end]
        ms = [x for x in copies + memset if previous < x['start'] <= end]
        aa = [x for x in apis if previous < x['start'] <= end]
        counts = collections.Counter(group(x['name']) for x in ks)
        durations = collections.Counter()
        for k in ks:
            durations[group(k['name'])] += k['end'] - k['start']
        intervals = [(x['start'], x['end']) for x in ks + ms]
        first = min(a for a, b in intervals)
        last = max(b for a, b in intervals)
        active = union_ns(intervals)
        selected = collections.Counter(x['name'] for x in aa if any(t in x['name'] for t in
            ['GraphLaunch', 'GraphInstantiate', 'GraphExecUpdate', 'StreamBeginCapture', 'StreamEndCapture']))
        phases.append(dict(phase='prefill' if i == 0 else 'decode' + str(i),
            boundary_end_ns=end, kernel_count=len(ks),
            graph_node_kernel_count=sum(x['graph_node'] for x in ks),
            kernel_group_counts=dict(counts), kernel_group_duration_sum_ns=dict(durations),
            selected_api_calls=dict(selected), observed_device_activity_span_ns=last-first,
            union_kernel_copy_memset_active_ns=active,
            observed_intra_span_without_target_activity_ns=last-first-active,
            readback_to_readback_ns=None if i == 0 else end-previous,
            observed_gap_before_first_activity_ns=None if i == 0 else first-previous))
        previous = end
    stable = phases[7:]
    numeric = {k: stats([p[k] for p in stable]) for k in [
        'kernel_count', 'graph_node_kernel_count', 'observed_device_activity_span_ns',
        'union_kernel_copy_memset_active_ns', 'observed_intra_span_without_target_activity_ns',
        'readback_to_readback_ns', 'observed_gap_before_first_activity_ns']}
    groups = sorted({k for p in stable for k in p['kernel_group_counts']})
    group_stats = {g: dict(count=stats([p['kernel_group_counts'].get(g, 0) for p in stable]),
        kernel_duration_sum_ns=stats([p['kernel_group_duration_sum_ns'].get(g, 0) for p in stable]))
        for g in groups}
    selected_kernels = [k for k in kernels if ends[6] < k['start'] <= ends[-1] and
                        group(k['name']) in ['cuBLAS_gemvx', 'ggml_mmvf', 'GEMM_named']]
    geometry = collections.defaultdict(list)
    for k in selected_kernels:
        geometry[(k['name'], tuple(k['grid']), tuple(k['block']))].append(k['end'] - k['start'])
    geometries = [dict(name=n, grid=g, block=b, instances=len(v),
                      instances_per_stable_step=len(v)/25, durations_ns=stats(v),
                      sum_duration_ns=sum(v)) for (n, g, b), v in geometry.items()]
    geometries.sort(key=lambda r: -r['sum_duration_ns'])
    if engine == 'candidate':
        csvrows = list(csv.DictReader((OUT / 'candidate-trace_cuda_gpu_kern_sum.csv').open()))
        assert sum(int(x['Instances']) for x in csvrows) == len(kernels)
        save(OUT / 'candidate-phases.json', dict(method=
            '32 observed final 4B device-to-host readbacks. Phase0 includes load/cold setup; '
            'decode bins include inter-step host work, not exact consumer step_start.',
            phases=phases, stable_decode7_through31=numeric))
    graphlaunch = [x for x in apis if 'GraphLaunch' in x['name']]
    return dict(kernel_instances=len(kernels), stable_decode7_through31=numeric,
        stable_group_stats=group_stats, stable_structures=sorted({
            (p['kernel_count'], p['graph_node_kernel_count'],
             sum(v for k, v in p['selected_api_calls'].items() if 'GraphLaunch' in k)) for p in stable}),
        first_8_phase_structure=[dict(phase=p['phase'], kernels=p['kernel_count'],
            groups=p['kernel_group_counts'], apis=p['selected_api_calls']) for p in phases[:8]],
        graph_launch_count=len(graphlaunch), all_graph_launch_api_returns_zero=
            all(x['return_value'] == 0 for x in graphlaunch),
        stable_projection_kernel_geometry=geometries, sqlite=ident(db))


engines = {name: load_engine(name) for name in ['candidate', 'hyle', 'peer']}
actual = read(OUT / 'candidate-target-stdout.log')
fixed = read(ARCH / 'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
assert actual['decode_input_ids'] == fixed['decode_input_ids']
assert len(actual['generated_ids']) == 32
own_path = ARCH / 'cuda-bfloat-elementwise-build/perf128-02-candidate/stdout.log'
assert actual['generated_ids'] == read(own_path)['generated_ids']
baseline = read(BASE / 'hyle-target-stdout.log')
assert actual['generated_ids'] == baseline['generated_ids']
counts = {}
for name in ['candidate', 'hyle', 'peer']:
    counts[name] = {key: value['count']['median'] for key, value in engines[name]['stable_group_stats'].items()}
assert engines['candidate']['stable_structures'] == [(1794, 1500, 401)] or len(engines['candidate']['stable_structures']) == 1
new = counts['candidate']; old = counts['hyle']
assert new['cuBLAS_gemvx'] == old['cuBLAS_gemvx'] == 187
assert new.get('ggml_mmvf', 0) == old.get('ggml_mmvf', 0) == 0
assert new['BF16_native_add'] == 84 and new['BF16_native_multiply'] == 102 and new['BF16_native_sigmoid'] == 24
assert old['scalar_BF16_to_F32']-new['scalar_BF16_to_F32'] == 396
assert old['scalar_F32_to_BF16']-new['scalar_F32_to_BF16'] == 210
summary = dict(schema='hyle.cuda.bfloat-elementwise.trace.v1', status='one_trace_and_official_exports_terminal_success',
    scope='Exactly one128-prompt+31fixeddecode trace of prebuilt candidate7924728. No compilation/link/SDK or model copy.',
    profile=read(OUT/'candidate-profile.result.json'), stats=read(OUT/'candidate-stats.result.json'),
    engines=engines, stable_kernel_group_counts=counts,
    input_identity=ident(OUT/'input-identities.json'), tests=ident(ARCH/'cuda-bfloat-elementwise-tests/summary.json'),
    numerical_guard=dict(predicted_ids32_equal_unprofiled_candidate=True, predicted_ids32_equal_original_baseline=True,
        decode_input_ids_equal_fixed=True, own_unprofiled_result=ident(own_path),
        full_decision_parity_receipt=ident(ARCH/'cuda-bfloat-elementwise-build/decisions-parity.json'),
        token_equality_is_not_precision_or_quality_acceptance=True),
    findings=[
        'Every25 stable decode7..31 bin has1794 kernels,401 CUDA GraphLaunch. Original Hyle has2400/401; peer558/1.',
        'BF16->F32 scalar casts801->405 (-396); F32->BF16 casts427->217 (-210). Total606 fewer casts exactly matches606 fewer kernels.',
        'Real typed BF16 native specialization per stable step:84 Add,102 Mul,24 Sigmoid. Each storesBF16; no per-operation BF16 store has been removed.',
        '186 binary operations remove372 input casts;24 unary operations remove24 input casts. Their210 outputs remove210 post-casts. This accounts for the observed396+210 count reduction.',
        'All187 projections remain original cuBLAS gemvx. This is not the rejected mmvf/vector-route experiment.',
        'Exact per-operation RNE/private intermediate and old-result contracts are tested by the two focused BF16 tests, with canonical IQ1 integrity control. Trace kernel names/counts alone do not prove arithmetic bit identity.'
    ],
    limits=[
        'Legacy software instrumented node:host-only trace. CUDA driver13.4 versus collector13.3 warning retained. No fair latency/throughput/winner claim from trace durations.',
        'Decode bins are readback-to-readback envelopes including host preparation; prefill includes loading/cold setup.',
        'Observed target activity gaps do not prove whole-device idle.',
        'Current tests passed across initial Direct+IQ1 run and corrected Graph-only run; not represented as a single final3/3 execution.',
        'Root unprofiled paired measurements and128payload bit comparison are separate evidence. No new model quality or general dtype acceptance.'
    ], gpu_window_released=True)
save(OUT/'summary.json',summary)
save(OUT/'cleanup-windows.json',dict(root=str(OUT),files=[],bytes=0,delete_executed=False,
    retain=['raw nsys-rep, SQLite, official CSV, scripts and reports','original product/test objects and build cache'],
    no_images_created_in_this_stage=True))
print(json.dumps({name:engines[name]['stable_structures'] for name in engines},indent=2))
print(json.dumps(counts,indent=2))
