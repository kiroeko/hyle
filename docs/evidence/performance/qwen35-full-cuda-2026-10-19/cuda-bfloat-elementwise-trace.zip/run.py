from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
BUILD = ARCH / 'cuda-bfloat-elementwise-build'
IMAGE = BUILD / 'candidate.exe'
CASE = ARCH / 'qwen-gpu-comparison/128-prefill'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


BASE = read(BUILD / 'candidate-link-plan.json')['command']
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': BASE[0].replace('link.exe', 'cl.exe')})
ENV['VSLANG'] = '1033'
ENV['PATH'] = os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE
    if Path(v).is_absolute() and v.lower().endswith('.lib'))) + os.pathsep + ENV['PATH']
assert not ENV.get('GGML_CUDA_DISABLE_GRAPHS')


def execute(tag, argv):
    assert not (OUT / (tag+'.command.json')).exists(), 'Single actual attempt; no implicit retries'
    row = dict(tag=tag, command=list(map(str, argv)), cwd=str(ROOT), started=time.time(), exit=None)
    save(tag+'.command.json', row)
    with (OUT / (tag+'.stdout.log')).open('wb') as so, (OUT / (tag+'.stderr.log')).open('wb') as se:
        process = subprocess.Popen(row['command'], cwd=ROOT, env=ENV, stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = process.pid
        save('live.json', row)
        print('START', tag, 'PID', process.pid, flush=True)
        row['exit'] = process.wait()
    row.update(terminal=True, finished=time.time())
    save(tag+'.result.json', row)
    save('live.json', row)
    print('END', tag, 'exit', row['exit'], 'seconds', round(row['finished']-row['started'], 3), flush=True)
    return row['exit']


def profile():
    tests = read(ARCH / 'cuda-bfloat-elementwise-tests/summary.json')
    assert tests['tests_passed'] == 3 and tests['tests_failed'] == 0
    assert tests['status'] == 'three_unique_cases_passed_across_initial_and_corrected_graph_runs'
    image = ident(IMAGE)
    assert image['sha256'] == '792472800d9fd58f557dce8e71f2db535e07c85de5e5aa21a32225725a339ecf'
    owners = []
    for name in ['ggml-cuda', 'binbcast', 'unary', 'tensor-current']:
        receipt = read(BUILD / (name+'-identity.json'))
        assert ident(receipt['object']['path']) == receipt['object']
        assert ident(receipt['source']['path']) == receipt['source']
        owners.append(receipt)
    save('input-identities.json', dict(image=image, selected_products=owners,
        link_plan=ident(BUILD / 'candidate-link-plan.json'), tests=ident(ARCH / 'cuda-bfloat-elementwise-tests/summary.json'),
        inputs=[ident(CASE / name) for name in ['fixed-inputs.json', 'inputs/prompt.ids',
                                              'inputs/weights.tsv', 'decode.ids']],
        no_compile_or_link=True, no_model_or_sdk_copy=True))
    return execute('candidate-profile', [NSYS, 'profile', '--trace=cuda', '--sample=none',
        '--cpuctxsw=none', '--cuda-graph-trace=node:host-only', '--discard-environment=true',
        '--output='+str(OUT / 'candidate-trace'), IMAGE, '--inputs', CASE / 'inputs',
        '--decode-ids', CASE / 'decode.ids', '--capacity', '256', '--progress', 'direct'])


def export():
    assert read(OUT / 'candidate-profile.result.json')['exit'] == 0
    return execute('candidate-stats', [NSYS, 'stats', '--report', 'cuda_api_sum,cuda_gpu_kern_sum',
        '--format', 'csv', '--output', OUT / 'candidate-trace', OUT / 'candidate-trace.nsys-rep'])


if __name__ == '__main__':
    assert sys.argv[1:] in [['profile'], ['export']]
    raise SystemExit(profile() if sys.argv[1] == 'profile' else export())
