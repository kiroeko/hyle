"""Archive completed FI diagnostics only; no build, GPU work or deletion."""
from pathlib import Path
import hashlib
import json
import re
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/first-fi-startup.zip'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def checked(row):
    actual = identity(row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row
    return Path(row['path'])


def main():
    completed = read(STAGE / 'combined-evidence.json')
    assert completed['checks']['passed'] and read(STAGE / 'summary.json')['passed']
    assert read(STAGE / 'all-api/summary.json')['passed']
    for row in completed['evidence']:
        checked(row)
    for arm in completed['host_wrapper_observations'].values():
        for row in arm['identities']:
            checked(row)

    # Preserve the necessary original selected source/headers, not a SDK tree.
    facts = read(STAGE / 'findings.json')['provenance']
    support = []
    for key in ['actual_link_plan', 'successful_compile_recipe', 'current_native_source',
                'compiled_frozen_native_source', 'selected_prefill_header', 'verified_replay_header']:
        support.append(checked(facts[key]))
    for key in ['supporting_receipts', 'normal_dispatch_support_headers', 'preincluded_headers']:
        support.extend(checked(row) for row in facts[key])
    probe = read(STAGE / 'plan.json')
    support.append(checked(probe['source']))
    for arm in probe['arms'].values():
        support.append(checked(arm['original_link']))
    # These native declarations prove the unchanged compiled type/helper prefix.
    legacy = ROOT / '.scratch/inference-feature-completion-2026-10-18/windows-batch'
    support.extend([ROOT / 'src/compute_provider_flashinfer/native_batch.h',
                    legacy / 'frozen/src/compute_provider_flashinfer/native_batch.h'])
    support.extend([ARCH / 'batch-graph-capture/performance-prepared/plan.json',
                    ARCH / 'batch-graph-capture/cold-profile/plan.json',
                    ARCH / 'batch-graph-capture/checks/20261019T150633/flashinfer-identity.json'])
    # Freeze the small helper import closure under its original repository paths.
    pending = [STAGE / 'host_probe.py', STAGE / 'profile_all_api.py']
    seen = set()
    while pending:
        path = pending.pop().resolve()
        if path in seen:
            continue
        seen.add(path)
        code = path.read_text(encoding='utf-8')
        for pattern, base in [(r"ARCH\s*/\s*['\"]([^'\"]+\.py)['\"]", ARCH),
                              (r"STAGE\s*/\s*['\"]([^'\"]+\.py)['\"]", path.parent)]:
            pending.extend(base / name for name in re.findall(pattern, code))
        if not path.is_relative_to(STAGE):
            support.append(path)
    support_rows = []
    for path in dict.fromkeys(p.resolve() for p in support):
        assert path.is_relative_to(ROOT), path
        relative = path.relative_to(ROOT)
        target = STAGE / 'support' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        data = path.read_bytes()
        target.write_bytes(data)
        support_rows.append(dict(**identity(path), archive_path='support/' + relative.as_posix()))
    save(STAGE / 'archive-support.json', support_rows)

    obsolete = STAGE / 'all-api/first-fi-api-attribution.json'
    save(STAGE / 'archive-scope.json', dict(
        scope='Two temporary FI host-wrapper processes and one unmodified production all-API trace; only original evidence and necessary source/recipe references.',
        primary='combined-evidence.json; reproducible by analyze_combined.py using the retained SQLite and raw wrapper output.',
        superseded_excluded=dict(**identity(obsolete), reason='Provisional script used the GPU correlationId, which belongs to outer GraphLaunch, as the recording launch. Correct mapping follows original graph-node creation to cudaLaunchKernel54855, immediately preceded by FuncSetAttribute54854. The provisional JSON is omitted, not endorsed.'),
        wrapper_limits=completed['limits'],
        conclusion='First FI host-call delay is localized to a first cudaFuncSetAttribute; internal loading/JIT mechanism remains unproven. No implemented optimization or throughput/TTFT improvement claim.',
        excluded='exe/obj/o/map/lib/exp/pdb/dll/pyc/tmp, temporary folders, full SDK/cache trees, other batch drafts.',
        source_snapshot='Two actual probe overlays and their dependency records are retained. Selected native code/headers are identity checked against the earlier static provenance; support includes only small source/recipe/helper references, not a new complete native dependency scan.',
        cleanup='Separate exact candidate list only. This script performs no deletion and never edits root test.ps1.'))

    cleanup = []
    for arm in ['baseline', 'current']:
        for path in sorted((STAGE / arm).glob('*')):
            if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp', '.pdb'}:
                resolved = path.resolve()
                assert resolved.is_relative_to(ROOT / '.scratch')
                cleanup.append(identity(resolved))
    assert len([row for row in cleanup if Path(row['path']).suffix == '.exe']) == 2
    save(STAGE / 'reclaim-targets.json', dict(targets=cleanup, count=len(cleanup),
        bytes=sum(row['bytes'] for row in cleanup), protected_by_archive=str(DEST),
        preserved='Both provider.obj files, all sources, deps, commands, JSON, logs, raw profile and all other production images/objects. Images are reproducible from retained objects/link recipes; executable payloads themselves are not in this evidence ZIP.',
        execution='Plan only; root owns test.ps1 and actual deletion.'))

    excluded = {'.exe', '.obj', '.o', '.map', '.lib', '.exp', '.pdb', '.dll', '.pyc', '.tmp'}
    files = [p for p in STAGE.rglob('*') if p.is_file()
             and p.suffix.lower() not in excluded
             and not {'tmp', '__pycache__'}.intersection(p.relative_to(STAGE).parts)
             and p.name not in {'archive-receipt.json'} and p != obsolete]
    files.sort(key=lambda p: p.relative_to(STAGE).as_posix())
    manifest = {p.relative_to(STAGE).as_posix(): identity(p) for p in files}
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            archive.write(path, path.relative_to(STAGE).as_posix())
        archive.writestr('payload-sha256.json', manifest_bytes)
    # One read of each decompressed entry verifies explicit CRC32 and SHA256.
    # ZipExtFile also enforces its stored CRC at EOF.
    expected = {name: row['sha256'] for name, row in manifest.items()}
    expected['payload-sha256.json'] = digest(manifest_bytes)
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist()) == len(expected)
        for info in archive.infolist():
            sha = hashlib.sha256()
            crc = 0
            size = 0
            with archive.open(info) as handle:
                while chunk := handle.read(1024 * 1024):
                    sha.update(chunk)
                    crc = zlib.crc32(chunk, crc)
                    size += len(chunk)
            assert size == info.file_size and crc & 0xffffffff == info.CRC, info.filename
            assert sha.hexdigest() == expected[info.filename], info.filename
    receipt = dict(**identity(DEST), payloads=len(manifest), entries=len(expected),
                   CRC_and_every_payload_SHA_verified=True, crc_verified=True,
                   payload_sha256_verified=True, verification_passes=1,
                   source_probes=2, production_all_api_traces=1,
                   performance_claim=False, internal_module_loading_confirmed=False,
                   excluded_provisional_correlation_attribution=True,
                   cleanup_candidates=len(cleanup), cleanup_bytes=sum(r['bytes'] for r in cleanup))
    save(STAGE / 'archive-receipt.json', receipt)
    save(DEST.with_name('first-fi-startup-archive.json'), receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
