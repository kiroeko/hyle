"""One production-image trace exposing CUDA APIs omitted by default collection."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
spec = importlib.util.spec_from_file_location('fi_all_api_helpers', ARCH / 'batch-graph-capture/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
base = ARCH / 'batch-graph-capture'
rotation = c.read(base / 'performance-prepared/plan.json')
build = c.read(rotation['build_plan']['path'])
link = c.read(Path(build['links']['qwen']['image']).parent / 'qwen-link-plan.json')
command = next(r['command'] for r in rotation['requests'] if r['arm'] == 'current').copy()
assert b.identity(command[0]) == rotation['images']['current']
nsys = c.read(base / 'cold-profile/plan.json')['arms']['current']['commands']['profile'][0]
out = STAGE / 'all-api'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
stem = out / 'capture'
commands = dict(profile=[nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
    '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only', '--discard-environment=true',
    '--output=' + str(stem), *command],
    export=[nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'])
c.save(out / 'plan.json', dict(image=b.identity(command[0]), commands=commands,
    reason='Default Nsight CUDA collection omitted device/attribute calls used by the actual linked FI helper.',
    model_processes=1, throughput_claim=False, source_changes=False, host_or_native_compiles=0))
env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
c.save(out / 'runtime.json', dict(runtime=runtime, CUDA_MODULE_LOADING=env.get('CUDA_MODULE_LOADING')))
for tag, argv in commands.items():
    c.execute(tag, argv, env, out)
c.save(out / 'summary.json', dict(passed=True, model_processes=1, throughput_claim=False,
    limits='All-API tracing perturbs host timing; use only for API attribution, not a throughput estimate.'))
print('ALL_API_COMPLETE', out, flush=True)
