"""Two temporary host-wrapper probes, unchanged CUDA mathematics and fixed model inputs."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('fi_probe_helpers', ARCH / 'batch-graph-capture/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = ARCH / 'batch-graph-capture'
source = ROOT / 'src/compute_provider_flashinfer/flashinfer_provider.cc'
before = source.read_text()
helper = r'''
#include <chrono>
#include <cstdio>
namespace {
using FiProbeClock = std::chrono::steady_clock;
long long fi_probe_ns(FiProbeClock::duration duration) noexcept {
  return static_cast<long long>(std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count());
}
struct FiProbeRow { unsigned long long query_rows; bool recording; long long stream, bindings, scope, native, total; };
struct FiProbeStore {
  FiProbeRow rows[24]{}; unsigned count = 0;
  ~FiProbeStore() {
    for (unsigned i = 0; i < count; ++i) {
      const auto &r = rows[i];
      std::fprintf(stderr, "FI_HOST_PROBE ordinal=%u rows=%llu recording=%u stream_ns=%lld bindings_ns=%lld scope_ns=%lld native_ns=%lld total_ns=%lld\n",
          i, r.query_rows, unsigned(r.recording), r.stream, r.bindings, r.scope, r.native, r.total);
    }
  }
};
FiProbeStore &fi_probe_store() { static FiProbeStore store; return store; }
}
'''
changed = before.replace('namespace hyle::compute::flashinfer {', helper + '\nnamespace hyle::compute::flashinfer {', 1)
needle = '  auto&slot=*static_cast<BatchSlot*>(opaque);\n  if(!slot.generation || inputs.size()!=(slot.mla?2u:3u))'
assert changed.count(needle) == 1
changed = changed.replace(needle, '  auto&slot=*static_cast<BatchSlot*>(opaque);\n  auto &probe_store=fi_probe_store(); const auto probe_begin=FiProbeClock::now();\n  if(!slot.generation || inputs.size()!=(slot.mla?2u:3u))')
needle = '  if(slot.spec.query_rows==0)return detail::EnqueueResult::no_op();\n  std::array<const void*,3> pointers{};'
assert changed.count(needle) == 1
changed = changed.replace(needle, '  if(slot.spec.query_rows==0)return detail::EnqueueResult::no_op();\n  const auto probe_stream=FiProbeClock::now();\n  std::array<const void*,3> pointers{};')
needle = '''  cuda::detail::ScopedPrimaryContext scope(slot.primary);if(!scope)return detail::EnqueueResult::rejected(scope.status());
  try{if(slot.mla)return detail::EnqueueResult::accepted_command(cuda::status(
      native::run_mla(slot.plan,slot.spec,pointers[0],pointers[1],*metadata,*output,*floating,*integer,*stream)));
    const auto run=slot.spec.qk_head_dim==512?&native::run_highdim_batch:&native::run_batch;
    return detail::EnqueueResult::accepted_command(cuda::status(run(slot.plan,slot.spec,pointers[0],pointers[1],pointers[2],*metadata,*output,*floating,*integer,*stream)));}'''
replacement = '''  const auto probe_bindings=FiProbeClock::now();
  cuda::detail::ScopedPrimaryContext scope(slot.primary);if(!scope)return detail::EnqueueResult::rejected(scope.status());
  const auto probe_scope=FiProbeClock::now();
  try{
    const auto invoke=[&](){
      if(slot.mla)return native::run_mla(slot.plan,slot.spec,pointers[0],pointers[1],*metadata,*output,*floating,*integer,*stream);
      const auto run=slot.spec.qk_head_dim==512?&native::run_highdim_batch:&native::run_batch;
      return run(slot.plan,slot.spec,pointers[0],pointers[1],pointers[2],*metadata,*output,*floating,*integer,*stream);
    };
    const auto result=invoke(); const auto probe_end=FiProbeClock::now();
    if(probe_store.count<24)probe_store.rows[probe_store.count++]={static_cast<unsigned long long>(slot.spec.query_rows),sequence.recording(),
        fi_probe_ns(probe_stream-probe_begin),fi_probe_ns(probe_bindings-probe_stream),fi_probe_ns(probe_scope-probe_bindings),
        fi_probe_ns(probe_end-probe_scope),fi_probe_ns(probe_end-probe_begin)};
    return detail::EnqueueResult::accepted_command(cuda::status(result));}'''
assert changed.count(needle) == 1
changed = changed.replace(needle, replacement)
recipe = c.read(BASE / 'checks/20261019T150633/flashinfer-identity.json')
rotation = c.read(BASE / 'performance-prepared/plan.json')
paths = {'baseline': ARCH / 'cold-capture-topology/checks/20261019T142405/qwen-link-plan.json',
         'current': BASE / 'checks/20261019T151524-fixture-include/qwen-link-plan.json'}
plan = dict(source=b.identity(source), host_compiles=2, native_compiles=0, SDK_build=False,
    model_processes=2, throughput_claim=False, diagnostic_output='Fixed-size rows printed only at process shutdown, after every measured step.', arms={})
for arm, path in paths.items():
    out = STAGE / arm
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    text = changed
    if arm == 'baseline':
        block = text[text.index('ProviderRuntimeProperties batch_runtime'):text.index('const detail::BatchProviderVTable kBatchVTable')]
        assert block.count('.capture_compatible=true') == 1
        text = text.replace(block, block.replace('.capture_compatible=true', '.capture_compatible=false'))
    overlay = out / 'flashinfer_provider.cc'
    overlay.write_text(text)
    command = b.host_command(recipe['command'], overlay, 'provider', out)
    command.insert(1, '/I' + str(source.parent))
    link = c.read(path)
    owners = [r for r in link['inputs'] if Path(r['path']).name.endswith('flashinfer_provider.obj') or Path(r['path']).name == 'flashinfer.obj']
    assert len(owners) == 1, owners
    image = out / 'qwen.exe'
    link_command = [str(out / 'provider.obj') if c.key(x) == c.key(owners[0]['path']) else x for x in link['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    link_command += ['/OUT:' + str(image), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    request = next(r for r in rotation['requests'] if r['arm'] == arm)['command'].copy()
    request[0] = str(image)
    plan['arms'][arm] = dict(overlay=b.identity(overlay), compile=command, link=link_command,
        original_link=b.identity(path), original_owner=owners[0], command=request)
c.save(STAGE / 'plan.json', plan)
reference = c.read(BASE / 'correctness-final/summary.json')['observation']
for arm, row in plan['arms'].items():
    out = STAGE / arm
    link = c.read(row['original_link']['path'])
    env, runtime = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
    c.execute('compile', row['compile'], env, out)
    c.execute('link', row['link'], env, out)
    c.save(out / 'image.json', b.identity(row['command'][0]))
    c.save(out / 'runtime.json', dict(runtime=runtime, CUDA_MODULE_LOADING=env.get('CUDA_MODULE_LOADING')))
    c.execute('model', row['command'], env, out)
    import json
    result = json.loads((out / 'model.stdout.log').read_text().splitlines()[-1])
    assert result['generated_ids'] == reference['generated_ids'] and result['decode_input_ids'] == reference['decode_input_ids']
assert b.identity(source) == plan['source']
c.save(STAGE / 'summary.json', dict(passed=True, host_compiles=2, native_compiles=0, SDK_build=False,
    model_processes=2, same_predictions_and_inputs=True, throughput_claim=False, product_changes=False))
print('HOST_PROBE_COMPLETE', STAGE, flush=True)
