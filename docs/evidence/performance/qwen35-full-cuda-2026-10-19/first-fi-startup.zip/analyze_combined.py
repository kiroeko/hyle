"""Read existing probes/SQLite only; no compilation, model invocation or GPU work."""
from pathlib import Path
import hashlib
import json
import re
import sqlite3

STAGE = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


database = STAGE / "all-api/capture.sqlite"
db = sqlite3.connect("file:" + database.as_posix() + "?mode=ro", uri=True)
db.row_factory = sqlite3.Row
strings = dict(db.execute("SELECT id,value FROM StringIds"))
runtime = []
for row in db.execute("SELECT * FROM CUPTI_ACTIVITY_KIND_RUNTIME ORDER BY start"):
    item = dict(row)
    item["name"] = strings[item["nameId"]]
    item["duration_ns"] = item["end"] - item["start"]
    runtime.append(item)

# The model writes 128 I32 tokens and positions after both shape compilations.
# Earlier 512-byte weight uploads are deliberately excluded.
uploads = [dict(row) for row in db.execute(
    "SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE bytes=512 AND copyKind=1 ORDER BY start")][-2:]
assert len(uploads) == 2
upload_apis = []
for copy in uploads:
    candidates = [a for a in runtime if a["correlationId"] == copy["correlationId"]]
    assert len(candidates) == 1 and "MemcpyHtoD" in candidates[0]["name"]
    upload_apis.append(candidates[0])
anchor = max(row["end"] for row in upload_apis)
next_copies = [dict(row) for row in db.execute(
    "SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY WHERE bytes=4 AND copyKind=1 AND start>? ORDER BY start", (anchor,))]
assert next_copies
prefill_end = next_copies[0]["start"]

node_rows = {}
for row in db.execute("SELECT * FROM CUDA_GRAPH_NODE_EVENTS ORDER BY start"):
    item = dict(row)
    node_rows.setdefault(item["graphNodeId"], []).append(item)


def capture_launch(kernel):
    node = kernel["graphNodeId"]
    chain = []
    seen = set()
    while True:
        assert node not in seen
        seen.add(node)
        events = node_rows[node]
        parents = {e["originalGraphNodeId"] for e in events if e["originalGraphNodeId"] is not None}
        assert len(parents) <= 1
        chain.append(dict(node_id=node, events=events))
        if not parents:
            root = min(events, key=lambda e: e["start"])
            break
        node = parents.pop()
    # A graph-replayed kernel's correlationId belongs to GraphLaunch. Recover
    # its capture-time launch through the original graph node's creation event.
    calls = [a for a in runtime if a["globalTid"] == root["globalTid"]
             and a["start"] <= root["start"] <= a["end"]
             and a["name"].startswith("cudaLaunchKernel")]
    assert len(calls) == 1, calls
    launch = calls[0]
    preceding = [a for a in runtime if a["globalTid"] == launch["globalTid"]
                 and a["end"] <= launch["start"]]
    attr = next(a for a in reversed(preceding) if a["name"].startswith("cudaFuncSetAttribute"))
    between = [a for a in preceding if a["start"] >= attr["end"]]
    assert not any(a["name"].startswith("cudaLaunchKernel") for a in between)
    prelude = [a for a in preceding if a["end"] <= attr["start"]][-3:]
    assert [a["name"].split("_v")[0] for a in prelude] == [
        "cudaGetDevice", "cudaDeviceGetAttribute", "cudaDeviceGetAttribute"]
    replay = [a for a in runtime if a["correlationId"] == kernel["correlationId"]]
    assert len(replay) == 1 and replay[0]["name"].startswith("cudaGraphLaunch")
    return dict(gpu_kernel=kernel, graph_node_chain=chain,
                capture_creation=root, capture_launch=launch,
                corresponding_graph_replay_api=replay[0],
                preceding_attribute=attr, preceding_device_queries=prelude,
                intervening_apis=between,
                attribute_end_to_launch_start_ns=launch["start"] - attr["end"])


fi = []
for row in db.execute("SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start"):
    item = dict(row)
    name = strings[item["demangledName"]]
    if anchor < item["start"] < prefill_end and "BatchPrefillWithRaggedKVCacheKernel" in name:
        item["kernel_name"] = name
        item["duration_ns"] = item["end"] - item["start"]
        fi.append(item)
assert len(fi) == 6
mapped = [capture_launch(kernel) for kernel in fi]
attrs = [m["preceding_attribute"] for m in mapped]
assert len({a["correlationId"] for a in attrs}) == 6
step_attrs = [a for a in runtime if anchor < a["start"] < prefill_end
              and a["name"].startswith("cudaFuncSetAttribute")]
assert {a["correlationId"] for a in attrs} == {a["correlationId"] for a in step_attrs}

probes = {}
outputs = []
for arm in ("baseline", "current"):
    folder = STAGE / arm
    rows = []
    text = (folder / "model.stderr.log").read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.startswith("FI_HOST_PROBE "):
            rows.append({k: int(v) for k, v in re.findall(r"(\w+)=([0-9]+)", line)})
    assert rows and rows[0]["rows"] == 128
    prefill = [row for row in rows if row["rows"] == 128]
    assert len(prefill) == 6
    output = read(folder / "model.stdout.log")
    outputs.append(output)
    probes[arm] = dict(
        rows=rows, row_limit=24, first_native_ns=rows[0]["native_ns"],
        remaining_prefill_native_ns=[r["native_ns"] for r in prefill[1:]],
        phases=[line for line in text.splitlines() if line.startswith(("prepared T=128 ", "prefill "))],
        identities=[identity(folder / name) for name in (
            "flashinfer_provider.cc", "compile.command.json", "compile.result.json",
            "link.command.json", "link.result.json", "image.json", "model.command.json",
            "model.result.json", "model.stdout.log", "model.stderr.log", "runtime.json")],
        runtime=read(folder / "runtime.json"))
assert outputs[0]["generated_ids"] == outputs[1]["generated_ids"]
assert outputs[0]["decode_input_ids"] == outputs[1]["decode_input_ids"]
assert len(outputs[0]["generated_ids"]) == 32 and len(outputs[0]["decode_input_ids"]) == 31

streams = []
target_stdout = None
for row in db.execute("SELECT * FROM ProcessStreams"):
    filename = strings[row["filenameId"]]
    content = strings[row["contentId"]]
    if "/streams/" in filename.replace("\\", "/"):
        streams.append(dict(filename=filename, bytes=len(content.encode("utf-8")),
                            sha256=hashlib.sha256(content.encode("utf-8")).hexdigest(),
                            phase_lines=[line for line in content.splitlines()
                                         if line.startswith(("prepared T=128 ", "prefill "))]))
        if "stdout_" in filename:
            target_stdout = json.loads(content)
assert target_stdout is not None
assert target_stdout["generated_ids"] == outputs[0]["generated_ids"]
assert target_stdout["decode_input_ids"] == outputs[0]["decode_input_ids"]
profile_plan = read(STAGE / "all-api/plan.json")
for name in ("profile", "export"):
    result = read(STAGE / f"all-api/{name}.result.json")
    assert result["exit"] == 0 and result["terminal"] is True
assert "--cuda-trace-all-apis=true" in profile_plan["commands"]["profile"]
findings = read(STAGE / "findings.json")

report = dict(
    purpose="Independent capture-node-to-host-API confirmation, combined with completed temporary host-wrapper observations.",
    work_performed=dict(read_only_existing_evidence=True, new_compiles=0, new_model_processes=0,
                        new_GPU_work=False, product_changes=False, throughput_claim=False),
    evidence=[identity(STAGE / name) for name in (
        "findings.json", "host_probe.py", "plan.json", "summary.json", "profile_all_api.py",
        "all-api/plan.json", "all-api/profile.command.json", "all-api/profile.result.json",
        "all-api/profile.stdout.log", "all-api/profile.stderr.log", "all-api/export.command.json",
        "all-api/export.result.json", "all-api/capture.sqlite", "all-api/capture.nsys-rep",
        "all-api/runtime.json", "all-api/summary.json")],
    production_image=profile_plan["image"],
    scope=dict(input_tokens=128, fixed_decode_inputs=31, predictions=32,
               shape="BF16 causal ragged equal QK/VO depth 256; first prefill six FI calls",
               profiler_all_apis=True, model_inputs_and_predictions_identical_across_three_processes=True,
               full_tensor_numerical_comparison_in_these_three_processes=False),
    host_wrapper_observations=probes,
    all_api_observations=dict(
        input_copy_anchor=dict(copies=uploads, matching_host_apis=upload_apis,
                               host_end_ns=anchor, next_decode_copy=next_copies[0]),
        process_streams=streams, fi_prefill_calls=mapped,
        first_attribute_duration_ns=attrs[0]["duration_ns"],
        remaining_attribute_duration_ns=[a["duration_ns"] for a in attrs[1:]],
        first_get_device_and_two_attribute_duration_sum_ns=sum(a["duration_ns"] for a in mapped[0]["preceding_device_queries"]),
        first_attribute_to_launch_wall_ns=mapped[0]["capture_launch"]["end"] - attrs[0]["start"],
        first_fi_gpu_duration_ns=fi[0]["duration_ns"],
        first_capture_launch_duration_ns=mapped[0]["capture_launch"]["duration_ns"],
        attribute_share_of_attribute_through_launch_interval=attrs[0]["duration_ns"] / (mapped[0]["capture_launch"]["end"]-attrs[0]["start"])),
    conclusions=[
        "Confirmed: the first step's first FI capture kernel maps through original graph-node creation to cudaLaunchKernel corr54855, immediately preceded on the same host thread by cudaFuncSetAttribute corr54854 lasting 4,973,684 ns. The GPU kernel correlationId62229 instead names the later outer cudaGraphLaunch.",
        "The selected native prefill helper's source sequence is cudaGetDevice, two cudaDeviceGetAttribute queries, cudaFuncSetAttribute on the selected function, then cudaLaunchKernel. This matches the traced contiguous sequence. API function-pointer arguments are not present in this SQLite schema; association uses original node creation, same-thread order, no intervening launch, and actual selected source.",
        "Two separate non-profiler host-wrapper processes observe first native call 5.3774 ms (eager FI baseline) and 5.2920 ms (captured FI current); later same-T128 calls are microseconds. Thus this first-use cost is not created solely by outer graph capture.",
        "The full all-API trace directly localizes a millisecond first-use cost to cudaFuncSetAttribute. Previously missing CUDA API records cannot be described as pure CPU dispatch time. It does not establish which internal CUDA driver/module/kernel initialization mechanism accounts for that call.",
        "The first FI GPU kernel itself lasts only 11,456 ns in this trace. This startup host cost is separate from attention GPU math, graph instantiation cost, and steady-state decode critical-path cost.",
        "These separate processes and instrumented runs cannot explain the full unprofiled three-window prefill regression or demonstrate a speed/TTFT benefit. No product optimization was applied."
    ],
    limits=[
        "All-API profiling may perturb host latency and does not supply an unprofiled throughput estimate. Do not subtract the profiled attribute duration from another process's wrapper duration as an additive decomposition.",
        "The wrapper uses steady_clock, fixed 24-entry storage, and prints at shutdown, outside every measured step. Its native interval excludes stream/pointer resolution and context push but includes selected helper dispatch and original launch calls; timer overhead and coarse 100 ns increments still apply. It is not an internal CUDA/module profiler.",
        "Only generated IDs and fixed input IDs were compared in these three diagnostic processes, not hidden states/logits. Existing 64-vector product regression remains a separate evidence source.",
        "Captured replay does not call the host wrapper on every GPU math execution. Fewer wrapper rows cannot prove fewer attention kernels.",
        "The trace records no CUDA function-pointer arguments for FuncSetAttribute and no directly attributed internal module load beneath it. A matching SM89 cubin and PTX both exist in the actual native object; this alone does not establish driver loading/JIT policy.",
        "No new performance win, numeric change, synchronization change, or cross-platform/general-model claim is established."
    ],
    follow_up=dict(
        minimal_architecture=findings["generic_cold_binding_proposal"],
        falsifiable_check="If an implementation binds exactly the selected original launch function and shared-memory attribute once per retained native plan/context before capture, later first record should show no multi-ms attribute call while keeping the exact kernel/function/grid/block/shared memory and outputs. Compare process-entry-to-first-token and whole first-step boundaries; plan-time initialization must remain included, and total work saved/overlap must be shown before claiming TTFT speedup.",
        internal_module_loading_confirmed=False, optimization_implemented=False,
        moving_cost_to_another_timer_is_a_speedup=False),
    checks=dict(exact_six_prefill_FI_nodes=True, original_node_mapping_unique=True,
                capture_launch_unique=True, six_attribute_calls_unique_and_exhaust_step=True,
                no_intervening_kernel_launch_after_attribute=True,
                host_probe_and_production_profile_inputs_predictions_match=True,
                passed=True))
output = STAGE / "combined-evidence.json"
output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(output=identity(output), attributes_ns=[a["duration_ns"] for a in attrs],
                      first_capture_correlation=mapped[0]["capture_launch"]["correlationId"],
                      first_replay_correlation=mapped[0]["corresponding_graph_replay_api"]["correlationId"],
                      passed=True), indent=2))
