"""Run the small typed-load fixture, with exact-case and no-skip accounting."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('gdn_test_build', STAGE / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
m.check(plan)
assert c.read(path.parent / 'summary.json')['passed']
out = STAGE / 'tests'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
names = ['GgmlCudaGdnTypedLoad.' + name for name in (
    'IndependentVAndBetaMatchOriginalAcrossTokensAndSnapshots',
    'PublishedCastAndExtraReaderRetainF32Values',
    'RecurrentKeepsF32SigmoidAfterRawBetaWiden')]
link = plan['links']['gdn']
image = b.identity(link['image'])
assert image == c.read(path.parent / 'gdn-image.json')
env, _ = b.environment(link['command'], link['inputs'], out)
command = [image['path'], '--gtest_filter=' + ':'.join(names),
    '--gtest_output=xml:' + str(out / 'results.xml')]
try:
    c.execute('gdn', command, env, out)
finally:
    cases = ET.parse(out / 'results.xml').findall('.//testcase') if (out / 'results.xml').exists() else []
    actual = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
    passed = (set(actual) == set(names) and all(not any(row.find(tag) is not None
        for tag in ('failure', 'error', 'skipped')) for row in cases))
    c.save(out / 'summary.json', dict(passed=passed, cases=len(cases), names=actual,
        exact_filters=names, skipped=sum(row.find('skipped') is not None for row in cases),
        image=image, build_plan=b.identity(path), GPU_run=True))
if not passed:
    raise ValueError('Expected all3 exact CUDA fixture cases without skip/failure')
print('GDN_TYPED_LOAD_TESTS', len(cases), 'passed', flush=True)
