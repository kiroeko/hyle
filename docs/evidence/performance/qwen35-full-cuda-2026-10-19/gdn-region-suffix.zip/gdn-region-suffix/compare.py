"""Prepare, then explicitly run the retained nine-process matched rotation."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('dynamic_alias_retained_rotation', ARCH / 'batch-layout-query-reuse/compare_three.py')
rotation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rotation)
b, c, r = rotation.b, rotation.c, rotation.r
rotation.STAGE = STAGE
r.PREPARED = STAGE / 'performance-prepared'
BASELINE = ARCH / 'gdn-typed-load/checks/20261019T163125/qwen.exe'
BASELINE_SHA = '9fb98bd227f73d7c9052f737a7d72cfcd0f4b462c16798a7e4c2ee6c0c57a928'
PEER_SHA = 'fb169f0282f2a834a61b3e887edaba92d8699814558b0c5f1a13aaf07e0de969'


def runtime_environment(build, peer, out):
    # Same linked runtime construction as the preceding matched rotation.
    # This is not a union with an unrelated CPU test-image closure.
    inputs = build['links']['qwen']['inputs'] + peer['inputs']
    paths = [row['path'] if isinstance(row, dict) else row for row in inputs]
    env, runtime = b.environment(build['links']['qwen']['command'], paths, out)
    for key in r.FORBIDDEN_ENV:
        if key in env:
            raise ValueError('Unexpected experiment environment: ' + key)
    return env, runtime


r.runtime_environment = runtime_environment


def prepare(build_path):
    build_path = build_path.resolve()
    build = c.read(build_path)
    assert c.read(build_path.parent / 'summary.json')['passed']
    assert c.read(STAGE / 'correctness/summary.json')['passed']
    retained_path = ARCH / 'batch-graph-capture/performance-prepared/plan.json'
    retained = c.read(retained_path)
    images = dict(baseline=b.identity(BASELINE), current=c.read(build_path.parent / 'qwen-image.json'),
        llama=c.read(ARCH / 'cuda-explicit-rope/performance-prepared/peer-image.json'))
    assert images['baseline']['sha256'] == BASELINE_SHA
    assert images['llama']['sha256'] == PEER_SHA
    assert c.key(images['current']['path']) == c.key(build['links']['qwen']['image'])
    for row in images.values():
        r.require_same(row)
    # Reuse only actual fixture/model identities and metric values. Deliberately
    # never iterate retained['frozen'] as a source/build admission checklist.
    first_hyle = next(row['command'] for row in retained['requests'] if row['arm'] == 'current')
    first_peer = next(row['command'] for row in retained['requests'] if row['arm'] == 'llama')
    inputs = Path(first_hyle[first_hyle.index('--inputs') + 1])
    decode = Path(first_hyle[first_hyle.index('--decode-ids') + 1])
    manifest = inputs / 'weights.tsv'
    lines = manifest.read_text(encoding='utf-8').splitlines()
    inventory_path = ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json'
    inventory = c.read(inventory_path)
    model = Path(lines[1])
    record = next(row for row in inventory['files'] if row['path'] == model.name)
    model_expected = {'path': str(model.resolve()), 'bytes': record['size_bytes'], 'sha256': record['sha256']}
    converted = c.read(ARCH / 'llama-matched-consumer/converted-file-identity.json')
    r.require_same(model_expected)
    r.require_same(converted)
    assert lines[0] == 'HYLE_QWEN35_TEXT_V1' and lines[2] == retained['source_id'] == inventory['artifact_identity_sha256']
    assert len(lines[3:]) == 320
    assert list(map(int, (inputs / 'prompt.ids').read_text().split())) == retained['fixed']['prompt_ids']
    assert list(map(int, decode.read_text().split())) == retained['fixed']['decode_input_ids']
    assert len(retained['fixed']['prompt_ids']) == 128 and len(retained['fixed']['decode_input_ids']) == 31
    assert c.read(first_peer[2])['prompt_ids'] == retained['fixed']['prompt_ids']
    assert c.read(first_peer[2])['decode_input_ids'] == retained['fixed']['decode_input_ids']
    assert c.key(first_peer[1]) == c.key(converted['path'])
    peer = c.read(r.PEER_PLAN)
    assert len(peer['inputs']) == 9
    for row in peer['inputs']:
        r.require_same(row)
    requests = []
    for request in retained['requests']:
        argv = request['command'].copy()
        argv[0] = images[request['arm']]['path']
        assert '--trace' not in argv
        requests.append({**request, 'command': argv})
    assert [row['arm'] for row in requests] == r.ORDER
    frozen_paths = [Path(__file__), ARCH / 'batch-layout-query-reuse/compare_three.py',
        ARCH / 'cuda-bf16-dual-projection/compare_three_dual.py', build_path,
        build_path.parent / 'qwen-link-plan.json', r.PEER_PLAN, retained_path,
        STAGE / 'host-source-freeze.json', ARCH / 'gdn-typed-load/native-source-freeze.json', STAGE / 'correctness/summary.json',
        inventory_path, manifest, inputs / 'prompt.ids', decode, Path(first_peer[2])]
    plan = {key: retained[key] for key in ('schema_version', 'status', 'fixed', 'source_id',
        'expected_baseline_ids', 'order', 'metric_contract')}
    plan.update(build_plan=b.identity(build_path), images=images,
        frozen=[b.identity(path) for path in frozen_paths] + [model_expected, converted],
        peer_inputs=peer['inputs'], requests=requests, profiler=False,
        source_or_SDK_compilations_during_rotation=0, links_during_rotation=0,
        historical_source_freeze_check=False,
        precision_limit='Same-source BF16 weights; Hyle/reference intermediate precision recipes remain different.',
        baseline='Retained unchanged9fb98b production carrier image; its trace proved both inputs still F32 because ordinary region discovery split the private Casts.')
    r.PREPARED.mkdir(exist_ok=False)
    c.save(r.PREPARED / 'plan.json', plan)
    print('PREPARED_NO_GPU', r.PREPARED / 'plan.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        if args.build_plan:
            raise ValueError('Preparation and timed rotation are separate invocations')
        rotation.run(r.PREPARED / 'plan.json', STAGE / 'performance-rotation')
    else:
        if not args.build_plan:
            raise ValueError('--build-plan required')
        prepare(args.build_plan)
