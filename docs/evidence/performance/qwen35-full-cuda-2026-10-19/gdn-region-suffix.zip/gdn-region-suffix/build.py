"""Refresh only the GDN fusion proposal and its regression fixture."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'gdn-typed-load/checks/20261019T163125'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

old = load('gdn_carrier_build', ARCH / 'gdn-typed-load/build.py')
b, c = old.b, old.c

def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Current build input changed: ' + row['path'])

def prepare(out):
    seal = STAGE / 'host-source-freeze.json'
    frozen = [b.identity(Path(__file__)), b.identity(seal)]
    for row in c.read(seal)['files']:
        actual = b.identity(ROOT / row['path'])
        if any(actual[k] != row.get('after', row)[k] for k in ('bytes','sha256')):
            raise ValueError('Reviewed source differs: ' + row['path'])
        frozen.append(actual)
    rows = []
    templates = [
        ('adapter', ARCH / 'decode-next-cold/checks/20261019T155819/26-graph_provider_ggml_cuda-ggml_cuda_region-identity.json',
         ROOT / 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'),
        ('gdn-test', BASE / 'gdn-test-identity.json', ROOT / 'tests/graph_provider_ggml_cuda/gdn_typed_load_test.cc')]
    for tag, recipe_path, source in templates:
        recipe = c.read(recipe_path)
        command = b.host_command(recipe['command'], source, tag, out)
        frozen += [b.identity(source), b.identity(recipe_path)]
        frozen += [b.identity(p) for p in b.host_dependencies(recipe['command'])]
        snapshot = out / 'compiled-source' / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(source.read_bytes())
        frozen.append(b.identity(snapshot))
        rows.append(dict(tag=tag, source=b.identity(source), recipe=b.identity(recipe_path),
            old_object=recipe['object'], object=str(out / (tag+'.obj')), command=command))
    qwen = c.read(BASE / 'qwen-link-plan.json')
    gdn = c.read(BASE / 'gdn-link-plan.json')
    cached = {c.key(r['path']):r for r in [*qwen['inputs'], *gdn['inputs']]}
    replace = {c.key(r['old_object']['path']):r['object'] for r in rows}
    assert len(replace) == 2 and set(replace) <= set(cached)
    links = {}
    for arm, link in [('qwen',qwen),('gdn',gdn)]:
        image = out / (arm+'.exe')
        command = [replace.get(c.key(x),x) for x in link['command']
            if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib'))
            and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        assert len(inputs) == len(link['inputs']) and len(set(map(c.key,inputs))) == len(inputs)
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
        frozen += [b.identity(BASE / (arm+'-link-plan.json'))]
    frozen += [b.identity(ARCH/'gdn-typed-load/native-source-freeze.json'),
        b.identity(ROOT/'third_party/ggml_cuda_runtime/patches.json'),
        b.identity(ROOT/'cmake/HyleDependencyLock.json')]
    return dict(compile=rows, links=links, cached_inputs=list(cached.values()),
        frozen=list({c.key(r['path']):r for r in frozen}.values()), host_TUs=2, native_TUs=0,
        SDK_build=False, private_shared_ABI_changed=False, baseline_image=c.read(BASE/'qwen-image.json'),
        scope='Provider-local cold fusion proposal and actual-selection regression; existing native carrier and Graph core unchanged.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',action='store_true')
    p.add_argument('--resume',type=Path)
    args=p.parse_args()
    if args.resume:
        path=args.resume.resolve(); out=path.parent; plan=c.read(path)
    else:
        out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True,exist_ok=False); (out/'tmp').mkdir()
        plan=prepare(out); path=out/'plan.json'; c.save(path,plan)
    print('PLAN',path,flush=True)
    if not args.build: return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row): raise ValueError('Cached object changed: '+row['path'])
    env,_=b.environment(plan['links']['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
    identities={c.key(r['path']):r for r in plan['cached_inputs']}
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            prior=c.read(receipt)
            if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(r) for r in prior['dependencies']):
                identities[c.key(prior['object']['path'])]=prior['object']; print('REUSE',row['tag'],flush=True); continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt),row['command'],env,out)
        check(plan)
        data=c.read(out/(row['tag']+'-deps.json'))['Data']
        record=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in [data['Source'],*data['Includes']]])
        c.save(receipt,record); identities[c.key(record['object']['path'])]=record['object']
        print('COMPILED',row['tag'],flush=True)
    for arm,link in plan['links'].items():
        receipt=out/(arm+'-image.json')
        if receipt.exists() and b.same(c.read(receipt)): continue
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')))
        c.execute(arm+'-link-'+str(attempt),link['command'],env,out)
        check(plan)
        c.save(out/(arm+'-link-plan.json'),dict(command=link['command'],inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(receipt,b.identity(link['image']))
    c.save(out/'summary.json',dict(passed=True,host_TUs=2,native_TUs=0,SDK_build=False,GPU_run=False))
    c.save(STAGE/'latest-check.json',dict(plan=str(path)))
    print('BUILD_COMPLETE',path,flush=True)

if __name__=='__main__': main()
