"""Copy the unchanged model runner and adapt the matched rotation preparation."""
from pathlib import Path
STAGE=Path(__file__).resolve().parent
OLD=STAGE.parent/'gdn-typed-load'
assert not (STAGE/'run_model.py').exists() and not (STAGE/'compare.py').exists()
(STAGE/'run_model.py').write_bytes((OLD/'run_model.py').read_bytes())
code=(OLD/'compare.py').read_text(encoding='utf-8')
code=code.replace("BASELINE = ARCH / 'decode-next-cold/checks/20261019T155819/qwen.exe'",
    "BASELINE = ARCH / 'gdn-typed-load/checks/20261019T163125/qwen.exe'")
code=code.replace('88e738542418eeb3980f09118f014a2a87be145800a3884123d195f5eae3fab5',
    '9fb98bd227f73d7c9052f737a7d72cfcd0f4b462c16798a7e4c2ee6c0c57a928')
code=code.replace("STAGE / 'host-source-freeze.json', STAGE / 'native-source-freeze.json'",
    "STAGE / 'source-freeze.json', ARCH / 'gdn-typed-load/native-source-freeze.json'")
code=code.replace('Retained unchanged production 88e738 image, not temporary FI probe or old pre-co-capture image.',
    'Retained unchanged9fb98b production carrier image; its trace proved both inputs still F32 because ordinary region discovery split the private Casts.')
(STAGE/'compare.py').write_text(code,encoding='utf-8')
print('Prepared model and rotation helpers; no build/model started')
