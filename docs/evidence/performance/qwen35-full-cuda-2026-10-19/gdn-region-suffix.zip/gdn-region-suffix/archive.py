"""Archive the host-only GDN region correction; no build, model run or cleanup."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/gdn-region-suffix.zip'
OMIT = {'.exe', '.obj', '.o', '.map', '.lib', '.a', '.exp', '.pdb', '.dll',
        '.pyc', '.tmp', '.bf16', '.f16', '.f32', '.bin', '.npy', '.zip'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def check(row, path=None):
    actual = identity(path or row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256')), (row, actual)
    return actual


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', required=True, type=Path)
    args = parser.parse_args()
    plan_path = args.build_plan.resolve()
    assert plan_path.is_relative_to(STAGE / 'checks')
    plan = read(plan_path)
    build = read(plan_path.parent / 'summary.json')
    assert build['passed'] and build['host_TUs'] == 2 and build['native_TUs'] == 0
    assert not build['SDK_build']

    tests = read(STAGE / 'tests/summary.json')
    process = read(STAGE / 'tests/gdn.result.json')
    cases = ET.parse(STAGE / 'tests/results.xml').findall('.//testcase')
    names = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases]
    assert tests['passed'] and tests['cases'] == len(cases) and len(cases) > 0
    assert tests['skipped'] == 0 and len(set(names)) == len(names)
    assert set(names) == set(tests['exact_filters']) and process['exit'] == 0
    assert not any(x.find('failure') is not None or x.find('error') is not None or
                   x.find('skipped') is not None for x in cases)
    model = read(STAGE / 'correctness/summary.json')
    observation = model['observation']
    assert model['passed'] and observation['equal_vectors'] == len(observation['vectors']) == 64
    assert observation['all_outputs_finite'] and observation['same_fixed_decode_inputs']
    assert observation['same_greedy_ids_as_reference'] and len(observation['generated_ids']) == 32
    assert len(observation['decode_input_ids']) == 31
    for row in observation['vectors']:
        assert row['byte_equal'] and row['actual']['bytes'] == row['reference']['bytes']
        assert row['actual']['sha256'] == row['reference']['sha256']
    perf = read(STAGE / 'performance-rotation/summary.json')
    runs = read(STAGE / 'performance-rotation/runs.json')
    assert perf['terminal_zero'] == len(runs) == 9 and not perf['profiler']
    assert [r['arm'] for r in runs] == perf['order']
    assert all(r['exit'] == 0 and r['decode_input_ids'] == observation['decode_input_ids'] for r in runs)
    assert all(len(perf['groups'][arm]['full31_seconds']['samples']) == 3
               for arm in ('baseline', 'current', 'llama'))
    profile = read(STAGE / 'profile/summary.json')
    analysis = read(STAGE / 'profile/analysis.json')
    assert profile['passed'] and analysis['passed']
    for name in ('capture.nsys-rep', 'capture.sqlite', 'capture_cuda_gpu_kern_sum.csv'):
        assert (STAGE / 'profile' / name).is_file()
    # Physical counts remain measured observations, never repaired to an expectation.

    payloads = {}
    def add(path, name):
        path = Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT), path
        assert name not in payloads or payloads[name] == path, name
        payloads[name] = path

    seal_path = STAGE / 'host-source-freeze.json'
    frozen = read(seal_path)
    assert len(frozen['files']) == 2
    sources = []
    for row in frozen['files']:
        rel = Path(row['path'])
        after = row.get('after', row)
        current = check(after, ROOT / rel)
        add(ROOT / rel, 'gdn-region-suffix/final-source/' + rel.as_posix())
        before = STAGE / 'host-before' / rel
        if not before.exists():
            before = STAGE / 'before' / rel
        sources.append(dict(path=rel.as_posix(), before=check(row['before'], before), after=current))
    # Only FINAL actual owner dependencies are checked against current product.
    # Historical attempt1 freezes/logs stay verbatim; they are not current source.
    owners, dependencies, support = [], {}, set()
    for owner in plan['compile']:
        receipt_path = plan_path.parent / (owner['tag'] + '-identity.json')
        record = read(receipt_path)
        assert record['command'] == owner['command']
        check(owner['source'])
        source = Path(owner['source']['path']).resolve()
        check(owner['source'], plan_path.parent / 'compiled-source' / source.relative_to(ROOT))
        for row in [record['source'], *record['dependencies']]:
            path = Path(row['path']).resolve()
            if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('src', 'include', 'tests', 'cmake'):
                check(row)
                old = dependencies.get(str(path).casefold())
                assert old is None or old['sha256'] == row['sha256'], path
                dependencies[str(path).casefold()] = row
        check(owner['recipe'])
        support.add(Path(owner['recipe']['path']).resolve())
        owners.append(dict(tag=owner['tag'], source=record['source'], object=record['object'], receipt=identity(receipt_path)))
    for row in dependencies.values():
        path = Path(row['path']).resolve()
        add(path, 'gdn-region-suffix/dependency-source/' + path.relative_to(ROOT).as_posix())

    # Retain small recipe/freeze records, not the unchanged native89 closure.
    for row in plan['frozen']:
        path = Path(row['path']).resolve()
        if path.suffix.lower() in ('.json', '.py'):
            check(row)
            if not path.is_relative_to(STAGE):
                support.add(path)
    pending, seen = list(STAGE.rglob('*.py')), set()
    while pending:
        path = pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts:
            continue
        assert path.is_file() and path.is_relative_to(ROOT), path
        seen.add(path)
        code = path.read_text(encoding='utf-8')
        for variable, base in (('ARCH', ARCH), ('STAGE', path.parent), ('ROOT', ROOT)):
            pending += [base / name for name in re.findall(variable + r"\s*/\s*['\"]([^'\"]+\.py)['\"]", code)]
        if not path.is_relative_to(STAGE):
            support.add(path)
    inputs = read(STAGE / 'correctness/inputs.json')
    for key in ('manifest', 'prompt', 'decode'):
        check(inputs[key])
        support.add(Path(inputs[key]['path']).resolve())
    support.add(ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
    for rel in ('docs/architecture/compute-design.md', 'docs/developer/current-work.md',
                'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
        support.add(ROOT / rel)
    prior = read(STAGE / 'prior-non-hit-support.json')
    for row in prior['files']:
        check(row, ROOT / row['snapshot_path'])
    prior_receipt = read(STAGE / 'support/gdn-typed-load/archive-receipt.json')
    for path in sorted(support):
        assert path.suffix.lower() not in OMIT
        add(path, 'gdn-region-suffix/support/' + path.relative_to(ROOT).as_posix())
    for path in STAGE.rglob('*'):
        if not path.is_file() or path.suffix.lower() in OMIT:
            continue
        rel = path.relative_to(STAGE)
        if {x.lower() for x in rel.parts}.intersection({'tmp', '__pycache__', 'sdk', 'cache'}):
            continue
        if path.name == 'archive-receipt.json' and path.parent == STAGE:
            continue
        add(path, 'gdn-region-suffix/' + rel.as_posix())

    scope = dict(host_TUs=2, native_TUs=0, tests=names, equal_vectors=64,
        unprofiled_processes=9, sources=sources, owners=owners,
        current_profile=dict(passed=profile['passed'], physical_expectations_met=profile.get('physical_expectations_met'),
                             observed_counts=profile.get('observed_counts')),
        prior_physical_non_hit_archive=prior_receipt,
        retained='Original attempt1 source/freeze/application and2failed+1passed fixture results, final source/actual owner deps and commands, actual numerical/performance/profile raw records and independent review.',
        excluded='Unchanged oldnative89headers/source, SDK/model/object/image/debug/tmp payloads and duplicate64raw tensors. Original non-hit archive and exact per-vector identities supply their evidence references.',
        limits='Selected-region membership, actual typed physical hit and numerical/throughput observations are distinct. No independent quality or statistically stable speed acceptance is implied.',
        cleanup_executed=False)
    scope_bytes = (json.dumps(scope, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    manifest = {name: identity(path) for name, path in sorted(payloads.items())}
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payloads.items()):
            archive.write(path, name)
        archive.writestr('archive-scope.json', scope_bytes)
        archive.writestr('payload-sha256.json', manifest_bytes)
    expected = {name: row['sha256'] for name, row in manifest.items()}
    expected.update({'archive-scope.json': sha(scope_bytes), 'payload-sha256.json': sha(manifest_bytes)})
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist()) == len(expected)
        for info in archive.infolist():
            h, crc, size = hashlib.sha256(), 0, 0
            with archive.open(info) as handle:
                while chunk := handle.read(1024 * 1024):
                    h.update(chunk)
                    crc, size = zlib.crc32(chunk, crc), size + len(chunk)
            assert size == info.file_size and crc & 0xffffffff == info.CRC, info.filename
            assert h.hexdigest() == expected[info.filename], info.filename
    receipt = dict(**identity(DEST), entries=len(expected), payloads=len(manifest),
        crc_verified=True, payload_sha256_verified=True, verification_passes=1,
        build_plan=identity(plan_path), source_freeze=identity(seal_path),
        host_TUs=2, native_TUs=0, tests=len(cases), equal_vectors=64,
        unprofiled_processes=9, physical_expectations_met=profile.get('physical_expectations_met'),
        raw_vector_duplicates_omitted=True, old_native_payloads_omitted=True, cleanup_executed=False)
    save(STAGE / 'archive-receipt.json', receipt)
    save(DEST.with_name('gdn-region-suffix-archive.json'), receipt)
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
