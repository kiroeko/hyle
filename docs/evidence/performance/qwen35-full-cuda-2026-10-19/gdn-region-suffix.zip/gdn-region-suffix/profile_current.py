"""Prepare, or explicitly collect one production-image CUDA/API trace."""
from pathlib import Path
import argparse
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
OUT = STAGE / 'profile'
NATIVE_FREEZE = ARCH / 'gdn-typed-load/native-source-freeze.json'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_current(b, c, plan_path):
    plan = c.read(plan_path)
    summary = c.read(plan_path.parent / 'summary.json')
    if not summary['passed'] or summary['host_TUs'] != 2 or summary['native_TUs'] != 0:
        raise ValueError('Successful current two-host/zero-native build required')
    if c.key(c.read(STAGE / 'latest-check.json')['plan']) != c.key(plan_path):
        raise ValueError('Expected this stage latest build')
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Current build identity changed: ' + row['path'])
    for row in c.read(STAGE / 'host-source-freeze.json')['files']:
        expected = row.get('after', row)
        actual = b.identity(ROOT / row['path'])
        if any(actual[k] != expected[k] for k in ('bytes', 'sha256')):
            raise ValueError('Current source differs from host-source-freeze: ' + row['path'])
    # This batch changes only the two host owners. Retain and check the actual
    # native source identities, without applying the old host/product freeze.
    for row in c.read(NATIVE_FREEZE)['files']:
        if not b.same(row['after']):
            raise ValueError('Retained native source changed: ' + row['path'])
    test_path = STAGE / 'tests/summary.json'
    tests = c.read(test_path)
    if not tests['passed'] or tests['cases'] < 3 or tests['skipped'] != 0:
        raise ValueError('Current three-or-more CUDA cases without skips required')
    cases = ET.parse(STAGE / 'tests/results.xml').findall('.//testcase')
    actual = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
    if (len(actual) != tests['cases'] or len(set(actual)) != len(actual)
            or set(actual) != set(tests['names'])
            or set(actual) != set(tests['exact_filters'])
            or any(row.find(tag) is not None for row in cases for tag in ('failure', 'error', 'skipped'))):
        raise ValueError('Current XML disagrees with exact successful test summary')
    if tests['build_plan'] != b.identity(plan_path):
        raise ValueError('CUDA tests used another build plan')
    if tests['image'] != c.read(plan_path.parent / 'gdn-image.json') or not b.same(tests['image']):
        raise ValueError('CUDA test image differs')
    correctness = c.read(STAGE / 'correctness/summary.json')
    observed = correctness['observation']
    if (not correctness['passed'] or observed['equal_vectors'] != 64
            or not observed['all_outputs_finite']
            or observed['image'] != c.read(plan_path.parent / 'qwen-image.json')):
        raise ValueError('Current fixed-input 64-exact model regression required')
    return plan


def prepare(b, c, plan_path):
    if (OUT / 'plan.json').exists():
        raise ValueError('Refuse to overwrite trace plan')
    plan = verify_current(b, c, plan_path)
    rotation_path = STAGE / 'performance-prepared/plan.json'
    rotation = c.read(rotation_path)
    request = next(row for row in rotation['requests'] if row['arm'] == 'current')
    command = request['command'].copy()
    image = c.read(plan_path.parent / 'qwen-image.json')
    if b.identity(command[0]) != image or rotation['images']['current'] != image:
        raise ValueError('Exact production image differs')
    if '--trace' in command or '--trace-level' in command:
        raise ValueError('No tensor dumps in this physical trace')
    assert command[command.index('--steps') + 1] == '32'
    assert command[command.index('--capacity') + 1] == '256'
    assert len(rotation['fixed']['prompt_ids']) == 128 and len(rotation['fixed']['decode_input_ids']) == 31
    nsys = c.read(ARCH / 'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0]
    stem = OUT / 'capture'
    commands = dict(
        profile=[nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
            '--discard-environment=true', '--output=' + str(stem), *command],
        export=[nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        stats=[nsys, 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,cuda_gpu_mem_size_sum',
               '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'])
    OUT.mkdir(exist_ok=False)
    (OUT / 'tmp').mkdir()
    c.save(OUT / 'plan.json', dict(status='prepared_not_run', build_plan=b.identity(plan_path),
        runner=b.identity(Path(__file__)), analyzer=b.identity(STAGE / 'analyze_profile.py'),
        image=image, link_plan=b.identity(plan_path.parent / 'qwen-link-plan.json'),
        current_freezes=[b.identity(STAGE / 'host-source-freeze.json')],
        retained_native_freeze=b.identity(NATIVE_FREEZE),
        test_summary=b.identity(STAGE / 'tests/summary.json'),
        test_XML=b.identity(STAGE / 'tests/results.xml'),
        correctness_summary=b.identity(STAGE / 'correctness/summary.json'),
        retained_input_plan=b.identity(rotation_path), fixed=rotation['fixed'], source_id=rotation['source_id'],
        expected_generated_ids=c.read(STAGE / 'correctness/summary.json')['observation']['generated_ids'],
        commands=commands, consumer_command=command, GPU_model_processes_planned=1,
        baseline_reprofiled=False, baseline_launch_count_reference=740,
        expected_not_asserted=dict(decode7_kernels=704, BF16_to_F32=73, F32_to_BF16=54,
                                   GDN=18, GDN_V_BF16_beta_BF16=18),
        tensor_dumps=False, all_CUDA_APIs=True, compilations=0, links=0, throughput_claim=False,
        timed_rotation_required_before_collection=False,
        limits='One current trace, all-API profiling perturbs timing. Physical instantiations/counts only; source/IDs and existing64vector proof are separate. No inferred CPU attribution from unmarked gaps.'))
    print('PROFILE_PREPARED_NO_GPU', OUT / 'plan.json', flush=True)


def run(b, c, plan_path):
    if not (OUT / 'plan.json').exists():
        prepare(b, c, plan_path)
    current = verify_current(b, c, plan_path)
    plan = c.read(OUT / 'plan.json')
    assert plan['build_plan'] == b.identity(plan_path)
    for row in [plan['runner'], plan['analyzer'], plan['image'], plan['link_plan'],
                plan['retained_native_freeze'], plan['retained_input_plan'],
                plan['test_summary'], plan['test_XML'], plan['correctness_summary'],
                *plan['current_freezes']]:
        if not b.same(row):
            raise ValueError('Prepared trace identity changed: ' + row['path'])
    link = c.read(Path(plan['link_plan']['path']))
    paths = [row['path'] if isinstance(row, dict) else row for row in link['inputs']]
    env, runtime = b.environment(link['command'], paths, OUT)
    forbidden = ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION', 'GGML_CUDA_GRAPH_OPT',
                 'HYLE_RMS_DIAG', 'HYLE_GDN_L2_DIAG')
    if any(key in env for key in forbidden):
        raise ValueError('Non-production graph/diagnostic override')
    c.save(OUT / 'runtime.json', dict(runtime_library_directories_from_own_link=runtime,
        link_input_count=len(paths), unrelated_CPU_or_peer_DLL_union_used=False,
        CUDA_MODULE_LOADING=env.get('CUDA_MODULE_LOADING'), forbidden_overrides_absent=list(forbidden)))
    for tag, command in plan['commands'].items():
        if (OUT / (tag + '.command.json')).exists() or (OUT / (tag + '.result.json')).exists():
            raise ValueError('No implicit profile/export/stats retry: ' + tag)
        c.execute(tag, command, env, OUT)
    c.save(OUT / 'collection-summary.json', dict(passed=True, fresh_model_processes=1,
        profile_exit=c.read(OUT / 'profile.result.json')['exit'],
        export_exit=c.read(OUT / 'export.result.json')['exit'],
        stats_exit=c.read(OUT / 'stats.result.json')['exit'], throughput_claim=False))
    load('gdn_physical_analysis', STAGE / 'analyze_profile.py').analyze()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', type=Path)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--analyze', action='store_true')
    args = parser.parse_args()
    if args.run and args.analyze:
        raise ValueError('Choose collection or offline analysis')
    if args.analyze:
        load('gdn_physical_analysis', STAGE / 'analyze_profile.py').analyze()
    else:
        h = load('gdn_profile_build_helpers', STAGE / 'build.py')
        run(h.b, h.c, args.plan.resolve()) if args.run else prepare(h.b, h.c, args.plan.resolve())
