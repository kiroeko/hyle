param([switch]$ReclaimCompletedQwen)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/qwen-benchmark-reclaim'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
$externalMistarget = [IO.Path]::GetFullPath([string]$plan.single_external_mistarget.path)
$expectedMistarget = [IO.Path]::GetFullPath((Join-Path ([IO.Directory]::GetParent($workspace).FullName) 'docs/evidence/correctness/inference-foundation-review-2026-10-18/linux-current-graph.zip'))
if ($externalMistarget -ne $expectedMistarget) { throw 'Unexpected external cleanup target' }
function Assert-Identity($entry, [switch]$AllowMistarget) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase) -and
        -not ($AllowMistarget -and $path -eq $expectedMistarget)) { throw "Outside intended project paths: $path" }
    $item = Get-Item -LiteralPath $path
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
        throw "Identity changed: $path"
    }
}
foreach ($archive in $plan.archives) { Assert-Identity $archive }
foreach ($object in $plan.retained_objects) { Assert-Identity $object }
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if ($path -ne $expectedMistarget) {
        if ($plan.allowed_parent_directories -notcontains [IO.Path]::GetDirectoryName($path)) { throw "Outside exact completed stages: $path" }
        if (@('.exe', '.map', '.lib', '.exp') -notcontains [IO.Path]::GetExtension($path)) { throw "Not a completed linked image: $path" }
    }
    Assert-Identity $entry -AllowMistarget
}
if (-not $ReclaimCompletedQwen) {
    [pscustomobject]@{ files = $plan.files; bytes = $plan.bytes; archives = $plan.archives.Count; retained_objects = $plan.retained_objects.Count }
    return
}
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup receipt already exists; do not replay deletions' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{
        deleted = $deleted.ToArray(); files = $deleted.Count; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum
        archives_verified = $true; retained_objects = $plan.retained_objects; complete = ($deleted.Count -eq $plan.targets.Count)
        linux_images_retained = $true; single_converted_model_retained = $plan.preserved_model_identity
        script_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
    } | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($object in $plan.retained_objects) { Assert-Identity $object }
[pscustomobject]@{ deleted_files = $deleted.Count; reclaimed_bytes = $plan.bytes; retained_objects = $plan.retained_objects.Count }
