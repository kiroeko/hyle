"""Three matched process pairs or one official trace, after numerical proof."""
from pathlib import Path
import argparse
import importlib.util
import json
import statistics
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result

b=load('rms_build',STAGE/'build_current.py')
c=b.c
old=load('retained_metrics',b.ARCH/'cuda-normalization-review/experiment.py')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('plan',type=Path);p.add_argument('mode',choices=('performance','profile'))
    args=p.parse_args();plan=c.read(args.plan)
    candidate=Path(plan['links']['qwen']['image'])
    proof=c.read(args.plan.parent/'run-qwen/summary.json')
    if proof['equal_vectors']!=64 or not proof['same_generated_ids'] or not proof['same_decode_input_ids']:
        raise ValueError('Exact real-model numerical proof is incomplete')
    current=b.b.identity(candidate)
    if current!=proof['image']:
        raise ValueError('Candidate image differs from the numerical proof')
    out=STAGE/args.mode;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    env,_=b.b.environment(plan['links']['qwen']['command'],
        [row['path'] for row in plan['cached_inputs']],out)
    original=c.read(b.ARCH/'cuda-reshape-reuse/profile-qwen.command.json')['command']
    image_index=original.index('--inputs')-1
    model=[str(candidate)]+original[image_index+1:]
    if args.mode=='profile':
        stem=out/'qwen-rms-frontier-trace'
        command=[('--output='+str(stem)) if item.startswith('--output=') else item
            for item in original[:image_index]]+model
        c.save(out/'inputs.json',{'image':current,'command':command,'profiler_runs':1,
            'full_step_performance':False,'numerical_proof':b.b.identity(args.plan.parent/'run-qwen/summary.json')})
        c.execute('profile',command,env,out)
        c.execute('export',[original[0],'export','--type=sqlite','--output='+str(stem)+'.sqlite',
            str(stem)+'.nsys-rep'],env,out)
        # Read the completed export directly; nsys-rep timestamp checks do not
        # justify repeating an already completed GPU collection.
        c.execute('stats',[original[0],'stats','--report=cuda_gpu_kern_sum,cuda_api_sum',
            '--format=csv','--output='+str(stem),str(stem)+'.sqlite'],env,out)
        c.save(out/'summary.json',{'image':current,'trace_stem':str(stem),
            'profiler_runs':1,'terminal':True,'throughput_claim':False})
        print('PROFILE_COMPLETE',stem,flush=True);return
    prior_path=b.ARCH/'cuda-gdn-l2-fusion/checks/timing-report-20261019T075349/qwen-link-plan.json'
    prior=c.read(prior_path)
    for row in prior['inputs']:
        if not b.b.same(row):raise ValueError('Baseline retained input drift: '+row['path'])
    baseline=out/'baseline.exe'
    command=[item for item in prior['command']
        if not item.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(baseline),'/MAP:'+str(baseline.with_suffix('.map')),
        '/IMPLIB:'+str(baseline.with_suffix('.lib'))]
    c.save(out/'baseline-link-plan.json',dict(prior,command=command))
    c.execute('baseline-link',command,env,out)
    order=['baseline','candidate','candidate','baseline','baseline','candidate']
    expected=json.loads((b.ARCH/'cuda-reshape-reuse/correctness-candidate.stdout.log').read_text().splitlines()[-1])
    c.save(out/'inputs.json',{'order':order,'baseline':b.b.identity(baseline),'candidate':current,
        'baseline_recipe':b.b.identity(prior_path),'prompt':128,'decode':31,'capacity':256,
        'profiler':False,'memory_monitor':False,
        'timing':'consumer step_seconds including upload/layout/binding/capture preparation/submit/wait'})
    runs=[]
    for index,arm in enumerate(order):
        argv=model.copy();argv[0]=str(baseline if arm=='baseline' else candidate)
        tag=f'{index+1:02d}-{arm}';c.execute(tag,argv,env,out)
        observed=json.loads((out/(tag+'.stdout.log')).read_text().splitlines()[-1])
        if observed['generated_ids']!=expected['generated_ids'] or observed['decode_input_ids']!=expected['decode_input_ids']:
            raise ValueError('The fixed journey differs')
        runs.append({'arm':arm,'tag':tag,**old.metrics(out/(tag+'.stderr.log'))})
        c.save(out/'runs.json',runs)
    keys=[key for key in runs[0] if key not in ('arm','tag')]
    groups={arm:{key:{'samples':[row[key] for row in runs if row['arm']==arm],
        'median':statistics.median(row[key] for row in runs if row['arm']==arm)}
        for key in keys} for arm in ('baseline','candidate')}
    summary={'groups':groups,'ratios':{key:groups['candidate'][key]['median']/groups['baseline'][key]['median']
        for key in keys},'all_ids_equal':True,'statistical_significance':False,'quality_acceptance':False}
    c.save(out/'summary.json',summary);print(json.dumps(summary),flush=True)

if __name__=='__main__':
    main()
