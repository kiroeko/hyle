"""Only provider/test/consumer host increments; all CUDA and SDK objects reused."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('rms_frontier_base', ARCH/'cuda-projection-fusion/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); c = b.c
GDN = ARCH/'cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236'
QWEN = ARCH/'cuda-gdn-l2-fusion/checks/timing-report-20261019T075349'

def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]

def check(plan):
    for row in plan['frozen'] + plan['cached_inputs']:
        if not b.same(row): raise ValueError('Input drift: '+row['path'])

def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--build', action='store_true'); args = p.parse_args()
    out = STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    recipes = (
        ('region', 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc', ARCH/'immutable-constant-alias/checks/20261019T063301-1d108b74/77-graph_provider_ggml_cuda-ggml_cuda_region-identity.json'),
        ('rms-cast-test', 'tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc', ARCH/'cuda-rms-inplace/checks/20261019T071441-877cffe6/rms-cast-test-identity.json'),
        ('consumer', 'tools/qwen35_text/main.cc', QWEN/'consumer-identity.json'))
    frozen = [b.identity(x) for x in (Path(__file__), STAGE/'run_checks.py', ROOT/'third_party/ggml_cuda_runtime/patches.json', ROOT/'include/hyle/mem/mapping.h')]
    compiles = []; replacements = {}
    for tag, relative, path in recipes:
        recipe = c.read(path); source = ROOT/relative
        command = b.host_command(recipe['command'], source, tag, out)
        compiles.append({'tag':tag, 'command':command, 'source':b.identity(source), 'object':str(out/(tag+'.obj'))})
        replacements[c.key(recipe['object']['path'])] = str(out/(tag+'.obj'))
        frozen.extend(b.identity(x) for x in (path, source))
        frozen.extend(b.identity(x) for x in b.host_dependencies(recipe['command']) if x.is_file())
    original = c.read(GDN/'run-cuda/summary.json')['cases']
    found = ['.'.join(x) for x in re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', (ROOT/'tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc').read_text())]
    cases = original + [x for x in found if x not in original]
    if len(cases) != len(set(cases)): raise ValueError('Duplicate regression')
    cached = {}; links = {}
    for name, base, count in (('cuda',GDN,131), ('qwen',QWEN,123)):
        path = base/(name+'-link-plan.json'); old = c.read(path)
        if len(old['inputs']) != count: raise ValueError('Baseline closure differs')
        frozen.append(b.identity(path))
        for row in old['inputs']: cached[row['path']] = row
        selected = {key:value for key,value in replacements.items() if any(c.key(row['path'])==key for row in old['inputs'])}
        if len(selected) != 2: raise ValueError('Expected region plus consumer/test replacement')
        image = out/(name+'.exe')
        command = [selected.get(c.key(x),x) for x in old['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
        if len(inputs(command)) != count: raise ValueError('New closure differs')
        links[name] = {'command':command,'inputs':inputs(command),'image':str(image)}
    plan = {'compile':compiles,'links':links,'frozen':list({x['path']:x for x in frozen}.values()),'cached_inputs':list(cached.values()),
        'directed_tests':cases,'native_TUs':0,'host_TUs':3,'SDK_build':False,'CMake_run':False}
    target = out/'plan.json'; c.save(target,plan); check(plan); print('PLAN',target,flush=True)
    if not args.build: return
    (out/'tmp').mkdir(); env,_ = b.environment(links['qwen']['command'], list(cached), out)
    for item in compiles:
        c.execute(item['tag']+'-compile',item['command'],env,out); check(plan)
        c.save(out/(item['tag']+'-identity.json'), {'command':item['command'],'source':item['source'],'object':b.identity(item['object'])})
    for name,link in links.items():
        c.execute(name+'-link',link['command'],env,out); check(plan)
        c.save(out/(name+'-link-plan.json'), {'command':link['command'],'inputs':[b.identity(x) for x in link['inputs']]})
        c.save(out/(name+'-image.json'),b.identity(link['image']))
    c.save(out/'summary.json',{'passed':True,'host_TUs':3,'native_TUs':0,'GPU_run':False}); print('BUILD_COMPLETE',target,flush=True)

if __name__ == '__main__': main()
