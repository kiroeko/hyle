"""Run retained CUDA coverage plus the focused RMS cases, or exact Qwen replay."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def main():
    if len(sys.argv)!=3 or sys.argv[2] not in ('cuda','qwen'): raise ValueError('Usage: plan.json {cuda|qwen}')
    b=load('frontier_build',STAGE/'build_current.py'); plan=b.c.read(Path(sys.argv[1])); b.check(plan)
    runner=load('frontier_checks',b.ARCH/'cuda-normalization-review/run_checks.py')
    runner.STAGE=STAGE; runner.b=b; runner.c=b.c; runner.CASES={'cuda':plan['directed_tests']}; runner.main()

if __name__ == '__main__': main()
