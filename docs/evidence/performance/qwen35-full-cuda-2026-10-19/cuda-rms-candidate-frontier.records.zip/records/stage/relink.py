"""Retain the failed attempt; add its missing cached platform_fs library only."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frontier_relink_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c

def main():
    prior=STAGE/'checks/20261019T080921'; original=c.read(prior/'plan.json'); b.check(original)
    fs=b.ROOT/'.scratch/build-compute-v2-dev/bin/hyle_platform_fs.lib'
    if b.b.identity(fs)['sha256']!='3c750d5908efe3fc60570ed87ea469c6e907d236dd72a42f14fbd25c6ea0eafb': raise ValueError('FS cache differs')
    out=STAGE/'checks'/('platform-fs-relink-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
    out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    cuda=dict(original['links']['cuda'])
    qwen=original['links']['qwen']; image=out/'qwen.exe'
    command=[x for x in qwen['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command += [str(fs),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    if len(b.inputs(command))!=124:raise ValueError('Expected123inputs pluscachedplatform_fs')
    built=[b.b.identity(row['object']) for row in original['compile']]
    plan=dict(original,links={'cuda':cuda,'qwen':{'command':command,'image':str(image),'inputs':b.inputs(command)}},
        frozen=original['frozen']+[b.b.identity(Path(__file__))],cached_inputs=original['cached_inputs']+built+[b.b.identity(fs)],
        compile=[],compiled_host_TUs_preceding_attempt=3,relink_only=True,failed_attempt=b.b.identity(prior/'plan.json'))
    target=out/'plan.json';c.save(target,plan);b.check(plan);print('PLAN',target,flush=True)
    env,_=b.b.environment(command,[row['path'] for row in plan['cached_inputs']],out)
    c.execute('qwen-link',command,env,out);b.check(plan)
    c.save(out/'qwen-link-plan.json',{'command':command,'inputs':[b.b.identity(x) for x in b.inputs(command)]})
    c.save(out/'qwen-image.json',b.b.identity(image))
    for name in ('cuda-link-plan.json','cuda-image.json'):c.save(out/name,c.read(prior/name))
    c.save(out/'summary.json',{'passed':True,'compile_commands':0,'links':1,'original_host_TUs':3,'SDK_build':False})
    print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
