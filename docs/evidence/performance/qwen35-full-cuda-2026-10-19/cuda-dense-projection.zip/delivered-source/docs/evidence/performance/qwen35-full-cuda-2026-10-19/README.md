# Qwen3.5-2B 全 CUDA 实际对照

2026-10-19，Windows / RTX 4070 12GB / driver 617.14。双方完整执行官方同源2B文本模型24层，
不执行视觉或MTP，权重在推理前全部驻留GPU；同为BF16权重、BF16 KV、单请求、context容量256、GPU greedy。
llama.cpp为本地d9e03f1074dbd2979126d91dce1b5d304ec8394e，复用与其GGML pin 456相符的原CUDA数学闭包，
不是本地较新HEAD，也不把既有Hyle资源集成补丁隐藏为纯上游未修改构建。

以下首表保留修改前基线。本日后续先统一普通ggml CUDA区域的临时寿命复用，再接入共同Graph workspace，
并补齐BF16逐算子承载；当前128-token场景Hyle显存降至3.939 GiB。各阶段变更与同源A/B见文末，
不能把旧表6.431 GiB当作修复后的数值。

每个场景3对独立进程，按H/L、L/H、H/L顺序运行，表列中位数。输入前缀和31个decode输入逐token一致，
两边分别反馈自己的KV/conv/GDN状态；未读取对方状态、hidden或logits。所有吞吐测量未挂profiler。
21-token场景另有一次关闭内存监控的对照，两端预热后decode分别76.14和106.16 tokens/s，未作开销修正。

| 指标 | Hyle | llama.cpp |
|---|---:|---:|
| 128-token场景：权重/模型加载子段 | 3.086 s | 1.603 s |
| 有效载荷加载率 | 1.136 GiB/s | 2.188 GiB/s |
| 进程启动到可推理 | 3.892 s | 1.772 s |
| 进程启动到首token | 3.968 s | 1.877 s |
| 首次prefill，128 tokens | 1680.1 tokens/s | 1223.6 tokens/s |
| decode，全部31步，含原生预热 | 69.3 tokens/s | 104.1 tokens/s |
| decode7–31，预热后25步 | 77.4 tokens/s | 105.8 tokens/s |
| 进程Dedicated显存采样峰值 | 6.431 GiB | 3.946 GiB |
| 进程RAM Working Set峰值 | 1.501 GiB | 4.069 GiB |

短输入控制：21-token首次prefill为286.6 / 222.4 tokens/s，预热后decode为78.1 / 106.7 tokens/s，
Dedicated显存峰值为4.327 / 3.825 GiB，RAM Working Set峰值为1.501 / 4.069 GiB。
128-token场景中，Hyle预热后decode低约26.9%，进程启动到ready耗时约2.20倍，Dedicated显存多约2.484 GiB。
这是当前配置的实际输项；首次prefill更快不能抵销加载、decode和显存问题，也不能外推长prefill或质量等价。

加载子段的前端工作不同：Hyle从原safetensors按manifest读取、分配并同步上传320个张量，
llama从单份官方converter生成的text-only/no-MTP GGUF加载，含原格式的metadata和tokenizer处理。
原text payload为3,763,655,360B，GGUF的有效text payload为3,764,747,520B（187 BF16＋133 F32无损例外）。
因此同时保留从进程启动到ready和首token的完整端点，不单用加载子段宣称等工作胜负。
Hyle的ready计入prefill/T1原冷编译；双方都不额外预跑数学。首次prefill仍包含各自原生首次执行开销。

完整step从输入准备前开始，到GPU选出的token在host可读为止，包含布局、绑定、重放准备和完成等待。
仅使用旧Hyle submit→token的seconds会漏费用，本表使用step_seconds。
原生预热没有被删除：全31步与实际decode7–31窗口分别列出；后者不是长期运行或热稳定性承诺。
llama原公开tensor_buft_overrides将默认在CPU的input embedding置于CUDA0，并与tied output共享原tensor/backing；
实际25/25层、6个KV层、18个recurrent层均CUDA0，32次GPU sampler快路，没有CPU采样fallback。
其原框架仍额外回读248320个sampled logits，费用保留；未修改上游以消除该工作。

显存采用本PID的Windows GPU Process Memory Dedicated/Shared，50ms采样，峰值为采样下界；
本机WDDM的NVML进程显存为N/A，未把整卡占用当本进程VRAM。RAM为PSAPI Working Set，含映射/共享驻留页，
不能据此推导整机物理RAM节省相同数量。PrivateUsage/PeakPagefileUsage另存为提交量，不能与GPU Shared相加当物理内存。
短场景的完整独立memory-review保留阶段前后点、时间偏差和缺样；尤其不能将释放后的最近点冒充推理驻留。

提示21→128 tokens、context容量始终256时，Hyle显存峰值增加2.104 GiB，peer仅增加0.121 GiB。
128场景每组model_loaded→ready间均有9个有效样本，ready前已观察到约6.23–6.30 GiB；
这之前尚未首次提交数学。自loaded后首样本至峰值的增长中，92.8%–95.3%已在ready前存在，
该区间包含状态初始化和prefill/T1各两个执行槽，不能把全部费用归因于某一allocator。
源码确认ggml非tiled Invocation逐非view/nonexternal tensor独立分配buffer并随槽保留，没有原生liveness复用；
这是首要调查候选，尚未逐buffer定量。显式Graph workspace增长仅约33.3 MiB，
默认GDN仅保最终状态，不是误保所有token状态。逐样本与有界静态算术见128-prefill/memory-review.json。
128场景推理期间RAM Working Set中位数为1.108 / 4.069 GiB，Private Commit为8.254 / 4.882 GiB；
因此Hyle Working Set较低不能直接解释为主机内存总体代价更低。

双方中间精度仍有差异：Hyle多处保BF16边界，peer多处为F32。短场景预测top1为30/32相同（decode23、29不同），
128-token场景为32/32；这些都不是独立质量评测或整模型精度接受。
各场景源代码、命令、逐步计时、预测IDs与进程内存样本见[性能原始记录](qwen-full-cuda-comparison.zip)，
正常64-token greedy生成也在包内，达到步数上限而非EOS。模型转换/设备/ABI身份及原始peer构建见
[llama参考准备](llama-reference-preparation.zip)；
不包含SDK、object、image或额外模型副本。原生capture观测另见
[实际trace](../../correctness/inference-foundation-review-2026-10-18/qwen-native-graph-observation.zip)。

归档后通过根目录test.ps1精确删除20个已完成实验exe/map/lib/exp及1个写错checkout位置的证据zip副本，
共664,878,137B；可复用object、SDK、原模型及单份转换GGUF保留。[清理记录](qwen-benchmark-reclaim.zip)

## 原生临时缓冲寿命复用

同日沿原Invocation将普通区域与分块attention统一到原生gallocr：冷reserve临时空间，
真实绑定后仅安装已有地址；保持常量、校验输入、输出/root、各槽所有权及退休顺序。
移除了普通区域逐张量独立分配的分支，没有新增公共选项、执行器或数学实现。
只替换一个provider宿主object，未重编native/SDK。同一128-token场景重新运行3对独立进程B/A、A/B、B/A：

| 指标 | 修改前 | 修改后 |
|---|---:|---:|
| PID Dedicated显存峰值 | 6.431 GiB | 5.312 GiB |
| 首次prefill | 1647.6 tokens/s | 1653.0 tokens/s |
| decode7–31 | 77.32 tokens/s | 77.36 tokens/s |

显存三次均减少1,201,676,288B（1.119 GiB），吞吐无明显变化。21-token单对控制为4.327→4.159 GiB。
21/128-token各32阶段的logits和最后hidden共128份向量与旧实现逐字节相同；不是新的通用质量接受。
原24层Add长链只publish最终输出，实际native retained从184降到8 MiB，旧实现明确不满足128 MiB宽限，
新实现通过且精确输出25*x、原输入不变。published view/root、旧结果、checked失败不发布、双slot换地址等4项通过；
原TypedSlice负控错误地强制prepare成功，允许它在prepare按InvalidArgument提前拒绝坏对齐后，该项单独1/1通过。
原失败日志、初版fixture及更正后记录均保留，没有把006原4/5记成全过。

该阶段仍比原llama参考峰值高约1.365 GiB；每region/shape/slot的独立原生workspace当时尚未接入共同Graph liveness，
原生首次执行、融合地址条件及其他模型功能继续审查。本次不据此宣布架构goal完成。
[源码、原始A/B、决策数据与回归](ggml-cuda-liveness.zip)另含下一步沿既有caller workspace接线的只读设计，未将设计当作已实现。
本修复归档对相同决策payload去重，保存全部逻辑文件身份；经test.ps1精确清理16个已完成image/map/lib/exp，
回收599,196,703B，保留4个新增复用object及全部源码/日志/数据/SDK。[清理记录](ggml-cuda-liveness-reclaim.zip)

## 接入共同 workspace

第二阶段沿既有ProviderPrepared.workspace与create_invocation(BufferView)接线，不增加公共API或新执行器。
冷编译用空地址的真实buffer描述测量精确chunk span，不分配device payload、不上传常量、不执行数学；
普通Invocation将原gallocr chunk映射到真实caller workspace，逐项核对size/offset，禁止容量不足时另开私有池。
返回的buffer保留canonical CUDA类型；原安全ID/常量和原生BLAS/pool/cache仍独立持有。
Graph adapter转发真实需求，由现有HB/liveness规划复用有序region的空间。Direct调用按标准requirement提供并持有workspace，
Graph消费者入口不变。显式冷constant packing仍自行持有临时空间，未把它变成普通执行的隐藏fallback。

只替换provider与Graph adapter两个宿主object，native数学、共同Graph/Compute owner及SDK均复用。
同一128-token固定输入再次按B/A、A/B、B/A运行3对独立进程，性能运行均无trace/profiler：

| 指标 | 仅区域内复用 | 接入共同workspace |
|---|---:|---:|
| PID Dedicated显存峰值 | 5.312 GiB | 3.972 GiB |
| 首次prefill | 1702.0 tokens/s | 1706.4 tokens/s |
| decode7–31 | 77.47 tokens/s | 77.95 tokens/s |
| 进程启动到ready | 3.777 s | 3.772 s |

显存三次均减少1,438,658,560B（1.340 GiB）；吞吐与启动变化不足以宣称改善。21-token单对控制为4.159→3.872 GiB。
从首轮6.431 GiB累计降至3.972 GiB，仍比原llama参考的3.946 GiB高约26 MiB；peer本阶段未重跑。
21/128-token各32阶段共128份logits/hidden向量与上一阶段逐字节相同，数学与中间精度未调整。
新两region测试中，各原生需求8 MiB，加上8 MiB边界张量后Graph总空间16 MiB，证明共用而非相加。
8个相关测试TU鲜编，唯一过滤运行10/10通过，覆盖普通attention、GDN快照重绑、checked失败不发布/重建、
abandon/close、view/root、旧结果和双slot。两次首次编译配方/警告失败及修正均保留，未重编native或SDK。
多chunk与其他模型的完整旅程仍未因此实测验收，独立shape与并发slot仍各自持有backing，decode和加载输项继续处理。
[源码、精确命令、A/B原始数据与回归](ggml-cuda-caller-workspace.zip)。
本阶段归档后经根目录test.ps1精确清理12个已完成image/map/lib/exp，回收451,978,680B；
2个产品与8个测试object、全部数据/源码/日志和SDK保留。[清理记录](ggml-cuda-caller-workspace-reclaim.zip)

后续全库调用者扫描另迁移8个测试/fixture文件中的9处Direct调用：按实际prepared operation的
workspace_requirement分配并持有所选resource的缓冲，零需求仍传空view。8个CUDA测试TU增量编译成功，
8个代表用例全部通过、无跳过，83项实际依赖复核无漂移；CPU共享fixture分支未运行，未重建native或SDK。
[迁移源码、精确命令和回归记录](ggml-cuda-workspace-consumers.zip)保留扫描边界与未修改的零需求调用者。
归档核对后经根目录test.ps1精确删除4个已完成image/map/lib/exp，回收153,514,557B，保留8个新object。
[清理记录](ggml-cuda-workspace-consumers-reclaim.zip)

同包另含冷常量打包的只读审查：在已接纳原生工作后，若checked drain与析构drain均未证明退休，
当前Status工厂仍进入原生对象和失败产物清理，违反其返回前完成准备的合同。该缺口未修复，未复现UAF；
普通free可能同步、终态设备错误及实际context销毁的情况分别记录，不能把观察错误直接当作仍有活内核。

## Decode 成本复核

较早共同workspace候选（capture复用之前）的三轮128-token历史记录中，decode7–31每步耗时中位数为12.67–12.80ms。
上传、layout更新、绑定和重放准备合计中位数0.33–0.35ms，约2.7%；submit返回前为4.37–4.58ms，
约35%，包含驱动调用和可能的阻塞，与GPU执行重叠，不能直接当作可节省的CPU费用。
此前capacity64的软件trace中，预热后每步有401次原生Graph launch；它说明提交粒度较碎，
不能代替本阶段双方GPU关键路径对照，也未定量证明BF16、转换或路由是decode差距主因。
加载消费者则逐张量读取、分配并同步上传320份权重，尚未流水化；加载与decode问题分别调查。
[历史离线重算脚本、逐步统计及旧trace结构边界](qwen-decode-cost-review.zip)。

最新同窗三对里，Hyle PreferCapture的准备为0.499–0.726ms/步，submit调用0.128–0.133ms，
返回后到完成读回11.142–11.556ms。Peer的batch准备0.14–0.19µs，decode返回0.161–0.243ms，
同步10.205–10.360ms，token访问与采样合计0.018–0.027ms。准备、submit/decode调用、等待的边界不同，
调用期间还可能与GPU交叠；不能把等待全算作GPU内核，也不能把两端分段差全算作独占CPU成本。
每对在入队API返回前的墙钟差为0.454–0.693ms，占对应完整step差的27–43%；
因此准备/入队仍是当前剩余差距的重要候选，不能用历史105.8的跨时目标排除它。

## 原生向量路由实验已撤回

同一128-token输入和31步固定decode的软件trace显示，decode7–31每步Hyle为2400个kernel、401次原生Graph launch，
peer为558个kernel、1次Graph launch；187个Hyle投影实际走cuBLAS gemvx，peer为163个ggml mmvf。
peer的24次差值集中在6144输出行的融合kernel组，但未采集逐逻辑node参数，不能据此要求消除Hyle的BF16舍入边界。
[双方原始trace、分箱和精度边界](qwen-decode-native-route.zip)保留实际记录；软件profile时长不用于公平吞吐比较。

随后仅改两个宿主owner，将187个单向量投影交给原ggml mmvf，保留公共BF16输入/输出边界，未重编native或SDK。
候选实际全部走mmvf，却每步新增374个scalar cast（两向各187），kernel增至2774、Graph launch增至569；
冷Graph步骤减少19并不代表实际提交更少。[候选唯一trace](qwen-decode-native-route-candidate.zip)保留这一反例。
独立无profile的3对B/A、A/B、B/A中，首次prefill中位数1670.7→1503.4 tokens/s，
预热后decode中位数78.042→76.090 tokens/s，显存采样峰值3.972→4.009 GiB，因此撤回默认路由修改及实验测试源码。
这没有证明新增cast是全部回退原因，也没有证明mmvf在其他装配中普遍更慢。

两个定向数学/寿命测试通过，21/128-token决策旅程预测IDs一致，但128份hidden/logits向量仅2份逐字节相同；
这些结果不构成精度、质量或完整模型接受。四个源文件的精确恢复收据、冻结before/candidate/diff、全部失败编链日志、
原始性能数据及去重后的双方决策向量见[已否定实验归档](cuda-native-matvec-rejected.zip)。

## BF16 逐算子直接承载

同日为原ggml CUDA binary/unary模板补齐同BF16输入/输出，以及广播所需的typed Repeat，
消除原先逐节点先转F32、运算后再转回BF16的临时张量。每个算子仍有自己的BF16落存边界，
BF16连续Add/Mul禁用跨节点融合以保留逐节点RNE；未改变原F32/F16与Rsqrt数学。
仅重编3个原CUDA TU和1个Hyle宿主TU，unary保持原precise参数，无整套SDK重建。
原CUDA头的C4819警告保留；初次runtime-only源码派生漏掉IQ1扩展，在编译前被拒绝，
随后使用含IQ1的完整canonical派生，未把该初版用于运行。

同一128-token＋31个固定decode输入、context容量256、两个原槽，3对无profiler独立进程按B/A、A/B、B/A运行；
两端均使用原50ms PID显存采样，表列中位数：

| 指标 | 修改前 | 修改后 |
|---|---:|---:|
| 首次prefill | 1589.1 tokens/s | 1765.1 tokens/s |
| decode7–31 | 77.32 tokens/s | 79.84 tokens/s |
| PID Dedicated显存采样峰值 | 3.972 GiB | 3.939 GiB |

首次prefill提高约11.1%，预热后decode提高约3.25%，显存三次均减少34 MiB。
加载和启动未见改善，llama参考本轮未重跑；采样峰值仍是下界。21/128-token各32阶段共128份
logits/hidden与旧caller-workspace产物逐字节相同，不构成独立质量或全平台验收。
回归有3个不同用例通过：原联合运行Direct与IQ1通过、Graph因fixture借入buffer寿命失败；
修正fixture重置顺序后，Graph单独重跑通过。初版BF16比较和Graph调用API编译失败也保留，未记作首轮全过。
[源码、派生纠正、精确构建、原始A/B与回归记录](cuda-bfloat-elementwise.zip)保存上述边界；
相同决策向量引用旧归档的精确payload哈希，scratch原始数据仍保留。

独立一次Nsight观测确认decode7–31每步实际执行BF16 Add 84、Mul 102、Sigmoid 24次，
BF16→F32 / F32→BF16转换从原801 / 427降为405 / 217；原生GraphLaunch仍为401次，187个cuBLAS投影仍在。
该trace只用于接线和调用计数，不用其时长代替上表吞吐；[完整原始trace](cuda-bfloat-elementwise-trace.zip)独立保留。

归档后通过根目录test.ps1精确清理22个已完成image/map/lib/exp与1个已撤回且未引用的实验header，共808,658,511B；保留10个新增object、8份原始Nsight/SQLite及全部决策数据、源码、SDK和模型。[清理记录](cuda-decode-investigation-reclaim.zip)

## 普通 Graph 的冷绑定与连续捕获

普通算子和区域共用原 Invocation 的冷绑定；连续合格命令可在原 segment 内一起录制，
保留不能捕获的命令及原 Completion 退休边界。ggml CUDA 复用原编码器直接录制，
不执行私有图 warmup 或嵌套 GraphLaunch；原 metadata 启用逻辑保持 Mean 的 CUB 数学选择。
10个不同用例分轮通过：2个Softplus跨provider/双槽用例、5个CPU合同控制、2个旧CUDA capture/checked控制、
1个宽度50000的Mean冷录制与逐bit对照。最初rank-2 MatMul fixture拒绝、CUB宏资格误判及旧owner链接失败均保留，
未记作首轮全过；调整过的旧TensorRegion helper本轮未另运行。

该轮完整Qwen仅运行1对功能探针：21-token prompt＋3个固定decode，Commands与PreferCapture各进程成功，
8份hidden/logits逐字节相同，实际路由分别为Commands和Hybrid。首次prefill冷准备为2.05与51.72ms，
三个decode的冷准备分别落在0.61–1.49与6.40–9.28ms。该轮每步reset/rebind会重新录制，
这不是摊销后的capture吞吐对照，不能宣称decode性能缺口已闭合，也不构成独立精度或质量验收。
[源码、失败经过、精确构建和原始结果](cuda-coarse-capture.zip)保存本轮证据；
决策向量引用既有归档中已逐SHA核实的相同payload，scratch原始数据全部保留。

根目录 test.ps1 已精确清理本轮12个 image/map/lib/exp，共402,821,651B；保留53个对象、16份原始向量，主ZIP不变。[已执行清理记录](cuda-coarse-capture-reclaim.zip)

后续已将同址录制保留在原Invocation：reset/rebind撤销执行权限，重新准备后可复用实际参数未变的录制；
配置或原生资源变化先销毁对应录制，失败也不例外。CommandCapture v2的身份能力默认未知，
由实际后端证明相同TensorView仍代表相同物理参数；不靠Provider或模型名单。ggml CUDA也复用既有指针绑定，
每次仍校验全部端口，仅省去地址未变时重复的Scope、bind与finish_bind。

CPU11与最终CUDA6共17个不同用例通过，两次初始CPU链接配方失败保留；未重编原生数学或SDK。
最终21-token prompt＋3步固定decode单对的8份hidden/logits逐字节等于旧caller归档；prefill及前两次decode各新录7段，
第三次decode新录0段、复用7段。最终同镜像128-token＋31步decode按B/A、A/B、B/A运行三对独立进程，
无profiler或显存监控；以下均按包含上传、冷准备、submit与读回的完整step计时，列三次中位数：

| 指标 | Commands | PreferCapture |
|---|---:|---:|
| 首次prefill | 1716.43 tokens/s | 1660.51 tokens/s |
| decode1–31 | 57.80 tokens/s | 74.06 tokens/s |
| decode7–31 | 62.32 tokens/s | 77.46 tokens/s |

六次定时运行的32个预测ID一致，只有上述独立功能对提供逐bit向量检查。Prefill仍有回退。
旧BF16的79.84同样按完整step的decode7–31统计；复原119个输入的旧闭包同窗控制为68.47/66.07，
该组发生最终绑定去重之前。初轮运行后观测到用户后台GPU竞争，不能据此归因各轮时长，
也不能宣称超过旧79.84或历史差异已经消除。本轮未重测llama、显存或独立质量。
[源码、17项回归、三组独立对照与原始记录](cuda-capture-reuse.zip)保留初轮、历史控制和最终结果；
32份scratch向量均核对旧ZIP的精确payload后引用，未重复复制。

根目录 test.ps1 已按两份归档及精确身份清理本轮33个文件（24个image/map/lib/exp与9个已替代对象），共878,181,587B；保留18个最终本轮对象、1个既有Direct测试对象与32份原始向量，主ZIP不变。[已执行清理记录](cuda-capture-reuse-reclaim.zip)

最新同窗按H/L、L/H、H/L完成三对无profiler、无外部显存监控的128＋31步对照：Hyle PreferCapture/peer的prefill中位1711.33/1278.20、decode1–31为78.60/93.32、decode7–31为83.36/95.16 tokens/s；32个预测ID一致。当前warm差约1.49ms/步（Hyle吞吐低12.4%），不是历史105.8对77.5的跨时差；本轮只确认完整step差距，不宣称内核主因或质量验收。

独立Nsight Systems观测确认当前每步1794/558个kernel与7/1次GraphLaunch，Hyle其中622个BF16↔F32转换；
capture已聚合提交，尚未消除数学节点。当前FFN的rank-2投影与Silu不被同一ggml region接纳，需真实融合lowering，
不能只删除支持谓词或舍去BF16中间舍入。Hyle准备约0.50–0.73ms/步仍是差距候选；软件profile时长不能加总解释未profile的1.49ms。
Nsight Compute各采同一LM-head权重形状的一颗kernel，两端DRAM吞吐约491/489GB/s、峰值占比97.55/97.04%；
该单核观测支持其已接近带宽上限，不代表全部投影或全模型。两端activation/output精度不同，缓存与时钟未锁定。

[当前同窗基线、Nsight/Ncu原始记录与融合边界](cuda-current-peer.zip)保留首次Ncu运行环境失败及peer辅助JSON被命令元数据覆盖的限制；单个LM-head计数器不是全模型性能结论，融合与cold-pack方案尚未实施。

根目录 test.ps1 已精确清理本轮6个image/map/lib/exp，共208,092,023B；保留91个对象、6份原始Nsight/SQLite/Ncu数据，主ZIP不变。[已执行清理记录](cuda-current-peer-reclaim.zip)

## 保留逐节点舍入的 BF16 连续融合

后续在原 ggml CUDA multi-Add/Mul 路径接通 BF16，2–8 个同类节点的每次结果在寄存器中执行 BF16 RNE，
检查广播、单用、发布输出与实际地址重叠，保留不合格后缀的普通执行。原 F32/F16 数学分支不变；
没有新增共同 Graph 路由或执行器。仅重编两个 CUDA TU、两个受当前头文件影响的测试 TU，复用依赖缓存。
三个定向用例通过，覆盖深度2/3/8、广播、双槽换址及发布中间值；3×17形状不覆盖unravel路径。
128-token prefill＋31步固定decode的64份hidden/logits与本轮旧实现逐字节相同，32个预测ID相同。

三对无profiler、无显存监控的独立进程按B/C、C/B、B/C执行，prefill中位1655.49→1668.36、
decode1–31为74.99→74.22、decode7–31为79.04→77.80 tokens/s。warm中位低约1.57%，
本轮未证明性能改善，也未据此归因差异。独立trace确认定向用例真实执行多源BF16 kernel；
完整Qwen没有命中该模式，每步仍有BF16 Add84、Mul102，不能把局部融合能力当作模型优化。
Nsight软件观测只用于调用计数，原driver/collector版本警告保留，不用于吞吐对照。

[实现、精确构建、原始结果及两次trace](cuda-bf16-chain-fusion.zip)记录上述边界。
首轮锁文件树哈希因排序方式错误被CMake拒绝，改为与CMake一致的排序后定向审计通过；
完整FFN等模型融合、准备成本及cold-pack来源/退休所有权缺口仍未修复。

根目录 test.ps1 已精确清理本轮12个image/map/lib/exp，共450,119,947B；保留4个新对象、
128份原始向量与两次原始trace/SQLite，主ZIP不变。[已执行清理记录](cuda-bf16-chain-fusion-reclaim.zip)

## 投影接线与输入/累加精度

尝试让ggml CUDA承接plain rank2与transpose-dense RHS后，Qwen的49个MatMul改路由：
18个in_proj_a、18个in_proj_b、6个q_proj、6个k_proj及LM head；72个FFN投影仍为cuBLAS。
公开step从1204降为1185，但初次候选warm探针仅5.66/9.15 tokens/s；紧邻旧路径为89.88。
这不是性能改善。32个预测ID相同，但64份hidden/logits均非bit-identical，最大绝对差0.25。

一次独立Nsight trace确认每步1977颗kernel（旧1794），GraphLaunch仍为7；新增98次BF16→F32原生转换。
其中一次尺寸恰好248320×2048的LM head转换，每步产生约1.89GiB F32数据；25步转换与后续F32 GEMV
占所记录kernel时长约88.2%。无GPU活动记录的空隙不足以解释主要退化；奇偶步长尾不能由此断言是纯数学或分页。

原生`GGML_PREC_F32`累加请求强制了F32 operands。修复仅限fast NVIDIA、双BF16来源、F32输出：
沿既有BF16 GEMM保留输入，仍用F32累加/输出和公开BF16 RNE；F32 strict、F16、mixed来源及ENV覆盖保持。
仅重编一份CUDA TU，产品patch与v9锁已更新；完整mixed/IQ1生成源码逐字节等于被测源码，CMake定向锁审计通过。
该候选64/64向量逐字节等于旧路径，6项定向测试通过；没有再采修复后的profile，不据此报告新kernel计数。

三对无profiler、无显存监控的新进程按B/C、C/B、B/C执行，128-token prompt、31个固定decode输入、容量256、
Direct进度与PreferCapture相同，按含prepare的完整step计时：

| 指标 | 旧路径中位数 | 扩大rank2接线＋累加修复候选中位数 |
|---|---:|---:|
| 首次prefill tokens/s | 1753.25 | 1239.61 |
| decode1–31 tokens/s | 86.35 | 81.10 |
| decode7–31 tokens/s | 91.39 | 91.03 |

warm基本持平，首次prepare/capture成本增加；未证明净收益。因此最终恢复原plain rank2准入边界，
保留native BF16输入/F32累加修复及batched transpose-dense RHS能力，不新增模型/Provider名单或修改共同Graph。
交付版本重编3个受影响host TU、6个定向用例通过；一次完整128＋31功能探针通过。
不把该单次运行当性能结论，不代表完整FFN融合、独立质量验收或其他平台/设备验证。

[候选源码、初始失败、数值/路由对照、三对实测与原始trace](cuda-dense-projection.zip)保留推进及撤回依据。
最初Graph测试误把零拷贝View计为无step、修正时误用Result为指针，以及首轮把CUDA单层manifest哈希当mixed/IQ1哈希的集成断言失败均未记作通过。
