"""Compile exactly the staged native main CUDA TU with the cached recipe."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parents[1]
ROOT = ARCH.parents[1]
PRIOR = ARCH / 'cuda-bf16-chain-fusion'
spec = importlib.util.spec_from_file_location('native_bf16_compile_helpers', PRIOR / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT

freeze = b.read(OUT / 'source-freeze.json')
source = OUT / 'ggml-cuda.cu'
assert b.ident(source) == freeze['candidate']
assert all(b.ident(r['path']) == r for r in freeze['headers'])
recipe = ARCH / 'cuda-bfloat-elementwise-build/compile-recipes.json'
original = b.read(recipe)['ggml-cuda']
args, skip = [], False
for value in original:
    if skip:
        skip = False
        continue
    if value in ('-c', '-o', '-MT', '-MF'):
        skip = True
        continue
    if value.startswith('-Xcompiler=-Fd'):
        continue
    args.append(value)
assert '-use_fast_math' in args and '-std=c++17' in args
assert '--generate-code=arch=compute_89,code=[sm_89]' in args
args += ['-MT', str(OUT / 'ggml-cuda.obj'), '-MF', str(OUT / 'ggml-cuda.d'),
         '-c', str(source), '-o', str(OUT / 'ggml-cuda.obj'),
         '-Xcompiler=-Fd' + str(OUT / 'ggml-cuda.pdb') + ',-FS']
b.save('compile-recipes.json', {'ggml-cuda': args})
result = b.execute('001-ggml-cuda-compile', args)
assert b.ident(source) == freeze['candidate']
assert all(b.ident(r['path']) == r for r in freeze['headers'])
b.save('ggml-cuda-identity.json', {
    'source': b.ident(source), 'object': b.ident(OUT / 'ggml-cuda.obj'),
    'command': args, 'compile_result': result,
    'matching_headers': freeze['headers'],
    'actual_repo_headers': [b.ident(p) for p in b.dependencies(OUT / 'ggml-cuda.d')],
    'recipe_origin': b.ident(recipe), 'helper_origin': b.ident(PRIOR / 'build.py'),
    'native_math_flags_changed': False, 'linked': False, 'GPU_execution': False,
    'SDK_rebuild': False, 'objects_copied': False,
})
print('ONE_CUDA_TU_COMPLETE', json.dumps(b.read(OUT / 'ggml-cuda-identity.json')['object']), flush=True)
