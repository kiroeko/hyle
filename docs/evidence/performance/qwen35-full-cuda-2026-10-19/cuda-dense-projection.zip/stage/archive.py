"""Preserve useful sources/results once; no builds, GPUs, SDK or model copies."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-dense-projection.zip'
sha = lambda data: hashlib.sha256(data).hexdigest()


def identity(path):
    return dict(path=str(path.relative_to(ROOT)), bytes=path.stat().st_size,
                sha256=sha(path.read_bytes()))


assert not DEST.exists(), 'Never replace a published experiment archive'
assert (STAGE / 'delivered-correctness-summary.json').is_file()
for receipt in ('delivered/tensor-identity.json', 'delivered/tensor-test-identity.json',
                'delivered/projection-test-identity.json', 'route-test-identity.json'):
    row = json.loads((STAGE / receipt).read_text())['source']
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes'] and sha(path.read_bytes()) == row['sha256']
composition = json.loads((STAGE / 'native-bf16-acc/product-composition.json').read_text())
for field in ('manifest', 'lock', 'native'):
    row = composition[field]
    path = Path(row['path'])
    assert path.stat().st_size == row['bytes'] and sha(path.read_bytes()) == row['sha256']
assert json.loads((STAGE / 'delivered/directed-tests-summary.json').read_text())['count'] == 6
allowed = {'.py', '.cc', '.cu', '.json', '.log', '.diff', '.tsv', '.xml', '.cmake', '.txt', '.nsys-rep', '.sqlite'}
excluded = {'archive-receipt.json', 'archive-inventory.json', 'cleanup-plan.json', 'cleanup-receipt.json'}
files = {}
for path in sorted(STAGE.rglob('*')):
    rel = path.relative_to(STAGE)
    if path.is_file() and path.suffix in allowed and path.name not in excluded and not {'tmp', '__pycache__'} & set(rel.parts):
        files['stage/' + rel.as_posix()] = path
sources = [
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'tests/compute_provider_ggml_cuda/tensor_test.cc',
    'tests/graph_provider_ggml_cuda/dense_projection_test.cc',
    'tests/graph_provider_ggml_cuda/CMakeLists.txt',
    'tests/graph_route_cuda/ggml_test.cc',
    'third_party/ggml_cuda_runtime/patches.json', 'cmake/HyleDependencyLock.json',
    'docs/architecture/compute-design.md', 'docs/implementation/model-operators.md',
    'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']
for name in sources:
    files['delivered-source/' + name] = ROOT / name
for name in ('fixed-inputs.json', 'decode.ids', 'inputs/prompt.ids', 'inputs/weights.tsv'):
    files['input-reference/' + name] = STAGE.parent / 'qwen-gpu-comparison/128-prefill' / name
vectors = []
for path in sorted(STAGE.rglob('*')):
    if path.is_file() and path.suffix in ('.bf16', '.f32'):
        vectors.append(identity(path))
        # Retain representative raw payloads and identities of every output.
        # All raw vectors remain in scratch; cleanup touches only linked artifacts.
        if path.parent.name in ('prefill', 'decode8', 'decode31'):
            files['stage/' + path.relative_to(STAGE).as_posix()] = path
entries = [dict(archive_path=name, **identity(path)) for name, path in sorted(files.items())]
manifest = dict(entries=entries, raw_vectors_retained_in_scratch=vectors,
    vector_payload_policy='Embed prefill/decode8/decode31; all outputs remain in scratch with SHA256 here.',
    no_model_weights=True, no_SDK_or_objects=True,
    delivery='Keep original plain rank2 boundary; retain qualified BF16-input/F32acc native correction and batched transpose-dense RHS.',
    limitation='Current selected-model/quantization/fusion review is not complete; no cross-platform or independent quality acceptance.')
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
    archive.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for row in entries:
        raw = archive.read(row['archive_path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
receipt = dict(archive=identity(DEST), payload_files=len(files), vectors=len(vectors),
    verified='CRC and every archived payload SHA256', sources=[identity(ROOT / name) for name in sources])
(STAGE / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({key: receipt[key] for key in ('archive', 'payload_files', 'vectors', 'verified')}, indent=2))
