cmake_minimum_required(VERSION 3.25)
include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)
