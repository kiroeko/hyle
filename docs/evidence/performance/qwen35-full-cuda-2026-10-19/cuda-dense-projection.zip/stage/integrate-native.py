"""Integrate the one qualified native edit and verify the full composition."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
OUT = STAGE / 'native-bf16-acc'
ROOT = STAGE.parents[2]
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
LOCK = ROOT / 'cmake/HyleDependencyLock.json'
sha = lambda data: hashlib.sha256(data).hexdigest()


def ident(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path.read_bytes()))


def backup(path, name):
    target = OUT / name
    assert not target.exists(), 'Never overwrite the original product state'
    target.write_bytes(path.read_bytes())


spec = importlib.util.spec_from_file_location('current_source_composer',
    STAGE.parent / 'generic-progress/ggml-cache/build.py')
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)
before_contents, _, before_source_id = owner.generate(False)
edit = json.loads((OUT / 'edit.json').read_text())
manifest = json.loads(MANIFEST.read_text())
entry = next(row for row in manifest['files'] if row['path'] == 'src/ggml-cuda/ggml-cuda.cu')
data = (RAW / entry['path']).read_bytes().replace(b'\r\n', b'\n')
assert sha(data) == entry['before_sha256']
for item in entry['edits']:
    old, new = item['before'].encode(), item['after'].encode()
    assert data.count(old) == 1
    data = data.replace(old, new, 1)
assert sha(data) == entry['after_sha256']
assert sha(before_contents[entry['path']]) == '4a5d1642f5e630a2d948d240d421dccbb7c2c78983230861e5ef0fd95628622b'
old, new = edit['before'].encode(), edit['after'].encode()
assert data.count(old) == 1
candidate = data.replace(old, new, 1)
backup(MANIFEST, 'patches.before.json')
backup(LOCK, 'lock.before.json')
entry['edits'].append(edit)
entry['after_sha256'] = sha(candidate)
MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
lock_text = LOCK.read_text()
dependency = next(row for row in json.loads(lock_text)['dependencies'] if row['name'] == 'ggml_cuda_runtime_patches')
vendor = ROOT / dependency['vendored']['path']
rows = []
for path in sorted(vendor.rglob('*'), key=lambda path: path.relative_to(vendor).as_posix()):
    if path.is_file():
        normalized = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
        rows.append(path.relative_to(vendor).as_posix() + '|' + sha(normalized) + '\n')
tree = sha(''.join(rows).encode())
assert lock_text.count(dependency['vendored']['tree_sha256']) == 1
assert dependency['version'].endswith('-v8')
version = dependency['version'][:-3] + '-bf16-input-acc-v9'
lock_text = lock_text.replace(dependency['vendored']['tree_sha256'], tree)
lock_text = lock_text.replace(dependency['version'], version)
LOCK.write_text(lock_text, encoding='utf-8')
contents, composed, source_id = owner.generate(False)
assert contents[entry['path']] == (OUT / 'ggml-cuda.cu').read_bytes()
assert sorted(path for path in contents if contents[path] != before_contents[path]) == [entry['path']]
receipt = dict(manifest=ident(MANIFEST), lock=ident(LOCK), native=ident(OUT / 'ggml-cuda.cu'),
    source_id=source_id, previous_source_id=before_source_id, version=version,
    locked_vendor_tree_sha256=tree, changed_native_files=[entry['path']],
    all_other_composed_files_unchanged=True, SDK_modified=False)
(OUT / 'product-composition.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
