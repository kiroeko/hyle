"""Reuse the tested CUDA closure; compile three host TUs, no native SDK."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'cuda-bf16-chain-fusion'
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('projection_helpers', PRIOR / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
sys.modules['build'] = b
spec = importlib.util.spec_from_file_location('projection_runs', PRIOR / 'run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)

SOURCES = {
    'tensor': ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc',
    'projection-test': ROOT / 'tests/graph_provider_ggml_cuda/dense_projection_test.cc',
    'tensor-test': ROOT / 'tests/compute_provider_ggml_cuda/tensor_test.cc',
    'route-test': ROOT / 'tests/graph_route_cuda/ggml_test.cc',
}
FILTER = ':'.join('GgmlCudaDenseProjection.' + name for name in (
    'DirectRank2DenseAndTransposedRhsKeepPrecisionAndSlots',
    'QwenWeightViewsKeepPublishedRoundingAndRebindBothSlots',
    'PaddedOrOtherStridedRhsAndStridedLhsStayUnsupported'))

def compile_command(name):
    if name == 'tensor':
        command = b.read(OUT.parent / 'cuda-bfloat-elementwise-build/tensor-current-identity.json')['command']
    else:
        template = 'region-test' if name in ('projection-test', 'route-test') else 'tensor-test'
        command = b.read(PRIOR / (template + '-compile.command.json'))['command']
    result = []
    skip = False
    for arg in command:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
        elif arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith('.cc'):
            continue
        else:
            result.append(arg)
    return result + ['/sourceDependencies', str(OUT / (name + '-deps.json')),
                     str(SOURCES[name]), '/Fo' + str(OUT / (name + '.obj')),
                     '/Fd' + str(OUT / (name + '.pdb'))]

def link(name, tests=False, baseline=False):
    template = 'fusion-tests' if tests else 'candidate'
    command = b.read(PRIOR / (template + '-link-plan.json'))['command']
    replacements = {} if baseline else {
        str(OUT.parent / 'cuda-bfloat-elementwise-build/tensor-current.obj'): str(OUT / 'tensor.obj')}
    if tests:
        replacements[str(PRIOR / 'tensor-test.obj')] = str(OUT / 'tensor-test.obj')
    assert all(path in command for path in replacements), 'Expected exact cached object missing'
    result = []
    for arg in command:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        result.append(replacements.get(arg, arg))
    if tests:
        result.append(str(OUT / 'projection-test.obj'))
        if (OUT / 'route-test.obj').is_file():
            result.append(str(OUT / 'route-test.obj'))
    result += ['/OUT:' + str(OUT / (name + '.exe')),
               '/MAP:' + str(OUT / (name + '.map')),
               '/IMPLIB:' + str(OUT / (name + '.lib'))]
    b.save(name + '-link-plan.json', dict(command=result))
    b.execute(name + '-link' + args.suffix, result)
    b.save(name + '-image.json', dict(image=b.ident(OUT / (name + '.exe')),
                                    link_plan=b.ident(OUT / (name + '-link-plan.json'))))

def build():
    frozen = [b.ident(path) for path in SOURCES.values()]
    b.save('build-source-freeze.json', dict(sources=frozen))
    for name in SOURCES:
        b.execute(name + '-compile', compile_command(name))
        b.save(name + '-identity.json', dict(source=b.ident(SOURCES[name]),
                                            object=b.ident(OUT / (name + '.obj'))))
    assert frozen == [b.ident(path) for path in SOURCES.values()]
    link('candidate')
    link('fusion-tests', tests=True)

def tests():
    r.image('fusion-tests')
    tag = 'directed-tests' + args.suffix
    b.execute(tag, [OUT / 'fusion-tests.exe', '--gtest_color=no',
        '--gtest_filter=' + args.filter, '--gtest_output=xml:' + str(OUT / (tag + '.xml'))])
    xml = ET.parse(OUT / (tag + '.xml')).getroot()
    cases = xml.findall('.//testcase')
    assert len(cases) == len(args.filter.split(':')) and not xml.findall('.//failure') and not xml.findall('.//skipped')
    b.save(tag + '-summary.json', dict(count=len(cases), failures=0, skipped=0,
        cases=[c.attrib['classname'] + '.' + c.attrib['name'] for c in cases]))

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['build', 'test-fix', 'route-test', 'tests', 'qwen', 'qwen-repeat', 'profile', 'export-profile', 'baseline-link', 'baseline-qwen'])
parser.add_argument('--suffix', default='')
parser.add_argument('--filter', default=FILTER)
args = parser.parse_args()
if args.mode == 'build':
    build()
elif args.mode == 'test-fix':
    assert args.suffix
    b.execute('projection-test-compile' + args.suffix, compile_command('projection-test'))
    b.save('projection-test-identity.json', dict(source=b.ident(SOURCES['projection-test']),
        object=b.ident(OUT / 'projection-test.obj')))
    link('fusion-tests', tests=True)
elif args.mode == 'route-test':
    b.execute('route-test-compile', compile_command('route-test'))
    b.save('route-test-identity.json', dict(source=b.ident(SOURCES['route-test']),
        object=b.ident(OUT / 'route-test.obj')))
    link('fusion-tests', tests=True)
elif args.mode == 'tests':
    tests()
elif args.mode == 'qwen':
    r.trial('qwen-candidate', 'candidate', trace=True)
elif args.mode == 'qwen-repeat':
    r.trial('qwen-candidate-repeat', 'candidate', trace=False)
elif args.mode in ('profile', 'export-profile'):
    nsys = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
    if args.mode == 'profile':
        actual = r.image('candidate')
        target = b.read(OUT / 'qwen-candidate-repeat.command.json')['command']
        assert target[0] == actual['path'] and '--trace' not in target
        b.save('profile-inputs.json', dict(image=actual, profiler=b.ident(nsys),
            target=target, purpose='Diagnose the newly observed regression; profiled timing is not fair throughput.'))
        b.execute('profile', [nsys, 'profile', '--trace=cuda', '--sample=none',
            '--cpuctxsw=none', '--cuda-graph-trace=node:host-only',
            '--discard-environment=true', '--output=' + str(OUT / 'projection-trace'), *target])
    else:
        b.execute('export-profile', [nsys, 'export', '--type=sqlite',
            '--output=' + str(OUT / 'projection-trace.sqlite'), OUT / 'projection-trace.nsys-rep'])
elif args.mode == 'baseline-link':
    link('baseline', baseline=True)
else:
    r.trial('qwen-baseline', 'baseline', trace=True)
