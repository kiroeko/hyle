"""One corrected native member and cached host closure; explicit bounded runs."""
from pathlib import Path
import argparse
import importlib.util
import json
import statistics
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
DELIVERED = '--delivered' in sys.argv
OUT = STAGE / ('delivered' if DELIVERED else 'native-bf16-acc')
OUT.mkdir(exist_ok=True)
ROOT = STAGE.parents[2]
PRIOR = STAGE.parent / 'cuda-bf16-chain-fusion'
spec = importlib.util.spec_from_file_location('projection_final_helpers', PRIOR / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
sys.modules['build'] = b
spec = importlib.util.spec_from_file_location('projection_final_runs', PRIOR / 'run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
FILTER = ':'.join([
    'GgmlCudaDenseProjection.' + ('DirectBatchedDenseAndTransposedRhsKeepPrecisionAndSlots' if DELIVERED
                                else 'DirectRank2DenseAndTransposedRhsKeepPrecisionAndSlots'),
    'GgmlCudaDenseProjection.' + ('BatchedWeightViewsKeepPublishedRoundingAndRebindBothSlots' if DELIVERED
                                else 'QwenWeightViewsKeepPublishedRoundingAndRebindBothSlots'),
    'GgmlCudaDenseProjection.PaddedOrOtherStridedRhsAndStridedLhsStayUnsupported',
    'CudaDefaultGraph.RequiredCublasProjectionComposesWithGgmlRegion',
    'CudaDefaultGraph.RequiredUnrelatedCublasNodeDoesNotSplitGgmlRegion',
    'GgmlCudaTensor.BatchedF32MatMulRebindsIndependentSlotsWithoutNarrowing'])


def link(name, template, native):
    command = b.read(STAGE / (template + '-link-plan.json'))['command']
    old = str(PRIOR / 'ggml-cuda.obj')
    new = str(STAGE / 'native-bf16-acc/ggml-cuda.obj')
    if native:
        assert command.count(old) == 1 and Path(new).is_file()
        command = [new if arg == old else arg for arg in command]
        if DELIVERED:
            replacements = {str(STAGE / (tag + '.obj')): str(OUT / (tag + '.obj'))
                for tag in ('tensor', 'projection-test', 'tensor-test')}
            command = [replacements.get(arg, arg) for arg in command]
    command = [arg for arg in command if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(OUT / (name + '.exe')),
                '/MAP:' + str(OUT / (name + '.map')),
                '/IMPLIB:' + str(OUT / (name + '.lib'))]
    inputs = [b.ident(arg) for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
    b.save(name + '-link-plan.json', dict(command=command, inputs=inputs,
        SDK_rebuild=False, object_copy=False, native_replacement=native))
    b.execute(name + '-link', command)
    b.save(name + '-image.json', dict(image=b.ident(OUT / (name + '.exe')),
        link_plan=b.ident(OUT / (name + '-link-plan.json'))))
    map_text = (OUT / (name + '.map')).read_text(errors='replace')
    assert not any('ggml-cuda.lib:' in line.lower() and 'ggml-cuda.cu.obj' in line.lower()
                   for line in map_text.splitlines()), 'Unexpected old CUDA member'


def tests():
    r.image('fusion-tests')
    b.execute('directed-tests', [OUT / 'fusion-tests.exe', '--gtest_color=no',
        '--gtest_filter=' + FILTER, '--gtest_output=xml:' + str(OUT / 'directed-tests.xml')])
    xml = ET.parse(OUT / 'directed-tests.xml').getroot()
    cases = xml.findall('.//testcase')
    assert len(cases) == 6 and not xml.findall('.//failure') and not xml.findall('.//skipped')
    b.save('directed-tests-summary.json', dict(count=6, failures=0, skipped=0,
        cases=[c.attrib['classname'] + '.' + c.attrib['name'] for c in cases]))


def performance():
    expected = b.read(STAGE / 'qwen-baseline-metrics.json')['ids']
    order = ('baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate')
    runs = []
    b.save('performance-plan.json', dict(order=list(order), prompt=128, fixed_decode=31,
        full_step=True, profiler=False, memory_monitor=False,
        baseline='Before rank-two admission, previous BF16-chain native object',
        candidate='Rank-two admission plus qualified BF16 input/F32 accumulator native path'))
    for index, arm in enumerate(order, 1):
        row = r.trial(f'perf-{index:02d}-{arm}', arm)
        assert row['ids'] == expected
        runs.append(row)
        b.save('performance-results.json', dict(runs=runs, remaining=len(order)-len(runs)))
    keys = ('prefill_tokens_per_second', 'full31_tokens_per_second', 'warm7_31_tokens_per_second')
    groups = {arm: {key: dict(samples=[row[key] for row in runs if row['arm'] == arm],
        median=statistics.median(row[key] for row in runs if row['arm'] == arm)) for key in keys}
        for arm in ('baseline', 'candidate')}
    b.save('performance-summary.json', dict(groups=groups,
        ratios={key: groups['candidate'][key]['median']/groups['baseline'][key]['median'] for key in keys},
        ids_equal=True, statistical_significance=False, quality_acceptance=False))
    print(json.dumps(groups), flush=True)


parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['compile', 'link', 'tests', 'qwen', 'performance', 'profile', 'export'])
parser.add_argument('--delivered', action='store_true')
args = parser.parse_args()
if args.mode == 'compile':
    assert DELIVERED
    sources = dict(tensor=ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc',
        **{'projection-test': ROOT / 'tests/graph_provider_ggml_cuda/dense_projection_test.cc',
           'tensor-test': ROOT / 'tests/compute_provider_ggml_cuda/tensor_test.cc'})
    b.save('source-freeze.json', dict(sources=[b.ident(path) for path in sources.values()]))
    for tag, source in sources.items():
        command = b.read(STAGE / (tag + '-compile.command.json'))['command']
        replacements = {str(STAGE / (tag + suffix)): str(OUT / (tag + suffix))
            for suffix in ('.obj', '.pdb', '-deps.json')}
        command = [('/Fo' + str(OUT / (tag + '.obj')) if arg.lower().startswith('/fo') else
                    '/Fd' + str(OUT / (tag + '.pdb')) if arg.lower().startswith('/fd') else
                    replacements.get(arg, arg)) for arg in command]
        b.execute(tag + '-compile', command)
        b.save(tag + '-identity.json', dict(source=b.ident(source), object=b.ident(OUT / (tag + '.obj'))))
elif args.mode == 'link':
    link('candidate', 'candidate', True)
    link('fusion-tests', 'fusion-tests', True)
    link('baseline', 'baseline', False)
elif args.mode == 'tests':
    tests()
elif args.mode == 'qwen':
    r.trial('correctness-candidate', 'candidate', trace=True)
elif args.mode == 'performance':
    performance()
elif args.mode == 'profile':
    actual = r.image('candidate')
    target = b.read(OUT / 'perf-02-candidate.command.json')['command']
    assert target[0] == actual['path'] and '--trace' not in target
    b.save('profile-inputs.json', dict(image=actual, profiler=b.ident(NSYS), target=target,
        purpose='Verify physical removal of per-step BF16 head widening; not throughput.'))
    b.execute('profile', [NSYS, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
        '--cuda-graph-trace=node:host-only', '--discard-environment=true',
        '--output=' + str(OUT / 'corrected-trace'), *target])
else:
    b.execute('export', [NSYS, 'export', '--type=sqlite',
        '--output=' + str(OUT / 'corrected-trace.sqlite'), OUT / 'corrected-trace.nsys-rep'])
