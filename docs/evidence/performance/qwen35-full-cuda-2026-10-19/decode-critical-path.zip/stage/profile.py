"""Exactly one complete CUDA/API trace per retained production consumer, then offline exports."""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('critical_path_cached_helpers', ARCH / 'cuda-grouped-fusion/build.py')
b, c = build.b, build.c
FORBIDDEN = ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION', 'GGML_CUDA_GRAPH_OPT',
             'HYLE_RMS_DIAG', 'HYLE_GDN_L2_DIAG')


def prepare():
    destination = STAGE / 'plan.json'
    if destination.exists():
        raise ValueError('Refuse to overwrite collection plan')
    retained = c.read(ARCH / 'batch-layout-query-reuse/performance-prepared/plan.json')
    original = c.read(ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    nsys = original[0]
    links = {
        'hyle': ARCH / 'cuda-grouped-fusion/checks/20261019T123025/qwen-link-plan.json',
        'peer': ARCH / 'cuda-bf16-dual-projection/metadata-fix/performance-prepared/peer-link-plan.json',
    }
    receipts = {
        'hyle': ARCH / 'cuda-grouped-fusion/checks/20261019T123025/qwen-image.json',
        'peer': ARCH / 'cuda-explicit-rope/performance-prepared/peer-image.json',
    }
    arms = {}
    for arm, request_arm in (('hyle', 'current'), ('peer', 'llama')):
        out = STAGE / arm
        out.mkdir(exist_ok=False)
        (out / 'tmp').mkdir()
        request = next(row for row in retained['requests'] if row['arm'] == request_arm)
        command = [arg.replace('{output}', str(out)) for arg in request['command']]
        image = c.read(receipts[arm])
        if b.identity(Path(image['path'])) != image:
            raise ValueError('Retained image identity differs: ' + arm)
        command[0] = image['path']
        if arm == 'peer':
            command[-1] = str(out / 'peer-result.json')
        stem = out / 'decode'
        profile = [nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                   '--cuda-graph-trace=node:host-only', '--discard-environment=true',
                   '--output=' + str(stem), *command]
        arms[arm] = {'image': image, 'link_plan': b.identity(links[arm]), 'consumer_command': command,
            'commands': {
                'profile': profile,
                'export': [nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
                'stats': [nsys, 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,cuda_gpu_mem_size_sum',
                          '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'],
            }}
    facts = {
        'nvidia-smi': ['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,power.limit,compute_cap', '--format=csv,noheader'],
        'nsys-version': [nsys, '--version'],
    }
    for tag, command in facts.items():
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
        c.save(STAGE / (tag + '.json'), {'command': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        if result.returncode:
            raise ValueError(tag + ' unavailable')
    inputs = ARCH / 'qwen-gpu-comparison/128-prefill'
    c.save(destination, {'status': 'prepared_no_GPU', 'runner': b.identity(Path(__file__)),
        'retained_input_plan': b.identity(ARCH / 'batch-layout-query-reuse/performance-prepared/plan.json'),
        'fixed': retained['fixed'], 'metric_contract': retained['metric_contract'],
        'input_identities': [b.identity(inputs / name) for name in ('fixed-inputs.json', 'decode.ids', 'inputs/prompt.ids')],
        'arms': arms, 'GPU_trace_collections_planned': 2, 'throughput_claim': False,
        'tensor_dumps': False, 'compilations': 0, 'links': 0,
        'boundary': 'Production consumer startup,128-token prefill and31 fixed decode inputs; warm decode7..31 only after observed token-copy audit. Host CUDA APIs and CUDA graph-node tracing; no invented profiler markers.',
        'limits': ['Profiler durations diagnose this trace only, not unprofiled throughput.',
                   'CPU prepare/bind internal subfunctions have no markers; report source-defined aggregate consumer timers and observable API gaps without assigning unmarked CPU samples.',
                   'Same model source and input IDs do not imply identical intermediate precision, weight packing or engine work.']})
    print('PREPARED', destination, flush=True)


def run():
    plan = c.read(STAGE / 'plan.json')
    for row in plan['input_identities']:
        if b.identity(Path(row['path'])) != row:
            raise ValueError('Fixed input drift')
    terminal = []
    for arm, row in plan['arms'].items():
        out = STAGE / arm
        if (out / 'profile.result.json').exists() or (out / 'profile.command.json').exists():
            raise ValueError('No implicit trace retry: ' + arm)
        if b.identity(Path(row['image']['path'])) != row['image']:
            raise ValueError('Image drift')
        if b.identity(Path(row['link_plan']['path'])) != row['link_plan']:
            raise ValueError('Link recipe drift')
        link = c.read(Path(row['link_plan']['path']))
        paths = [entry['path'] if isinstance(entry, dict) else entry for entry in link['inputs']]
        env, runtime = b.environment(link['command'], paths, out)
        if any(key in env for key in FORBIDDEN):
            raise ValueError('Non-production graph/diagnostic override present')
        c.save(out / 'runtime.json', {'library_directories_from_own_link_inputs': runtime,
            'link_inputs_count': len(paths), 'peer_hyle_DLL_union_used': False,
            'PATH': env.get('PATH', ''), 'TEMP': env['TEMP'],
            'forbidden_overrides_absent': list(FORBIDDEN)})
        for tag, command in row['commands'].items():
            c.execute(tag, command, env, out)
        terminal.append(arm)
        c.save(STAGE / 'collection-summary.json', {'terminal_zero_arms': terminal, 'trace_collections': len(terminal),
            'throughput_claim': False, 'status': 'complete' if len(terminal) == 2 else 'incomplete'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    run() if args.run else prepare()
