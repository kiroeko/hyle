"""Offline timing attribution from retained official CUDA trace exports, never throughput."""
from pathlib import Path
import bisect
import collections
import csv
import importlib.util
import json
import re
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('critical_path_physical_helpers', ARCH / 'cuda-stable-silu/profile-analysis-stable.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def dist(values):
    values = list(values)
    return {'samples': values, 'mean': statistics.mean(values), 'median': statistics.median(values),
            'min': min(values), 'max': max(values)} if values else None


def merged(intervals):
    out = []
    for start, end in sorted(intervals):
        if not out or start > out[-1][1]:
            out.append([start, end])
        else:
            out[-1][1] = max(out[-1][1], end)
    return out


def union(intervals):
    return sum(end - start for start, end in merged(intervals))


def overlap(intervals, windows):
    return union((max(start, lo), min(end, hi)) for start, end in intervals for lo, hi in windows
                 if max(start, lo) < min(end, hi))


def weight_inventory():
    path = ARCH / 'qwen-gpu-comparison/128-prefill/inputs/weights.tsv'
    weights = {}
    for line in path.read_text().splitlines()[3:]:
        fields = line.split()
        name, dtype, rank = fields[:3]
        rank = int(rank)
        weights[name.removeprefix('model.language_model.')] = {
            'name': name, 'dtype': dtype, 'shape': list(map(int, fields[3:3 + rank])),
            'bytes': int(fields[-1])}
    return path, weights


def expected_projection_order(weights, arm):
    roles = []
    for layer in range(24):
        prefix = 'layers.' + str(layer) + '.'
        if layer % 4 != 3:
            items = [('GDN_qkv_projection', ['linear_attn.in_proj_qkv.weight']),
                     ('GDN_a_or_b_projection', ['linear_attn.in_proj_a.weight']),
                     ('GDN_a_or_b_projection', ['linear_attn.in_proj_b.weight']),
                     ('GDN_z_projection', ['linear_attn.in_proj_z.weight']),
                     ('GDN_output_projection', ['linear_attn.out_proj.weight'])]
            grids = [1536, 4, 4, 512, 512] if arm == 'hyle' else [6144, 16, 16, 2048, 2048]
        else:
            items = [('dense_attention_Q_projection', ['self_attn.q_proj.weight']),
                     ('dense_attention_K_or_V_projection', ['self_attn.k_proj.weight']),
                     ('dense_attention_K_or_V_projection', ['self_attn.v_proj.weight']),
                     ('dense_attention_output_projection', ['self_attn.o_proj.weight'])]
            grids = [1024, 128, 128, 512] if arm == 'hyle' else [4096, 512, 512, 2048]
        items += [('FFN_gate_up_dual_projection', ['mlp.gate_proj.weight', 'mlp.up_proj.weight']),
                  ('FFN_down_projection', ['mlp.down_proj.weight'])]
        grids += [6144, 512 if arm == 'hyle' else 2048]
        for (role, names), grid in zip(items, grids):
            source = [weights[prefix + name] for name in names]
            roles.append({'role': role, 'layer': layer, 'weights': source,
                          'logical_weight_bytes': sum(row['bytes'] for row in source),
                          'expected_grid': [grid, 1, 1],
                          'family': 'GGML_MMVF_dual' if role == 'FFN_gate_up_dual_projection' else
                                    ('cuBLAS_BF16_GEMV' if arm == 'hyle' else 'GGML_MMVF')})
    roles.append({'role': 'LM_head', 'layer': None, 'weights': [weights['embed_tokens.weight']],
                  'logical_weight_bytes': weights['embed_tokens.weight']['bytes'],
                  'expected_grid': [62080 if arm == 'hyle' else 248320, 1, 1],
                  'family': 'cuBLAS_BF16_GEMV' if arm == 'hyle' else 'GGML_MMVF'})
    return roles


def projection(name):
    return 'internal::gemvx::kernel<' in name or 'mul_mat_vec_f<' in name


def category(name):
    if projection(name):
        return 'projection_MM'
    if 'gated_delta_net_cuda<' in name:
        return 'GDN_core_only'
    if 'ssm_conv_f32<' in name:
        return 'causal_conv_core'
    if 'hyle_bf16_l2_core<' in name:
        return 'GDN_L2_core'
    if 'flashinfer::' in name or 'flash_attn_ext_vec<' in name:
        return 'dense_attention_core_and_merge'
    if 'cpy_scalar_contiguous<' in name:
        return 'BF16_F32_cast' if ('<__nv_bfloat16, float>' in name or '<float, __nv_bfloat16>' in name) else 'other_contiguous_copy'
    if 'cpy_scalar' in name:
        return 'layout_or_copy'
    if 'k_set_rows<' in name or '::single_update<' in name:
        return 'KV_cache_write'
    if 'rope_multi<' in name or 'hyle_explicit_rope<' in name:
        return 'RoPE'
    if 'rms_norm_f32<' in name:
        return 'normalization'
    if ('ArgPair<float>' in name or 'ArgValue<float>' in name or 'ArgIndex<float>' in name or 'argmax_f32' in name):
        return 'sampling_argmax'
    if 'GatherOutput<' in name or 'k_get_rows' in name:
        return 'gather_or_state_selection'
    return 'other_elementwise_or_concat'


def analyze_arm(arm, weights):
    out = STAGE / arm
    stem = out / 'decode'
    data = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'))
    con = sqlite3.connect(Path(str(stem) + '.sqlite').resolve().as_uri() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
    strings = dict(con.execute('select id,value from StringIds'))
    apis = [dict(row, name=strings[row['nameId']]) for row in con.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start')]
    diagnostics = [dict(row) for row in con.execute('select * from DIAGNOSTIC_EVENT')]
    for row in con.execute('select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
        if '/streams/' in row['filename'].replace('\\', '/'):
            kind = 'stderr' if 'stderr_' in row['filename'] else 'stdout'
            (out / ('target.' + kind + '.log')).write_text(row['value'], encoding='utf-8')
    memsets = [dict(row) for row in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMSET order by start')] if 'CUPTI_ACTIVITY_KIND_MEMSET' in tables else []
    con.close()
    token = sorted((row for row in data['copies'] if row['copyKind'] == 2 and row['bytes'] == 4), key=lambda r: r['end'])
    assert len(token) == 32 and len({row['end'] for row in token}) == 32
    logits = sorted((row for row in data['copies'] if row['copyKind'] == 2 and row['bytes'] == 248320 * 4), key=lambda r: r['end'])
    if arm == 'peer':
        assert len(logits) == 32
        assert all(t['end'] < l['start'] and (i == 31 or l['end'] < token[i + 1]['start']) for i, (t, l) in enumerate(zip(token, logits)))
        assert all(not any(t['end'] < k['start'] <= l['end'] for k in data['kernels']) for t, l in zip(token, logits))
    else:
        assert not logits
    endpoints = [row['end'] for row in (logits if arm == 'peer' else token)]
    phases, mapped, idle_intervals, execution_segments = [], [], [], []
    role_plan = expected_projection_order(weights, arm)
    symbol_samples = collections.defaultdict(lambda: [0] * 25)
    geometry_samples = collections.defaultdict(list)
    role_samples = collections.defaultdict(lambda: [0] * 25)
    category_samples = collections.defaultdict(lambda: {'duration_ns': [0] * 25, 'count': [0] * 25})
    api_samples = collections.defaultdict(lambda: {'duration_ns': [0] * 25, 'count': [0] * 25})
    for phase in range(32):
        lo, hi = endpoints[phase - 1] if phase else 0, endpoints[phase]
        kernels = [row for row in data['kernels'] if lo < row['start'] <= hi]
        assert not any(row['end'] > hi for row in kernels)
        copies = [row for row in data['copies'] if lo < row['start'] <= hi]
        sets = [row for row in memsets if lo < row['start'] <= hi]
        calls = [row for row in apis if lo < row['start'] <= hi]
        projections = [row for row in kernels if projection(row['name'])]
        if phase >= 1:
            assert len(projections) == len(role_plan) == 163, (arm, phase, len(projections))
            for ordinal, (kernel, role) in enumerate(zip(projections, role_plan)):
                assert [kernel[key] for key in ('gridX', 'gridY', 'gridZ')] == role['expected_grid'], (arm, phase, ordinal)
                if arm == 'hyle':
                    assert ('hyle_bf16_dual_matvec_silu_epilogue' in kernel['name']) == (role['role'] == 'FFN_gate_up_dual_projection')
                if phase >= 7:
                    role_samples[role['role']][phase - 7] += kernel['end'] - kernel['start']
                    geometry_samples[(role['role'], kernel['name'], tuple(role['expected_grid']))].append(kernel['end'] - kernel['start'])
            if phase == 7:
                mapped = [dict(role, symbol=kernel['name'], block=[kernel[key] for key in ('blockX', 'blockY', 'blockZ')],
                               kernel_ordinal=kernels.index(kernel)) for kernel, role in zip(projections, role_plan)]
                for ordinal, kernel in enumerate(kernels):
                    tag = ('graph', kernel['graphId']) if kernel['graphNodeId'] else ('eager', category(kernel['name']))
                    if not execution_segments or execution_segments[-1]['tag'] != list(tag):
                        previous = execution_segments[-1]['end_ns'] if execution_segments else lo
                        execution_segments.append({'tag': list(tag), 'first_kernel_ordinal': ordinal,
                            'start_ns': kernel['start'], 'end_ns': kernel['end'], 'kernel_count': 0,
                            'kernel_duration_sum_ns': 0, 'gap_from_previous_segment_ns': kernel['start'] - previous})
                    segment = execution_segments[-1]
                    segment['end_ns'] = max(segment['end_ns'], kernel['end'])
                    segment['last_kernel_ordinal'] = ordinal
                    segment['kernel_count'] += 1
                    segment['kernel_duration_sum_ns'] += kernel['end'] - kernel['start']
        intervals = [(row['start'], row['end']) for row in kernels + copies + sets]
        busy = merged(intervals)
        idle = []
        cursor = lo
        for begin, end in busy:
            if cursor < begin:
                idle.append([cursor, begin])
            cursor = max(cursor, end)
        if cursor < hi:
            idle.append([cursor, hi])
        launch = [row for row in calls if 'GraphLaunch' in row['name']]
        first_kernel = min((row['start'] for row in kernels), default=hi)
        last_kernel = max((row['end'] for row in kernels), default=lo)
        internal_idle = [(max(begin, first_kernel), min(end, last_kernel)) for begin, end in idle
                         if max(begin, first_kernel) < min(end, last_kernel)]
        row = {'phase': phase, 'label': 'prefill' if not phase else 'decode' + str(phase),
            'previous_endpoint_ns': lo, 'endpoint_ns': hi, 'endpoint_interval_ns': hi - lo,
            'kernel_count': len(kernels), 'graph_node_kernel_count': sum(bool(k['graphNodeId']) for k in kernels),
            'GraphLaunch_count': len(launch), 'kernel_duration_sum_ns': sum(k['end'] - k['start'] for k in kernels),
            'kernel_union_busy_ns': union((k['start'], k['end']) for k in kernels),
            'copy_duration_sum_ns': sum(k['end'] - k['start'] for k in copies),
            'all_device_activity_union_ns': union(intervals), 'no_traced_device_activity_ns': hi - lo - union(intervals),
            'pre_first_kernel_ns': first_kernel - lo, 'after_last_kernel_ns': hi - last_kernel,
            'internal_no_device_activity_ns': union(internal_idle),
            'GraphLaunch_API_sum_ns': sum(k['end'] - k['start'] for k in launch),
            'GraphLaunch_API_overlap_device_idle_ns': overlap([(k['start'], k['end']) for k in launch], idle),
            'D2D_copy_bytes': sum(k['bytes'] for k in copies if k['copyKind'] == 8),
            'D2D_copy_count': sum(k['copyKind'] == 8 for k in copies),
            'D2D_copy_duration_ns': sum(k['end'] - k['start'] for k in copies if k['copyKind'] == 8),
            'D2H_copy_bytes': sum(k['bytes'] for k in copies if k['copyKind'] == 2),
            'copy_counts': dict(collections.Counter(str(k['copyKind']) + ':' + str(k['bytes']) for k in copies))}
        phases.append(row)
        if phase >= 7:
            index = phase - 7
            for kernel in kernels:
                duration = kernel['end'] - kernel['start']
                symbol_samples[kernel['name']][index] += duration
                cat = category(kernel['name'])
                category_samples[cat]['duration_ns'][index] += duration
                category_samples[cat]['count'][index] += 1
            for call in calls:
                api_samples[call['name']]['duration_ns'][index] += call['end'] - call['start']
                api_samples[call['name']]['count'][index] += 1
            for begin, end in idle:
                idle_intervals.append({'phase': phase, 'start': begin, 'end': end, 'duration_ns': end - begin,
                    'location': 'before_first_kernel' if end <= first_kernel else 'after_last_kernel' if begin >= last_kernel else 'internal',
                    'overlapping_GraphLaunch_API': [dict(k) for k in launch if k['start'] < end and begin < k['end']]})
    warm = phases[7:]
    roles = []
    for name, samples in role_samples.items():
        one = [row for row in role_plan if row['role'] == name]
        byte_count = sum(row['logical_weight_bytes'] for row in one)
        timing = dist(samples)
        roles.append({'role': name, 'count_per_decode': len(one), 'logical_weight_bytes_per_decode': byte_count,
            'weight_dtypes': sorted({w['dtype'] for row in one for w in row['weights']}),
            'duration_ns_per_decode': timing,
            'normalized_logical_weight_GB_per_second_from_trace_mean': byte_count / timing['mean'],
            'normalized_logical_weight_GB_per_second_from_trace_median': byte_count / timing['median'],
            'activation_storage_dtype': 'BF16' if arm == 'hyle' else 'F32',
            'output_storage_dtype': 'BF16' if arm == 'hyle' else 'F32', 'accumulation_dtype': 'F32',
            'logical_read_scope': 'One logical read of each selected matrix per fixed single-token decode; not measured DRAM traffic, cache misses or a throughput benchmark.'})
    symbols = [{'symbol': name, 'duration_ns_per_warm_step': dist(samples)} for name, samples in symbol_samples.items()]
    symbols.sort(key=lambda row: row['duration_ns_per_warm_step']['mean'], reverse=True)
    categories = {name: {key: dist(values) for key, values in row.items()} for name, row in category_samples.items()}
    api_stats = {name: {key: dist(values) for key, values in row.items()} for name, row in api_samples.items()}
    scalar_keys = ['endpoint_interval_ns', 'kernel_count', 'graph_node_kernel_count', 'GraphLaunch_count',
        'kernel_duration_sum_ns', 'kernel_union_busy_ns', 'copy_duration_sum_ns', 'all_device_activity_union_ns',
        'no_traced_device_activity_ns', 'pre_first_kernel_ns', 'after_last_kernel_ns', 'internal_no_device_activity_ns',
        'GraphLaunch_API_sum_ns', 'GraphLaunch_API_overlap_device_idle_ns', 'D2D_copy_bytes',
        'D2D_copy_count', 'D2D_copy_duration_ns', 'D2H_copy_bytes']
    timers = {}
    if arm == 'hyle':
        text = (out / 'target.stderr.log').read_text(encoding='utf-8')
        prepared = re.findall(r'prepared T=(\d+) visible=(\d+).*?cold_batch_seconds=(\S+).*?capture_recorded=(\d+) capture_reused=(\d+)', text)
        steps = re.findall(r'^(prefill|decode\d+) tokens=\d+ visible=\d+ seconds=(\S+) submit_seconds=(\S+) step_seconds=(\S+)', text, re.M)
        assert len(prepared) == len(steps) == 32
        timers = {'cold_batch_seconds': dist(float(x[2]) for x in prepared[7:]),
            'submit_seconds': dist(float(x[2]) for x in steps[7:]),
            'submit_through_host_token_seconds': dist(float(x[1]) for x in steps[7:]),
            'step_input_prepare_through_host_token_seconds': dist(float(x[3]) for x in steps[7:]),
            'warm_capture_counts': [{'recorded': int(x[3]), 'reused': int(x[4])} for x in prepared[7:]],
            'source_contract': 'tools/qwen35_text/main.cc:490-559; cold_batch includes layout version, six batch prepares, binds and prepare_replay. Submit is separate; all are profiled process wall timers and overlap GPU work/waits. No exact bind-only marker exists.'}
    else:
        result = a.read(out / 'peer-result.json')
        assert len(result['phases']) == 32
        timers = {key: dist(row[key] for row in result['phases'][7:]) for key in result['phases'][7] if key.endswith('_seconds')}
    assert data['receipt']['csv_sqlite_per_symbol_counts_equal']
    assert not data['receipt']['graph_api_failures']
    failures = [row for row in apis if row['returnValue'] != 0]
    report = {'arm': arm, 'receipt': data['receipt'], 'runtime_nonzero_returns': failures,
        'endpoint_audit': {'token4B_copies': len(token), 'sampled_logit993280B_copies': len(logits),
            'endpoint_choice': 'Final sampled-logit copy completion' if arm == 'peer' else 'Token4B copy completion',
            'no_kernels_between_token_and_logits_endpoints': True if arm == 'peer' else None,
            'scope': 'Endpoint intervals include inter-step CPU/reporting and next-step preparation; not the consumer step stopwatch or an unprofiled latency measurement.'},
        'phases': phases, 'warm_decode7_31': {key: dist(row[key] for row in warm) for key in scalar_keys},
        'categories': categories, 'projection_roles': sorted(roles, key=lambda row: row['duration_ns_per_decode']['mean'], reverse=True),
        'projection_mapping_decode7': mapped, 'top_kernel_symbols': symbols,
        'execution_segments_decode7': execution_segments,
        'API_wall_time': api_stats, 'profiled_consumer_timers': timers,
        'diagnostics': diagnostics, 'warnings': [r for r in diagnostics if r['severity'] >= 2],
        'longest_idle_intervals': sorted(idle_intervals, key=lambda row: row['duration_ns'], reverse=True)[:50],
        'per_role_kernel_geometry': [{'role': key[0], 'symbol': key[1], 'grid': list(key[2]), 'individual_duration_ns': dist(values)}
                                    for key, values in geometry_samples.items()],
        'throughput_claim': False, 'independent_quality_acceptance': False}
    a.save(out / 'analysis.json', report)
    return report


def main():
    inventory, weights = weight_inventory()
    reports = {arm: analyze_arm(arm, weights) for arm in ('hyle', 'peer')}
    role_comparison = []
    h = {row['role']: row for row in reports['hyle']['projection_roles']}
    p = {row['role']: row for row in reports['peer']['projection_roles']}
    assert h.keys() == p.keys()
    for name in h:
        assert h[name]['logical_weight_bytes_per_decode'] == p[name]['logical_weight_bytes_per_decode']
        role_comparison.append({'role': name, 'logical_weight_bytes_per_decode': h[name]['logical_weight_bytes_per_decode'],
            'count_per_decode': h[name]['count_per_decode'], 'weight_dtype_both': 'BF16',
            'hyle_activation_and_output_dtype': 'BF16', 'peer_activation_and_output_dtype': 'F32',
            'accumulation_dtype_both': 'F32',
            'hyle_mean_us': h[name]['duration_ns_per_decode']['mean'] / 1000,
            'peer_mean_us': p[name]['duration_ns_per_decode']['mean'] / 1000,
            'hyle_median_us': h[name]['duration_ns_per_decode']['median'] / 1000,
            'peer_median_us': p[name]['duration_ns_per_decode']['median'] / 1000,
            'mean_difference_us': (h[name]['duration_ns_per_decode']['mean'] - p[name]['duration_ns_per_decode']['mean']) / 1000})
    plan = a.read(STAGE / 'plan.json')
    peer = a.read(STAGE / 'peer/peer-result.json')
    hyle = json.loads((STAGE / 'hyle/target.stdout.log').read_text().splitlines()[-1])
    assert peer['prompt_ids'] == plan['fixed']['prompt_ids']
    assert peer['decode_input_ids'] == hyle['decode_input_ids'] == plan['fixed']['decode_input_ids']
    assert len(peer['phases']) == len(peer['predicted_ids']) == len(hyle['generated_ids']) == 32
    precision = {'weights': 'All observed163 logical projection carriers load BF16 matrices in both arms. Hyle source manifest has320 tensors/3763655360B. Peer loader reports187 BF16+133F32 tensors; converting small/nonprojection tensors toF32 does not mean projection weights were converted.',
        'hyle_projection': '139 cuBLAS BF16 W/A/output GEMVs with F32 compute (cublas_provider.cc:252-263);24 native dual FFN BF16 W/A/output with F32 accumulation and original BF16 RNE boundaries in epilogue (unary.cu:790-798).',
        'peer_projection': '163 native MMVF kernels have BF16 W, F32 activation and F32 output.54 are has_fusion=true (24dualFFN+24down+6attentionout),109false; the source MMVF float accumulator is not equivalent to retaining all Hyle BF16 boundaries.',
        'GDN_conv': 'Both observed core kernels acceptF32. Hyle explicitly rounds intermediate projections/conv activation/L2 toBF16 then widens toF32; peer maintains predominantlyF32 intermediates, fusesSILU intoSSMconv and uses different L2/norm composition. Same core symbol is not proof of identical inputs.',
        'KV': 'Both BF16 K/V. Hyle recurrent stateF32 with caller-owned ping-pong; peer original nativeF32 recurrent state/cache management.',
        'head_sampling': 'Hyle BF16 head output is widened toF32 then GPU TopK/CUB; peer F32 head output uses native argmax and additionally copies248320 sampled logits (993280B) perphase. Both host4B token paths are included; no tensor dumps are enabled.',
        'source_references': ['tools/qwen35_text/main.cc:173-199,285-300,346-433,490-559',
            'src/compute_provider_cublas/cublas_provider.cc:252-284',
            '.scratch/architecture-refactor-2026-10-18/cuda-fusion-precision/native-source/src/ggml-cuda/unary.cu:790-798',
            '.scratch/architecture-refactor-2026-10-18/cuda-fusion-precision/native-source/src/ggml-cuda/mmvf.cuh:274-338',
            '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/models/qwen35.cpp:154-216,335-482',
            '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/peer_benchmark.cpp:109-211']}
    result = {'scope': 'One complete128+31 CUDA/API/node trace per production consumer; offline warm decode7..31 attribution only',
        'images': {arm: row['image'] for arm, row in plan['arms'].items()},
        'device': a.read(STAGE / 'nvidia-smi.json'), 'tool': a.read(STAGE / 'nsys-version.json'),
        'input_checks': {'prompt128_equal': len(peer['prompt_ids']) == 128, 'decode31_equal': len(peer['decode_input_ids']) == 31,
                         'predicted_ids_equal': peer['predicted_ids'] == hyle['generated_ids'], 'same_internal_math': False},
        'weight_inventory': a.identity(inventory), 'logical_projection_weight_bytes_per_decode': sum(row['logical_weight_bytes_per_decode'] for row in role_comparison),
        'role_mapping_method': 'Sequential per-layer projection ordinal independently checked against graph source and observed carrier/grid shape for all31decode steps;24 recurrence/full-attention layer roles; same-size a/b and K/V remain deliberately combined. No fictitious profiler markers.',
        'projection_role_comparison': sorted(role_comparison, key=lambda row: row['hyle_mean_us'], reverse=True),
        'precision_and_work_boundary': precision,
        'arms': {arm: {'warm_decode7_31': report['warm_decode7_31'], 'categories': report['categories'],
            'profiled_consumer_timers': report['profiled_consumer_timers'], 'warnings': report['warnings'],
            'receipt_checks': {'CSV_SQLite_per_symbol_equal': report['receipt']['csv_sqlite_per_symbol_counts_equal'],
                             'graph_API_zero': not report['receipt']['graph_api_failures'],
                             'all_runtime_API_zero': not report['runtime_nonzero_returns']},
            'analysis': a.identity(STAGE / arm / 'analysis.json')} for arm, report in reports.items()},
        'throughput_claim': False, 'same_internal_precision': False, 'full_model_quality_verified': False,
        'limits': ['CUDA driver13.4 is newer than collector13.3; original warnings retained. No CUPTI report failure was silently discarded.',
                   'Single traces contain variable kernel long tails. Mean and median are both retained; no numerical decomposition is a statistical speedup claim.',
                   'Kernel elapsed durations may include contention/preemption; no counters measured actual DRAM traffic or active SM cycles.',
                   'API waits overlap GPU work. API sums and consumer timers must not be added to GPU durations.',
                   'No OS-runtime/CPU stack samples or bind-only markers; exact private CPU subfunction attribution remains unknown.',
                   'GPU event union and idle periods cover traced target activity only; idle does not prove CPU computation was the cause.',
                   'Logical weight read bytes normalize a per-token matrix footprint; cache/reloads/transactions are unmeasured.']}
    a.save(STAGE / 'analysis.json', result)
    for arm, report in reports.items():
        warm = report['warm_decode7_31']
        print(arm, 'kernels', warm['kernel_count']['median'], 'GraphLaunch', warm['GraphLaunch_count']['median'],
              'kernel_sum_mean_us', warm['kernel_duration_sum_ns']['mean'] / 1000,
              'device_idle_mean_us', warm['no_traced_device_activity_ns']['mean'] / 1000)
    for row in result['projection_role_comparison']:
        print(row['role'], 'bytes', row['logical_weight_bytes_per_decode'], 'hyle_us', row['hyle_mean_us'], 'peer_us', row['peer_mean_us'])
    print('ANALYZED', STAGE / 'analysis.json')


if __name__ == '__main__':
    main()
