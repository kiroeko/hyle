# Current production decode trace

The current bottleneck is projection matrix traffic/work, not the count of casts or the GDN recurrence kernel. Both consumers execute **163 projection kernels per decode**. Hyle has 740 total kernels versus the peer's 558; the corresponding nonprojection counts are 577 and 395. Thus 395 is not this peer's total kernel count.

These observations use one full process trace per arm, RTX 4070 / SM89, driver 617.14 and Nsight Systems 2026.1.3. Each process uses the retained 128-token prompt and the same 31 fixed decode input IDs, context capacity 256, no tensor dumps. Only decode7..31 contributes to warm summaries. Both profile/export/stats commands exited zero, all CUDA runtime returns are zero, and every official CSV kernel-symbol count matches SQLite. All 32 predicted IDs agree, which is not independent model quality or full-vector equivalence evidence.

## Measured warm kernel time and logical matrix footprint

The table contains **profiled kernel elapsed time**, mean over 25 warm steps. A projection's role was matched to source layer order, exact matrix shape and observed carrier/grid across all 31 decode steps. Same-size a/b and K/V roles remain combined. The detailed analysis retains all samples, per-role medians, symbols, block/grid dimensions and one representative mapped step.

| Projection role | Kernels/step | Logical weight MB/step | Hyle ms/step | Peer ms/step |
|---|---:|---:|---:|---:|
| FFN gate+up, fused dual projection | 24 | 1207.960 | 3.332 | 3.158 |
| LM head | 1 | 1017.119 | 2.502 | 2.514 |
| FFN down | 24 | 603.980 | 1.576 | 1.508 |
| GDN QKV projection | 18 | 452.985 | 1.205 | 1.115 |
| GDN output projection | 18 | 150.995 | 0.491 | 0.451 |
| GDN Z projection | 18 | 150.995 | 0.433 | 0.399 |
| Dense-attention Q projection | 6 | 100.663 | 0.330 | 0.259 |
| Dense-attention output projection | 6 | 50.332 | 0.156 | 0.191 |
| GDN a/b projections | 36 | 2.359 | 0.102 | 0.057 |
| Dense-attention K/V projections | 12 | 25.166 | 0.076 | 0.125 |
| **All projections** | **163** | **3762.553** | **10.204** | **9.777** |

“Logical weight MB” is one nominal read of each matrix operand per single-token decode, using decimal MB. It is not a measured DRAM transaction count: caches, repeated reads and memory-controller utilization were not profiled. The total is derived from the existing source weights.tsv and per-role BF16 matrices, not estimated from kernel count. FFN plus LM head constitutes 75.2% of this logical weight footprint.

Hyle's normalized logical weight bytes divided by profiled mean kernel time is 362.5 GB/s for gate+up, 383.1 GB/s for down and 406.6 GB/s for the head; peer values are 382.5, 400.4 and 404.7 GB/s. These are normalization ratios, **not measured bandwidth or unprofiled throughput**. Head medians are almost equal (2.208 versus 2.206ms); large dense-attention projection medians also nearly coincide. This trace does not establish a large GEMV implementation failure that would justify rerunning the previously studied general MMVF replacement.

Projection kernels account for 91.05% of Hyle's 11.207ms kernel-duration sum and 92.27% of the peer's 10.596ms. Nonprojection kernel sums are 1.003 and 0.819ms. The extra 182 kernels therefore do not imply twice the compute time.

| Selected nonprojection work | Hyle kernels/step | Hyle mean ms/step | Peer mean ms/step |
|---|---:|---:|---:|
| Contiguous BF16/F32 casts | 163 | 0.154 | No corresponding explicit contiguous cast family |
| GDN core only | 18 | 0.067 | 0.055 |
| Causal-conv core | 18 | 0.025 | 0.026 |
| Hyle BF16 L2 core | 36 | 0.092 | Different F32 RMS/scale composition |
| Dense-attention core/merge | 12 | 0.059 | 0.107 across 6 kernels |
| Sampling argmax kernels | 4 | 0.102 | 0.066 across 1 kernel |
| RoPE | 12 | 0.020 | 0.014 |

Hyle also has 73 traced D2D copies per warm step: mean 22.97MB (median 25.93MB), mean 0.088ms. The peer has no traced D2D memcpy activity in these warm intervals. Their exact storage role is not identified by address-free trace metadata; do not label all of them GDN-state copies. Hyle's published recurrent-state ping-pong and graph/region copies are candidates for a separate source-level no-copy audit, with an upper timing budget around the observed 88us, rather than treating these copies as the main decode loss.

## Precision and consumer boundaries

All projection matrix weights are BF16 in the observed carriers. Hyle's source manifest has 320 tensors / 3,763,655,360 bytes. The peer loader reports 187 BF16 and 133 F32 tensors: small/other tensors converted to F32 do not mean projection matrices are F32.

Hyle's 139 cuBLAS projections have BF16 weights, activations and outputs with F32 compute. Its 24 native dual FFN kernels likewise take BF16 activations/weights and preserve the original BF16 RNE boundaries in their F32-accumulating epilogue. The peer's 163 native MMVF projections take BF16 weights but F32 activations and produce F32 outputs. Its 54 fused carriers comprise 24 dual FFN, 24 FFN-down and 6 attention-output projections. These are different intermediate numerical recipes; the trace cannot determine which has better model quality.

Both core GDN/conv kernels accept F32. Hyle widens explicitly rounded BF16 intermediates into them; the peer keeps predominantly F32 intermediates, fuses SiLU into SSM conv and uses different L2/norm composition. Dropping these Hyle conversion boundaries to reduce launches would change the numerical contract. Both use BF16 K/V and F32 recurrent state.

Hyle widens the BF16 head result to F32 and uses GPU TopK/CUB. The peer uses native GPU argmax and the public backend token fast path, but its default engine also copies 248,320 sampled logits / 993,280 bytes every phase. Hyle transfers a 4-byte token only. The two data-transfer boundaries are recorded, not silently equalized.

## Host, region boundaries and device gaps

Hyle reuses seven graph captures in all warm steps; the peer launches one captured graph. Hyle has 723 graph-node kernels plus 17 eager kernels (embedding gather, six attention/merge pairs and four argmax kernels); the peer has 558 graph-node kernels.

The source-defined Hyle `cold_batch_seconds` aggregate is mean 0.333ms: layout version, six batch prepares, bindings and prepare_replay. Submit is mean 0.998ms. The peer's `decode_return_seconds` is mean 0.655ms and includes its original scheduling/enqueue work. There is no bind-only marker or CPU stack sample. These are different boundaries and overlap GPU execution; they cannot be added to GPU busy time or compared as isolated CPU functions. Synchronize waits also overlap GPU work.

The union of traced kernel/copy/memset activity is 11.288ms per Hyle endpoint interval versus 10.638ms for the peer. No-device-activity time is 1.037 versus 1.005ms. **Internal** no-device-activity between first and last kernel is 0.351 versus 0.066ms (medians 0.278 versus 0.019ms). This is an observable region/launch-seam opportunity, not proof of a particular CPU function's cost. Hyle's GraphLaunch API sum is 0.793ms, but only 0.187ms overlaps traced device idle; most API wall time overlaps GPU work. The peer's single GraphLaunch API is 0.457ms and is entirely before device execution. Counts or API sums alone therefore cannot explain the gap.

The detailed decode7 segment timeline shows the actual seven graph IDs separated by six eager attention+merge pairs. In that sample, five attention-to-next-graph gaps are about 7us, and embedding-to-first-graph is 166us. Profiler node tracing can affect host GraphLaunch duration, so these figures are diagnosis targets, not unprofiled savings guarantees.

Endpoint accounting uses the final device readback: Hyle's token D2H, peer's later sampled-logits D2H. The peer's 32 token/logits-copy pairs have no intervening kernels, so either endpoint gives the same physical kernel bins. The endpoint-to-endpoint interval includes inter-step reporting and preparation; it is not relabeled as the consumer stopwatch.

## What this supports next

1. Any new experiment should state its expected time budget. The main matrix work already dominates and the head is close to the peer; do not select a general kernel replacement just because it removes casts or changes kernel count. FFN and QKV are the largest plausible projection subdomains to examine if an exact preserved-precision/source-level improvement is found.
2. Review the seven-region prepare/bind/submit seams and the 73 D2D copies for avoidable work, keeping actual alias/lifetime and replay contracts. This trace gives a few-hundred-microsecond seam budget and an 88us D2D budget, not a multi-millisecond explanation.
3. Argmax and remaining BF16 L2/cast composition are bounded secondary candidates. Any fusion must preserve their dtype/RNE/math contract; reducing logical matrix bytes through a different quantization would be a separate precision and quality decision.

No product edits, compilation, throughput rotation, NCU run or new benchmark occurred. Both reports retain the original warning that driver CUDA13.4 is newer than the collector's supported13.3 and fallback libraries were used. Individual kernels exhibit long tails (for example a peer projection normally around55us lasts842us in one step); elapsed time can include contention/preemption. Distributions overlap. One sequential trace pair cannot establish a stable speedup/regression, DRAM bottleneck proof, an exact CPU private-function attribution, all-platform behavior or model quality.

Raw commands/environment: `plan.json`, each arm's `runtime.json` and `*.command/result.json`. Raw evidence: `decode.nsys-rep`, `decode.sqlite`, four official CSV reports, embedded target logs. Detailed offline evidence: `analysis.json` and each arm's `analysis.json`.
