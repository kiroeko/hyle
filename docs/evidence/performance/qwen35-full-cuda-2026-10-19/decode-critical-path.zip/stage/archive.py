"""Publish the frozen two-trace diagnosis; no build, profiling or cleanup."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/decode-critical-path.zip'

def sha(data):
    return hashlib.sha256(data).hexdigest()

receipt = json.loads((STAGE / 'evidence-receipt.json').read_bytes())
if DEST.exists():
    raise ValueError('Refuse to replace an existing diagnosis archive')
files = {}
for row in receipt['files']:
    path = Path(row['path'])
    if not path.is_relative_to(STAGE) or not path.is_file() or path.is_symlink():
        raise ValueError('Unexpected payload path')
    data = path.read_bytes()
    if (len(data), sha(data)) != (row['bytes'], row['sha256']):
        raise ValueError('Frozen diagnosis changed: ' + str(path))
    files['stage/' + path.relative_to(STAGE).as_posix()] = data
for rel in ('evidence-receipt.json', 'archive.py'):
    files['stage/' + rel] = (STAGE / rel).read_bytes()
files['SHA256SUMS.json'] = (json.dumps({name: dict(bytes=len(data), sha256=sha(data))
    for name, data in sorted(files.items())}, indent=2) + '\n').encode()
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(DEST) as archive:
    if archive.testzip() is not None:
        raise ValueError('Archive CRC failure')
    for name, data in files.items():
        if archive.read(name) != data:
            raise ValueError('Archive payload changed')
out = dict(path=str(DEST.relative_to(ROOT)), bytes=DEST.stat().st_size,
    sha256=sha(DEST.read_bytes()), payloads=len(files)-1,
    original_frozen_payloads=receipt['payload_count'], CRC_and_all_hashes_verified=True,
    GPU_collections=2, performance_improvement_claim=False)
DEST.with_name('decode-critical-path-archive.json').write_text(
    json.dumps(out, indent=2) + '\n', encoding='utf-8')
print(json.dumps(out, indent=2))
