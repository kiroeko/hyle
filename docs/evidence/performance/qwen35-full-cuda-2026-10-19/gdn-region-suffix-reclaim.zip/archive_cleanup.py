"""Package the completed exact cleanup, without any further deletion."""
from pathlib import Path
import hashlib
import json
import zipfile
STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/gdn-region-suffix-reclaim.zip'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def identity(path):
    path=path.resolve(); data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def check(row):
    actual=identity(Path(row['path']))
    assert all(actual[k]==row[k] for k in ('bytes','sha256'))
plan=read(STAGE/'cleanup-plan.json'); result=read(STAGE/'cleanup-result.json')
assert result['deleted_files']==plan['count']==224 and result['deleted_bytes']==plan['total_bytes']
assert all(not Path(row['path']).exists() for row in plan['targets'])
for row in [*plan['evidence'],*plan['retained_images'],*plan['retained_vectors'],plan['current_build_plan']]: check(row)
build=read(Path(plan['current_build_plan']['path']))
assert all(Path(p).is_file() for link in build['links'].values() for p in link['inputs'])
assert (ROOT/'test.ps1').read_bytes()==(STAGE/'executed-reclaim.ps1').read_bytes()
files={name:STAGE/name for name in ('cleanup-plan.json','cleanup-result.json','executed-reclaim.ps1',
    'test-before-reclaim.ps1','prepare_cleanup.py','archive_cleanup.py','archive-receipt.json')}
files['current-test.ps1']=ROOT/'test.ps1'
manifest={name:identity(path) for name,path in files.items()}
manifest_data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
assert not DEST.exists()
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in files.items(): z.write(path,name)
    z.writestr('payload-sha256.json',manifest_data)
expected={k:v['sha256'] for k,v in manifest.items()}
expected['payload-sha256.json']=hashlib.sha256(manifest_data).hexdigest()
with zipfile.ZipFile(DEST) as z:
    assert set(z.namelist())==set(expected)
    for name in z.namelist():
        data=z.read(name) # zipfile also validates CRC32.
        assert hashlib.sha256(data).hexdigest()==expected[name]
receipt=dict(**identity(DEST),entries=len(expected),crc_verified=True,payload_sha256_verified=True,
    deleted_files=plan['count'],deleted_bytes=plan['total_bytes'],retained_images=plan['retained_images'],
    retained_reference_vectors=len(plan['retained_vectors']),all_link_inputs_retained=True,recursive=False)
DEST.with_suffix('.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False,indent=2))
