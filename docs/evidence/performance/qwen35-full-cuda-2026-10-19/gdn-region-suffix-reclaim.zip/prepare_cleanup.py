"""Prepare exact, archived, rebuildable-file cleanup; never deletes."""
from pathlib import Path
import hashlib
import json
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def identity(path):
    path=path.resolve(); data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def check(row,path=None):
    actual=identity(path or Path(row['path']))
    assert all(actual[k]==row[k] for k in ('bytes','sha256')),(row,actual)
    return actual
out=STAGE/'checks/20261019T165656'
dest=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
evidence=[identity(dest/name) for name in ('gdn-typed-load.zip','gdn-typed-load-archive.json',
    'gdn-region-suffix.zip','gdn-region-suffix-archive.json')]
for name in ('gdn-typed-load','gdn-region-suffix'):
    record=read(dest/(name+'-archive.json'))
    assert record['crc_verified'] and record['payload_sha256_verified']
    check(record)
retained=[check(read(out/'qwen-image.json')),
    check(read(ARCH/'gdn-typed-load/checks/20261019T163125/qwen-image.json')),
    check(read(ARCH/'cuda-explicit-rope/performance-prepared/peer-image.json')),
    check(read(ARCH/'decode-next-cold/checks/20261019T155819/cpu-image.json'))]
current=read(STAGE/'correctness/summary.json')
references=[check(r['reference']) for r in current['observation']['vectors']]
assert len(references)==64
targets={}
def target(path):
    path=path.resolve()
    assert path.is_relative_to(ROOT/'.scratch') and path.is_file()
    row=identity(path); targets[str(path).casefold()]=row
image_bases=[
    ARCH/'gdn-typed-load/checks/20261019T163125/gdn',
    STAGE/'checks/20261019T164900/qwen',STAGE/'checks/20261019T164900/gdn',
    STAGE/'checks/20261019T165315/qwen',STAGE/'checks/20261019T165315/gdn',
    out/'gdn',
    ARCH/'decode-next-cold/checks/20261019T155819/qwen',
    ARCH/'batch-graph-capture/checks/20261019T151408-fixture-include/qwen']
for base in image_bases:
    assert base.with_suffix('.exe').is_file()
    for suffix in ('.exe','.map','.exp','.lib','.pdb'):
        path=base.with_suffix(suffix)
        if path.exists(): target(path)
for folder in (ARCH/'gdn-typed-load/correctness',STAGE/'attempt2-correctness',STAGE/'correctness'):
    observed=read(folder/'summary.json')['observation']
    assert observed['equal_vectors']==64 and len(observed['vectors'])==64
    for row in observed['vectors']:
        path=folder/'trace'/row['path']
        actual=check(row['actual'],path)
        assert actual['sha256']==row['reference']['sha256'] and row['byte_equal']
        target(path)
plan_identity=identity(out/'plan.json')
inputs={str(Path(p).resolve()).casefold() for link in read(out/'plan.json')['links'].values() for p in link['inputs']}
assert not set(targets).intersection(inputs)
assert not set(targets).intersection(str(Path(r['path']).resolve()).casefold() for r in retained+references+evidence)
plan=dict(evidence=evidence,retained_images=retained,retained_vectors=references,current_build_plan=plan_identity,
    targets=list(targets.values()),count=len(targets),total_bytes=sum(r['bytes'] for r in targets.values()),
    scope='Eight obsolete/temporary images and side products plus192 duplicate exact tensors; retain current/baseline/peer/CPU images, all objects, SDKs, actual sources and64 original vectors.',
    recursive=False)
path=STAGE/'cleanup-plan.json'
assert not path.exists()
path.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=(ROOT/'test.ps1').read_bytes()
(STAGE/'test-before-reclaim.ps1').write_bytes(old)
script=old.decode('utf-8-sig')
script=script.replace('decode-next-cold\\cleanup-plan.json','gdn-region-suffix\\cleanup-plan.json')
script=script.replace('2f873d4b67ece63ffd542106e83359725ac955f4d37c4c65441c4b55f88e8bad',identity(path)['sha256'])
script=script.replace('decode-next-cold\\cleanup-result.json','gdn-region-suffix\\cleanup-result.json')
assert 'decode-next-cold\\cleanup-' not in script
(ROOT/'test.ps1').write_text(script,encoding='utf-8')
(STAGE/'executed-reclaim.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(plan=identity(path),count=plan['count'],bytes=plan['total_bytes'],
    MiB=plan['total_bytes']/1024**2,images_retained=len(retained),reference_vectors_retained=len(references),
    deletion_executed=False),indent=2))
