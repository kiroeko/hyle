"""Prepare, or explicitly collect one production-image CUDA/API trace."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
OUT = STAGE / 'profile'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_current(b, c, plan_path):
    plan = c.read(plan_path)
    if not c.read(plan_path.parent / 'summary.json')['passed']:
        raise ValueError('Successful current build required')
    if c.key(c.read(STAGE / 'latest-check.json')['plan']) != c.key(plan_path):
        raise ValueError('Expected this stage latest build')
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Current build identity changed: ' + row['path'])
    for seal, source in [('native-source-freeze.json', STAGE / 'native-source'),
                         ('host-source-freeze.json', ROOT)]:
        for row in c.read(STAGE / seal)['files']:
            expected = row.get('after', row)
            actual = b.identity(source / row['path'])
            if any(actual[k] != expected[k] for k in ('bytes', 'sha256')):
                raise ValueError('Current source differs from ' + seal + ': ' + row['path'])
    if not c.read(STAGE / 'correctness/summary.json')['passed']:
        raise ValueError('Current fixed-input model regression required')
    return plan


def prepare(b, c, plan_path):
    if (OUT / 'plan.json').exists():
        raise ValueError('Refuse to overwrite trace plan')
    plan = verify_current(b, c, plan_path)
    rotation_path = STAGE / 'performance-prepared/plan.json'
    rotation = c.read(rotation_path)
    request = next(row for row in rotation['requests'] if row['arm'] == 'current')
    command = request['command'].copy()
    image = c.read(plan_path.parent / 'qwen-image.json')
    if b.identity(command[0]) != image or rotation['images']['current'] != image:
        raise ValueError('Exact production image differs')
    if '--trace' in command or '--trace-level' in command:
        raise ValueError('No tensor dumps in this physical trace')
    assert command[command.index('--steps') + 1] == '32'
    assert command[command.index('--capacity') + 1] == '256'
    assert len(rotation['fixed']['prompt_ids']) == 128 and len(rotation['fixed']['decode_input_ids']) == 31
    nsys = c.read(ARCH / 'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0]
    stem = OUT / 'capture'
    commands = dict(
        profile=[nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
            '--discard-environment=true', '--output=' + str(stem), *command],
        export=[nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        stats=[nsys, 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,cuda_gpu_mem_size_sum',
               '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'])
    OUT.mkdir(exist_ok=False)
    (OUT / 'tmp').mkdir()
    c.save(OUT / 'plan.json', dict(status='prepared_not_run', build_plan=b.identity(plan_path),
        runner=b.identity(Path(__file__)), analyzer=b.identity(STAGE / 'analyze_profile.py'),
        image=image, link_plan=b.identity(plan_path.parent / 'qwen-link-plan.json'),
        current_freezes=[b.identity(STAGE / name) for name in ('native-source-freeze.json', 'host-source-freeze.json')],
        retained_input_plan=b.identity(rotation_path), fixed=rotation['fixed'], source_id=rotation['source_id'],
        expected_generated_ids=c.read(STAGE / 'correctness/summary.json')['observation']['generated_ids'],
        commands=commands, consumer_command=command, GPU_model_processes_planned=1,
        baseline_reprofiled=False, baseline_launch_count_reference=740,
        expected_not_asserted=dict(decode7_kernels=704, BF16_to_F32=73, F32_to_BF16=54,
                                   GDN=18, GDN_V_BF16_beta_BF16=18),
        tensor_dumps=False, all_CUDA_APIs=True, compilations=0, links=0, throughput_claim=False,
        limits='One current trace, all-API profiling perturbs timing. Physical instantiations/counts only; source/IDs and existing64vector proof are separate. No inferred CPU attribution from unmarked gaps.'))
    print('PROFILE_PREPARED_NO_GPU', OUT / 'plan.json', flush=True)


def run(b, c, plan_path):
    if not (OUT / 'plan.json').exists():
        prepare(b, c, plan_path)
    current = verify_current(b, c, plan_path)
    plan = c.read(OUT / 'plan.json')
    assert plan['build_plan'] == b.identity(plan_path)
    for row in [plan['runner'], plan['analyzer'], plan['image'], plan['link_plan'], *plan['current_freezes']]:
        if not b.same(row):
            raise ValueError('Prepared trace identity changed: ' + row['path'])
    perf = c.read(STAGE / 'performance-rotation/summary.json')
    if perf['terminal_zero'] != 9:
        raise ValueError('Coordinate GPU only after completed nine-process rotation')
    link = c.read(Path(plan['link_plan']['path']))
    paths = [row['path'] if isinstance(row, dict) else row for row in link['inputs']]
    env, runtime = b.environment(link['command'], paths, OUT)
    forbidden = ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION', 'GGML_CUDA_GRAPH_OPT',
                 'HYLE_RMS_DIAG', 'HYLE_GDN_L2_DIAG')
    if any(key in env for key in forbidden):
        raise ValueError('Non-production graph/diagnostic override')
    c.save(OUT / 'runtime.json', dict(runtime_library_directories_from_own_link=runtime,
        link_input_count=len(paths), unrelated_CPU_or_peer_DLL_union_used=False,
        CUDA_MODULE_LOADING=env.get('CUDA_MODULE_LOADING'), forbidden_overrides_absent=list(forbidden)))
    for tag, command in plan['commands'].items():
        if (OUT / (tag + '.command.json')).exists() or (OUT / (tag + '.result.json')).exists():
            raise ValueError('No implicit profile/export/stats retry: ' + tag)
        c.execute(tag, command, env, OUT)
    c.save(OUT / 'collection-summary.json', dict(passed=True, fresh_model_processes=1,
        profile_exit=c.read(OUT / 'profile.result.json')['exit'],
        export_exit=c.read(OUT / 'export.result.json')['exit'],
        stats_exit=c.read(OUT / 'stats.result.json')['exit'], throughput_claim=False))
    load('gdn_physical_analysis', STAGE / 'analyze_profile.py').analyze()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', type=Path)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--analyze', action='store_true')
    args = parser.parse_args()
    if args.run and args.analyze:
        raise ValueError('Choose collection or offline analysis')
    if args.analyze:
        load('gdn_physical_analysis', STAGE / 'analyze_profile.py').analyze()
    else:
        h = load('gdn_profile_build_helpers', STAGE / 'build.py')
        run(h.b, h.c, args.plan.resolve()) if args.run else prepare(h.b, h.c, args.plan.resolve())
