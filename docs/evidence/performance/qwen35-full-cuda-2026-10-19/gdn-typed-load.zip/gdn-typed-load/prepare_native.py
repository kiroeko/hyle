"""Prepare exact-load GDN overlay from the complete current locked replay."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def replace(text, old, new):
    assert text.count(old) == 1, old[:120]
    return text.replace(old, new, 1)


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256']
    for edit in row['edits']:
        old, new = edit['before'].encode(), edit['after'].encode()
        assert data.count(old) == 1, row['path']
        data = data.replace(old, new, 1)
    assert sha(data) == row['after_sha256']
    return data


SUPPORT = r'''
// Private carrier: only V/beta may replace a materialized F32 widening edge.
// This predicate is metadata-only: buffers/data need not exist during sizing.
bool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst) {
    if (!dst || dst->op != GGML_OP_GATED_DELTA_NET || dst->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const q = dst->src[0], * const k = dst->src[1], * const v = dst->src[2];
    const ggml_tensor * const g = dst->src[3], * const beta = dst->src[4], * const state = dst->src[5];
    if (!q || !k || !v || !g || !beta || !state || q->type != GGML_TYPE_F32 ||
        k->type != GGML_TYPE_F32 || g->type != GGML_TYPE_F32 || state->type != GGML_TYPE_F32 ||
        (v->type != GGML_TYPE_F32 && v->type != GGML_TYPE_BF16) ||
        (beta->type != GGML_TYPE_F32 && beta->type != GGML_TYPE_BF16)) return false;
    const int64_t S = v->ne[0], H = v->ne[1], T = v->ne[2], B = v->ne[3];
    const int K = ggml_get_op_params_i32(dst, 0);
    if ((S != 16 && S != 32 && S != 64 && S != 128) || H <= 0 || H > INT32_MAX ||
        T <= 0 || T > INT32_MAX || B <= 0 || B > UINT32_MAX || K < 1 ||
        !ggml_are_same_shape(q, k) || !ggml_are_same_stride(q, k) ||
        q->ne[0] != S || q->ne[1] <= 0 || H % q->ne[1] || q->ne[2] != T ||
        q->ne[3] <= 0 || B % q->ne[3] ||
        (g->ne[0] != 1 && g->ne[0] != S) || beta->ne[0] != 1 ||
        g->ne[1] != H || g->ne[2] != T || g->ne[3] != B ||
        beta->ne[1] != H || beta->ne[2] != T || beta->ne[3] != B ||
        state->ne[0] != S || state->ne[1] != S || state->ne[2] != H || state->ne[3] != B ||
        !ggml_is_contiguous_rows(q) || !ggml_is_contiguous_rows(k) ||
        !ggml_is_contiguous_rows(v) || !ggml_is_contiguous(g) ||
        !ggml_is_contiguous(beta) || !ggml_is_contiguous(state) || !ggml_is_contiguous(dst)) return false;
    // All kernel offsets are signed element offsets. Also prove ggml_nbytes
    // cannot overflow before later bound owner/capacity/range validation.
    const ggml_tensor * const tensors[] = {q, k, v, g, beta, state, dst};
    for (const auto * tensor : tensors) {
        const size_t element = ggml_type_size(tensor->type);
        size_t bytes = element;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0 ||
                (tensor->ne[axis] > 1 && tensor->nb[axis] % element)) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
    }
    const auto mul = [](int64_t a, int64_t b, int64_t & result) {
        if (a > INT64_MAX / b) return false;
        result = a * b;
        return true;
    };
    int64_t width, token_rows, state_rows, rows, elements;
    if (!mul(S, H, width) || !mul(T, B, token_rows) || !mul(K, S, state_rows) ||
        !mul(state_rows, B, state_rows) || token_rows > INT64_MAX - state_rows) return false;
    rows = token_rows + state_rows;
    return mul(width, rows, elements) && elements <= INT64_MAX / int64_t(sizeof(float)) &&
        dst->ne[0] == width && dst->ne[1] == rows && dst->ne[2] == 1 && dst->ne[3] == 1;
}

'''


BOUND = r'''
// New typed reads retain their actual original buffers. Cold supports never
// requires addresses; encode validates owners without CUDA pointer queries.
static bool ggml_cuda_gdn_uses_typed_loads(const ggml_tensor * dst) {
    return !dst->src[2] || !dst->src[4] ||
        dst->src[2]->type != GGML_TYPE_F32 || dst->src[4]->type != GGML_TYPE_F32;
}

static bool ggml_cuda_gdn_typed_bound(const ggml_tensor * dst, int device,
                                     const ggml_tensor * cache = nullptr) {
    if (!ggml_cuda_supports_gated_delta_net_typed(dst) ||
        !GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[device].cc) ||
        dst->src[2]->ne[3] > ggml_cuda_mmvq_grid_y[device]) return false;
    const auto bounded = [device](const ggml_tensor * tensor) {
        if (!tensor || !tensor->data || !tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        const uintptr_t begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        size_t bytes = ggml_type_size(tensor->type);
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (tensor->ne[axis] <= 0) return false;
            const uint64_t extent = uint64_t(tensor->ne[axis] - 1);
            if (extent && tensor->nb[axis] > (uint64_t(INT64_MAX) - bytes) / extent) return false;
            bytes += extent * tensor->nb[axis];
        }
        return begin % ggml_type_size(tensor->type) == 0 && begin >= base &&
            begin - base <= capacity && bytes <= capacity - (begin - base) && bytes <= UINTPTR_MAX - begin;
    };
    const auto overlap = [](const ggml_tensor * a, const ggml_tensor * b) {
        const uintptr_t x = reinterpret_cast<uintptr_t>(a->data), y = reinterpret_cast<uintptr_t>(b->data);
        return x < y + ggml_nbytes(b) && y < x + ggml_nbytes(a);
    };
    if (!bounded(dst)) return false;
    for (int port = 0; port < 6; ++port) {
        if (!bounded(dst->src[port]) || overlap(dst, dst->src[port])) return false;
    }
    if (cache) {
        const auto * v = dst->src[2];
        const size_t slot_bytes = size_t(v->ne[0]) * v->ne[0] * v->ne[1] * v->ne[3] * sizeof(float);
        if (cache->type != GGML_TYPE_F32 || !bounded(cache) ||
            (cache->ne[2] > 1 && (cache->nb[2] % sizeof(float) || cache->nb[2] < slot_bytes)) ||
            overlap(dst, cache)) return false;
        for (int port = 0; port < 6; ++port) {
            if (!overlap(cache, dst->src[port])) continue;
            // The original state-cache fusion may replace exactly s0. Each
            // block loads and owns its whole state column before writing it.
            if (port != 5 || cache->data != dst->src[port]->data ||
                ggml_nbytes(dst->src[port]) != slot_bytes) return false;
        }
    }
    return true;
}

'''


def native_gdn(old):
    text = old.decode()
    text = replace(text, '#include "ggml-cuda/common.cuh"\n', '#include "ggml-cuda/common.cuh"\n#include "convert.cuh"\n' + SUPPORT)
    text = replace(text, 'template <int S_v, bool KDA, bool keep_rs_t>', 'template <int S_v, bool KDA, bool keep_rs_t, typename TV, typename TB>')
    text = replace(text, '                                     const float * v,', '                                     const TV * v,')
    text = replace(text, '                                     const float * beta,', '                                     const TB * beta,')
    text = replace(text, '                                     int64_t       sb1,', '                                     int64_t       sg1,\n                                     int64_t       sg2,\n                                     int64_t       sg3,\n                                     int64_t       sb1,')
    text = replace(text, '        const float * v_t = v + sequence * sv3 + t * sv2 + h_idx * sv1;', '        const TV * v_t = v + sequence * sv3 + t * sv2 + h_idx * sv1;')
    text = replace(text, '        const int64_t gb_offset = sequence * sb3 + t * sb2 + h_idx * sb1;\n        const float * beta_t = beta + gb_offset;\n        const float * g_t    = g    + gb_offset * (KDA ? S_v : 1);\n\n        const float beta_val = *beta_t;',
        '        const TB * beta_t = beta + sequence * sb3 + t * sb2 + h_idx * sb1;\n        const float * g_t = g + sequence * sg3 + t * sg2 + h_idx * sg1;\n\n        const float beta_val = ggml_cuda_cast<float>(*beta_t);')
    assert text.count('v_t[col]') == 2
    text = text.replace('v_t[col]', 'ggml_cuda_cast<float>(v_t[col])')
    text = replace(text, 'template <bool KDA, bool keep_rs_t>\nstatic void launch_gated_delta_net(', 'template <bool KDA, bool keep_rs_t, typename TV, typename TB>\nstatic void launch_gated_delta_net(')
    text = replace(text, '        const float * q_d, const float * k_d, const float * v_d,\n        const float * g_d, const float * b_d, const float * s_d,', '        const float * q_d, const float * k_d, const TV * v_d,\n        const float * g_d, const TB * b_d, const float * s_d,')
    text = replace(text, '        int64_t sb1,   int64_t sb2, int64_t sb3,', '        int64_t sg1,   int64_t sg2, int64_t sg3,\n        int64_t sb1,   int64_t sb2, int64_t sb3,')
    for depth in (16, 32, 64, 128):
        text = replace(text, f'gated_delta_net_cuda<{depth}, KDA, keep_rs_t>', f'gated_delta_net_cuda<{depth}, KDA, keep_rs_t, TV, TB>')
    assert text.count('                sb1, sb2, sb3, neqk1_magic') == 4
    text = text.replace('                sb1, sb2, sb3, neqk1_magic', '                sg1, sg2, sg3, sb1, sb2, sb3, neqk1_magic')
    text = replace(text, 'static void ggml_cuda_op_gated_delta_net_impl(', 'template <typename TV, typename TB>\nstatic void ggml_cuda_op_gated_delta_net_impl(')
    text = replace(text, '    GGML_TENSOR_LOCALS(size_t,  nbb, src_beta, nb);', '    GGML_TENSOR_LOCALS(size_t,  nbb, src_beta, nb);\n    GGML_TENSOR_LOCALS(size_t,  nbg, src_g, nb);')
    text = replace(text, '    const float * v_d = (const float *) src_v->data;', '    const TV * v_d = (const TV *) src_v->data;')
    text = replace(text, '    const float * b_d = (const float *) src_beta->data;', '    const TB * b_d = (const TB *) src_beta->data;')
    text = replace(text, '    // strides in floats (beta strides used for both g and beta offset computation)', '    // Per-port element strides: g remains F32, independently of typed beta.')
    for name in ('sv1', 'sv2', 'sv3'):
        text = replace(text, f'    const int64_t {name} = nbv{name[-1]} / sizeof(float);', f'    const int64_t {name} = nbv{name[-1]} / sizeof(TV);')
    for name in ('sb1', 'sb2', 'sb3'):
        text = replace(text, f'    const int64_t {name} = nbb{name[-1]} / sizeof(float);', f'    const int64_t {name} = nbb{name[-1]} / sizeof(TB);')
    text = replace(text, '    const int64_t sb1 = nbb1 / sizeof(TB);', '    const int64_t sg1 = nbg1 / sizeof(float);\n    const int64_t sg2 = nbg2 / sizeof(float);\n    const int64_t sg3 = nbg3 / sizeof(float);\n    const int64_t sb1 = nbb1 / sizeof(TB);')
    assert text.count('                sb1, sb2, sb3, neqk1,') == 4
    text = text.replace('                sb1, sb2, sb3, neqk1,', '                sg1, sg2, sg3, sb1, sb2, sb3, neqk1,')
    dispatch = r'''
static void ggml_cuda_dispatch_gated_delta_net(ggml_backend_cuda_context & ctx, ggml_tensor * dst,
        const ggml_cuda_gated_delta_net_fused_cache * cache) {
    if (dst->src[2]->type != GGML_TYPE_F32 || dst->src[4]->type != GGML_TYPE_F32) {
        if (!ggml_cuda_supports_gated_delta_net_typed(dst)) {
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed GDN metadata");
        }
        if (dst->src[2]->type == GGML_TYPE_BF16) {
            if (dst->src[4]->type == GGML_TYPE_BF16) {
                ggml_cuda_op_gated_delta_net_impl<nv_bfloat16, nv_bfloat16>(ctx, dst, cache);
            } else {
                ggml_cuda_op_gated_delta_net_impl<nv_bfloat16, float>(ctx, dst, cache);
            }
        } else {
            ggml_cuda_op_gated_delta_net_impl<float, nv_bfloat16>(ctx, dst, cache);
        }
    } else {
        ggml_cuda_op_gated_delta_net_impl<float, float>(ctx, dst, cache);
    }
}

'''
    text = replace(text, '\nvoid ggml_cuda_op_gated_delta_net(', dispatch + 'void ggml_cuda_op_gated_delta_net(')
    text = replace(text, '    ggml_cuda_op_gated_delta_net_impl(ctx, dst, nullptr);', '    ggml_cuda_dispatch_gated_delta_net(ctx, dst, nullptr);')
    text = replace(text, '    ggml_cuda_op_gated_delta_net_impl(ctx, dst, &cache);', '    ggml_cuda_dispatch_gated_delta_net(ctx, dst, &cache);')
    return text.encode()


def main_source(old):
    text = old.decode()
    anchor = '// No CUDA pointer query on the hot path: resource admission already binds\n'
    text = replace(text, anchor, BOUND + anchor)
    text = replace(text, '        case GGML_OP_GATED_DELTA_NET:\n            ggml_cuda_op_gated_delta_net(ctx, dst);',
        '        case GGML_OP_GATED_DELTA_NET:\n            if (ggml_cuda_gdn_uses_typed_loads(dst) && !ggml_cuda_gdn_typed_bound(dst, ctx.device)) {\n                hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid bound typed GDN inputs/output");\n            }\n            ggml_cuda_op_gated_delta_net(ctx, dst);')
    text = replace(text, '        const ggml_cgraph * cgraph, int node_idx, ggml_cuda_gated_delta_net_fused_cache & fused_state_cpy) {',
        '        const ggml_cgraph * cgraph, int node_idx, ggml_cuda_gated_delta_net_fused_cache & fused_state_cpy, int device) {')
    text = replace(text, '    fused_state_cpy.data        = (float *) dst->data; // rollback group 0 (newest)',
        '    if (ggml_cuda_gdn_uses_typed_loads(gdn) && !ggml_cuda_gdn_typed_bound(gdn, device, dst)) {\n        return 0;\n    }\n    fused_state_cpy.data        = (float *) dst->data; // rollback group 0 (newest)')
    text = replace(text, '        const int nodes_to_skip = ggml_cuda_try_gdn_cache_fusion(cgraph, i, fused_state_cpy);',
        '        if (ggml_cuda_gdn_uses_typed_loads(node) && !ggml_cuda_gdn_typed_bound(node, cuda_ctx->device)) {\n            hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid bound typed GDN inputs/output");\n        }\n        const int nodes_to_skip = ggml_cuda_try_gdn_cache_fusion(cgraph, i, fused_state_cpy, cuda_ctx->device);')
    old_support = '''        case GGML_OP_GATED_DELTA_NET:
            //TODO: enable once MUSA compiler is solved https://github.com/ggml-org/llama.cpp/pull/19504#issuecomment-4018634327
#ifdef GGML_USE_MUSA
            return false;
#else
            return true;
#endif // GGML_USE_MUSA'''
    new_support = old_support.replace('            return true;', '''            if (ggml_cuda_gdn_uses_typed_loads(op)) {
                return ggml_cuda_supports_gated_delta_net_typed(op) &&
                    GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[dev_ctx->device].cc) &&
                    op->src[2]->ne[3] <= ggml_cuda_mmvq_grid_y[dev_ctx->device];
            }
            return true;''')
    text = replace(text, old_support, new_support)
    return text.encode()


def unique_edits(old, new):
    left, right = old.decode().splitlines(True), new.decode().splitlines(True)
    result, data = [], old
    for group in difflib.SequenceMatcher(None, left, right, autojunk=False).get_grouped_opcodes(4):
        first, last = group[0], group[-1]
        before = ''.join(left[first[1]:last[2]])
        after = ''.join(right[first[3]:last[4]])
        assert data.count(before.encode()) == 1
        data = data.replace(before.encode(), after.encode(), 1)
        result.append(dict(before=before, after=after))
    assert data == new
    return result


def main():
    STAGE.mkdir(exist_ok=True)
    mixed = STAGE / 'mixed-cpu-manifest.json'
    load('gdn_mixed', ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').derive(UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    combined = STAGE / 'before-combined.json'
    composer = load('gdn_cuda', ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')
    composer.derive(UPSTREAM, mixed, ROOT / 'third_party/ggml_cuda_runtime/patches.json',
                     ROOT / 'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    baseline = {row['path']: replay(row) for row in read(combined)['files']}
    paths = ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/gated_delta_net.cu', 'src/ggml-cuda/gated_delta_net.cuh']
    replacements, frozen, diffs = [], [], []
    for name in paths:
        old = baseline.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        if name.endswith('ggml-cuda.cu'):
            new = main_source(old)
        elif name.endswith('.cu'):
            new = native_gdn(old)
        else:
            new = old + b'\n// Metadata-only qualification for private typed V/beta loads; no address is required.\nbool ggml_cuda_supports_gated_delta_net_typed(const ggml_tensor * dst);\n'
        for folder, data in [('before-native', old), ('native-overlay/source', new)]:
            path = STAGE / folder / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        replacements.append(dict(path=name, before_sha256=sha(old), after_sha256=sha(new), edits=unique_edits(old, new)))
        frozen.append(dict(path=name, before_sha256=sha(old), after_sha256=sha(new),
            before=str(STAGE / 'before-native' / name), after=str(STAGE / 'native-overlay/source' / name)))
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
    save(STAGE / 'native-overlay/replacements.json', dict(files=replacements))
    (STAGE / 'native-overlay/changes.diff').write_text(''.join(diffs), encoding='utf-8')
    save(STAGE / 'native-overlay/source-freeze.json', dict(files=frozen,
        host_ABI_changed=False, public_API_changed=False, shared_by_value_struct_changed=False,
        native_TUs_requiring_refresh=['ggml-cuda.cu', 'gated_delta_net.cu'],
        build_or_GPU_run=False))
    print('OVERLAY_READY', STAGE / 'native-overlay/source-freeze.json')


if __name__ == '__main__':
    main()
