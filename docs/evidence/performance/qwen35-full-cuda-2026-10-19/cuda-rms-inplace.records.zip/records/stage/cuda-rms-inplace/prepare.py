"""Permit only exact dense in-place RMS input mapping; preserve other aliases."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
UPSTREAM=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST=ROOT/'third_party/ggml_cuda_runtime/patches.json'

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def apply(data,edits):
    for edit in edits:
        old,new=edit['before'].encode(),edit['after'].encode()
        if data.count(old)!=1:raise ValueError('Nonunique native patch')
        data=data.replace(old,new,1)
    return data

HELPER='''static bool ggml_cuda_rms_cast_input_safe(const ggml_tensor * dst, const ggml_tensor * src) {
    if (ggml_cuda_rms_cast_disjoint(dst, src)) {
        return true;
    }
    // One block owns each dense row. Its original block reduction synchronizes
    // every initial input read before any epilogue store; the epilogue then
    // reads/writes each column in the same thread. Only this exact mapping is
    // safe in place. Partial, strided or broadcast overlaps still fall back.
    if (!src->data || src->data != dst->data ||
        src->type != GGML_TYPE_BF16 || dst->type != GGML_TYPE_BF16 ||
        !ggml_are_same_shape(src, dst) || !ggml_is_contiguous(src) || !ggml_is_contiguous(dst) ||
        memcmp(src->nb, dst->nb, sizeof(src->nb)) != 0) {
        return false;
    }
    const size_t bytes = ggml_nbytes(src);
    return bytes == ggml_nbytes(dst) && bytes <= UINTPTR_MAX - (uintptr_t) src->data;
}

'''

def main():
    before=STAGE/'patches.before.json'
    if before.exists():raise ValueError('Do not overwrite the original attempt')
    before.write_bytes(MANIFEST.read_bytes())
    manifest=json.loads(before.read_text())
    row=next(r for r in manifest['files'] if r['path']=='src/ggml-cuda/ggml-cuda.cu')
    original=(UPSTREAM/row['path']).read_bytes().replace(b'\r\n',b'\n')
    if sha(original)!=row['before_sha256']:raise ValueError('Upstream source drift')
    old=apply(original,row['edits'])
    if sha(old)!=row['after_sha256']:raise ValueError('Original patch replay differs')
    edits=[
        {'before':"// backing, so reject any overlap with the real BF16 input or F32 scale.",
         'after':"// backing. Permit disjoint reads or the exact dense BF16 input mapping;\n// keep every scale strictly disjoint from the output."},
        {'before':'static bool ggml_cuda_match_rms_norm_cast(',
         'after':HELPER+'static bool ggml_cuda_match_rms_norm_cast('},
        {'before':'!ggml_cuda_rms_cast_disjoint(dst, x) ||',
         'after':'!ggml_cuda_rms_cast_input_safe(dst, x) ||'},
    ]
    new=apply(old,edits);row['edits']+=edits;row['after_sha256']=sha(new)
    save(MANIFEST,manifest)
    (STAGE/'native-change.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),
        new.decode().splitlines(True),fromfile='v12/ggml-cuda.cu',tofile='v13/ggml-cuda.cu')),encoding='utf-8')
    save(STAGE/'raw-source-freeze.json',{'before':sha(old),'after':sha(new),'kernel_changed':False,
        'allowed_input_overlap':'exact same non-null BF16 dense shape, strides and byte range only',
        'scale_overlap_allowed':False})
    print('PATCH_PREPARED',sha(new),flush=True)

if __name__=='__main__':main()
