"""Increment one native main and two host TUs; retain the existing SDK closure."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import re
import sys
import uuid
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=STAGE.parents[2]
spec=importlib.util.spec_from_file_location('projection_increment',ARCH/'cuda-projection-fusion/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
OLD=ARCH/'cuda-rms-cast-fusion/checks/20261019T065214-eb0b4c02'
BASE=ARCH/'cuda-rms-cast-fusion/checks/20261019T065521-144b94d3'

def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]

def check(plan):
    for row in plan['frozen']+plan['cached_inputs']:
        if not b.same(row):raise ValueError('Input drift: '+row['path'])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',action='store_true');args=p.parse_args()
    out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    freeze=c.read(STAGE/'native-source-freeze.json')
    header=STAGE/'provider-version.h'
    source=STAGE/'native-source/src/ggml-cuda/ggml-cuda.cu'
    if b.identity(source)['sha256']!=freeze['sources']['src/ggml-cuda/ggml-cuda.cu']:raise ValueError('Native source differs')
    frozen=[b.identity(x) for x in (Path(__file__),source,header,STAGE/'native-source-freeze.json',
        STAGE/'native-source/src/ggml-cuda/norm.cuh',ROOT/'third_party/ggml_cuda_runtime/patches.json',
        ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',ROOT/'cmake/HyleDependencyLock.json')]
    recipe=c.read(OLD/'ggml-cuda-identity.json');template=[];skip=False
    for item in recipe['command']:
        if skip:skip=False;continue
        if item=='-ccbin':skip=True;continue
        template.append(item)
    command=b.native_command(template,source,'ggml-cuda',out)
    command[1:1]=['-I'+str(source.parent.parent),'-I'+str(source.parent)]
    compiles=[{'tag':'ggml-cuda','command':command,'object':str(out/'ggml-cuda.obj'),'source':b.identity(source)}]
    replacements={c.key(recipe['object']['path']):str(out/'ggml-cuda.obj')}
    for tag,relative in (('provider','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
                         ('rms-cast-test','tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc')):
        path=OLD/(tag+'-identity.json');old=c.read(path);template=old['command']
        if tag=='provider':template=['/FI'+str(header) if x.lower().startswith('/fi') else x for x in template]
        source=ROOT/relative;command=b.host_command(template,source,tag,out)
        compiles.append({'tag':tag,'command':command,'object':str(out/(tag+'.obj')),'source':b.identity(source)})
        replacements[c.key(old['object']['path'])]=str(out/(tag+'.obj'))
        frozen.extend(b.identity(x) for x in b.host_dependencies(template) if x.is_file())
        frozen.extend((b.identity(source),b.identity(path)))
    frozen.append(b.identity(OLD/'ggml-cuda-identity.json'))
    cases=['.'.join(m) for m in re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',
        (ROOT/'tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc').read_text())]
    if len(cases)!=4 or len(set(cases))!=4:raise ValueError('Expected four RMS tests')
    links={};cached={}
    for name,count in (('qwen',123),('cuda',130)):
        path=BASE/(name+'-link-plan.json');base=c.read(path);frozen.append(b.identity(path))
        if len(base['inputs'])!=count:raise ValueError('Unexpected retained closure')
        for row in base['inputs']:cached[row['path']]=row
        required=[key for key in replacements if name=='cuda' or not key.endswith('rms-cast-test.obj')]
        for key in required:
            if sum(c.key(x['path'])==key for x in base['inputs'])!=1:raise ValueError('Replacement owner missing')
        link=[replacements.get(c.key(x),x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        image=out/(name+'.exe');link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        if len(inputs(link))!=count:raise ValueError('Link closure changed size')
        links[name]={'command':link,'image':str(image),'inputs':inputs(link)}
    plan={'compile':compiles,'links':links,'frozen':list({x['path']:x for x in frozen}.values()),
        'cached_inputs':list(cached.values()),'directed_tests':cases,'SDK_build':False,'CMake_run':False,
        'native_TUs':1,'host_TUs':2,'native_source_id':freeze['source_id']}
    target=out/'plan.json';c.save(target,plan);print('PLAN',target,flush=True);check(plan)
    if not args.build:return
    (out/'tmp').mkdir();env,_=b.environment(links['qwen']['command'],list(cached),out)
    for item in compiles:
        c.execute(item['tag']+'-compile',item['command'],env,out);check(plan)
        c.save(out/(item['tag']+'-identity.json'),{'command':item['command'],'source':item['source'],'object':b.identity(item['object'])})
    for name,link in links.items():
        c.save(out/(name+'-link-plan.json'),{'command':link['command'],'inputs':[b.identity(x) for x in link['inputs']]})
        c.execute(name+'-link',link['command'],env,out);check(plan);c.save(out/(name+'-image.json'),b.identity(link['image']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':1,'host_TUs':2,'GPU_run':False})
    print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
