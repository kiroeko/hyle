"""Explicit cuda or qwen mode only; reuse existing exact checks without a new runner."""
from pathlib import Path
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent


def load(name,path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def main():
    if len(sys.argv)!=3 or sys.argv[2] not in ('cuda','qwen'):
        raise ValueError('Usage: run_checks.py checks/<session>/plan.json {cuda|qwen}; no CPU mode')
    current = load('rms_cast_current_build',STAGE/'build_current.py')
    path = Path(sys.argv[1]).resolve()
    if path.name!='plan.json' or not path.is_relative_to(STAGE/'checks'):
        raise ValueError('Plan must belong to this stage/checks')
    plan = current.c.read(path); current.check(plan)
    retained = load('retained_immutable_checks',current.ARCH/'immutable-constant-alias/run_checks.py')
    runner = retained.prior
    previous = list(runner.CASES['cuda'])
    if len(previous)!=12: raise ValueError('Expected the twelve retained CUDA regressions')
    cases = previous+['GgmlCudaTensor.FloatingNormAffineAndUnaryConversions']+plan['directed_tests']
    if len(cases)!=17 or len(set(cases))!=17: raise ValueError('Expected seventeen exact CUDA cases')
    runner.STAGE=STAGE; runner.b=current; runner.c=current.c; runner.CASES={'cuda':cases}
    # Existing runner records real commands/PIDs/exits, XML, output vectors and
    # original failures. A pre-existing run directory rejects implicit retry.
    runner.main()
    if sys.argv[2]=='qwen':
        run = path.parent/'run-qwen'; summary = current.c.read(run/'summary.json')
        prior = current.ARCH/'cuda-reshape-reuse'
        capture = lambda p: re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)',p.read_text())
        expected = capture(prior/'correctness-candidate.stderr.log')
        actual = capture(run/'qwen.stderr.log')
        result = json.loads((run/'qwen.stdout.log').read_text().splitlines()[-1])
        summary.update(capture_counts_equal=actual==expected,
                       equal_token_ids=len(result['generated_ids']) if summary['same_generated_ids'] else 0)
        current.c.save(run/'summary.json',summary)
        if actual!=expected or len(result['generated_ids'])!=32:
            raise ValueError('Qwen capture counts or the32 generated IDs differ')


if __name__=='__main__':
    try: main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True); raise SystemExit(1)
