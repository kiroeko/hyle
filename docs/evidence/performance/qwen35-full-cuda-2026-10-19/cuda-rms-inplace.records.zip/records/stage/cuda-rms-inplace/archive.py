"""Archive bounded evidence and exact current sources; retain object/SDK caches."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
spec=importlib.util.spec_from_file_location('inplace_build_archive',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
DEST=b.ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-rms-inplace.zip'
DIAG=ARCH/'cuda-rms-layout-review'
PRODUCTS=('third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md',
    'cmake/HyleDependencyLock.json','tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc',
    'docs/architecture/compute-design.md','docs/developer/current-work.md',
    'docs/implementation/model-operators.md','docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('prepare','archive'));p.add_argument('plan',type=Path)
    args=p.parse_args();plan=c.read(args.plan);b.check(plan)
    if not c.read(args.plan.parent/'summary.json')['passed']:raise ValueError('Build failed')
    if args.mode=='prepare':
        targets=[b.b.identity(x) for root in (STAGE,DIAG) for x in root.rglob('*')
            if x.is_file() and x.suffix.lower() in ('.exe','.map','.lib','.exp')]
        c.save(STAGE/'reclaim-targets.json',targets)
        c.save(STAGE/'archive-source-freeze.json',[b.b.identity(b.ROOT/x) for x in PRODUCTS])
        print('PREPARED',len(targets),sum(x['bytes'] for x in targets),flush=True);return
    if DEST.exists():raise ValueError('Do not overwrite an archive')
    suffixes={'.py','.json','.xml','.log','.csv','.sqlite','.nsys-rep','.bf16','.f32','.h','.cu','.cuh','.diff','.cmake','.ids'}
    payload={}
    for root in (STAGE,DIAG,ARCH/'cuda-ffn-projection-review'):
        for x in root.rglob('*'):
            if x.is_file() and x.suffix.lower() in suffixes and 'tmp' not in x.relative_to(root).parts and x.name not in ('archive-verification.json','reclaim-receipt.json'):
                payload['stage/'+root.name+'/'+x.relative_to(root).as_posix()]=x
    for row in c.read(STAGE/'archive-source-freeze.json')+plan['frozen']:
        source=Path(row['path'])
        if not b.b.same(row):raise ValueError('Source drift: '+str(source))
        if source.is_relative_to(b.ROOT) and not source.is_relative_to(b.ROOT/'.scratch'):
            payload['source/'+source.relative_to(b.ROOT).as_posix()]=source
    manifest=[]
    with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,source in sorted(payload.items()):
            data=source.read_bytes();z.writestr(name,data)
            manifest.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        z.writestr('manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(DEST) as z:
        if z.testzip() is not None:raise ValueError('CRC mismatch')
        for row in manifest:
            data=z.read(row['name'])
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('Payload SHA mismatch')
    result=dict(b.b.identity(DEST),entries=len(manifest),CRC_and_payload_SHA_verified=True,
        reclaim_manifest=b.b.identity(STAGE/'reclaim-targets.json'))
    c.save(STAGE/'archive-verification.json',result);print(json.dumps(result),flush=True)

if __name__=='__main__':main()
