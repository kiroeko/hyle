"""Read the one successful diagnostic log; write metadata-only grouped findings."""
from __future__ import annotations

import collections
import hashlib
import json
from pathlib import Path


STAGE = Path(__file__).resolve().parent
RUN = STAGE / "checks/20261019T070847-4de5d00d/run-diagnostic"
LOG = RUN / "qwen.stderr.log"
PREFIX = "HYLE_RMS_DIAG "


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def key(row: dict) -> tuple:
    return row["graph"], row["rms"]


def span(tensor: dict) -> dict:
    return {field: tensor[field] for field in ("data", "end", "bytes", "ne", "nb")}


def main() -> None:
    rows = []
    diagnostic_bytes = 0
    phase = "T128"
    boundary_line = None
    for line_number, line in enumerate(LOG.read_text().splitlines(), 1):
        if line.startswith("prepared T=128 "):
            assert boundary_line is None
            boundary_line = line_number
            phase = "T1"
        if line.startswith(PREFIX):
            diagnostic_bytes += len((line + "\n").encode())
            row = json.loads(line[len(PREFIX):])
            row.update(line=line_number, phase=phase)
            rows.append(row)
    assert boundary_line is not None
    assert not any(r["event"] == "truncated" for r in rows)
    tensors = collections.defaultdict(dict)
    sequences = {}
    for row in rows:
        if row["event"] == "tensor":
            tensors[row["id"]][row["label"]] = row
        elif row["event"] == "sequence":
            sequences[row["id"]] = row
    headers = [r for r in rows if r["event"] in ("candidate", "legacy_rms")]
    assert [r["id"] for r in headers] == list(range(194))
    receipt = json.loads((RUN / "qwen.result.json").read_text())
    assert receipt["exit"] == 0 and receipt["terminal"] is True
    output = {
        "scope": "One existing diagnostic-only --steps 2 run, T128 prefill and T1 first decode; no latency or quality claim.",
        "log": identity(LOG),
        "successful_run_receipt": str(RUN / "qwen.result.json"),
        "exit": receipt["exit"],
        "coverage": {
            "parse_errors": 0,
            "truncated": False,
            "diagnostic_bytes_lf_normalized": diagnostic_bytes,
            "cap_bytes": 393216,
            "header_ids_contiguous": [0, 193],
            "event_counts": dict(collections.Counter(r["event"] for r in rows)),
            "phase_boundary": {"line": boundary_line, "marker": "prepared T=128", "rule": "T128 diagnostics precede this marker; T1 diagnostics follow it."},
        },
        "phases": {},
    }
    for phase_name in ("T128", "T1"):
        phase_rows = [r for r in rows if r["phase"] == phase_name]
        candidates = [r for r in phase_rows if r["event"] == "candidate"]
        matched = [r for r in candidates if r["matched"]]
        rejected = [r for r in candidates if not r["matched"]]
        legacy = [r for r in phase_rows if r["event"] == "legacy_rms"]
        matched_keys = {key(r) for r in matched}
        rejected_keys = {key(r) for r in rejected}
        legacy_keys = {key(r) for r in legacy}
        assert len(matched) == len(matched_keys) == 48
        assert len(rejected) == len(rejected_keys) == 18
        assert len(legacy) == len(legacy_keys) == 31
        assert rejected_keys <= legacy_keys
        assert not matched_keys & legacy_keys
        assert len(matched_keys | legacy_keys) == 79
        assert {r["reason"] for r in rejected} == {"alias.input"}
        assert all(r["weighted"] for r in matched)
        assert all(not r["weighted"] for r in rejected)
        for row in rejected:
            t = tensors[row["id"]]
            a, b = t["input"], t["destination"]
            assert a["dtype"] == b["dtype"] == "bf16"
            assert span(a) == span(b)
            assert a["view"] == b["view"] == "0000000000000000"
            assert not a["overflow"] and not b["overflow"]
            assert a["nb"][0] == 2
            assert all(a["nb"][d] == a["nb"][d-1] * a["ne"][d-1] for d in range(1, 4))
            assert (a["uses"], t["widen"]["uses"], t["rms"]["uses"], b["uses"]) == (2, 2, 1, 2)
        groups = collections.defaultdict(list)
        for row in legacy:
            if key(row) in rejected_keys:
                continue
            t = tensors[row["id"]]
            groups[(tuple(t["rms"]["ne"]), t["rms_input"]["op"])].append(row)
        structural = []
        for (shape, input_op), group in sorted(groups.items()):
            row = group[0]
            t = tensors[row["id"]]
            assert t["rms_input"]["dtype"] == "f32"
            structural.append({
                "count": len(group), "ne": list(shape), "native_input_op": input_op,
                "native_input_dtype": "f32", "input_index": row["input_index"],
                "input_view_nonnull": t["rms_input"]["view"] != "0000000000000000",
                "reason": "No adjacent BF16-to-F32 CPY in this native subgraph; outside complete-chain candidate, not an alias rejection.",
                "example_log_line": row["line"],
                "local_sequence": [n["op"] + ":" + n["dtype"] for n in sequences[row["id"]]["nodes"]],
            })
        assert sum(g["count"] for g in structural) == 13
        example = rejected[0]
        output["phases"][phase_name] = {
            "diagnostic_lines": [min(r["line"] for r in phase_rows), max(r["line"] for r in phase_rows)],
            "unique_rms": 79, "matched_weighted": 48, "remaining": 31,
            "matched_shape": matched[0]["ne"],
            "explicit_rejections": {"alias.input": 18},
            "alias_rejections": {
                "weighted": False, "same_dense_bf16_mapping": 18,
                "uses_input_widen_rms_dst": [2, 2, 1, 2],
                "flags_input_widen_rms_dst": [16, 16, 16, 16],
                "input_and_dst_view_src_null": True,
                "example_log_line": example["line"],
                "example_identical_input_and_dst_span": span(tensors[example["id"]]["input"]),
            },
            "outside_complete_cast_chain": structural,
            "coverage_reconciliation": "48 matched + 31 distinct legacy = 79 unique RMS; 18 rejected candidates are included in the 31 legacy, not added again.",
        }
    output["limits"] = [
        "No node/ValueId mapping in this log: native F32 leaf or reshape does not prove original logical input was F32 or identify a model role.",
        "The single cols=2048 F32 external input in each phase is not proven to be final norm or to have shared consumers. Do not reinterpret its allocation as BF16.",
        "Host Recipe.norm (tools/qwen35_text/main.cc:175-178) explicitly casts to F32; main.cc:395/397 and :424 are q/k and final norm callers. These source facts do not assign individual native pointers to those nodes.",
        "For the 13 structural non-candidates, this log does not include the external producer graph or final output spans, so cross-region cast placement and alias status remain unproven here.",
        "Coverage applies to these two preparation/compute graph walks only, not later decode shapes or a latency measurement.",
    ]
    destination = STAGE / "diagnostic-findings.json"
    destination.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": identity(destination), "phase_counts": {p: [v["matched_weighted"], v["remaining"]] for p, v in output["phases"].items()}}))


if __name__ == "__main__":
    main()
