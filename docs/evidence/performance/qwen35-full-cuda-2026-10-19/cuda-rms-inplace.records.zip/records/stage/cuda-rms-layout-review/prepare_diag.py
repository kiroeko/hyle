"""Prepare one scratch-only RMS matcher diagnostic TU; never build or run it."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
V12 = ROOT / ".scratch/architecture-refactor-2026-10-18/cuda-rms-cast-fusion/native-source"
REL = Path("src/ggml-cuda/ggml-cuda.cu")

HELPERS = r'''// Temporary scratch-only host metadata diagnostics. No tensor bytes are read.
static bool hyle_rms_diag_enabled() {
    static const bool enabled = [] {
        const char * value = std::getenv("HYLE_RMS_DIAG");
        return value && std::atoi(value) != 0;
    }();
    return enabled;
}

static void hyle_rms_diag_line(const char * format, ...) {
    if (!hyle_rms_diag_enabled()) return;
    char line[4096];
    va_list args;
    va_start(args, format);
    const int size = std::vsnprintf(line, sizeof(line), format, args);
    va_end(args);
    if (size < 0) return;
    const size_t count = std::min((size_t) size, sizeof(line) - 1);
    static std::mutex mutex;
    static size_t written = 0;
    static bool truncated = false;
    const std::lock_guard<std::mutex> lock(mutex);
    if (truncated) return;
    constexpr size_t limit = 384 * 1024;
    constexpr char prefix[] = "HYLE_RMS_DIAG ";
    constexpr char notice[] = "HYLE_RMS_DIAG {\"event\":\"truncated\",\"limit_bytes\":393216}\n";
    if (written + sizeof(prefix) - 1 + count + 1 + sizeof(notice) - 1 > limit) {
        if (!truncated) {
            std::fputs(notice, stderr);
            truncated = true;
        }
        return;
    }
    std::fwrite(prefix, 1, sizeof(prefix) - 1, stderr);
    std::fwrite(line, 1, count, stderr);
    std::fputc('\n', stderr);
    written += sizeof(prefix) - 1 + count + 1;
}

static int hyle_rms_diag_uses(const ggml_cgraph * graph, const ggml_tensor * tensor) {
    if (!tensor) return -1;
    const size_t slot = ggml_hash_find(&graph->visited_hash_set, tensor);
    if (slot == GGML_HASHSET_FULL || !ggml_bitset_get(graph->visited_hash_set.used, slot)) return -1;
    return graph->use_counts[slot];
}

static int hyle_rms_diag_index(const ggml_cgraph * graph, const ggml_tensor * tensor) {
    for (int i = 0; i < graph->n_nodes; ++i) if (graph->nodes[i] == tensor) return i;
    return -1;
}

static void hyle_rms_diag_tensor(unsigned id, const char * label,
                                  const ggml_cgraph * graph, const ggml_tensor * tensor) {
    if (!tensor) {
        hyle_rms_diag_line("{\"event\":\"tensor\",\"id\":%u,\"label\":\"%s\",\"present\":false}", id, label);
        return;
    }
    const size_t bytes = ggml_nbytes(tensor);
    const uintptr_t start = (uintptr_t) tensor->data;
    const bool overflow = bytes > UINTPTR_MAX - start;
    hyle_rms_diag_line(
        "{\"event\":\"tensor\",\"id\":%u,\"label\":\"%s\",\"tensor\":\"%p\","
        "\"op\":\"%s\",\"dtype\":\"%s\",\"uses\":%d,\"flags\":%u,\"view\":\"%p\","
        "\"src0\":\"%p\",\"src1\":\"%p\",\"ne\":[%lld,%lld,%lld,%lld],"
        "\"nb\":[%llu,%llu,%llu,%llu],\"data\":\"%p\",\"end\":\"%p\",\"bytes\":%llu,\"overflow\":%s}",
        id, label, (const void *) tensor, ggml_op_name(tensor->op), ggml_type_name(tensor->type),
        hyle_rms_diag_uses(graph, tensor), (unsigned) tensor->flags, (const void *) tensor->view_src,
        (const void *) tensor->src[0], (const void *) tensor->src[1],
        (long long) tensor->ne[0], (long long) tensor->ne[1], (long long) tensor->ne[2], (long long) tensor->ne[3],
        (unsigned long long) tensor->nb[0], (unsigned long long) tensor->nb[1],
        (unsigned long long) tensor->nb[2], (unsigned long long) tensor->nb[3], tensor->data,
        (void *) (overflow ? 0 : start + bytes), (unsigned long long) bytes, overflow ? "true" : "false");
}

static void hyle_rms_diag_sequence(unsigned id, const ggml_cgraph * graph, int center) {
    char sequence[3072];
    size_t used = 0;
    const int begin = std::max(0, center - 3);
    const int end = std::min(graph->n_nodes, center + 6);
    for (int i = begin; i < end; ++i) {
        const ggml_tensor * node = graph->nodes[i];
        const int n = std::snprintf(sequence + used, sizeof(sequence) - used,
            "%s{\"i\":%d,\"tensor\":\"%p\",\"op\":\"%s\",\"dtype\":\"%s\",\"cols\":%lld,\"uses\":%d,\"flags\":%u}",
            i == begin ? "" : ",", i, (const void *) node, ggml_op_name(node->op), ggml_type_name(node->type),
            (long long) node->ne[0], hyle_rms_diag_uses(graph, node), (unsigned) node->flags);
        if (n < 0 || (size_t) n >= sizeof(sequence) - used) return;
        used += (size_t) n;
    }
    hyle_rms_diag_line("{\"event\":\"sequence\",\"id\":%u,\"graph\":\"%p\",\"center\":%d,\"nodes\":[%s]}",
        id, (const void *) graph, center, sequence);
}

struct hyle_rms_diag_failure {
    const char * reason;
    int index;
};

static hyle_rms_diag_failure hyle_rms_diag_suffix(const ggml_cgraph * graph, int begin, bool weighted) {
    const ggml_op ops[] = {GGML_OP_RMS_NORM, weighted ? GGML_OP_MUL : GGML_OP_CPY, GGML_OP_CPY};
    const int count = weighted ? 3 : 2;
    for (int offset = 0; offset < count; ++offset) {
        const int i = begin + offset;
        if (i >= graph->n_nodes) return {"suffix.bounds", i};
        const ggml_tensor * node = graph->nodes[i];
        if (node->op != ops[offset]) return {"suffix.op", i};
        if ((node->flags & GGML_TENSOR_FLAG_COMPUTE) == 0) return {"suffix.compute_flag", i};
        if (offset < count - 1 && !ggml_node_has_n_uses(graph, i, 1)) {
            if (hyle_rms_diag_uses(graph, node) != 1) return {"suffix.use_count", i};
            if (node->view_src) return {"suffix.view_src", i};
            if (node->flags & GGML_TENSOR_FLAG_OUTPUT) return {"suffix.output_flag", i};
            return {"suffix.use_helper", i};
        }
        if (offset > 0) {
            const ggml_tensor * previous = graph->nodes[i - 1];
            if (node->src[0] != previous && node->src[1] != previous) return {"suffix.edge", i};
            if (!ggml_are_same_shape(node, previous)) return {"suffix.shape", i};
        }
    }
    return {"suffix.unclassified", begin};
}

static const char * hyle_rms_diag_widen_reason(const ggml_cgraph * graph, int i) {
    const ggml_tensor * widen = graph->nodes[i];
    const ggml_tensor * x = widen->src[0];
    if (widen->op != GGML_OP_CPY) return "widen.op";
    if (widen->type != GGML_TYPE_F32) return "widen.dtype";
    if (widen->src[1] != widen) return "widen.self_destination";
    if (!x || x->type != GGML_TYPE_BF16) return "input.dtype";
    if ((widen->flags & GGML_TENSOR_FLAG_COMPUTE) == 0) return "widen.compute_flag";
    if (!ggml_node_has_n_uses(graph, i, 2)) {
        if (hyle_rms_diag_uses(graph, widen) != 2) return "widen.use_count";
        if (widen->view_src) return "widen.view_src";
        if (widen->flags & GGML_TENSOR_FLAG_OUTPUT) return "widen.output_flag";
        return "widen.use_helper";
    }
    if (!ggml_are_same_shape(x, widen)) return "widen.shape";
    if (!ggml_is_contiguous(widen)) return "widen.contiguous";
    if (!ggml_is_contiguous_rows(x)) return "input.contiguous_rows";
    return "widen.unclassified";
}

static const char * hyle_rms_diag_dst_reason(const ggml_tensor * dst, const ggml_tensor * norm,
                                            const ggml_tensor * last_f32, const ggml_tensor * x,
                                            const ggml_tensor * mul) {
    if (dst->op != GGML_OP_CPY) return "dst.op";
    if (dst->type != GGML_TYPE_BF16) return "dst.dtype";
    if (dst->src[0] != last_f32) return "dst.input_edge";
    if (dst->src[1] != dst) return "dst.self_destination";
    if (dst->view_src) return "dst.view_src";
    if (!ggml_are_same_shape(norm, dst)) return "dst.shape";
    if (!ggml_is_contiguous(dst)) return "dst.contiguous";
    if (!ggml_cuda_rms_cast_disjoint(dst, x)) return "alias.input";
    if (mul && !ggml_cuda_rms_cast_disjoint(dst, mul)) return "alias.scale";
    return "dst.unclassified";
}

static unsigned hyle_rms_diag_id() {
    static std::atomic<unsigned> next{0};
    return next.fetch_add(1, std::memory_order_relaxed);
}

static void hyle_rms_diag_candidate(const ggml_cgraph * graph, int i,
                                     const char * reason, int detail, bool matched) {
    if (!hyle_rms_diag_enabled() || i < 0 || i + 1 >= graph->n_nodes) return;
    const ggml_tensor * widen = graph->nodes[i];
    const ggml_tensor * x = widen->src[0];
    const ggml_tensor * norm = graph->nodes[i + 1];
    if (widen->op != GGML_OP_CPY || widen->type != GGML_TYPE_F32 || !x ||
        x->type != GGML_TYPE_BF16 || norm->op != GGML_OP_RMS_NORM) return;
    const ggml_tensor * next = i + 2 < graph->n_nodes ? graph->nodes[i + 2] : nullptr;
    const bool weighted = next && next->op == GGML_OP_MUL;
    const int dst_index = i + (weighted ? 3 : 2);
    const ggml_tensor * dst = dst_index < graph->n_nodes ? graph->nodes[dst_index] : nullptr;
    const ggml_tensor * mul = weighted ? next->src[next->src[0] == norm ? 1 : 0] : nullptr;
    const unsigned id = hyle_rms_diag_id();
    uint32_t eps_bits;
    memcpy(&eps_bits, norm->op_params, sizeof(eps_bits));
    hyle_rms_diag_line(
        "{\"event\":\"candidate\",\"id\":%u,\"graph\":\"%p\",\"i\":%d,\"rms_i\":%d,"
        "\"rms\":\"%p\",\"matched\":%s,\"reason\":\"%s\",\"detail\":%d,\"weighted\":%s,"
        "\"ne\":[%lld,%lld,%lld,%lld],\"widen_uses\":%d,\"rms_uses\":%d,\"eps_bits\":\"%08x\","
        "\"x_data\":\"%p\",\"dst_data\":\"%p\",\"x_disjoint\":%d,\"scale_disjoint\":%d}",
        id, (const void *) graph, i, i + 1, (const void *) norm, matched ? "true" : "false", reason, detail,
        weighted ? "true" : "false", (long long) x->ne[0], (long long) x->ne[1], (long long) x->ne[2], (long long) x->ne[3],
        hyle_rms_diag_uses(graph, widen), hyle_rms_diag_uses(graph, norm), (unsigned) eps_bits, x->data,
        dst ? dst->data : nullptr, dst ? (int) ggml_cuda_rms_cast_disjoint(dst, x) : -1,
        dst && mul ? (int) ggml_cuda_rms_cast_disjoint(dst, mul) : -1);
    if (matched) return;
    hyle_rms_diag_tensor(id, "input", graph, x);
    hyle_rms_diag_tensor(id, "widen", graph, widen);
    hyle_rms_diag_tensor(id, "rms", graph, norm);
    hyle_rms_diag_tensor(id, "next", graph, next);
    hyle_rms_diag_tensor(id, "scale", graph, mul);
    hyle_rms_diag_tensor(id, "destination", graph, dst);
    hyle_rms_diag_sequence(id, graph, i + 1);
}

// Called only when the ordinary graph walk actually reaches an RMS node.
// The 48 typed hits skip this node, and are counted by candidate matched lines.
static void hyle_rms_diag_legacy(const ggml_cgraph * graph, int i) {
    if (!hyle_rms_diag_enabled() || graph->nodes[i]->op != GGML_OP_RMS_NORM) return;
    const ggml_tensor * norm = graph->nodes[i];
    const ggml_tensor * input = norm->src[0];
    const unsigned id = hyle_rms_diag_id();
    hyle_rms_diag_line("{\"event\":\"legacy_rms\",\"id\":%u,\"graph\":\"%p\",\"i\":%d,"
        "\"rms\":\"%p\",\"input_index\":%d,\"cols\":%lld,\"uses\":%d,\"flags\":%u}",
        id, (const void *) graph, i, (const void *) norm, hyle_rms_diag_index(graph, input),
        (long long) norm->ne[0], hyle_rms_diag_uses(graph, norm), (unsigned) norm->flags);
    hyle_rms_diag_tensor(id, "rms", graph, norm);
    hyle_rms_diag_tensor(id, "rms_input", graph, input);
    if (input && input->op == GGML_OP_CPY && input->src[0]) {
        hyle_rms_diag_tensor(id, "pre_widen_input", graph, input->src[0]);
    }
    hyle_rms_diag_sequence(id, graph, i);
}

'''


def main():
    source_path = V12 / REL
    before = source_path.read_bytes()
    text = before.decode()
    begin = text.index("static bool ggml_cuda_match_rms_norm_cast(")
    end = text.index("// try and fuse nodes and return the number of nodes to skip", begin)
    original = text[begin:end]
    body = original.replace("    match = {};\n", """    match = {};
    const auto reject = [&](const char * reason, int detail = -1) {
        hyle_rms_diag_candidate(cgraph, i, reason, detail, false);
        return false;
    };
""", 1)
    # Preserve every original predicate. Only error returns and the successful
    # return get diagnostic calls; the logger's reason helpers do not decide.
    reasons = [
        'return reject("candidate.bounds");',
        'return reject(hyle_rms_diag_widen_reason(cgraph, i));',
        'return reject(norm->op != GGML_OP_RMS_NORM ? "rms.op" : norm->type != GGML_TYPE_F32 ? "rms.dtype" : norm->src[0] != widen ? "rms.input_edge" : !ggml_are_same_shape(widen, norm) ? "rms.shape" : "rms.contiguous");',
        'return reject("rms.epsilon");',
        'return reject(x->ne[dim] <= 0 || x->ne[dim] > INT32_MAX ? "input.extent" : "input.stride_units", dim);',
        'const auto failure = hyle_rms_diag_suffix(cgraph, i + 1, true);\n            return reject(failure.reason, failure.index);',
        'return reject(product->type != GGML_TYPE_F32 ? "product.dtype" : "product.input_edge");',
        'return reject(!mul ? "scale.missing" : mul->type != GGML_TYPE_F32 ? "scale.dtype" : "scale.contiguous_rows");',
        'return reject(mul->ne[dim] <= 0 || x->ne[dim] % mul->ne[dim] != 0 ? "scale.broadcast" : "scale.stride_units", dim);',
        'const auto failure = hyle_rms_diag_suffix(cgraph, i + 1, false);\n        return reject(failure.reason, failure.index);',
        'return reject(hyle_rms_diag_dst_reason(dst, norm, last_f32, x, mul));',
    ]
    # Exclude the reject lambda's own return false from substitutions.
    marker = "    if (i < 0"
    prefix, suffix = body.split(marker, 1)
    assert suffix.count("return false;") == len(reasons)
    parts = suffix.split("return false;")
    suffix = "".join(part + (reasons[i] if i < len(reasons) else "") for i, part in enumerate(parts))
    body = prefix + marker + suffix
    assert body.count("    return true;\n") == 1
    body = body.replace("    return true;\n", '    hyle_rms_diag_candidate(cgraph, i, "matched", -1, true);\n    return true;\n')
    text = text[:begin] + HELPERS + body + text[end:]
    header = """static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {

    static bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));
    if (disable_fusion) {
        return 0;
    }

    ggml_tensor * node = cgraph->nodes[i];
"""
    assert text.count(header) == 1
    text = text.replace(header, header + "\n    hyle_rms_diag_legacy(cgraph, i);\n", 1)
    after = text.encode()
    target = STAGE / "native-source" / REL
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(after)
    (STAGE / "native-change.diff").write_text("".join(difflib.unified_diff(
        before.decode().splitlines(True), text.splitlines(True),
        fromfile="v12/" + REL.as_posix(), tofile="diagnostic/" + REL.as_posix())), encoding="utf-8", newline="\n")
    header_path = V12 / "src/ggml-cuda/norm.cuh"
    result = {
        "scope": "Scratch-only bounded host metadata diagnostics; no product manifest change, build, device execution, latency or tensor-content recording.",
        "prepare_script": {"path": str(Path(__file__).resolve()), "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        "input": {"path": str(source_path), "sha256": hashlib.sha256(before).hexdigest()},
        "output": {"path": str(target), "sha256": hashlib.sha256(after).hexdigest(), "bytes": len(after)},
        "required_header": {"path": str(header_path), "sha256": hashlib.sha256(header_path.read_bytes()).hexdigest()},
        "prepend_include_directories": [str(V12 / "src"), str(V12 / "src/ggml-cuda")],
        "include_note": "Keep both v12 include directories before cached source directories. This stage contains ONLY the main TU, no copied SDK or headers.",
        "environment": {"HYLE_RMS_DIAG": "1"},
        "run_boundary": "One root-controlled --steps 2 run; do not use this image for performance measurements.",
        "stderr_prefix": "HYLE_RMS_DIAG ", "log_limit_bytes": 384 * 1024,
        "predicate_changes": "None: original matcher predicates remain verbatim; error/success returns only gain metadata logging. Existing fusion-disable behavior is unchanged.",
        "candidate_definition": "F32 CPY with BF16 source, immediately followed by RMS_NORM. Other remaining RMS nodes are logged separately with their actual neighboring native op sequence.",
        "unverified": ["Compilation", "Runtime diagnostic coverage", "Remaining-31 refusal classification"],
    }
    (STAGE / "source-freeze.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
