"""One real CUDA mixed-chain capture, metadata update and owner replacement test."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_capture_gpu_helpers', STAGE / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
h.check(plan['frozen'])
assert c.read(path.parent / 'summary.json')['passed']
out = STAGE / 'capture-tests-final'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
link = plan['links']['capture']
image = b.identity(link['image'])
assert image == c.read(path.parent / 'capture-image.json')
name = 'GraphBatchCapture.FreshMetadataPermissionsRetainOnlyUnchangedNativeCommands'
command = [image['path'], '--gtest_filter=' + name, '--gtest_output=xml:' + str(out / 'results.xml')]
env, _ = b.environment(link['command'], link['inputs'], out)
c.execute('capture', command, env, out)
cases = ET.parse(out / 'results.xml').findall('.//testcase')
passed = len(cases) == 1 and cases[0].attrib['classname'] + '.' + cases[0].attrib['name'] == name and all(
    cases[0].find(tag) is None for tag in ('failure', 'error', 'skipped'))
c.save(out / 'summary.json', dict(passed=passed, tests=len(cases), image=image, build_plan=b.identity(path)))
if not passed:
    raise ValueError('Actual four-episode CUDA capture fixture failed')
print('CAPTURE_TEST', 'passed', flush=True)
