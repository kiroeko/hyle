"""Prepare, or explicitly run, nine fresh baseline/current/llama processes.

Default: write a frozen performance plan, without starting model execution.
--relink-peer permits only the retained nine-input peer link when its image is
absent. --run consumes that plan into a new output directory. Numerical model
acceptance is a separate experiment; prediction differences are reported here.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import math
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEFAULT_BUILD = STAGE / 'checks/relink-20261019T084930/plan.json'
PREPARED = STAGE / 'performance-prepared'
PEER_PLAN = ARCH / 'cuda-current-peer/peer-link-plan.json'
FAIR_PLAN = ARCH / 'cuda-current-peer/run-plan.json'
MODEL_RECEIPT = ARCH / 'llama-matched-consumer/converted-file-identity.json'
INVENTORY = ROOT / 'docs/implementation/tasks/compute/qwen35-2b-local-input.json'
BASELINE_IDS = ARCH / 'cuda-hot-prepare-selection/comparison/01-baseline.stdout.log'
ORDER = ['baseline', 'current', 'llama', 'llama', 'baseline', 'current',
         'current', 'llama', 'baseline']
PEER_COMMIT = 'd9e03f1074dbd2979126d91dce1b5d304ec8394e'
FORBIDDEN_ENV = ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION',
                 'GGML_CUDA_GRAPH_OPT', 'HYLE_RMS_DIAG', 'HYLE_GDN_L2_DIAG')
COMMON_METRICS = ('load_seconds', 'prepare_seconds', 'startup_to_ready_seconds',
    'ttft_seconds', 'prefill_seconds', 'prefill_tokens_per_second',
    'full31_seconds', 'full31_tokens_per_second', 'warm7_31_seconds',
    'warm7_31_tokens_per_second')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


b = load('dual_performance_build_helpers', STAGE / 'build_current.py').b
c = b.c


def last_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8').splitlines()[-1])


def require_same(row):
    if not b.same(row):
        raise ValueError('Input drift or missing file: ' + row['path'])


def runtime_environment(build, peer, out):
    paths = [r['path'] for r in build['cached_inputs']] + [r['path'] for r in peer['inputs']]
    env, runtime = b.environment(build['links']['qwen']['command'], paths, out)
    for key in FORBIDDEN_ENV:
        if key in env:
            raise ValueError('Reference environment requires absent ' + key)
    return env, runtime


def execute(tag, command, env, out):
    if any(out.glob(tag + '.*')):
        raise ValueError('Refusing overwrite or implicit retry: ' + tag)
    return c.execute(tag, list(map(str, command)), env, out)


def prepare(build_path, relink_peer):
    build_path = build_path.resolve()
    build, peer, fair = c.read(build_path), c.read(PEER_PLAN), c.read(FAIR_PLAN)
    images = {}
    for arm, key in (('baseline', 'baseline'), ('current', 'qwen')):
        image = Path(build['links'][key]['image'])
        receipt = c.read(build_path.parent / (key + '-image.json'))
        require_same(receipt)
        if str(image.resolve()).casefold() != receipt['path'].casefold():
            raise ValueError('Linked image receipt differs: ' + arm)
        if c.read(build_path.parent / (key + '-link.result.json'))['exit'] != 0:
            raise ValueError('Hyle image link has no terminal-zero receipt')
        images[arm] = receipt
    if len(peer['inputs']) != 9 or len({r['path'].casefold() for r in peer['inputs']}) != 9:
        raise ValueError('Expected retained exact-nine-input peer closure')
    for row in peer['inputs']:
        require_same(row)
    fixtures = [fair[key] for key in ('prompt', 'fixed_inputs', 'tape')]
    for row in fixtures:
        require_same(row)
    fixed = c.read(fair['fixed_inputs']['path'])
    inputs = Path(fair['prompt']['path']).parent
    manifest = inputs / 'weights.tsv'
    lines = manifest.read_text(encoding='utf-8').splitlines()
    inventory = c.read(INVENTORY)
    if lines[0] != 'HYLE_QWEN35_TEXT_V1' or lines[2] != inventory['artifact_identity_sha256'] or len(lines[3:]) != 320:
        raise ValueError('Unexpected Hyle weight manifest')
    shard = Path(lines[1])
    source = next(r for r in inventory['files'] if r['path'] == shard.name)
    shard_row = {'path': str(shard.resolve()), 'bytes': source['size_bytes'], 'sha256': source['sha256']}
    model = c.read(MODEL_RECEIPT)
    require_same(shard_row)
    require_same(model)
    if (len(fixed['prompt_ids']) != 128 or len(fixed['decode_input_ids']) != 31 or
            list(map(int, Path(fair['prompt']['path']).read_text().split())) != fixed['prompt_ids'] or
            list(map(int, Path(fair['tape']['path']).read_text().split())) != fixed['decode_input_ids']):
        raise ValueError('Expected exactly the shared 128+31 fixed-input journey')
    expected = last_json(BASELINE_IDS)
    if len(expected['generated_ids']) != 32 or expected['decode_input_ids'] != fixed['decode_input_ids'] or expected['source_id'] != lines[2]:
        raise ValueError('Baseline ID receipt does not describe these inputs')
    hyle_tail = ['--inputs', str(inputs), '--decode-ids', fair['tape']['path'],
        '--steps', '32', '--capacity', '256', '--progress', 'direct', '--replay', 'prefer-capture']
    retained_tail = next(r['argv'][1:] for r in fair['requests'] if r['engine'] == 'hyle')
    if hyle_tail != retained_tail:
        raise ValueError('Fair Hyle consumer flags differ')
    PREPARED.mkdir(exist_ok=False)
    (PREPARED / 'tmp').mkdir()
    env, runtime = runtime_environment(build, peer, PREPARED)
    peer_image = PREPARED / 'peer.exe'
    peer_command = [x for x in peer['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    peer_command += ['/OUT:' + str(peer_image), '/MAP:' + str(peer_image.with_suffix('.map')),
                     '/IMPLIB:' + str(peer_image.with_suffix('.lib'))]
    c.save(PREPARED / 'peer-link-plan.json', {'command': peer_command, 'inputs': peer['inputs'],
        'compilations': 0, 'scope': 'Only output paths changed from retained nine-input closure'})
    if relink_peer:
        execute('peer-link', peer_command, env, PREPARED)
        images['llama'] = b.identity(peer_image)
        c.save(PREPARED / 'peer-image.json', images['llama'])
    else:
        images['llama'] = {'path': str(peer_image), 'missing': True}
    frozen_paths = [Path(__file__), STAGE / 'build_current.py', ARCH / 'cuda-projection-fusion/build.py',
        ARCH / 'cold-constant-retirement/cold_check.py', build_path, PEER_PLAN, FAIR_PLAN,
        MODEL_RECEIPT, INVENTORY, BASELINE_IDS, manifest]
    frozen = [b.identity(path) for path in frozen_paths] + fixtures + [shard_row, model]
    requests = []
    for index, arm in enumerate(ORDER, 1):
        tag = f'{index:02d}-{arm}'
        command = [images[arm]['path']] + (hyle_tail if arm != 'llama' else
            [model['path'], fair['fixed_inputs']['path'], '{output}/' + tag + '-peer-result.json'])
        requests.append({'arm': arm, 'tag': tag, 'command': command})
    result = {'schema_version': 1, 'status': 'prepared_not_run', 'build_plan': b.identity(build_path),
        'images': images, 'peer_inputs': peer['inputs'], 'frozen': frozen,
        'fixed': fixed, 'source_id': lines[2], 'expected_baseline_ids': expected['generated_ids'],
        'order': ORDER, 'requests': requests, 'runtime_paths': runtime,
        'source_or_SDK_compilations': 0, 'Hyle_links': 0, 'peer_links': int(relink_peer),
        'GPU_runs': 0, 'profiler': False, 'external_memory_monitor': False,
        'run_command_template': [sys.executable, str(Path(__file__).resolve()), '--run',
            '--numerical-proof', '{reviewed_numerical_summary.json}', '--reviewed-numerics'],
        'numerical_acceptance': 'Separate root-reviewed full-model numerical experiment; this runner records predictions and does not accept quality.',
        'metric_contract': {'warm7_31': 'decode7 through decode31 inclusive, exactly25steps',
            'step': 'Consumer input preparation through host token completion; includes upload/layout/bind/capture/submit/wait.',
            'load': 'Hyle weights_load_seconds versus peer model_load_seconds: different documented sub-boundaries.',
            'prepare': 'Hyle shape_prepare_seconds versus peer context_prepare_seconds: different work.',
            'ttft': 'Reported process-entry-to-first-host-token; includes startup and first-step work.'}}
    c.save(PREPARED / 'plan.json', result)
    print('PREPARED_NO_GPU', PREPARED / 'plan.json', flush=True)


def finite_positive(value):
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError('Nonpositive/nonfinite timing')
    return value


def scalar(text, key):
    values = re.findall(r'\b' + key + r'=([0-9.e+-]+)', text)
    if len(values) != 1:
        raise ValueError('Expected one timing field ' + key)
    return finite_positive(values[0])


def phase_metrics(seconds, load, prepare, ready, ttft):
    return {'load_seconds': load, 'prepare_seconds': prepare, 'startup_to_ready_seconds': ready,
        'ttft_seconds': ttft, 'prefill_seconds': seconds[0],
        'prefill_tokens_per_second': 128 / seconds[0], 'full31_seconds': sum(seconds[1:]),
        'full31_tokens_per_second': 31 / sum(seconds[1:]),
        'warm7_31_seconds': sum(seconds[7:]), 'warm7_31_tokens_per_second': 25 / sum(seconds[7:])}


def hyle_result(out, request, plan):
    tag = request['tag']
    observed = last_json(out / (tag + '.stdout.log'))
    text = (out / (tag + '.stderr.log')).read_text(encoding='utf-8')
    phases = re.findall(r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+).*?step_seconds=([0-9.e+-]+).*?next=(\d+)', text, re.M)
    expected = [('prefill', '128', '128')] + [('decode' + str(i), '1', str(128 + i)) for i in range(1, 32)]
    if ([r[:3] for r in phases] != expected or observed['decode_input_ids'] != plan['fixed']['decode_input_ids'] or
            not observed['fixed_decode'] or observed['source_id'] != plan['source_id'] or
            observed['visible_tokens'] != 159 or observed['text_tensors'] != 320 or
            len(observed['generated_ids']) != 32 or [int(r[4]) for r in phases] != observed['generated_ids']):
        raise ValueError('Hyle input/phase/output contract differs: ' + tag)
    seconds = [finite_positive(r[3]) for r in phases]
    captures = [list(map(int, r)) for r in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', text)]
    if len(captures) != 32:
        raise ValueError('Expected all32 Hyle capture reports')
    if request['arm'] == 'baseline' and observed['generated_ids'] != plan['expected_baseline_ids']:
        raise ValueError('Retained baseline predictions changed')
    values = phase_metrics(seconds, scalar(text, 'weights_load_seconds'), scalar(text, 'shape_prepare_seconds'),
                           scalar(text, 'startup_to_ready_seconds'), scalar(text, 'first_token_elapsed_seconds'))
    return {'metrics': values, 'phase_step_seconds': seconds, 'capture_counts': captures,
        'capture_recorded_total': sum(r[0] for r in captures), 'capture_reused_total': sum(r[1] for r in captures),
        'matches_retained_capture_journey': captures == [[7, 0]] * 3 + [[0, 7]] * 29,
        'generated_ids': observed['generated_ids'], 'decode_input_ids': observed['decode_input_ids'],
        'same_baseline_predictions': observed['generated_ids'] == plan['expected_baseline_ids'],
        'prediction_differences_from_baseline': [i for i, (a, e) in enumerate(zip(observed['generated_ids'], plan['expected_baseline_ids'])) if a != e]}


def peer_result(path, plan):
    result = c.read(path)
    phases = result['phases']
    if (result['llama_commit'] != PEER_COMMIT or result['context_capacity'] != 256 or
            result['configured_batch_capacity'] != 128 or result['kv_dtype'] != 'BF16' or
            result['flash_attention'] != 'enabled' or result['cuda_disable_graphs_env'] != '<absent>' or
            result['prompt_ids'] != plan['fixed']['prompt_ids'] or
            result['decode_input_ids'] != plan['fixed']['decode_input_ids'] or
            [r['phase'] for r in phases] != list(range(32)) or
            [r['input_tokens'] for r in phases] != [128] + [1] * 31 or
            [r['visible_tokens'] for r in phases] != list(range(128, 160)) or
            any(r['sampled_logits_elements'] != 248320 for r in phases) or
            len(result['predicted_ids']) != 32 or
            [r['predicted_id'] for r in phases] != result['predicted_ids']):
        raise ValueError('Peer reference/input/phase/readback contract differs')
    seconds = [finite_positive(r['step_seconds']) for r in phases]
    loading = result['loading']
    values = phase_metrics(seconds, finite_positive(loading['model_load_seconds']),
        finite_positive(loading['context_prepare_seconds']), finite_positive(loading['startup_to_ready_seconds']),
        finite_positive(loading['first_token_elapsed_seconds']))
    return {'metrics': values, 'loading': loading, 'phase_step_seconds': seconds,
        'capture_counts': None, 'capture_scope': 'Peer graphs enabled; no per-phase capture counter is exposed by this unchanged consumer.',
        'generated_ids': result['predicted_ids'], 'decode_input_ids': result['decode_input_ids'],
        'same_baseline_predictions': result['predicted_ids'] == plan['expected_baseline_ids'],
        'prediction_differences_from_baseline': [i for i, (a, e) in enumerate(zip(result['predicted_ids'], plan['expected_baseline_ids'])) if a != e],
        'sampling_D2H_per_phase': {'token_bytes': 4, 'sampled_logits_bytes': 993280}}


def run(prepared_path, output, numerical_proof):
    plan = c.read(prepared_path)
    if plan['status'] != 'prepared_not_run' or plan['order'] != ORDER:
        raise ValueError('Expected prepared nine-process rotation')
    for row in plan['frozen'] + plan['peer_inputs'] + list(plan['images'].values()):
        require_same(row)
    build, peer = c.read(plan['build_plan']['path']), c.read(PEER_PLAN)
    numerical_document = c.read(numerical_proof)
    if (numerical_document.get('schema') != 'hyle.qwen.dual_numerics.v1' or
            not numerical_document.get('diagnostic_complete') or
            not numerical_document.get('structural_checks', {}).get('passed') or
            not numerical_document.get('baseline_exact_reference')):
        raise ValueError('Expected completed structural numerical diagnosis and exact retained baseline')
    for arm in ('baseline', 'current'):
        if (numerical_document['images'][arm] != plan['images'][arm] or
                numerical_document['arms'][arm]['image'] != plan['images'][arm] or
                numerical_document['arms'][arm]['decode_input_ids'] != plan['fixed']['decode_input_ids'] or
                len(numerical_document['arms'][arm]['generated_ids']) != 32):
            raise ValueError('Numerical diagnosis does not describe these exact images/fixed inputs')
    numerical_proof = b.identity(numerical_proof.resolve())
    output = output.resolve()
    if not output.is_relative_to(STAGE) or output == STAGE or output == PREPARED:
        raise ValueError('Performance output must be a new child directory of this stage')
    output.mkdir(parents=True, exist_ok=False)
    (output / 'tmp').mkdir()
    env, runtime = runtime_environment(build, peer, output)
    c.save(output / 'inputs.json', {'prepared_plan': b.identity(prepared_path), 'images': plan['images'],
        'numerical_proof_reference': numerical_proof, 'operator_reviewed_numerics': True,
        'numerical_or_quality_acceptance_by_this_runner': False,
        'order': ORDER, 'runtime_paths': runtime, 'fixed_inputs': plan['fixed'],
        'profiler': False, 'external_memory_monitor': False, 'compiles': 0, 'links': 0})
    runs = []
    for request in plan['requests']:
        for row in plan['images'].values():
            require_same(row)
        command = [arg.replace('{output}', str(output)) for arg in request['command']]
        terminal = execute(request['tag'], command, env, output)
        observed = (peer_result(output / (request['tag'] + '-peer-result.json'), plan) if request['arm'] == 'llama'
                    else hyle_result(output, request, plan))
        reference_arm = 'baseline' if request['arm'] == 'llama' else request['arm']
        if observed['generated_ids'] != numerical_document['arms'][reference_arm]['generated_ids']:
            raise ValueError('Process predictions differ from its separately reviewed numerical journey')
        same_arm = [r for r in runs if r['arm'] == request['arm']]
        if any(r['generated_ids'] != observed['generated_ids'] or r['capture_counts'] != observed['capture_counts'] for r in same_arm):
            raise ValueError('Repeated image predictions or capture journey differ')
        row = {'arm': request['arm'], 'tag': request['tag'], 'pid': terminal['pid'],
            'exit': terminal['exit'], 'process_wall_seconds': terminal['finished'] - terminal['started'],
            'command': command, **observed}
        runs.append(row)
        c.save(output / 'runs.json', runs)
    groups = {arm: {key: {'samples': [r['metrics'][key] for r in runs if r['arm'] == arm],
        'median': statistics.median(r['metrics'][key] for r in runs if r['arm'] == arm),
        'min': min(r['metrics'][key] for r in runs if r['arm'] == arm),
        'max': max(r['metrics'][key] for r in runs if r['arm'] == arm)}
        for key in COMMON_METRICS} for arm in ('baseline', 'current', 'llama')}
    result = {'status': 'nine_fresh_unprofiled_processes_terminal_zero', 'terminal_zero': len(runs),
        'order': ORDER, 'groups': groups, 'images': plan['images'],
        'current_over_baseline': {k: groups['current'][k]['median'] / groups['baseline'][k]['median'] for k in COMMON_METRICS},
        'current_over_llama': {k: groups['current'][k]['median'] / groups['llama'][k]['median'] for k in COMMON_METRICS},
        'same_fixed_inputs_all9': True, 'predictions_deterministic_within_each_arm': True,
        'same_baseline_predictions_all9': all(r['same_baseline_predictions'] for r in runs),
        'capture_results': {arm: [r['capture_counts'] for r in runs if r['arm'] == arm] for arm in groups},
        'statistical_significance': False, 'independent_quality_acceptance': False,
        'profiler': False, 'external_memory_monitor': False, 'historical_timing_samples_used': 0,
        'metric_contract': plan['metric_contract'],
        'limits': ['Only three processes per image in one rotated window; process/cold-file/system drift remains possible.',
            'Same prompt, fixed decode inputs, capacity and same-source weights; predictions do not feed later inputs.',
            'Hyle compiles both shapes before prefill, peer graph maintenance remains inside step; use startup-to-token for cold comparison.',
            'Load and prepare sub-boundaries contain different work across engines; TTFT includes original consumer startup.',
            'Preparation hashes both complete model files; no OS file-cache eviction is performed and load times are not cold-disk measurements.',
            'Peer preserves GPU greedy and993280B sampled-logit readback plus4B token per phase; no payload/output contract was removed.',
            'Host step/process wall times include CPU work and synchronization; they are not pure GPU time.',
            'Prediction agreement and this fixed tape are not independent language-model quality acceptance.']}
    c.save(output / 'summary.json', result)
    print('NINE_PROCESS_ROTATION_COMPLETE', output / 'summary.json', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path, default=DEFAULT_BUILD)
    parser.add_argument('--relink-peer', action='store_true', help='Prepare only: link unchanged retained nine-input peer, no model run')
    parser.add_argument('--run', action='store_true', help='Explicitly start all nine model processes after separate numerical review')
    parser.add_argument('--prepared-plan', type=Path, default=PREPARED / 'plan.json')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--numerical-proof', type=Path, help='Record separate full-model numerical report identity; does not invent acceptance criteria')
    parser.add_argument('--reviewed-numerics', action='store_true', help='Operator has reviewed the independent numerical diagnosis; diagnostic_complete alone is not model acceptance')
    args = parser.parse_args()
    if args.run:
        if args.relink_peer:
            raise ValueError('Peer relinking belongs to preparation, not the timed rotation')
        if not args.numerical_proof or not args.reviewed_numerics:
            raise ValueError('--run requires --numerical-proof and explicit --reviewed-numerics; diagnostics alone do not accept the new math')
        out = args.output or STAGE / ('performance-rotation-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
        run(args.prepared_plan.resolve(), out, args.numerical_proof)
    else:
        if args.output or args.numerical_proof or args.reviewed_numerics:
            raise ValueError('--output/--numerical-proof/--reviewed-numerics apply only to --run')
        prepare(args.build_plan, args.relink_peer)


if __name__ == '__main__':
    main()
