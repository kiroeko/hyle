"""Three native and two host increments; unchanged SDK plus current CPU copy owners."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent;ARCH=STAGE.parent;ROOT=ARCH.parents[1]
spec=importlib.util.spec_from_file_location('dual_projection_build_base',ARCH/'cuda-projection-fusion/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
BASE=ARCH/'cuda-hot-prepare-selection/checks/20261019T082235'
CORE=ARCH/'cuda-hot-prepare-selection/checks/cpu-identity-20261019T082918'
GDN=ARCH/'cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236'
REGION=ARCH/'cuda-rms-candidate-frontier/checks/20261019T080921/region-identity.json'

def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]

def check(plan):
    for row in plan['frozen']+plan['cached_inputs']:
        if not b.same(row):raise ValueError('Input drift: '+row['path'])

def strip_ccbin(template):
    command=[];skip=False
    for item in template:
        if skip:skip=False;continue
        if item=='-ccbin':skip=True;continue
        command.append(item)
    return command

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',action='store_true');args=p.parse_args()
    out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S');out.mkdir(parents=True,exist_ok=False)
    freeze=c.read(STAGE/'native-source-freeze.json')
    frozen=[b.identity(x) for x in (Path(__file__),STAGE/'native-source-freeze.json',STAGE/'provider-version.h',
        ROOT/'third_party/ggml_cuda_runtime/patches.json',ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',ROOT/'cmake/HyleDependencyLock.json',
        ARCH/'cuda-gdn-l2-fusion/native-source/src/ggml-cuda/norm.cuh')]
    cached={};compiles=[];replacement={}
    for tag,path in (('ggml-cuda',GDN/'ggml-cuda-identity.json'),
        ('mmvf',ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/mmvf-identity.json'),
        ('unary',ARCH/'cuda-stable-silu/unary-identity.json')):
        recipe=c.read(path);source=STAGE/'native-source/src/ggml-cuda'/(tag+'.cu')
        if b.identity(source)['sha256']!=freeze['sources']['src/ggml-cuda/'+tag+'.cu']:raise ValueError('Native source differs')
        command=b.native_command(strip_ccbin(recipe['command']),source,tag,out)
        command[1:1]=['-I'+str(STAGE/'native-source/src'),'-I'+str(STAGE/'native-source/src/ggml-cuda')]
        if tag=='unary' and any('use_fast_math' in x for x in command):raise ValueError('Stable SiLU requires strict unary TU')
        compiles.append({'tag':tag,'kind':'native','command':command,'source':b.identity(source),'object':str(out/(tag+'.obj'))})
        replacement[c.key(recipe['object']['path'])]=str(out/(tag+'.obj'));frozen.extend((b.identity(path),b.identity(source)))
    frozen.append(b.identity(STAGE/'native-source/src/ggml-cuda/mmvf.cuh'))
    for tag,relative,path in (('provider','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',GDN/'provider-identity.json'),
        ('region','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',REGION)):
        recipe=c.read(path);template=recipe['command'];source=ROOT/relative
        if tag=='provider':template=['/FI'+str(STAGE/'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
        command=b.host_command(template,source,tag,out)
        compiles.append({'tag':tag,'kind':'host','command':command,'source':b.identity(source),'object':str(out/(tag+'.obj'))})
        replacement[c.key(recipe['object']['path'])]=str(out/(tag+'.obj'))
        frozen.extend((b.identity(path),b.identity(source)));frozen.extend(b.identity(x) for x in b.host_dependencies(template) if x.is_file())
    prior_path=BASE/'qwen-link-plan.json';prior=c.read(prior_path)
    if len(prior['inputs'])!=124:raise ValueError('Current baseline closure differs')
    for row in prior['inputs']:cached[row['path']]=row
    for key in replacement:
        if sum(c.key(row['path'])==key for row in prior['inputs'])!=1:raise ValueError('Replacement owner missing')
    core_transfer=c.read(CORE/'batch-transfer-identity.json')['object'];core_resource=c.read(CORE/'mem-resource-identity.json')['object']
    old_transfer=ARCH/'native-ragged-graph/validation/windows/src--compute--batch_transfer.obj'
    common=[core_transfer['path'] if c.key(x)==c.key(old_transfer) else x for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    if sum(c.key(x)==c.key(core_transfer['path']) for x in common)!=1:raise ValueError('CPU copy owner replacement missing')
    common[1:1]=[core_resource['path']]
    cached.update({row['path']:row for row in (core_transfer,core_resource)})
    frozen.append(b.identity(prior_path));links={}
    for name in ('baseline','qwen'):
        image=out/(name+'.exe');command=[replacement.get(c.key(x),x) if name=='qwen' else x for x in common]
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        if len(inputs(command))!=125:raise ValueError('Expected125-input core-corrected closure')
        links[name]={'command':command,'image':str(image),'inputs':inputs(command)}
    plan={'compile':compiles,'links':links,'cached_inputs':list(cached.values()),'frozen':list({r['path']:r for r in frozen}.values()),
        'native_TUs':3,'host_TUs':2,'SDK_build':False,'CMake_run':False,'native_source_id':freeze['source_id'],
        'baseline':'Previous native/provider objects; same current resource/copy objects added to both arms','tests_run':False}
    target=out/'plan.json';c.save(target,plan);check(plan);print('PLAN',target,flush=True)
    if not args.build:return
    (out/'tmp').mkdir();env,_=b.environment(links['qwen']['command'],list(cached),out)
    for row in compiles:
        c.execute(row['tag']+'-compile',row['command'],env,out);check(plan)
        c.save(out/(row['tag']+'-identity.json'),{'command':row['command'],'source':row['source'],'object':b.identity(row['object'])})
    for name,link in links.items():
        c.execute(name+'-link',link['command'],env,out);check(plan)
        c.save(out/(name+'-link-plan.json'),{'command':link['command'],'inputs':[b.identity(x) for x in link['inputs']]});c.save(out/(name+'-image.json'),b.identity(link['image']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':3,'host_TUs':2,'SDK_build':False,'GPU_run':False});print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
