"""Prepare (default), or run two fixed-token Qwen diagnostic replays with --run.
Baseline must retain the old64 vectors byte-for-byte. Current errors are reported,
not accepted by a new tolerance; this is not a language-model quality benchmark.
"""
from pathlib import Path
import argparse,csv,datetime as dt,hashlib,importlib.util,json,os,re,sys,traceback
sys.dont_write_bytecode=True
os.environ.update(OPENBLAS_NUM_THREADS='2',MKL_NUM_THREADS='2',OMP_NUM_THREADS='2')
import numpy as np
STAGE=Path(__file__).resolve().parent;ARCH=STAGE.parent;ROOT=ARCH.parents[1]
spec=importlib.util.spec_from_file_location('dual_numerics_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
REFERENCE=ARCH/'cuda-reshape-reuse'
PHASES=['prefill']+[f'decode{i}'for i in range(1,32)]
BUDGETS=[ARCH/'qwen-numerics/summary.json',ARCH/'qwen-fixed-decode/summary.json',
         ARCH/'qwen-fixed-decode/numerical-comparison.json']
def save(path,value):
 path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def identity(path):
 path=Path(path).resolve();h=hashlib.sha256()
 with path.open('rb')as stream:
  for chunk in iter(lambda:stream.read(8<<20),b''):h.update(chunk)
 return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
def final_json(path):
 return json.loads(next(line for line in reversed(path.read_text().splitlines())if line.strip().startswith('{')))
def vector(path):
 bits=np.fromfile(path,dtype='<u2'if path.suffix=='.bf16'else'<u4')
 values=(bits.astype('<u4')<<16).view('<f4')if path.suffix=='.bf16'else bits.view('<f4')
 return values.astype(np.float64),bits

def metrics(actual,reference):
 a,ab=vector(actual);r,rb=vector(reference)
 if a.shape!=r.shape:raise ValueError('Tensor length differs: '+str(actual))
 finite=np.isfinite(a)&np.isfinite(r);d=a[finite]-r[finite];v=r[finite]
 norm=float(np.dot(v,v));sq=float(np.dot(d,d));nonzero=v!=0
 width=16 if actual.suffix=='.bf16'else 32;sign=1<<(width-1)
 def order(bits):
  x=bits.astype(np.int64);return np.where(x&sign,sign-(x&(sign-1)),sign+x)
 ulp=np.abs(order(ab[finite])-order(rb[finite]))
 mismatch=np.flatnonzero(ab!=rb)
 return {'elements':int(a.size),'bit_equal_elements':int(np.count_nonzero(ab==rb)),
  'first_bit_mismatch':int(mismatch[0])if mismatch.size else None,
  'finite_pairs':int(finite.sum()),'candidate_nan':int(np.isnan(a).sum()),'reference_nan':int(np.isnan(r).sum()),
  'candidate_posinf':int(np.isposinf(a).sum()),'candidate_neginf':int(np.isneginf(a).sum()),
  'reference_posinf':int(np.isposinf(r).sum()),'reference_neginf':int(np.isneginf(r).sum()),
  'max_abs':float(np.abs(d).max())if d.size else None,
  'rms':float(np.sqrt(sq/d.size))if d.size else None,
  'relative_l2':float(np.sqrt(sq/norm))if norm else(0.0 if sq==0 else None),
  'max_relative_nonzero_reference':float(np.max(np.abs(d[nonzero]/v[nonzero])))if nonzero.any()else None,
  'zero_reference_nonzero_candidate':int(np.count_nonzero((v==0)&(d!=0))),
  'max_ulp':int(ulp.max())if ulp.size else None,'ulp_dtype':'BF16'if width==16 else'F32',
  'ulp_signed_zero':'positive/negative zero have distance0; raw bit equality still distinguishes them',
  'metric_domain':'finite pairs only; nonfinite counts separately reported'}

def routes(trace):
 result={}
 for t in (128,1):
  path=trace/'routes'/f'default-T{t}.route.tsv'
  with path.open(newline='')as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
  dual=[row for row in rows if row['kind']=='1'and row['provider']=='ggml-cuda'and row['implementation']=='4']
  if any(sorted(node.split(':',1)[1]for node in row['nodes'].split(','))!=['binary','matmul','matmul','unary']for row in dual):
   raise ValueError('impl4 does not contain exact public four-node recipe')
  result[str(t)]={'file':identity(path),'steps':len(rows),'impl4_count':len(dual),'impl4_steps':dual,
   'explicit_copy_steps':sum(row['kind']=='2'for row in rows),'copy_bytes':None,
   'copy_bytes_status':'Consumer TSV does not emit CompileReport copy_bytes; zero proposal cost or zero explicit Copy steps does not measure internal/native copies.'}
 return result

def analyze_arm(name,image,run,reference_vectors,reference_result):
 trace=run/'trace';paths=sorted(p.relative_to(trace)for p in trace.rglob('*')if p.suffix in('.bf16','.f32'))
 if paths!=list(reference_vectors):raise ValueError(name+' observation set differs from exact64 reference')
 result=final_json(run/'qwen.stdout.log');stderr=(run/'qwen.stderr.log').read_text()
 captures=[{'tokens':int(t),'visible':int(v),'replay':replay,'recorded':int(recorded),'reused':int(reused)}
  for t,v,replay,recorded,reused in re.findall(r'^prepared T=(\d+) visible=(\d+) replay=(\w+).*?capture_recorded=(\d+) capture_reused=(\d+)$',stderr,re.M)]
 workspace=[{'tokens':int(t),'steps':int(steps),'workspace_bytes_per_slot':int(size)}
  for t,steps,size in re.findall(r'^compiled T=(\d+) steps=(\d+) workspace/slot=(\d+)',stderr,re.M)]
 vectors=[]
 for path in paths:
  new=identity(trace/path);old=reference_vectors[path]
  vectors.append({'path':path.as_posix(),'actual':new,'reference':old,
   'byte_equal':new['bytes']==old['bytes']and new['sha256']==old['sha256'],
   'metrics':metrics(trace/path,Path(old['path']))})
 report={'image':image,'process':c.read(run/'qwen.result.json'),
  'generated_ids':result['generated_ids'],'decode_input_ids':result['decode_input_ids'],
  'source_id':result['source_id'],'text_tensors':result['text_tensors'],'visible_tokens':result['visible_tokens'],
  'fixed_decode':result['fixed_decode'],'same_greedy_ids_as_reference':result['generated_ids']==reference_result['generated_ids'],
  'same_fixed_decode_inputs':result['decode_input_ids']==reference_result['decode_input_ids'],
  'equal_vectors':sum(row['byte_equal']for row in vectors),'vectors':vectors,'routes':routes(trace),
  'workspace':workspace,'capture_counts':captures,
  'capture_32_phases_with_7_ranges':len(captures)==32 and all(row['recorded']+row['reused']==7 for row in captures),
  'all_outputs_finite':all(not any(row['metrics'][k]for k in('candidate_nan','candidate_posinf','candidate_neginf'))for row in vectors),
  'physical_fusion_verified':False,'physical_fusion_note':'Cold impl4 membership is selection evidence; a physical kernel trace is still required.'}
 if len(report['generated_ids'])!=32 or len(report['decode_input_ids'])!=31:raise ValueError('Fixed32phase ID count differs')
 save(run/'analysis.json',report);return report

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('plan',type=Path)
 parser.add_argument('--run',action='store_true');parser.add_argument('--out',type=Path);args=parser.parse_args()
 plan=c.read(args.plan);b.check(plan)
 if not c.read(args.plan.resolve().parent/'summary.json')['passed']:raise ValueError('Build/relink not successful')
 out=args.out.resolve()if args.out else STAGE/'numerics'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
 out.mkdir(parents=True,exist_ok=False)
 old_command=c.read(REFERENCE/'correctness-candidate.command.json')['command']
 inputs=Path(old_command[old_command.index('--inputs')+1]);decode=Path(old_command[old_command.index('--decode-ids')+1])
 weights=inputs/'weights.tsv';lines=weights.read_text().splitlines();model=Path(lines[1]);expected_artifact_id=lines[2]
 inventory_path=ROOT/'docs/implementation/tasks/compute/qwen35-2b-local-input.json';inventory=c.read(inventory_path)
 if expected_artifact_id!=inventory['artifact_identity_sha256']:raise ValueError('Inventory artifact identity differs')
 model_rows=[row for row in inventory['files']if row['path']==model.name]
 if len(model_rows)!=1:raise ValueError('Model shard inventory entry is missing/duplicated')
 model_record=model_rows[0]
 if model.stat().st_size!=model_record['size_bytes']:raise ValueError('Model shard size differs from inventory')
 if lines[0]!='HYLE_QWEN35_TEXT_V1'or len(lines[3:])!=320:raise ValueError('Weight inventory differs')
 reference_trace=REFERENCE/'correctness-candidate/trace'
 reference_vectors={p.relative_to(reference_trace):identity(p)for p in sorted(reference_trace.rglob('*'))if p.suffix in('.bf16','.f32')}
 if len(reference_vectors)!=64:raise ValueError('Reference does not contain64 observations')
 expected_paths={Path(phase)/name for phase in PHASES for name in('hidden.bf16','logits.f32')}
 if set(reference_vectors)!=expected_paths:raise ValueError('Reference phase/tensor names differ')
 reference_result=final_json(REFERENCE/'correctness-candidate.stdout.log')
 images={arm:identity(plan['links'][key]['image'])for arm,key in(('baseline','baseline'),('current','qwen'))}
 for arm,key in(('baseline','baseline'),('current','qwen')):
  if images[arm]!=c.read(args.plan.resolve().parent/(key+'-image.json')):raise ValueError('Image drift')
 frozen_inputs={'weights_manifest':identity(weights),'prompt_ids':identity(inputs/'prompt.ids'),'decode_ids':identity(decode),
  'model':{'path':str(model.resolve()),'bytes':model.stat().st_size,'expected_sha256':model_record['sha256']},
  'model_inventory':identity(inventory_path),'artifact_identity_sha256':expected_artifact_id,
  'build_plan':identity(args.plan),'runner':identity(Path(__file__)),
  'reference_command':identity(REFERENCE/'correctness-candidate.command.json'),
  'reference_result':identity(REFERENCE/'correctness-candidate.stdout.log'),
  'sources':plan['frozen'],'budget_evidence':[identity(path)for path in BUDGETS]}
 commands={}
 for arm in images:
  argv=list(old_command);argv[0]=images[arm]['path'];argv[argv.index('--trace')+1]=str(out/arm/'trace');commands[arm]=argv
 report={'schema':'hyle.qwen.dual_numerics.v1','diagnostic_complete':False,'quality_accepted':None,
  'quality_status':'diagnostic_only_no_predefined_model_budget','images':images,'inputs':frozen_inputs,
  'baseline_exact_reference':False,'arms':{},'commands':commands,
  'acceptance_limit':'Existing independent Torch qwen-numerics/summary.json and qwen-fixed-decode/numerical-comparison.json explicitly leave numerical/quality acceptance open. Their prompts/tapes differ; no pre-existing quantitative full-model budget applies here. No result-dependent tolerance is introduced.',
  'throughput_claim':False,'physical_fusion_verified':False}
 save(out/'plan.json',report);print('PLAN',out/'plan.json',flush=True)
 if not args.run:return
 try:
  actual_model=identity(model)
  if actual_model['sha256']!=model_record['sha256']or actual_model['bytes']!=model_record['size_bytes']:raise ValueError('Model shard SHA/size differs from local inventory')
  report['inputs']['model']=actual_model
  for arm in ('baseline','current'):
   run=out/arm;run.mkdir();(run/'tmp').mkdir()
   b.check(plan)
   if identity(images[arm]['path'])!=images[arm]:raise ValueError('Image changed before execution')
   env,_=b.b.environment(plan['links']['qwen']['command'],[row['path']for row in plan['cached_inputs']],run)
   c.execute('qwen',commands[arm],env,run)
   report['arms'][arm]=analyze_arm(arm,images[arm],run,reference_vectors,reference_result)
   if arm=='baseline':
    base=report['arms'][arm];report['baseline_exact_reference']=base['equal_vectors']==64 and base['same_greedy_ids_as_reference']and base['same_fixed_decode_inputs']
    if not report['baseline_exact_reference']:raise ValueError('Baseline failed exact old64vector/32greedy-ID/31input-ID parity; candidate not run')
  base,current=report['arms']['baseline'],report['arms']['current']
  checks={'baseline_exact_reference':report['baseline_exact_reference'],
   'same_model_and_input_ids':all(a['source_id']==expected_artifact_id and a['same_fixed_decode_inputs']and a['text_tensors']==320 and a['fixed_decode']for a in report['arms'].values()),
   'baseline_impl4_zero':all(row['impl4_count']==0 for row in base['routes'].values()),
   'current_impl4_decode24_prefill0':current['routes']['1']['impl4_count']==24 and current['routes']['128']['impl4_count']==0,
   'capture_counts':all(a['capture_32_phases_with_7_ranges']for a in report['arms'].values()),
   'workspace_reported':all({r['tokens']for r in a['workspace']}=={1,128}for a in report['arms'].values())}
  report['structural_checks']={'passed':all(checks.values()),**checks};report['diagnostic_complete']=True
  report['status']='diagnostics_complete_not_quality_acceptance'
  save(out/'summary.json',report)
  print('DIAGNOSTICS',out/'summary.json','baseline_equal64',report['baseline_exact_reference'],
        'current_equal',current['equal_vectors'],'current_same_greedy_ids',current['same_greedy_ids_as_reference'],flush=True)
  if not report['structural_checks']['passed']:raise ValueError('Structural observation differs; full diagnostic summary preserved')
 except Exception as error:
  report['error']=str(error);save(out/'summary.json',report)
  (out/'failure.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
if __name__=='__main__':
 try:main()
 except Exception as error:print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
