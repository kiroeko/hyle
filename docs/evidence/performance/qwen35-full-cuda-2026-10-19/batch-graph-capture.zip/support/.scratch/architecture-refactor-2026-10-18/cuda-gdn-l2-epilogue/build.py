"""Reuse v17 images/objects and increment only the scalar/L2 implementation."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('l2_prior_build', ARCH / 'cuda-explicit-rope/build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
b, c = previous.b, previous.c
V17 = ARCH / 'cuda-explicit-rope/checks/20261019T100154'
GDN = ARCH / 'cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236'


def check(plan):
    for row in plan['frozen'] + plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Source or retained input drift: ' + row['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    freeze = c.read(STAGE / 'native-source-freeze.json')
    frozen = [b.identity(p) for p in (Path(__file__), STAGE / 'native-source-freeze.json',
        STAGE / 'provider-version.h', STAGE / 'provider-source-freeze.json',
        STAGE / 'tests-source-freeze.json', ROOT / 'third_party/ggml_cuda_runtime/patches.json',
        ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md', ROOT / 'cmake/HyleDependencyLock.json')]
    for relative, expected in freeze['sources'].items():
        path = STAGE / 'native-source' / relative
        if b.identity(path)['sha256'] != expected:
            raise ValueError('Native overlay differs')
        frozen.append(b.identity(path))
    specs = (
        ('ggml-cuda', 'native', V17 / 'ggml-cuda-identity.json', STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'),
        ('norm', 'native', GDN / 'norm-identity.json', STAGE / 'native-source/src/ggml-cuda/norm.cu'),
        ('tensor-program', 'host', V17 / 'tensor-program-identity.json', ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'),
        ('provider', 'host', V17 / 'provider-identity.json', ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('gdn-l2-test', 'host', GDN / 'gdn-l2-test-identity.json', ROOT / 'tests/graph_provider_ggml_cuda/gdn_l2_fusion_test.cc'),
    )
    rows, replacements = [], {}
    for tag, kind, recipe_path, source in specs:
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Retained object differs: ' + tag)
        template = recipe['command']
        if kind == 'native':
            command = b.native_command(previous.original.strip_ccbin(template), source, tag, out)
            command[1:1] = ['-I' + str(STAGE / 'native-source/src'), '-I' + str(STAGE / 'native-source/src/ggml-cuda')]
            if tag == 'norm' and not any('use_fast_math' in x for x in command):
                raise ValueError('Norm must retain the original binary/reduction arithmetic flags')
        else:
            if tag == 'provider':
                template = ['/FI' + str(STAGE / 'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command = b.host_command(template, source, tag, out)
        rows.append({'tag': tag, 'kind': kind, 'command': command, 'source': b.identity(source), 'object': str(out / (tag + '.obj'))})
        replacements[c.key(recipe['object']['path'])] = str(out / (tag + '.obj'))
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    qwen, cuda = c.read(V17 / 'qwen-link-plan.json'), c.read(V17 / 'cuda-link-plan.json')
    cached = {c.key(row['path']): row for row in qwen['inputs'] + cuda['inputs']}
    baseline = c.read(V17 / 'qwen-image.json')
    if not b.same(baseline):
        raise ValueError('Retained v17 baseline image is unavailable')
    links = {'baseline': {'command': qwen['command'], 'image': baseline['path'], 'inputs': [r['path'] for r in qwen['inputs']]}}
    for tag, source, count in (('qwen', qwen, 124), ('cuda', cuda, 132)):
        present = {c.key(row['path']) for row in source['inputs']}
        if len(present.intersection(replacements)) != (4 if tag == 'qwen' else 5):
            raise ValueError('Unexpected replacement owner set: ' + tag)
        for owner in present.intersection(replacements):
            if sum(c.key(x) == owner for x in source['command']) != 1:
                raise ValueError('Duplicate replacement owner')
        command = [replacements.get(c.key(x), x) for x in source['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = previous.original.inputs(command)
        if len(inputs) != count or len({c.key(x) for x in inputs}) != count:
            raise ValueError('Input closure changed')
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    frozen.append(baseline)
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(r['path']): r for r in frozen}.values()),
        'native_TUs': 2, 'host_TUs': 3, 'SDK_build': False, 'CMake_run': False,
        'native_source_id': freeze['source_id'], 'GPU_run': False, 'baseline_image_reused': True}
    target = out / 'plan.json'
    c.save(target, plan)
    check(plan)
    print('PLAN', target, flush=True)
    if not args.build:
        return
    (out / 'tmp').mkdir()
    env, _ = b.environment(links['qwen']['command'], [row['path'] for row in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'], 'source': row['source'], 'object': b.identity(row['object'])})
    for tag in ('qwen', 'cuda'):
        link = links[tag]
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'], 'inputs': [b.identity(x) for x in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    c.save(out / 'baseline-image.json', baseline)
    for before, after in (('qwen-link-plan.json', 'baseline-link-plan.json'), ('qwen-link.result.json', 'baseline-link.result.json')):
        (out / after).write_bytes((V17 / before).read_bytes())
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 2, 'host_TUs': 3, 'SDK_build': False, 'GPU_run': False, 'baseline_image_reused': True})
    print('BUILD_COMPLETE', target, flush=True)


if __name__ == '__main__':
    main()
