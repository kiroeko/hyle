"""Plan four incremental TUs and candidate/control links; --build executes only those."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'batch-layout-query-reuse/checks/20261019T120828-test-define'
ALLOCATION = ARCH / 'cuda-fusion-allocation/checks/20261019T115201'
HEADERS = ARCH / 'cuda-fusion-precision/native-source'
spec = importlib.util.spec_from_file_location('grouped_allocation_helpers', ARCH / 'cuda-fusion-allocation/build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c = a.b, a.c
check, check_cached = a.check, a.check_cached


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    freeze = c.read(STAGE / 'native-source-freeze.json')
    reviewed = c.read(STAGE / 'source-freeze.json')
    tests = c.read(STAGE / 'tests-source-freeze.json')
    test_plan = c.read(STAGE / 'tests-plan.json')
    native = STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'
    if b.identity(native)['sha256'] != freeze['sources']['src/ggml-cuda/ggml-cuda.cu']:
        raise ValueError('Sealed native main differs')
    if b.identity(native)['sha256'] != c.read(STAGE / 'native-overlay/source-freeze.json')['after_sha256']:
        raise ValueError('Sealed main differs from reviewed native overlay')
    version = (STAGE / 'provider-version.h').read_text(encoding='utf-8-sig')
    if len(re.findall(r'^\s*#\s*define\s+HYLE_GGML_CUDA_PROVIDER_VERSION\b', version, re.M)) != 1 or freeze['source_id'] not in version:
        raise ValueError('Provider FI must contain exactly one current native identity')
    for row in reviewed['files']:
        actual = b.identity(ROOT / row['product'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied reviewed host source differs: ' + row['product'])
    for row in tests['files']:
        actual = b.identity(ROOT / row['target'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied test source differs: ' + row['target'])
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = [b.identity(path) for path in (
        Path(__file__), ARCH / 'cuda-fusion-allocation/build.py',
        Path(b.__file__), Path(c.__file__),
        STAGE / 'native-source-freeze.json', STAGE / 'native-overlay/source-freeze.json',
        STAGE / 'source-freeze.json', STAGE / 'tests-source-freeze.json',
        STAGE / 'tests-plan.json', STAGE / 'provider-version.h',
        ROOT / 'src/compute_provider_ggml_cuda/tensor_program.h',
        ROOT / 'src/compute_provider_ggml_cuda/native_bridge.h',
        ROOT / 'src/compute_provider_ggml_cuda/native_bridge_impl.h',
        ROOT / 'src/compute_provider_ggml_cuda/CMakeLists.txt',
        ROOT / 'tests/graph_route_cuda/CMakeLists.txt',
        ROOT / 'third_party/ggml_cuda_runtime/patches.json',
        ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT / 'cmake/HyleDependencyLock.json')]
    if (STAGE / 'application.json').is_file():
        frozen.append(b.identity(STAGE / 'application.json'))
    receipt = ARCH / 'cuda-fusion-precision/header-closure.json'
    frozen.append(b.identity(receipt))
    headers = c.read(receipt)
    if headers['header_count'] != 89:
        raise ValueError('Expected existing coherent89-header closure')
    for row in headers['headers']:
        identity = b.identity(HEADERS / row['path'])
        if identity['sha256'] != row['sha256']:
            raise ValueError('Reused coherent GGML header differs')
        frozen.append(identity)
    provider = ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
    lowerer = ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'
    stable_test = ROOT / 'tests/graph_route_cuda/stable_silu_test.cc'
    specifications = (
        ('ggml-cuda', 'native', ALLOCATION / 'ggml-cuda-identity.json', native),
        ('provider', 'host', ALLOCATION / 'provider-identity.json', provider),
        ('tensor-program', 'host', ARCH / 'recurrent-gdn-schema/checks/20261019T113131/22-compute_provider_ggml_cuda-tensor_program-identity.json', lowerer),
        ('stable-test', 'host', ALLOCATION / 'stable-test-identity.json', stable_test),
    )
    rows, replacements, retained_owners = [], {}, {}
    for tag, kind, recipe_path, source in specifications:
        recipe = c.read(recipe_path)
        template = recipe['command']
        if kind == 'native':
            command = a.strip_ccbin(b.native_command(a.strip_ccbin(template), source, tag, out))
            command = [value for value in command if not (value.startswith('-I') and
                ('architecture-refactor-2026-10-18' in value or 'reference-windows' in value))]
            command[1:1] = ['-I' + str(HEADERS / 'include'), '-I' + str(HEADERS / 'src'),
                            '-I' + str(HEADERS / 'src/ggml-cuda')]
        else:
            forced = [value for value in template if value.lower().startswith('/fi')]
            if tag == 'provider' and len(forced) != 1:
                raise ValueError('Expected one provider identity FI')
            if any('provider-version.h' not in value.replace('\\', '/') for value in forced):
                raise ValueError('Unexpected forced include in retained host recipe')
            template = ['/FI' + str(STAGE / 'provider-version.h') if value.lower().startswith('/fi') else value for value in template]
            command = b.host_command(template, source, tag, out)
            command = [value for value in command if not (value.lower().startswith(('/i', '/external:i')) and
                ('reference-windows' in value or 'cuda-fusion-precision/native-source' in value.replace('\\', '/')))]
            command[1:1] = ['/external:I' + str(HEADERS / 'include'), '/external:I' + str(HEADERS / 'src')]
            frozen.extend(b.identity(path) for path in b.host_dependencies(template))
        obj = str(out / (tag + '.obj'))
        rows.append({'tag': tag, 'kind': kind, 'source': b.identity(source), 'command': command, 'object': obj})
        old = c.key(recipe['object']['path'])
        replacements[old] = obj
        retained_owners[old] = recipe['object']
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    frozen.extend(b.identity(path) for path in a.hyle_literal_dependencies([provider, lowerer, stable_test]))
    links, cached = {}, {}
    for tag, base_tag, count, expected in (
            ('cuda', 'cuda', 133, {'ggml-cuda', 'provider', 'tensor-program', 'stable-test'}),
            ('qwen', 'qwen', 125, {'ggml-cuda', 'provider', 'tensor-program'}),
            ('control-cuda', 'cuda', 133, {'stable-test'})):
        path = BASE / (base_tag + '-link-plan.json')
        base = c.read(path)
        frozen.append(b.identity(path))
        present = {c.key(row['path']) for row in base['inputs']}
        if len(base['inputs']) != count or len(present) != count:
            raise ValueError('Latest base link closure differs: ' + tag)
        for row in base['inputs']:
            key = c.key(row['path'])
            if key in cached and (cached[key]['bytes'], cached[key]['sha256']) != (row['bytes'], row['sha256']):
                raise ValueError('Base links disagree about retained input: ' + row['path'])
            cached[key] = row
        chosen = {old: new for old, new in replacements.items() if
                  next(row['tag'] for row in rows if row['object'] == new) in expected}
        if len(chosen) != len(expected) or not set(chosen).issubset(present):
            raise ValueError('Exact replacement set differs: ' + tag)
        for owner in chosen:
            if sum(c.key(value) == owner for value in base['command']) != 1:
                raise ValueError('Nonunique linked owner: ' + tag)
            if cached[owner]['sha256'] != retained_owners[owner]['sha256']:
                raise ValueError('Recipe object differs from linked owner: ' + tag)
        command = [chosen.get(c.key(value), value) for value in base['command']
                   if not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = a.prior.prior.prior.inputs(command)
        if len(inputs) != count or len(set(map(c.key, inputs))) != count:
            raise ValueError('Final link input closure differs: ' + tag)
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs,
                      'replacement_tags': sorted(expected), 'base': str(path)}
    plan = {
        'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(row['path']): row for row in frozen}.values()),
        'native_TUs': 1, 'host_TUs': 3, 'SDK_build': False, 'CMake_run': False, 'GPU_run': False,
        'native_source_id': freeze['source_id'], 'test_filter': test_plan['filter'],
        'exact_tests': test_plan['cases'], 'reused_coherent_GGML_headers': 89,
        'native_private_by_value_ABI_changed': False,
        'refresh_scope': 'Only main, provider, tensor lowerer and existing stable-test TU. Control keeps all old production objects and replaces only the test object.',
    }
    path = out / 'plan.json'
    c.save(path, plan)
    a.check(plan)
    a.check_cached(plan)
    print('PLAN', path, flush=True)
    if not args.build:
        return
    env, _ = b.environment(links['qwen']['command'], links['qwen']['inputs'], out)
    fresh = []
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        a.check(plan)  # Only frozen sources/headers, not retained large libraries.
        if row['kind'] == 'native':
            dependencies = (out / (row['tag'] + '.d')).read_text(encoding='utf-8').replace('\\', '/')
            if 'cuda-fusion-precision/native-source/src/ggml-cuda/common.cuh' not in dependencies:
                raise ValueError('Fresh main did not use coherent GGML headers')
        identity = b.identity(row['object'])
        fresh.append(identity)
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': identity})
    for tag, link in links.items():
        c.execute(tag + '-link', link['command'], env, out)
        a.check(plan)
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    a.check_cached(plan)  # Terminal verification of old objects/libraries.
    for row in fresh:
        if not b.same(row):
            raise ValueError('Fresh object drifted during link: ' + row['path'])
    identities = {c.key(row['path']): row for row in [*plan['cached_inputs'], *fresh]}
    for tag, link in links.items():
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'],
            'inputs': [identities[c.key(value)] for value in link['inputs']]})
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 1, 'host_TUs': 3,
        'SDK_build': False, 'GPU_run': False, 'control_old_production': True,
        'native_source_id': freeze['source_id']})
    print('BUILD_COMPLETE', path, flush=True)


if __name__ == '__main__':
    main()
