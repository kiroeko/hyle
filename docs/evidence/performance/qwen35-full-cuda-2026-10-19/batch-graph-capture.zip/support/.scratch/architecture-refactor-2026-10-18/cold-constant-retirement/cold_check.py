"""Explicit CPU graph fault-test closure; default action only writes a plan.

Examples (no compiler, linker, or test process without a mode flag):
  python cold_check.py --source tests/graph/region_provider_test.cc \
      --target-test GraphPacking.SomeExactCase
  python cold_check.py --source src/graph/constant_artifact.cc \
      --source tests/graph/constant_artifact_cache_test.cc \
      --target-test CanonicalConstantCache.SomeExactCase --build
  # --test builds the same explicit sources/closure, then runs exact names only.

This driver does not infer a header/ABI rebuild closure. Inspect the recorded
source/dependency drift and explicitly list every owner that must be rebuilt.
It never invokes CMake, builds an SDK, copies dependencies, or runs a suite.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import uuid
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
LINK_PLAN = ARCH / "cuda-stable-silu/cpu-tests-link-plan.json"
# A null old object adds a test TU absent from the recorded link closure.
RECIPES = {
    "src/graph/executable.cc": (
        "cuda-stable-silu/graph-identity.json", None,
        "cuda-stable-silu/graph.obj"),
    "src/graph/constant_artifact.cc": (
        "cuda-capture-reuse/validation/graph--constant_artifact-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--constant_artifact-v2.obj"),
    "tests/graph/region_provider_test.cc": (
        "cuda-stable-silu/control-test-identity.json", None,
        "cuda-stable-silu/control-test.obj"),
    "tests/graph/constant_artifact_cache_test.cc": (
        "canonical-constants-cache/commands.json", "constant_artifact_cache_test-compile", None),
    "src/graph/input_sources.cc": (
        "cuda-capture-reuse/validation/graph--input_sources-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--input_sources-v2.obj"),
    "src/graph/region_access.cc": (
        "cuda-capture-reuse/validation/graph--region_access-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--region_access-v2.obj"),
    "src/graph/resources.cc": (
        "cuda-capture-reuse/validation/graph--resources-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--resources-v2.obj"),
    "src/graph/resource_report.cc": (
        "cuda-capture-reuse/validation/graph--resource_report-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--resource_report-v2.obj"),
    "src/graph/submission.cc": (
        "cuda-capture-reuse/validation/graph--submission-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph--submission-v2.obj"),
    "src/graph_progress/progress.cc": (
        "cuda-capture-reuse/validation/graph_progress--progress-v2-identity.json", None,
        "cuda-capture-reuse/validation/graph_progress--progress-v2.obj"),
    "src/graph_route_cpu/ggml_region.cc": (
        "cuda-stable-silu/cpu-region-identity.json", None,
        "cuda-stable-silu/cpu-region.obj"),
    "src/graph_provider_onednn/onednn_region_provider.cc": (
        "cuda-stable-silu/onednn-region-identity.json", None,
        "cuda-stable-silu/onednn-region.obj"),
    "src/compute/resource_budget.cc": (
        "cold-constant-retirement/resource-budget-compile-recipe.json", None, None),
}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def snapshot(path, digest=False):
    path = Path(path).resolve()
    row = {"path": str(path), "exists": path.is_file()}
    if not row["exists"]:
        return row
    stat = path.stat()
    row.update(bytes=stat.st_size, mtime_ns=stat.st_mtime_ns,
               mtime_utc=dt.datetime.fromtimestamp(stat.st_mtime, dt.timezone.utc).isoformat())
    if digest:
        sha = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                sha.update(block)
        row["sha256"] = sha.hexdigest()
    return row


def key(path):
    return str(Path(path).resolve()).casefold()


def recipe(name):
    receipt, tag, old = RECIPES[name]
    path = ARCH / receipt
    document = read(path)
    if tag:
        document = next(row for row in document if row.get("tag") == tag)
        if document.get("exit") != 0:
            raise ValueError("Recipe is not a successful command: " + str(path))
    command = document["command"]
    sources = [Path(x).resolve() for x in command if x.lower().endswith(".cc")]
    if sources != [(ROOT / name).resolve()]:
        raise ValueError("Recipe source mismatch: " + name)
    return path, document, ARCH / old if old else None


def compile_command(template, source, stem, output):
    command, skip = [], False
    for arg in template:
        if skip:
            skip = False
            continue
        if arg.lower() == "/sourcedependencies":
            skip = True
        elif arg.lower().startswith(("/fo", "/fd")) or arg.lower().endswith(".cc"):
            continue
        else:
            command.append(arg)
    command += ["/sourceDependencies", str(output / (stem + "-deps.json")),
                str(source), "/Fo" + str(output / (stem + ".obj")),
                "/Fd" + str(output / (stem + ".pdb"))]
    return command


def environment(command, inputs, output):
    sys.path.insert(0, str(ROOT / "scripts"))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({"CMAKE_CXX_COMPILER":
                                        str(Path(command[0]).with_name("cl.exe"))})
    env["VSLANG"] = "1033"
    directories = list(dict.fromkeys(str(Path(x).parent) for x in inputs))
    env["PATH"] = os.pathsep.join(directories) + os.pathsep + env.get("PATH", "")
    env["TEMP"] = env["TMP"] = str(output / "tmp")
    return env, directories


def sdk_libraries(command, env):
    search = [Path(x) for x in env.get("LIB", "").split(os.pathsep) if x]
    rows = []
    for arg in command:
        path = Path(arg)
        if arg.startswith("/") or path.is_absolute() or path.suffix.lower() != ".lib":
            continue
        resolved = next((directory / path for directory in search
                         if (directory / path).is_file()), None)
        rows.append({"argument": arg, "resolved": snapshot(resolved) if resolved else None})
    return rows


def execute(tag, command, env, output):
    row = {"tag": tag, "command": command, "cwd": str(ROOT),
           "started": time.time(), "exit": None}
    save(output / (tag + ".command.json"), row)
    with (output / (tag + ".stdout.log")).open("wb") as so, \
            (output / (tag + ".stderr.log")).open("wb") as se:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row["pid"] = process.pid
        save(output / "live.json", row)
        print("START", tag, "PID", process.pid, flush=True)
        row["exit"] = process.wait()
    row.update(finished=time.time(), terminal=True)
    save(output / (tag + ".result.json"), row)
    save(output / "live.json", row)
    print("END", tag, "exit", row["exit"], flush=True)
    if row["exit"]:
        raise RuntimeError(tag + " failed; inspect " + str(output))
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--source", action="append", required=True,
                        help="Explicit registered repository .cc path; repeat as needed")
    parser.add_argument("--target-test", action="append", required=True,
                        help="Exact Suite.Case; repeat for more than one CPU case; no wildcards")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="Only inventory and plan (default)")
    mode.add_argument("--build", action="store_true", help="Compile listed sources and link only")
    mode.add_argument("--test", action="store_true", help="Build, then run exact target-test names")
    args = parser.parse_args()
    names = []
    for value in args.source:
        source = Path(value)
        source = (ROOT / source).resolve() if not source.is_absolute() else source.resolve()
        try:
            name = source.relative_to(ROOT).as_posix()
        except ValueError:
            parser.error("source must be inside this repository: " + value)
        if name not in RECIPES:
            parser.error("No reviewed cache recipe for " + name + "; registered: " + ", ".join(RECIPES))
        if name in names:
            parser.error("duplicate source: " + name)
        names.append(name)
    tests = args.target_test
    if len(set(tests)) != len(tests) or any(not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*\.[A-Za-z_][A-Za-z_0-9]*", x) for x in tests):
        parser.error("target-test must contain unique exact Suite.Case names, without patterns")
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    output = STAGE / "checks" / session
    output.mkdir(parents=True, exist_ok=False)
    original = read(LINK_PLAN)
    command = original["command"]
    absolute_inputs = [x for x in command if not x.startswith("/") and Path(x).is_absolute()
                       and Path(x).suffix.lower() in (".obj", ".lib")]
    recorded = {key(row["path"]): row for row in original["inputs"]}
    closure = []
    for path in absolute_inputs:
        row = snapshot(path, Path(path).suffix.lower() == ".obj")
        old = recorded.get(key(path), {})
        row["recorded_bytes"] = old.get("bytes")
        row["recorded_sha256"] = old.get("sha256")
        row["recorded_hash_matches"] = (row.get("sha256") == old.get("sha256")
                                          if "sha256" in row else None)
        closure.append(row)
    env, runtime_paths = environment(command, absolute_inputs, output)
    sdk = sdk_libraries(command, env)
    missing = [row["path"] for row in closure if not row["exists"]]
    missing += [row["argument"] for row in sdk if row["resolved"] is None]
    inventory, compiles, replacements, additions = [], [], {}, []
    for name in RECIPES:
        path, document, old_object = recipe(name)
        source = snapshot(ROOT / name, True)
        cached = snapshot(old_object) if old_object else None
        row = {"source": source, "selected": name in names,
               "recipe": snapshot(path, True), "cached_object": cached,
               "cached_source": document.get("source"),
               "source_newer_than_object": (source["mtime_ns"] > cached["mtime_ns"]
                   if cached and cached["exists"] else None),
               "source_hash_matches_receipt": (source["sha256"] == document["source"]["sha256"]
                   if document.get("source") else None),
               "changed_recorded_dependencies": []}
        for dependency in document.get("current_hyle_dependency_identities", []):
            actual = snapshot(dependency["path"], True)
            if actual.get("sha256") != dependency["sha256"]:
                row["changed_recorded_dependencies"].append({"before": dependency, "current": actual})
        inventory.append(row)
        if name not in names:
            continue
        stem = name.removesuffix(".cc").replace("/", "--")
        argv = compile_command(document["command"], ROOT / name, stem, output)
        object_path = str(output / (stem + ".obj"))
        if old_object:
            if sum(key(x) == key(old_object) for x in absolute_inputs) != 1:
                raise ValueError("Expected exactly one replaceable input: " + str(old_object))
            replacements[key(old_object)] = object_path
        else:
            additions.append(object_path)
        compiles.append({"source_name": name, "source": source, "command": argv,
                         "object": object_path, "stem": stem})
    linked = [replacements.get(key(arg), arg) if not arg.startswith("/") else arg for arg in command
              if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    linked += additions + ["/OUT:" + str(output / "cold-tests.exe"),
                           "/MAP:" + str(output / "cold-tests.map"),
                           "/IMPLIB:" + str(output / "cold-tests.lib")]
    plan = {"mode": "test" if args.test else "build" if args.build else "dry-run",
            "base_link_plan": snapshot(LINK_PLAN, True), "absolute_inputs": closure,
            "named_sdk_libraries": sdk, "missing_inputs": missing,
            "source_inventory": inventory, "compile": compiles, "link": linked,
            "exact_tests": tests, "runtime_path_directories": runtime_paths,
            "sources_are_explicit": True, "header_rebuild_closure_inferred": False,
            "dependency_copy": False, "sdk_build": False,
            "freshness_note": "Source/dependency drift is recorded, not automatically repaired. Caller owns the explicit ABI rebuild closure."}
    save(output / "plan.json", plan)
    print(json.dumps({"plan": str(output / "plan.json"), "mode": plan["mode"],
                      "inputs": len(closure), "named_sdk_libraries": len(sdk),
                      "missing": missing, "compile_sources": names, "exact_tests": tests}), flush=True)
    if missing:
        raise ValueError("Cached link closure has missing inputs")
    if not (args.build or args.test):
        return
    (output / "tmp").mkdir()
    for item in compiles:
        if snapshot(item["source"]["path"], True)["sha256"] != item["source"]["sha256"]:
            raise ValueError("Selected source changed after planning: " + item["source_name"])
        execute(item["stem"] + "-compile", item["command"], env, output)
        if snapshot(item["source"]["path"], True)["sha256"] != item["source"]["sha256"]:
            raise ValueError("Selected source changed during compile: " + item["source_name"])
        save(output / (item["stem"] + "-identity.json"),
             {"source": item["source"], "object": snapshot(item["object"], True),
              "command": item["command"]})
    execute("link", linked, env, output)
    save(output / "image.json", snapshot(output / "cold-tests.exe", True))
    if args.test:
        execute("tests", [str(output / "cold-tests.exe"), "--gtest_color=no",
                          "--gtest_filter=" + ":".join(tests),
                          "--gtest_output=xml:" + str(output / "tests.xml")], env, output)
        xml = ET.parse(output / "tests.xml").getroot()
        cases = xml.findall(".//testcase")
        actual = [row.attrib["classname"] + "." + row.attrib["name"] for row in cases]
        if sorted(actual) != sorted(tests) or xml.findall(".//failure") or xml.findall(".//skipped"):
            raise ValueError("Exact selected tests absent, failed or skipped")
        save(output / "tests-summary.json", {"cases": actual, "failures": 0, "skipped": 0})


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, StopIteration) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
