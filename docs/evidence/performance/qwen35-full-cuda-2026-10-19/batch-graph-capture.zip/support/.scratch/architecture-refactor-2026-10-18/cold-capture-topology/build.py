"""Refresh eight private PlanState owners and two CPU fixtures, reusing all SDKs."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
spec=importlib.util.spec_from_file_location('capture_topology_helpers',ARCH/'cuda-grouped-fusion/build.py')
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
b,c=helper.b,helper.c
CPU=ARCH/'mlx-affine-widths/common/checks/current'
QWEN=ARCH/'mlx-affine-widths/cuda/checks/20261019T135721'
EXACT_TESTS=[
 'GraphViews.MetadataOnlyChainNeedsNoProviderOrPreparationBudget',
 'GraphViews.EveryExactCompileAllocationFailureCleansUpAndRetries',
 'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves',
 'GraphRegions.PreparedReplayCanHaveDelegatedOwnership',
 'GraphRegions.PreparedReplayChecksReplacedQueueOwnerAndClosedContext',
 'GraphRegions.BorrowedCaptureLaunchUsesOriginalAdmissionAndRejectsForeignContext',
 'GraphRegions.CapturesCompatibleRangesAroundAnUncapturableCommandInOneSequence',
 'GraphRegions.CapturesAndReplaysACommandSegmentWithoutRewalkingItsSteps',
 'GraphRegions.ReadyOnlyRegionCarriesControlDependenciesWithoutItsOwnQueue',
 'GraphRegions.ReadyOnlyRegionAndViewsExecuteWithoutAnyQueue',
 'GraphRegions.RejectFallbackPolicyRequiresCompleteRegionCoverage',
 'GraphRegions.SchedulesAContractedNodeSetAfterItsExternalPredecessor',
]
def check(frozen):
    for row in frozen:
        if not b.same(row): raise ValueError('Frozen source/recipe drift: '+row['path'])
def link_inputs(command):
    return [str(Path(x)) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()]
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true')
    args=parser.parse_args()
    out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    seal=c.read(STAGE/'source-freeze.json')
    for row in seal['files']:
        actual=b.identity(ROOT/row['source'])
        if actual['sha256']!=row['after']['sha256']: raise ValueError('Product source differs from seal')
    recipes=c.read(ARCH/'immutable-alias-index/host-recipes.json')
    cpu=c.read(CPU/'cpu-link-plan.json');qwen=c.read(QWEN/'qwen-link-plan.json')
    baseline=c.read(QWEN/'qwen-image.json')
    if not b.same(baseline): raise ValueError('Retained Qwen baseline differs')
    frozen=[b.identity(p) for p in [Path(__file__),STAGE/'source-freeze.json',
        ROOT/'src/graph/plan_state.h',ARCH/'immutable-alias-index/host-recipes.json',
        CPU/'cpu-link-plan.json',QWEN/'qwen-link-plan.json']]
    rows=[];replacements={}
    for index,row in enumerate(recipes['compile'][:8]+[recipes['compile'][9],recipes['compile'][10]]):
        source=ROOT/row['source_name'];tag=str(index)+'-'+source.stem
        old=(ARCH/'decode-host-path-review/checks/20261019T132925/resources.obj' if index==4
             else ARCH/'immutable-alias-index/checks/20261019T111822'/(str(index)+'-'+source.stem+'.obj')) if index<8 else None
        target=out/(tag+'.obj')
        rows.append(dict(tag=tag,source=b.identity(source),object=str(target),
            command=b.host_command(row['command_template'],source,tag,out),old_object=str(old) if old else None))
        frozen.append(b.identity(source))
        if old: replacements[c.key(str(old))]=str(target)
        snapshot=STAGE/'source'/row['source_name']
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        if snapshot.exists() and snapshot.read_bytes()!=source.read_bytes(): raise ValueError('Source snapshot differs')
        snapshot.write_bytes(source.read_bytes());frozen.append(b.identity(snapshot))
    cached={c.key(row['path']):row for row in cpu['inputs']+qwen['inputs']}
    links={}
    audits={}
    for tag,base in [('cpu',cpu),('qwen',qwen)]:
        present={c.key(x['path']) for x in base['inputs']}
        assert set(replacements)<=present,(tag,'replacement missing')
        forbidden=[x['path'] for x in base['inputs'] if any(s in Path(x['path']).name.lower()
            for s in ['aggregate_native_retirement','constant_artifact_cache_test'])]
        assert not forbidden,forbidden
        command=[replacements.get(c.key(x),x) for x in base['command']
            if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if tag=='cpu': command[1:1]=[row['object'] for row in rows[8:]]
        image=out/(tag+'.exe')
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=link_inputs(command)
        assert len(inputs)==(114 if tag=='cpu' else 127) and len(set(map(c.key,inputs)))==len(inputs)
        links[tag]=dict(command=command,image=str(image),inputs=inputs)
        audits[tag]=dict(base_inputs=len(base['inputs']),result_inputs=len(inputs),private_test_owners=forbidden)
    links['baseline']=dict(command=qwen['command'],image=baseline['path'],inputs=[x['path'] for x in qwen['inputs']])
    plan=dict(compile=rows,links=links,frozen=frozen,cached_inputs=list(cached.values()),
        private_ABI_owners=8,host_TUs=10,native_TUs=0,SDK_build=False,GPU_run=False,
        input_audit=audits,exact_tests=EXACT_TESTS)
    c.save(out/'plan.json',plan);c.save(out/'baseline-image.json',baseline)
    print('PLAN',out/'plan.json',flush=True)
    if not args.build:return
    check(frozen)
    for row in cached.values():
        if not b.same(row): raise ValueError('Cached input drift: '+row['path'])
    env,_=b.environment(links['qwen']['command'],[x['path'] for x in cached.values()],out)
    identities={c.key(x['path']):x for x in cached.values()}
    dependency_rows=[]
    for row in rows:
        c.execute(row['tag']+'-compile',row['command'],env,out);check(frozen)
        deps=c.read(out/(row['tag']+'-deps.json'))['Data']
        paths=[Path(deps['Source']),*(Path(p) for p in deps['Includes'])]
        depids=[b.identity(p) for p in paths]
        if row['tag'].split('-')[0] in [str(i) for i in range(9)]:
            assert any(c.key(p)==c.key(ROOT/'src/graph/plan_state.h') for p in paths),row['tag']
        obj=b.identity(row['object']);identities[c.key(obj['path'])]=obj
        record=dict(command=row['command'],source=row['source'],object=obj,dependencies=depids)
        c.save(out/(row['tag']+'-identity.json'),record);dependency_rows.append(record)
    for tag in ['cpu','qwen']:
        row=links[tag];c.execute(tag+'-link',row['command'],env,out);check(frozen)
        c.save(out/(tag+'-link-plan.json'),dict(command=row['command'],inputs=[identities[c.key(p)] for p in row['inputs']]))
        c.save(out/(tag+'-image.json'),b.identity(row['image']))
    for row in cached.values():
        if not b.same(row): raise ValueError('Cached input changed during build: '+row['path'])
    c.save(out/'source-dependencies.json',dependency_rows)
    c.save(out/'summary.json',dict(passed=True,host_TUs=10,native_TUs=0,SDK_build=False,GPU_run=False,
        links={tag:b.identity(links[tag]['image']) for tag in ['cpu','qwen']}))
    c.save(STAGE/'latest-check.json',dict(plan=str(out/'plan.json')))
    print('BUILD_COMPLETE',out/'plan.json',flush=True)
if __name__=='__main__':main()
