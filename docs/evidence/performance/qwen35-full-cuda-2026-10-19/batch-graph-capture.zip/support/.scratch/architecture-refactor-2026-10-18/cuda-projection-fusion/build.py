"""Cached CUDA increment; default is a plan with no compiler/link/GPU.

--build [--plan PATH] compiles two native and three host TUs, then links Qwen
and the existing CUDA test closure. --test [--plan PATH] runs only the two new
exact tests from an already successful build. No SDK build or object/header copy.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import os
import sys
import uuid
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location(
    "retained_cold_check", ARCH / "cold-constant-retirement/cold_check.py")
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

BASE = ARCH / "cold-copy-retirement/relinks/20261019T053106-dbca0667"
NATIVE_RECIPE = ARCH / "cuda-stable-silu/ggml-cuda-compile-plan.json"
OLD_NATIVE = ARCH / "cuda-stable-silu/ggml-cuda.obj"
OLD_TENSOR = ARCH / "cuda-reshape-reuse/tensor.obj"
PROVIDER_RECIPE = ARCH / "cold-constant-retirement/cuda-checks/20261019T051553-817e50eb/provider-identity.json"
OLD_PROVIDER = PROVIDER_RECIPE.parent / "provider.obj"
NATIVE_FREEZE = STAGE / "native-source-freeze.json"
VERSION_HEADER = STAGE / "provider-version.h"
TESTS = (
    "GgmlCudaBfloatMatvec.ExactRoundingForAlignedAndOddInnerWithBothRhsLayouts",
    "GgmlCudaBfloatMatvec.Float32SourceAndOutputKeepTheirPrecision",
)


def identity(path):
    row = c.snapshot(path, True)
    return {key: row[key] for key in ("path", "bytes", "sha256")}


def optional_identity(path):
    path = Path(path)
    return identity(path) if path.is_file() else {"path": str(path.resolve()), "missing": True}


def same(row):
    return not row.get("missing") and identity(row["path"]) == row


def host_command(recipe, source, tag, out):
    result, skip = [], False
    for arg in recipe:
        if skip:
            skip = False
            continue
        if arg.lower() == "/sourcedependencies":
            skip = True
        elif not (arg.lower().endswith(".cc") or arg.lower().startswith(("/fo", "/fd"))):
            result.append(arg)
    result += ["/sourceDependencies", str(out / (tag + "-deps.json")), str(source),
               "/Fo" + str(out / (tag + ".obj")), "/Fd" + str(out / (tag + ".pdb"))]
    if "/W4" not in result or "/WX" not in result:
        raise ValueError("The strict cached host recipe is required")
    return result


def native_command(recipe, source, tag, out):
    result, skip = [], False
    for arg in recipe:
        if skip:
            skip = False
            continue
        if arg in ("-c", "-o", "-MT", "-MF"):
            skip = True
        elif not arg.startswith("-Xcompiler=-Fd"):
            result.append(arg)
    if "--generate-code=arch=compute_89,code=[sm_89]" not in result or "-std=c++17" not in result:
        raise ValueError("The original sm89 native configuration must be retained")
    compiler = c.read(ARCH / "cuda-reshape-reuse/tensor-identity.json")["command"][0]
    return result + ["-ccbin", str(Path(compiler).parent),
                     "-MT", str(out / (tag + ".obj")), "-MF", str(out / (tag + ".d")),
                     "-c", str(source), "-o", str(out / (tag + ".obj")),
                     "-Xcompiler=-Fd" + str(out / (tag + ".pdb")) + ",-FS"]


def environment(command, inputs, out):
    # cmd.exe used by nvcc drops an oversized PATH. Object directories contain
    # no runtime DLLs; retain only library/runtime locations and pin cl first.
    env, runtime = c.environment(command,
        [arg for arg in inputs if Path(arg).suffix.lower() == ".lib"], out)
    compiler = Path(command[0]).with_name("cl.exe")
    env["PATH"] = str(compiler.parent) + os.pathsep + env["PATH"]
    return env, runtime


def host_dependencies(command):
    result = set()
    for i, arg in enumerate(command):
        if arg.lower() == "/sourcedependencies":
            old = Path(command[i + 1])
            if old.is_file():
                for value in c.read(old).get("Data", {}).get("Includes", []):
                    path = Path(value).resolve()
                    if any(path.is_relative_to(ROOT / prefix) for prefix in ("src", "include")):
                        result.add(path)
        elif arg.lower().startswith("/fi"):
            result.add(Path(arg[3:]).resolve())
    return result


def make_plan():
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    out = STAGE / "checks" / session
    out.mkdir(parents=True, exist_ok=False)
    native = c.read(NATIVE_RECIPE)
    native_freeze = c.read(NATIVE_FREEZE)
    provider_version = native_freeze["version"] + "+" + native_freeze["source_id"]
    header = "#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION " + json.dumps(provider_version) + "\n"
    if not VERSION_HEADER.is_file() or VERSION_HEADER.read_text(encoding="utf-8") != header:
        VERSION_HEADER.write_text(header, encoding="utf-8")
    frozen = {row["path"]: row for row in native["headers"]}
    if not all(same(row) for row in frozen.values()):
        raise ValueError("A reused native header no longer matches its original ABI identity")
    for path in (NATIVE_FREEZE, VERSION_HEADER):
        frozen[str(path)] = identity(path)
    compiles = []
    for tag in ("ggml-cuda", "mmvf"):
        source = STAGE / "native-source/src/ggml-cuda" / (tag + ".cu")
        if source.is_file() and identity(source)["sha256"] != native_freeze["sources"]["src/ggml-cuda/" + tag + ".cu"]:
            raise ValueError("Native source does not match root freeze: " + str(source))
        compiles.append({"tag": tag, "kind": "native", "source": optional_identity(source),
            "recipe": identity(NATIVE_RECIPE), "command": native_command(native["command"], source, tag, out),
            "object": str(out / (tag + ".obj")),
            "derivation": "Same full sm89 recipe and flags; only source/output/dependency/PDB paths changed."})
    for tag, source, origin in (
        ("tensor", ROOT / "src/compute_provider_ggml_cuda/tensor_program.cc",
         ARCH / "cuda-reshape-reuse/tensor-identity.json"),
        ("bfloat-matvec-test", ROOT / "tests/compute_provider_ggml_cuda/bfloat_matvec_test.cc",
         ARCH / "cuda-stable-silu/tensor-test-identity.json"),
        ("provider", ROOT / "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc", PROVIDER_RECIPE),
    ):
        recipe = c.read(origin)
        template = recipe["command"]
        old_forced = []
        if tag == "provider":
            old_forced = [arg[3:] for arg in template if arg.lower().startswith("/fi")]
            if len(old_forced) != 1 or Path(old_forced[0]).name != "provider-version.h":
                raise ValueError("Expected one cached forced provider version header")
            template = ["/FI" + str(VERSION_HEADER) if arg.lower().startswith("/fi") else arg
                        for arg in template]
        compiles.append({"tag": tag, "kind": "host", "source": optional_identity(source),
            "recipe": identity(origin), "command": host_command(template, source, tag, out),
            "object": str(out / (tag + ".obj"))})
        if tag in ("tensor", "provider"):
            for path in host_dependencies(template):
                if c.key(path) not in {c.key(old) for old in old_forced}:
                    frozen[str(path)] = identity(path)
    for relative in ("tests/compute_provider_ggml_cuda/tensor_test_support.h",
                     "tests/compute_provider_ggml_cuda/test_support.h",
                     "tests/compute_provider_native/half_test_support.h"):
        path = ROOT / relative
        frozen[str(path)] = identity(path)
    for row in compiles:
        frozen[row["source"]["path"]] = row["source"]
        if not Path(row["command"][0]).is_file():
            raise ValueError("Cached compiler is missing: " + row["command"][0])
    replacements = {c.key(OLD_NATIVE): str(out / "ggml-cuda.obj"),
                    c.key(OLD_TENSOR): str(out / "tensor.obj"),
                    c.key(OLD_PROVIDER): str(out / "provider.obj")}
    links, cached = {}, {}
    for name, expected in (("qwen", 121), ("cuda-tests", 124)):
        base = BASE / (name + "-link-plan.json")
        original = c.read(base)
        if len(original["inputs"]) != expected:
            raise ValueError("Unexpected retained closure size: " + name)
        for row in original["inputs"]:
            if row["path"] not in cached:
                if not same(row):
                    raise ValueError("Cached link input missing/changed: " + row["path"])
                cached[row["path"]] = row
        for old in replacements:
            if sum(c.key(arg) == old for arg in original["command"] if not arg.startswith("/")) != 1:
                raise ValueError("Expected one explicit replaced owner: " + old)
        argv = [replacements.get(c.key(arg), arg) if not arg.startswith("/") else arg
                for arg in original["command"]
                if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
        argv += [str(out / "mmvf.obj")]
        if name == "cuda-tests":
            argv += [str(out / "bfloat-matvec-test.obj")]
        image = out / ("candidate.exe" if name == "qwen" else "fusion-tests.exe")
        argv += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                 "/IMPLIB:" + str(image.with_suffix(".lib"))]
        inputs = [arg for arg in argv if not arg.startswith("/") and Path(arg).is_absolute()
                  and Path(arg).suffix.lower() in (".obj", ".lib")]
        if len(inputs) != expected + (1 if name == "qwen" else 2):
            raise ValueError("Unexpected new closure size")
        links[name] = {"base": identity(base), "command": argv, "inputs": inputs,
                       "image": str(image), "absolute_input_count": len(inputs)}
    env, runtime = environment(links["qwen"]["command"],
        list(dict.fromkeys(arg for row in links.values() for arg in row["inputs"])), out)
    sdk = c.sdk_libraries(links["qwen"]["command"], env)
    if any(row["resolved"] is None for row in sdk):
        raise ValueError("A named Windows SDK library is missing")
    plan = {"schema": "hyle.projection_matvec.build_plan.v1", "compile": compiles,
        "links": links, "frozen_sources_and_headers": list(frozen.values()),
        "cached_inputs": list(cached.values()), "runtime_path_directories": runtime,
        "named_sdk_libraries": sdk, "tests": TESTS,
        "runtime_provider_version": provider_version,
        "ready_for_build": all(not row.get("missing") for row in frozen.values()),
        "SDK_build": False, "CMake_run": False, "dependency_or_object_copy": False,
        "dense_projection_test_claimed": False,
        "native_header_ABI": "92 retained header identities match stable-silu; no header edit or ABI expansion.",
        "source_freeze": "Snapshots are taken now; rechecked before each command and after compilation. Replan if any source was still being edited."}
    path = out / "plan.json"
    c.save(path, plan)
    print("PLAN", str(path), "ready_for_build", plan["ready_for_build"], flush=True)
    return path


def verify_frozen(plan):
    for row in plan["frozen_sources_and_headers"] + plan["cached_inputs"]:
        if not same(row):
            raise ValueError("Frozen source/header/input changed or is missing: " + row["path"])
    for item in plan["compile"]:
        if not same(item["recipe"]):
            raise ValueError("Recipe changed after planning")
    for item in plan["links"].values():
        if not same(item["base"]):
            raise ValueError("Base link plan changed after planning")


def load_plan(path):
    path = Path(path).resolve()
    if not path.is_relative_to(STAGE / "checks") or path.name != "plan.json":
        raise ValueError("Plan must be this stage's checks/<session>/plan.json")
    return path, c.read(path)


def build(path):
    path, plan = load_plan(path)
    out = path.parent
    if not plan["ready_for_build"]:
        raise ValueError("Incomplete provisional sources; make a new plan after source freeze")
    if any(out.glob("*-compile.command.json")):
        raise ValueError("Preserve this build attempt; make a new plan to retry")
    verify_frozen(plan)
    env, _ = environment(plan["links"]["qwen"]["command"],
        list(dict.fromkeys(arg for row in plan["links"].values() for arg in row["inputs"])), out)
    (out / "tmp").mkdir()
    for item in plan["compile"]:
        verify_frozen(plan)
        c.execute(item["tag"] + "-compile", item["command"], env, out)
        verify_frozen(plan)
        c.save(out / (item["tag"] + "-identity.json"), {"source": item["source"],
            "object": identity(item["object"]), "recipe": item["recipe"], "command": item["command"]})
    for name, item in plan["links"].items():
        verify_frozen(plan)
        link_path = out / (name + "-link-plan.json")
        c.save(link_path, {"command": item["command"], "inputs": [identity(arg) for arg in item["inputs"]],
            "base": item["base"], "build_plan": identity(path), "SDK_build": False,
            "dependency_or_object_copy": False})
        c.execute(name + "-link", item["command"], env, out)
        c.save(out / (name + "-image.json"), {"image": identity(item["image"]),
            "link_plan": identity(link_path)})
    c.save(out / "build-summary.json", {"terminal": True, "exit": 0,
        "compile_TUs": len(plan["compile"]),
        "runtime_provider_version": plan["runtime_provider_version"],
        "images": {name: identity(item["image"]) for name, item in plan["links"].items()},
        "GPU_run": False})
    c.save(STAGE / "last-build.json", {"plan": identity(path)})
    print("BUILT", str(out / "build-summary.json"), flush=True)


def test(path):
    path, plan = load_plan(path)
    out = path.parent
    if c.read(out / "build-summary.json").get("exit") != 0:
        raise ValueError("The planned incremental build must have succeeded first")
    row = c.read(out / "cuda-tests-image.json")
    if not same(row["image"]) or not same(row["link_plan"]):
        raise ValueError("Built test image or link plan changed")
    if (out / "directed-tests.command.json").exists():
        raise ValueError("No implicit test retry or result overwrite")
    env, _ = environment(plan["links"]["cuda-tests"]["command"],
                           plan["links"]["cuda-tests"]["inputs"], out)
    c.save(out / "directed-tests-inputs.json", {"image": row["image"], "tests": TESTS})
    xml = out / "directed-tests.xml"
    c.execute("directed-tests", [row["image"]["path"], "--gtest_color=no",
        "--gtest_filter=" + ":".join(TESTS), "--gtest_output=xml:" + str(xml)], env, out)
    root = ET.parse(xml).getroot()
    cases = [v.attrib["classname"] + "." + v.attrib["name"] for v in root.findall(".//testcase")]
    if set(cases) != set(TESTS) or len(cases) != 2 or root.findall(".//failure") or root.findall(".//skipped"):
        raise ValueError("The two exact new tests did not both pass without skips")
    c.save(out / "tests-summary.json", {"cases": cases, "failures": 0, "skipped": 0,
        "image": row["image"], "xml": identity(xml)})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--build", action="store_true")
    mode.add_argument("--test", action="store_true")
    parser.add_argument("--plan", help="Use an existing immutable checks/<session>/plan.json")
    args = parser.parse_args()
    if args.test:
        path = args.plan or c.read(STAGE / "last-build.json")["plan"]["path"]
        test(path)
    elif args.build:
        build(args.plan or make_plan())
    elif args.plan:
        parser.error("--plan is for --build or --test; dry-run creates a new plan")
    else:
        make_plan()


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
