"""Increment one native allocator/fuser TU and two host owners; reuse all SDKs."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'recurrent-gdn-schema/checks/20261019T113131'
V20 = ARCH / 'cuda-fusion-precision/checks/20261019T111328'
HEADERS = ARCH / 'cuda-fusion-precision/native-source'
spec = importlib.util.spec_from_file_location('allocation_cached_build', ARCH / 'recurrent-gdn-schema/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c


def check(plan):
    # The source/header set is small. Large retained libraries and native
    # objects are hashed only at the initial and terminal build boundaries.
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/header/recipe drift: ' + row['path'])


def check_cached(plan):
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Retained object/library drift: ' + row['path'])


def strip_ccbin(command):
    result, skip = [], False
    for value in command:
        if skip:
            skip = False
            continue
        if value in ('-ccbin', '--compiler-bindir'):
            skip = True
        elif not value.startswith(('-ccbin=', '--compiler-bindir=')):
            result.append(value)
    return result


def hyle_literal_dependencies(sources):
    # Extend the retained sourceDependencies with new same-build local includes
    # such as SmallVector/StdAllocator, before invoking a compiler.
    found, pending = {}, list(sources)
    include_dirs = [ROOT / 'include', ROOT / 'src/compute', ROOT / 'src/compute_provider_ggml_cuda',
                    ROOT / 'src/compute_ggml_runtime', ROOT]
    while pending:
        path = Path(pending.pop()).resolve()
        if c.key(path) in found:
            continue
        found[c.key(path)] = path
        text = path.read_text(encoding='utf-8-sig')
        for name in re.findall(r'^\s*#\s*include\s*"([^"\n]+)"', text, re.M):
            target = next((directory / name for directory in [path.parent, *include_dirs]
                           if (directory / name).is_file()), None)
            if target is not None and any(target.resolve().is_relative_to(ROOT / prefix) for prefix in ('src', 'include', 'tests')):
                pending.append(target)
    return list(found.values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    freeze = c.read(STAGE / 'native-source-freeze.json')
    reviewed = c.read(STAGE / 'source-freeze.json')
    tests = c.read(STAGE / 'tests-source-freeze.json')
    source = STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'
    expected = next(row['after'] for row in reviewed['files'] if row['target'] == 'native/src/ggml-cuda/ggml-cuda.cu')
    actual = b.identity(source)
    if (actual['bytes'], actual['sha256']) != (expected['bytes'], expected['sha256']):
        raise ValueError('Sealed main differs from reviewed source')
    if freeze.get('sources', {}).get('src/ggml-cuda/ggml-cuda.cu', actual['sha256']) != actual['sha256']:
        raise ValueError('Sealed native-source-freeze differs')
    for row in reviewed['files']:
        if row['target'].startswith('native/'):
            continue
        actual = b.identity(ROOT / row['target'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied reviewed host/bridge source differs')
    test_source = ROOT / 'tests/graph_route_cuda/stable_silu_test.cc'
    actual = b.identity(test_source)
    if (actual['bytes'], actual['sha256']) != (tests['after']['bytes'], tests['after']['sha256']):
        raise ValueError('Applied test overlay differs')
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = [b.identity(path) for path in (
        Path(__file__), STAGE / 'native-source-freeze.json', STAGE / 'source-freeze.json',
        STAGE / 'application.json', STAGE / 'tests-source-freeze.json', STAGE / 'provider-version.h',
        ROOT / 'src/compute_provider_ggml_cuda/native_bridge.h',
        ROOT / 'src/compute_provider_ggml_cuda/native_bridge_impl.h',
        ROOT / 'src/compute_provider_ggml_cuda/CMakeLists.txt',
        ROOT / 'tests/graph_route_cuda/CMakeLists.txt',
        ROOT / 'third_party/ggml_cuda_runtime/patches.json', ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT / 'cmake/HyleDependencyLock.json')]
    receipt = ARCH / 'cuda-fusion-precision/header-closure.json'
    frozen.append(b.identity(receipt))
    headers = c.read(receipt)
    if headers['header_count'] != 89:
        raise ValueError('Expected existing coherent89-header closure')
    for row in headers['headers']:
        path = HEADERS / row['path']
        identity = b.identity(path)
        if identity['sha256'] != row['sha256']:
            raise ValueError('Reused coherent GGML header differs')
        frozen.append(identity)
    base_plan = c.read(BASE / 'plan.json')
    provider = next(row for row in base_plan['compile'] if row['source']['path'].endswith('ggml_cuda_provider.cc'))
    specifications = (
        ('ggml-cuda', 'native', V20 / 'ggml-cuda-identity.json', source),
        ('provider', 'host', BASE / (provider['tag'] + '-identity.json'), ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('stable-test', 'host', V20 / 'stable-test-identity.json', test_source),
    )
    rows, replacements = [], {}
    for tag, kind, recipe_path, source in specifications:
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Retained owner object differs: ' + tag)
        template = recipe['command']
        if kind == 'native':
            command = strip_ccbin(b.native_command(strip_ccbin(template), source, tag, out))
            command = [value for value in command if not (value.startswith('-I') and
                ('architecture-refactor-2026-10-18' in value or 'reference-windows' in value))]
            command[1:1] = ['-I' + str(HEADERS / 'include'), '-I' + str(HEADERS / 'src'),
                            '-I' + str(HEADERS / 'src/ggml-cuda')]
        else:
            if tag == 'provider':
                forced = [value for value in template if value.lower().startswith('/fi')]
                if len(forced) != 1:
                    raise ValueError('Expected one provider native identity header')
                template = ['/FI' + str(STAGE / 'provider-version.h') if value.lower().startswith('/fi') else value for value in template]
            command = b.host_command(template, source, tag, out)
            command = [value for value in command if not (value.lower().startswith(('/i', '/external:i')) and
                ('reference-windows' in value or 'cuda-fusion-precision/native-source' in value.replace('\\', '/')))]
            command[1:1] = ['/external:I' + str(HEADERS / 'include'), '/external:I' + str(HEADERS / 'src')]
            frozen.extend(b.identity(path) for path in b.host_dependencies(template))
        obj = str(out / (tag + '.obj'))
        rows.append({'tag': tag, 'kind': kind, 'source': b.identity(source), 'command': command, 'object': obj})
        replacements[c.key(recipe['object']['path'])] = obj
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    frozen.extend(b.identity(path) for path in hyle_literal_dependencies([
        ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', test_source,
        ROOT / 'src/compute_provider_ggml_cuda/native_bridge.h', ROOT / 'src/compute_provider_ggml_cuda/native_bridge_impl.h']))
    links, cached = {}, {}
    for tag, count, replaced in (('cuda', 133, 3), ('qwen', 125, 2)):
        path = BASE / (tag + '-link-plan.json')
        base = c.read(path)
        frozen.append(b.identity(path))
        cached.update({c.key(row['path']): row for row in base['inputs']})
        present = {c.key(row['path']) for row in base['inputs']}
        if len(present.intersection(replacements)) != replaced:
            raise ValueError('Exact replacement set differs: ' + tag)
        for owner in present.intersection(replacements):
            if sum(c.key(value) == owner for value in base['command']) != 1:
                raise ValueError('Nonunique linked owner: ' + tag)
        command = [replacements.get(c.key(value), value) for value in base['command']
                   if not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = prior.prior.prior.inputs(command)
        if len(inputs) != count or len(set(map(c.key, inputs))) != count:
            raise ValueError('Final link input closure differs')
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    plan = {
        'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(row['path']): row for row in frozen}.values()),
        'native_TUs': 1, 'host_TUs': 2, 'SDK_build': False, 'CMake_run': False, 'GPU_run': False,
        'native_source_id': freeze.get('source_id'), 'exact_tests': tests['tests'],
        'native_private_by_value_ABI_changed': False,
        'reused_coherent_GGML_headers': 89,
        'refresh_scope': 'Only main defines the added cold collector; fresh provider and stable-test call it. Existing MMVF/MMVQ/unary math and the latest GDN/index closure remain unchanged.',
    }
    path = out / 'plan.json'
    c.save(path, plan)
    check(plan)
    check_cached(plan)
    print('PLAN', path, flush=True)
    if not args.build:
        return
    env, _ = b.environment(links['qwen']['command'], links['qwen']['inputs'], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        if row['kind'] == 'native':
            dependencies = (out / (row['tag'] + '.d')).read_text(encoding='utf-8').replace('\\', '/')
            if 'cuda-fusion-precision/native-source/src/ggml-cuda/common.cuh' not in dependencies:
                raise ValueError('Fresh main did not use the coherent GGML header tree')
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': b.identity(row['object'])})
    check_cached(plan)
    for tag in ('cuda', 'qwen'):
        link = links[tag]
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'],
            'inputs': [b.identity(value) for value in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 1, 'host_TUs': 2,
        'SDK_build': False, 'GPU_run': False, 'fresh_header_closure': True})
    print('BUILD_COMPLETE', path, flush=True)


if __name__ == '__main__':
    main()
