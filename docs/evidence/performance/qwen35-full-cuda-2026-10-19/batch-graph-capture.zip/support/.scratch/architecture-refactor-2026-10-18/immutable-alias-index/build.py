"""Apply the reviewed allocation index and increment its actual host closure."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('alias_cached_build', ARCH / 'cuda-fusion-precision/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c
CUDA = ARCH / 'cuda-fusion-precision/checks/20261019T111328'


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/recipe drift: ' + row['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    freeze = c.read(STAGE / 'source-freeze.json')
    for row in freeze['files']:
        actual = b.identity(ROOT / row['source'])
        wanted = row['before'] if args.apply else row['after']
        if (actual['bytes'], actual['sha256']) != (wanted['bytes'], wanted['sha256']):
            raise ValueError('Product source drift: ' + row['source'])
        if not b.same(row['after']):
            raise ValueError('Reviewed overlay drift: ' + row['source'])
    if args.apply:
        for row in freeze['files']:
            (ROOT / row['source']).write_bytes(Path(row['after']['path']).read_bytes())
        c.save(STAGE / 'application.json', {
            'freeze': b.identity(STAGE / 'source-freeze.json'),
            'files': [b.identity(ROOT / row['source']) for row in freeze['files']],
            'public_ABI_change': False, 'private_PlanState_ABI_change': True})
        print('APPLIED', len(freeze['files']), flush=True)
    if not args.build:
        return
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    recipes = c.read(STAGE / 'host-recipes.json')
    cpu = c.read(recipes['base_cpu_link_plan']['path'])
    qwen = c.read(CUDA / 'qwen-link-plan.json')
    baseline = c.read(CUDA / 'qwen-image.json')
    if not b.same(baseline):
        raise ValueError('Retained v20 baseline image differs')
    frozen = [b.identity(x) for x in (
        Path(__file__), STAGE / 'source-freeze.json', STAGE / 'host-recipes.json',
        ROOT / 'src/graph/plan_state.h', CUDA / 'qwen-link-plan.json',
        Path(recipes['base_cpu_link_plan']['path']))]
    rows, replacements, core_replacements = [], {}, {}
    for index, row in enumerate(recipes['compile']):
        source = ROOT / row['source_name']
        actual = b.identity(source)
        if (actual['bytes'], actual['sha256']) != (row['source']['bytes'], row['source']['sha256']):
            raise ValueError('Reviewed compile source drift: ' + row['source_name'])
        tag = str(index) + '-' + source.stem
        command = b.host_command(row['command_template'], source, tag, out)
        obj = str(out / (tag + '.obj'))
        rows.append({'tag': tag, 'command': command, 'source': actual, 'object': obj})
        frozen.extend((actual, b.identity(row['recipe']['path'])))
        if row['old_object']:
            old = c.key(row['old_object']['path'])
            replacements[old] = obj
            if index < 8:
                core_replacements[old] = obj
        # Archive the tested closure without duplicating headers or SDKs.
        snapshot = STAGE / 'source' / row['source_name']
        if not snapshot.exists():
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes(source.read_bytes())
    cached = {c.key(row['path']): row for row in cpu['inputs'] + qwen['inputs']}
    links = {}
    for tag, base, replace, count in (
            ('cpu', cpu, replacements, 112), ('qwen', qwen, core_replacements, 125)):
        present = {c.key(row['path']) for row in base['inputs']}
        if len(present.intersection(replace)) != len(replace):
            raise ValueError('Exact replacement closure differs: ' + tag)
        command = [replace.get(c.key(x), x) for x in base['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if tag == 'cpu':
            command.insert(1, rows[-1]['object'])
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = prior.inputs(command)
        if len(inputs) != count or len(set(map(c.key, inputs))) != count:
            raise ValueError('Link count/identity differs: ' + tag)
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    links['baseline'] = {'command': qwen['command'], 'image': baseline['path'],
                         'inputs': [x['path'] for x in qwen['inputs']]}
    frozen.append(baseline)
    plan = {'compile': rows, 'links': links, 'frozen': list({c.key(x['path']): x for x in frozen}.values()),
            'cached_inputs': list(cached.values()), 'host_TUs': len(rows), 'native_TUs': 0,
            'SDK_build': False, 'CMake_run': False, 'GPU_run': False,
            'private_header_closure': '8 core owners + 2 linked private-header tests + public executable fixture',
            'exact_tests': recipes['exact_tests']}
    path = out / 'plan.json'
    c.save(path, plan)
    check(plan)
    for row in cached.values():
        if not b.same(row):
            raise ValueError('Cached object/library differs: ' + row['path'])
    print('PLAN', path, flush=True)
    env, _ = b.environment(links['qwen']['command'], [x['path'] for x in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        c.save(out / (row['tag'] + '-identity.json'), {
            'command': row['command'], 'source': row['source'], 'object': b.identity(row['object'])})
    for tag in ('cpu', 'qwen'):
        row = links[tag]
        c.execute(tag + '-link', row['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': row['command'],
            'inputs': [b.identity(x) for x in row['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(row['image']))
    c.save(out / 'baseline-image.json', baseline)
    c.save(out / 'summary.json', {'passed': True, 'host_TUs': len(rows), 'native_TUs': 0,
                                 'SDK_build': False, 'GPU_run': False})
    print('BUILD_COMPLETE', path, flush=True)


if __name__ == '__main__':
    main()
