"""Increment the complete private precision/OAI carrier ABI; no SDK rebuild."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('precision_prior_build', ARCH / 'cuda-fusion-layout/build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
b, c = previous.b, previous.c
BASE = ARCH / 'cuda-fusion-layout/checks/20261019T105435'
NATIVE = ARCH / 'cuda-fusion-layout/native-build/20261019T104704'
DUAL = ARCH / 'cuda-bf16-dual-projection/checks/20261019T084721'
ROPE = ARCH / 'cuda-explicit-rope/checks/20261019T100154'


def check(plan):
    for row in plan['frozen'] + plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Retained source/input drift: ' + row['path'])


def strip_ccbin(command):
    result, skip = [], False
    for item in command:
        if skip:
            skip = False
            continue
        if item == '-ccbin':
            skip = True
        else:
            result.append(item)
    return result


def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    freeze = c.read(STAGE / 'native-source-freeze.json')
    frozen = [b.identity(p) for p in (Path(__file__), STAGE / 'native-source-freeze.json',
        STAGE / 'provider-version.h', STAGE / 'tests-source-freeze.json',
        ROOT / 'third_party/ggml_cuda_runtime/patches.json', ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT / 'cmake/HyleDependencyLock.json')]
    for relative, expected in freeze['sources'].items():
        path = STAGE / 'native-source' / relative
        if b.identity(path)['sha256'] != expected:
            raise ValueError('Native source/header differs')
        frozen.append(b.identity(path))
    header_receipt = STAGE / 'header-closure.json'
    headers = c.read(header_receipt)
    frozen.append(b.identity(header_receipt))
    for row in headers['headers']:
        path = STAGE / 'native-source' / row['path']
        if b.identity(path)['sha256'] != row['sha256']:
            raise ValueError('Coherent header closure differs')
        frozen.append(b.identity(path))
    specs = (
        ('ggml-cuda', 'native', NATIVE / 'ggml-cuda-identity.json', STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'),
        ('mmvf', 'native', DUAL / 'mmvf-identity.json', STAGE / 'native-source/src/ggml-cuda/mmvf.cu'),
        ('mmvq', 'native', NATIVE / 'mmvq-identity.json', STAGE / 'native-source/src/ggml-cuda/mmvq.cu'),
        ('unary', 'native', ROPE / 'unary-identity.json', STAGE / 'native-source/src/ggml-cuda/unary.cu'),
        ('provider', 'host', BASE / 'provider-identity.json', ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('stable-test', 'host', BASE / 'stable-test-identity.json', ROOT / 'tests/graph_route_cuda/stable_silu_test.cc'),
    )
    rows, replacements, test_only = [], {}, {}
    for tag, kind, recipe_path, source in specs:
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Retained object differs: ' + tag)
        template = recipe['command']
        if kind == 'native':
            command = b.native_command(strip_ccbin(template), source, tag, out)
            command = [x for x in command if not (x.startswith('-I') and
                ('architecture-refactor-2026-10-18' in x or 'reference-windows' in x))]
            command[1:1] = ['-I' + str(STAGE / 'native-source/include'),
                '-I' + str(STAGE / 'native-source/src'), '-I' + str(STAGE / 'native-source/src/ggml-cuda')]
            if tag == 'unary' and any('use_fast_math' in x for x in command):
                raise ValueError('Retain the strict unary recipe')
        else:
            if tag == 'provider':
                template = ['/FI' + str(STAGE / 'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command = b.host_command(template, source, tag, out)
        obj = str(out / (tag + '.obj'))
        rows.append({'tag': tag, 'kind': kind, 'command': command, 'source': b.identity(source), 'object': obj})
        replacements[c.key(recipe['object']['path'])] = obj
        if tag == 'stable-test':
            test_only[c.key(recipe['object']['path'])] = obj
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    qwen, cuda = c.read(BASE / 'qwen-link-plan.json'), c.read(BASE / 'cuda-link-plan.json')
    cached = {c.key(r['path']): r for r in qwen['inputs'] + cuda['inputs']}
    baseline = c.read(BASE / 'qwen-image.json')
    if not b.same(baseline):
        raise ValueError('Retained v19 model image differs')
    frozen.append(baseline)
    links = {}
    for tag, source, replace, count in (('cuda-before', cuda, test_only, 133),
                                       ('qwen', qwen, replacements, 125), ('cuda', cuda, replacements, 133)):
        present = {c.key(r['path']) for r in source['inputs']}
        expected = 1 if tag == 'cuda-before' else (5 if tag == 'qwen' else 6)
        if len(present.intersection(replace)) != expected:
            raise ValueError('Incomplete private ABI replacement set: ' + tag)
        for owner in present.intersection(replace):
            if sum(c.key(x) == owner for x in source['command']) != 1:
                raise ValueError('Duplicate owner')
        command = [replace.get(c.key(x), x) for x in source['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
        owned = inputs(command)
        if len(owned) != count or len({c.key(x) for x in owned}) != count:
            raise ValueError('Link closure changed')
        links[tag] = {'command': command, 'image': str(image), 'inputs': owned}
    links['baseline'] = {'command': qwen['command'], 'image': baseline['path'], 'inputs': [r['path'] for r in qwen['inputs']]}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(r['path']): r for r in frozen}.values()), 'native_TUs': 4, 'host_TUs': 2,
        'SDK_build': False, 'CMake_run': False, 'GPU_run': False, 'native_source_id': freeze['source_id'],
        'private_ABI': 'All main/MMVF/MMVQ/unary by-value fusion-argument owners rebuilt as one closure',
        'baseline_model_image_reused': True}
    target = out / 'plan.json'
    c.save(target, plan)
    check(plan)
    print('PLAN', target, flush=True)
    if not args.build:
        return
    (out / 'tmp').mkdir()
    env, _ = b.environment(links['qwen']['command'], [r['path'] for r in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        if row['kind'] == 'native':
            dependencies = (out / (row['tag'] + '.d')).read_text(encoding='utf-8').replace('\\', '/')
            if 'cuda-fusion-precision/native-source/src/ggml-cuda/common.cuh' not in dependencies:
                raise ValueError('Private ABI header not used by ' + row['tag'])
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'], 'source': row['source'], 'object': b.identity(row['object'])})
    for tag in ('cuda-before', 'qwen', 'cuda'):
        link = links[tag]
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'], 'inputs': [b.identity(x) for x in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    c.save(out / 'baseline-image.json', baseline)
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 4, 'host_TUs': 2, 'SDK_build': False, 'GPU_run': False})
    print('BUILD_COMPLETE', target, flush=True)


if __name__ == '__main__':
    main()
