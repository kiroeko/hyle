"""Increment only explicit RoPE owners, retaining the v16 link closure."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('rope_retained_build', ARCH / 'cuda-bf16-dual-projection/build_current.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
b, c = original.b, original.c
V16 = ARCH / 'cuda-bf16-dual-projection/metadata-fix/checks/20261019T091159'
DUAL = ARCH / 'cuda-bf16-dual-projection/checks/20261019T084721'
GDN = ARCH / 'cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236'
TEST = ARCH / 'cuda-bf16-dual-projection/tests-build/20261019T085621'


def check(plan):
    for row in plan['frozen'] + plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Source or retained input drift: ' + row['path'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build', action='store_true')
    args = p.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    freeze = c.read(STAGE / 'native-source-freeze.json')
    frozen = [b.identity(x) for x in (Path(__file__), STAGE / 'native-source-freeze.json',
        STAGE / 'provider-version.h', ROOT / 'third_party/ggml_cuda_runtime/patches.json',
        ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md', ROOT / 'cmake/HyleDependencyLock.json',
        ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h',
        ROOT / 'src/compute_ggml_runtime/explicit_rope.h')]
    for relative, expected in freeze['sources'].items():
        path = STAGE / 'native-source' / relative
        if b.identity(path)['sha256'] != expected:
            raise ValueError('Native source differs: ' + relative)
        frozen.append(b.identity(path))
    specs = (
        ('ggml-cuda', 'native', V16 / 'ggml-cuda-identity.json', STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'),
        ('unary', 'native', DUAL / 'unary-identity.json', STAGE / 'native-source/src/ggml-cuda/unary.cu'),
        ('tensor-program', 'host', GDN / 'tensor-program-identity.json', ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'),
        ('provider', 'host', V16 / 'provider-identity.json', ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('stable-test', 'host', TEST / 'stable-test-identity.json', ROOT / 'tests/graph_route_cuda/stable_silu_test.cc'),
    )
    rows, replacements = [], {}
    for tag, kind, recipe_path, source in specs:
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Old object differs: ' + tag)
        template = recipe['command']
        if kind == 'native':
            command = b.native_command(original.strip_ccbin(template), source, tag, out)
            command[1:1] = ['-I' + str(STAGE / 'native-source/src'), '-I' + str(STAGE / 'native-source/src/ggml-cuda')]
            if tag == 'unary' and any('use_fast_math' in x for x in command):
                raise ValueError('RoPE must use the existing strict unary TU')
        else:
            if tag == 'provider':
                template = ['/FI' + str(STAGE / 'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command = b.host_command(template, source, tag, out)
        rows.append({'tag': tag, 'kind': kind, 'command': command, 'source': b.identity(source),
            'object': str(out / (tag + '.obj'))})
        replacements[c.key(recipe['object']['path'])] = str(out / (tag + '.obj'))
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    qwen = c.read(V16 / 'qwen-link-plan.json')
    tests = c.read(V16 / 'cuda-link-plan.json')
    cached = {c.key(row['path']): row for row in qwen['inputs'] + tests['inputs']}
    links = {}
    for tag, source, replace, count in (
        ('baseline', qwen, False, 124), ('qwen', qwen, True, 124), ('cuda', tests, True, 132)):
        present = {c.key(row['path']) for row in source['inputs']}
        for owner in replacements:
            if owner in present and sum(c.key(x) == owner for x in source['command']) != 1:
                raise ValueError('Replacement owner is not unique: ' + tag)
        expected = 5 if tag == 'cuda' else 4
        if len(present.intersection(replacements)) != expected:
            raise ValueError('Unexpected replacement closure: ' + tag)
        command = [replacements.get(c.key(x), x) if replace else x for x in source['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
            '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = original.inputs(command)
        if len(inputs) != count or len({c.key(x) for x in inputs}) != count:
            raise ValueError('Input count or uniqueness differs: ' + tag)
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(row['path']): row for row in frozen}.values()),
        'native_TUs': 2, 'host_TUs': 3, 'SDK_build': False, 'CMake_run': False,
        'native_source_id': freeze['source_id'], 'GPU_run': False}
    target = out / 'plan.json'
    c.save(target, plan)
    check(plan)
    print('PLAN', target, flush=True)
    if not args.build:
        return
    (out / 'tmp').mkdir()
    env, _ = b.environment(links['qwen']['command'], [row['path'] for row in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': b.identity(row['object'])})
    for tag, link in links.items():
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'],
            'inputs': [b.identity(x) for x in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 2, 'host_TUs': 3,
        'SDK_build': False, 'CMake_run': False, 'GPU_run': False})
    print('BUILD_COMPLETE', target, flush=True)


if __name__ == '__main__':
    main()
