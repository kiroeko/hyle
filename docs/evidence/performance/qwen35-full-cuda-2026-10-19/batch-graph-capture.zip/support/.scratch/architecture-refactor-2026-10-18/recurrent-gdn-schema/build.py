"""Refresh the actual public-inline host closure; reuse native math and SDKs."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('gdn_cached_helpers', ARCH / 'immutable-alias-index/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Source/recipe drift: ' + row['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    recipes_path = STAGE / 'host-recipes.json'
    recipes = c.read(recipes_path)
    freeze = c.read(STAGE / 'source-freeze.json')
    for row in freeze['files']:
        actual = b.identity(ROOT / row['source'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Reviewed product source differs: ' + row['source'])
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = [b.identity(x) for x in (Path(__file__), recipes_path, STAGE / 'source-freeze.json',
        STAGE / 'application.json', STAGE / 'inline-dependencies.json',
        ROOT / 'include/hyle/compute/model_ops.h', ROOT / 'src/graph/plan_state.h')]
    rows, by_tag = [], {}
    for row in recipes['compile']:
        source = Path(row['source']['path'])
        if not b.same(row['source']):
            raise ValueError('Current source differs: ' + str(source))
        tag = row['tag']
        command = b.host_command(row['command_template'], source, tag, out)
        entry = {'tag': tag, 'source': row['source'], 'command': command,
                 'object': str(out / (tag + '.obj')), 'closures': row['closures']}
        rows.append(entry)
        by_tag[tag] = entry
        frozen.extend((row['source'], b.identity(row['recipe']['path'])))
        frozen.extend(b.identity(path) for path in b.host_dependencies(row['command_template']))
        target = STAGE / 'source' / source.relative_to(ROOT)
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    links, cached = {}, {}
    for tag in ('cpu', 'cuda', 'qwen'):
        proposal = recipes['links'][tag]
        base_path = Path(proposal['base_link_plan']['path'])
        base = c.read(base_path)
        frozen.append(b.identity(base_path))
        present = {c.key(x['path']) for x in base['inputs']}
        if len(present) != proposal['base_absolute_inputs']:
            raise ValueError('Base link closure differs: ' + tag)
        cached.update({c.key(x['path']): x for x in base['inputs']})
        replacements = {c.key(x['old_object']['path']): by_tag[x['replacement_compile_tag']]['object']
                        for x in proposal['fresh_owner_replacements']}
        for row in proposal['cached_alias_core_replacements']:
            if not b.same(row['replacement_object']):
                raise ValueError('Latest PlanState object differs')
            replacements[c.key(row['old_object']['path'])] = row['replacement_object']['path']
            cached[c.key(row['replacement_object']['path'])] = row['replacement_object']
            frozen.append(b.identity(row['recipe']['path']))
        if len(replacements) != proposal['expected_total_replaced_objects'] or not set(replacements).issubset(present):
            raise ValueError('Replacement owner set differs: ' + tag)
        for key in replacements:
            if sum(c.key(x) == key for x in base['command']) != 1:
                raise ValueError('Replacement owner is not unique: ' + tag)
        command = [replacements.get(c.key(x), x) for x in base['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        command[1:1] = [by_tag[x]['object'] for x in proposal['add_compile_tags']]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = prior.prior.inputs(command)
        if len(inputs) != proposal['expected_absolute_inputs'] or len(set(map(c.key, inputs))) != len(inputs):
            raise ValueError('Final link closure differs: ' + tag)
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
            'frozen': list({c.key(x['path']): x for x in frozen}.values()),
            'host_TUs': len(rows), 'native_TUs': 0, 'SDK_build': False, 'CMake_run': False,
            'public_inline_header': b.identity(ROOT / 'include/hyle/compute/model_ops.h'),
            'private_PlanState': b.identity(ROOT / 'src/graph/plan_state.h'),
            'GPU_run': False}
    path = out / 'plan.json'
    c.save(path, plan)
    check(plan)
    for row in cached.values():
        if not b.same(row):
            raise ValueError('Cached object/library differs: ' + row['path'])
    print('PLAN', path, flush=True)
    if not args.build:
        return
    env, _ = b.environment(links['qwen']['command'], links['qwen']['inputs'], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        deps = c.read(out / (row['tag'] + '-deps.json'))['Data']['Includes']
        if c.key(ROOT / 'include/hyle/compute/model_ops.h') not in {c.key(x) for x in deps}:
            raise ValueError('Fresh inline owner did not consume the public header: ' + row['tag'])
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': b.identity(row['object']),
            'public_header': plan['public_inline_header']})
    for row in cached.values():
        if not b.same(row):
            raise ValueError('Cached input changed during compilation: ' + row['path'])
    for tag in ('cpu', 'cuda', 'qwen'):
        row = links[tag]
        c.execute(tag + '-link', row['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': row['command'],
            'inputs': [b.identity(x) for x in row['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(row['image']))
    c.save(out / 'summary.json', {'passed': True, 'host_TUs': len(rows), 'native_TUs': 0,
        'SDK_build': False, 'GPU_run': False, 'fresh_owners_read_current_inline_header': True})
    print('BUILD_COMPLETE', path, flush=True)


if __name__ == '__main__':
    main()
