"""Increment native layout guards, provider identity and one existing test TU."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('layout_prior_build', ARCH / 'cuda-gdn-l2-epilogue/build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
b, c = previous.b, previous.c
V18 = ARCH / 'cuda-gdn-l2-epilogue/checks/20261019T102437'
V17 = ARCH / 'cuda-explicit-rope/checks/20261019T100154'


def check(plan):
    for row in plan['frozen'] + plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Retained input/source drift: ' + row['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--native-receipts', type=Path, required=True)
    args = parser.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    freeze = c.read(STAGE / 'native-source-freeze.json')
    frozen = [b.identity(p) for p in (Path(__file__), STAGE / 'native-source-freeze.json',
        STAGE / 'provider-version.h', STAGE / 'tests-source-freeze.json',
        ROOT / 'third_party/ggml_cuda_runtime/patches.json', ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT / 'cmake/HyleDependencyLock.json')]
    for relative, expected in freeze['sources'].items():
        path = STAGE / 'native-source' / relative
        if b.identity(path)['sha256'] != expected:
            raise ValueError('Native source differs')
        frozen.append(b.identity(path))
    specs = (
        ('ggml-cuda', 'native', V18 / 'ggml-cuda-identity.json', STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'),
        ('mmvq', 'native', V18 / 'ggml-cuda-identity.json', STAGE / 'native-source/src/ggml-cuda/mmvq.cu'),
        ('provider', 'host', V18 / 'provider-identity.json', ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),
        ('stable-test', 'host', V17 / 'stable-test-identity.json', ROOT / 'tests/graph_route_cuda/stable_silu_test.cc'),
    )
    native_plan_path = args.native_receipts.resolve() / 'plan.json'
    native_plan = c.read(native_plan_path)
    check(native_plan)
    if not c.read(native_plan_path.parent / 'summary.json')['passed']:
        raise ValueError('Successful native increment required')
    frozen.append(b.identity(native_plan_path))
    rows, replacements, test_replacement, native_inputs = [], {}, {}, []
    for tag, kind, recipe_path, source in specs:
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Retained object differs: ' + tag)
        template = recipe['command']
        if kind == 'native':
            receipt_path = native_plan_path.parent / (tag + '-identity.json')
            receipt = c.read(receipt_path)
            if not b.same(receipt['object']) or receipt['source']['sha256'] != b.identity(source)['sha256']:
                raise ValueError('Precompiled native object/source differs: ' + tag)
            frozen.append(b.identity(receipt_path))
            native_inputs.append(receipt['object'])
            obj = receipt['object']['path']
            command = receipt['command']
        else:
            if tag == 'provider':
                template = ['/FI' + str(STAGE / 'provider-version.h') if x.lower().startswith('/fi') else x for x in template]
            command = b.host_command(template, source, tag, out)
            obj = str(out / (tag + '.obj'))
        if kind != 'native':
            rows.append({'tag': tag, 'kind': kind, 'command': command, 'source': b.identity(source), 'object': obj})
        if tag != 'mmvq':
            replacements[c.key(recipe['object']['path'])] = obj
        if tag == 'stable-test':
            test_replacement[c.key(recipe['object']['path'])] = obj
        frozen.extend((b.identity(recipe_path), b.identity(source)))
    qwen, cuda = c.read(V18 / 'qwen-link-plan.json'), c.read(V18 / 'cuda-link-plan.json')
    cached = {c.key(r['path']): r for r in qwen['inputs'] + cuda['inputs']}
    cached.update({c.key(r['path']): r for r in native_inputs})
    baseline = c.read(V18 / 'qwen-image.json')
    if not b.same(baseline):
        raise ValueError('Retained v18 model baseline is unavailable')
    frozen.append(baseline)
    links = {}
    for tag, source, replace, count in (('cuda-before', cuda, test_replacement, 132),
                                       ('qwen', qwen, replacements, 125), ('cuda', cuda, replacements, 133)):
        present = {c.key(r['path']) for r in source['inputs']}
        expected = 1 if tag == 'cuda-before' else (2 if tag == 'qwen' else 3)
        if len(present.intersection(replace)) != expected:
            raise ValueError('Replacement owner set differs: ' + tag)
        for owner in present.intersection(replace):
            if sum(c.key(x) == owner for x in source['command']) != 1:
                raise ValueError('Duplicate owner: ' + tag)
        command = [replace.get(c.key(x), x) for x in source['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if tag != 'cuda-before':
            # Resolve the updated external entry points from this object before
            # archive extraction. No SDK/library or unrelated object is rebuilt.
            command.insert(1, next(r['path'] for r in native_inputs if Path(r['path']).name == 'mmvq.obj'))
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = previous.previous.original.inputs(command)
        if len(inputs) != count or len({c.key(x) for x in inputs}) != count:
            raise ValueError('Input closure changed: ' + tag)
        links[tag] = {'command': command, 'image': str(image), 'inputs': inputs}
    links['baseline'] = {'command': qwen['command'], 'image': baseline['path'],
                         'inputs': [r['path'] for r in qwen['inputs']]}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({c.key(r['path']): r for r in frozen}.values()),
        'native_TUs': 2, 'host_TUs': 2, 'SDK_build': False, 'CMake_run': False,
        'native_TUs_compiled_here': 0, 'native_receipts': str(native_plan_path.parent),
        'native_source_id': freeze['source_id'], 'GPU_run': False, 'baseline_model_image_reused': True,
        'red_green_test_closure': 'before changes test object only in132inputs; after changes test/main/provider and adds exact mmvq object before archive resolution'}
    target = out / 'plan.json'
    c.save(target, plan)
    check(plan)
    print('PLAN', target, flush=True)
    if not args.build:
        return
    (out / 'tmp').mkdir()
    env, _ = b.environment(links['qwen']['command'], [r['path'] for r in cached.values()], out)
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'], 'source': row['source'], 'object': b.identity(row['object'])})
    for tag in ('cuda-before', 'qwen', 'cuda'):
        link = links[tag]
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'], 'inputs': [b.identity(x) for x in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    c.save(out / 'baseline-image.json', baseline)
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 2, 'host_TUs': 2, 'SDK_build': False, 'GPU_run': False})
    print('BUILD_COMPLETE', target, flush=True)


if __name__ == '__main__':
    main()
