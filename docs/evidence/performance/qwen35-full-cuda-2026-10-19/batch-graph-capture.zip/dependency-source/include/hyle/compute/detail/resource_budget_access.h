#pragma once

#include "hyle/compute/resource_budget.h"

namespace hyle::compute::detail {
// Cold lifetime composition only: the accounting wrapper retains its budget,
// while the actual allocator object must be retained by its real owner.
struct ResourceBudgetAccess final {
  static HYLE_COMPUTE_API mem::AllocatorRef
  backing_allocator(const ResourceBudget &) noexcept;
  static HYLE_COMPUTE_API mem::AllocatorRef
  backing_allocator(const ResourceBudget::Reservation &) noexcept;
};
} // namespace hyle::compute::detail
