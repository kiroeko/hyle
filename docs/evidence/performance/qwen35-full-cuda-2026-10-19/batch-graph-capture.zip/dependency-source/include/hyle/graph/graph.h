#pragma once

#include <array>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <span>
#include <type_traits>
#include <utility>

#include "hyle/compute/operation.h"
#include "hyle/error/result.h"
#include "hyle/graph/visibility.h"
#include "hyle/mem/allocator.h"

namespace hyle::graph {

namespace detail {
struct GraphIdentity;
struct GraphState;
struct BuilderState;
struct GraphAccess;
} // namespace detail

enum class ValueKind : std::uint8_t {
  kInput = 0,
  kConstant,
  kNodeOutput,
};

// Identity of external state, not a tensor value or MemoryResource allocator.
// Different IDs are independent only after compile validates their backing.
class EffectResourceId final {
public:
  constexpr EffectResourceId() noexcept = default;
  constexpr bool valid() const noexcept { return generation_ != 0; }
  constexpr explicit operator bool() const noexcept { return valid(); }
  constexpr std::uint32_t ordinal() const noexcept { return ordinal_; }
  friend constexpr bool operator==(EffectResourceId,
                                   EffectResourceId) noexcept = default;

private:
  friend struct detail::GraphIdentity;
  constexpr EffectResourceId(std::uint64_t generation,
                             std::uint32_t ordinal) noexcept
      : generation_(generation), ordinal_(ordinal) {}
  std::uint64_t generation_ = 0;
  std::uint32_t ordinal_ = 0;
};

// Graph-local identity of an independent or derived dimension. Reusing an ID
// shares its value; finite arithmetic and explicit guards are built separately.
// This is not a general symbolic equation solver.
class DimensionId final {
public:
  constexpr DimensionId() noexcept = default;

  constexpr bool valid() const noexcept { return generation_ != 0; }
  constexpr explicit operator bool() const noexcept { return valid(); }
  constexpr std::uint32_t ordinal() const noexcept { return ordinal_; }

  friend constexpr bool operator==(DimensionId, DimensionId) noexcept = default;

private:
  friend struct detail::GraphIdentity;
  constexpr DimensionId(std::uint64_t generation,
                        std::uint32_t ordinal) noexcept
      : generation_(generation), ordinal_(ordinal) {}

  std::uint64_t generation_ = 0;
  std::uint32_t ordinal_ = 0;
};

struct DimensionBounds final {
  std::int64_t minimum = 1;
  std::int64_t maximum = 1;
  std::int64_t multiple_of = 1;

  friend constexpr bool operator==(DimensionBounds,
                                   DimensionBounds) noexcept = default;
};

// One logical extent is either a non-negative fixed value or one graph-local
// bounded symbol. An invalid fixed value remains representable so fallible
// TensorSpec construction can diagnose it without exceptions.
class Dimension final {
public:
  constexpr Dimension() noexcept = default;
  constexpr explicit Dimension(DimensionId symbol) noexcept : symbol_(symbol) {}

  static constexpr Dimension fixed(std::int64_t value) noexcept {
    Dimension result;
    result.fixed_ = value;
    return result;
  }

  constexpr bool valid() const noexcept {
    return symbol_.valid() || fixed_ >= 0;
  }
  constexpr bool is_fixed() const noexcept { return !symbol_.valid(); }
  constexpr bool is_symbol() const noexcept { return symbol_.valid(); }
  constexpr std::int64_t fixed_value() const noexcept { return fixed_; }
  constexpr DimensionId symbol() const noexcept { return symbol_; }

  friend constexpr bool operator==(Dimension, Dimension) noexcept = default;

private:
  DimensionId symbol_{};
  std::int64_t fixed_ = -1;
};

// Graph-time, metadata-only View. Dimensions (including slice start/count)
// use this builder's independent or derived values; axis/step/permutation are
// fixed. No tensor payload is read. Compile binds a concrete compute::View.
class ViewSpec final {
public:
  ViewSpec() noexcept = default;

  HYLE_GRAPH_API static Result<ViewSpec>
  reshape(std::span<const Dimension> dimensions) noexcept;
  HYLE_GRAPH_API static Result<ViewSpec> slice(std::int32_t axis,
                                               Dimension start, Dimension count,
                                               std::int64_t step = 1) noexcept;
  HYLE_GRAPH_API static Result<ViewSpec>
  permute(std::span<const std::int32_t> axes) noexcept;
  HYLE_GRAPH_API static Result<ViewSpec>
  broadcast_to(std::span<const Dimension> dimensions) noexcept;

  bool valid() const noexcept { return valid_; }
  explicit operator bool() const noexcept { return valid(); }
  compute::ViewKind kind() const noexcept { return kind_; }
  std::span<const Dimension> dimensions() const noexcept {
    return {dimensions_.data(), kind_ == compute::ViewKind::kReshape ||
                                        kind_ == compute::ViewKind::kBroadcast
                                    ? rank_
                                    : std::size_t{0}};
  }
  std::int32_t axis() const noexcept { return axis_; }
  Dimension start() const noexcept { return start_; }
  Dimension count() const noexcept { return count_; }
  std::int64_t step() const noexcept { return step_; }
  std::span<const std::int32_t> permutation() const noexcept {
    return {permutation_.data(),
            kind_ == compute::ViewKind::kPermute ? rank_ : std::size_t{0}};
  }
  HYLE_GRAPH_API bool is_symbolic() const noexcept;

private:
  std::array<Dimension, compute::kMaxTensorRank> dimensions_{};
  std::array<std::int32_t, compute::kMaxTensorRank> permutation_{};
  Dimension start_ = Dimension::fixed(0);
  Dimension count_ = Dimension::fixed(0);
  std::int64_t step_ = 1;
  std::int32_t axis_ = 0;
  std::uint8_t rank_ = 0;
  compute::ViewKind kind_ = compute::ViewKind::kReshape;
  bool valid_ = false;
};

enum class TensorSpecKind : std::uint8_t {
  kInvalid = 0,
  kConcrete,
  kDense,
  kBlockedDense,
  kInferred,
};

// Logical graph-time tensor metadata. Concrete preserves every TensorDesc
// layout. Symbolic external storage supports dense/blocked-dense descriptions.
// An inferred output constrains shape/type/format but obtains physical strides
// and block axis from its producer; it is not an independent storage layout.
// Arbitrary symbolic strides and opaque layouts are not guessed.
class TensorSpec final {
public:
  TensorSpec() noexcept = default;

  HYLE_GRAPH_API static Result<TensorSpec>
  concrete(compute::TensorDesc description) noexcept;
  HYLE_GRAPH_API static Result<TensorSpec>
  dense(compute::DataType type, std::span<const Dimension> dimensions) noexcept;
  HYLE_GRAPH_API static Result<TensorSpec>
  blocked_dense(compute::DataType logical_type,
                std::span<const Dimension> dimensions,
                compute::StorageFormat format) noexcept;
  // Output-only: the operation schema owns the physical layout. Cannot be
  // used for input()/constant(). Even fixed dimensions require inference.
  HYLE_GRAPH_API static Result<TensorSpec>
  inferred(compute::DataType type, std::span<const Dimension> dimensions,
           compute::StorageFormat format = {}) noexcept;

  bool valid() const noexcept { return kind_ != TensorSpecKind::kInvalid; }
  explicit operator bool() const noexcept { return valid(); }
  TensorSpecKind kind() const noexcept { return kind_; }
  compute::DataType data_type() const noexcept { return type_; }
  const compute::StorageFormat &storage_format() const noexcept {
    return format_;
  }
  std::size_t rank() const noexcept { return rank_; }
  std::span<const Dimension> dimensions() const noexcept {
    return {dimensions_.data(), rank_};
  }
  // Includes unresolved producer-inferred layout, even with fixed extents.
  HYLE_GRAPH_API bool is_symbolic() const noexcept;
  // Succeeds for an original concrete description or a fixed dense/
  // blocked-dense spec. Symbolic specs require graph specialization.
  HYLE_GRAPH_API Result<compute::TensorDesc>
  concrete_description() const noexcept;

  friend constexpr bool operator==(const TensorSpec &left,
                                   const TensorSpec &right) noexcept {
    if (left.kind_ != right.kind_ || left.type_ != right.type_ ||
        left.rank_ != right.rank_ || left.format_ != right.format_ ||
        left.concrete_ != right.concrete_) {
      return false;
    }
    for (std::size_t index = 0; index < left.rank_; ++index) {
      if (left.dimensions_[index] != right.dimensions_[index])
        return false;
    }
    return true;
  }

private:
  std::array<Dimension, compute::kMaxTensorRank> dimensions_{};
  compute::TensorDesc concrete_{};
  compute::StorageFormat format_{};
  compute::DataType type_ = compute::DataType::kUnknown;
  std::uint8_t rank_ = 0;
  TensorSpecKind kind_ = TensorSpecKind::kInvalid;
};

struct ShapeBinding final {
  DimensionId dimension{};
  std::int64_t value = 0;

  friend constexpr bool operator==(ShapeBinding,
                                   ShapeBinding) noexcept = default;
};

// Graph-local identity. The private generation prevents IDs from another
// builder/graph being accepted merely because their ordinals happen to match.
// ordinal() is useful for diagnostics; runtime binding remains O(1).
class ValueId final {
public:
  constexpr ValueId() noexcept = default;

  constexpr bool valid() const noexcept { return generation_ != 0; }
  constexpr explicit operator bool() const noexcept { return valid(); }
  constexpr ValueKind kind() const noexcept { return kind_; }
  constexpr std::uint32_t ordinal() const noexcept { return ordinal_; }

  friend constexpr bool operator==(ValueId, ValueId) noexcept = default;

private:
  friend struct detail::GraphIdentity;
  constexpr ValueId(std::uint64_t generation, ValueKind kind,
                    std::uint32_t ordinal) noexcept
      : generation_(generation), ordinal_(ordinal), kind_(kind) {}

  std::uint64_t generation_ = 0;
  std::uint32_t ordinal_ = 0;
  ValueKind kind_ = ValueKind::kInput;
};

class NodeId final {
public:
  constexpr NodeId() noexcept = default;

  constexpr bool valid() const noexcept { return generation_ != 0; }
  constexpr explicit operator bool() const noexcept { return valid(); }
  constexpr std::uint32_t ordinal() const noexcept { return ordinal_; }

  friend constexpr bool operator==(NodeId, NodeId) noexcept = default;

private:
  friend struct detail::GraphIdentity;
  constexpr NodeId(std::uint64_t generation, std::uint32_t ordinal) noexcept
      : generation_(generation), ordinal_(ordinal) {}

  std::uint64_t generation_ = 0;
  std::uint32_t ordinal_ = 0;
};

// Immutable, self-contained logical DAG metadata. Copies share one intrusive
// state; no Graph owns tensor payload, Context, Queue or provider artifacts.
class Graph final {
public:
  Graph() noexcept = default;
  HYLE_GRAPH_API Graph(const Graph &other) noexcept;
  HYLE_GRAPH_API Graph &operator=(const Graph &other) noexcept;
  HYLE_GRAPH_API Graph(Graph &&other) noexcept;
  HYLE_GRAPH_API Graph &operator=(Graph &&other) noexcept;
  HYLE_GRAPH_API ~Graph();

  bool valid() const noexcept { return state_ != nullptr; }
  explicit operator bool() const noexcept { return valid(); }
  HYLE_GRAPH_API std::size_t value_count() const noexcept;
  HYLE_GRAPH_API std::size_t dimension_count() const noexcept;
  HYLE_GRAPH_API std::size_t independent_dimension_count() const noexcept;
  HYLE_GRAPH_API std::size_t input_count() const noexcept;
  HYLE_GRAPH_API std::size_t constant_count() const noexcept;
  HYLE_GRAPH_API std::size_t node_count() const noexcept;
  HYLE_GRAPH_API std::size_t output_count() const noexcept;
  HYLE_GRAPH_API std::size_t effect_resource_count() const noexcept;
  HYLE_GRAPH_API Result<EffectResourceId>
  effect_resource_id(std::size_t index) const noexcept;

  HYLE_GRAPH_API Result<DimensionId>
  dimension_id(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<DimensionBounds>
  dimension_bounds(DimensionId dimension) const noexcept;
  HYLE_GRAPH_API Result<bool>
  dimension_is_independent(DimensionId dimension) const noexcept;

  HYLE_GRAPH_API Result<ValueId> input_id(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const compute::TensorDesc &>
  input_description(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const TensorSpec &>
  input_spec(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<ValueId>
  constant_id(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const compute::TensorDesc &>
  constant_description(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const TensorSpec &>
  constant_spec(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<NodeId> node_id(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<compute::OperationKind>
  operation_kind(NodeId node) const noexcept;
  // Unbound ViewSpec nodes have no concrete Operation: returns
  // FailedPrecondition. Use view_spec() to inspect their logical parameters.
  HYLE_GRAPH_API Result<const compute::Operation &>
  operation(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<const ViewSpec &> view_spec(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<std::size_t>
  node_input_count(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<ValueId>
  node_input(NodeId node, std::size_t input_index) const noexcept;
  HYLE_GRAPH_API Result<std::size_t>
  node_dependency_count(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<NodeId>
  node_dependency(NodeId node, std::size_t dependency_index) const noexcept;
  HYLE_GRAPH_API Result<std::size_t>
  node_resource_count(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<EffectResourceId>
  node_resource(NodeId node, std::size_t port) const noexcept;
  HYLE_GRAPH_API Result<std::size_t>
  node_output_count(NodeId node) const noexcept;
  HYLE_GRAPH_API Result<ValueId>
  result(NodeId node, std::size_t output_index = 0) const noexcept;
  HYLE_GRAPH_API Result<NodeId> producer(ValueId value) const noexcept;
  HYLE_GRAPH_API Result<ValueId>
  output_id(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const compute::TensorDesc &>
  output_description(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const TensorSpec &>
  output_spec(std::size_t index = 0) const noexcept;
  HYLE_GRAPH_API Result<const compute::TensorDesc &>
  value_description(ValueId value) const noexcept;
  HYLE_GRAPH_API Result<const TensorSpec &>
  value_spec(ValueId value) const noexcept;

private:
  friend struct detail::GraphAccess;
  explicit Graph(detail::GraphState *state) noexcept : state_(state) {}
  detail::GraphState *state_ = nullptr;
};

struct GraphBuilderOptions final {
  // Empty selects mem::system_allocator(). The backing must outlive the
  // builder and every Graph published from it.
  mem::AllocatorRef metadata_allocator{};
};

// Fallible, single-owner DAG construction. add_node() accepts only values
// already produced by this builder, making cycles unrepresentable. A failed
// mutator leaves logical content unchanged; capacity growth may remain
// reserved.
class GraphBuilder final {
public:
  GraphBuilder() noexcept = default;
  GraphBuilder(const GraphBuilder &) = delete;
  GraphBuilder &operator=(const GraphBuilder &) = delete;
  HYLE_GRAPH_API GraphBuilder(GraphBuilder &&other) noexcept;
  HYLE_GRAPH_API GraphBuilder &operator=(GraphBuilder &&other) noexcept;
  HYLE_GRAPH_API ~GraphBuilder();

  HYLE_GRAPH_API static Result<GraphBuilder>
  create(GraphBuilderOptions options = {}) noexcept;

  bool valid() const noexcept { return state_ != nullptr; }
  explicit operator bool() const noexcept { return valid(); }

  HYLE_GRAPH_API Result<EffectResourceId> effect_resource() noexcept;
  // Bind every schema resource port in its declared order. Rebinding before
  // finish is allowed; repeated ports can name the same resource. Does not
  // insert edges: conflicting accesses still need data/control dependencies.
  HYLE_GRAPH_API Status bind_resources(
      NodeId node, std::span<const EffectResourceId> resources) noexcept;

  HYLE_GRAPH_API Result<DimensionId> dimension(DimensionBounds bounds) noexcept;
  // Operands must be nonnegative constants or existing IDs from this builder.
  // Derived IDs are evaluated, never supplied as ShapeBindings. Their bounds
  // are conservative envelopes; guards can exclude points inside them.
  HYLE_GRAPH_API Result<DimensionId> dimension_sum(Dimension left,
                                                   Dimension right) noexcept;
  HYLE_GRAPH_API Result<DimensionId>
  dimension_product(Dimension left, Dimension right) noexcept;
  // Requires nonzero, exact division at specialization (no rounding).
  HYLE_GRAPH_API Result<DimensionId>
  dimension_quotient(Dimension left, Dimension right) noexcept;
  HYLE_GRAPH_API Result<DimensionId>
  dimension_broadcast(Dimension left, Dimension right) noexcept;
  HYLE_GRAPH_API Status require_dimension_equal(Dimension left,
                                                Dimension right) noexcept;
  HYLE_GRAPH_API Status require_dimension_less_equal(Dimension left,
                                                     Dimension right) noexcept;

  HYLE_GRAPH_API Result<ValueId>
  input(compute::TensorDesc description) noexcept;
  HYLE_GRAPH_API Result<ValueId> input(TensorSpec spec) noexcept;
  HYLE_GRAPH_API Result<ValueId>
  constant(compute::TensorDesc description) noexcept;
  HYLE_GRAPH_API Result<ValueId> constant(TensorSpec spec) noexcept;
  HYLE_GRAPH_API Result<NodeId>
  add_node(compute::Operation operation,
           std::span<const ValueId> inputs) noexcept;
  HYLE_GRAPH_API Result<NodeId>
  add_node(compute::Operation operation, std::span<const ValueId> inputs,
           std::span<const TensorSpec> outputs) noexcept;
  // Infers logical output axes and preserves the producer-derived layout.
  // Shape expressions and input must belong to this builder. Concrete-only
  // calls use the ordinary compute::View path immediately.
  HYLE_GRAPH_API Result<NodeId> add_node(ViewSpec view, ValueId input) noexcept;
  HYLE_GRAPH_API Result<ValueId> add(ViewSpec view, ValueId input) noexcept;
  HYLE_GRAPH_API Result<ValueId>
  result(NodeId node, std::size_t output_index = 0) const noexcept;
  HYLE_GRAPH_API Status depends_on(NodeId node, NodeId prerequisite) noexcept;
  template <class Descriptor, class... Inputs>
    requires std::constructible_from<compute::Operation, Descriptor> &&
             (std::same_as<std::remove_cvref_t<Inputs>, ValueId> && ...)
  Result<ValueId> add(Descriptor operation, Inputs... inputs) noexcept {
    const compute::Operation erased(std::move(operation));
    if (compute::operation_traits(erased).outputs != 1) {
      return std::unexpected(Status::InvalidArgument(
          "multi-output operation requires add_node() and result()"));
    }
    const std::array<ValueId, sizeof...(Inputs)> values{inputs...};
    auto node = add_node(erased, values);
    if (!node)
      return std::unexpected(std::move(node).error());
    return result(*node);
  }
  template <class Descriptor, class... Inputs>
    requires std::constructible_from<compute::Operation, Descriptor> &&
             (std::same_as<std::remove_cvref_t<Inputs>, ValueId> && ...)
  Result<ValueId> add(Descriptor operation, TensorSpec output,
                      Inputs... inputs) noexcept {
    const compute::Operation erased(std::move(operation));
    if (compute::operation_traits(erased).outputs != 1) {
      return std::unexpected(Status::InvalidArgument(
          "multi-output operation requires add_node() and result()"));
    }
    const std::array<ValueId, sizeof...(Inputs)> values{inputs...};
    const std::array<TensorSpec, 1> outputs{output};
    auto node = add_node(erased, values, outputs);
    if (!node)
      return std::unexpected(std::move(node).error());
    return result(*node);
  }
  HYLE_GRAPH_API Status publish(ValueId value) noexcept;
  HYLE_GRAPH_API Result<Graph> finish() && noexcept;

private:
  explicit GraphBuilder(detail::BuilderState *state) noexcept : state_(state) {}
  detail::BuilderState *state_ = nullptr;
};

} // namespace hyle::graph
