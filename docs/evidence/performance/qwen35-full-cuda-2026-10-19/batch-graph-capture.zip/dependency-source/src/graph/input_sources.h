#pragma once

#include <cstddef>
#include <span>

#include "hyle/graph/executable.h"

namespace hyle::graph::detail {
struct InvocationState;
struct InputSourcesState;

// Optional cold attachment. Its immutable source owners outlive provider
// slots; per-run facts describe only uses of the original physical Plan.
class InputSourcesOwner final {
public:
  InputSourcesOwner() noexcept = default;
  explicit InputSourcesOwner(InputSourcesState *state) noexcept : state_(state) {}
  InputSourcesOwner(const InputSourcesOwner &) = delete;
  InputSourcesOwner &operator=(const InputSourcesOwner &) = delete;
  HYLE_GRAPH_API InputSourcesOwner(InputSourcesOwner &&) noexcept;
  HYLE_GRAPH_API InputSourcesOwner &operator=(InputSourcesOwner &&) noexcept;
  HYLE_GRAPH_API ~InputSourcesOwner();
  InputSourcesState *get() const noexcept { return state_; }
  explicit operator bool() const noexcept { return state_ != nullptr; }
  HYLE_GRAPH_API void reset() noexcept;

private:
  InputSourcesState *state_ = nullptr;
};

HYLE_GRAPH_API Status prepare_input_sources(InvocationState &,
    std::span<const QueueBinding>, HostWaitPolicy) noexcept;
HYLE_GRAPH_API void commit_input_sources(InvocationState &) noexcept;
HYLE_GRAPH_API void begin_input_sources(InvocationState &) noexcept;
HYLE_GRAPH_API Result<bool> input_sources_ready(
    InvocationState &, std::size_t segment) noexcept;
HYLE_GRAPH_API Status wait_input_sources(
    InvocationState &, std::size_t segment) noexcept;
HYLE_GRAPH_API Status enqueue_input_sources(InvocationState &, std::size_t segment,
    compute::detail::QueueSequence &) noexcept;
HYLE_GRAPH_API Result<bool> input_results_ready(InvocationState &) noexcept;
HYLE_GRAPH_API Status wait_input_results(InvocationState &) noexcept;
HYLE_GRAPH_API void note_borrowed_input_source(InvocationState &, ValueId) noexcept;
HYLE_GRAPH_API void reset_input_source_bindings(InvocationState &) noexcept;
HYLE_GRAPH_API bool has_input_source(const InvocationState &, ValueId) noexcept;
HYLE_GRAPH_API Status reconcile_input_sources(
    InvocationState &, const Status &graph_terminal) noexcept;
} // namespace hyle::graph::detail
