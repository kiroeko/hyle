"""One CUDA/API trace per old/new image to attribute the observed first-step regression."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_pair_helpers', STAGE / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = STAGE / 'cold-profile'
out.mkdir(exist_ok=False)
rotation = c.read(STAGE / 'performance-prepared/plan.json')
old = STAGE.parent / 'cold-capture-topology/checks/20261019T142405/qwen-link-plan.json'
new_plan = c.read(rotation['build_plan']['path'])
new = Path(new_plan['links']['qwen']['image']).parent / 'qwen-link-plan.json'
nsys = c.read(STAGE.parent / 'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0]
plan = dict(reason='New unprofiled prefill is slower in this nine-process window; inspect actual first capture/instantiate/launch API work.',
    throughput_claim=False, compiled_or_linked=False, runner=b.identity(Path(__file__)), arms={})
for arm, path in [('baseline', old), ('current', new)]:
    dest = out / arm
    dest.mkdir()
    (dest / 'tmp').mkdir()
    request = next(row for row in rotation['requests'] if row['arm'] == arm)
    command = [arg.replace('{output}', str(dest)) for arg in request['command']]
    assert b.identity(command[0]) == rotation['images'][arm]
    stem = dest / 'capture'
    commands = {
        'profile': [nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-graph-trace=node:host-only', '--discard-environment=true', '--output=' + str(stem), *command],
        'export': [nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
    }
    plan['arms'][arm] = dict(image=b.identity(command[0]), link_plan=b.identity(path), commands=commands)
c.save(out / 'plan.json', plan)
for arm, row in plan['arms'].items():
    dest = out / arm
    link = c.read(row['link_plan']['path'])
    env, runtime = b.environment(link['command'], [x['path'] for x in link['inputs']], dest)
    c.save(dest / 'runtime.json', dict(runtime=runtime))
    for tag, command in row['commands'].items():
        c.execute(tag, command, env, dest)
c.save(out / 'summary.json', dict(passed=True, trace_collections=2, throughput_claim=False,
    limits='One trace per image; profiler perturbs duration. Attribute observed API work, not stable end-to-end gains.'))
print('PROFILE_PAIR_COMPLETE', out, flush=True)
