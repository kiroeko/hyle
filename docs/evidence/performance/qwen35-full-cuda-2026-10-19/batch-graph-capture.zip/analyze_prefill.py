"""Read existing unprofiled logs and two SQLite traces; never launch a workload."""
from pathlib import Path
import hashlib
import json
import re
import sqlite3
import statistics as stats

STAGE = Path(__file__).resolve().parent
METRICS = ("cold_ms", "post_cold_ms", "submit_ms", "step_ms")


def phases(text):
    cold = re.findall(r"prepared T=(\d+) visible=(\d+) replay=(\w+) cold_batch_seconds=([\deE.+-]+) capture_recorded=(\d+) capture_reused=(\d+)", text)
    hot = re.findall(r"^(prefill|decode\d+) tokens=(\d+) visible=(\d+) seconds=([\deE.+-]+) submit_seconds=([\deE.+-]+) step_seconds=([\deE.+-]+)", text, re.M)
    assert len(cold) == len(hot) == 32
    rows = []
    for a, b in zip(cold, hot):
        assert a[1] == b[2]
        rows.append(dict(name=b[0], cold_ms=float(a[3])*1000,
                         post_cold_ms=float(b[3])*1000, submit_ms=float(b[4])*1000,
                         step_ms=float(b[5])*1000, recorded=int(a[4]), reused=int(a[5])))
    return rows


def unprofiled():
    result = {}
    for arm in ("baseline", "current"):
        runs = []
        for path in sorted((STAGE / "performance-rotation").glob(f"*-{arm}.stderr.log")):
            rows = phases(path.read_text())
            runs.append(dict(log=str(path.relative_to(STAGE)), first=rows[:3],
                             warm7_31_mean_per_token_ms={k: stats.mean(r[k] for r in rows[7:]) for k in METRICS}))
        assert len(runs) == 3
        medians = {name: {k: stats.median(r["first"][index][k] for r in runs) for k in METRICS}
                   for name, index in (("prefill", 0), ("decode1", 1), ("decode2", 2))}
        medians["warm7_31_mean_per_token_ms"] = {
            k: stats.median(r["warm7_31_mean_per_token_ms"][k] for r in runs) for k in METRICS}
        # Means of disjoint components add; independent medians need not add.
        accounting = {k: stats.mean(r["first"][0][k] for r in runs) for k in METRICS}
        accounting["other_before_or_between_timers_ms"] = accounting["step_ms"] - accounting["cold_ms"] - accounting["post_cold_ms"]
        result[arm] = dict(median_ms=medians, prefill_mean_accounting_ms=accounting, samples=runs)
    return result


def trace(arm):
    path = STAGE / "cold-profile" / arm / "capture.sqlite"
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    names = dict(db.execute("select id,value from StringIds"))
    tables = {r[0] for r in db.execute("select name from sqlite_master where type='table'")}
    apis = [dict(r, name=names[r["nameId"]]) for r in db.execute("select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start")]
    streams = list(db.execute("select f.value filename,c.value content from ProcessStreams p join StringIds f on p.filenameId=f.id join StringIds c on p.contentId=c.id"))
    stderr = next(r["content"] for r in streams if "/stderr_" in r["filename"])
    rows = phases(stderr)
    # Final two 512-byte H2D copies are precisely the actual 128 I32 tokens
    # and positions; preceding same-sized weight uploads are outside this step.
    h2d = list(db.execute("select * from CUPTI_ACTIVITY_KIND_MEMCPY where copyKind=1 and bytes=512 order by start"))[-2:]
    assert len(h2d) == 2 and h2d[1]["start"] - h2d[0]["start"] < 1000000
    anchor_api = [a for a in apis if a["correlationId"] in {r["correlationId"] for r in h2d}]
    assert len(anchor_api) == 2
    begin = max(a["end"] for a in anchor_api)
    end = db.execute("select min(start) from CUPTI_ACTIVITY_KIND_MEMCPY where copyKind=1 and bytes=4 and start>?", (begin,)).fetchone()[0]
    phase_apis = [a for a in apis if begin <= a["start"] < end]
    launches = [a for a in phase_apis if a["name"].startswith("cudaGraphLaunch")]
    first_launch = launches[0]["start"]
    before_launch = [a for a in phase_apis if a["start"] < first_launch]
    captures = []
    for a in before_launch:
        if a["name"].startswith("cudaStreamBeginCapture"):
            close = next(b for b in before_launch if b["start"] > a["start"] and b["name"].startswith("cudaStreamEndCapture"))
            captures.append(dict(begin_ns=a["start"], end_ns=close["end"], wall_ms=(close["end"]-a["start"])/1e6))
    def api_summary(prefix, seq):
        chosen = [a for a in seq if a["name"].startswith(prefix)]
        return dict(count=len(chosen), api_sum_ms=sum(a["end"]-a["start"] for a in chosen)/1e6)
    summary = {prefix: api_summary(prefix, before_launch) for prefix in
               ("cudaStreamBeginCapture", "cudaStreamEndCapture", "cudaGraphInstantiate")}
    summary["cudaGraphLaunch"] = api_summary("cudaGraphLaunch", phase_apis)
    fi = db.execute("select k.* from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on k.demangledName=s.id where k.start>=? and k.start<? and s.value like '%BatchPrefillWithRaggedKVCacheKernel%' order by k.start limit 1", (begin, end)).fetchone()
    assert fi
    if fi["graphNodeId"] is None:
        launch = next(a for a in apis if a["correlationId"] == fi["correlationId"])
    else:
        node = fi["graphNodeId"]
        while True:
            original = db.execute("select originalGraphNodeId from CUDA_GRAPH_NODE_EVENTS where graphNodeId=? and originalGraphNodeId is not null limit 1", (node,)).fetchone()
            if original is None:
                break
            node = original[0]
        created = db.execute("select min(start) from CUDA_GRAPH_NODE_EVENTS where graphNodeId=?", (node,)).fetchone()[0]
        launch = next(a for a in apis if a["start"] <= created <= a["end"] and a["name"].startswith("cudaLaunchKernel"))
    previous = max((a for a in apis if a["globalTid"] == launch["globalTid"] and a["end"] <= launch["start"]), key=lambda a:a["end"])
    overlap = db.execute("select sum(min(end,?)-max(start,?)),count(*) from CUPTI_ACTIVITY_KIND_KERNEL where end>? and start<?", (launch["start"], previous["end"], previous["end"], launch["start"])).fetchone()
    return dict(sqlite=str(path.relative_to(STAGE)), sqlite_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                runtime_table="CUPTI_ACTIVITY_KIND_RUNTIME", driver_table_present="CUPTI_ACTIVITY_KIND_DRIVER" in tables,
                driver_note="Selected cuLibraryLoadData/cuKernelGetFunction/cuMemcpyHtoD entries occur in RUNTIME; absence of a separate DRIVER table is not absence of all driver names.",
                profiled_logs_first_three=rows[:3],
                anchor=dict(bytes_each=512, correlations=[r["correlationId"] for r in h2d],
                            host_last_copy_end_ns=begin, next_decode_input_copy_gpu_start_ns=end),
                first_capture_groups=captures, prefill_api_summary=summary,
                first_graph_launch_ns=first_launch,
                anchor_to_first_graph_launch_ms=(first_launch-begin)/1e6,
                capture_begin_to_end_wall_sum_ms=sum(r["wall_ms"] for r in captures),
                first_fi_launch=dict(api=launch["name"], correlation=launch["correlationId"], start_ns=launch["start"], duration_ms=(launch["end"]-launch["start"])/1e6,
                                     previous_api=previous["name"], previous_api_end_ns=previous["end"],
                                     no_observed_main_thread_cuda_api_gap_ms=(launch["start"]-previous["end"])/1e6,
                                     gpu_kernel_duration_overlap_ms=(overlap[0] or 0)/1e6, overlapping_gpu_kernel_count=overlap[1]),
                limits="API sums, capture wall intervals and GPU intervals overlap; never add them as disjoint time. Entire phase0 includes no pre-anchor load/compile costs here. Single profiler sample cannot establish unprofiled speed.")


diagnostic_dir = STAGE / "prefill-commands-diagnostic"
diagnostic_text = (diagnostic_dir / "qwen.stderr.log").read_text()
diagnostic = dict(summary=json.loads((diagnostic_dir / "summary.json").read_text()),
                  prefill=phases(diagnostic_text)[0],
                  ttft_seconds=float(re.search(r"first_token_elapsed_seconds=([\d.]+)", diagnostic_text)[1]),
                  interpretation="One same-image Commands process demonstrates a different first-use cost placement. It is unpaired and cannot establish TTFT improvement or justify a default consumer policy change.")
report = dict(unprofiled=unprofiled(), traces={a:trace(a) for a in ("baseline", "current")},
              commands_single_process_diagnostic=diagnostic,
              primary_explanation="The observed unprofiled regression is confined to first T128 cold preparation. First-use FI host dispatch is now recorded before any outer GraphLaunch, rather than after the first launched ordinary range; loss of CPU/GPU overlap is the leading hypothesis. Its opaque gap is observed, but the internal thunk/lazy-load function and stable net cost are not established.",
              negative_evidence="The one profiled pair does not reproduce the prefill regression and its summed prefill GraphInstantiate API time decreases. Do not attribute the regression to a larger graph's instantiation on this evidence.",
              next_discriminating_metric="If revisited later: first T128 time within native_batch.cu run_batch dispatch before the first FI runtime launch, its GPU overlap and outer record/instantiate separately would distinguish a first-use host thunk from graph-instantiation cost. No additional experiment is requested or run in this review.",
              source_boundaries=["tools/qwen35_text/main.cc:487-555 (step/cold/submit+wait/readback boundaries)", "src/compute_provider_flashinfer/flashinfer_provider.cc:337-357 (existing run resolves pointers then invokes native math)", "src/compute_provider_flashinfer/native_batch.cu:35-76 (original templated dispatch)", "src/compute_batch/batch_execution.cc:837-853 (direct run during recording)", "src/compute_backend_cuda/cuda_backend.cc:1267-1304 (EndCapture/GraphInstantiate)", "src/graph/executable.cc:9137-9191 (capture/record/end/retire)"],
              new_GPU_runs=0, new_builds=0, product_changes=0)
out = STAGE / "prefill-regression-review.json"
out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(path=str(out), sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                     profile_prefill_api={a:r["prefill_api_summary"] for a,r in report["traces"].items()},
                     first_fi={a:r["first_fi_launch"] for a,r in report["traces"].items()}), indent=2))
