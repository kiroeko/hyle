"""Run the changed workspace fixture and relevant original Graph capture guards."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_capture_cpu_helpers', STAGE / 'build.py')
bld = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bld)
b, c = bld.b, bld.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
bld.check(plan['frozen'])
assert c.read(path.parent / 'summary.json')['passed']
out = STAGE / 'cpu-tests-final'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
image = b.identity(plan['links']['cpu']['image'])
assert image == c.read(path.parent / 'cpu-image.json')
exact = [
    'GraphRegions.CapturesAndReplaysACommandSegmentWithoutRewalkingItsSteps',
    'GraphRegions.CapturesCompatibleRangesAroundAnUncapturableCommandInOneSequence',
    'GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode',
    'GraphRegions.FailedSelectedConfigurationInvalidatesBeforeItsCallback',
    'GraphRegions.BorrowedCaptureLaunchUsesOriginalAdmissionAndRejectsForeignContext',
    'GraphRegions.PreparedReplayChecksReplacedQueueOwnerAndClosedContext',
    'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves',
]
env, _ = b.environment(plan['links']['cpu']['command'], plan['links']['cpu']['inputs'], out)
command = [image['path'], '--gtest_filter=' + ':'.join(exact + ['BatchWorkspace.*']),
    '--gtest_output=xml:' + str(out / 'results.xml')]
c.execute('cpu', command, env, out)
cases = ET.parse(out / 'results.xml').findall('.//testcase')
names = {row.attrib['classname'] + '.' + row.attrib['name'] for row in cases}
passed = (set(exact) <= names and len(cases) == 12 and
    'BatchWorkspace.BorrowedCommandGatePrecedesScratchAndPlanChanges' in names and
    all(not any(row.find(tag) is not None for tag in ('failure', 'skipped', 'error')) for row in cases))
c.save(out / 'summary.json', dict(passed=passed, tests=len(cases), skipped=0,
    exact_tests=sorted(names), image=image, build_plan=b.identity(path)))
if not passed:
    raise ValueError('Expected12 exact CPU tests without failures or skips')
print('CPU_TESTS', len(cases), 'passed', flush=True)
