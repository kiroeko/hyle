"""Refresh the common seal fix and one actual CUDA fixture; no SDK rebuild."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parent.parents[1]
BASE = STAGE / 'checks/20261019T150633'
spec = importlib.util.spec_from_file_location('batch_capture_final_helpers', STAGE / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = STAGE / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-seal')
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
bases = {arm: c.read(BASE / (arm + '-link-plan.json')) for arm in ('cpu', 'qwen')}
prior = c.read(BASE / 'plan.json')
seal = c.read(STAGE / 'source-freeze-final.json')
frozen = [b.identity(row['path']) for row in prior['frozen']]
frozen += [b.identity(p) for p in (Path(__file__), STAGE / 'source-freeze-final.json', BASE / 'plan.json')]
for row in seal['files']:
    actual = b.identity(ROOT / row['source'])
    assert actual['sha256'] == row['after']['sha256'], row['source']
    frozen += [actual, b.identity(row['after']['path'])]
frozen = list({c.key(row['path']): row for row in frozen}.values())
rows = []
for tag, source, recipe_path, arms in [
    ('executable', ROOT / 'src/graph/executable.cc', BASE / 'executable-identity.json', ('cpu', 'qwen')),
    ('region-test', ROOT / 'tests/graph/region_provider_test.cc', BASE / 'region-test-identity.json', ('cpu',)),
    ('capture-test', ROOT / 'tests/graph_batch/batch_capture_test.cc', BASE / 'region-test-identity.json', ('capture',)),
]:
    recipe = c.read(recipe_path)
    rows.append(dict(tag=tag, source=b.identity(source), command=b.host_command(recipe['command'], source, tag, out),
        object=str(out / (tag + '.obj')), old_object=None if tag == 'capture-test' else recipe['object'], arms=arms))
cached = {c.key(row['path']): row for base in bases.values() for row in base['inputs']}
links = {}
for arm, base in bases.items():
    replacements = {c.key(row['old_object']['path']): row['object'] for row in rows if arm in row['arms']}
    assert set(replacements) <= {c.key(row['path']) for row in base['inputs']}
    command = [replacements.get(c.key(arg), arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    links[arm] = dict(command=command, inputs=h.helpers.link_inputs(command), image=str(image))
qwen_main = [row['path'] for row in bases['qwen']['inputs'] if Path(row['path']).name == '21-qwen35_text-main.obj']
assert len(qwen_main) == 1
gtest = [row['path'] for row in bases['cpu']['inputs'] if Path(row['path']).name in ('gtest.lib', 'gtest_main.lib')]
assert len(gtest) == 2
command = [arg for arg in links['qwen']['command'] if c.key(arg) != c.key(qwen_main[0])
    and not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command[1:1] = [rows[2]['object'], *gtest]
image = out / 'capture.exe'
command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
links['capture'] = dict(command=command, inputs=h.helpers.link_inputs(command), image=str(image))
assert [len(links[arm]['inputs']) for arm in ('cpu', 'qwen', 'capture')] == [115, 127, 129]
for link in links.values():
    assert len(link['inputs']) == len(set(map(c.key, link['inputs'])))
plan = dict(compile=rows, links=links, frozen=frozen, cached_inputs=list(cached.values()),
    host_TUs=3, native_TUs=0, SDK_build=False, GPU_run=False,
    inherited_successful_build=b.identity(BASE / 'summary.json'), common_seal_fix=True)
c.save(out / 'plan.json', plan)
print('PLAN', out / 'plan.json', flush=True)
h.check(frozen)
for row in cached.values():
    assert b.same(row), row['path']
env, _ = b.environment(links['qwen']['command'], list(cached), out)
identities = dict(cached)
deps = []
for row in rows:
    c.execute(row['tag'] + '-compile', row['command'], env, out)
    h.check(frozen)
    data = c.read(out / (row['tag'] + '-deps.json'))['Data']
    record = dict(source=row['source'], command=row['command'], object=b.identity(row['object']),
        dependencies=[b.identity(p) for p in [data['Source'], *data['Includes']]])
    c.save(out / (row['tag'] + '-identity.json'), record)
    identities[c.key(row['object'])] = record['object']
    deps.append(record)
for arm, link in links.items():
    c.execute(arm + '-link', link['command'], env, out)
    h.check(frozen)
    c.save(out / (arm + '-link-plan.json'), dict(command=link['command'], inputs=[identities[c.key(p)] for p in link['inputs']]))
    c.save(out / (arm + '-image.json'), b.identity(link['image']))
c.save(out / 'source-dependencies.json', deps)
c.save(out / 'summary.json', dict(passed=True, host_TUs=3, native_TUs=0, SDK_build=False, GPU_run=False))
c.save(STAGE / 'latest-check.json', dict(plan=str(out / 'plan.json')))
print('BUILD_COMPLETE', out / 'plan.json', flush=True)
