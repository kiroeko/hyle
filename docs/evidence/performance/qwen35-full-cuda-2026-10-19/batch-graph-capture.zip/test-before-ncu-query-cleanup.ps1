# Prepared only. Copy this reviewed script to repository test.ps1 before execution.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$workspace = 'C:\public\project-hyle\hyle'
$scratch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch'))
$scratchPrefix = $scratch.TrimEnd('\') + '\'
$planPath = Join-Path $scratch 'architecture-refactor-2026-10-18\cold-capture-topology\cleanup-plan.json'
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json

function Assert-ExactFile($record, [bool]$scratchOnly) {
    $path = [IO.Path]::GetFullPath([string]$record.path)
    if ($scratchOnly -and !$path.StartsWith($scratchPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Target is outside repository .scratch: $path"
    }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer) { throw "Expected one file: $path" }
    $ancestor = $item
    while ($null -ne $ancestor) {
        if (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Refusing a reparse-point path: $path"
        }
        if ($ancestor -is [IO.FileInfo]) { $ancestor = $ancestor.Directory }
        else { $ancestor = $ancestor.Parent }
    }
    if ($item.Length -ne [long]$record.bytes) { throw "Size changed: $path" }
    $sha = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($sha -ne [string]$record.sha256) { throw "SHA256 changed: $path" }
    return $path
}

# Validate every target and its archived evidence before the first removal.
foreach ($archive in $plan.evidence_archives) { $null = Assert-ExactFile $archive $false }
$protected = @{}
foreach ($image in $plan.retained_images) {
    $path = Assert-ExactFile $image $true
    $protected[$path] = $true
}
$checked = @()
$seen = @{}
[long]$bytes = 0
foreach ($target in $plan.targets) {
    $path = Assert-ExactFile $target $true
    if ([IO.Path]::GetExtension($path) -notin @('.exe', '.map', '.lib', '.exp')) {
        throw "Unexpected target extension: $path"
    }
    if ($protected.ContainsKey($path)) { throw "Target is a retained image: $path" }
    if ($seen.ContainsKey($path)) { throw "Duplicate target: $path" }
    $seen[$path] = $true
    $checked += $path
    $bytes += [long]$target.bytes
}
if ($checked.Count -ne [int]$plan.count -or $bytes -ne [long]$plan.bytes) {
    throw 'Target count or byte total does not match the plan.'
}
foreach ($path in $checked) { Remove-Item -LiteralPath $path -Force }
foreach ($path in $checked) {
    if (Test-Path -LiteralPath $path) { throw "Removal did not finish: $path" }
}
foreach ($image in $plan.retained_images) {
    if (!(Test-Path -LiteralPath $image.path -PathType Leaf)) {
        throw "Retained image is missing: $($image.path)"
    }
}
[pscustomobject]@{
    executed = $true
    removed_count = $checked.Count
    removed_bytes = $bytes
    paths = $checked
    retained_images = $plan.retained_images
    evidence_archives = $plan.evidence_archives
    finished = (Get-Date).ToString('o')
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path (Split-Path $planPath) 'cleanup-result.json') -Encoding utf8
Write-Output "Removed $($checked.Count) exact files, $bytes bytes. Retained images and source/cache files remain."
