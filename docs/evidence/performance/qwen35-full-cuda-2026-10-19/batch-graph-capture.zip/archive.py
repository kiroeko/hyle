"""Archive this batch once final sources/results are frozen; no cleanup."""
import argparse,hashlib,json,pathlib,re,xml.etree.ElementTree as ET,zipfile
STAGE=pathlib.Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/batch-graph-capture.zip'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(data): return hashlib.sha256(data).hexdigest()
def identity(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def save(name,value): (STAGE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def check(row):
    p=pathlib.Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'],str(p)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    if not args.run:
        print('Prepared only. After final source/performance freeze: python '+str(pathlib.Path(__file__))+' --run')
        return
    freeze=read(STAGE/'current-source-freeze.json')
    for row in freeze['files']:
        frozen=row.get('after',row)
        check(frozen)
        if 'source' in row: assert identity(ROOT/row['source'])['sha256']==frozen['sha256']
    for folder,count in [('cpu-tests-final',12),('capture-tests-final',1)]:
        summary=read(STAGE/folder/'summary.json')
        assert summary['passed'] and summary['tests']==count
        xml=ET.parse(STAGE/folder/'results.xml').getroot()
        assert int(xml.attrib['tests'])==count and not xml.findall('.//failure') and not xml.findall('.//skipped')
    correctness=read(STAGE/'correctness-final/summary.json');obs=correctness['observation']
    assert correctness['passed'] and obs['equal_vectors']==64 and len(obs['generated_ids'])==32
    assert obs['same_greedy_ids_as_reference'] and correctness['single_outer_range_32_phases']
    assert correctness['route']=='hybrid' and correctness['sampling_provider_remains_uncaptured']
    assert all(v['byte_equal'] and v['actual']['sha256']==v['reference']['sha256'] for v in obs['vectors'])
    perf=read(STAGE/'performance-rotation/summary.json')
    assert perf['terminal_zero']==9 and perf['same_baseline_predictions_all9']

    # Each successful owner's latest dependency record retains its own SHA.
    # One known header delta is comments only; preserve both exact versions.
    header_versions=read(STAGE/'dependency-source-versions.json')
    known_header={row['sha256']:row for row in header_versions['versions']}
    for row in known_header.values(): check(row)
    owners={}
    for p in sorted((STAGE/'checks').rglob('*-identity.json')):
        row=read(p)
        if isinstance(row,dict) and row.get('source') and row.get('dependencies') and row.get('object'):
            owners[row['source']['path'].lower()]=row
    dependencies={}
    for owner in owners.values():
        for row in [owner['source']]+owner['dependencies']:
            p=pathlib.Path(row['path'])
            try: rel=p.relative_to(ROOT)
            except ValueError: continue
            if rel.parts[0] not in ('src','include','tests'): continue
            if rel.as_posix()==header_versions['source']:
                assert row['sha256'] in known_header,'Unexplained region_provider.h version'
                version=known_header[row['sha256']]
                assert row['bytes']==version['bytes']
                archive_path=version['archive_path']
            else:
                check(row) # Any other live/source drift remains an error.
                target=STAGE/'dependency-source'/rel
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
                archive_path='dependency-source/'+rel.as_posix()
            dependencies[(row['path'],row['sha256'])]=dict(**row,archive_path=archive_path)
    save('archive-dependency-sources.json',list(dependencies.values()))

    # Include only small helper/recipe inputs, restoring original relative
    # locations; no SDK/cache tree or previous model vector payload is copied.
    pending=list(STAGE.glob('*.py'));seen=set();support=[]
    while pending:
        p=pending.pop().resolve()
        if p in seen: continue
        seen.add(p);code=p.read_text(encoding='utf-8')
        for expr,base in [(r"ARCH\s*/\s*['\"]([^'\"]+\.py)['\"]",ARCH),
                          (r"STAGE\s*/\s*['\"]([^'\"]+\.py)['\"]",p.parent)]:
            pending.extend(base/m for m in re.findall(expr,code))
        if not p.is_relative_to(STAGE): support.append(p)
    support.extend([ARCH/'cold-capture-topology/checks/20261019T142405/plan.json',
        ARCH/'cold-capture-topology/checks/20261019T142405/cpu-link-plan.json',
        ARCH/'cold-capture-topology/checks/20261019T142405/qwen-link-plan.json',
        ARCH/'cold-capture-topology/archive-receipt.json',
        ARCH/'immutable-alias-index/host-recipes.json',
        ROOT/'docs/evidence/correctness/mlx-affine-widths-cuda-2026-10-19-archive.json'])
    support_rows=[]
    for p in dict.fromkeys(support):
        rel=p.relative_to(ROOT);target=STAGE/'support'/rel
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
        support_rows.append(dict(**identity(p),archive_path='support/'+rel.as_posix()))
    save('archive-support.json',support_rows)
    for name in ['docs/architecture/compute-design.md','docs/developer/current-work.md',
                 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']:
        target=STAGE/'context'/name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/name).read_bytes())
    save('archive-summary.json',dict(CPU_tests=12,CUDA_capture_tests=1,equal_vectors=64,
        equal_greedy_ids=32,unprofiled_processes=9,route='single-range hybrid; terminal sampling remains uncaptured',
        current_over_baseline=perf['current_over_baseline'],current_over_llama=perf['current_over_llama'],
        performance_conclusion='Raw rotated-window results and final explanation are retained; no automatic stable-speed or quality acceptance.',
        vectors='Duplicate equal tensor payloads omitted; correctness-final/summary.json records exact current/reference paths, sizes and SHA256. Prior archive receipts are references. Retained raw vectors are not deleted.',
        failures='All stage build attempts, original result logs and correction records are preserved; final success does not rewrite earlier failures.',
        cleanup='This script never deletes files or edits test.ps1.'))
    excluded={'.exe','.obj','.o','.lib','.a','.exp','.map','.pdb','.dll','.pyc','.tmp','.bf16','.f32','.f16','.bin','.npy'}
    files=[p for p in STAGE.rglob('*') if p.is_file() and p.suffix.lower() not in excluded
           and p.name!='archive-receipt.json' and not {'tmp','__pycache__','SDK','sdk','cache'}.intersection(p.relative_to(STAGE).parts)
           and not (p.stat().st_size>8*1024*1024 and any(word in p.name.lower() for word in ['query','metricdb','metric-db']))]
    hashes={p.relative_to(STAGE).as_posix():sha(p.read_bytes()) for p in files}
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for p in sorted(files): archive.write(p,p.relative_to(STAGE).as_posix())
        archive.writestr('payload-sha256.json',json.dumps(hashes,indent=2)+'\n')
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for name,digest in hashes.items(): assert sha(archive.read(name))==digest,name
    save('archive-receipt.json',dict(**identity(DEST),payloads=len(hashes),crc_verified=True,
        payload_sha256_verified=True,CPU_tests=12,CUDA_capture_tests=1,equal_vectors=64,
        equal_greedy_ids=32,unprofiled_processes=9,raw_duplicate_vectors_omitted=True))
    print(json.dumps(read(STAGE/'archive-receipt.json'),indent=2))
if __name__=='__main__': main()
