"""Reuse two successful seal owners; supply the existing CUDA SDK include to fixture."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('resume_batch_helpers', STAGE / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
base = STAGE / 'checks/20261019T151143-seal'
previous = c.read(base / 'plan.json')
fixture = h.ROOT / 'tests/graph_batch/batch_capture_test.cc'
inherited_frozen = [row for row in previous['frozen'] if c.key(row['path']) != c.key(fixture)]
h.check(inherited_frozen)
out = STAGE / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-fixture-include')
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
recipe = c.read(STAGE.parent / 'mlx-affine-widths/cuda/checks/20261019T135721/21-qwen35_text-main-identity.json')
cuda_includes = [arg for arg in recipe['command'] if arg.lower().startswith(('/i', '/external:i')) and 'NVIDIA GPU Computing Toolkit' in arg]
assert len(cuda_includes) == 3  # toolkit, CCCL and CUPTI from the exact original host recipe
cuda_defines = [arg for arg in recipe['command'] if arg.startswith(('/DHYLE_COMPUTE_', '/DHYLE_GRAPH_'))]
assert '/DHYLE_COMPUTE_CUDA=1' in cuda_defines
row = previous['compile'][2]
row['source'] = b.identity(fixture)
row['command'] = b.host_command(row['command'], Path(row['source']['path']), 'capture-test', out)
row['command'][1:1] = [*cuda_includes, *(arg for arg in cuda_defines if arg not in row['command'])]
old_fixture = row['object']
row['object'] = str(out / 'capture-test.obj')
links = {}
for arm, old in previous['links'].items():
    command = [row['object'] if c.key(arg) == c.key(old_fixture) else arg for arg in old['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    links[arm] = dict(command=command, inputs=h.helpers.link_inputs(command), image=str(image))
identities = {c.key(row['path']): row for row in previous['cached_inputs']}
reused = []
for tag in ('executable', 'region-test'):
    record = c.read(base / (tag + '-identity.json'))
    assert b.same(record['source']) and b.same(record['object'])
    for dep in record['dependencies']:
        assert b.same(dep), dep['path']
    identities[c.key(record['object']['path'])] = record['object']
    reused.append(record)
plan = dict(previous, links=links, compile=[row], host_TUs=1, reused_fresh_host_TUs=2,
    frozen=[*inherited_frozen, b.identity(fixture), b.identity(Path(__file__))],
    fixture_include_correction='Original CPU GTest recipe lacked CUDA toolkit header includes and public CUDA compile definitions; borrowed those exact existing Qwen host arguments, no SDK build.',
    preceding_plan=b.identity(base / 'plan.json'))
c.save(out / 'plan.json', plan)
print('PLAN', out / 'plan.json', flush=True)
env, _ = b.environment(links['qwen']['command'], list(identities), out)
c.execute('capture-test-compile', row['command'], env, out)
data = c.read(out / 'capture-test-deps.json')['Data']
record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
    dependencies=[b.identity(p) for p in [data['Source'], *data['Includes']]])
c.save(out / 'capture-test-identity.json', record)
identities[c.key(row['object'])] = record['object']
for arm, link in links.items():
    if arm != 'capture':
        retained = STAGE / 'checks/20261019T151408-fixture-include'
        old = c.read(retained / 'plan.json')['links'][arm]
        assert b.identity(old['image']) == c.read(retained / (arm + '-image.json'))
        link = dict(old)
        links[arm] = link
    else:
        c.execute(arm + '-link', link['command'], env, out)
    h.check(plan['frozen'])
    c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / (arm + '-link-plan.json'), dict(command=link['command'], inputs=[identities[c.key(p)] for p in link['inputs']]))
c.save(out / 'source-dependencies.json', [*reused, record])
c.save(out / 'plan.json', dict(plan, links=links, reused_core_images=True))
c.save(out / 'summary.json', dict(passed=True, host_TUs=1, reused_fresh_host_TUs=2, native_TUs=0, SDK_build=False, GPU_run=False))
c.save(STAGE / 'latest-check.json', dict(plan=str(out / 'plan.json')))
print('BUILD_COMPLETE', out / 'plan.json', flush=True)
