#include <gtest/gtest.h>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/cuda.h"
#include "hyle/compute/detail/paged_arena_access.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/cuda.h"
#include "hyle/graph/result.h"
#include "hyle/mem/buffer.h"
#include "hyle/simd/dtype.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = g::batch;
namespace m = hyle::mem;

TEST(GraphBatchCapture, FreshMetadataPermissionsRetainOnlyUnchangedNativeCommands) {
  constexpr std::uint32_t depth = 64, page_size = 16;
  auto context = g::cuda::create_context().value();
  auto queue = context.create_queue().value();
  auto device = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice).value();
  auto host = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kPinnedHost).value();
  const auto plain = c::CacheStorage::plain(c::DataType::kFloat16).value();
  const c::BatchCapacity capacity{
      .storage = c::BatchStorage::kPaged,
      .query_type = c::DataType::kFloat16, .output_type = c::DataType::kFloat16,
      .key_storage = plain, .value_storage = plain,
      .max_requests = 1, .max_query_rows = 1, .max_kv_rows = 48,
      .max_pages = 4, .max_page_refs = 3,
      .query_heads = 1, .kv_heads = 1,
      .qk_head_dim = depth, .value_head_dim = depth, .page_size = page_size};
  auto schema = c::BatchSchema::create(capacity).value();
  const std::array<std::int32_t, 2> qptr{0, 1}, kvptr{0, 2};
  const std::array<std::int32_t, 2> first_ids{0, 1}, next_ids{2, 1};
  const std::array<std::int32_t, 1> tails{page_size};
  const std::array layouts{
      schema.version({qptr, kvptr, first_ids, tails}).value(),
      schema.version({qptr, kvptr, next_ids, tails}).value()};
  const auto query_desc = c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 3>{1, 1, depth}).value();
  const auto bank_desc = c::batch_cache_description(
      capacity, c::BatchCacheRole::kKey).value();
  auto builder = g::GraphBuilder::create().value();
  const auto query = builder.input(query_desc).value();
  const auto key = builder.input(bank_desc).value();
  const auto value = builder.input(bank_desc).value();
  const auto narrowed = builder.add(c::Cast{c::DataType::kFloat16}, query).value();
  const auto attention = builder.add_node(c::Operation::custom(
      gb::paged_attention(layouts[0], {.scale = .125F, .causal = false}).value()),
      std::array{narrowed, key, value}).value();
  const auto attended = builder.result(attention).value();
  const auto widened = builder.add(c::Cast{c::DataType::kFloat32}, attended).value();
  const auto output = builder.add(c::Unary{c::UnaryKind::kNeg}, widened).value();
  ASSERT_TRUE(builder.publish(output).ok());
  const auto graph = std::move(builder).finish().value();
  auto compiled = g::cuda::compile(graph, context, device.ref(),
      {.operation_fallback = g::OperationFallbackPolicy::kReject});
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto slot = compiled->executable.create_invocation(
      {.resources = g::ResourceOptions{}}).value();
  auto query_buffer = m::Buffer::create(device.ref(), query_desc.required_bytes().value(), 64).value();
  auto output_buffer = m::Buffer::create(device.ref(), query_desc.required_bytes().value(), 64).value();
  ASSERT_TRUE(query_buffer.view().fill(std::byte{0}).ok());
  auto keys = c::PagedArena::create(schema, c::BatchCacheRole::kKey,
      device.ref(), {.max_backing_bytes = 1u << 20}).value();
  auto values = c::PagedArena::create(schema, c::BatchCacheRole::kValue,
      device.ref(), {.max_backing_bytes = 1u << 20}).value();
  std::array<c::ReadLease, 4> ready_keys, ready_values;
  std::vector<std::uint16_t> words(page_size * depth);
  for (std::uint32_t page = 0; page < 4; ++page) {
    auto kw = keys.acquire(page).value();
    auto vw = values.acquire(page).value();
    ASSERT_TRUE(kw.lease().view()->fill(std::byte{0}).ok());
    std::fill(words.begin(), words.end(), hyle::simd::f32_to_f16(float(page + 1)).bits);
    ASSERT_TRUE(vw.lease().view()->write(std::as_bytes(std::span(words))).ok());
    ready_keys[page] = kw.publish(page_size).value();
    ready_values[page] = vw.publish(page_size).value();
  }
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  gb::PrepareOptions options{.host_workspace = host.ref(),
      .max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 64u << 10};
  const auto bind_ordinary = [&]() {
    auto status = slot.bind(query, c::ConstTensorView::create(query_desc, query_buffer.view()).value());
    status.Update(slot.bind(output, c::TensorView::create(query_desc, output_buffer.view()).value()));
    return status;
  };
  std::array<c::ConstTensorView, 2> bank_views;
  for (unsigned episode = 0; episode < 4; ++episode) {
    SCOPED_TRACE(episode);
    const auto& layout = layouts[episode ? 1 : 0];
    const std::array versions{gb::NodeLayout{attention, layout}};
    // Pure page-ID contents change on episode 1. Episode 2 explicitly makes
    // a fresh native plan. Episode 3 replaces the original native owner even
    // if the device allocator later returns the same numerical addresses.
    options.update = episode != 2;
    if (episode == 3) options.max_float_workspace_bytes = 16u << 20;
    const auto prepared = gb::prepare(slot, queues, versions, options);
    ASSERT_TRUE(prepared.ok()) << prepared.message();
    EXPECT_EQ(slot.replay_route(), g::ReplayRoute::kUnprepared);
    EXPECT_FALSE(slot.submit(queues));
    ASSERT_TRUE(bind_ordinary().ok());
    const auto& ids = episode ? next_ids : first_ids;
    const std::array selected_keys{ready_keys[std::size_t(ids[0])], ready_keys[std::size_t(ids[1])]};
    const std::array selected_values{ready_values[std::size_t(ids[0])], ready_values[std::size_t(ids[1])]};
    auto key_frame = keys.read(layout, selected_keys).value();
    auto value_frame = values.read(layout, selected_values).value();
    bank_views[0] = c::detail::PagedArenaAccess::tensor(key_frame).value();
    bank_views[1] = c::detail::PagedArenaAccess::tensor(value_frame).value();
    ASSERT_TRUE(gb::bind(slot, key, std::move(key_frame)).ok());
    ASSERT_TRUE(gb::bind(slot, value, std::move(value_frame)).ok());
    const auto replay = slot.prepare_replay(queues,
        {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
    ASSERT_TRUE(replay.ok()) << replay.message();
    EXPECT_EQ(slot.replay_route(), g::ReplayRoute::kCaptured);
    const auto report = slot.replay_report();
    EXPECT_EQ(report.recorded_capture_range_count, episode == 1 ? 0u : 1u);
    EXPECT_EQ(report.reused_capture_range_count, episode == 1 ? 1u : 0u);
    const auto native = gb::report(slot, attention).value();
    EXPECT_EQ(native.reused_native_plan, episode == 1);
    {
      auto done = slot.submit(queues);
      ASSERT_TRUE(done) << done.error().message();
      ASSERT_TRUE(done->wait().ok());
      auto result = slot.result(output).value();
      std::array<float, depth> actual;
      auto tensor = result.tensor();
      ASSERT_TRUE(tensor) << tensor.error().message();
      ASSERT_TRUE(tensor->storage().read(std::as_writable_bytes(std::span(actual))).ok());
      // Q=K=0, so noncausal attention averages the two constant full pages.
      const float expected = episode ? -2.5F : -1.5F;
      for (float element : actual) EXPECT_FLOAT_EQ(element, expected);
      EXPECT_TRUE(gb::prepare(slot, queues, versions, options).IsUnavailable());
      EXPECT_TRUE(slot.reset().IsUnavailable());
    }
  }
  // All ordinary ports can be rebound after this rejected cold episode. An
  // owned-layout node has no external metadata port to make preparation fail
  // merely for an unbound tensor: the fresh native token itself must reject.
  EXPECT_TRUE(gb::prepare(slot, queues, {}).IsInvalidArgument());
  ASSERT_TRUE(bind_ordinary().ok());
  // These are the real original banks, retained by their PagedArenas. No typed
  // native preparation is smuggled in while completing generic bindings.
  ASSERT_TRUE(slot.bind(key, bank_views[0]).ok());
  ASSERT_TRUE(slot.bind(value, bank_views[1]).ok());
  EXPECT_TRUE(slot.prepare_replay(queues,
      {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject})
      .IsFailedPrecondition());
  EXPECT_FALSE(slot.submit(queues));
  ASSERT_TRUE(slot.close().ok());
  ASSERT_TRUE(context.drain().ok());
}
} // namespace
