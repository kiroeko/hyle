"""Incremental host-only batch/Graph capture wiring; reuse the existing SDKs."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'cold-capture-topology/checks/20261019T142405'
spec = importlib.util.spec_from_file_location('batch_capture_build_helpers', ARCH / 'cold-capture-topology/build.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
b, c = helpers.b, helpers.c
check = helpers.check

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    bases = {arm: c.read(BASE / (arm + '-link-plan.json')) for arm in ('cpu', 'qwen')}
    specifications = [
        ('executable', BASE / '0-executable-identity.json', ('cpu', 'qwen')),
        ('region-test', BASE / '8-region_provider_test-identity.json', ('cpu',)),
        ('batch-execution', ARCH / 'batch-layout-query-reuse/checks/20261019T120652/05-compute_batch-batch_execution-identity.json', ('cpu', 'qwen')),
        ('graph-batch-cpu', ARCH / 'mlx-affine-widths/common/checks/current/03-graph_batch-batch-identity.json', ('cpu',)),
        ('graph-batch-cuda', ARCH / 'mlx-affine-widths/cuda/checks/20261019T135721/04-graph_batch-batch-identity.json', ('qwen',)),
        ('flashinfer', ARCH / 'mlx-affine-widths/cuda/checks/20261019T135721/14-compute_provider_flashinfer-flashinfer_provider-identity.json', ('qwen',)),
        ('workspace-test', ARCH / 'batch-layout-query-reuse/checks/20261019T120652/workspace-test-identity.json', ('cpu',)),
    ]
    frozen = [b.identity(p) for p in (Path(__file__), STAGE / 'source-freeze.json',
        ROOT / 'src/graph/plan_state.h', *(BASE / (arm + '-link-plan.json') for arm in bases))]
    seal = c.read(STAGE / 'source-freeze.json')
    for row in seal['files']:
        actual = b.identity(ROOT / row['source'])
        if actual['sha256'] != row['after']['sha256']:
            raise ValueError('Product source differs from frozen batch: ' + row['source'])
        frozen.append(actual)
    rows = []
    for tag, recipe_path, arms in specifications:
        recipe = c.read(recipe_path)
        source = Path(recipe['source']['path'])
        command = b.host_command(recipe['command'], source, tag, out)
        rows.append(dict(tag=tag, source=b.identity(source), recipe=b.identity(recipe_path),
            command=command, object=str(out / (tag + '.obj')),
            old_object=None if tag == 'workspace-test' else recipe['object'], arms=arms))
        frozen += [b.identity(recipe_path), b.identity(source)]
        frozen += [b.identity(p) for p in b.host_dependencies(recipe['command'])]
    frozen = list({c.key(row['path']): row for row in frozen}.values())
    cached = {c.key(row['path']): row for base in bases.values() for row in base['inputs']}
    links = {}
    for arm, base in bases.items():
        replace = {c.key(row['old_object']['path']): row['object'] for row in rows if arm in row['arms'] and row['old_object']}
        actual = {c.key(row['path']) for row in base['inputs']}
        if not set(replace) <= actual:
            raise ValueError('Replacement owner is absent: ' + arm)
        for row in rows:
            if arm in row['arms'] and row['old_object'] and cached[c.key(row['old_object']['path'])] != row['old_object']:
                raise ValueError('Recipe differs from actual linked owner: ' + row['tag'])
        command = [replace.get(c.key(arg), arg) for arg in base['command']
            if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        extra = [row['object'] for row in rows if arm in row['arms'] and not row['old_object']]
        command[1:1] = extra
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
            '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = helpers.link_inputs(command)
        if len(inputs) != len(base['inputs']) + len(extra) or len(set(map(c.key, inputs))) != len(inputs):
            raise ValueError('Link input closure differs: ' + arm)
        links[arm] = dict(command=command, image=str(image), inputs=inputs)
    plan = dict(compile=rows, links=links, frozen=frozen, cached_inputs=list(cached.values()),
        native_TUs=0, host_TUs=len(rows), SDK_build=False, GPU_run=False)
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    if not args.build:
        return
    check(frozen)
    for row in cached.values():
        if not b.same(row):
            raise ValueError('Retained input differs: ' + row['path'])
    env, _ = b.environment(links['qwen']['command'], list(cached), out)
    identities = dict(cached)
    dependencies = []
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(frozen)
        data = c.read(out / (row['tag'] + '-deps.json'))['Data']
        deps = [b.identity(p) for p in [data['Source'], *data['Includes']]]
        record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']), dependencies=deps)
        identities[c.key(row['object'])] = record['object']
        c.save(out / (row['tag'] + '-identity.json'), record)
        dependencies.append(record)
    for arm, link in links.items():
        c.execute(arm + '-link', link['command'], env, out)
        check(frozen)
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'], inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / 'source-dependencies.json', dependencies)
    c.save(out / 'summary.json', dict(passed=True, host_TUs=len(rows), native_TUs=0, SDK_build=False, GPU_run=False))
    c.save(STAGE / 'latest-check.json', dict(plan=str(out / 'plan.json')))
    print('BUILD_COMPLETE', out / 'plan.json', flush=True)

if __name__ == '__main__':
    main()
