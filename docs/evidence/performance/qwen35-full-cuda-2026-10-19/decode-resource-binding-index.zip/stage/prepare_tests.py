"""Prepare the existing CPU region-test TU overlay, without applying or running."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
REL = 'tests/graph/region_provider_test.cc'
baseline = STAGE / 'tests-before' / REL
before = (baseline if baseline.is_file() else ROOT / REL).read_bytes()
eol = '\r\n' if b'\r\n' in before else '\n'
text = before.decode('utf-8').replace('\r\n', '\n')
edits = []


def replace(old, new):
    global text
    if text.count(old) != 1:
        raise ValueError('Expected unique test anchor: ' + old[:80])
    text = text.replace(old, new)
    edits.append({'old': old, 'new': new})


anchor = 'TEST(GraphRouteBoundary, ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort) {'
replace(anchor, (STAGE / 'binding-index-tests.inc').read_text() + anchor)
start = text.index(anchor)
end = text.index('\nTEST(', start + len(anchor))
case = text[start:end]
case = case.replace('  const std::array pages{input};', '''  std::array<hyle::compute::ReadLease, 3> pages{
      input.subview(0, 8).value(), input.subview(8, 8).value(),
      input.subview(16, 16).value()};''')
old = '''  ASSERT_TRUE(run.bind(logical.output, row(8), std::move(output)).ok());
  ASSERT_TRUE(hyle::graph::detail::RegionAccess::reserve_reads(run, 4, resources).ok());'''
new = '''  ASSERT_TRUE(run.bind(logical.output, row(8), std::move(output)).ok());
  auto replacement = make_tensor(row(8));
  const std::array<float, 8> changed{1, 2, 3, 4, 5, 6, 7, 8};
  write(replacement, changed);
  // Actual anonymous suffix guards exist here. Ordinary rebinding must erase
  // only this input's pages while keeping the fixed output record in place.
  ASSERT_TRUE(run.bind(logical.input, replacement.view.as_const()).ok());
  pages = {};
  auto restored = input.try_write();
  ASSERT_TRUE(restored) << restored.error().message();
  input = restored->publish().value();
  tensor = input.tensor(row(8)).value();
  ASSERT_TRUE(hyle::graph::detail::RegionAccess::reserve_reads(run, 4, resources).ok());'''
if case.count(old) != 1:
    raise ValueError('Output suffix anchor changed')
case = case.replace(old, new)
old = '''  EXPECT_TRUE(completion->wait().ok());
}'''
new = '''  EXPECT_TRUE(completion->wait().ok());
  {
    auto result = run.result(logical.output).value();
    std::array<float, 8> observed{};
    ASSERT_TRUE(result.tensor()->storage().read(
        std::as_writable_bytes(std::span(observed))).ok());
    for (std::size_t i = 0; i < observed.size(); ++i) EXPECT_EQ(observed[i], -changed[i]);
  }
  *completion = {};
  ASSERT_TRUE(run.reset().ok());
  pages = {input.subview(0, 8).value(), input.subview(8, 8).value(),
           input.subview(16, 16).value()};
  ASSERT_TRUE(hyle::graph::detail::RegionAccess::bind_projected(
      run, logical.input, tensor, pages, readers).ok());
  pages = {};
  // Reset must also release a nonempty suffix without moving fixed slots.
  ASSERT_TRUE(run.reset().ok());
  auto after_reset = input.try_write();
  ASSERT_TRUE(after_reset) << after_reset.error().message();
}'''
if case.count(old) != 1:
    raise ValueError('Projected completion anchor changed')
case = case.replace(old, new)
replace(text[start:end], case)
after = text.replace('\n', eol).encode('utf-8')


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


for directory, raw in (('tests-before', before), ('test-overlay', after)):
    target = STAGE / directory / REL
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
(STAGE / 'tests.diff').write_text(''.join(difflib.unified_diff(before.decode().replace('\r\n', '\n').splitlines(True), text.splitlines(True),
    fromfile='a/' + REL, tofile='b/' + REL)), encoding='utf-8')
(STAGE / 'tests-source-freeze.json').write_text(json.dumps({'status': 'scratch_only_not_applied_not_compiled',
    'files': [{'target': REL, 'before': identity(before), 'after': identity(after), 'edits': edits}],
    'new_test': 'GraphResources.FixedBindingIndexKeepsRebindGenerationAndResultLeaseGuards',
    'extended_existing_test': 'GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort'}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(identity(after)))
