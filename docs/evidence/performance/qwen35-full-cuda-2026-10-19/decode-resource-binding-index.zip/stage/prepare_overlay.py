"""Prepare one TU-local fixed-binding index overlay; no product edit or build."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
REL = 'src/graph/resources.cc'
source = ROOT / REL
baseline = STAGE / 'before' / REL
before = (baseline if baseline.is_file() else source).read_bytes()
text = before.decode('utf-8')
edits = []


def replace(old, new):
    global text
    if text.count(old) != 1:
        raise ValueError('Expected one source anchor: ' + old[:80])
    text = text.replace(old, new)
    edits.append({'old': old, 'new': new})


replace('''      : allocator(selected), bindings(mem::StdAllocator<LeaseBinding>(selected)),
        permissions(selected) {}''', '''      : allocator(selected), bindings(mem::StdAllocator<LeaseBinding>(selected)),
        binding_slots(mem::StdAllocator<std::uint32_t>(selected)),
        permissions(selected) {}''')
replace('''  std::vector<LeaseBinding, mem::StdAllocator<LeaseBinding>> bindings;
  LeasePermissionSet permissions;''', '''  std::vector<LeaseBinding, mem::StdAllocator<LeaseBinding>> bindings;
  // The external ValueId records form an immutable prefix. Only anonymous
  // projected-page guards are appended/erased after it. Slots index identity,
  // never permissions, leases, addresses or readiness from an old episode.
  std::vector<std::uint32_t, mem::StdAllocator<std::uint32_t>> binding_slots;
  std::size_t fixed_binding_count = 0;
  LeasePermissionSet permissions;''')
replace('''LeaseBinding *find_binding(InvocationState *state, ValueId value) noexcept {
  if (!state || !state->resources) return nullptr;
  for (auto &binding : state->resources.get()->bindings)
    if (binding.value == value) return &binding;
  return nullptr;
}
Status check_binding_replacement(const InvocationState &state, ValueId value) noexcept {
  if (state.resources) {
    for (const auto &binding : state.resources.get()->bindings)
      if (binding.value == value && binding.configuration)
        return Status::FailedPrecondition(
            "graph input belongs to its cold configuration; reset before ordinary rebinding");
  }
  return Status::Ok();
}''', '''const LeaseBinding *find_binding(const InvocationState *state, ValueId value) noexcept {
  if (!state || !state->resources || !value.valid()) return nullptr;
  const auto &episode = *state->resources.get();
  if (value.ordinal() >= episode.binding_slots.size()) return nullptr;
  const auto slot = episode.binding_slots[value.ordinal()];
  if (slot >= episode.fixed_binding_count) return nullptr;
  const auto &binding = episode.bindings[slot];
  // Equal ordinals from a different Graph/generation never name this record.
  return binding.value == value ? &binding : nullptr;
}
LeaseBinding *find_binding(InvocationState *state, ValueId value) noexcept {
  return const_cast<LeaseBinding *>(find_binding(
      static_cast<const InvocationState *>(state), value));
}
Status check_binding_replacement(const InvocationState &state, ValueId value) noexcept {
  const auto *binding = find_binding(&state, value);
  if (binding && binding->configuration)
    return Status::FailedPrecondition(
        "graph input belongs to its cold configuration; reset before ordinary rebinding");
  return Status::Ok();
}''')
replace('''  std::erase_if(bindings, [](const auto &binding) { return !binding.value.valid(); });
  for (auto &binding : bindings) {''', '''  // All extra records are anonymous page guards; fixed ValueId slots never
  // move. Shrinking releases exactly the old projected permission suffix.
  bindings.resize(state.resources.get()->fixed_binding_count);
  for (auto &binding : bindings) {''')
replace('''  std::erase_if(bindings, [&](const auto &binding) {
    return !binding.value.valid() && binding.projection == value;
  });''', '''  const auto extras = bindings.begin() + state.resources.get()->fixed_binding_count;
  bindings.erase(std::remove_if(extras, bindings.end(), [&](const auto &binding) {
    return binding.projection == value;
  }), bindings.end());''')
replace('''        episode->bindings.push_back({.value = value});
    }
  } catch (...) { return Status::ResourceExhausted("graph fixed resource metadata"); }''', '''        episode->bindings.push_back({.value = value});
    }
    episode->fixed_binding_count = episode->bindings.size();
    if (episode->fixed_binding_count != 0) {
      episode->binding_slots.assign(state_->plan->descriptions.size(), UINT32_MAX);
      for (std::size_t slot = 0; slot < episode->fixed_binding_count; ++slot)
        episode->binding_slots[episode->bindings[slot].value.ordinal()] =
            static_cast<std::uint32_t>(slot);
    }
  } catch (...) { return Status::ResourceExhausted("graph fixed resource metadata"); }''')
after = text.encode('utf-8')


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


for directory, raw in (('before', before), ('source', after)):
    target = STAGE / directory / REL
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
(STAGE / 'changes.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True), text.splitlines(True),
    fromfile='a/' + REL, tofile='b/' + REL)), encoding='utf-8')
freeze = {'status': 'scratch_only_not_applied_not_compiled', 'files': [{'product': REL,
    'before': identity(before), 'after': identity(after), 'edits': edits}],
    'public_or_private_header_changes': False,
    'invariant': 'Fixed external ValueId records are created once by prepare_resources; all three runtime append sites add only invalid-ValueId projected page guards at the suffix. No fixed record is erased/reordered.'}
(STAGE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
print(json.dumps(freeze['files'][0]['after']))
