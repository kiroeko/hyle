"""Focused resource-binding identity, permissions, aliases, and lifetime checks."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('binding_index_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
if not c.read(plan_path.parent / 'summary.json')['passed']:
    raise ValueError('Successful incremental build required')
cases = [
    'GraphResources.FixedBindingIndexKeepsRebindGenerationAndResultLeaseGuards',
    'GraphRouteBoundary.ProjectedRegionRequiresItsSelectedArtifactAndPhysicalPort',
    'GraphRegions.RawBindingsAndOwnedResultsUseTheSameInvocationGate',
    'Invocation.RepeatedOutputBindingKeepsAliasChecksForChangedInputsAndRanges',
    'GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode',
]
out = plan_path.parent / 'run-cpu'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
env, directories = b.environment(plan['links']['cpu']['command'], plan['links']['cpu']['inputs'], out)
c.save(out / 'runtime-environment.json', {
    'runtime_link_input_paths': plan['links']['cpu']['inputs'],
    'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
exit_code = None
try:
    c.execute('cpu', [plan['links']['cpu']['image'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(cases), '--gtest_output=xml:' + str(out / 'cpu.xml')], env, out)
    exit_code = 0
finally:
    xml = out / 'cpu.xml'
    if xml.exists():
        root = ET.parse(xml).getroot()
        counts = {key: int(root.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
        observed = [row.attrib['classname'] + '.' + row.attrib['name'] for row in root.findall('testsuite/testcase')]
        counts['skipped'] = len(root.findall('testsuite/testcase/skipped'))
        passed = exit_code == 0 and set(observed) == set(cases) and counts['tests'] == len(cases) and not any(
            counts[key] for key in ('failures', 'disabled', 'errors', 'skipped'))
        c.save(out / 'summary.json', {'passed': passed, 'counts': counts, 'expected': cases, 'observed': observed,
            'image': b.identity(plan['links']['cpu']['image']), 'runner': b.identity(Path(__file__)),
            'performance_claim': False})
    else:
        passed = False
        c.save(out / 'summary.json', {'passed': False, 'XML_missing': True})
if not passed:
    raise ValueError('Expected exactly five related CPU cases without error or skip')
print('RESOURCE_TESTS', counts, flush=True)
