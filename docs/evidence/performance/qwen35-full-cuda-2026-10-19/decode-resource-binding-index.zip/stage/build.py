"""Refresh only resources and its CPU region-test owner, then retained115/134/125 links."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('host_path_cached_helpers', ARCH / 'cuda-grouped-fusion/build.py')
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
b, c = cached.b, cached.c
OLD = ARCH / 'immutable-alias-index/checks/20261019T111822'
FP8 = ARCH / 'cuda-grouped-fp8-slots/validation/checks/20261019T132520'
BASES = {'cpu': ARCH / 'batch-layout-query-reuse/checks/20261019T120828-test-define/cpu-link-plan.json',
         'cuda': FP8 / 'cuda-link-plan.json', 'qwen': FP8 / 'qwen-link-plan.json'}


def check(plan):
    for row in plan['frozen']:
        if b.identity(row['path']) != row:
            raise ValueError('Source/recipe/header drift: ' + row['path'])


def check_cached(plan):
    for row in plan['cached_inputs']:
        if b.identity(row['path']) != row:
            raise ValueError('Cached input drift: ' + row['path'])


def paths(link):
    return [row['path'] if isinstance(row, dict) else row for row in link['inputs']]


def prepare():
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    compiles, replacements, frozen = [], {}, []
    for tag, source, recipe_name, closure in (
        ('resources', ROOT / 'src/graph/resources.cc', '4-resources-identity.json', ['cpu', 'cuda', 'qwen']),
        ('region-test', ROOT / 'tests/graph/region_provider_test.cc', '9-region_provider_test-identity.json', ['cpu']),
    ):
        recipe_path = OLD / recipe_name
        recipe = c.read(recipe_path)
        row = {'tag': tag, 'source': b.identity(source), 'recipe': b.identity(recipe_path),
               'old_object': recipe['object'], 'closures': closure,
               'command': b.host_command(recipe['command'], source, tag, out), 'object': str(out / (tag + '.obj'))}
        compiles.append(row)
        replacements[recipe['object']['path'].casefold()] = row
        frozen += [row['source'], row['recipe']]
        frozen += [b.identity(path) for path in b.host_dependencies(recipe['command']) if path != source]
    for name in ('build.py', 'application.json', 'source-freeze.json', 'tests-source-freeze.json',
                 'prepare_overlay.py', 'prepare_tests.py', 'binding-index-tests.inc'):
        frozen.append(b.identity(STAGE / name))
    links, cached_inputs = {}, {}
    for arm, path in BASES.items():
        base = c.read(path)
        if len(base['inputs']) != {'cpu': 115, 'cuda': 134, 'qwen': 125}[arm]:
            raise ValueError('Unexpected retained closure count')
        frozen.append(b.identity(path))
        command = []
        found = []
        for arg in base['command']:
            replacement = replacements.get(arg.casefold())
            if replacement and arm in replacement['closures']:
                command.append(replacement['object'])
                found.append(replacement['tag'])
            elif arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
                prefix = arg.split(':', 1)[0]
                extension = {'/OUT': '.exe', '/MAP': '.map', '/IMPLIB': '.lib'}[prefix.upper()]
                command.append(prefix + ':' + str(out / (arm + extension)))
            else:
                command.append(arg)
        expected = ['resources', 'region-test'] if arm == 'cpu' else ['resources']
        if sorted(found) != sorted(expected):
            raise ValueError('Expected exact owner replacements: ' + arm + str(found))
        inputs = []
        for row in base['inputs']:
            if not isinstance(row, dict):
                raise ValueError('Retained exact input identities required')
            replacement = replacements.get(row['path'].casefold())
            if replacement and arm in replacement['closures']:
                inputs.append(replacement['object'])
            else:
                inputs.append(row['path'])
                prior = cached_inputs.setdefault(row['path'].casefold(), row)
                if prior != row:
                    raise ValueError('Conflicting cached input identity')
        links[arm] = {'base_plan': b.identity(path), 'replaced_owners': found,
            'command': command, 'inputs': inputs, 'image': str(out / (arm + '.exe'))}
    frozen = list({row['path'].casefold(): row for row in frozen}.values())
    plan = {'status': 'prepared_not_compiled', 'frozen': frozen, 'cached_inputs': list(cached_inputs.values()),
            'compiles': compiles, 'links': links, 'out': str(out), 'public_header_changes': False,
            'native_CUDA_compilations': 0, 'runtime_DLL_union_used': False}
    c.save(out / 'plan.json', plan)
    c.save(STAGE / 'host-recipes.json', {'compile': compiles, 'base_links': {arm: str(path) for arm, path in BASES.items()},
        'links': links, 'no_private_or_public_header_ABI_change': True})
    print('PLAN', out / 'plan.json', flush=True)
    return out / 'plan.json'


def build(plan_path):
    plan = c.read(plan_path)
    out = Path(plan['out'])
    check(plan)
    check_cached(plan)
    completed = []
    summary = {'passed': False, 'compiled': [], 'links': []}
    try:
        for row in plan['compiles']:
            check(plan)
            env, _ = b.environment(row['command'], plan['links']['cpu']['inputs'], out)
            c.execute(row['tag'] + '-compile', row['command'], env, out)
            deps = b.host_dependencies(row['command'])
            identity = {'source': row['source'], 'command': row['command'], 'object': b.identity(row['object']),
                        'dependencies': [b.identity(path) for path in sorted(deps)]}
            c.save(out / (row['tag'] + '-identity.json'), identity)
            completed.append(identity['object'])
            summary['compiled'].append(row['tag'])
        for arm, link in plan['links'].items():
            check(plan)
            env, _ = b.environment(link['command'], link['inputs'], out)
            c.execute(arm + '-link', link['command'], env, out)
            c.save(out / (arm + '-image.json'), b.identity(link['image']))
            c.save(out / (arm + '-link-plan.json'), {'command': link['command'],
                'inputs': [b.identity(path) for path in link['inputs']]})
            summary['links'].append(arm)
        check(plan)
        check_cached(plan)
        summary['passed'] = True
    finally:
        c.save(out / 'summary.json', summary)
    print('BUILD', summary, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--plan', type=Path)
    args = parser.parse_args()
    plan = args.plan.resolve() if args.plan else prepare()
    if args.build:
        build(plan)
