"""Reuse the successful resources owner; compile only the corrected test fixture."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('binding_index_build', STAGE / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
original = STAGE / 'checks/20261019T132925/plan.json'
plan = c.read(original)
oldout = original.parent
out = STAGE / 'checks' / (dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-fixture')
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
resource = c.read(oldout / 'resources-identity.json')
if b.identity(resource['object']['path']) != resource['object']:
    raise ValueError('Previously compiled resource owner differs')
for row in resource['dependencies'] + [resource['source']]:
    if b.identity(row['path']) != row:
        raise ValueError('Fresh resources owner source/header differs')
newfrozen = []
for row in plan['frozen']:
    path = Path(row['path'])
    actual = b.identity(path)
    if not path.is_relative_to(STAGE) and path != m.ROOT / 'tests/graph/region_provider_test.cc' and actual != row:
        raise ValueError('Unrelated frozen identity changed: ' + str(path))
    newfrozen.append(actual)
newfrozen += [b.identity(Path(__file__)), b.identity(original), b.identity(oldout / 'resources-identity.json')]
test = next(row for row in plan['compiles'] if row['tag'] == 'region-test')
old_object = test['object']
test['source'] = b.identity(test['source']['path'])
test['command'] = b.host_command(test['command'], Path(test['source']['path']), test['tag'], out)
test['object'] = str(out / 'region-test.obj')
plan['compiles'] = [test]
plan['frozen'] = newfrozen
plan['cached_inputs'].append(resource['object'])
for arm, link in plan['links'].items():
    command = []
    for arg in link['command']:
        if arg == old_object:
            command.append(test['object'])
        elif arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            prefix = arg.split(':', 1)[0]
            suffix = {'/OUT': '.exe', '/MAP': '.map', '/IMPLIB': '.lib'}[prefix.upper()]
            command.append(prefix + ':' + str(out / (arm + suffix)))
        else:
            command.append(arg)
    link['command'] = command
    link['inputs'] = [test['object'] if value == old_object else value for value in link['inputs']]
    link['image'] = str(out / (arm + '.exe'))
plan['out'] = str(out)
plan['reused_resources_owner'] = resource['object']
plan['fixture_correction_history'] = b.identity(STAGE / 'application.json')
c.save(out / 'plan.json', plan)
c.save(STAGE / 'host-recipes-final.json', {'plan': b.identity(out / 'plan.json'),
    'compiles': plan['compiles'], 'resources_reused_without_recompilation': resource,
    'links': plan['links']})
print('RESUME_PLAN', out / 'plan.json', flush=True)
m.build(out / 'plan.json')
