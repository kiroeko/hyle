"""Archive the tested resource-binding index without duplicating baseline vectors."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T133822-fixture/plan.json'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/decode-resource-binding-index.zip'
BASELINE = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/recurrent-gdn-schema.zip'
TRACE_ARCHIVE = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/decode-critical-path.zip'
EXCLUDED = {'.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.dll', '.pyc', '.tmp'}
SUPPORT = (
    'cuda-grouped-fusion/build.py', 'cuda-fusion-allocation/build.py',
    'recurrent-gdn-schema/build.py', 'immutable-alias-index/build.py',
    'cuda-fusion-precision/build.py', 'cuda-fusion-layout/build.py',
    'cuda-gdn-l2-epilogue/build.py', 'cuda-explicit-rope/build.py',
    'cuda-bf16-dual-projection/build_current.py', 'cuda-projection-fusion/build.py',
    'cold-constant-retirement/cold_check.py', 'cuda-bf16-dual-projection/compare_numerics.py',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def verify(row):
    if identity(row['path']) != row:
        raise ValueError('Frozen evidence/source drift: ' + row['path'])
    return Path(row['path']).resolve()


def main():
    if DEST.exists():
        raise ValueError('Archive already exists')
    plan = read(PLAN)
    if not read(PLAN.parent / 'summary.json')['passed']:
        raise ValueError('Successful final build required')
    tests = read(PLAN.parent / 'run-cpu/summary.json')
    model = read(STAGE / 'correctness/summary.json')
    if not tests['passed'] or tests['counts'] != {
            'tests': 5, 'failures': 0, 'disabled': 0, 'errors': 0, 'skipped': 0}:
        raise ValueError('Expected five actual CPU cases without failure/skip')
    if not model['passed'] or model['observation']['equal_vectors'] != 64:
        raise ValueError('Expected64 exact model vectors')
    for row in read(STAGE / 'application.json')['files']:
        actual = identity(ROOT / row['path'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied source drift')
    owners = [
        read(STAGE / 'checks/20261019T132925/resources-identity.json'),
        read(PLAN.parent / 'region-test-identity.json'),
    ]
    files = {}

    def add(name, path, expected=None):
        path = Path(path).resolve()
        if expected:
            verify(expected)
        if name in files and files[name] != path:
            raise ValueError('Conflicting payload: ' + name)
        files[name] = path

    for owner in owners:
        for row in [owner['source']] + owner['dependencies']:
            path = verify(row)
            if path.is_relative_to(ROOT):
                add('tested-source/' + path.relative_to(ROOT).as_posix(), path, row)
    for row in plan['frozen']:
        path = verify(row)
        if not path.is_relative_to(STAGE) and path.is_relative_to(ROOT) and path.suffix.lower() not in EXCLUDED:
            add('frozen-input/' + path.relative_to(ROOT).as_posix(), path, row)
    for arm, count in (('cpu', 115), ('cuda', 134), ('qwen', 125)):
        link = read(PLAN.parent / (arm + '-link-plan.json'))
        if len(link['inputs']) != count:
            raise ValueError('Actual link input count differs')
        verify(read(PLAN.parent / (arm + '-image.json')))

    baseline_identity = identity(BASELINE)
    inputs = read(STAGE / 'correctness/inputs.json')
    reference = {Path(row['path']).relative_to(ARCH / 'recurrent-gdn-schema/correctness/trace').as_posix(): row
                 for row in inputs['reference_vectors']}
    actual = sorted((STAGE / 'correctness/trace').rglob('*'))
    vectors = []
    with zipfile.ZipFile(BASELINE) as archive:
        for path in actual:
            if path.suffix not in ('.bf16', '.f32'):
                continue
            relative = path.relative_to(STAGE / 'correctness/trace').as_posix()
            row = identity(path)
            expected = reference[relative]
            entry = 'stage/correctness/trace/' + relative
            data = archive.read(entry)
            if (row['bytes'], row['sha256']) != (expected['bytes'], expected['sha256']) or (
                    len(data), sha(data)) != (row['bytes'], row['sha256']):
                raise ValueError('Baseline ZIP does not reconstruct current exact vector')
            vectors.append({'actual': row, 'reference': expected, 'baseline_zip_entry': entry,
                            'baseline_zip_payload_bytes': len(data), 'baseline_zip_payload_sha256': sha(data)})
    if len(vectors) != 64:
        raise ValueError('Expected64 restorable actual vectors')
    vector_receipt = {'all_64_current_vectors_equal_reference_and_archived_payload_SHA': True,
        'baseline_zip': baseline_identity, 'vectors': vectors,
        'new_vector_payloads_omitted_from_new_ZIP': True}
    (STAGE / 'vector-restoration.json').write_text(json.dumps(vector_receipt, indent=2) + '\n')

    retained = {str(Path(plan['links'][arm]['image']).resolve()).casefold() for arm in ('cuda', 'qwen')}
    targets = []
    for path in sorted((STAGE / 'checks').rglob('*')):
        if path.is_file() and (path.suffix.lower() in ('.map', '.lib', '.exp') or (
                path.suffix.lower() == '.exe' and str(path.resolve()).casefold() not in retained)):
            row = identity(path)
            row['reason'] = ('Rebuildable link byproduct; exact commands/owner identities retained' if path.suffix != '.exe'
                             else 'Superseded or CPU-only test image; raw observations retained, latest CUDA/Qwen remain')
            targets.append(row)
    reclaim = {'executed': False, 'must_use_root_test_ps1': True, 'targets': targets,
        'count': len(targets), 'bytes': sum(row['bytes'] for row in targets),
        'retained_current_images': [identity(plan['links'][arm]['image']) for arm in ('cuda', 'qwen')],
        'all_objects_and_recipes_retained': True, 'all_64_new_raw_vectors_retained_as_latest_baseline': True,
        'vectors_baseline_zip': baseline_identity}
    (STAGE / 'reclaim-targets.json').write_text(json.dumps(reclaim, indent=2) + '\n')
    scope = {'batch': 'decode-resource-binding-index', 'plan': identity(PLAN),
        'applied_product_sources': read(STAGE / 'application.json')['files'],
        'fresh_product_TUs': 1, 'fresh_test_TUs': 1, 'native_CUDA_or_SDK_rebuilds': 0,
        'actual_link_inputs': {'cpu': 115, 'cuda': 134, 'qwen': 125},
        'CPU_cases': 5, 'model_vector_count': 64, 'fresh_model_processes': 1,
        'throughput_claim': False, 'new_profile_or_throughput_runs': 0,
        'original_profile_separate_archive': identity(TRACE_ARCHIVE),
        'baseline_model_vectors_separate_archive': baseline_identity,
        'vector_restoration_proof': identity(STAGE / 'vector-restoration.json'),
        'earlier_test_fixture_failures_preserved': True,
        'public_header_or_ABI_changes': False,
        'SDK_models_objects_executables_maps_tmp_excluded': True,
        'other_unapplied_agent_drafts_excluded': True}
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n')
    for relative in SUPPORT:
        path = ARCH / relative
        add('replay-support/' + path.relative_to(ROOT).as_posix(), path)
    for path in sorted(STAGE.rglob('*')):
        relative = path.relative_to(STAGE)
        if (not path.is_file() or 'tmp' in relative.parts or '__pycache__' in relative.parts or
                path.suffix.lower() in EXCLUDED or path.name == 'archive-verification.json' or
                (path.is_relative_to(STAGE / 'correctness/trace') and path.suffix in ('.bf16', '.f32'))):
            continue
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        add('stage/' + relative.as_posix(), path)
    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            records.append({'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)})
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(records) + 1:
            raise ValueError('ZIP CRC/count failure')
        for row in records:
            data = archive.read(row['entry'])
            if (len(data), sha(data)) != (row['bytes'], row['sha256']):
                raise ValueError('Payload SHA/size mismatch')
    receipt = dict(identity(DEST), CRC_and_every_payload_SHA_verified=True,
        payloads=len(records), entries_including_manifest=len(records) + 1,
        uncompressed_payload_bytes=sum(row['bytes'] for row in records),
        CPU_tests=5, exact_model_vectors=64, repeated_vector_payloads_omitted=True,
        throughput_claim=False, original_trace_archive_referenced_not_duplicated=True,
        source_sha256='360c50b8777206413a5d781192e59ca026830ea3986120cbab692ce6b14c9fab',
        reclaim_targets_count=len(targets), reclaim_bytes=reclaim['bytes'])
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text)
    DEST.with_name('decode-resource-binding-index-archive.json').write_text(text)
    print(text, flush=True)


if __name__ == '__main__':
    main()
