"""Compose the narrow RMS cast fusion onto the locked CUDA raw manifest.

This script prepares source/patch evidence only. It never compiles or runs CUDA.
"""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
BASE = Path("C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424")
MANIFEST = ROOT / "third_party/ggml_cuda_runtime/patches.json"
SNAPSHOT = STAGE / "patches.before.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def apply(data, edits, path):
    for index, edit in enumerate(edits):
        before = edit["before"].encode()
        after = edit["after"].encode()
        count = data.count(before)
        if count != 1:
            raise RuntimeError((path, index, "context count", count))
        data = data.replace(before, after)
    return data


NORM_OUTPUT = r'''        if constexpr (std::is_same<Dst, nv_bfloat16>::value) {
            static_assert(!do_add, "BF16 RMS cast fusion does not include add");
            const float normalized = __fmul_rn(scale, (float) x[col]);
            float value = normalized;
            if constexpr (do_multiply) {
                const int mul_col = fastmodulo(col, mul_ncols_packed);
                value = __fmul_rn(normalized, mul[mul_col]);
            }
            dst[col] = __float2bfloat16_rn(value);
        } else if constexpr (do_multiply && do_add) {'''

NORM_ENTRY = r'''// Only the surrounding native cast chain selects this entry. The original
// F32 RMS/MUL nodes remain the unfused mathematical and allocation oracle.
template <int block_size, bool do_multiply>
static void rms_norm_bf16_cast_cuda(const ggml_tensor * x,
                                    const ggml_tensor * mul,
                                    ggml_tensor * dst,
                                    const float eps,
                                    cudaStream_t stream) {
    const dim3 blocks_num(x->ne[1], x->ne[2], x->ne[3]);
    const dim3 block_dims(block_size, 1, 1);
    const ggml_cuda_kernel_launch_params params = {
        blocks_num, block_dims, block_size > WARP_SIZE ? 32 * sizeof(float) : 0, stream};
    const float * mul_data = mul ? (const float *) mul->data : nullptr;
    const int64_t mul_s1 = mul ? mul->nb[1] / sizeof(float) : 0;
    const int64_t mul_s2 = mul ? mul->nb[2] / sizeof(float) : 0;
    const int64_t mul_s3 = mul ? mul->nb[3] / sizeof(float) : 0;
    const uint3 mul_n0 = mul ? init_fastdiv_values(mul->ne[0]) : make_uint3(0, 0, 0);
    const uint3 mul_n1 = mul ? init_fastdiv_values(mul->ne[1]) : make_uint3(0, 0, 0);
    const uint3 mul_n2 = mul ? init_fastdiv_values(mul->ne[2]) : make_uint3(0, 0, 0);
    const uint3 mul_n3 = mul ? init_fastdiv_values(mul->ne[3]) : make_uint3(0, 0, 0);
    ggml_cuda_kernel_launch(
        rms_norm_f32<block_size, do_multiply, false, nv_bfloat16, nv_bfloat16>, params,
        (const nv_bfloat16 *) x->data, (nv_bfloat16 *) dst->data,
        (int) x->ne[0], (int64_t) (x->nb[1] / sizeof(nv_bfloat16)),
        (int64_t) (x->nb[2] / sizeof(nv_bfloat16)), (int64_t) (x->nb[3] / sizeof(nv_bfloat16)), eps,
        mul_data, mul_s1, mul_s2, mul_s3, mul_n0, mul_n1, mul_n2, mul_n3,
        nullptr, 0, 0, 0, make_uint3(0, 0, 0), make_uint3(0, 0, 0), make_uint3(0, 0, 0), make_uint3(0, 0, 0));
}

void ggml_cuda_op_rms_norm_cast_fused(ggml_backend_cuda_context & ctx,
                                      const ggml_tensor * x,
                                      const ggml_tensor * norm,
                                      const ggml_tensor * mul,
                                      ggml_tensor * dst) {
    GGML_ASSERT(x->type == GGML_TYPE_BF16 && dst->type == GGML_TYPE_BF16);
    GGML_ASSERT(norm->op == GGML_OP_RMS_NORM && norm->type == GGML_TYPE_F32);
    GGML_ASSERT(!mul || mul->type == GGML_TYPE_F32);
    float eps;
    memcpy(&eps, norm->op_params, sizeof(eps));
    if (x->ne[0] < 1024) {
        if (mul) {
            rms_norm_bf16_cast_cuda<256, true>(x, mul, dst, eps, ctx.stream());
        } else {
            rms_norm_bf16_cast_cuda<256, false>(x, nullptr, dst, eps, ctx.stream());
        }
    } else {
        if (mul) {
            rms_norm_bf16_cast_cuda<1024, true>(x, mul, dst, eps, ctx.stream());
        } else {
            rms_norm_bf16_cast_cuda<1024, false>(x, nullptr, dst, eps, ctx.stream());
        }
    }
}

'''

NORM_DECL = r'''void ggml_cuda_op_rms_norm_cast_fused(ggml_backend_cuda_context & ctx,
                                      const ggml_tensor * x,
                                      const ggml_tensor * norm,
                                      const ggml_tensor * mul,
                                      ggml_tensor * dst);

'''

MATCHER = r'''struct ggml_cuda_rms_norm_cast_match {
    const ggml_tensor * x = nullptr;
    const ggml_tensor * norm = nullptr;
    const ggml_tensor * mul = nullptr;
    ggml_tensor * dst = nullptr;
    int count = 0;
};

// Include actual reads even when they are OP_NONE leaves. CPY src[1] is its
// destination self-reference, not a read; elided F32 intermediates are not
// kernel inputs. The original allocator may reuse the old widened source's
// backing, so reject any overlap with the real BF16 input or F32 scale.
static bool ggml_cuda_rms_cast_disjoint(const ggml_tensor * dst, const ggml_tensor * src) {
    if (!dst->data || !src->data) {
        return false;
    }
    const uintptr_t d = (uintptr_t) dst->data;
    const uintptr_t s = (uintptr_t) src->data;
    const size_t dn = ggml_nbytes(dst);
    const size_t sn = ggml_nbytes(src);
    if (dn > UINTPTR_MAX - d || sn > UINTPTR_MAX - s) {
        return false;
    }
    return d + dn <= s || s + sn <= d;
}

static bool ggml_cuda_match_rms_norm_cast(const ggml_cgraph * cgraph, int i,
                                         ggml_cuda_rms_norm_cast_match & match) {
    match = {};
    if (i < 0 || i >= cgraph->n_nodes || cgraph->n_nodes - i < 3) {
        return false;
    }
    const ggml_tensor * widen = cgraph->nodes[i];
    const ggml_tensor * x = widen->src[0];
    // The first CPY has exactly its self-reference and the one RMS reader.
    // Keep the ordinary helper's published/view protections; do not lower
    // every cast's use count or weaken the common graph fusion contract.
    if (widen->op != GGML_OP_CPY || widen->type != GGML_TYPE_F32 ||
        widen->src[1] != widen || !x || x->type != GGML_TYPE_BF16 ||
        (widen->flags & GGML_TENSOR_FLAG_COMPUTE) == 0 ||
        !ggml_node_has_n_uses(cgraph, i, 2) ||
        !ggml_are_same_shape(x, widen) || !ggml_is_contiguous(widen) ||
        !ggml_is_contiguous_rows(x)) {
        return false;
    }
    const ggml_tensor * norm = cgraph->nodes[i + 1];
    if (norm->op != GGML_OP_RMS_NORM || norm->type != GGML_TYPE_F32 ||
        norm->src[0] != widen || !ggml_are_same_shape(widen, norm) ||
        !ggml_is_contiguous(norm)) {
        return false;
    }
    float eps;
    memcpy(&eps, norm->op_params, sizeof(eps));
    if (!std::isfinite(eps) || eps < 0.0f) {
        return false;
    }
    for (int dim = 0; dim < GGML_MAX_DIMS; ++dim) {
        if (x->ne[dim] <= 0 || x->ne[dim] > INT32_MAX ||
            x->nb[dim] % sizeof(nv_bfloat16) != 0) {
            return false;
        }
    }
    const ggml_tensor * mul = nullptr;
    const ggml_tensor * last_f32 = norm;
    int count = 3;
    if (cgraph->nodes[i + 2]->op == GGML_OP_MUL) {
        if (!ggml_can_fuse(cgraph, i + 1, {GGML_OP_RMS_NORM, GGML_OP_MUL, GGML_OP_CPY})) {
            return false;
        }
        const ggml_tensor * product = cgraph->nodes[i + 2];
        if (product->type != GGML_TYPE_F32 ||
            (product->src[0] == norm) == (product->src[1] == norm)) {
            return false;
        }
        mul = product->src[product->src[0] == norm ? 1 : 0];
        if (!mul || mul->type != GGML_TYPE_F32 || !ggml_is_contiguous_rows(mul)) {
            return false;
        }
        for (int dim = 0; dim < GGML_MAX_DIMS; ++dim) {
            if (mul->ne[dim] <= 0 || x->ne[dim] % mul->ne[dim] != 0 ||
                mul->nb[dim] % sizeof(float) != 0) {
                return false;
            }
        }
        last_f32 = product;
        count = 4;
    } else if (!ggml_can_fuse(cgraph, i + 1, {GGML_OP_RMS_NORM, GGML_OP_CPY})) {
        return false;
    }
    ggml_tensor * dst = cgraph->nodes[i + count - 1];
    if (dst->op != GGML_OP_CPY || dst->type != GGML_TYPE_BF16 ||
        dst->src[0] != last_f32 || dst->src[1] != dst || dst->view_src ||
        !ggml_are_same_shape(norm, dst) || !ggml_is_contiguous(dst) ||
        !ggml_cuda_rms_cast_disjoint(dst, x) ||
        (mul && !ggml_cuda_rms_cast_disjoint(dst, mul))) {
        return false;
    }
    match.x = x;
    match.norm = norm;
    match.mul = mul;
    match.dst = dst;
    match.count = count;
    return true;
}

'''

DISPATCH = r'''    // Keep the native F32 program as the fallback. This complete cast chain
    // has no BF16 boundary between normalization and its optional F32 scale.
    if (node->op == GGML_OP_CPY) {
        ggml_cuda_rms_norm_cast_match match;
        if (ggml_cuda_match_rms_norm_cast(cgraph, i, match)) {
            ggml_cuda_op_rms_norm_cast_fused(*cuda_ctx, match.x, match.norm, match.mul, match.dst);
            return match.count - 1;
        }
    }

'''


def main():
    STAGE.mkdir(parents=True, exist_ok=True)
    if not SNAPSHOT.exists():
        SNAPSHOT.write_bytes(MANIFEST.read_bytes())
    manifest = json.loads(SNAPSHOT.read_bytes())
    assert manifest["upstream_revision"] == "456172ec733a135778adcd32d00e576a58232e45"
    all_diffs = []
    records = []
    for rel in ["src/ggml-cuda/norm.cu", "src/ggml-cuda/norm.cuh", "src/ggml-cuda/ggml-cuda.cu"]:
        raw = (BASE / rel).read_bytes()
        entry = next((e for e in manifest["files"] if e["path"] == rel), None)
        if entry is None:
            entry = {"path": rel, "before_sha256": sha(raw), "after_sha256": sha(raw), "edits": []}
            manifest["files"].append(entry)
        assert sha(raw) == entry["before_sha256"], rel
        current = apply(raw, entry["edits"], rel)
        assert sha(current) == entry["after_sha256"], rel
        before_sha = sha(current)
        if rel.endswith("/norm.cu"):
            edits = [
                {"before": '#include <cstdint>\n', "after": '#include <cstdint>\n#include <type_traits>\n'},
                {"before": 'template <int block_size, bool do_multiply = false, bool do_add = false>\nstatic __global__ void rms_norm_f32(const float * x,\n                                    float *       dst,',
                 "after": 'template <int block_size, bool do_multiply = false, bool do_add = false, typename T = float, typename Dst = float>\nstatic __global__ void rms_norm_f32(const T * x,\n                                    Dst *         dst,'},
                {"before": '        if constexpr (do_multiply && do_add) {', "after": NORM_OUTPUT},
                {"before": 'void ggml_cuda_op_rms_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {',
                 "after": NORM_ENTRY + 'void ggml_cuda_op_rms_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {'},
            ]
        elif rel.endswith("/norm.cuh"):
            context = 'void ggml_cuda_op_rms_norm(ggml_backend_cuda_context & ctx, ggml_tensor * dst);\n'
            edits = [{"before": context, "after": NORM_DECL + context}]
        else:
            context = '// try and fuse nodes and return the number of nodes to skip\n'
            head = '''static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {

    static bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));
    if (disable_fusion) {
        return 0;
    }

    ggml_tensor * node = cgraph->nodes[i];

'''
            edits = []
            if b'#include <cmath>' not in current:
                edits.append({"before": '#include <cstddef>\n', "after": '#include <cstddef>\n#include <cmath>\n'})
            edits.extend([{"before": context, "after": MATCHER + context},
                          {"before": head, "after": head + DISPATCH}])
        candidate = apply(current, edits, rel)
        entry["edits"].extend(edits)
        entry["after_sha256"] = sha(candidate)
        assert apply(raw, entry["edits"], rel) == candidate
        target = STAGE / "native-source" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(candidate)
        all_diffs.extend(difflib.unified_diff(current.decode().splitlines(True),
            candidate.decode().splitlines(True), fromfile="v11/" + rel, tofile="candidate/" + rel))
        records.append({"path": rel, "base_sha256": sha(raw), "v11_sha256": before_sha,
                        "after_sha256": sha(candidate), "bytes": len(candidate), "added_edits": len(edits)})
    prepared = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    current_manifest = MANIFEST.read_bytes()
    if current_manifest not in (SNAPSHOT.read_bytes(), prepared):
        raise RuntimeError("current manifest changed outside this preparation")
    MANIFEST.write_bytes(prepared)
    (STAGE / "native-change.diff").write_text("".join(all_diffs), encoding="utf-8", newline="\n")
    result = {"snapshot_sha256": sha(SNAPSHOT.read_bytes()), "manifest_sha256": sha(prepared),
              "source_revision": manifest["upstream_revision"], "files": records,
              "validation": "Exact unique-context raw patch replay only; no build or device execution."}
    (STAGE / "source-freeze.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
