"""Compare physical kernels from official trace exports; never infer tokens/s."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('physical_counts',
    STAGE.parent/'cuda-stable-silu/profile-analysis-stable.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

def main():
    stem=STAGE/'profile/qwen-rms-cast-trace'
    old=STAGE.parent/'immutable-constant-alias/profile/qwen-immutable-alias-trace'
    current=a.load(Path(str(stem)+'.sqlite'),Path(str(stem)+'_cuda_gpu_kern_sum.csv'))
    before=a.load(Path(str(old)+'.sqlite'),Path(str(old)+'_cuda_gpu_kern_sum.csv'))
    cp,bp=a.phases(current),a.phases(before)
    comparison=a.compare(current,before,cp,bp)
    checks={'current_phase_binning':cp['valid'],'baseline_phase_binning':bp['valid'],
        'official_csv_sqlite_equal':current['receipt']['csv_sqlite_per_symbol_counts_equal'],
        'no_graph_api_error':not current['receipt']['graph_api_failures'],
        'profile_exit_zero':a.read(STAGE/'profile/profile.result.json')['exit']==0,
        'same_generated_ids':current['target']['output']['generated_ids']==before['target']['output']['generated_ids']}
    deltas=[{'name':r['name'],'baseline_per_step':r['baseline']/25,
        'candidate_per_step':r['candidate']/25,'delta_per_step':r['delta']/25}
        for r in comparison['warm_kernel_symbol_deltas']]
    result={'schema':'hyle.rms_cast.physical_counts.v1','checks':checks,
        'current_image':a.read(STAGE/'profile/inputs.json')['image'],
        'current_receipt':current['receipt'],'baseline_receipt':before['receipt'],
        'current_warm':cp['warm_decode7_31'],'baseline_warm':bp['warm_decode7_31'],
        'deltas':deltas,'warm_phase_deltas':comparison['warm_phase_delta'],
        'throughput_claim':False,'quality_acceptance':False,
        'limits':['Baseline is a retained preceding-image trace, not simultaneous timing.',
            'Prefill phase includes cold work; no pure-prefill kernel count is claimed.',
            'Only separate unprofiled process pairs establish throughput observations.',
            'Native allocator may still reserve elided intermediate storage; no workspace reduction is inferred.',
            'GDN L2, full projection fusion and other models/quantizations/platforms remain incomplete.']}
    a.save(STAGE/'profile-analysis.json',result)
    print(json.dumps({'checks':checks,'deltas':deltas,
        'baseline':bp['warm_decode7_31']['physical_kernel_count'],
        'current':cp['warm_decode7_31']['physical_kernel_count']},indent=2))
    if not all(checks.values()):raise SystemExit(1)

if __name__=='__main__':main()
