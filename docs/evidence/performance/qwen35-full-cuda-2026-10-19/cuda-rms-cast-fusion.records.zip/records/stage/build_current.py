"""Plan by default; --build compiles only two native and two host TUs.

Root supplies native-source-freeze.json, its three native files and the actual
production provider-version.h. Reuse the final immutable-alias link closure;
no SDK/CMake build, CPU tests, source/object copies or implicit retries.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import re
import sys
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('retained_projection_build', ARCH/'cuda-projection-fusion/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
c = b.c
BASE = ARCH/'immutable-constant-alias/checks/20261019T063738-35becef7'
NATIVE_RECIPE = ARCH/'cuda-stable-silu/ggml-cuda-compile-plan.json'
PROVIDER_RECIPE = ARCH/'cuda-normalization-review/checks/20261019T060757-4cda26e4/75-compute_provider_ggml_cuda-ggml_cuda_provider-identity.json'
TEST_RECIPE = ARCH/'immutable-constant-alias/checks/20261019T063301-1d108b74/96-graph_provider_ggml_cuda-constant_expression_test-identity.json'
OLD_MAIN = ARCH/'cuda-projection-fusion/checks/20261019T054525-686f560d/ggml-cuda.obj'
OLD_PROVIDER = PROVIDER_RECIPE.with_name(PROVIDER_RECIPE.name.replace('-identity.json', '.obj'))
TEST_SOURCE = ROOT/'tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc'


def inputs(command):
    return [a for a in command if not a.startswith('/') and Path(a).is_absolute()
            and Path(a).suffix.lower() in ('.obj', '.lib')]


def make_plan():
    freeze_path, header = STAGE/'native-source-freeze.json', STAGE/'provider-version.h'
    freeze = c.read(freeze_path)
    text = header.read_text(encoding='utf-8')
    macros = re.findall(r'^\s*#\s*define\s+HYLE_GGML_CUDA_PROVIDER_VERSION\s+("[^\n]*")\s*$',text,re.M)
    if len(macros)!=1 or len(re.findall(r'^\s*#\s*define\s+HYLE_GGML_CUDA_PROVIDER_VERSION\b',text,re.M))!=1:
        raise ValueError('Expected one root-supplied provider version macro')
    version = json.loads(macros[0])
    if freeze['source_id'] not in version:
        raise ValueError('The production provider version omits the frozen source id')
    tests = ['.'.join(m) for m in re.findall(r'\bTEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',
                                            TEST_SOURCE.read_text(encoding='utf-8'))]
    if len(tests) != 3 or len(set(tests)) != 3:
        raise ValueError('Expected exactly three new RMS cast test cases')
    out = STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True, exist_ok=False)
    native = c.read(NATIVE_RECIPE)
    frozen = {str(p): b.identity(p) for p in (freeze_path, header, Path(__file__), STAGE/'run_checks.py',
        ROOT/'third_party/ggml_cuda_runtime/patches.json', ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',
        ROOT/'cmake/HyleDependencyLock.json', ROOT/'src/compute_provider_ggml_cuda/numerical_contract.h')}
    # Retained native headers stay in place. The changed norm.cuh below is an
    # explicit stage-local include, not an edit to any cached SDK header.
    for row in native['headers']:
        if not b.same(row): raise ValueError('Retained native header drift: '+row['path'])
        frozen[row['path']] = row
    source_paths = {}
    for relative in ('src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/norm.cu', 'src/ggml-cuda/norm.cuh'):
        path = Path(freeze.get('source_paths', {}).get(relative, STAGE/'native-source'/relative))
        if not path.is_absolute(): path = STAGE/path
        path = path.resolve()
        if not path.is_relative_to(STAGE) or b.identity(path)['sha256'] != freeze['sources'][relative]:
            raise ValueError('Native source differs from root freeze: '+str(path))
        source_paths[relative] = path; frozen[str(path)] = b.identity(path)
    compiles = []
    for tag in ('ggml-cuda', 'norm'):
        source = source_paths['src/ggml-cuda/'+tag+'.cu']
        command = b.native_command(native['command'], source, tag, out)
        include = source_paths['src/ggml-cuda/norm.cuh'].parent
        command[1:1] = ['-I'+str(include.parent), '-I'+str(include)]
        if '-use_fast_math' not in command:
            raise ValueError('Both native TUs must retain the original fast-math recipe')
        compiles.append({'tag':tag, 'kind':'native', 'source':b.identity(source),
            'basis':b.identity(NATIVE_RECIPE), 'command':command, 'object':str(out/(tag+'.obj'))})
    for tag, source, recipe_path in (
        ('provider', ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', PROVIDER_RECIPE),
        ('rms-cast-test', TEST_SOURCE, TEST_RECIPE)):
        template = c.read(recipe_path)['command']
        if tag == 'provider':
            forced = [a for a in template if a.lower().startswith('/fi')]
            if len(forced) != 1: raise ValueError('Expected one cached forced version include')
            template = ['/FI'+str(header) if a.lower().startswith('/fi') else a for a in template]
        command = b.host_command(template, source, tag, out)
        compiles.append({'tag':tag, 'kind':'host', 'source':b.identity(source),
            'basis':b.identity(recipe_path), 'command':command, 'object':str(out/(tag+'.obj'))})
        for path in b.host_dependencies(template):
            if path.is_file(): frozen[str(path)] = b.identity(path)
    for item in compiles:
        if not Path(item['command'][0]).is_file(): raise ValueError('Cached compiler is missing')
        frozen[item['source']['path']] = item['source']
    replacements = {c.key(OLD_MAIN):str(out/'ggml-cuda.obj'), c.key(OLD_PROVIDER):str(out/'provider.obj')}
    links, cached = {}, {}
    for name, expected in (('qwen',122), ('cuda',127)):
        base = BASE/(name+'-link-plan.json'); original = c.read(base)
        old_inputs = inputs(original['command'])
        if len(old_inputs) != expected: raise ValueError('Unexpected retained '+name+' closure')
        recorded = {c.key(r['path']):r for r in original['inputs']}
        for path in old_inputs:
            row = b.identity(path)
            if row != recorded[c.key(path)]: raise ValueError('Cached link input drift: '+path)
            cached[path] = row
        for old in replacements:
            if sum(c.key(p)==old for p in old_inputs) != 1:
                raise ValueError('Expected one explicit main/provider replacement')
        if any(Path(p).name.lower() in ('norm.obj','norm.cu.obj') for p in old_inputs):
            raise ValueError('The retained norm owner was expected inside ggml-cuda.lib')
        if sum(Path(p).name.lower()=='ggml-cuda.lib' for p in old_inputs) != 1:
            raise ValueError('Expected one retained native CUDA archive')
        command = [replacements.get(c.key(a),a) if not a.startswith('/') else a
                   for a in original['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        # Full norm TU is explicit before the archive; its old member is not
        # extracted. No /FORCE:MULTIPLE, archive mutation or dependency copy.
        command[1:1] = [str(out/'norm.obj')]
        if name == 'cuda': command[1:1] = [str(out/'rms-cast-test.obj')]
        image = out/(name+'.exe')
        command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')),
                    '/IMPLIB:'+str(image.with_suffix('.lib'))]
        new_inputs = inputs(command)
        if len(new_inputs) != expected+(1 if name=='qwen' else 2): raise ValueError('Unexpected new link closure')
        if len({c.key(p) for p in new_inputs}) != len(new_inputs): raise ValueError('Duplicate explicit input')
        links[name] = {'command':command, 'inputs':new_inputs, 'image':str(image), 'base':b.identity(base)}
    env, runtime = b.environment(links['qwen']['command'], list(cached), out)
    sdk = c.sdk_libraries(links['qwen']['command'], env)
    if any(r['resolved'] is None for r in sdk): raise ValueError('Missing named Windows SDK library')
    plan = {'schema':'hyle.rms_cast.increment.v1', 'compile':compiles, 'links':links,
        'frozen':list(frozen.values()), 'cached_inputs':list(cached.values()),
        'runtime_path_directories':runtime, 'named_sdk_libraries':sdk, 'directed_tests':tests,
        'runtime_provider_version':version, 'native_source_id':freeze['source_id'],
        'native_archive_override':'Explicit full norm.obj; retained ggml-cuda.lib is unmodified.',
        'SDK_build':False, 'CMake_run':False, 'dependency_or_object_copy':False}
    target = out/'plan.json'; c.save(target,plan)
    print('PLAN',target,'native_TUs=2 host_TUs=2 links=2; no compiler or GPU started',flush=True)
    return target


def check(plan):
    for row in plan['frozen']+plan['cached_inputs']:
        if not b.same(row): raise ValueError('Source/header/input drift: '+row['path'])
    for item in plan['compile']:
        if not b.same(item['basis']): raise ValueError('Compile recipe drift')
    for item in plan['links'].values():
        if not b.same(item['base']): raise ValueError('Retained link plan drift')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true'); parser.add_argument('--plan',type=Path)
    args = parser.parse_args(); target = args.plan.resolve() if args.plan else make_plan()
    if target.name!='plan.json' or not target.is_relative_to(STAGE/'checks'):
        raise ValueError('Plan must belong to this stage/checks')
    plan = c.read(target); check(plan)
    if not args.build: return
    out = target.parent
    if any(out.glob('*.command.json')): raise ValueError('Preserve this attempt; make a fresh plan to retry')
    (out/'tmp').mkdir(exist_ok=False)
    env,_ = b.environment(plan['links']['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
    for item in plan['compile']:
        check(plan); c.execute(item['tag']+'-compile',item['command'],env,out); check(plan)
        c.save(out/(item['tag']+'-identity.json'),{'command':item['command'],'source':item['source'],
            'object':b.identity(item['object']),'recipe':item['basis']})
    for name,item in plan['links'].items():
        check(plan)
        c.save(out/(name+'-link-plan.json'),{'command':item['command'],
            'inputs':[b.identity(p) for p in item['inputs']],'base':item['base']})
        c.execute(name+'-link',item['command'],env,out); check(plan)
        c.save(out/(name+'-image.json'),b.identity(item['image']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':2,'host_TUs':2,'links':2,
        'tests_run':False,'GPU_run':False,'runtime_provider_version':plan['runtime_provider_version']})
    print('BUILD_COMPLETE',out,flush=True)


if __name__=='__main__':
    try: main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True); raise SystemExit(1)
