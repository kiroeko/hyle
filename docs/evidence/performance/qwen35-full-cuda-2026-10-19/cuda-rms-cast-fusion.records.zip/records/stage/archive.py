"""Retain the current patch, exact commands, failures and observations; no SDK copies."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import zipfile
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('archive_rms_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
DEST=b.ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-rms-cast-fusion.zip'
PRODUCTS=(
    'third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md',
    'cmake/HyleDependencyLock.json','src/compute_provider_ggml_cuda/numerical_contract.h',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'tests/graph_provider_ggml_cuda/rms_cast_fusion_test.cc',
    'tests/graph_provider_ggml_cuda/CMakeLists.txt','docs/architecture/compute-design.md',
    'docs/developer/current-work.md','docs/implementation/model-operators.md','test.ps1')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('prepare','archive'));p.add_argument('plan',type=Path)
    args=p.parse_args();path=args.plan.resolve()
    if not path.is_relative_to(STAGE/'checks'):raise ValueError('Wrong stage')
    plan=c.read(path)
    if not c.read(path.parent/'summary.json')['passed']:raise ValueError('Current build did not pass')
    if args.mode=='prepare':
        targets=[b.b.identity(item) for item in STAGE.rglob('*') if item.is_file()
            and item.suffix.lower() in ('.exe','.map','.lib','.exp')]
        c.save(STAGE/'reclaim-targets.json',targets)
        c.save(STAGE/'archive-source-freeze.json',[b.b.identity(b.ROOT/name) for name in PRODUCTS])
        print('PREPARED',len(targets),'files',sum(row['bytes'] for row in targets),'bytes');return
    if DEST.exists():raise ValueError('Do not overwrite the archive')
    allowed={'.json','.py','.log','.xml','.csv','.sqlite','.nsys-rep','.bf16','.f32','.tsv',
             '.diff','.h','.cu','.cuh','.cmake'}
    payload={'stage/'+item.relative_to(STAGE).as_posix():item
        for item in STAGE.rglob('*') if item.is_file() and item.suffix.lower() in allowed
        and 'tmp' not in item.relative_to(STAGE).parts
        and item.name not in ('archive-verification.json','reclaim-receipt.json')}
    for row in c.read(STAGE/'archive-source-freeze.json')+plan['frozen']:
        source=Path(row['path'])
        if not b.b.same(row):raise ValueError('Frozen source drift: '+str(source))
        if source.is_relative_to(b.ROOT) and not source.is_relative_to(b.ROOT/'.scratch'):
            payload['source/'+source.relative_to(b.ROOT).as_posix()]=source
    manifest=[]
    with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,source in sorted(payload.items()):
            data=source.read_bytes();archive.writestr(name,data)
            manifest.append({'name':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        archive.writestr('manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:raise ValueError('Archive CRC mismatch')
        for row in manifest:
            data=archive.read(row['name'])
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('Archive SHA mismatch')
    proof=dict(b.b.identity(DEST),entries=len(manifest),CRC_and_payload_SHA_verified=True,
        reclaim_manifest=b.b.identity(STAGE/'reclaim-targets.json'))
    c.save(STAGE/'archive-verification.json',proof);print(json.dumps(proof),flush=True)

if __name__=='__main__':main()
