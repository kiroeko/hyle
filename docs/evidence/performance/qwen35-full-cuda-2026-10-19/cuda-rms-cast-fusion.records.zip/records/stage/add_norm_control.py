"""Plan by default; --build adds one legacy norm-control TU and relinks CUDA only.

Retain the successful native/provider/new-test objects, original15-case XML and
Qwen image/proof. The unchanged run_checks.py must still find all16 CUDA cases.
"""
from pathlib import Path
import argparse
import copy
import datetime as dt
import importlib.util
import sys
import uuid

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rms_control_current_build',STAGE/'build_current.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
b,c=d.b,d.c
BASE=STAGE/'checks/20261019T065214-eb0b4c02/plan.json'
RECIPE=d.ARCH/'cuda-stable-silu/tensor-test-identity.json'
SOURCE=d.ROOT/'tests/compute_provider_ggml_cuda/tensor_test.cc'


def make_plan():
    old=c.read(BASE);first=BASE.parent;d.check(old)
    if not c.read(first/'summary.json')['passed']:
        raise ValueError('The original four-TU build/link did not finish')
    out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    template=c.read(RECIPE)['command'];tag='norm-control'
    command=b.host_command(template,SOURCE,tag,out)
    compiled={'tag':tag,'kind':'host','command':command,'object':str(out/(tag+'.obj')),
              'source':b.identity(SOURCE),'basis':b.identity(RECIPE)}
    frozen={r['path']:r for r in old['frozen']}
    for path in (SOURCE,Path(__file__),RECIPE):frozen[str(path)]=b.identity(path)
    # Reuse the real tensor TU's dependency output, including fixture headers;
    # current snapshots belong to this fresh compile, not its historical object.
    for index,arg in enumerate(template):
        if arg.lower()!='/sourcedependencies':continue
        path=Path(template[index+1]);frozen[str(path)]=b.identity(path)
        for name in c.read(path).get('Data',{}).get('Includes',[]):
            header=Path(name).resolve()
            if header.is_relative_to(d.ROOT):frozen[str(header)]=b.identity(header)
    links,cached,reused={},{},{}
    for name in ('qwen','cuda'):
        base=first/(name+'-link-plan.json');original=c.read(base)
        for row in original['inputs']:
            if not b.same(row):raise ValueError('Successful first-build input drift: '+row['path'])
            cached[row['path']]=row
        if name=='cuda':
            command=[a for a in original['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
            if any(Path(p).name.lower() in ('norm-control.obj','tensor-test.obj','tensor_test.cc.obj')
                   for p in d.inputs(command)):
                raise ValueError('Legacy tensor test owner already appears explicitly')
            command[1:1]=[compiled['object']]
            image=out/'cuda.exe'
            command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
                      '/IMPLIB:'+str(image.with_suffix('.lib'))]
        else:
            command=original['command'];image=Path(old['links'][name]['image'])
            reused[name]=c.read(first/(name+'-image.json'))
            if b.identity(image)!=reused[name]:raise ValueError('Reused Qwen image identity differs')
        current=d.inputs(command)
        if len(current)!=len(original['inputs'])+(name=='cuda'):
            raise ValueError('Unexpected closure growth')
        if len({c.key(p) for p in current})!=len(current):raise ValueError('Duplicate explicit input')
        links[name]={'command':command,'inputs':current,'image':str(image),'base':b.identity(base)}
    if links['cuda']['inputs'].count(compiled['object'])!=1:
        raise ValueError('Expected exactly one new norm-control owner')
    retained={name:b.identity(first/'run-cuda'/name) for name in ('tests.xml','tests.result.json','tests.stdout.log')}
    value=copy.deepcopy(old)
    value.update(schema='hyle.rms_cast.add_norm_control.v1',compile=[compiled],links=links,
        frozen=list(frozen.values()),cached_inputs=list(cached.values()),
        original_successful_build=b.identity(BASE),original_build_summary=b.identity(first/'summary.json'),
        reused_images=reused,reused_qwen_proof=str(first/'run-qwen/summary.json'),
        retained_first_selection=retained,product_and_ABI_unchanged=True,
        control_only_increment=True)
    target=out/'plan.json';c.save(target,value)
    print('PLAN',target,'host_TUs=1 CUDA_link_only; Qwen image/proof reused',flush=True)
    return target


def check(value):
    d.check(value)
    for row in [value['original_successful_build'],value['original_build_summary'],
                *value['reused_images'].values(),*value['retained_first_selection'].values()]:
        if not b.same(row):raise ValueError('Retained build/image/first-selection drift: '+row['path'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true');parser.add_argument('--plan',type=Path)
    args=parser.parse_args();target=args.plan.resolve() if args.plan else make_plan()
    if target.name!='plan.json' or not target.is_relative_to(STAGE/'checks'):
        raise ValueError('Plan must belong to this stage/checks')
    value=c.read(target);check(value)
    if not args.build:return
    out=target.parent
    if any(out.glob('*.command.json')):raise ValueError('Keep this attempt; make a fresh plan to retry')
    (out/'tmp').mkdir(exist_ok=False)
    env,_=b.environment(value['links']['qwen']['command'],[r['path'] for r in value['cached_inputs']],out)
    row=value['compile'][0];check(value)
    c.execute(row['tag']+'-compile',row['command'],env,out);check(value)
    c.save(out/(row['tag']+'-identity.json'),{'command':row['command'],'source':row['source'],
        'object':b.identity(row['object']),'recipe':row['basis']})
    row=value['links']['cuda']
    c.save(out/'cuda-link-plan.json',{'command':row['command'],
        'inputs':[b.identity(p) for p in row['inputs']],'base':row['base']})
    c.execute('cuda-link',row['command'],env,out);check(value)
    c.save(out/'cuda-image.json',b.identity(row['image']))
    c.save(out/'qwen-image.json',value['reused_images']['qwen'])
    c.save(out/'qwen-link-plan.json',c.read(value['links']['qwen']['base']['path']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':0,'host_TUs':1,'links':1,
        'tests_run':False,'GPU_run':False,'reused_images':value['reused_images'],
        'reused_qwen_proof':value['reused_qwen_proof'],'product_and_ABI_unchanged':True,
        'retained_first_selection':value['retained_first_selection'],
        'runtime_provider_version':value['runtime_provider_version']})
    print('CONTROL_BUILT',out,flush=True)


if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError) as error:
        print('ERROR',str(error),file=sys.stderr,flush=True);raise SystemExit(1)
