"""Seal the exact locked patch composition; retain only the three changed sources."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
VERSION = 'hyle-ggml-cuda-resource-iq1-f32-causal-bf16-fusion-bf16-input-acc-stable-silu-bf16-matvec-rms-cast-v12'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tree(root):
    manifest = ''
    for path in sorted(root.rglob('*'), key=lambda p:p.relative_to(root).as_posix()):
        if path.is_symlink():
            raise ValueError('No symlink in a locked vendor snapshot')
        if not path.is_file():
            continue
        data = path.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
        manifest += path.relative_to(root).as_posix()+'|'+sha(data)+'\n'
    return sha(manifest.encode())

def main():
    runtime = ROOT/'src/compute_ggml_runtime'
    cuda_root = ROOT/'third_party/ggml_cuda_runtime'
    lock_path = ROOT/'cmake/HyleDependencyLock.json'
    before = STAGE/'before-seal'
    before.mkdir(exist_ok=True)
    for name,path in [('dependency-lock.json',lock_path),('NOTICE.md',cuda_root/'NOTICE.md')]:
        if not (before/name).exists():
            (before/name).write_bytes(path.read_bytes())
    mixed = STAGE/'mixed-cpu-manifest.json'
    load('mixed_cpu',runtime/'prepare_mixed_cpu_manifest.py').derive(
        UPSTREAM,ROOT/'third_party/ggml_runtime/patches.json',
        ROOT/'third_party/ggml_cpu_runtime/patches.json',mixed)
    combined = STAGE/'combined-manifest.json'
    load('cuda_iq1',runtime/'prepare_cuda_iq1_manifest.py').derive(
        UPSTREAM,mixed,cuda_root/'patches.json',cuda_root/'iq1-patches.json',combined)
    materialized = {}
    changed = {'src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/norm.cu','src/ggml-cuda/norm.cuh'}
    for row in read(combined)['files']:
        data = (UPSTREAM/row['path']).read_bytes().replace(b'\r\n',b'\n')
        if sha(data) != row['before_sha256']:
            raise ValueError('Original source mismatch: '+row['path'])
        for edit in row['edits']:
            old,new = edit['before'].encode(),edit['after'].encode()
            if data.count(old) != 1:
                raise ValueError('Nonunique combined context: '+row['path'])
            data = data.replace(old,new,1)
        if sha(data) != row['after_sha256']:
            raise ValueError('Combined result mismatch: '+row['path'])
        if row['path'] in changed:
            path = STAGE/'native-source'/row['path']
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(data)
            materialized[row['path']] = sha(data)
    if set(materialized) != changed:
        raise ValueError('The intended native source set is incomplete')
    lock = read(lock_path)
    entries = {row['name']:row for row in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'] = VERSION
    cuda['vendored']['tree_sha256'] = tree(cuda_root)
    for license in cuda['license']['files']:
        if license['root'] == 'hyle' and license['path'].endswith('NOTICE.md'):
            license['sha256'] = sha((ROOT/license['path']).read_bytes().replace(b'\r\n',b'\n'))
    lock_path.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8')
    # Same mixed CPU+CUDA identity sequence as the owning CMake, without
    # configuring or materializing another whole SDK/source tree.
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += sha((runtime/'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += sha((runtime/'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = sha(identity.encode())[:16]
    (STAGE/'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "'+
        '456172ec+iq1-46cbf0e9-resource-'+source_id+'"\n',encoding='utf-8')
    result = {'version':VERSION,'source_id':source_id,
        'vendor_tree_sha256':cuda['vendored']['tree_sha256'],'sources':materialized,
        'all_mixed_CPU_IQ1_CUDA_edits_replayed':True,'SDK_modified':False,
        'default_projection_priority_changed':False}
    save(STAGE/'native-source-freeze.json',result)
    audit = 'include("'+(ROOT/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\n'
    audit += 'hyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n'
    audit += '_hyle_dependency_tree_sha256("'+cuda_root.as_posix()+'" _actual)\n'
    audit += 'if(NOT _actual STREQUAL "'+cuda['vendored']['tree_sha256']+'")\n'
    audit += '  message(FATAL_ERROR "Vendor tree digest mismatch")\nendif()\n'
    (STAGE/'audit-native-lock.cmake').write_text(audit,encoding='utf-8')
    print(json.dumps(result,indent=2),flush=True)

if __name__ == '__main__':
    main()
