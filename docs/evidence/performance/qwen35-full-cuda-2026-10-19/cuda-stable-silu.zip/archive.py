"""Compact, verified evidence; no binaries, SDK, weights or deletion."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
ZIP = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-stable-silu.zip'

def ident(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

freeze = json.loads((STAGE / 'final-source-freeze.json').read_text())
for row in freeze['files']:
    actual = ident(ROOT / row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256')), row['path']
images = []
for name in ('baseline', 'candidate', 'cuda-tests', 'cpu-tests'):
    for suffix in ('.exe', '.map', '.lib', '.exp'):
        path = STAGE / (name + suffix)
        if path.is_file():
            images.append(ident(path))
save(STAGE / 'image-artifacts.json', dict(files=images, total_bytes=sum(r['bytes'] for r in images),
    preserve='All9 host objects,2 native objects, SDK, source snapshots, raw vectors and original profiles remain in place.'))

payload = {}
def add(path, arcname=None):
    if path.is_file():
        key = arcname or path.relative_to(STAGE).as_posix()
        assert key not in payload, key
        payload[key] = path

for path in STAGE.iterdir():
    if path.is_file() and path.suffix in ('.json', '.log', '.py', '.diff', '.cc', '.h', '.xml', '.cu', '.ps1'):
        if path.name not in ('archive-result.json', 'cleanup-plan.json', 'cleanup-result.json', 'live.json'):
            add(path)
for directory in ('before', 'native-source', 'final-source', 'profile'):
    for path in sorted((STAGE / directory).rglob('*')):
        add(path)
for arm in ('baseline', 'candidate', 'candidate-preferred'):
    for path in sorted((STAGE / ('correctness-' + arm) / 'trace/routes').glob('*.tsv')):
        add(path)
# One copy of the unchanged prefill/final hidden and logits payloads. The final
# gate records all64 exact hashes; all original vectors remain in scratch.
for phase in ('prefill', 'decode31'):
    for filename in ('hidden.bf16', 'logits.f32'):
        add(STAGE / 'correctness-baseline/trace' / phase / filename)
cold = ARCH / 'cold-candidates'
for path in sorted(cold.rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.diff', '.cc', '.h', '.md'):
        add(path, 'cold-candidates/' + path.relative_to(cold).as_posix())
for filename in ('build.py', 'run.py'):
    add(ARCH / 'cuda-bf16-chain-fusion' / filename, 'references/helpers/' + filename)
for filename in ('qwen-phases.json', 'qwen-trace_cuda_gpu_kern_sum.csv'):
    add(ARCH / 'cuda-bf16-chain-fusion/profile' / filename, 'references/baseline-profile/' + filename)
for name in ('docs/architecture/graph-design.md', 'docs/architecture/compute-design.md',
             'docs/implementation/model-operators.md',
             'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
    add(ROOT / name, 'current-docs/' + name)
case = ARCH / 'qwen-gpu-comparison/128-prefill'
for name in ('fixed-inputs.json', 'decode.ids', 'inputs/prompt.ids', 'inputs/weights.tsv'):
    add(case / name, 'references/fixed-inputs/' + name)

manifest = {key: ident(path) for key, path in sorted(payload.items())}
assert not ZIP.exists(), 'Do not replace an existing evidence archive'
with zipfile.ZipFile(ZIP, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for key, path in sorted(payload.items()):
        archive.write(path, key)
    archive.writestr('payload-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
    for key, row in manifest.items():
        raw = archive.read(key)
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], key
result = dict(archive=ident(ZIP), payload_files=len(payload), all_CRC_and_SHA256_verified=True,
    sources_unchanged=True, originals_retained=True, image_files_copied=False,
    prior_raw_baseline='cuda-bf16-chain-fusion.zip already retains the original baseline Nsight/SQLite.')
save(STAGE / 'archive-result.json', result)
save(STAGE / 'cleanup-plan.json', dict(archive=result['archive'], files=images,
    total_bytes=sum(r['bytes'] for r in images), scope='Only the16 completed image/map/lib/exp files; no recursive deletion.'))
print(json.dumps(result), flush=True)
