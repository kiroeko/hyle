"""Compile only the two frozen CUDA TUs; never link or execute a GPU program."""
from pathlib import Path
import argparse
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
ROOT = OUT.parents[2]
spec = importlib.util.spec_from_file_location('stable_silu_compile_helpers',
    ARCH / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT


def frozen():
    freeze = b.read(OUT / 'source-freeze.json')
    for key in ['manifest', 'lock', 'private_header']:
        row = freeze[key]
        assert b.ident(row['path']) == row, key
    for row in freeze['sources']:
        assert b.ident(row['path']) == row
    return freeze


def build(name):
    freeze = frozen()
    if name == 'ggml-cuda':
        origin = ARCH / 'cuda-dense-projection/native-bf16-acc/compile-recipes.json'
        original = b.read(origin)['ggml-cuda']
    else:
        origin = ARCH / 'cuda-bfloat-elementwise-build/unary-identity.json'
        original = b.read(origin)['command']
    args, skip = [], False
    for v in original:
        if skip:
            skip = False
            continue
        if v in ['-c', '-o', '-MT', '-MF']:
            skip = True
            continue
        if v.startswith('-Xcompiler=-Fd'):
            continue
        args.append(v)
    assert '-std=c++17' in args
    assert '--generate-code=arch=compute_89,code=[sm_89]' in args
    assert ('-use_fast_math' in args) == (name == 'ggml-cuda')
    assert any('compute_provider_ggml_cuda' in v for v in args)
    source = OUT / 'native-source/src/ggml-cuda' / (name + '.cu')
    obj, dep = OUT / (name + '.obj'), OUT / (name + '.d')
    assert not obj.exists(), 'Do not overwrite an existing compiled object'
    args += ['-MT', str(obj), '-MF', str(dep), '-c', str(source), '-o', str(obj),
             '-Xcompiler=-Fd' + str(OUT / (name + '.pdb')) + ',-FS']
    # Only authenticate the reused repo headers; no SDK/header/object is copied.
    prior_dep = (ARCH / 'cuda-dense-projection/native-bf16-acc/ggml-cuda.d') if name == 'ggml-cuda' else (ARCH / 'cuda-bfloat-elementwise-build/unary.obj.d')
    headers = {str(p): b.ident(p) for p in b.dependencies(prior_dep)}
    headers[str(ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h')] = freeze['private_header']
    recipe = dict(name=name, command=args, recipe_origin=b.ident(origin),
                  source=b.ident(source), headers=list(headers.values()))
    b.save(name + '-compile-plan.json', recipe)
    result = b.execute(('001-' if name == 'ggml-cuda' else '002-') + name + '-compile', args)
    frozen()
    assert all(b.ident(k) == v for k, v in headers.items()), 'A reused header changed during compilation'
    b.save(name + '-identity.json', dict(source=b.ident(source), object=b.ident(obj),
        private_header=freeze['private_header'], command=args, compile_result=result,
        recipe_origin=b.ident(origin), matching_headers=list(headers.values()),
        actual_repo_headers=[b.ident(p) for p in b.dependencies(dep)],
        source_id=freeze['source_id'], fast_math=name == 'ggml-cuda',
        linked=False, GPU_execution=False, SDK_modified=False, reused_objects_modified=False))
    print(name, 'COMPLETE', json.dumps(b.ident(obj)), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name', choices=['ggml-cuda', 'unary'])
    build(parser.parse_args().name)
