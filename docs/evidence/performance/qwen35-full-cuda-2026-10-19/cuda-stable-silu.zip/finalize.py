"""Verify appended edits against the complete pre-edit mixed/IQ1 composition."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sha = lambda data: hashlib.sha256(data).hexdigest()
ident = lambda p: dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))
spec = importlib.util.spec_from_file_location('stable_silu_final_composer',
    OUT.parent / 'generic-progress/ggml-cache/build.py')
composer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(composer)
before = json.loads((OUT / 'native-before.json').read_text())
manifest_path = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
lock_path = ROOT / 'cmake/HyleDependencyLock.json'
current = json.loads(manifest_path.read_text())
original = json.loads((OUT / 'before/third_party/ggml_cuda_runtime/patches.json').read_text())
old_entries = {x['path']: x for x in original['files']}
entries = {x['path']: x for x in current['files']}
after, combined, source_id = composer.generate(False)
changed = sorted(p for p, data in after.items() if sha(data) != before['composed_source_sha256'][p])
assert changed == ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/unary.cu']
for name in changed:
    previous = (OUT / 'before' / name).read_bytes()
    count = len(old_entries[name]['edits'])
    assert entries[name]['edits'][:count] == old_entries[name]['edits']
    for edit in entries[name]['edits'][count:]:
        a, b = edit['before'].encode(), edit['after'].encode()
        assert previous.count(a) == 1, (name, a[:80])
        previous = previous.replace(a, b, 1)
    assert previous == after[name], name
    target = OUT / 'native-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(after[name])
dep = next(x for x in json.loads(lock_path.read_text())['dependencies'] if x['name'] == 'ggml_cuda_runtime_patches')
assert dep['version'].endswith('-stable-silu-v10')
freeze = dict(previous_source_id=before['source_id'], source_id=source_id,
    manifest=ident(manifest_path), lock=ident(lock_path),
    private_header=ident(ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h'),
    sources=[ident(OUT / 'native-source' / p) for p in changed],
    changed_native_files=changed, all_other_composed_files_unchanged=True,
    full_mixed_and_iq1_composition_valid=True,
    vendor_tree_sha256=dep['vendored']['tree_sha256'], version=dep['version'],
    SDK_modified=False, public_descriptor_added=False)
(OUT / 'combined-manifest.json').write_text(json.dumps(combined, indent=2)+'\n')
(OUT / 'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n')
print(json.dumps(freeze, indent=2))
