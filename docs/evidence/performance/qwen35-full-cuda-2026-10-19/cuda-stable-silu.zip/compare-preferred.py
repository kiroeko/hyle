"""Offline comparison of the retained baseline and final preferred candidate."""
import collections
import csv
import hashlib
import json
import pathlib
import re

STAGE = pathlib.Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
TAGS = {"baseline": "correctness-baseline", "candidate": "correctness-candidate-preferred"}
PHASES = ["prefill"] + [f"decode{i}" for i in range(1, 32)]
OUTPUTS = ["hidden.bf16", "logits.f32"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = pathlib.Path(path)
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(data), "sha256": sha(data)}


def canonical(value):
    return sha(json.dumps(value, separators=(",", ":"), sort_keys=True).encode())


def read(arm, suffix):
    return json.loads((STAGE / f"{TAGS[arm]}{suffix}").read_text())


inputs = {arm: read(arm, "-inputs.json") for arm in TAGS}
stdout = {arm: read(arm, ".stdout.log") for arm in TAGS}
metrics = {arm: read(arm, "-metrics.json") for arm in TAGS}
results = {arm: read(arm, ".result.json") for arm in TAGS}
manifests, differences = {}, []
by_output = {name: {"files": 32, "equal_files": 0} for name in OUTPUTS}
total_bytes = 0
for arm, tag in TAGS.items():
    manifest = []
    for phase in PHASES:
        for name in OUTPUTS:
            data = (STAGE / tag / "trace" / phase / name).read_bytes()
            manifest.append(f"{phase}/{name}|{len(data)}|{sha(data)}\n")
            by_output[name]["bytes_per_file"] = len(data)
            if arm == "candidate":
                total_bytes += len(data)
                before = STAGE / TAGS["baseline"] / "trace" / phase / name
                if data == before.read_bytes():
                    by_output[name]["equal_files"] += 1
                else:
                    differences.append(f"{phase}/{name}")
    manifests[arm] = sha("".join(manifest).encode())

routes, shared_pairs, shared_changes = {}, None, None
for label in ["default-T1", "default-T128"]:
    rows, nodes, receipts = {}, {}, {}
    for arm, tag in TAGS.items():
        path = STAGE / tag / "trace/routes" / f"{label}.route.tsv"
        receipts[arm] = identity(path)
        with path.open() as stream:
            rows[arm] = list(csv.DictReader(stream, delimiter="\t"))
        nodes[arm] = {}
        for row in rows[arm]:
            for member in row["nodes"].split(","):
                ordinal, operation = member.split(":")
                nodes[arm][int(ordinal)] = (row["provider"], row["kind"], row["implementation"], operation)
    before, after = nodes["baseline"], nodes["candidate"]
    changes = collections.defaultdict(list)
    for ordinal, actual in sorted(after.items()):
        previous = before[ordinal]
        if actual != previous:
            key = f"{previous[0]}/kind{previous[1]}/impl{previous[2]} -> {actual[0]}/kind{actual[1]}/impl{actual[2]}"
            changes[key].append(ordinal)
    pairs = [[int(m.split(":")[0]) for m in row["nodes"].split(",")]
             for row in rows["candidate"]
             if row["provider"] == "ggml-cuda" and row["implementation"] == "3"]
    blas = {arm: {n for n, value in nodes[arm].items()
                  if value[0] == "cublasLt" and value[3] == "matmul"} for arm in TAGS}
    if shared_pairs is None:
        shared_pairs, shared_changes = pairs, dict(changes)
    else:
        assert shared_pairs == pairs and shared_changes == dict(changes)
    boundaries = [STAGE / tag / "trace/routes" / f"{label}.boundaries.tsv" for tag in TAGS.values()]
    routes[label] = {
        **receipts, "logical_nodes_each": len(before), "node_set_equal": before.keys() == after.keys(),
        "operation_labels_equal": all(before[n][3] == after[n][3] for n in before),
        "baseline_steps": len(rows["baseline"]), "candidate_steps": len(rows["candidate"]),
        "node_route_changed_count": sum(map(len, changes.values())),
        "provider_changed_nodes": sum(before[n][0] != after[n][0] for n in before),
        "ggml_impl3_region_count": len(pairs),
        "cublasLt_matmul_nodes": {arm: len(blas[arm]) for arm in TAGS},
        "all_baseline_cublasLt_matmul_nodes_retained": blas["baseline"] == blas["candidate"],
        "remaining_sglang_SiLU_nodes": [n for n, value in sorted(after.items()) if value[0] == "sglang-cuda"],
        "boundaries_byte_equal": boundaries[0].read_bytes() == boundaries[1].read_bytes(),
        "boundaries": {arm: identity(path) for arm, path in zip(TAGS, boundaries)},
    }

capture = {}
for arm, tag in TAGS.items():
    reports = re.findall(r"prepared T=(\d+) visible=(\d+) replay=(\w+).*?capture_recorded=(\d+) capture_reused=(\d+)",
                         (STAGE / f"{tag}.stderr.log").read_text())
    counts = metrics[arm]["capture_counts"]
    assert len(reports) == len(counts) == 32
    assert [(int(r[3]), int(r[4])) for r in reports] == [(x["recorded"], x["reused"]) for x in counts]
    capture[arm] = {
        "preparations": len(reports), "replay_route_counts": dict(collections.Counter(r[2] for r in reports)),
        "recorded_total": sum(x["recorded"] for x in counts), "reused_total": sum(x["reused"] for x in counts),
        "per_phase_counts_sha256": canonical(counts),
        "initial_recording_phases": [phase for phase, count in zip(PHASES, counts) if count["recorded"]],
    }

image_matches = {}
for arm in TAGS:
    receipt = inputs[arm]["image"]
    actual = identity(receipt["path"])
    image_matches[arm] = all(receipt[key] == actual[key] for key in ["bytes", "sha256"])
    assert image_matches[arm]
    assert metrics[arm]["ids"] == stdout[arm]["generated_ids"]

bf16 = [pair for pair in shared_pairs if pair[1] - pair[0] == 3]
f32 = [pair for pair in shared_pairs if pair[1] - pair[0] == 1]
root_gate = json.loads((STAGE / "correctness-preferred-gate.json").read_text())
assert root_gate["final_candidate_image"] == inputs["candidate"]["image"]
summary = {
    "status": "64_vector_files_and_32_generated_IDs_bit_identical" if not differences else "vector_difference",
    "scope": "Offline final preferred candidate vs retained original correctness-baseline, 128 prefill +31 fixed-input decode. No new build/GPU/profile/performance measurement.",
    "vectors": {"files": 64, "equal_files": 64-len(differences), "bytes_per_arm": total_bytes,
                "baseline_content_manifest_sha256": manifests["baseline"], "candidate_content_manifest_sha256": manifests["candidate"],
                "manifest_order": "prefill then decode1..31; hidden.bf16 then logits.f32; UTF8 relative_path|byte_count|sha256 LF rows",
                "by_output": by_output, "differences": differences},
    "IDs": {"count": len(stdout["baseline"]["generated_ids"]),
            "equal": stdout["baseline"]["generated_ids"] == stdout["candidate"]["generated_ids"],
            "baseline_canonical_JSON_sha256": canonical(stdout["baseline"]["generated_ids"]),
            "candidate_canonical_JSON_sha256": canonical(stdout["candidate"]["generated_ids"]),
            "fixed_decode_inputs_equal": stdout["baseline"]["decode_input_ids"] == stdout["candidate"]["decode_input_ids"],
            "source_id_equal": stdout["baseline"]["source_id"] == stdout["candidate"]["source_id"]},
    "inputs_equal": {key: inputs["baseline"][key] == inputs["candidate"][key]
                     for key in ["fixed_inputs", "prompt", "weights_reference", "tape"]},
    "images": {arm: inputs[arm]["image"] for arm in TAGS}, "image_receipts_match_actual_files": image_matches,
    "root_gate": {"receipt": identity(STAGE / "correctness-preferred-gate.json"),
                  "candidate_image_identity_agrees": True, "root_gate_unchanged": True},
    "probe_results": {arm: {key: results[arm][key] for key in ["pid", "exit", "terminal"]} for arm in TAGS},
    "first_and_last_phase_boundaries": {
        phase: {"candidate_outputs": {name: identity(STAGE / TAGS["candidate"] / "trace" / phase / name) for name in OUTPUTS},
                "generated_ID": stdout["candidate"]["generated_ids"][index],
                "vectors_and_ID_equal_to_baseline": True}
        for phase, index in [("prefill", 0), ("decode31", -1)]},
    "capture": {"per_phase_counts_equal": metrics["baseline"]["capture_counts"] == metrics["candidate"]["capture_counts"], **capture},
    "routes": routes,
    "shared_T1_T128_impl3": {
        "total": len(shared_pairs), "BF16_FFN_count": len(bf16), "F32_SSM_z_gate_count": len(f32),
        "BF16_FFN_exact_node_pairs": bf16, "F32_SSM_z_gate_exact_node_pairs": f32,
        "dtype_evidence": "Model builder main.cc:181-186 BF16 FFN and372-374 F32 SSM gate, matched to stable node ordinals in the route. Dtype is source-derived, not a field emitted by route.tsv.",
        "unclassified_pairs": [p for p in shared_pairs if p not in bf16 and p not in f32],
    },
    "shared_T1_T128_node_change_groups": shared_changes,
    "interpretation": "42 exact SiLU/Mul route2 regions;18 old generic Mul+Cast regions leave their trailing Cast standalone and24 former standalone Mul operations join their SiLU. Public steps decrease24. Remaining18 SGLang SiLU are conv activations with three View readers. Routing does not establish physical kernel counts or speedup.",
    "preservation": "Initial correctness-summary.json, remaining-chain-review.json and earlier trace receipts are retained unchanged.",
    "analysis_script": identity(pathlib.Path(__file__)),
}
target = STAGE / "correctness-preferred-summary.json"
target.write_text(json.dumps(summary, indent=2)+"\n", encoding="utf-8")
assert summary["vectors"]["files"] == summary["vectors"]["equal_files"] == 64
assert summary["IDs"]["equal"] and summary["IDs"]["fixed_decode_inputs_equal"]
assert all(summary["inputs_equal"].values())
print(json.dumps(identity(target), indent=2))
