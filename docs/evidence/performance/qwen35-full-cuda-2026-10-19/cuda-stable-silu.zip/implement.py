"""Append exact native edits and validate all mixed/IQ1 composed sources."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
LOCK = ROOT / 'cmake/HyleDependencyLock.json'
HEADER = ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h'
sha = lambda data: hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))


spec = importlib.util.spec_from_file_location('stable_silu_composer',
    OUT.parent / 'generic-progress/ggml-cache/build.py')
composer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(composer)
before, _, before_id = composer.generate(False)
assert not (OUT / 'native-before.json').exists(), 'Preserve the initial native before state'
before_dir = OUT / 'before'
before_dir.mkdir(exist_ok=True)
for p in [MANIFEST, LOCK]:
    target = before_dir / p.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
for name in ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/unary.cu']:
    p = before_dir / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(before[name])
save('native-before.json', dict(product_files=[ident(MANIFEST), ident(LOCK)],
    new_private_header=ident(HEADER), source_id=before_id,
    composed_source_sha256={p: sha(v) for p, v in before.items()}))
manifest = json.loads(MANIFEST.read_text())
entries = {row['path']: row for row in manifest['files']}
candidate = {}


def apply(path, old, new):
    if path not in candidate:
        e = entries[path]
        data = (RAW / path).read_bytes().replace(b'\r\n', b'\n')
        assert sha(data) == e['before_sha256']
        for edit in e['edits']:
            a, b = edit['before'].encode(), edit['after'].encode()
            assert data.count(a) == 1, (path, a[:80])
            data = data.replace(a, b, 1)
        assert sha(data) == e['after_sha256']
        candidate[path] = data
    a, b = old.encode(), new.encode()
    assert candidate[path].count(a) == 1, (path, a[:120])
    candidate[path] = candidate[path].replace(a, b, 1)
    entries[path]['edits'].append(dict(before=old, after=new))
    entries[path]['after_sha256'] = sha(candidate[path])


MAIN = 'src/ggml-cuda/ggml-cuda.cu'
UNARY = 'src/ggml-cuda/unary.cu'
apply(MAIN, '#include "ggml-impl.h"', '#include "ggml-impl.h"\n#include "numerical_contract.h"')
helpers = '''// Only this private UNARY contract uses stable tails and an intermediate RNE.
static bool ggml_hyle_stable_silu(const ggml_tensor * node) {
    return node && node->op == GGML_OP_UNARY && ggml_get_unary_op(node) == GGML_UNARY_OP_SILU &&
        ggml_get_op_params_i32(node, hyle::compute::ggml_cuda::internal::kUnaryContractParam) ==
            hyle::compute::ggml_cuda::internal::kStableSiluContract;
}

static bool ggml_hyle_can_fuse_stable_silu_mul(const ggml_tensor * unary, const ggml_tensor * mul) {
    const ggml_tensor * x = unary->src[0];
    if (mul->src[0] != unary && mul->src[1] != unary) {
        return false;
    }
    const ggml_tensor * other = mul->src[0] == unary ? mul->src[1] : mul->src[0];
    if (!x || !other || other == unary ||
        (unary->type != GGML_TYPE_F32 && unary->type != GGML_TYPE_BF16) ||
        x->type != unary->type || other->type != unary->type || mul->type != unary->type ||
        !x->data || !unary->data || !other->data || !mul->data || ggml_nelements(unary) == 0 ||
        !ggml_is_contiguous(x) || !ggml_is_contiguous(unary) ||
        !ggml_is_contiguous(other) || !ggml_is_contiguous(mul) ||
        !ggml_are_same_layout(x, unary) || !ggml_are_same_layout(other, unary) ||
        !ggml_are_same_layout(mul, unary)) {
        return false;
    }
    const auto overlaps = [](const ggml_tensor * a, const ggml_tensor * b) {
        const uintptr_t aa = (uintptr_t) a->data;
        const uintptr_t bb = (uintptr_t) b->data;
        return aa <= bb ? bb - aa < ggml_nbytes(a) : aa - bb < ggml_nbytes(b);
    };
    const auto same_mapping = [](const ggml_tensor * a, const ggml_tensor * b) {
        return a->data == b->data && ggml_are_same_layout(a, b);
    };
    // Include OP_NONE leaves: another operand may observe the elided store.
    if (overlaps(unary, other) ||
        (overlaps(unary, x) && !same_mapping(unary, x)) ||
        (overlaps(mul, x) && !same_mapping(mul, x)) ||
        (overlaps(mul, other) && !same_mapping(mul, other))) {
        return false;
    }
    return true;
}

'''
apply(MAIN, 'static bool ggml_cuda_can_fuse(const struct ggml_cgraph *', helpers + 'static bool ggml_cuda_can_fuse(const struct ggml_cgraph *')
apply(MAIN, '''    const auto is_equal = [](const std::initializer_list<enum ggml_op> & list1,''', '''    // The old convolution/activation fusers do not implement this contract.
    // Only the marked two-node pointwise path below may elide its Unary store.
    for (size_t j = 0; j < ops.size(); ++j) {
        if (node_idx + (int) j >= cgraph->n_nodes) {
            return false;
        }
        if (ggml_hyle_stable_silu(cgraph->nodes[node_idx + j]) &&
            !(j == 0 && ops.size() == 2 && ops.begin()[0] == GGML_OP_UNARY &&
              ops.begin()[1] == GGML_OP_MUL)) {
            return false;
        }
    }

    const auto is_equal = [](const std::initializer_list<enum ggml_op> & list1,''')
apply(MAIN, '''        if (unary->type != GGML_TYPE_F32 && unary->type != GGML_TYPE_F16) {
            return false;
        }

        if (unary->type != mul->type) {''', '''        if (ggml_hyle_stable_silu(unary)) {
            return ggml_hyle_can_fuse_stable_silu_mul(unary, mul);
        }

        if (unary->type != GGML_TYPE_F32 && unary->type != GGML_TYPE_F16) {
            return false;
        }

        if (unary->type != mul->type) {''')
apply(MAIN, '''        case GGML_OP_UNARY:
            if (op->src[0]->type == GGML_TYPE_BF16 || op->type == GGML_TYPE_BF16) {''', '''        case GGML_OP_UNARY:
            if (ggml_hyle_stable_silu(op)) {
                return (op->type == GGML_TYPE_F32 || op->type == GGML_TYPE_BF16) &&
                       op->src[0]->type == op->type && ggml_is_contiguous(op->src[0]);
            }
            if (op->src[0]->type == GGML_TYPE_BF16 || op->type == GGML_TYPE_BF16) {''')

apply(UNARY, '#include "convert.cuh"', '#include "convert.cuh"\n#include "numerical_contract.h"\n\n#include <type_traits>')
apply(UNARY, '''static __device__ __forceinline__ float op_silu(float x) {
    return ggml_cuda_op_silu_single(x);
}
''', '''static __device__ __forceinline__ float op_silu(float x) {
    return ggml_cuda_op_silu_single(x);
}

// Match HYLE ordinary Unary, not the separately defined GLU formula.
// This unit is compiled by ggml-cuda-precise-unary without fast math.
static __device__ __forceinline__ float op_hyle_stable_silu(float x) {
    if (isinf(x) && x < 0) {
        return 0.0f;
    }
    const float e = expf(-fabsf(x));
    const float sigmoid = x >= 0 ? 1.0f / (1.0f + e) : e / (1.0f + e);
    return x * sigmoid;
}

static bool ggml_hyle_stable_silu(const ggml_tensor * node) {
    return ggml_get_unary_op(node) == GGML_UNARY_OP_SILU &&
        ggml_get_op_params_i32(node, hyle::compute::ggml_cuda::internal::kUnaryContractParam) ==
            hyle::compute::ggml_cuda::internal::kStableSiluContract;
}
''')
apply(UNARY, '''                  op == op_sqrt || op == op_tanh || op == op_sigmoid) {''', '''                  op == op_sqrt || op == op_tanh || op == op_sigmoid || op == op_hyle_stable_silu) {''')
apply(UNARY, '''void ggml_cuda_op_silu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_silu>(ctx, dst);
}''', '''void ggml_cuda_op_silu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (ggml_hyle_stable_silu(dst)) {
        GGML_ASSERT(dst->type == GGML_TYPE_F32 || dst->type == GGML_TYPE_BF16);
        ggml_cuda_op_unary<op_hyle_stable_silu>(ctx, dst);
        return;
    }
    ggml_cuda_op_unary<op_silu>(ctx, dst);
}''')
apply(UNARY, '''template <float (*op)(float), typename T>
static __global__ void unary_gated_op_kernel''', '''template <float (*op)(float), typename T, bool round_unary = false>
static __global__ void unary_gated_op_kernel''')
apply(UNARY, '''    dst[i] = (T)(op((float)x[j0]) * (float)g[j1]);''', '''    if constexpr (round_unary) {
        float value = op((float)x[j0]);
        if constexpr (std::is_same<T, nv_bfloat16>::value) {
            value = __bfloat162float(__float2bfloat16_rn(value));
        } else {
            value = (float)(T)value;
        }
        dst[i] = (T)(value * (float)g[j1]);
    } else {
        dst[i] = (T)(op((float)x[j0]) * (float)g[j1]);
    }''')
apply(UNARY, '''template <float (*op)(float), typename T>
static void unary_gated_cuda''', '''template <float (*op)(float), typename T, bool round_unary = false>
static void unary_gated_cuda''')
apply(UNARY, '''ggml_cuda_kernel_launch(unary_gated_op_kernel<op, T>, launch_params, x, g, dst, k, n, o0, o1);''', '''ggml_cuda_kernel_launch(unary_gated_op_kernel<op, T, round_unary>, launch_params, x, g, dst, k, n, o0, o1);''')
apply(UNARY, '''template <float (*op)(float)>
static void ggml_cuda_op_unary_mul_impl''', '''template <float (*op)(float), bool round_unary = false>
static void ggml_cuda_op_unary_mul_impl''')
apply(UNARY, '''    GGML_ASSERT(unary_src->type == GGML_TYPE_F32 || unary_src->type == GGML_TYPE_F16);''', '''    GGML_ASSERT(unary_src->type == GGML_TYPE_F32 || unary_src->type == GGML_TYPE_F16 ||
                (round_unary && unary_src->type == GGML_TYPE_BF16));''')
apply(UNARY, '''    if (unary_src->type == GGML_TYPE_F16) {
        unary_gated_cuda<op>((const half *) unary_src->data''', '''    if constexpr (round_unary) {
        if (unary_src->type == GGML_TYPE_BF16) {
            unary_gated_cuda<op, nv_bfloat16, true>((const nv_bfloat16 *) unary_src->data,
                (const nv_bfloat16 *) other_src->data, (nv_bfloat16 *) mul_node->data, k, nc,
                unary_stride / sizeof(nv_bfloat16), other_stride / sizeof(nv_bfloat16), stream);
            return;
        }
    }
    if (unary_src->type == GGML_TYPE_F16) {
        unary_gated_cuda<op, half, round_unary>((const half *) unary_src->data''')
apply(UNARY, '''        unary_gated_cuda<op>((const float *) unary_src->data,''', '''        unary_gated_cuda<op, float, round_unary>((const float *) unary_src->data,''')
apply(UNARY, '''void ggml_cuda_op_unary_mul(ggml_backend_cuda_context & ctx, ggml_tensor * unary_node, ggml_tensor * mul_node) {
    switch''', '''void ggml_cuda_op_unary_mul(ggml_backend_cuda_context & ctx, ggml_tensor * unary_node, ggml_tensor * mul_node) {
    if (ggml_hyle_stable_silu(unary_node)) {
        GGML_ASSERT(unary_node->type == GGML_TYPE_F32 || unary_node->type == GGML_TYPE_BF16);
        ggml_cuda_op_unary_mul_impl<op_hyle_stable_silu, true>(ctx, unary_node, mul_node);
        return;
    }
    switch''')

MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
lock_text = LOCK.read_text()
dep = next(x for x in json.loads(lock_text)['dependencies'] if x['name'] == 'ggml_cuda_runtime_patches')
vendor = ROOT / dep['vendored']['path']
rows = []
for p in sorted(vendor.rglob('*'), key=lambda p: p.relative_to(vendor).as_posix()):
    assert not p.is_symlink()
    if p.is_file():
        data = p.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
        rows.append(p.relative_to(vendor).as_posix() + '|' + sha(data) + '\n')
tree = sha(''.join(rows).encode())
assert dep['version'].endswith('-v9')
version = dep['version'][:-3] + '-stable-silu-v10'
assert lock_text.count(dep['vendored']['tree_sha256']) == lock_text.count(dep['version']) == 1
lock_text = lock_text.replace(dep['vendored']['tree_sha256'], tree).replace(dep['version'], version)
LOCK.write_text(lock_text, encoding='utf-8')
import runpy
runpy.run_path(str(OUT / 'finalize.py'), run_name='__main__')
