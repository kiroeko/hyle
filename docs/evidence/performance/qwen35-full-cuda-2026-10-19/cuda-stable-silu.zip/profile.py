"""One complete model trace, then official offline export and statistics."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('silu_profile_helpers', OUT.parent / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
plan = b.read(OUT / 'profile-plan.json')
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('profile', 'export', 'stats'))
mode = parser.parse_args().mode
(OUT / 'profile').mkdir(exist_ok=True)
if mode == 'profile':
    actual = b.read(OUT / 'candidate-image.json')['image']
    assert actual == b.ident(actual['path'])
    proof = b.read(OUT / 'correctness-preferred-gate.json')
    assert proof['vectors']['files'] == proof['vectors']['equal_files'] == 64
    command = plan['profile_command']
    assert actual['path'] in command and '--trace' not in command
    b.save('profile-qwen-stable-silu-inputs.json', dict(image=actual,
        link_plan=b.ident(OUT / 'candidate-link-plan.json'),
        correctness=b.ident(OUT / 'correctness-preferred-gate.json'),
        performance=b.ident(OUT / 'performance-summary.json'),
        actual_command=command, planned_only_receipt_is_not_used=True,
        profiler_timings_used_for_speed=False, memory_monitor=False))
else:
    command = plan['offline_' + mode + '_command']
b.execute(mode + '-qwen-stable-silu', command)
