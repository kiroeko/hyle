# 模型、量化 profile 与算子子图

本表是模型与计算能力的地图：模型／量化制品→权重角色与推理主链→基础算子和常见融合→实际后端实现。
正向用于找缺算子、缺融合和漏接线，反向用于判断哪些实现仍有消费者。融合本身也需要精确的格式、数值和资源合同；
图上的 region、批量 capture 和物理 kernel 融合分别记录，不把几种实现形状当成同一种能力。

这是当前模型与量化版本到权重角色、计算子图、Hyle custom descriptor 的现行人读入口。模型范围由[需求目录 D](tasks/compute/llm-moe-provider-demand-matrix.json) 的 `/current_scope` 定义：六个既有模型，加 DeepSeek V4 Pro-0813、Flash-0731 两个正式版，共 **8 个模型**；下表的 **24 个 profile 是本轮已锁基线，不是量化支持范围上限**。旧 `deepseek_v4_pro`、`deepseek_v4_flash` preview 及其量化衍生制品不再属于当前范围；正式版属于单独锁定的身份，不自动扩大到 V4.1。

目标模型的 Unsloth 量化制品及 Hugging Face 上的主流量化制品也属于后续覆盖范围，不能用“每模型三个profile”排除其他实际发布的格式。新增制品按 D 的 `/current_scope/quantization_scope` 核定真实仓库、固定revision、对应GA base model、逐角色格式与数值合同后扩充本表；尚未核实的格式不写成某个模型已经发布或Hyle已经支持。

来源索引：D 的 `/profile_catalog` 与 `/current_scope/added_releases` 保存身份，`/demand_units` 保存 15 个区域；[需求明细 C](tasks/compute/llm-moe-coverage-matrix.json) 的 `/requirements` 保存 64 条历史需求；[原生映射 P](tasks/compute/llm-moe-provider-map.json) 的 `/requirements` 回指 C 的具体 domain。下面保留这些来源的反向关系，不继承旧状态、通过结论或 Provider 支持声明。

工作顺序是维护总表、核实并移除仅属旧 preview 的非通用实现、再逐量化精度检查融合与接入切割。**历史 64 行不是完整 GA 清单，也不是 24 个 profile 的逐角色量化与融合审查完成清单。** 这里的“保留”只表示当前需求或独立能力仍在、暂不删除；不表示现有 descriptor 已数值等价或已经支持 GA。

## 模型与量化身份

`official`、`primary`、`fidelity` 分别对应目录键 `official`、`primary_gguf`、`fidelity_gguf`。身份 pointer 均相对 D；固定 revision 以相应对象为准。GA GGUF 的发布者与 `base_model` 已核对，主文件逐 tensor header 尚未核定，因此精确混合 codec 继续留空，不由 variant 名推断。

| 模型 | Profile | 具体 variant | 记录的 formats / 未核项 | 身份 pointer（D） |
| --- | --- | --- | --- | --- |
| Qwen3.5-2B | official | official-bf16 | BF16；F32 recurrent | `/profile_catalog/0/official` |
| Qwen3.5-2B | primary | UD-Q4_K_XL | Q4_K；Q5_K；Q6_K；Q8_0；IQ4_XS；F16；F32 | `/profile_catalog/0/primary_gguf` |
| Qwen3.5-2B | fidelity | UD-Q8_K_XL | Q8_0；F16；F32 | `/profile_catalog/0/fidelity_gguf` |
| Qwen3.8-27B | official | official-bf16 | BF16；F32 recurrent | `/profile_catalog/1/official` |
| Qwen3.8-27B | primary | UD-Q4_K_M | Q3_K；Q4_K；Q5_K；Q6_K；Q8_0；IQ3；IQ4；BF16；F32 | `/profile_catalog/1/primary_gguf` |
| Qwen3.8-27B | fidelity | UD-Q8_K_XL | Q8_0；BF16；F32 | `/profile_catalog/1/fidelity_gguf` |
| Qwen3.8-2.4T-A95B | official | official-bf16 | BF16；F32 recurrent/router | `/profile_catalog/2/official` |
| Qwen3.8-2.4T-A95B | primary | UD-IQ4_XS | IQ4_XS；Q4_K；Q5_K；Q6_K；F32 | `/profile_catalog/2/primary_gguf` |
| Qwen3.8-2.4T-A95B | fidelity | Q8_0 | Q8_0；F32 | `/profile_catalog/2/fidelity_gguf` |
| Kimi-K3 | official | official-mxfp4 | MXFP4 packed expert；UE8M0 scale；BF16；F32 | `/profile_catalog/3/official` |
| Kimi-K3 | primary | UD-Q4_K_XL | MXFP4；Q8_0；F32 | `/profile_catalog/3/primary_gguf` |
| Kimi-K3 | fidelity | UD-Q8_K_XL | MXFP4；BF16；F32 | `/profile_catalog/3/fidelity_gguf` |
| GLM-5.3 | official | official-fp8 | FP8 E4M3 block128；BF16；F32 | `/profile_catalog/6/official` |
| GLM-5.3 | primary | UD-Q4_K_XL | Q4_K；Q5_K；Q6_K；Q8_0；F32 | `/profile_catalog/6/primary_gguf` |
| GLM-5.3 | fidelity | Q8_0 | Q8_0；F32 | `/profile_catalog/6/fidelity_gguf` |
| GLM-5.3-Flash | official | official-fp8 | FP8 E4M3 block128；BF16；F32 | `/profile_catalog/7/official` |
| GLM-5.3-Flash | primary | UD-Q4_K_XL | Q4_K；Q5_K；Q6_K；Q8_0；F32 | `/profile_catalog/7/primary_gguf` |
| GLM-5.3-Flash | fidelity | Q8_0 | Q8_0；F32 | `/profile_catalog/7/fidelity_gguf` |
| DeepSeek-V4-Pro-0813 | official | official-fp4-fp8-dspark | packed FP4 expert；FP8 E4M3；UE8M0 scale；BF16；F32；I64 | `/current_scope/added_releases/0/official` |
| DeepSeek-V4-Pro-0813 | primary | UD-Q4_K_XL | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/0/primary_gguf` |
| DeepSeek-V4-Pro-0813 | fidelity | UD-Q8_K_XL | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/0/fidelity_gguf` |
| DeepSeek-V4-Flash-0731 | official | official-fp4-fp8-dspark | packed FP4 expert；FP8 E4M3；UE8M0 scale；BF16；F32；I64 | `/current_scope/added_releases/1/official` |
| DeepSeek-V4-Flash-0731 | primary | UD-Q4_K_XL | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/1/primary_gguf` |
| DeepSeek-V4-Flash-0731 | fidelity | UD-Q8_K_XL | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/1/fidelity_gguf` |

Variant 名称不表示所有权重采用同一精度。例如 Kimi 的 `UD-Q4_K_XL` 目录仍记录 MXFP4/Q8_0/F32；`IQ3`、`IQ4` 仍是宽泛名称，不能补写成已确定 codec。Qwen3.5-2B 两个 GGUF profile 明确排除 R13（MTP）。官方、GGUF、历史人工量化样例不能互相替代。

Pro GA GGUF 固定为 [Unsloth Pro-0813][pro-gguf] `6d053616d152293da72569f56b861466f10ace7d`，两种 variant 各20分片；Flash GA GGUF 固定为 [Unsloth Flash-0731][flash-gguf] `fbbb5b93fb787c21338159b0af3318bb3f4d9768`，各5分片。[Flash GGUF DSpark 说明][flash-dspark]将其列为独立 optional add-on；不能把主 profile 自动解释成启用 DSpark，也不额外增加上述24个主 profile。发布者关于 MXFP4 passthrough、Q8_0/BF16 转换的声明仍须与实际选定文件的 tensor header 对照。

## 正式版 DeepSeek：角色、存储与数值边界

[Pro-0813][pro-card] 与 [Flash-0731][flash-card]均明确替代 preview 并附带 DSpark。官方固定 revision 分别为 `72e1d3230f6c080a530b0a1d46f8eb4602340597`、`7872f01b1d1fe23eabc4c98b48bffcef5a386062`。两份 config 的 `quant_method=fp8` 与仓库 FP8 标签都**不表示全 FP8**：`expert_dtype=fp4` 仍在。

下表的存储与计算分开记录：checkpoint 身份、转换后载体、参考实现 parameter dtype 不是同一件事。FP4/FP8 kernel 的 F32 累加由固定源码声明；`F.linear` / `einsum` 的物理执行算法与设备精度仍由具体后端核定。来源为两份固定 [Pro config][pro-config] / [Flash config][flash-config]、[Pro inference][pro-source] / [Flash inference][flash-source]及相同 revision 的 `inference/kernel.py`、`inference/convert.py`。

| 权重角色 / 子图 | Pro-0813 / Flash-0731 形状与模型参数 | 存储 / 转换 | Activation → accumulate → output；待核边界 |
| --- | --- | --- | --- |
| Embedding / LM head | vocab129280；hidden7168 / 4096 | checkpoint BF16；LM head 在参考程序持有 F32 parameter | embedding Gather→BF16；head 以 F32 operands 计算→F32 logits；完整词表不得用缩小 head 代替 |
| Q low-rank、Q/KV、输出 `wo_b`、shared expert 线性 | Q rank1536 / 1024；attention heads128 / 64，D512；输出 groups16 / 8、rank1024；FFN intermediate3072 / 2048 | 默认 E4M3FN `[N,K]`，128×128 UE8M0 scales；BF16/F32 例外逐角色处理 | BF16→动态 E4M3 group128；absmax floor1e-4、向上 power2 scale；FP8 GEMM F32累加→BF16 |
| `wo_a` 输出中间投影 | Pro / Flash 按各自 groups 与 output rank | checkpoint FP8 block128；官方 convert 解码并改为 BF16；参考层明确 BF16 | BF16 grouped `einsum("bsgd,grd->bsgr",...)`→BF16；不得把冷转换遗漏后直接套默认 FP8，也不把其物理累加算法写成已验证 |
| Routed expert gate/up/down | E384 / 256，Top6；`w1/w3: N3072,K7168 / N2048,K4096`，`w2` 方向相反 | packed E2M1 FP4 `[N,K/2]`，I8 容器；UE8M0 scales `[N,K/32]` | BF16→动态 FP8 group128→F32 kernel累加→BF16；gate/up转F32并按10裁剪、SiLU乘法，route weight 在 down 前施加；不能换成 Kimi 的 group32 activation 合同 |
| Router / hash table | E384 / 256、Top6、scale2.5 / 1.5；首3层 hash | BF16 router weight转F32计算；F32 selection bias；checkpoint API 有 I64，参考 `tid2eid` 为 I32 | F32 logits→sqrt(softplus)；普通层按带 bias 分数选 ID、无 bias 分数归一化；hash 按 token table 原序选 ID；GA `Gate.forward` 的归一化没有 `+1e-20` |
| mHC / norms / attention sink | HC4、Sinkhorn20、eps1e-6；每层 attention/FFN 与输出 head 分开 | HC fn/base/scale、norm weights、sink 为 F32 parameter；不能把整个 checkpoint 标成 F32 | F32 norm/projection/coefficients→HC pre/post；残差与返回的 BF16 边界必须保留；GLM Flash 仍共享 HC 数学需求 |
| CSA/HCA compressor 与缓存 | SWA128；ratio4（重叠）/128；Pro主干31×128+30×4，Flash主干20×128+21×4+2×0；两者另有3个 ratio0 DSpark stages | F32 compressor 计算/增量 KV 与 score state，随后 norm/转换；checkpoint各角色 dtype 与参考F32 parameter需区别 | BF16 hidden→F32 gated pooling/state→BF16；普通 NoPE KV 有 FP8/group64 simulation；ratio4 index compressor另走 Hadamard/FP4-QAT；GLM K4 pooling 不等同此合同 |
| Index projection / score / TopK | H64/D128；Pro Top1024，Flash Top512；causal 压缩候选 | `wq_b` 默认FP8；`weights_proj` BF16；参考 index cache 是 BF16 QAT 值 | RoPE→Hadamard→FP4/group32 QAT；BF16 dot/ReLU/weighted product/head sum边界后选TopK；Hyle物理68B行与paged metadata是接入载体，不是官方checkpoint格式 |
| DSpark `mtp.*` 新角色 | 3 stages；block_size5；Pro target layers58/59/60、Markov rank512；Flash40/41/42、rank256；noise token128799 | stage0 `main_proj/main_norm`；末stage Markov embedding/head、confidence projection与HC head；各角色按正式源 dtype核对 | target hidden拼接/投影→draft block/Markov logits→confidence；另核draft/verify、接受前缀、KV/state生命周期，不能承接旧单层MTP结论 |

Pro 的 `inference/kernel.py` 与旧 `b596…` 字节相同；两份 GA 的 Linear、Gate、Expert、MoE、Indexer、Compressor 主体及 HC pre/post 与各自 preview 保持相同计算。这证明需求仍在，不证明 Hyle 原有实现与 GA 精确等价。两份顶层 config 仍写 `num_nextn_predict_layers=1`，但固定 `inference/config.json` 写 `n_mtp_layers=3`，源码构造三个 `DSparkBlock`；总表保留这项来源差异，不能只取旧字段作结论。固定源码、元数据与差异对照见[本轮来源包](../evidence/research/deepseek-v4-ga-2026-10-19.zip)，其中没有权重payload。

特别需要对照：现有 `SqrtSoftplusHashRouting`/SGLang 接线包含 `sum+1e-20`，而 GA `Gate.forward` 没有该 epsilon；`LightningIndexer` 的 F32/F16-mask 接口也不能直接等同参考 indexer 的 BF16逐步舍入。保留这些实现的同时，需要核实极小分数、零和、tie、bounds、输出转换与实际 region 接线。

## 扩展量化制品

[量化制品明细](model-quantizations.json)另保存首批33条来源记录，覆盖八个目标模型，包含固定revision、
base-model声明、codec/packing/activation域、配置证据和未知项。除原UD-Q4/UD-Q8外，已发现AWQ产生的
compressed-tensors INT4、GPTQ、FP8、NVFP4/MXFP4、BNB NF4和MLX混合位宽等实际制品。
其中部分配置尚未完整读取，源模型commit通常也未由发布者锁定；这些是需求发现，不是后端支持结论，
也未穷尽HF的主流制品。Unsloth目录已发现的其他GGUF变体同样保留为需求，不把文件名当逐tensor格式。
[原始metadata与配置](../evidence/research/model-quantization-discovery-2026-10-19.zip)不含权重payload。

## 模型到计算与融合子图

公共项包括布局/物化/转换、embedding/head、norm/逐点/残差、线性/FFN与状态资源复用（D：R01–R03、R15）；量化另查 R14。R 编号只是区域索引，不表示所有 dtype、role 或 fusion 已接入。

| 模型 | 主要计算与待核融合子图 | D / C 索引 |
| --- | --- | --- |
| Qwen3.5-2B / Qwen3.8-27B | Q/K/V→norm/RoPE→GQA→output gate→projection；causal conv→gate/decay→GDN→state；dense FFN；按profile核MTP | R04/R05/R13；F03.4、F04.3/4、F07–F10、F14.3 |
| Qwen3.8-2.4T-A95B | 上述attention/GDN；router→TopK→dispatch→grouped/shared experts→combine；MTP | R04/R05/R10/R11/R13；F07–F10、F12.1/2、F13.1/2、F14.3 |
| Kimi-K3 | KDA三路conv→gate/decay→recurrent；MLA；latent expert→SiTU/再量化→combine；AttnRes | R06/R07/R10–R12/R14；F09、F11–F13、F14.2、F15、F18.3 |
| GLM-5.3 | MLA/YaRN；index projection→score/TopK→sparse gather/attention；跨层选择复用；MoE；MTP index carry | R07–R11/R13/R14；F08.2、F12/13、F14.5、F15、F16.1/2、F18.1/5 |
| GLM-5.3-Flash | KDA/MLA；pooled index+未池化tail；跨层选择复用；MoE；mHC；MTP | R06–R14相应分支；F11–F16、F18.1/5 |
| Pro-0813 / Flash-0731 GA | MLA/CSA/HCA；H64 index；hash / sqrt-softplus router；mHC；FP4 expert+FP8 activation；DSpark | 对照R07–R14、旧F08/F12–F18；DSpark另列新合同 |

## 当前融合与量化接线缺口

以下是2026-10-19首批审查及后续修复，主看Qwen3.5/3.8 dense与MoE FFN，依据现有制品配置、Hyle admission/lowering和[锁定依赖](../../cmake/HyleDependencyLock.json)中的原生实现；未穷尽模型、格式、阶段或设备。表内区分已运行的修复与源码发现；制品发布、普通算子接通和物理融合分别核定。普通 `Unary SiLU→Multiply` 与 `GatedActivation` 是不同数值合同，不能互换来制造融合命中。

| 模型 / 格式域 | 已核源码事实 | 最小下一步 |
| --- | --- | --- |
| Qwen dense；F32/F16/BF16普通SiLU | [真实FFN](../../tools/qwen35_text/main.cc#L181)发普通SiLU再乘法。F32/BF16现已接稳定lowering及SiLU→Mul融合变体，保留[stable-tail、`-Inf→+0`](../../third_party/sglang_activation/activation.cuh#L96)与BF16 SiLU输出RNE；双槽换址、公开中间值和非连续节点集回归已通过。F16仍未准入该ggml变体，保留原Provider后备 | 补F16等价变体；完整gate/up投影融合仍需保留另外两次投影输出舍入，不能将这两个逐点节点的融合称为完整FFN |
| Qwen dense；F16/BF16投影→GatedActivation | 原生gate/up向量融合要求F32 activation/output；Hyle [MatMul输出转换](../../src/compute_provider_ggml_cuda/tensor_program.cc#L239)及[BF16 gate输入扩宽](../../src/compute_provider_ggml_cuda/tensor_program.cc#L659)保留公开舍入边界 | 需要显式保留gate/up舍入的融合变体；普通SiLU recipe还须保留SiLU舍入。不能只删Cast或放宽matcher |
| Q24 plain/BF16与GGUF K/IQ/Q8/MXFP4专家 | [plain GroupedMatMul](../../src/compute_provider_ggml_cuda/tensor_program.cc#L772)各自生成activation/ID reshape及结果view，切断原生MMID→GLU的直接边与指针一致要求；量化多token也可能被[展平](../../src/compute_provider_ggml_cuda/tensor_program.cc#L211)切断，但单token不一定 | 共享同值metadata view并保留原生rank3拓扑；保留重复ID、checked failure与公开中间值合同；按batch/硬件单独核原生融合资格 |
| Qwen官方block128 FP8；另有CT channel/token FP8 | [Float8BlockLinear](../../src/compute_provider_cuda/fp8_provider.cc#L44)仅接精确E4M3/F32 block128的独立量化+GEMM；gate/up各自量化。它不证明CT channel/token scale域或整段FFN可接 | 同一输入及group/floor/scale rounding合同下先共享本次调用的量化结果；CT域另绑精确合同；量化复用不写成两个GEMM物理融合 |
| Q24官方grouped FP8，Top10 | [锁定源码](../../third_party/sglang_activation/fp8/grouped/original_kernels.py#L327)有interleaved W13的`FUSE_SWIGLU`分支，但[四个AOT job](../../third_party/sglang_activation/fp8/grouped/compilation.json#L61)均关闭；[provider](../../src/compute_provider_cuda/grouped_fp8_provider.cc#L53)固定Top8，实际[fixture](../../tests/compute_models/d5_qwen38_24t_fixture.h#L31)为Top10 | 先补真实Top10的checked align/GEMM特化，再核该分支的fast-math、BF16边界与GatedActivation合同；合格后接W13准备和region matcher，不套普通稳定SiLU |
| Q35/Q27 AWQ命名制品、GPTQ、CT INT4 | [ArtifactWeightDecode](../../include/hyle/compute/model_ops.h#L229)仅有NF4、legacy AWQ GEMM4和CT symmetric4冷decode；不是packed W4A16 FFN。GPTQ与CT asymmetric合同未接，[Marlin组件](../../src/compute_provider_marlin/CMakeLists.txt#L1)当前缺席；新AWQ命名制品可能实际为CT packing | 按制品核codes/scales/zero points、g_idx/permutation、group和输出舍入；已有冷decode继续缓存。成熟packed实现只能接其已证格式，不能按“4bit/AWQ”同名复用 |
| Qwen HF MXFP4/NVFP4与GGUF FP4 | 原生ggml有NVFP4/MXFP4，而Hyle [GGUF身份](../../include/hyle/compute/low_precision.h#L36)及[mapping](../../src/compute_provider_ggml_cuda/tensor_program.cc#L28)仅接MXFP4；HF Quark W4A4、ModelOpt static与CT local-dynamic activation不是同一合同，也不等同DeepSeek固定FP4组合 | 先核所选GGUF逐role header再补NVFP4身份；HF格式分别接scale/activation量化和成熟kernel，之后审gate/up融合，不把W4A4改成另一activation精度 |
| Q35/Q27 MLX affine4/affine8 | affine4已有[Apple quantized_matmul/gather_qmm](../../src/compute_route_apple/apple_tensor.cc#L569)与[CUDA packed dot](../../src/compute_provider_torch_cuda/mlx_packed_kernel.cu#L26)，仅证明decode+dot；[descriptor](../../include/hyle/compute/model_ops.h#L270)无affine8，MXFP8不能代替affine8 | 先核实际word/scale/bias与activation dtype，补显式affine位宽合同；再核gate/up packing或epilogue，不将现有packed dot称整段FFN融合 |

F32 activation/output配合已接plain/GGUF权重，已有原生gate/up→GLU向量融合候选；它不含down projection/residual，也不覆盖任意prefill GEMM。[现有GGUF fixture](../../tests/graph_route_cuda/d5_qwen35_gguf_fragment_test.cc#L158)发布gate/up等全部中间值，[lowering会保护这些输出](../../src/compute_provider_ggml_cuda/ggml_cuda_provider.cc#L544)，因此不能用该case证明中间值已消除。物理命中须另用同数学、仅发布所需末端结果的case核定，保留诊断case与真实输出合同。

投影底座已补ggml CUDA rank2/batched矩阵末两轴transpose-dense RHS，并修正fast NVIDIA双BF16输入/F32累加被意外扩成整份F32输入的问题。能力准入与默认优先级分开：早先无条件扩大普通region造成49个投影改路由，因完整prefill退化而[撤回该默认选择](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#投影接线与输入累加精度)；现在冷发现读取实际叶提案，普通region不吞已知更优叶，真实融合独立提案。rank2能力已开放，默认及GGML400/cuBLAS300同分反例均保留cuBLAS投影；定向回归通过。当前Qwen FFN仍走独立投影，不构成完整融合或跨平台覆盖声明。

真实Qwen的decode每步已物理命中24个BF16 FFN及18个F32 SSM SiLU→Mul融合，kernel1794→1752；prefill只物理命中24处，另18个F32候选仍有接线缺口。64份向量与旧路径相同，但三对完整step对照尚未证明提速；[实测与未完成项](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#稳定-silu-融合与普通区域的冷偏好)分别记录，不以逻辑候选命中代替物理覆盖。

## 64 条历史需求的反向索引

以下恰好逐行覆盖 C 的64个ID。`Q35/Q27/Q24/K/G/GF` 对应上文六模型；“六模型”即这六者。六模型列是 C 的 `models` 去重求交，保留其历史指向；它不是对当前所选每个量化profile的实际tensor存在声明。尤其旧 Q4-S128、Q4-A64、Q8-B32、人工FP8样例，不自动成为24个profile的格式身份。

GA列依据当前固定源码补反向需要；F14.4旧单层MTP与DSpark分开。精确分支不相同或来源尚不足时直接写待核，不由family范围推导独占或删除。ID链接中的 `/requirements/N` 是 C 的 JSON pointer，不引入旧 route status。

| C ID / pointer | 具体数值、形状或子图边界 | 六模型历史指向 | GA Pro / Flash 现行反向关系 |
| --- | --- | --- | --- |
| [F01.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/0) | View/stride/alias、边界与空tail | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F01.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/1) | Copy/Concat；显式连续物化 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F01.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/2) | Cast与索引转换；IEEE舍入边界 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/3) | Embedding/轴向Gather、重复及越界ID | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/4) | Scatter赋值/加法；重复目的地与F32端口 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/5) | causal/ragged/全mask；动态offset | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/6) | 计数、exclusive scan、稳定dispatch逆映射 | Q24、K、G、GF | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/7) | 逐点/残差/广播及strided tail | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/8) | 稳定exp/log/silu/softplus/sqrt/Clamp | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/9) | gate/up→SwiGLU→down；保留转换 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/10) | Qwen head-interleaved sigmoid output gate | Q35、Q27、Q24 | —；按六模型对应分支保留 |
| [F04.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/11) | RMSNorm末轴F32归约、eps/gamma | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F04.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/12) | LayerNorm mean/variance、gamma/beta | 六模型 | 未见GA独立LayerNorm需求；公共能力保留，不由历史全模型映射补算子 |
| [F04.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/13) | L2归一化epsilon在sqrt内 | Q35、Q27、Q24、K、GF | —；按六模型对应分支保留 |
| [F04.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/14) | norm→gamma/输出舍入→swish gate | Q35、Q27、Q24、K、GF | —；按六模型对应分支保留 |
| [F04.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/15) | Reduce/Softmax的F32归约与全mask | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F04.6](tasks/compute/llm-moe-coverage-matrix.json#/requirements/16) | TopK真实k/tie/NaN与ID顺序 | Q24、K、G、GF | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/17) | M=1/17/128、真实N/K、累加类型 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/18) | batched/broadcast QK/PV及leading strides | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/19) | checkpoint转置/slice、GEMV尾部 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/20) | gate/up→activation→down→residual、活中间值 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F06.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/21) | 历史本地132张量signed Q4/group128 | Q35（历史本地派生） | 不是GA官方格式；不得把历史派生样例冒作GA/GGUF |
| [F06.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/22) | unsigned affine Q4/group64、scale+bias | 六模型（历史载体，选定profile归属待核） | 不是GA官方格式；GA GGUF逐role codec待header核 |
| [F06.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/23) | 历史本地Q8/block32 W8A16，无A8替代 | Q35（历史本地派生） | 不是GA官方格式；GA GGUF逐role codec待header核 |
| [F07.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/24) | Qwen真实GQA/MQA ratio、head256 | Q35、Q27、Q24 | —；GA使用自身D512/MLA/CSA，不套Qwen head256合同 |
| [F07.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/25) | KV append/read、page ID、valid length | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F07.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/26) | 完整Qwen gated attention及旧state | Q35、Q27、Q24 | —；GA attention链另按sink/HC/compression核 |
| [F08.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/27) | Qwen partial/interleaved RoPE与非零offset | Q35、Q27、Q24 | —；GA RoPE/YaRN按F08.2与正式源 |
| [F08.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/28) | YaRN/NoPE、原context与参数 | G、GF | 需；GA YaRN/rope参数及NoPE转换按两份config |
| [F08.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/29) | normalized Hadamard、符号/layout及1/sqrt(D) | — | 需；GA index Hadamard仍在；通用Hadamard不删 |
| [F09.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/30) | causal depthwise conv K4、真实QKV宽 | Q35、Q27、Q24、K、GF | —；此行为Qwen/KDA卷积合同 |
| [F09.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/31) | causal conv update、非零history/reset | Q35、Q27、Q24、K、GF | —；此行为Qwen/KDA卷积合同 |
| [F10.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/32) | scalar-decay GDN chunk、真实K/V比与state | Q35、Q27、Q24、K、GF | —；K/GF在C的宽指向不表示其KDA等同scalar GDN |
| [F10.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/33) | scalar-decay GDN recurrent、state布局 | Q35、Q27、Q24、K、GF | —；K/GF的实际KDA另查F11 |
| [F11.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/34) | KDA逐channel decay/chunk、GLM下界-5 | K、GF | —；K/GF需求保留 |
| [F11.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/35) | KDA recurrent、tail/reset/双state | K、GF | —；K/GF需求保留 |
| [F12.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/36) | 按模型score函数；bias仅用于selection | Q24、K、G、GF | 需；E384/256、Top6、sqrtsoftplus、bias只选ID；保留router并核数值 |
| [F12.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/37) | 真实E/TopK/group、原分数归一化 | Q24、K、G、GF | 需；scale2.5/1.5；GA无epsilon的归一化/tie需精确对照 |
| [F12.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/38) | 早期hash层token table→原序expert IDs | — | 需；首3层hash；I64 checkpoint/I32参考表；不能以score TopK替代 |
| [F13.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/39) | dispatch稳定映射、空expert、grouped GEMM | Q24、K、G、GF | 需；E384/256与Top6；各expert dtype另核 |
| [F13.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/40) | 路由加权/共享expert、重复目的地累加 | Q24、K、G、GF | 需；GA route weight在down前；F32 sum→BF16边界单列 |
| [F13.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/41) | Kimi latent3584/expert3072、SiTU softcaps | K | —；不能把Kimi latent/SiTU当GA FFN |
| [F14.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/42) | mHC4、Sinkhorn20、F32系数及pre/post/head | GF | 需；GA HC4/Sinkhorn20，与GF共享数学但逐dtype核 |
| [F14.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/43) | Kimi block12 AttnRes、prior blockstate | K | —；Kimi AttnRes独立合同保留 |
| [F14.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/44) | Qwen MTP norm/concat/full attention | Q35、Q27、Q24 | —；Qwen MTP按各profile，不能转签DSpark |
| [F14.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/45) | 旧DeepSeek单nextn层e/h投影与HC head | — | 待DSpark对照：旧单层MTPBlock已替换；不继承旧合同，也非可删公共能力 |
| [F14.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/46) | GLM MTP BF16角色与跨层index carry | G、GF | —；GLM index carry不等同DSpark target hidden |
| [F15.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/47) | MLA low-rank/absorbed投影、NoPE/RoPE/V宽 | K、G、GF | 需；GA q-rank1536/1024、D512与output组投影，按各角色核 |
| [F15.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/48) | 模型各自gated MLA/NoPE分支 | K、G、GF | GA自身sink/HC边界另核；不继承Kimi gate或GLM NoPE分支 |
| [F16.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/49) | learned index score→TopK→sparse attention | G、GF | 需；GA H64/D128、Top1024/512、BF16逐步舍入；GLM是H32合同 |
| [F16.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/50) | GLM跨层index选择复用/versioned state | G、GF | —；DSpark取target hidden不能据此宣称同一index carry |
| [F16.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/51) | GLM Flash pool4、learned gate与unpooled tail | GF | —；GA ratio4 overlap不是GLM pooled/tail合同 |
| [F17.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/52) | CSA/HCA learned KV/gate、ratio4/128 | — | 需；GA learned compressor仍在，ratio4/128；GGUF角色另核 |
| [F17.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/53) | SWA128、ratio4 overlap及causal压缩位置 | — | 需；SWA128与重叠窗口/causal位置保留 |
| [F17.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/54) | compression增量state、ratio±1边界/reset | — | 需；prefill/chunk/decode state与边界；不以旧回执签GA |
| [F18.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/55) | E4M3FN weight128x128/A128、F32 scales | Q35、G、GF | GA官方是UE8M0分支，非本行F32-scale身份；GLM及旧派生另核 |
| [F18.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/56) | FP8 UE8M0 power2、group/饱和/舍入 | — | 需；GA dense/shared FP8与UE8M0，不表示全FP8模型 |
| [F18.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/57) | Kimi W4A8：weight32/A32 UE8M0、SiTU再量化 | K | —；Kimi A32数值域保留，不以GA A128替代 |
| [F18.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/58) | DeepSeek E2M1 weight32、dynamic FP8 A128 | — | 需；两GA官方仍FP4/A128；GroupedFP4保留，GGUF不能按名称套格式 |
| [F18.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/59) | 按源区分KV/index codec、FP4 QAT与score | G、GF | 需；GA FP4-QAT index仍在；物理68B Hyle载体/GLM codec分开 |
| [F19.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/60) | 冷shape/参数绑定、动态position/valid length | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/61) | state端口/读写范围、独立slot与旧结果 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/62) | immutable weights、packing/cache/workspace复用 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/63) | Direct/Graph交付、OOM/accepted-failure/close | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |

DSpark 新合同不塞入旧64行：三个stage的main-hidden抽取/concat、draft attention与Markov/confidence角色、proposal/verify/accepted-prefix状态及可选GGUF sidecar需要另补精确行；顶层nextn字段与实际inference构造差异也保留。64行中标“需”只是现行需求存在，不是完整精度覆盖、实际kernel融合或端到端收益声明。

## 25 个 custom descriptor 与实际反向关系

下表逐项对应当前 [model_ops.h](../../include/hyle/compute/model_ops.h) 的25个描述符。源码链接定位入口；fixture链接说明已有消费者，GA源码链接说明计算需求。旧fixture仍使用旧profile身份时只作为recipe证据，必须迁移身份/逐角色合同后才可能提供GA执行证据。公共能力和固定模型组合分别判断，不能因为测试是消费者就永久保留一个废弃专用组合，也不能因移除preview就删除GA仍需的数学。

| Descriptor / 源码入口 | 现行需求、已有消费者或接线证据 | 保留边界 / 尚待核实 |
| --- | --- | --- |
| [`GatherElements`](../../include/hyle/compute/model_ops.h#L19) | [generic MoE routing](../../tests/compute_models/d5_moe_execution_fragments.h)：Q24/K/G/GF；GA selection也需逐元素Gather | 通用axis/bounds能力保留，实际GA ID与stride合同另核 |
| [`RowCacheEncode`](../../include/hyle/compute/model_ops.h#L64) | [row-cache状态消费者](../../tests/compute_state/row_cache_consumer.cc)与typed batch缓存；GA量化index有逻辑需求 | 通用row-inline codec保留；不能将Hyle物理行格式称官方checkpoint |
| [`RowCacheGatherDecode`](../../include/hyle/compute/model_ops.h#L94) | [row-cache Graph fixture](../../tests/compute_models/row_cache_graph_fixture.h)与状态消费者 | 通用typed gather/decode保留；选定profile的codec另绑 |
| [`RowCacheGatherDecodePadded`](../../include/hyle/compute/model_ops.h#L134) | [typed paged reader](../../include/hyle/graph/batch.h)：padding/空history语义 | 通用-1 padding、mask与页权限保留，不随专用scorer一起删 |
| [`RowCacheIndexerScores`](../../include/hyle/compute/model_ops.h#L169) | GA两版H64/D128、FP4-QAT score数学仍在；现有[scorer fixture](../../tests/compute_models/row_cache_indexer_fixture.h)是post-QAT合成边界 | 保留H64承载，GA接线/逐步BF16舍入待核；不是GLM H32通用indexer，也非已验证GA consumer |
| [`CacheEncode`](../../include/hyle/compute/model_ops.h#L213) | [公开cache codec](../../include/hyle/compute/model_ops.h#L205)面向追加的新行与native GGUF cache | 通用codec保留；GA cache实际codec不能由同名推断 |
| [`ArtifactWeightDecode`](../../include/hyle/compute/model_ops.h#L244) | [非GGUF载体fixture](../../tests/compute_models/cpu_c5_non_gguf_fixture.h)；NF4/compressed-tensors精确格式 | 保留独立通用artifact能力；24个profile的逐role使用与未使用仍需反查 |
| [`MlxQuantized`](../../include/hyle/compute/model_ops.h#L280) | [MLX packed fixture](../../tests/compute_models/cpu_c5_non_gguf_fixture.h)：affine/MXFP独立载体 | 保留通用MLX能力；不能将人工MLX样例签为所选GGUF/官方profile |
| [`BlockQuantizationRoundtrip`](../../include/hyle/compute/model_ops.h#L322) | [GA同族量化recipe](../../tests/compute_models/d5_deepseek_official_fragments.h)与正式源FP8/FP4 QAT | GA域仍需而保留；roundtrip不能替代完整量化MatMul证明 |
| [`Float8WeightDecode`](../../include/hyle/compute/model_ops.h#L359) | [GLM absorbed权重准备](../../tests/compute_models/d5_glm_remaining_fragments.h#L327)实际调用；GA wo_a也有冷转换 | 共享GLM能力保留；GA UE8M0→接入scale载体与BF16转换须精确核 |
| [`Float8BlockLinear`](../../include/hyle/compute/model_ops.h#L395) | [动态FP8线性fixture](../../tests/compute_models/d5_dynamic_fp8_fragments.h)：GLM；GA非expert线性仍需FP8 | 保留；F32-scale carrier、UE8M0值与floor/power2合同分别核 |
| [`GroupedFloat8Linear`](../../include/hyle/compute/model_ops.h#L442) | [GLM grouped FP8 fixture](../../tests/compute_models/d5_grouped_fp8_fragments.h) | GLM域保留；不能把可选FP4→FP8转换当GA原始expert格式 |
| [`GroupedFloat4Linear`](../../include/hyle/compute/model_ops.h#L490) | 两GA仍是FP4 weight32/FP8 A128；[旧同族recipe](../../tests/compute_models/d5_deepseek_official_fragments.h)与[CUDA固定N/K](../../src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc) | 保留GA组合；不等同Kimi A32；旧fixture身份和GA tensor角色仍须迁移 |
| [`Clamp`](../../include/hyle/compute/model_ops.h#L531) | GLM learned index ReLU、GA gate/up clip10；[MoE fixture](../../tests/compute_models/d5_moe_execution_fragments.h) | 通用min/max/clamp能力保留，Infinity/NaN规则按端口核 |
| [`SqrtSoftplusRouting`](../../include/hyle/compute/model_ops.h#L566) | 两GA E384/256、Top6、scale2.5/1.5仍需；[routing recipe](../../tests/compute_models/d5_moe_execution_fragments.h) | 保留固定组合；bias只选ID、unbiased normalize、tie与零和需对照GA，不写已支持 |
| [`SqrtSoftplusHashRouting`](../../include/hyle/compute/model_ops.h#L612) | 两GA首3层token-table hash；[SGLang接线](../../src/compute_provider_cuda/router_provider.cc) | 保留且需修核：当前sum+1e-20与GA无epsilon不同；表序/重复ID/bounds也属合同 |
| [`SinkAttention`](../../include/hyle/compute/model_ops.h#L655) | GA learned sink/sparse attention；[状态消费者](../../tests/compute_state/deepseek_sparse_prefix_consumer.cc) | 保留；BF16逐节点转换、mask/sink分母和稀疏位置另核 |
| [`CausalConv1d`](../../include/hyle/compute/model_ops.h#L706) | Q35/Q27/Q24 GDN、K/GF KDA；[真实Qwen消费者](../../tools/qwen35_text/main.cc) | 共享通用conv/history能力保留；GA无需conv不构成删除理由 |
| [`RecurrentGatedDeltaNet`](../../include/hyle/compute/model_ops.h#L763) | Qwen scalar-decay GDN；[GDN recipe](../../tests/compute_models/d5_qwen38_24t_semantic_fragments.h) | 保留；Kimi/GLM KDA的channel decay是另外合同，不能由宽family映射等同 |
| [`GroupedMatMul`](../../include/hyle/compute/model_ops.h#L817) | Q24/K/G/GF routed专家、GA分组投影；[Q24完整router](../../tests/compute_models/d5_qwen38_24t_full_router.h) | 通用stored-bank/ID能力保留；格式、A=1/S、累加/输出逐role核 |
| [`HyperConnectionCombine`](../../include/hyle/compute/model_ops.h#L863) | [GLM Flash](../../tests/compute_models/d5_glm_remaining_fragments.h#L211)实际接入[共享HC core](../../tests/compute_models/d5_moe_semantic_fragments.h#L331)；GA也需HC4/Sinkhorn20 | 共享GF与GA，保留；F32/BF16边界与epsilon不能被同名消除 |
| [`HyperConnectionPre`](../../include/hyle/compute/model_ops.h#L904) | GLM Flash共享core与GA HC collapse；输出head也有对应数学 | 共享能力保留，旧单层MTP与DSpark角色分开 |
| [`HyperConnectionPost`](../../include/hyle/compute/model_ops.h#L939) | GLM Flash共享core与GA HC expansion/residual | 共享能力保留；combination方向、残差与转换边界逐profile核 |
| [`LightningIndexer`](../../include/hyle/compute/model_ops.h#L988) | GA仍需H64/D128 learned score；现有[稀疏fixture](../../tests/sparse_fragment_test_support.h)仅合成F32/F16-mask端口 | 保留该承载并核GA BF16舍入/接线；模型fixture未直接调用，不能把GLM H32或合成测试称GA支持 |
| [`BFloatLinearF32`](../../include/hyle/compute/model_ops.h#L1039) | [Q24 BF16 router near-tie](../../tests/compute_models/d5_qwen38_24t_full_router.h)及KDA投影；GA router也有F32 score需求 | 共享能力保留；BF16权重/F32分数合同不等同普通BF16 MatMul输出 |

派生关系也必须保留在反向核对中：[detail::RowCachePagedIndexerScores](../../src/compute_batch/row_cache_map.h#L67) 与 [Graph PagedRowCacheIndexer](../../include/hyle/graph/batch.h#L81)依赖上述H64 scorer，另有页权限/metadata/empty-history合同；它们不增加25个公开descriptor的计数。不能只删schema而漏掉CUDA/Apple/Vulkan/CPU接线，也不能顺带删除generic row-cache map/gather/decode与typed paging能力。

[Hadamard](../../include/hyle/compute/operation.h#L390)是普通公开operation，不在25个custom描述符内；两GA仍需normalized Hadamard。带 `deepseek` 名称的[CUDA FP8 provider](../../src/compute_provider_cuda/deepseek_fp8_provider.cc)还承载GLM使用的decode与独立roundtrip能力；ggml `dsv4_hc_*` 也被GLM Flash使用。因此不能按路径/符号前缀或旧preview标签批量删除第三方依赖。

## 继续细化与融合审查边界

下一轮按每个选定profile的真实tensor角色补齐精确codec、block/group/axis、codes/scales/bias、pack/stride/orientation、activation量化、饱和/舍入、累加与输出。GA GGUF主header、DSpark可选sidecar及各backend原生域分别记录；全profile汇总formats不能代替逐role身份。

每条实际recipe需连到Hyle admission/lowering、原生standalone/region入口和依赖版本，并区分prefill/chunk/decode、真实M/N/K、ragged/tail、KV/state有效范围、动态参数及设备容量。核对Cast、公开中间值、外部reader、alias/state顺序与融合被切断的位置；packing/cache、workspace所有者、rebind/replay/capture、completion/失败不发布和旧结果寿命同时保留。源码可达、实际kernel执行、数值一致、融合命中与端到端收益各自有证据后再分别陈述；本表没有完成这些运行审查。

本轮没有确认可仅因撤销preview而删除上述router、GroupedFP4、HC、压缩或indexer实现。F14.4旧MTPBlock的变更应由DSpark角色对照解决；公共数学与仍有现行需求的载体继续保留。历史catalog、provider map、ledger及状态只提供来源，不签署当前支持。

[pro-card]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/README.md
[flash-card]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/README.md
[pro-config]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/config.json
[flash-config]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/config.json
[pro-source]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/inference/model.py
[flash-source]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/inference/model.py
[pro-gguf]: https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF/tree/6d053616d152293da72569f56b861466f10ace7d
[flash-gguf]: https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/tree/fbbb5b93fb787c21338159b0af3318bb3f4d9768
[flash-dspark]: https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/blob/fbbb5b93fb787c21338159b0af3318bb3f4d9768/dspark/README.md

