"""Bounded host recompilation, cached closures and explicit directed runs."""
from pathlib import Path
import argparse
import importlib.util
import json
import statistics
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
ROOT = OUT.parents[2]
PRIOR = ARCH / 'cuda-dense-projection/delivered'
OLD = ARCH / 'cuda-capture-reuse/validation'
spec = importlib.util.spec_from_file_location('stable_validation_helpers', ARCH / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
sys.modules['build'] = b
spec = importlib.util.spec_from_file_location('stable_model_runs', ARCH / 'cuda-bf16-chain-fusion/run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
HOST = {
    'tensor': (ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc', PRIOR / 'tensor-identity.json'),
    'tensor-test': (ROOT / 'tests/compute_provider_ggml_cuda/tensor_test.cc', PRIOR / 'tensor-test-identity.json'),
    'graph': (ROOT / 'src/graph/executable.cc', OLD / 'graph--executable-v2-identity.json'),
    'region': (ROOT / 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc', ARCH / 'cuda-coarse-capture-tests/graph_provider_ggml_cuda--ggml_cuda_region-final-identity.json'),
    'cpu-region': (ROOT / 'src/graph_route_cpu/ggml_region.cc', ARCH / 'cuda-coarse-capture-tests/graph_route_cpu--ggml_region-identity.json'),
    'onednn-region': (ROOT / 'src/graph_provider_onednn/onednn_region_provider.cc', ARCH / 'retire-native-runtime/paging-risks/onednn-region-identity.json'),
    'control-test': (ROOT / 'tests/graph/region_provider_test.cc', OLD / 'region-control-test-v2-identity.json'),
    'stable-test': (ROOT / 'tests/graph_route_cuda/stable_silu_test.cc', ARCH / 'cuda-dense-projection/route-test-identity.json'),
    'projection-test': (ROOT / 'tests/graph_provider_ggml_cuda/dense_projection_test.cc', PRIOR / 'projection-test-identity.json'),
}


def compile_host(tag):
    source, template = HOST[tag]
    original = b.read(template)
    if 'command' not in original:
        original = b.read(template.with_name(template.name.replace('-identity.json', '-compile.command.json')))
    command, skip = [], False
    for arg in original['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
        elif arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith('.cc'):
            continue
        else:
            command.append(arg)
    command += ['/sourceDependencies', str(OUT / (tag + '-deps.json')), str(source),
                '/Fo' + str(OUT / (tag + '.obj')), '/Fd' + str(OUT / (tag + '.pdb'))]
    frozen = b.ident(source)
    b.execute(tag + '-compile' + args.suffix, command)
    assert frozen == b.ident(source), 'Source changed during compilation'
    b.save(tag + '-identity.json', dict(source=frozen, object=b.ident(OUT / (tag + '.obj')), command=command))


def link(name):
    if name == 'cpu-tests':
        command = b.read(OLD / 'cpu-link-plan.json')['command']
    else:
        template = 'fusion-tests' if name == 'cuda-tests' else 'candidate'
        command = b.read(PRIOR / (template + '-link-plan.json'))['command']
    replacements = {
        str(OLD / 'graph--executable-v2.obj'): str(OUT / 'graph.obj'),
        str(ARCH / 'cuda-coarse-capture-tests/graph_provider_ggml_cuda--ggml_cuda_region-final.obj'): str(OUT / 'region.obj'),
        str(ARCH / 'cuda-coarse-capture-tests/graph_route_cpu--ggml_region.obj'): str(OUT / 'cpu-region.obj'),
        str(OLD / 'region-control-test-v2.obj'): str(OUT / 'control-test.obj'),
        str(ARCH / 'retire-native-runtime/paging-risks/onednn-region.obj'): str(OUT / 'onednn-region.obj'),
        str(PRIOR / 'tensor.obj'): str(OUT / 'tensor.obj'),
        str(PRIOR / 'tensor-test.obj'): str(OUT / 'tensor-test.obj'),
        str(PRIOR / 'projection-test.obj'): str(OUT / 'projection-test.obj'),
        str(ARCH / 'cuda-dense-projection/native-bf16-acc/ggml-cuda.obj'): str(OUT / 'ggml-cuda.obj'),
        str(ARCH / 'cuda-bfloat-elementwise-build/unary.obj'): str(OUT / 'unary.obj'),
    }
    if name != 'baseline':
        command = [replacements.get(arg, arg) for arg in command]
    if name == 'cuda-tests':
        command.append(str(OUT / 'stable-test.obj'))
    if name == 'cpu-tests' and str(OUT / 'onednn-region.obj') not in command:
        command.append(str(OUT / 'onednn-region.obj'))
    command = [arg for arg in command if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(OUT / (name + '.exe')), '/MAP:' + str(OUT / (name + '.map')),
                '/IMPLIB:' + str(OUT / (name + '.lib'))]
    inputs = [b.ident(arg) for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
    b.save(name + '-link-plan.json', dict(command=command, inputs=inputs, SDK_rebuild=False, object_copy=False))
    b.execute(name + '-link' + args.suffix, command)
    b.save(name + '-image.json', dict(image=b.ident(OUT / (name + '.exe')),
                                     link_plan=b.ident(OUT / (name + '-link-plan.json'))))


def tests(name):
    assert args.filter
    r.image(name)
    tag = name + args.suffix
    b.execute(tag, [OUT / (name + '.exe'), '--gtest_color=no', '--gtest_filter=' + args.filter,
        '--gtest_output=xml:' + str(OUT / (tag + '.xml'))])
    xml = ET.parse(OUT / (tag + '.xml')).getroot()
    cases = xml.findall('.//testcase')
    assert cases and not xml.findall('.//failure') and not xml.findall('.//skipped')
    if not any(mark in args.filter for mark in '*?-'):
        assert len(cases) == len(args.filter.split(':'))
    b.save(tag + '-summary.json', dict(count=len(cases), failures=0, skipped=0,
        cases=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases]))


def performance():
    proof = b.read(OUT / 'correctness-preferred-gate.json')
    assert proof['vectors']['equal_files'] == proof['vectors']['files'] == 64
    expected = b.read(OUT / 'correctness-baseline-metrics.json')['ids']
    order = ('baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate')
    b.save('performance-plan.json', dict(order=list(order), prompt=128, fixed_decode=31,
        full_step=True, profiler=False, memory_monitor=False, SDK_rebuild=False))
    runs = []
    for index, arm in enumerate(order, 1):
        row = r.trial(f'perf-{index:02d}-{arm}', arm)
        assert row['ids'] == expected
        runs.append(row)
        b.save('performance-results.json', dict(runs=runs, remaining=len(order)-len(runs)))
    keys = ('prefill_tokens_per_second', 'full31_tokens_per_second', 'warm7_31_tokens_per_second')
    groups = {arm: {key: dict(samples=[row[key] for row in runs if row['arm'] == arm],
        median=statistics.median(row[key] for row in runs if row['arm'] == arm)) for key in keys}
        for arm in ('baseline', 'candidate')}
    ratios = {key: groups['candidate'][key]['median']/groups['baseline'][key]['median'] for key in keys}
    b.save('performance-summary.json', dict(groups=groups, ratios=ratios,
        ids_equal=True, statistical_significance=False, quality_acceptance=False))
    print(json.dumps(dict(groups=groups, ratios=ratios)), flush=True)


parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['compile', 'link', 'tests', 'qwen', 'performance'])
parser.add_argument('names', nargs='*')
parser.add_argument('--filter')
parser.add_argument('--suffix', default='')
args = parser.parse_args()
if args.mode == 'performance':
    performance()
    raise SystemExit(0)
assert args.names
for name in args.names:
    if args.mode == 'compile':
        compile_host(name)
    elif args.mode == 'link':
        link(name)
    elif args.mode == 'tests':
        tests(name)
    else:
        assert name in ('baseline', 'candidate')
        r.trial('correctness-' + name + args.suffix, name, trace=True)
