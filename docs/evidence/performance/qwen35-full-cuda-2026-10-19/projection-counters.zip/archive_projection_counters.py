"""Validate three existing one-node CSV exports and archive without GPU/tool calls."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
ROOT = STAGE.parents[2]
OUT = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/projection-counters.zip'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def number(text):
    value = float(text.replace(',', ''))
    return int(value) if value.is_integer() else value


def main():
    metrics = ['gpu__time_duration.sum', 'dram__bytes_read.sum', 'dram__bytes_write.sum',
        'dram__throughput.avg.pct_of_peak_sustained_elapsed', 'lts__t_sectors_op_read.sum',
        'lts__t_sector_hit_rate.pct', 'lts__throughput.avg.pct_of_peak_sustained_elapsed',
        'l1tex__t_sectors_pipe_lsu_mem_local_op_ld.sum',
        'l1tex__t_sectors_pipe_lsu_mem_local_op_st.sum',
        'l1tex__t_sectors_pipe_lsu_mem_global_op_st.sum',
        'launch__registers_per_thread', 'launch__stack_size', 'profiler__replayer_passes',
        'profiler__replayer_bytes_mem_accessible.max', 'profiler__replayer_bytes_mem_backed_up.max']
    rows = []
    specs = [
        ('hyle', 'single-node-export.stdout.log', 'single-node-profile-a2.result.json', 'ffn-dual-decode7.ncu-rep', 5),
        ('peer', 'peer-node-export.stdout.log', 'peer-node-profile-a1.result.json', 'peer-ffn-decode7.ncu-rep', 5),
        ('hyle_store_probe', 'hyle-store-export.stdout.log', 'hyle-store-profile-a1.result.json', 'hyle-store-counter-decode7.ncu-rep', 3)]
    for arm, filename, result, report, passes in specs:
        with (HERE / filename).open(newline='', encoding='utf-8-sig') as stream:
            records = list(csv.DictReader(stream))
        units = next(row for row in records if not row['ID'])
        actual = [row for row in records if row['ID']]
        if len(actual) != 1:
            raise ValueError('Expected one result: ' + arm)
        row = actual[0]
        if row['Grid Size'] != '(6144, 1, 1)' or row['Block Size'] != '(256, 1, 1)':
            raise ValueError('Expected target geometry: ' + arm)
        if ('hyle_bf16_dual_matvec_silu_epilogue' in row['Kernel Name']) != (arm != 'peer'):
            raise ValueError('Expected target epilogue identity: ' + arm)
        if number(row['profiler__replayer_passes']) != passes or read(HERE / result)['exit'] != 0:
            raise ValueError('Pass count/process completion differs: ' + arm)
        rows.append(dict(arm=arm, results=1, profile_process_exit=0, natural_exit=True,
            kernel=row['Kernel Name'], grid=row['Grid Size'], block=row['Block Size'],
            metrics={key: dict(value=number(row[key]), unit=units[key]) for key in metrics if key in row and row[key]},
            CSV=identity(HERE / filename), report=identity(HERE / report)))
    expected = {'hyle': (50827648,7368832,124672), 'peer': (51900544,5305984,120928)}
    for row in rows[:2]:
        observed = tuple(row['metrics'][key]['value'] for key in ('dram__bytes_read.sum','dram__bytes_write.sum','gpu__time_duration.sum'))
        if observed != expected[row['arm']]:
            raise ValueError('Independent joined metrics differ')
    probe = rows[2]['metrics']
    if [probe[key]['value'] for key in (
        'l1tex__t_sectors_pipe_lsu_mem_local_op_ld.sum',
        'l1tex__t_sectors_pipe_lsu_mem_local_op_st.sum',
        'l1tex__t_sectors_pipe_lsu_mem_global_op_st.sum',
        'dram__bytes_write.sum','gpu__time_duration.sum')] != [0,0,6144,2980096,112192]:
        raise ValueError('Memory-space probe differs')
    joined = dict(validated=True, scope='One decode7 layer0 dual FFN node per existing profile, RTX4070/AD104, NCU2026.2.1; no new GPU run/query during joining.',
        target_logical_weight_bytes=50331648, profiles=rows,
        precision='Both load BF16 matrices. Hyle A/output are BF16 with original BF16 RNE epilogue; peer A/output F32. Same geometry and logical weight role do not establish identical numerical work.',
        interpretation=[
            'Both instrumented primary invocations show high DRAM utilization and about51MB reads. These are total measured DRAM bytes, not weight-only traffic proof.',
            'The separate Hyle memory-space probe observes zero local load/store sectors, so no local-memory spill/stack traffic is observed for this invocation. This is not a universal no-spill proof.',
            '6144 global-store sector requests for6144 CTAs are consistent with the reviewed source one BF16 store perCTA,12KB useful output. Sectors count requests, not unique output bytes.',
            'DRAMwrite changes from7,368,832B to2,980,096B between different Hyle metric/pass runs. Together with zero local sectors and source stores, these observations do not support an extra Hyle intermediate tensor. They do not identify dirty-L2 eviction, background engine traffic or replay perturbation as the measured cause.'
        ], limitations=[
            'Kernel replay used5/5/3passes, not application replay. cache-controlnone retains natural cache policy but repeated node replay/backup/instrumentation can perturb it; pass counts differ for the memory-space probe.',
            'The primary Hyle report backs up/accesses up to3,896,008,547B perpass. This is replay context, not this kernel useful output size.',
            'L2/DRAM are shared with other engines; the local NCU guide cannot isolate all DRAM traffic to SM stores. No exact dirty-writeback counter was collected.',
            'One profile percarrier is diagnostic. No stable kernel speed comparison, whole-engine gain, quality equivalence, or recommendation to change mathematical precision is claimed.'
        ], throughput_claim=False, stable_kernel_speed_claim=False, whole_engine_gain_claim=False,
        first_attempt='single-node-profile.result.json exited1 before target launch because the wrapper TEMP directory did not exist; root created it and the explicit a2retry succeeded. Original first failure logs retained.')
    save(HERE / 'projection-counters-joined.json', joined)
    exclusions = {'ad104-requested-metrics.txt','ad104-selected-suffixes.txt','current-device-base-query.txt',
        'profile-metrics-expanded.txt','live.json','archive-projection-receipt.json','archive-projection-payload.json'}
    files = [path for path in HERE.iterdir() if path.is_file() and path.name not in exclusions
             and path.suffix in ('.json','.py','.txt','.log','.ncu-rep')]
    for name in ('projection-profile-plan.json','projection-readonly-review.json'):
        if (STAGE / name).is_file():
            files.append(STAGE / name)
    payload = [dict(member=path.name, bytes=path.stat().st_size,
                    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted(files)]
    if len({row['member'] for row in payload}) != len(payload):
        raise ValueError('Nonunique archive members')
    save(HERE / 'archive-projection-payload.json', dict(files=payload,
        excluded='80MB all-metricDB, duplicate broad metric lists, SDK/images/objects/maps and other-backend evidence.'))
    files.append(HERE / 'archive-projection-payload.json')
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.exists():
        raise ValueError('Archive already exists; do not silently replace frozen evidence')
    with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(files):
            archive.write(path,path.name)
    with zipfile.ZipFile(OUT) as archive:
        if archive.testzip() is not None:
            raise ValueError('CRC failure')
        for row in payload:
            data=archive.read(row['member'])
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('Payload identity failure')
        count=len(archive.infolist())
    receipt=dict(archive=identity(OUT),entries=count,CRC_verified=True,payload_SHA256_verified=len(payload),
                 joined=identity(HERE/'projection-counters-joined.json'),new_GPU_runs=0,new_counter_queries=0)
    save(HERE/'archive-projection-receipt.json',receipt)
    save(OUT.with_suffix('.zip.receipt.json'),receipt)
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':
    main()
