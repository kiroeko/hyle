"""Collect only the prepared single warm FFN node, without changing clocks."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('projection_profile_helpers', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan = c.read(STAGE / 'projection-profile-plan.json')
assert b.same(plan['image'])
out = STAGE / 'ncu-preparation'
(out / 'tmp').mkdir(exist_ok=True)
assert not (out / 'ffn-dual-decode7.ncu-rep').exists()
current = c.read(Path(c.read(STAGE / 'latest-check.json')['plan']))['links']['qwen']
env, libraries = b.environment(current['command'], current['inputs'], out)
c.save(out / 'profile-inputs.json', dict(plan=b.identity(STAGE / 'projection-profile-plan.json'),
    runner=b.identity(Path(__file__)), image=plan['image'], runtime_directories=libraries,
    counter_results_requested=1, throughput_claim=False))
attempt = 1 + len(list(out.glob('single-node-profile*.result.json')))
tag = 'single-node-profile-a' + str(attempt)
try:
    result = c.execute(tag, plan['command'], env, out)
except Exception as error:
    c.save(out / 'profile-summary.json', dict(collected=False, passed=False, error=str(error), attempt=tag))
    raise
text = (out / (tag + '.stdout.log')).read_text(encoding='utf-8', errors='replace')
text += (out / (tag + '.stderr.log')).read_text(encoding='utf-8', errors='replace')
report = out / 'ffn-dual-decode7.ncu-rep'
if 'ERR_NVGPUCTRPERM' in text or 'No kernels were profiled' in text or not report.exists():
    c.save(out / 'profile-summary.json', dict(passed=False, exit=result['exit'],
        error='No successful counter report; check original logs', report_exists=report.exists()))
    raise SystemExit(2)
c.execute('single-node-export', plan['export_command'], env, out)
c.save(out / 'profile-summary.json', dict(collected=True, process=result, report=b.identity(report),
    CSV='single-node-export.stdout.log', counter_results_requested=1,
    validated=False, throughput_claim=False))
print('COLLECTED_SINGLE_NODE_REQUIRES_RESULT_VALIDATION', report, flush=True)
