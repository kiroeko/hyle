from pathlib import Path
import importlib.util,json,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capture_build',STAGE/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
b,c=build.b,build.c
path=Path(c.read(STAGE/'latest-check.json')['plan']);plan=c.read(path)
out=path.parent/'run-cpu';out.mkdir();(out/'tmp').mkdir()
env,_=b.environment(plan['links']['cpu']['command'],plan['links']['cpu']['inputs'],out)
command=[plan['links']['cpu']['image'],'--gtest_filter='+':'.join(plan['exact_tests']),
    '--gtest_output=xml:'+str(out/'cpu.xml')]
try:c.execute('cpu',command,env,out)
finally:
    if (out/'cpu.xml').exists():
        cases=list(ET.parse(out/'cpu.xml').getroot().iter('testcase'))
        names=[x.get('classname')+'.'+x.get('name') for x in cases]
        counts=dict(tests=len(cases),failures=sum(x.find('failure') is not None for x in cases),
            errors=sum(x.find('error') is not None for x in cases),skipped=sum(x.find('skipped') is not None for x in cases))
        passed=set(names)==set(plan['exact_tests']) and not any(counts[x] for x in ['failures','errors','skipped'])
        c.save(out/'summary.json',dict(passed=passed,counts=counts,observed=names,image=b.identity(plan['links']['cpu']['image'])))
        print('TESTS',counts,'exact',passed,flush=True)
        if not passed:raise SystemExit(2)
