"""Package this Graph batch; retained equal vector payloads remain in place."""
import hashlib,json,pathlib,re,xml.etree.ElementTree as ET,zipfile
STAGE=pathlib.Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cold-capture-topology.zip'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(data): return hashlib.sha256(data).hexdigest()
def identity(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def save(name,value): (STAGE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def check(row):
    p=pathlib.Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'],str(p)
checkdir=STAGE/'checks/20261019T142405'
assert read(checkdir/'summary.json')['passed']
cpu=read(checkdir/'run-cpu/summary.json')
assert cpu['passed'] and cpu['counts']==dict(tests=12,failures=0,errors=0,skipped=0)
xml=ET.parse(checkdir/'run-cpu/cpu.xml').getroot()
assert int(xml.attrib['tests'])==12 and not xml.findall('.//failure') and not xml.findall('.//skipped')
correctness=read(STAGE/'correctness/summary.json');obs=correctness['observation']
assert correctness['passed'] and obs['equal_vectors']==64 and obs['same_greedy_ids_as_reference']
assert len(obs['generated_ids'])==32 and obs['capture_32_phases_with_7_ranges']
assert all(v['byte_equal'] and v['actual']['sha256']==v['reference']['sha256'] for v in obs['vectors'])
perf=read(STAGE/'performance-rotation/summary.json')
assert perf['terminal_zero']==9 and perf['same_baseline_predictions_all9']
for row in read(STAGE/'source-freeze.json')['files']:
    check(dict(row['before'],path=str(STAGE/'before'/row['source'])));check(row['after'])
    assert identity(ROOT/row['source'])['sha256']==row['after']['sha256']

# Preserve the exact repository headers seen by these ten actual compilations.
# SDK/compiler/cache dependency rows remain recorded references, never copied.
dependency_rows=[]
for owner in read(checkdir/'source-dependencies.json'):
    check(owner['source']);check(owner['object'])
    for row in owner['dependencies']:
        p=pathlib.Path(row['path'])
        try: rel=p.relative_to(ROOT)
        except ValueError: continue
        if rel.parts[0] not in ('include','src','tests'): continue
        check(row)
        target=STAGE/'source'/rel
        if target.exists(): assert sha(target.read_bytes())==row['sha256']
        else: target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
        dependency_rows.append(dict(**row,archive_path='source/'+rel.as_posix()))
save('archive-dependency-sources.json',list({r['path']:r for r in dependency_rows}.values()))

# Small import helpers are restored to their original repository-relative paths.
pending=[STAGE/'build.py',STAGE/'run_model.py',STAGE/'compare.py'];seen=set();support=[]
while pending:
    p=pending.pop().resolve()
    if p in seen: continue
    seen.add(p);code=p.read_text(encoding='utf-8')
    for expr,base in [(r"ARCH\s*/\s*['\"]([^'\"]+\.py)['\"]",ARCH),
                      (r"STAGE\s*/\s*['\"]([^'\"]+\.py)['\"]",p.parent)]:
        pending.extend(base/m for m in re.findall(expr,code))
    if not p.is_relative_to(STAGE): support.append(p)
support.extend([ARCH/'immutable-alias-index/host-recipes.json',
    ARCH/'mlx-affine-widths/common/checks/current/cpu-link-plan.json',
    ARCH/'mlx-affine-widths/cuda/checks/20261019T135721/qwen-link-plan.json',
    ARCH/'mlx-affine-widths/cuda/checks/20261019T135721/qwen-image.json',
    ARCH/'decode-latest-comparison/prepared/plan.json',
    ROOT/'docs/evidence/correctness/mlx-affine-widths-cuda-2026-10-19-archive.json'])
support_rows=[]
for p in dict.fromkeys(support):
    data=p.read_bytes();rel=p.relative_to(ROOT);target=STAGE/'support'/rel
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    support_rows.append(dict(**identity(p),archive_path='support/'+rel.as_posix()))
save('archive-support.json',support_rows)
for name in ['docs/architecture/compute-design.md','docs/developer/current-work.md',
             'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']:
    target=STAGE/'context'/name;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((ROOT/name).read_bytes())
save('archive-summary.json',dict(host_TUs=10,native_TUs=0,SDK_build=False,CPU_tests=12,
    equal_vectors=64,equal_greedy_ids=32,capture_ranges=7,unprofiled_processes=9,
    current_over_baseline=perf['current_over_baseline'],current_over_llama=perf['current_over_llama'],
    stable_speedup_proven=False,quality_acceptance=False,
    vector_payloads='Equal retained raw vectors are omitted. correctness/summary.json records all old/current paths, bytes and SHA256; prior CUDA archive receipt is included. No referenced raw vectors are deleted.',
    dependencies='Actual repository source/header snapshots and compile sourceDependencies are included; SDKs, object files, models and images remain identity/recipe references.',
    cleanup='No deletion or test.ps1 modification is performed by this script.'))
excluded={'.exe','.obj','.o','.lib','.a','.exp','.map','.pdb','.dll','.pyc','.tmp','.bf16','.f32','.f16','.bin'}
files=[p for p in STAGE.rglob('*') if p.is_file() and p.suffix.lower() not in excluded
       and p.name!='archive-receipt.json' and not {'tmp','__pycache__'}.intersection(p.relative_to(STAGE).parts)]
hashes={p.relative_to(STAGE).as_posix():sha(p.read_bytes()) for p in files}
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in sorted(files): archive.write(p,p.relative_to(STAGE).as_posix())
    archive.writestr('payload-sha256.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for name,digest in hashes.items(): assert sha(archive.read(name))==digest,name
save('archive-receipt.json',dict(**identity(DEST),payloads=len(hashes),crc_verified=True,
    payload_sha256_verified=True,CPU_tests=12,equal_vectors=64,equal_greedy_ids=32,
    unprofiled_processes=9,raw_duplicate_vectors_omitted=True))
print(json.dumps(read(STAGE/'archive-receipt.json'),indent=2))
