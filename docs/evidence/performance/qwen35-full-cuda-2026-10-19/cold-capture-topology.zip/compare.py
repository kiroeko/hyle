"""Fresh matched rotation after immutable capture topology moves to Plan."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
spec = importlib.util.spec_from_file_location('cold_topology_rotation', ARCH / 'batch-layout-query-reuse/compare_three.py')
rotation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rotation)
b, c, r = rotation.b, rotation.c, rotation.r
rotation.STAGE = STAGE
r.PREPARED = STAGE / 'performance-prepared'


def runtime_environment(build, peer, out):
    inputs = build['links']['qwen']['inputs'] + peer['inputs']
    paths = [row['path'] if isinstance(row, dict) else row for row in inputs]
    env, runtime = b.environment(build['links']['qwen']['command'], paths, out)
    for key in r.FORBIDDEN_ENV:
        if key in env:
            raise ValueError('Unexpected experiment environment: ' + key)
    return env, runtime


r.runtime_environment = runtime_environment


def prepare(build_path):
    build = c.read(build_path)
    assert c.read(build_path.parent / 'summary.json')['passed']
    assert c.read(STAGE / 'correctness/summary.json')['passed']
    retained = c.read(ARCH / 'decode-latest-comparison/prepared/plan.json')
    images = dict(baseline=c.read(ARCH / 'mlx-affine-widths/cuda/checks/20261019T135721/qwen-image.json'),
        current=c.read(build_path.parent / 'qwen-image.json'), llama=retained['images']['llama'])
    for row in list(images.values()) + retained['peer_inputs']:
        r.require_same(row)
    frozen = [row for row in retained['frozen'] if row['path'] != retained['build_plan']['path']]
    for row in frozen:
        r.require_same(row)
    frozen += [b.identity(Path(__file__)), b.identity(build_path),
               b.identity(STAGE / 'source-freeze.json'), b.identity(STAGE / 'correctness/summary.json')]
    plan = {key: retained[key] for key in ('schema_version', 'status', 'fixed', 'source_id',
        'expected_baseline_ids', 'order', 'metric_contract')}
    requests = []
    for request in retained['requests']:
        argv = request['command'].copy()
        argv[0] = images[request['arm']]['path']
        requests.append({**request, 'command': argv})
    plan.update(build_plan=b.identity(build_path), images=images, frozen=frozen,
        peer_inputs=retained['peer_inputs'], requests=requests, profiler=False,
        source_or_SDK_compilations_during_rotation=0, links_during_rotation=0,
        precision_limit='Same-source BF16 weights; Hyle/reference intermediate precision recipes remain different.')
    r.PREPARED.mkdir(exist_ok=False)
    c.save(r.PREPARED / 'plan.json', plan)
    print('PREPARED_NO_GPU', r.PREPARED / 'plan.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        rotation.run(r.PREPARED / 'plan.json', STAGE / 'performance-rotation')
    else:
        prepare(args.build_plan.resolve())
