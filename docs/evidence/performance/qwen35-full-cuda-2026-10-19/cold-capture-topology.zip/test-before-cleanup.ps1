param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/current-batch-reclaim'
$planPath = Join-Path $stage 'plan.json'
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
if ($plan.status -ne 'ready_after_model_and_archive_verification') {
    throw 'Final model regression and evidence are required before this cleanup.'
}
$receiptPath = Join-Path $workspace 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/current-batch-reclaim.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'This exact cleanup has already been recorded.' }

function Confirm-LocalFile($row) {
    $resolved = (Resolve-Path -LiteralPath $row.path).Path
    if (-not $resolved.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Target escapes workspace: $resolved"
    }
    $item = Get-Item -LiteralPath $resolved
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw "Only exact ordinary files may be reclaimed: $resolved"
    }
    $hash = (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($item.Length -ne $row.bytes -or $hash -ne $row.sha256) { throw "Identity changed: $resolved" }
    return $resolved
}
foreach ($row in $plan.archives) { $null = Confirm-LocalFile $row }
foreach ($row in $plan.proofs) { $null = Confirm-LocalFile $row }
foreach ($row in $plan.retained) { $null = Confirm-LocalFile $row }
$targets = @()
foreach ($row in $plan.local) {
    $resolved = Confirm-LocalFile $row
    if ([IO.Path]::GetExtension($resolved) -notin '.exe', '.map', '.lib', '.exp') { throw "Unexpected reclaim type: $resolved" }
    if ($resolved -in $plan.retained.path) { throw "Retained input selected: $resolved" }
    $targets += $resolved
}
if (($targets | Sort-Object -Unique).Count -ne $targets.Count) { throw 'Duplicate cleanup targets.' }
Write-Output "Verified exact Windows targets: $($targets.Count); bytes: $($plan.windows_bytes)"
Write-Output "Verified Apple manifest: $($plan.remote.targets.Count) exact files; bytes: $($plan.apple_bytes)"
if (-not $Execute) { Write-Output 'Dry run only. No deletion.'; return }

# The remote program receives fixed identities, performs its own containment
# and hash checks, and unlinks individual files only. No recursive deletion.
$remotePayload = $plan.remote | ConvertTo-Json -Depth 15 -Compress
$encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($remotePayload))
$remotePython = @'
from pathlib import Path
import base64, hashlib, json
p = json.loads(base64.b64decode('__REQUEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019').resolve(strict=True)
def check(row):
    path = Path(row['path'])
    actual = path.resolve(strict=True)
    if path.is_symlink() or not actual.is_relative_to(base) or not actual.is_file():
        raise ValueError('Unexpected cleanup/cache path: ' + str(path))
    if actual.stat().st_size != row['bytes'] or hashlib.sha256(actual.read_bytes()).hexdigest() != row['sha256']:
        raise ValueError('Changed identity: ' + str(path))
    return actual
targets = [check(row) for row in p['targets']]
cached = [check(row) for row in p['retained_build_cache']]
if len(set(targets)) != len(targets) or set(targets).intersection(cached):
    raise ValueError('Duplicate or retained target')
for path in targets:
    path.unlink()
for row in p['retained_build_cache']:
    check(row)
print(json.dumps(dict(remote=p['remote'], removed=p['targets'],
    files=len(targets), bytes=sum(x['bytes'] for x in p['targets']),
    retained_cache_files=len(cached), cache_hashes_preserved=True)))
'@
$remotePython = $remotePython.Replace('__REQUEST__', $encoded)
$remoteResult = $remotePython | & ssh $plan.remote.remote 'python3 -'
if ($LASTEXITCODE -ne 0) { throw 'Remote exact-file cleanup failed.' }
$remoteReceipt = $remoteResult | ConvertFrom-Json
foreach ($target in $targets) { Remove-Item -LiteralPath $target -Force }
foreach ($target in $targets) { if (Test-Path -LiteralPath $target) { throw "Removal incomplete: $target" } }
foreach ($row in $plan.retained) { $null = Confirm-LocalFile $row }
$receipt = [ordered]@{
    completed = $true; utc = [DateTime]::UtcNow.ToString('o'); script = 'test.ps1'
    plan = $planPath; windows_files = $targets.Count; windows_bytes = $plan.windows_bytes
    windows_removed = $plan.local; apple = $remoteReceipt; retained = $plan.retained
    objects_sources_recipes_and_shared_SDKs_preserved = $true
}
$receipt | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Reclaimed Windows $($plan.windows_bytes) bytes and Apple $($plan.apple_bytes) bytes."
Write-Output $receiptPath
