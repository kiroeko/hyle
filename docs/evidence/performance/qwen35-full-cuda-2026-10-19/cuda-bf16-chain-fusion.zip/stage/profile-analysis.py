"""Read official Nsight SQLite/CSV exports only; never launch a GPU process."""
from pathlib import Path
import collections
import csv
import json
import re
import sqlite3
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
PROFILE = STAGE / 'profile'
ARCH = STAGE.parent
sys.path.insert(0, str(STAGE))
import build as b


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def stats(values):
    values = list(values)
    return dict(min=min(values), median=statistics.median(values), max=max(values), samples=values)


def bf16_degree(name):
    if not ('k_bin_bcast' in name and ', __nv_bfloat16' in name):
        return None
    op = 'add' if '&op_add' in name else 'multiply' if '&op_mul' in name else 'other'
    # The demangled template list precedes the function argument list. Each
    # RHS pointer template argument is one original arithmetic/RNE node.
    degree = name.split('>(')[0].count('const __nv_bfloat16 *')
    assert degree >= 1, name
    return op, degree


def load(kind):
    path = PROFILE / (kind + '-trace.sqlite')
    con = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    tables = {row[0] for row in con.execute('select name from sqlite_master where type="table"')}
    diagnostics = [dict(row) for row in con.execute('select timestamp,severity,text from DIAGNOSTIC_EVENT')]
    save(PROFILE / (kind + '-diagnostics.json'), diagnostics)
    target_logs = {}
    for filename, content in con.execute(
            'select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
        if '/streams/' in filename:
            suffix = 'stderr' if 'stderr_' in filename else 'stdout'
            target = PROFILE / (kind + '-target-' + suffix + '.log')
            target.write_text(content, encoding='utf-8')
            target_logs[suffix] = b.ident(target)
    kernels = [dict(row) for row in con.execute(
        'select k.start,k.end,k.streamId,k.correlationId,k.graphId,k.graphNodeId,'
        's.value as name from CUPTI_ACTIVITY_KIND_KERNEL k '
        'join StringIds s on s.id=k.demangledName order by k.start')]
    copies = [dict(row) for row in con.execute(
        'select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start')]
    apis = []
    for table in ['CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_DRIVER']:
        if table in tables:
            apis += [dict(row) for row in con.execute(
                'select a.start,a.end,a.correlationId,a.returnValue,s.value as name from ' + table +
                ' a join StringIds s on s.id=a.nameId where s.value like "%GraphLaunch%" order by a.start')]
    launches = sorted(apis, key=lambda row: row['start'])
    assert all(row['returnValue'] == 0 for row in launches)
    # Official CSV and SQLite agree on physical kernel invocation counts.
    with (PROFILE / (kind + '-trace_cuda_gpu_kern_sum.csv')).open(encoding='utf-8-sig', newline='') as stream:
        official = list(csv.DictReader(stream))
    assert sum(int(row['Instances']) for row in official) == len(kernels)
    physical = collections.Counter(k['name'] for k in kernels)
    assert {row['Name']: int(row['Instances']) for row in official} == dict(physical)
    bf16 = []
    for name, count in sorted(physical.items()):
        parsed = bf16_degree(name)
        if parsed:
            op, degree = parsed
            bf16.append(dict(op=op, RHS_degree=degree, invocations=count,
                             fused=degree > 1, name=name))
    target_pid = int(next(re.search(r'Process (\d+) was launched', row['text']).group(1)
        for row in diagnostics if 'was launched by the profiler' in row['text']))
    con.close()
    return dict(kernels=kernels, copies=copies, graph_launches=launches, bf16=bf16,
        receipt=dict(sqlite=b.ident(path), official_csv=b.ident(PROFILE / (kind + '-trace_cuda_gpu_kern_sum.csv')),
            report=b.ident(PROFILE / (kind + '-trace.nsys-rep')), diagnostics=b.ident(PROFILE / (kind + '-diagnostics.json')),
            target_logs=target_logs, nsys_pid=b.read(STAGE / ('profile-' + kind + '.result.json'))['pid'],
            target_pid=target_pid,
            warnings=[row for row in diagnostics if row['severity'] >= 2],
            all_diagnostics_retained=True, physical_kernel_count=len(kernels),
            graph_launch_count=len(launches), csv_sqlite_physical_counts_identical=True))


def qwen_summary(data):
    kernels, copies, launches = [data[key] for key in ('kernels', 'copies', 'graph_launches')]
    endpoints = [row['end'] for row in copies if row['copyKind'] == 2 and row['bytes'] == 4]
    assert len(endpoints) == 32
    assert collections.Counter(row['bytes'] for row in copies if row['copyKind'] == 2) == {4: 32}
    original_path = ARCH / 'cuda-current-peer/profile/hyle-phases.json'
    old = b.read(original_path)['phases']
    phases, previous = [], -1
    for index, end in enumerate(endpoints):
        selected = [row for row in kernels if previous < row['start'] <= end]
        graph_calls = [row for row in launches if previous < row['start'] <= end]
        bf16 = [bf16_degree(row['name']) for row in selected if bf16_degree(row['name'])]
        counts = collections.Counter(bf16)
        row = dict(phase='prefill' if index == 0 else 'decode' + str(index),
            token_D2H_end_ns=end, previous_token_D2H_end_ns=None if previous < 0 else previous,
            kernel_count=len(selected), graph_node_kernel_count=sum(bool(k['graphNodeId']) for k in selected),
            graph_launch_count=len(graph_calls), BF16_add_count=sum(n for (op, degree), n in counts.items() if op == 'add'),
            BF16_multiply_count=sum(n for (op, degree), n in counts.items() if op == 'multiply'),
            BF16_multisource_fused_count=sum(n for (op, degree), n in counts.items() if degree > 1),
            previous_baseline_kernel_count=old[index]['kernel_count'],
            previous_baseline_graph_node_kernel_count=old[index]['graph_node_kernel_count'],
            previous_baseline_graph_launch_count=old[index]['graph_launch_count'])
        row['baseline_counts_equal'] = all(row[key] == old[index][key] for key in
            ('kernel_count', 'graph_node_kernel_count', 'graph_launch_count'))
        phases.append(row)
        previous = end
    assert sum(p['kernel_count'] for p in phases) == len(kernels)
    assert all(p['baseline_counts_equal'] for p in phases)
    assert all(p['BF16_multisource_fused_count'] == 0 for p in phases)
    warm = phases[7:]
    keys = ['kernel_count', 'graph_node_kernel_count', 'graph_launch_count', 'BF16_add_count',
            'BF16_multiply_count', 'BF16_multisource_fused_count']
    result = dict(**data['receipt'], method='32 final 4-byte token D2H endpoints; activity start bins, matching retained baseline method.',
        phases=phases, warm_decode7_31={key: stats(p[key] for p in warm) for key in keys},
        BF16_kernel_templates=data['bf16'],
        prior_baseline_phase_receipt=b.ident(original_path), all32_baseline_counts_equal=True,
        actual_BF16_multisource_fusion=False, physical_kernel_reduction_observed=0,
        conclusion='This real Qwen workload did not execute a multi-source BF16 Add/Mul template; no actual kernel-count reduction.',
        comparison_scope='Counts versus retained current-peer trace of the same 119-input original closure; no profiled timing speed comparison.')
    save(PROFILE / 'qwen-phases.json', result)
    return result


def chains_summary(data):
    kernels = data['kernels']
    assert len(kernels) == 72 and all(bf16_degree(k['name']) for k in kernels)
    assert not data['graph_launches']
    grouped = collections.Counter(bf16_degree(row['name']) for row in kernels)
    for op in ['add', 'multiply']:
        assert {degree: count for (operation, degree), count in grouped.items() if operation == op} == {
            1: 16, 2: 8, 3: 4, 7: 4, 8: 4}
    # Each configuration finishes both streams before the next synchronous
    # source-loop configuration starts. No NVTX case labels were injected.
    # Configuration labels below are inference from that fixed source order;
    # physical template degrees/counts are direct SQLite observations.
    configurations, offset = [], 0
    for depth in [2, 3, 8]:
        for publish in [False, True]:
            count = 16 if publish else 8
            selected = kernels[offset:offset + count]
            offset += count
            actual = collections.Counter(bf16_degree(k['name']) for k in selected)
            expected = collections.Counter()
            for op in ['add', 'multiply']:
                if publish:
                    expected[(op, 1)] += 4
                    expected[(op, depth - 1)] += 4
                else:
                    expected[(op, depth)] = 4
            assert actual == expected
            configurations.append(dict(chain_depth=depth, publish_first=publish,
                label_method='Inferred from fixed synchronous source-loop order; not NVTX-labelled.',
                first_kernel_start_ns=min(row['start'] for row in selected),
                last_kernel_end_ns=max(row['end'] for row in selected), physical_kernels=len(selected),
                templates=[dict(op=op, RHS_degree=degree, invocations=n)
                           for (op, degree), n in sorted(actual.items())]))
    assert offset == len(kernels)
    logical = sum(degree * count for (op, degree), count in grouped.items())
    assert logical == 208
    target = Path(data['receipt']['target_logs']['stdout']['path']).read_text(encoding='utf-8')
    assert '[  PASSED  ] 1 test.' in target
    result = dict(**data['receipt'], directed_case='GgmlCudaGraph.BfloatChainsPreserveEveryRoundingAndPublishedIntermediate',
        case_passed=True, BF16_kernel_templates=data['bf16'], inferred_configurations=configurations,
        logical_arithmetic_nodes=logical, kernels_saved_versus_one_per_node=136,
        physical_kernel_reduction_fraction=136 / 208, multisource_fused_invocations=40,
        source_degree_identity='Sum(template RHS_degree × physical invocation count) = 208 original Add/Mul nodes.',
        published_boundary='Published first node executes separately; remaining depths 1/2/7 match original depths 2/3/8.',
        execution_mode='Direct kernel launches in this test trace: zero cudaGraphLaunch calls.',
        conclusion='Actual GPU execution proves BF16 Add/Mul pack depths 2, 3 and 8, and published-first truncation to 1/2/7.',
        limitation='Synthetic directed-case fusion proof does not establish whole-Qwen optimization or a fair speedup.')
    save(PROFILE / 'chains-templates.json', result)
    return result


def inventory():
    artifacts = []
    for name in ['baseline', 'candidate', 'fusion-tests']:
        files = [STAGE / (name + suffix) for suffix in ['.exe', '.map', '.lib', '.exp']]
        artifacts.append(dict(image_name=name, files=[b.ident(path) for path in files if path.is_file()],
            image_receipt=b.ident(STAGE / (name + '-image.json')),
            link_plan=b.ident(STAGE / (name + '-link-plan.json')),
            map_owners=b.ident(STAGE / (name + '-map-owners.json'))))
    result = dict(scope='Exact files for this round images; inventory only, no copy/archive/deletion executed.',
        artifact_groups=artifacts,
        new_objects=[b.ident(STAGE / (name + '.obj')) for name in ['ggml-cuda', 'binbcast', 'tensor-test', 'region-test']],
        profile_artifacts=[b.ident(path) for path in sorted(PROFILE.iterdir()) if path.is_file()],
        object_reuse='All other cached inputs remain referred to in original link plans; none copied.',
        archive_executed=False, deletion_executed=False)
    save(STAGE / 'image-artifacts.json', result)
    return result


if __name__ == '__main__':
    qwen = qwen_summary(load('qwen'))
    chains = chains_summary(load('chains'))
    images = inventory()
    save(STAGE / 'profile-summary.json', dict(status='exactly_two_traces_terminal_zero_official_exports_analysed',
        source_freeze=b.ident(STAGE / 'source-freeze.json'), trace_count=2,
        qwen=qwen, chains=chains, image_inventory=b.ident(STAGE / 'image-artifacts.json'),
        additional_compilation=False, additional_benchmark_pairs=False, additional_tests=False, Ncu=False,
        profiler_timings_used_for_speedup=False, GPU_window_released=True,
        overall_conclusion='Directed synthetic chains execute exact-rounding fusion; real Qwen has no fused template hit, no kernel reduction, and no demonstrated performance improvement.'))
    print('Qwen: 32 phase counts match baseline; warm kernels1794/GraphLaunch7/BF16add84/mul102; fused0.')
    print('Chains: actual packs2/3/8 and published-first1/2/7; 72 kernels for208 original nodes; pass1.')
    print('Original diagnostics, SQLite/CSV, source traces and exact image inventory retained; no deletion.')
