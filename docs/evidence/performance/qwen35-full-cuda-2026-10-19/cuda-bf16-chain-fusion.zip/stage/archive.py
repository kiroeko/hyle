"""Archive this completed experiment once; never build, run a GPU, or delete.

The archive depends on the existing repository and dependency caches, whose
identities and exact command lines are retained. It is not an SDK/model bundle.
Use --plan for a read-only inventory and compressed-size estimate.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time
import zipfile
import zlib

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bf16-chain-fusion.zip'
RECEIPT = STAGE / 'archive-receipt.json'
CLEANUP = STAGE / 'cleanup-plan.json'
CASE = ARCH / 'qwen-gpu-comparison/128-prefill'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def same_identity(actual, expected):
    return actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256']


def frozen_rows():
    freeze = read(STAGE / 'source-freeze.json')
    rows = freeze['sources'] + freeze['product']
    require(len(rows) == 6, 'Expected exactly four frozen sources and two product manifests')
    for row in rows:
        require(same_identity(identity(row['path']), row), 'Frozen source/product drift: ' + row['path'])
    return rows


def inventory():
    payload = {}
    missing = []

    def add(path, arcname):
        path = Path(path).resolve()
        require(path.is_relative_to(ROOT), 'Payload escaped repository: ' + str(path))
        require(path.suffix.lower() not in {'.obj', '.exe', '.map', '.lib', '.exp', '.pdb', '.bf16', '.f32'},
                'Disallowed binary/vector payload: ' + str(path))
        require(arcname not in payload or payload[arcname] == path, 'Duplicate archive name: ' + arcname)
        if path.is_file():
            payload[arcname] = path
        else:
            missing.append(str(path))

    def stage(name):
        add(STAGE / name, 'stage/' + name)

    required = (
        'archive.py', 'build.py', 'run.py', 'profile.py', 'profile-analysis.py',
        'source-freeze.json', 'canonical-source-identities.json', 'canonical-candidate.diff',
        'implementation-notes.json', 'compile-recipes.json', 'build-inputs.json',
        'build-summary.json', 'preparation.json', 'test-run-plan.json',
        'directed-tests-summary.json', 'directed-tests.xml', 'correctness-summary.json',
        'performance-run-plan.json', 'performance-results.json', 'performance-summary.json',
        'validation-summary.json', 'profile-summary.json', 'image-artifacts.json',
    )
    for name in required:
        stage(name)
    for name in ('ggml-cuda', 'binbcast', 'region-test', 'tensor-test'):
        stage(name + '-identity.json')
    for name in ('baseline', 'candidate', 'fusion-tests'):
        stage(name + '-link-plan.json')
        stage(name + '-image.json')
        stage(name + '-map-owners.json')
    # Actual process invocations, terminal results and unedited raw output.
    for pattern in ('*.command.json', '*.result.json', '*.stdout.log', '*.stderr.log',
                    '*-inputs.json', '*-metrics.json'):
        for path in sorted(STAGE.glob(pattern)):
            stage(path.name)
    for name in ('binbcast.cu', 'ggml-cuda.cu'):
        stage('canonical-native-source/src/ggml-cuda/' + name)
    for kind in ('chains', 'qwen'):
        for suffix in ('.nsys-rep', '.sqlite', '_cuda_api_sum.csv', '_cuda_gpu_kern_sum.csv'):
            stage('profile/' + kind + '-trace' + suffix)
    # Only small offline analysis outputs, if the analyst placed them here.
    for pattern in ('*.json', '*.csv', '*.tsv', '*.txt', '*.log'):
        for path in sorted((STAGE / 'profile').glob(pattern)):
            stage('profile/' + path.name)
    for arm in ('baseline', 'candidate'):
        for path in sorted((STAGE / ('correctness-' + arm) / 'trace/routes').glob('*.tsv')):
            stage(path.relative_to(STAGE).as_posix())
    for row in frozen_rows():
        path = Path(row['path']).resolve()
        if not path.is_relative_to(STAGE):
            add(path, 'source/' + path.relative_to(ROOT).as_posix())
    add(ROOT / 'tests/compute_provider_ggml_cuda/bfloat_elementwise_test_support.h',
        'source/tests/compute_provider_ggml_cuda/bfloat_elementwise_test_support.h')
    # The reused harness and exact input tape are small; the model stays external.
    harness = ARCH / 'cuda-capture-reuse/qwen-consumer-identity.json'
    add(harness, 'reused-recipes/qwen-consumer-identity.json')
    source = read(harness)['source']
    require(same_identity(identity(source['path']), source), 'Reused Qwen harness source drift')
    path = Path(source['path']).resolve()
    add(path, 'source/' + path.relative_to(ROOT).as_posix())
    for name in ('fixed-inputs.json', 'decode.ids', 'inputs/prompt.ids', 'inputs/weights.tsv'):
        add(CASE / name, 'case/' + name)
    for name in ('docs/architecture/compute-design.md', 'docs/developer/current-work.md',
                 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
        add(ROOT / name, 'context/' + name)
    return dict(sorted(payload.items())), sorted(set(missing))


def validate_completed():
    tests = read(STAGE / 'directed-tests-summary.json')
    require(tests['count'] == 3 and tests['failures'] == tests['skipped'] == 0,
            'Three directed tests must finish successfully')
    parity = read(STAGE / 'correctness-summary.json')
    require(parity['equal_vectors'] == parity['total_vectors'] == len(parity['vectors']) == 64,
            'Expected 64 exactly equal vector pairs')
    for row in parity['vectors']:
        require(row['equal'] and row['baseline_sha256'] == row['candidate_sha256'],
                'Vector hash mismatch: ' + row['path'])
        # Keep all 128 raw files in place, without copying or rehashing them.
        for arm in ('baseline', 'candidate'):
            path = STAGE / ('correctness-' + arm) / 'trace' / row['path']
            require(path.is_file() and path.stat().st_size == row['bytes'],
                    'Missing/truncated retained raw vector: ' + str(path))
    perf = read(STAGE / 'performance-results.json')
    require(perf['remaining'] == 0 and len(perf['runs']) == 6, 'Three performance pairs must be complete')
    # The summary is written after both captures and all offline analyses finish.
    summary = read(STAGE / 'profile-summary.json')
    require(summary.get('status') == 'exactly_two_traces_terminal_zero_official_exports_analysed'
            and summary.get('trace_count') == 2, 'Final two-trace profile summary is not complete')
    profiles = sorted(STAGE.glob('profile-*.result.json'))
    require([p.name for p in profiles] == ['profile-chains.result.json', 'profile-qwen.result.json'],
            'Expected exactly two actual Nsight profile process results')
    for path in profiles:
        result = read(path)
        require(result['exit'] == 0 and result.get('terminal'), 'Profile process is not terminal zero: ' + path.name)
    for pattern in ('*.sqlite-wal', '*.sqlite-shm', '*.sqlite-journal'):
        require(not list((STAGE / 'profile').glob(pattern)), 'SQLite still has a live sidecar')


def cleanup_rows():
    targets = []
    for image in ('baseline', 'candidate', 'fusion-tests'):
        for suffix in ('.exe', '.map', '.lib', '.exp'):
            path = (STAGE / (image + suffix)).resolve()
            require(path.parent == STAGE and path.is_file(), 'Cleanup target is not an exact stage file')
            targets.append(identity(path))
    objects = [identity(STAGE / (name + '.obj'))
               for name in ('ggml-cuda', 'binbcast', 'region-test', 'tensor-test')]
    traces = [identity(STAGE / 'profile' / (kind + '-trace' + suffix))
              for kind in ('chains', 'qwen') for suffix in ('.nsys-rep', '.sqlite')]
    return targets, objects, traces


def plan(payload, missing):
    raw = compressed = 0
    for path in payload.values():
        encoder = zlib.compressobj(9, zlib.DEFLATED, -15)
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                raw += len(block)
                compressed += len(encoder.compress(block))
        compressed += len(encoder.flush())
    print(json.dumps(dict(payload_files=len(payload), uncompressed_bytes=raw,
        estimated_zip_bytes=compressed + len(payload) * 220 + 40000,
        missing_required=missing, output=str(DEST), writes=False), indent=2))


def archive(payload, missing):
    require(not missing, 'Required archive inputs missing: ' + ', '.join(missing))
    for path in (DEST, RECEIPT, CLEANUP):
        require(not path.exists(), 'One-shot archive output already exists: ' + str(path))
    validate_completed()
    freeze_before = identity(STAGE / 'source-freeze.json')
    frozen_rows()
    rows = [dict(archive_path=name, **identity(path)) for name, path in payload.items()]
    targets, objects, traces = cleanup_rows()
    manifest = dict(payloads=rows,
        scope='Current BF16-chain experiment; external caches/models remain referenced by identity.',
        vector_payloads=0, vector_pair_hash_manifest='stage/correctness-summary.json',
        context='context/ contains documentation snapshots, outside the frozen product identity.')
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')
    expected = {row['archive_path']: row for row in rows}
    expected['archive-manifest.json'] = dict(bytes=len(manifest_bytes),
        sha256=hashlib.sha256(manifest_bytes).hexdigest())
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive_file:
        for name, path in payload.items():
            archive_file.write(path, name)
        archive_file.writestr('archive-manifest.json', manifest_bytes)
    with zipfile.ZipFile(DEST) as archive_file:
        require(archive_file.testzip() is None, 'ZIP CRC verification failed')
        require(set(archive_file.namelist()) == set(expected), 'Archive entry set mismatch')
        for name, row in expected.items():
            digest = hashlib.sha256()
            count = 0
            with archive_file.open(name) as stream:
                for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                    count += len(block)
                    digest.update(block)
            require(count == row['bytes'] and digest.hexdigest() == row['sha256'],
                    'Archived payload SHA256 mismatch: ' + name)
    for row in rows:
        require(same_identity(identity(row['path']), row), 'Payload changed during archive: ' + row['path'])
    frozen_rows()
    require(same_identity(identity(STAGE / 'source-freeze.json'), freeze_before), 'Source freeze changed during archive')
    for row in targets + objects + traces:
        require(same_identity(identity(row['path']), row), 'Artifact changed during archive: ' + row['path'])
    output_identity = identity(DEST)
    receipt = dict(status='verified', archive=output_identity, payload_count=len(rows),
        payload_bytes=sum(row['bytes'] for row in rows), zip_entries=len(expected), zip_crc_verified=True,
        every_payload_sha256_verified=True, source_freeze=freeze_before, frozen_source_and_product_drift=0,
        payload_manifest='archive-manifest.json', payload_manifest_sha256=expected['archive-manifest.json']['sha256'],
        retained_vector_pairs=64, retained_raw_vector_files=128, deleted_files=0, finished_unix=time.time())
    cleanup = dict(archive=output_identity, archive_verified=True, delete_candidates=targets,
        retain_objects=objects, retain_traces=traces, retained_vector_hash_manifest='correctness-summary.json',
        retained_raw_vector_files=128, executed=False)
    for path, data in ((RECEIPT, receipt), (CLEANUP, cleanup)):
        with path.open('x', encoding='utf-8', newline='\n') as stream:
            json.dump(data, stream, indent=2)
            stream.write('\n')
    print(json.dumps(dict(archive=output_identity, receipt=str(RECEIPT), cleanup_plan=str(CLEANUP),
                         payload_count=len(rows), deleted_files=0), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', action='store_true', help='Read only: inventory and size estimate; no archive')
    args = parser.parse_args()
    files, missing_files = inventory()
    if args.plan:
        plan(files, missing_files)
    else:
        archive(files, missing_files)
