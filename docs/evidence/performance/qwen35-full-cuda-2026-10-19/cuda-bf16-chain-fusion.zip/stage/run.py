"""Explicit directed GPU runs after source freeze and bounded build.

Modes are separate so the parent owns the GPU window. No profiler, memory
sampler, model/SDK copy, server, or full test matrix is started here.
"""
from pathlib import Path
import argparse
import json
import re
import statistics
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build as b

OUT, ARCH, ROOT = b.OUT, b.ARCH, b.ROOT
CASE = ARCH / 'qwen-gpu-comparison/128-prefill'


def image(name):
    row = b.read(OUT / (name + '-image.json'))['image']
    assert b.ident(row['path']) == row, 'Image drift before run'
    return row


def trial(tag, arm, trace=False):
    assert arm in ('baseline', 'candidate')
    actual = image(arm)
    stage = OUT / tag
    stage.mkdir(exist_ok=False)
    fixed = b.read(CASE / 'fixed-inputs.json')
    assert len(fixed['prompt_ids']) == 128 and len(fixed['decode_input_ids']) == 31
    argv = [str(OUT / (arm + '.exe')), '--inputs', str(CASE / 'inputs'),
            '--decode-ids', str(CASE / 'decode.ids'), '--steps', '32', '--capacity', '256',
            '--progress', 'direct', '--replay', 'prefer-capture']
    if trace:
        argv += ['--trace', str(stage / 'trace'), '--trace-level', 'decisions']
    b.save(tag + '-inputs.json', dict(image=actual, link_plan=b.ident(OUT / (arm + '-link-plan.json')),
        fixed_inputs=b.ident(CASE / 'fixed-inputs.json'), prompt=b.ident(CASE / 'inputs/prompt.ids'),
        weights_reference=b.ident(CASE / 'inputs/weights.tsv'), tape=b.ident(CASE / 'decode.ids'),
        profiler=False, memory_monitor=False, traced_decisions=trace))
    row = b.execute(tag, argv)
    log = (OUT / (tag + '.stderr.log')).read_text(encoding='utf-8', errors='replace')
    phases = [dict(phase=phase, tokens=int(tokens), visible=int(visible),
        submit_to_token_seconds=float(seconds), submit_seconds=float(submit),
        step_seconds=float(step), next_token=int(token)) for phase, tokens, visible, seconds, submit, step, token in
        re.findall(r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+) seconds=(\S+) submit_seconds=(\S+) step_seconds=(\S+) progress=direct next=(\d+)', log, re.M)]
    output = json.loads((OUT / (tag + '.stdout.log')).read_text(encoding='utf-8').splitlines()[-1])
    assert len(phases) == len(output['generated_ids']) == 32
    assert output['decode_input_ids'] == fixed['decode_input_ids']
    captures = [dict(recorded=int(a), reused=int(c)) for a, c in
                re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', log)]
    metrics = dict(arm=arm, tag=tag, pid=row['pid'], exit=row['exit'], trace=trace, phases=phases,
        ids=output['generated_ids'], capture_counts=captures,
        prefill_tokens_per_second=128 / phases[0]['step_seconds'],
        full31_tokens_per_second=31 / sum(p['step_seconds'] for p in phases[1:]),
        warm7_31_tokens_per_second=25 / sum(p['step_seconds'] for p in phases[7:]))
    b.save(tag + '-metrics.json', metrics)
    print('  prefill', round(metrics['prefill_tokens_per_second'], 2),
          'warm7_31', round(metrics['warm7_31_tokens_per_second'], 2), flush=True)
    return metrics


def tests(filters):
    image('fusion-tests')
    assert filters, 'Explicit exact test filter required'
    b.save('test-run-plan.json', dict(filters=filters,
        source_receipts=[b.ident(OUT / (name + '-identity.json')) for name in b.TEST_SOURCES],
        compiler_flags=['/W4', '/WX'], directed_only=True))
    b.execute('directed-tests', [OUT / 'fusion-tests.exe', '--gtest_color=no',
        '--gtest_filter=' + filters, '--gtest_output=xml:' + str(OUT / 'directed-tests.xml')])
    xml = ET.parse(OUT / 'directed-tests.xml').getroot()
    cases = xml.findall('.//testcase')
    assert cases and not xml.findall('.//failure') and not xml.findall('.//skipped')
    if '*' not in filters and '?' not in filters and '-' not in filters:
        assert len(cases) == len(filters.split(':')), 'Requested directed test was absent'
    b.save('directed-tests-summary.json', dict(status='all_selected_tests_passed', count=len(cases),
        cases=[row.attrib['classname'] + '.' + row.attrib['name'] for row in cases],
        xml=b.ident(OUT / 'directed-tests.xml'), skipped=0, failures=0))


def correctness():
    runs = [trial('correctness-' + arm, arm, trace=True) for arm in ('baseline', 'candidate')]
    roots = [OUT / ('correctness-' + arm) / 'trace' for arm in ('baseline', 'candidate')]
    relative = sorted(p.relative_to(roots[0]) for p in roots[0].rglob('*')
                      if p.suffix in ('.bf16', '.f32'))
    candidate_relative = sorted(p.relative_to(roots[1]) for p in roots[1].rglob('*')
                                if p.suffix in ('.bf16', '.f32'))
    assert len(relative) == 64 and relative == candidate_relative
    vectors = []
    for path in relative:
        before, after = [b.ident(root / path) for root in roots]
        vectors.append(dict(path=str(path), bytes=before['bytes'], equal=before['sha256'] == after['sha256'],
            baseline_sha256=before['sha256'], candidate_sha256=after['sha256']))
    result = dict(status='real_qwen_128_prompt_31_fixed_decode_compared',
        vectors=vectors, equal_vectors=sum(row['equal'] for row in vectors), total_vectors=len(vectors),
        prediction_ids_equal=runs[0]['ids'] == runs[1]['ids'],
        capture_counts_equal=runs[0]['capture_counts'] == runs[1]['capture_counts'],
        profiler=False, memory_monitor=False,
        scope='Final hidden BF16 and logits F32 for prefill plus 31 fixed decode inputs; exact bytes.',
        limitation='No independent model quality acceptance and no new state-vector acceptance.')
    b.save('correctness-summary.json', result)
    assert result['prediction_ids_equal'] and result['capture_counts_equal']
    assert result['equal_vectors'] == result['total_vectors'] == 64
    print('Exact Qwen parity: 64/64 hidden/logit vectors and 32/32 predicted IDs.', flush=True)


def performance():
    proof = b.read(OUT / 'correctness-summary.json')
    assert proof['equal_vectors'] == proof['total_vectors'] == 64
    order = ('baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate')
    requests = [dict(tag=f'perf-{index:02d}-{arm}', arm=arm) for index, arm in enumerate(order, 1)]
    b.save('performance-run-plan.json', dict(pair_order=['B/C', 'C/B', 'B/C'], requests=requests,
        prompt_tokens=128, fixed_decode_inputs=31, context_capacity=256,
        profiler=False, memory_monitor=False, replay='prefer-capture',
        timer='Full step, input preparation through token visible on host. Shape compilation outside step.'))
    runs = []
    for request in requests:
        row = trial(request['tag'], request['arm'])
        assert row['ids'] == b.read(OUT / 'correctness-baseline-metrics.json')['ids']
        runs.append(row)
        b.save('performance-results.json', dict(runs=runs, remaining=len(requests) - len(runs)))
    keys = ('prefill_tokens_per_second', 'full31_tokens_per_second', 'warm7_31_tokens_per_second')
    groups = {arm: {key: dict(samples=[r[key] for r in runs if r['arm'] == arm],
        median=statistics.median(r[key] for r in runs if r['arm'] == arm)) for key in keys}
        for arm in ('baseline', 'candidate')}
    speedup = {key: groups['candidate'][key]['median'] / groups['baseline'][key]['median'] for key in keys}
    b.save('performance-summary.json', dict(status='six_unprofiled_processes_terminal_zero',
        groups=groups, speedup=speedup, pair_order=['B/C', 'C/B', 'B/C'],
        prediction_ids_equal=True, profiler=False, memory_monitor=False,
        native_TUs_replaced=['ggml-cuda.cu', 'binbcast.cu'],
        limitations=['Three fresh-process pairs on the same Windows GPU; no statistical significance claim.',
            'No kernel-level cause inferred without the separately authorized trace.']))
    print(json.dumps(dict(speedup=speedup)), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['tests', 'correctness', 'performance'])
    parser.add_argument('--filter')
    options = parser.parse_args()
    assert (OUT / 'build-summary.json').is_file(), 'Bounded frozen-source build must finish first'
    if options.mode == 'tests':
        tests(options.filter)
    elif options.mode == 'correctness':
        correctness()
    else:
        performance()
