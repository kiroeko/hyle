"""Exactly two parent-authorized traces; subsequent export/stats are offline."""
from pathlib import Path
import argparse
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build as b

NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
OUT = b.OUT / 'profile'


def profile(kind):
    name = 'candidate' if kind == 'qwen' else 'fusion-tests'
    image = b.read(b.OUT / (name + '-image.json'))['image']
    assert b.ident(image['path']) == image
    if kind == 'qwen':
        target = b.read(b.OUT / 'perf-02-candidate.command.json')['command']
        assert target[0] == image['path']
        assert '--trace' not in target
    else:
        target = [image['path'], '--gtest_color=no',
                  '--gtest_filter=GgmlCudaGraph.BfloatChainsPreserveEveryRoundingAndPublishedIntermediate']
    stem = OUT / (kind + '-trace')
    argv = [str(NSYS), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-graph-trace=node:host-only', '--discard-environment=true',
            '--output=' + str(stem), *target]
    b.save('profile-' + kind + '-inputs.json', dict(image=image, profiler=b.ident(NSYS),
        source_freeze=b.ident(b.OUT / 'source-freeze.json'), target=target,
        original_performance=b.ident(b.OUT / 'performance-summary.json'),
        SDK_rebuild=False, memory_monitor=False, trace_vectors=False,
        scope='One actual profile; never use profiled timings as a fair speed measurement.'))
    b.execute('profile-' + kind, argv)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['profile', 'export', 'stats'])
    parser.add_argument('kind', choices=['qwen', 'chains'])
    options = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if options.mode == 'profile':
        profile(options.kind)
    elif options.mode == 'export':
        b.execute('export-' + options.kind, [NSYS, 'export', '--type=sqlite',
            '--output=' + str(OUT / (options.kind + '-trace.sqlite')),
            OUT / (options.kind + '-trace.nsys-rep')])
    else:
        b.execute('stats-' + options.kind, [NSYS, 'stats', '--report',
            'cuda_api_sum,cuda_gpu_kern_sum', '--format', 'csv',
            '--output=' + str(OUT / (options.kind + '-trace')),
            OUT / (options.kind + '-trace.nsys-rep')])
