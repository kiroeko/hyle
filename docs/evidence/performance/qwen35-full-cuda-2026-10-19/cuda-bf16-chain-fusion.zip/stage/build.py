"""Two native CUDA TUs, two strict host test TUs, cached link closures.

prepare is read-only with respect to sources and never starts a compiler or GPU.
build requires the parent's explicit source freeze. No SDK or object is copied.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
ROOT = ARCH.parents[1]
REFERENCE = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
BASE = ARCH / 'cuda-current-peer/hyle-link-plan.json'
PRIOR = ARCH / 'cuda-bfloat-elementwise-build'
NAMES = ('ggml-cuda', 'binbcast')
TEST_SOURCES = {
    'tensor-test': ROOT / 'tests/compute_provider_ggml_cuda/tensor_test.cc',
    'region-test': ROOT / 'tests/graph_provider_ggml_cuda/region_test.cc',
}
TEST_TEMPLATES = {
    'tensor-test': ARCH / 'cuda-bfloat-elementwise-tests/tensor-test-identity.json',
    'region-test': ARCH / 'cuda-coarse-capture-tests/ggml-mean-test-identity.json',
}
OLD_OBJECTS = {
    'ggml-cuda': ARCH / 'cuda-coarse-capture-tests/ggml-cuda-record-cub.obj',
    'binbcast': PRIOR / 'binbcast.obj',
}
REUSED_RECEIPTS = {
    'unary': PRIOR / 'unary-identity.json',
    'tensor-current': PRIOR / 'tensor-current-identity.json',
}
QWEN = ARCH / 'cuda-capture-reuse/qwen-consumer.obj'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def dependencies(path):
    """Read nvcc's one-dependency-per-line Windows Make output, no shell parse."""
    paths = []
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines()[1:]:
        value = line.strip().removesuffix('\\').rstrip().replace('\\ ', ' ')
        if value:
            p = Path(value).resolve()
            if p.is_file() and p.suffix.lower() in ('.h', '.hpp', '.cuh') and p.is_relative_to(ROOT):
                paths.append(p)
    return sorted(set(paths), key=lambda p: str(p).lower())


def header_contract():
    paths = set(dependencies(ARCH / 'cuda-coarse-capture-tests/ggml-cuda-record-cub.d'))
    paths.update(dependencies(PRIOR / 'binbcast.obj.d'))
    paths.update(ROOT / 'src/compute_provider_ggml_cuda' / name
                 for name in ('native_bridge.h', 'native_bridge_impl.h'))
    rows = [ident(p) for p in sorted(paths, key=lambda p: str(p).lower())]
    old = read(ARCH / 'cuda-coarse-capture-tests/ggml-cuda-record-cub-identity.json')['matching_headers']
    for row in old:
        assert ident(row['path']) == row, 'Bridge ABI drift requires separate ownership audit'
    common = ident(REFERENCE / 'src/ggml-cuda/common.cuh')
    assert common['sha256'] == '120d79b9df46d0973018bee2666ac7ed4c5cb137b96434056e7e7311682685b2'
    return rows


def environment():
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    plans = [read(BASE)['command'], read(ARCH / 'cuda-current-peer/peer-link-plan.json')['command']]
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': plans[0][0].replace('link.exe', 'cl.exe')})
    env['VSLANG'] = '1033'
    paths = [str(Path(v).parent) for plan in plans for v in plan
             if Path(v).is_absolute() and v.lower().endswith('.lib')]
    env['PATH'] = os.pathsep.join(dict.fromkeys(paths)) + os.pathsep + env['PATH']
    (OUT / 'tmp').mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(OUT / 'tmp')
    assert not env.get('GGML_CUDA_DISABLE_GRAPHS')
    return env


def execute(tag, command):
    assert not (OUT / (tag + '.command.json')).exists(), 'Preserve the actual attempt: ' + tag
    row = dict(tag=tag, command=list(map(str, command)), cwd=str(ROOT), started=time.time(), exit=None)
    save(tag + '.command.json', row)
    print('START', tag, flush=True)
    with (OUT / (tag + '.stdout.log')).open('wb') as so, (OUT / (tag + '.stderr.log')).open('wb') as se:
        process = subprocess.Popen(row['command'], cwd=ROOT, env=environment(), stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = process.pid
        save('live.json', row)
        row['exit'] = process.wait()
    row.update(terminal=True, finished=time.time())
    save(tag + '.result.json', row)
    save('live.json', row)
    print('END', tag, row['exit'], round(row['finished'] - row['started'], 3), flush=True)
    if row['exit']:
        print((OUT / (tag + '.stdout.log')).read_text(errors='replace')[-5000:], flush=True)
        print((OUT / (tag + '.stderr.log')).read_text(errors='replace')[-7000:], flush=True)
        raise SystemExit(row['exit'])
    return row


def recipes():
    result = {}
    originals = read(PRIOR / 'compile-recipes.json')
    for name in NAMES:
        args, skip = [], False
        for value in originals[name]:
            if skip:
                skip = False
                continue
            if value in ('-c', '-o', '-MT', '-MF'):
                skip = True
                continue
            if value.startswith('-Xcompiler=-Fd'):
                continue
            args.append(value)
        assert '-use_fast_math' in args and '-std=c++17' in args
        assert '--generate-code=arch=compute_89,code=[sm_89]' in args
        args += ['-MT', str(OUT / (name + '.obj')), '-MF', str(OUT / (name + '.d')),
                 '-c', str(OUT / 'build-source' / (name + '.cu')), '-o', str(OUT / (name + '.obj')),
                 '-Xcompiler=-Fd' + str(OUT / (name + '.pdb')) + ',-FS']
        result[name] = args
    for name, receipt in TEST_TEMPLATES.items():
        args, skip = [], False
        for value in read(receipt)['command']:
            if skip:
                skip = False
                continue
            if value.lower() == '/sourcedependencies':
                skip = True
                continue
            if value.lower().startswith(('/fo', '/fd')) or value.lower().endswith('.cc'):
                continue
            args.append(value)
        assert '/W4' in args and '/WX' in args
        args += ['/sourceDependencies', str(OUT / (name + '-deps.json')), str(TEST_SOURCES[name]),
                 '/Fo' + str(OUT / (name + '.obj')), '/Fd' + str(OUT / (name + '.pdb'))]
        result[name] = args
    save('compile-recipes.json', result)
    return result


def prepare():
    commands = recipes()
    plan = read(BASE)
    inputs = [v for v in plan['command'] if Path(v).is_absolute() and Path(v).suffix.lower() in ('.obj', '.lib')]
    missing = [v for v in inputs if not Path(v).is_file()]
    assert len(inputs) == 119 and not missing
    # Existing objects are referred to in place, never copied.
    assert all(plan['command'].count(str(p)) == 1 for p in OLD_OBJECTS.values())
    assert plan['command'].count(str(QWEN)) == 1
    reused = {}
    for name, path in REUSED_RECEIPTS.items():
        receipt = read(path)
        assert ident(receipt['object']['path']) == receipt['object']
        assert ident(receipt['source']['path']) == receipt['source'], name + ' source drift'
        reused[name] = dict(receipt=ident(path), **receipt)
    assert '-use_fast_math' not in reused['unary']['command']
    stale_tests = {}
    for name, path in TEST_TEMPLATES.items():
        receipt = read(path)
        deps = receipt.get('hyle_dependencies', receipt.get('current_hyle_dependency_identities', []))
        stale_tests[name] = [row['path'] for row in deps
                             if not Path(row['path']).is_file() or ident(row['path']) != row]
    headers = header_contract()
    save('preparation.json', dict(status='recipes_prepared_no_compiler_or_GPU_started',
        base=ident(BASE), input_count=len(inputs), missing_inputs=missing,
        required_cuda_TUs=list(NAMES), required_host_test_TUs=list(TEST_SOURCES),
        old_objects={name: ident(path) for name, path in OLD_OBJECTS.items()},
        reused_contracts=reused, headers=headers, stale_test_dependencies=stale_tests,
        flags_preserved=True, unary_precise_contract_preserved=True,
        object_copy=False, SDK_rebuild=False,
        previous_two_cuda_compile_seconds={name: read(PRIOR / (tag + '.result.json'))['finished'] -
            read(PRIOR / (tag + '.result.json'))['started'] for name, tag in
            [('ggml-cuda', '001-ggml-cuda-compile'), ('binbcast', '002-binbcast-compile')]}))
    print('Prepared: 2 CUDA TUs, 2 strict host test TUs; 119 cached link inputs all present.', flush=True)
    return commands


def source_rows(freeze):
    data = read(freeze)
    rows = []
    for key in ('native_files', 'sources', 'files', 'test_sources'):
        value = data.get(key, [])
        if isinstance(value, dict):
            value = list(value.values())
        assert isinstance(value, list), 'Freeze must supply identity rows in ' + key
        rows.extend(value)
    assert rows, 'Freeze must supply identity rows in native_files/sources/files/test_sources'
    selected = {}
    for name in NAMES:
        row = next(row for row in rows if Path(row['path']).name == name + '.cu')
        actual = ident(row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], 'Frozen source drift'
        selected[name] = actual
    for name in TEST_SOURCES:
        source = TEST_SOURCES[name]
        row = next(row for row in rows if Path(row['path']).resolve() == source.resolve())
        assert ident(source)['sha256'] == row['sha256'], 'Frozen test source drift'
    return selected


def make_link(name, native=False, tests=False):
    args = read(BASE)['command'][:]
    if native:
        replace = {str(path): str(OUT / (tag + '.obj')) for tag, path in OLD_OBJECTS.items()}
        args = [replace.get(v, v) for v in args]
    if tests:
        args.remove(str(QWEN))
        args[1:1] = [str(OUT / (name + '.obj')) for name in TEST_SOURCES]
        args += [str(ROOT / '.scratch/build-compute-v2-dev/lib' / name)
                 for name in ('gtest_main.lib', 'gtest.lib')]
    args = [v for v in args if not v.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    args += ['/OUT:' + str(OUT / (name + '.exe')), '/MAP:' + str(OUT / (name + '.map')),
             '/IMPLIB:' + str(OUT / (name + '.lib'))]
    inputs = [ident(v) for v in args if Path(v).is_absolute() and Path(v).suffix.lower() in ('.obj', '.lib')]
    save(name + '-link-plan.json', dict(command=args, base=ident(BASE), inputs=inputs,
        change='Two explicit native replacements' if native else 'Baseline same 119 cached inputs',
        tests=tests, object_copy=False, SDK_rebuild=False))
    execute(name + '-link', args)
    lines = (OUT / (name + '.map')).read_text(errors='replace').splitlines()
    replaced_members = [line for line in lines if 'ggml-cuda.lib:' in line.lower() and
                        any(v in line.lower() for v in ('binbcast.cu.obj', 'unary.cu.obj', 'ggml-cuda.cu.obj'))]
    assert not replaced_members, 'Old archive member unexpectedly extracted'
    selected = [str(OUT / (tag + '.obj')) if native else str(path) for tag, path in OLD_OBJECTS.items()]
    selected += [read(path)['object']['path'] for path in REUSED_RECEIPTS.values()]
    if tests:
        selected += [str(OUT / (tag + '.obj')) for tag in TEST_SOURCES]
    owners = {Path(path).name: [line for line in lines if line.split() and
              line.split()[-1].lower() == Path(path).name.lower()] for path in selected}
    assert all(owners.values()), 'Expected selected owner absent from actual map'
    save(name + '-map-owners.json', dict(map=ident(OUT / (name + '.map')),
        selected={key: dict(count=len(value), sample=value[:3]) for key, value in owners.items()},
        old_replaced_native_library_members=replaced_members))
    save(name + '-image.json', dict(image=ident(OUT / (name + '.exe')),
                                   map=ident(OUT / (name + '.map')), input_count=len(inputs)))


def build(freeze):
    commands = prepare()
    frozen = source_rows(freeze)
    headers = header_contract()
    save('build-inputs.json', dict(freeze=ident(freeze), native_sources=frozen,
        test_sources={name: ident(path) for name, path in TEST_SOURCES.items()}, headers=headers))
    (OUT / 'build-source').mkdir(exist_ok=True)
    for name, row in frozen.items():
        target = OUT / 'build-source' / (name + '.cu')
        assert not target.exists(), 'Do not overwrite an earlier source attempt'
        target.write_bytes(Path(row['path']).read_bytes())
    for name in NAMES:
        execute(name + '-compile', commands[name])
        assert ident(frozen[name]['path']) == frozen[name]
        assert header_contract() == headers, 'Native header changed during compilation'
        save(name + '-identity.json', dict(source=frozen[name],
            compiled_source=ident(OUT / 'build-source' / (name + '.cu')),
            object=ident(OUT / (name + '.obj')), command=commands[name]))
    for name, source in TEST_SOURCES.items():
        before = ident(source)
        execute(name + '-compile', commands[name])
        assert ident(source) == before
        includes = read(OUT / (name + '-deps.json'))['Data']['Includes']
        save(name + '-identity.json', dict(source=before, object=ident(OUT / (name + '.obj')),
            command=commands[name], hyle_dependencies=[ident(p) for p in includes
                if Path(p).resolve().is_relative_to(ROOT)]))
    make_link('baseline')
    make_link('candidate', native=True)
    make_link('fusion-tests', native=True, tests=True)
    assert source_rows(freeze) == frozen and header_contract() == headers
    save('build-summary.json', dict(status='two_cuda_two_host_compiled_three_images_linked_not_run',
        sources=frozen, headers=headers, frozen_source_drift=0, native_math_flags_changed=False,
        unary_precise_contract_preserved=True, product_host_compilations=0,
        gpu_execution=False, SDK_rebuild=False, object_copy=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'build'])
    parser.add_argument('--freeze', type=Path)
    options = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if options.mode == 'prepare':
        prepare()
    else:
        assert options.freeze, 'Explicit parent source freeze is required'
        build(options.freeze)
