"""One short raw GLU trace; observe full versus partial fusion from actual launches."""
from pathlib import Path
import argparse
import collections
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('allocation_profile_build', STAGE / 'build.py')
a = load('allocation_profile_analysis', ARCH / 'cuda-fusion-precision/profile-analysis.py')
b, c = build.b, build.c
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('plan', type=Path)
parser.add_argument('--analyze', action='store_true')
args = parser.parse_args()
out = STAGE / 'profile-tests'
stem = out / 'full-glu'
test = 'GgmlCudaFusionAllocation.FullGluUsesUnpublishedStorageRoots'
if not args.analyze:
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if not c.read(plan_path.parent / 'run-cuda/summary.json')['passed']:
        raise ValueError('Passing related tests required')
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = b.identity(plan['links']['cuda']['image'])
    if image != c.read(plan_path.parent / 'cuda-image.json'):
        raise ValueError('Current test image differs')
    original = c.read(ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    index = original.index('--inputs') - 1
    profile = [('--output=' + str(stem)) if value.startswith('--output=') else value for value in original[:index]]
    profile += [image['path'], '--gtest_color=no', '--gtest_filter=' + test,
                '--gtest_output=xml:' + str(out / 'target.xml')]
    commands = {
        'profile': profile,
        'export': [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        'stats': [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum', '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'],
    }
    c.save(out / 'inputs.json', {'image': image, 'plan': b.identity(plan_path),
        'runner': b.identity(Path(__file__)), 'analysis': b.identity(ARCH / 'cuda-fusion-precision/profile-analysis.py'),
        'commands': commands, 'profiler_collections': 1, 'throughput_claim': False,
        'prediction': {'candidate_full_GLU': 6, 'candidate_if_only_partial_MM_ADD': 12,
                       'oracle_unfused_MM': 12, 'oracle_standalone_OAI_GLU': 6}})
    env, _ = b.environment(plan['links']['cuda']['command'], plan['links']['cuda']['inputs'], out)
    for tag, command in commands.items():
        c.execute(tag, command, env, out)

a.PROFILE = out
data = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'), candidate=True)
symbols = collections.Counter(row['name'] for row in data['kernels'])
carriers = []
for name, count in symbols.items():
    arguments = a.template_arguments(name, 'mul_mat_vec_f')
    if arguments:
        carriers.append({'symbol': name, 'count': count,
                         'has_fusion': arguments[4] in ('true', '(bool)1') if len(arguments) > 4 else None})
fused = sum(row['count'] for row in carriers if row['has_fusion'] is True)
unfused = sum(row['count'] for row in carriers if row['has_fusion'] is False)
standalone = sum(count for name, count in symbols.items() if 'swiglu_oai_kernel<' in name)
target = ET.parse(out / 'target.xml').getroot()
counts = {key: int(target.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
counts['skipped'] = sum(int(row.attrib.get('skipped', '0')) for row in target.findall('testsuite'))
checks = {'CSV_SQLite_per_symbol_equal': data['receipt']['csv_sqlite_per_symbol_counts_equal'],
    'no_graph_API_errors': not data['receipt']['graph_api_failures'],
    'single_requested_test_passed': counts['tests'] == 1 and not any(counts[key] for key in ('failures', 'disabled', 'errors', 'skipped'))}
report = {'passed': all(checks.values()), 'checks': checks, 'receipt': data['receipt'],
    'test': test, 'target': counts, 'carriers': carriers, 'all_kernel_counts': dict(symbols),
    'observed_fused_MMVF': fused, 'observed_unfused_MMVF': unfused, 'observed_standalone_OAI_GLU': standalone,
    'full_GLU_observed_for_all_six_candidates': fused == 6 and unfused == 12 and standalone == 6,
    'prediction': c.read(out / 'inputs.json')['prediction'], 'profiler_collections': 1,
    'complete_model_trace': False, 'throughput_claim': False,
    'limits': 'The count interpretation covers this six-candidate/six-oracle raw test only. A logical candidate or has_fusion bit alone does not prove a full GLU.'}
c.save(out / 'analysis.json', report)
print('PHYSICAL_FULL_GLU', {key: report[key] for key in ('passed', 'observed_fused_MMVF',
    'observed_unfused_MMVF', 'observed_standalone_OAI_GLU', 'full_GLU_observed_for_all_six_candidates')}, flush=True)
if not report['passed']:
    raise ValueError('Physical trace evidence has unresolved errors')
