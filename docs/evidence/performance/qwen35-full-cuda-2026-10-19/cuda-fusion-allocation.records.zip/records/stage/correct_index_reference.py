"""Retain the first compiler failure and fix the original matcher index reference."""
from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('allocation_correction_seal', STAGE / 'seal.py')
seal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(seal)
s, ROOT = seal.s, seal.ROOT
vendor = ROOT / 'third_party/ggml_cuda_runtime'
relative = 'src/ggml-cuda/ggml-cuda.cu'
native = STAGE / 'native-source' / relative
old = native.read_bytes()
before = 'bias_node->src[2] != ids'
after = 'bias_node->src[2] != mm_node->src[2]'
if old.count(before.encode()) != 1:
    raise ValueError('Expected one original index-reference correction')
new = old.replace(before.encode(), after.encode(), 1)
backup = STAGE / 'before-index-correction'
backup.mkdir(exist_ok=False)
for path in (STAGE / 'source-freeze.json', STAGE / 'native-source-freeze.json', STAGE / 'changes.diff',
             STAGE / 'application.json', STAGE / 'provider-version.h', vendor / 'patches.json',
             ROOT / 'cmake/HyleDependencyLock.json'):
    (backup / path.name).write_bytes(path.read_bytes())
(backup / 'ggml-cuda.cu').write_bytes(old)
manifest = s.read(vendor / 'patches.json')
row = next(row for row in manifest['files'] if row['path'] == relative)
row['edits'].append({'before': before, 'after': after})
row['after_sha256'] = s.sha(seal.prior.replay(row))
proposed = STAGE / 'patches.index-corrected.json'
s.save(proposed, manifest)
runtime = ROOT / 'src/compute_ggml_runtime'
compose = s.load('allocation_corrected_composer', runtime / 'prepare_cuda_iq1_manifest.py')
combined = STAGE / 'combined-index-corrected.json'
compose.derive(seal.prior.UPSTREAM, STAGE / 'mixed-cpu-manifest.json', proposed, vendor / 'iq1-patches.json', combined)
composed = next(row for row in s.read(combined)['files'] if row['path'] == relative)
if seal.prior.replay(composed) != new:
    raise ValueError('Corrected full native replay differs')
native.write_bytes(new)
reviewed = STAGE / 'source/native' / relative
reviewed.write_bytes(new)
(vendor / 'patches.json').write_bytes(proposed.read_bytes())
freeze = s.read(STAGE / 'source-freeze.json')
row = next(row for row in freeze['files'] if row['target'].startswith('native/'))
row['after']['bytes'], row['after']['sha256'] = len(new), s.sha(new)
diff = []
for row in freeze['files']:
    diff.extend(difflib.unified_diff(Path(row['before']['path']).read_text().splitlines(True),
        Path(row['after']['path']).read_text().splitlines(True), fromfile='a/' + row['target'], tofile='b/' + row['target']))
delta = STAGE / 'changes.diff'
delta.write_text(''.join(diff), encoding='utf-8', newline='\n')
freeze['diff']['bytes'], freeze['diff']['sha256'] = delta.stat().st_size, s.sha(delta.read_bytes())
freeze['compiler_correction'] = 'Original ids alias in moved ADD_ID branch replaced by that same original mm_node->src[2]. First compiler failure retained.'
s.save(STAGE / 'source-freeze.json', freeze)
lock_path = ROOT / 'cmake/HyleDependencyLock.json'
lock = s.read(lock_path)
entries = {row['name']: row for row in lock['dependencies']}
cuda = entries['ggml_cuda_runtime_patches']
cuda['vendored']['tree_sha256'] = s.tree(vendor)
s.save(lock_path, lock)
identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
identity += cuda['vendored']['tree_sha256']
source_id = s.sha(identity.encode())[:16]
(STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
native_freeze = s.read(STAGE / 'native-source-freeze.json')
native_freeze.update(source_id=source_id, vendor_tree_sha256=cuda['vendored']['tree_sha256'], sources={relative: s.sha(new)})
s.save(STAGE / 'native-source-freeze.json', native_freeze)
application = s.read(STAGE / 'application.json')
application.update(native_source_id=source_id, native_sha256=s.sha(new), compiler_correction=freeze['compiler_correction'])
s.save(STAGE / 'application.json', application)
print('CORRECTED', source_id, s.sha(new), flush=True)
