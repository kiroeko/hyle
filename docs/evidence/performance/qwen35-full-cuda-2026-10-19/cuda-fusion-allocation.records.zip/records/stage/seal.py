"""Apply the reviewed cold allocation-dependency integration after exact replay."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('allocation_replay', STAGE.parent / 'cuda-explicit-rope/seal.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
s = prior.s


def edits(old, new):
    left, right = old.decode().splitlines(True), new.decode().splitlines(True)
    result, data = [], old
    for group in difflib.SequenceMatcher(None, left, right, autojunk=False).get_grouped_opcodes(5):
        first, last = group[0], group[-1]
        before = ''.join(left[first[1]:last[2]])
        after = ''.join(right[first[3]:last[4]])
        if data.count(before.encode()) != 1:
            raise ValueError('Native edit context is not unique')
        data = data.replace(before.encode(), after.encode(), 1)
        result.append({'before': before, 'after': after})
    if data != new:
        raise ValueError('Native incremental edit replay differs')
    return result


def verify(identity):
    data = Path(identity['path']).read_bytes()
    if len(data) != identity['bytes'] or s.sha(data) != identity['sha256']:
        raise ValueError('Reviewed input differs: ' + identity['path'])
    return data


def main():
    freeze = s.read(STAGE / 'source-freeze.json')
    for row in freeze['files']:
        verify(row['origin'])
        verify(row['before'])
        verify(row['after'])
    verify(freeze['diff'])
    verify(freeze['relocation_proof'])
    tests = s.read(STAGE / 'tests-source-freeze.json')
    verify(tests['before'])
    verify(tests['after'])
    verify(tests['fragment'])
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    manifest = s.read(vendor / 'patches.json')
    runtime = ROOT / 'src/compute_ggml_runtime'
    mixed = STAGE / 'mixed-cpu-manifest.json'
    s.load('allocation_mixed', runtime / 'prepare_mixed_cpu_manifest.py').derive(prior.UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    compose = s.load('allocation_composer', runtime / 'prepare_cuda_iq1_manifest.py')
    initial = STAGE / 'before-combined.json'
    compose.derive(prior.UPSTREAM, mixed, vendor / 'patches.json', vendor / 'iq1-patches.json', initial)
    native = next(row for row in freeze['files'] if row['target'].startswith('native/'))
    relative = native['target'].removeprefix('native/')
    original, target = verify(native['before']), verify(native['after'])
    current = next(row for row in s.read(initial)['files'] if row['path'] == relative)
    if prior.replay(current) != original:
        raise ValueError('Composed native baseline differs from reviewed source')
    delta = {'path': relative, 'before_sha256': s.sha(original), 'after_sha256': s.sha(target),
             'edits': edits(original, target)}
    s.save(STAGE / 'replacements.json', {'files': [delta]})
    row = next(row for row in manifest['files'] if row['path'] == relative)
    row['edits'].extend(delta['edits'])
    row['after_sha256'] = s.sha(prior.replay(row))
    proposed = STAGE / 'patches.draft.json'
    s.save(proposed, manifest)
    combined = STAGE / 'combined-manifest.json'
    compose.derive(prior.UPSTREAM, mixed, proposed, vendor / 'iq1-patches.json', combined)
    for row in s.read(combined)['files']:
        data = prior.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Composed patch SHA differs: ' + row['path'])
        if row['path'] == relative and data != target:
            raise ValueError('Reviewed native overlay differs from full replay')
    before = STAGE / 'before-seal'
    before.mkdir(exist_ok=False)
    for name, path in (('patches.json', vendor / 'patches.json'), ('NOTICE.md', vendor / 'NOTICE.md'),
                       ('dependency-lock.json', ROOT / 'cmake/HyleDependencyLock.json')):
        (before / name).write_bytes(path.read_bytes())
    native_path = STAGE / 'native-source' / relative
    native_path.parent.mkdir(parents=True, exist_ok=True)
    native_path.write_bytes(target)
    applied = []
    for row in freeze['files']:
        if row['target'].startswith('native/'):
            continue
        destination = ROOT / row['target']
        destination.write_bytes(verify(row['after']))
        applied.append({'target': str(destination), 'before_sha256': row['origin']['sha256'],
                        'after_sha256': row['after']['sha256']})
    Path(tests['before']['path']).write_bytes(verify(tests['after']))
    applied.append({'target': tests['before']['path'], 'before_sha256': tests['before']['sha256'],
                    'after_sha256': tests['after']['sha256']})
    (vendor / 'patches.json').write_bytes(proposed.read_bytes())
    notice = vendor / 'NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip() + '''

The original MMVF/MMVQ matcher now reports its actual weight, activation,
index, bias and scale storage roots to Hyle's cold allocation planner. A
private allocation-only graph extends those read lifetimes through each
potential fused output; execution and capture keep the original mathematical
graph. Measurement and actual invocation use the same dependency metadata.
Final encoding retains the bound-address, alignment, layout and RESTRICT
checks, including explicit caller aliases. No input OUTPUT flags, payload
copies, public API, extra executor or upstream optimizer are introduced.
The upstream weighted-MoE optimizer keeps its original registration behavior.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v21'
    cuda['vendored']['tree_sha256'] = s.tree(vendor)
    for item in cuda['license']['files']:
        if item['root'] == 'hyle' and item['path'].endswith('NOTICE.md'):
            item['sha256'] = s.sha(notice.read_bytes())
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    s.save(STAGE / 'native-source-freeze.json', {'version': cuda['version'], 'source_id': source_id,
        'vendor_tree_sha256': cuda['vendored']['tree_sha256'], 'sources': {relative: s.sha(target)},
        'all_mixed_CPU_IQ1_CUDA_edits_replayed': True, 'SDK_modified': False,
        'private_fusion_argument_ABI_changed': False, 'public_API_changed': False,
        'numerical_contract_changed': False})
    s.save(STAGE / 'application.json', {'applied': applied, 'native_source_id': source_id,
        'native_sha256': s.sha(target), 'validation_run': False})
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED', source_id, flush=True)


if __name__ == '__main__':
    main()
