from pathlib import Path
import difflib
import hashlib
import json
import re

REPO = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
NATIVE = REPO / '.scratch/architecture-refactor-2026-10-18/cuda-fusion-precision/native-source/src/ggml-cuda/ggml-cuda.cu'
NATIVE_SHA = '7b173a31c82ee787010c8c39e542ce6de1a0a47af159598b8aedfe7119f676a4'


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old[:100], text.count(old), count)
    return text.replace(old, new)


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


assert identity(NATIVE)['sha256'] == NATIVE_SHA
files = {
    'native/src/ggml-cuda/ggml-cuda.cu': NATIVE,
    **{f'src/compute_provider_ggml_cuda/{name}': REPO / 'src/compute_provider_ggml_cuda' / name
       for name in ('native_bridge.h', 'native_bridge_impl.h', 'ggml_cuda_provider.cc')},
}
before = {key: path.read_text(encoding='utf-8') for key, path in files.items()}
after = dict(before)

key = 'native/src/ggml-cuda/ggml-cuda.cu'
text = before[key]

# The eight actual memory inputs have one definition for qualification and deps.
marker = '// MMVF/MMVQ receive weight/input/output strides, but their epilogues do\n'
reads_helper = '''// Actual carrier reads, independent of their native graph spelling. Keep this
// shared by the final RESTRICT guard and cold allocation dependency collection.
static std::array<const ggml_tensor *, 8> ggml_cuda_matvec_fusion_reads(
        const ggml_tensor * mm, const ggml_cuda_mm_fusion_args_host & fusion) {
    return { mm->src[0], mm->src[1], mm->op == GGML_OP_MUL_MAT_ID ? mm->src[2] : nullptr,
             fusion.gate, fusion.x_bias, fusion.gate_bias, fusion.x_scale, fusion.gate_scale };
}

'''
text = replace(text, marker, reads_helper + marker)
text = replace(text,
    'const ggml_tensor * mm, const ggml_tensor * dst, const ggml_cuda_mm_fusion_args_host & fusion) {',
    'const ggml_tensor * mm, const ggml_tensor * dst, const ggml_cuda_mm_fusion_args_host & fusion,\n'
    '        bool require_bound = true) {')
text = replace(text,
    'if (reinterpret_cast<uintptr_t>(input->data) % alignof(float2) ||',
    'if ((require_bound && reinterpret_cast<uintptr_t>(input->data) % alignof(float2)) ||')
old_reads = '''    const ggml_tensor * reads[] = {weight, input, ids, fusion.gate,
        fusion.x_bias, fusion.gate_bias, fusion.x_scale, fusion.gate_scale};
'''
text = replace(text, old_reads, '    const auto reads = ggml_cuda_matvec_fusion_reads(mm, fusion);\n')
ancestry = '''        // The carrier reads these from memory. A scalar scale derived from
        // an elided projection (e.g. a one-row mm*mm) is not an external input.
        for (const ggml_tensor * source = read; source; source = source->view_src) {
            for (int node = first; node < first + count; ++node) {
                if (source == graph->nodes[node]) {
                    return false;
                }
            }
        }
'''
text = replace(text, ancestry, '')
layout_start = text.index('static bool ggml_cuda_matvec_fusion_layout(')
range_pos = text.index('    const auto range = []', layout_start)
cold_ancestry = '''    const auto reads = ggml_cuda_matvec_fusion_reads(mm, fusion);
    for (const auto * read : reads) {
        // A memory source produced by this elided span is not an external read.
        for (const ggml_tensor * source = read; source; source = source->view_src) {
            for (int node = first; node < first + count; ++node) {
                if (source == graph->nodes[node]) {
                    return false;
                }
            }
        }
    }
    // Cold matching only defers qualifications that require bound addresses.
    // The encoder always repeats the full range/alignment/RESTRICT checks.
    if (!require_bound) {
        return true;
    }
'''
text = text[:range_pos] + cold_ancestry + text[range_pos:]
# Remove the second readset declaration in the bound-only section.
bound_start = text.index('    // Include OP_NONE leaves;', layout_start)
pos = text.index('    const auto reads = ggml_cuda_matvec_fusion_reads(mm, fusion);\n', bound_start)
text = text[:pos] + text[pos:].replace('    const auto reads = ggml_cuda_matvec_fusion_reads(mm, fusion);\n', '', 1)

# MMVQ's compute-buffer padding condition is an address/buffer qualification.
text = replace(text,
    'static bool ggml_cuda_should_fuse_mul_mat_vec_q(const ggml_tensor * tensor) {',
    'static bool ggml_cuda_should_fuse_mul_mat_vec_q(const ggml_tensor * tensor, bool require_bound = true) {')
q_begin = text.index('static bool ggml_cuda_should_fuse_mul_mat_vec_q(')
q_end = text.index('static bool ggml_cuda_bfloat_matvec(', q_begin)
q = replace(text[q_begin:q_end],
    'const bool bad_padding_clear = ggml_backend_buffer_get_usage(src0->buffer)',
    'const bool bad_padding_clear = require_bound && ggml_backend_buffer_get_usage(src0->buffer)')
text = text[:q_begin] + q + text[q_end:]

# Preserve the existing can_fuse numerical/closure rules. Only the private
# matvec matcher requests its unbound form; every other call retains true.
text = replace(text,
    'std::initializer_list<enum ggml_unary_op> unary_ops) {',
    'std::initializer_list<enum ggml_unary_op> unary_ops,\n'
    '                               bool require_bound = true) {')
can_begin = text.index('static bool ggml_cuda_can_fuse(')
can_end = text.index('// BF16 fusion elides stores', can_begin)
can = text[can_begin:can_end]
assert can.count('return ggml_cuda_check_fusion_memory_ranges(') == 5
can = can.replace('return ggml_cuda_check_fusion_memory_ranges(',
                  'return !require_bound || ggml_cuda_check_fusion_memory_ranges(')
text = text[:can_begin] + can + text[can_end:]

# Move the existing nine call sites verbatim into one shared matcher. Device,
# precision, GLU parameters, branch order and structural qualifications stay.
try_begin = text.index('static int ggml_cuda_try_fuse(')
block_begin = text.index('    bool fused_mul_mat_vec = false;\n', try_begin)
block_end = text.index('    if (ggml_cuda_can_fuse(cgraph, i, { GGML_OP_RMS_NORM,', block_begin)
block = text[block_begin:block_end]
original_block = block
block = block.replace(
    '!ggml_cuda_check_fusion_memory_ranges(cgraph, i, n_ops, out_nodes, 1)',
    '(require_bound && !ggml_cuda_check_fusion_memory_ranges(cgraph, i, n_ops, out_nodes, 1))')
block = block.replace('GGML_OP_GLU }, {}))', 'GGML_OP_GLU }, {}, require_bound))')
block = re.sub(r'ggml_cuda_should_fuse_mul_mat_vec_q\((up_n|up|mm_node)\)',
               r'ggml_cuda_should_fuse_mul_mat_vec_q(\1, require_bound)', block)
block, layouts = re.subn(r'ggml_cuda_matvec_fusion_layout\(([^\n]+), fusion_data\)',
                         r'ggml_cuda_matvec_fusion_layout(\1, fusion_data, require_bound)', block)
assert layouts == 9
calls = re.compile(r'(?P<indent> +)ggml_cuda_mul_mat_vec_(?P<kind>[fq])\(\*cuda_ctx, src0, src1, ids, '
                   r'(?P<dst>[^,\n]+), (?:(?:ggml_prec\((?P<mm>[^\n]+?)->op_params\[0\]\), ))?&fusion_data\);')
found = list(calls.finditer(block))
assert len(found) == 9, len(found)
dispatches = []
# A call's exact mm is the same tensor supplied to the immediately prior guard.
def match_call(m):
    prefix = block[:m.start()]
    guard = list(re.finditer(r'ggml_cuda_matvec_fusion_layout\(cgraph, i, [^,]+, ([^,]+),', prefix))[-1]
    mm = guard.group(1)
    if m.group('mm'):
        assert m.group('mm') == mm
    count = list(re.finditer(r'ggml_cuda_matvec_fusion_layout\(cgraph, i, ([^,]+),', prefix))[-1].group(1)
    dispatches.append({'carrier': m.group('kind'), 'mm': mm, 'dst': m.group('dst'),
                       'count': count, 'precision': f'{mm}->op_params[0]' if m.group('kind') == 'f' else None})
    return (f"{m.group('indent')}match = {{ {mm}, {m.group('dst')}, fusion_data, {count}, "
            f"{'true' if m.group('kind') == 'q' else 'false'} }};")
block = calls.sub(match_call, block)
block, removed = re.subn(r' +const ggml_tensor \* src0 = [^;]+;\n'
                        r' +const ggml_tensor \* src1 = [^;]+;\n'
                        r' +const ggml_tensor \* ids  = [^;]+;\n', '', block)
assert removed == 6, removed
assert block.count('return fused_node_count - 1;') == 3
block = block.replace('return fused_node_count - 1;', 'return true;')
block, unused_counts = re.subn(r'^ +(?:int +)?fused_node_count\s*=.*;\n', '', block, flags=re.M)
assert unused_counts == 11, unused_counts

def normalized_moved_body(body):
    body = re.sub(r'^ +ggml_cuda_mul_mat_vec_[fq]\([^\n]+\);\n', '', body, flags=re.M)
    body = re.sub(r'^ +match = \{[^\n]+\};\n', '', body, flags=re.M)
    body = re.sub(r' +const ggml_tensor \* src0 = [^;]+;\n'
                  r' +const ggml_tensor \* src1 = [^;]+;\n'
                  r' +const ggml_tensor \* ids  = [^;]+;\n', '', body)
    body = re.sub(r'^ +(?:int +)?fused_node_count\s*=.*;\n', '', body, flags=re.M)
    body = body.replace('return fused_node_count - 1;', 'return true;')
    body = body.replace(', require_bound', '')
    body = body.replace('(require_bound && !ggml_cuda_check_fusion_memory_ranges(cgraph, i, n_ops, out_nodes, 1))',
                        '!ggml_cuda_check_fusion_memory_ranges(cgraph, i, n_ops, out_nodes, 1)')
    return re.sub(r'\s+', '', body)

normalized_before = normalized_moved_body(original_block)
normalized_after = normalized_moved_body(block)
assert normalized_before == normalized_after, 'Native matcher relocation changed a non-deferred qualification'
# Keep the original stop flags. The result owns the exact consumed count.
matcher = '''struct ggml_cuda_matvec_fusion_match {
    const ggml_tensor * mm = nullptr;
    ggml_tensor * dst = nullptr;
    ggml_cuda_mm_fusion_args_host fusion{};
    int count = 0;
    bool quantized = false;
};

static bool ggml_cuda_fusion_disabled() {
    static const bool disabled = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr &&
        std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));
    return disabled;
}

// One matcher supplies both cold read lifetimes and the original encoder.
// Unbound matching is conservative: final address guards may still decline.
static bool ggml_cuda_match_matvec_fusion(ggml_cgraph * cgraph, int i,
        bool require_bound, ggml_cuda_matvec_fusion_match & match) {
    if (cgraph->nodes[i]->op != GGML_OP_MUL_MAT && cgraph->nodes[i]->op != GGML_OP_MUL_MAT_ID) {
        return false;
    }
''' + block + '''    return false;
}

template<typename Add>
static void ggml_cuda_collect_fusion_alloc_deps(ggml_backend_cuda_context * cuda_ctx,
        ggml_cgraph * cgraph, Add && add) {
    if (ggml_cuda_fusion_disabled()) {
        return;
    }
    // The same actual native device used by the encoder's MMVF/MMVQ rules.
    ggml_cuda_set_device(cuda_ctx->device);
    const auto keep = [&](const ggml_tensor * read, int until_node) {
        if (!read) {
            return;
        }
        // In particular, OP_NONE view aliases do not contribute n_views in
        // gallocr. Preserve the real storage root instead of assuming that.
        while (read->view_src) {
            read = read->view_src;
        }
        add(const_cast<ggml_tensor *>(read), until_node);
    };
    for (int i = 0; i < cgraph->n_nodes; ++i) {
        ggml_cuda_matvec_fusion_match matvec;
        if (ggml_cuda_match_matvec_fusion(cgraph, i, false, matvec)) {
            for (const auto * read : ggml_cuda_matvec_fusion_reads(matvec.mm, matvec.fusion)) {
                keep(read, i + matvec.count - 1);
            }
        }
    }
}

'''
dispatch = '''    ggml_cuda_matvec_fusion_match matvec;
    if (ggml_cuda_match_matvec_fusion(cgraph, i, true, matvec)) {
        if (matvec.quantized) {
            ggml_cuda_mul_mat_vec_q(*cuda_ctx, matvec.mm->src[0], matvec.mm->src[1],
                                   matvec.mm->src[2], matvec.dst, &matvec.fusion);
        } else {
            ggml_cuda_mul_mat_vec_f(*cuda_ctx, matvec.mm->src[0], matvec.mm->src[1],
                                   matvec.mm->src[2], matvec.dst,
                                   ggml_prec(matvec.mm->op_params[0]), &matvec.fusion);
        }
        return matvec.count - 1;
    }

'''
text = text[:block_begin] + dispatch + text[block_end:]
text = text[:try_begin] + matcher + text[try_begin:]
text = replace(text,
    '''    static bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));
    if (disable_fusion) {''',
    '''    if (ggml_cuda_fusion_disabled()) {''')
optimizer_start = text.index('static void ggml_backend_cuda_graph_optimize(')
optimizer_end = text.index('\n#ifdef USE_CUDA_GRAPH', optimizer_start)
# The upstream scheduler does not add hidden storage roots to its leaf table.
# Preserve its original MoE dependencies and all optimizer behaviour; only
# Hyle's allocation-only builder consumes the new flattened-root collector.
new_optimizer = text[optimizer_start:optimizer_end]
new_optimizer = replace(new_optimizer,
    '''    static const bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));
    if (!disable_fusion) {''',
    '''    if (!ggml_cuda_fusion_disabled()) {''')
text = text[:optimizer_start] + new_optimizer + text[optimizer_end:]
after[key] = text

key = 'src/compute_provider_ggml_cuda/native_bridge.h'
after[key] = replace(before[key],
    '// Exact original native graph qualification. No payload is read or submitted.\n',
    '''// Cold-only dependency reporting, shared with the original native fusers.
// Reports actual storage roots and their last potential fused output's node
// ordinal in the original graph. No payload is read, graph reordered,
// stream created or optimizer enabled.
void collect_allocation_dependencies(
    ggml_backend *backend, ggml_cgraph *graph,
    void (*add)(void *user, ggml_tensor *root, int until_node), void *user);

// Exact original native graph qualification. No payload is read or submitted.
''')
key = 'src/compute_provider_ggml_cuda/native_bridge_impl.h'
after[key] = replace(before[key], 'cudaError_t drain(ggml_backend *backend) noexcept {',
    '''void collect_allocation_dependencies(
    ggml_backend *backend, ggml_cgraph *graph,
    void (*add)(void *user, ggml_tensor *root, int until_node), void *user) {
  GGML_ASSERT(backend && graph && add);
  ggml_cuda_collect_fusion_alloc_deps(
      static_cast<ggml_backend_cuda_context *>(backend->context), graph,
      [&](ggml_tensor *root, int until_node) { add(user, root, until_node); });
}

cudaError_t drain(ggml_backend *backend) noexcept {''')

key = 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
text = before[key]
text = replace(text, '#include <new>\n', '#include <new>\n#include <unordered_set>\n')
text = replace(text, '#include <ggml.h>\n', '#include <ggml.h>\n#include <ggml-impl.h>\n')
text = replace(text, '#include "hyle/compute/route_policy.h"\n',
               '#include "hyle/compute/route_policy.h"\n'
               '#include "hyle/container/small_vector.h"\n'
               '#include "hyle/mem/std_allocator.h"\n')
text = replace(text, '  ggml_cgraph *graph = nullptr;\n',
    '''  ggml_cgraph *graph = nullptr;
  // Only gallocr sees these dependency nodes. The encoder/capture graph and
  // its reader counts stay untouched; no additional payload is introduced.
  ggml_runtime::MetadataArena allocation_arena;
  ggml_cgraph allocation_graph{};
  using AllocationTensors = container::SmallVector<ggml_tensor *, 0, mem::AllocatorRef>;
  AllocationTensors allocation_nodes;
  AllocationTensors allocation_leafs;
''')
method = '''  ggml_cgraph *allocation_plan() noexcept {
    return allocation_nodes.empty() ? graph : &allocation_graph;
  }

  Status build_allocation_plan(mem::AllocatorRef allocator) {
    struct Dependency final {
      int until;
      ggml_tensor *tensor;
      std::size_t registration;
    };
    using Dependencies = std::vector<Dependency, mem::StdAllocator<Dependency>>;
    using TensorSet = std::unordered_set<ggml_tensor *, std::hash<ggml_tensor *>,
        std::equal_to<ggml_tensor *>, mem::StdAllocator<ggml_tensor *>>;
    struct Collection final {
      int node_count;
      Dependencies dependencies;
      bool invalid = false;
      Collection(int count, mem::AllocatorRef allocator)
          : node_count(count), dependencies(mem::StdAllocator<Dependency>{allocator}) {}
    };
    Collection collection{graph->n_nodes, allocator};
    bridge::collect_allocation_dependencies(
        backend, graph,
        [](void *state, ggml_tensor *tensor, int until_node) {
          auto &out = *static_cast<Collection *>(state);
          if (!tensor || tensor->view_src || until_node < 0 || until_node >= out.node_count) {
            out.invalid = true;
            return;
          }
          if (out.dependencies.size() == static_cast<std::size_t>(INT32_MAX))
            throw std::bad_alloc{};
          out.dependencies.push_back({until_node, tensor, out.dependencies.size()});
        },
        &collection);
    if (collection.invalid)
      return Status::Internal("ggml CUDA invalid allocation dependency");
    auto &deps = collection.dependencies;
    if (deps.empty())
      return Status::Ok();
    // In-place sort uses no hidden temporary allocator. Registration order
    // within an output does not depend on pointer order in the two builds.
    std::sort(deps.begin(), deps.end(), [](const auto &a, const auto &b) {
      return a.until != b.until ? a.until < b.until : a.registration < b.registration;
    });
    TensorSet seen{mem::StdAllocator<ggml_tensor *>{allocator}};
    int previous = -1;
    std::size_t unique = 0;
    for (const auto &dep : deps) {
      if (dep.until != previous) {
        seen.clear();
        previous = dep.until;
      }
      if (seen.insert(dep.tensor).second)
        deps[unique++] = dep;
    }
    deps.resize(unique);

    std::vector<ggml_tensor *, mem::StdAllocator<ggml_tensor *>> extra_roots{
        mem::StdAllocator<ggml_tensor *>{allocator}};
    seen.clear();
    // A NONE alias may hide its physical root from forward traversal. Count
    // that external leaf explicitly rather than relying on hash slack.
    for (const auto &dep : deps) {
      if (!ggml_hash_contains(&graph->visited_hash_set, dep.tensor) &&
          seen.insert(dep.tensor).second) {
        if (dep.tensor->op != GGML_OP_NONE)
          return Status::Internal("ggml CUDA allocation root outside graph");
        for (auto *source : dep.tensor->src)
          if (source)
            return Status::Internal("ggml CUDA external allocation root has sources");
        extra_roots.push_back(dep.tensor);
      }
    }
    std::size_t dep_nodes = 0;
    previous = -1;
    std::size_t group = 0;
    for (const auto &dep : deps) {
      if (dep.until != previous) {
        if (group != 0)
          dep_nodes += (group + GGML_MAX_SRC - 1) / GGML_MAX_SRC;
        previous = dep.until;
        group = 0;
      }
      ++group;
    }
    dep_nodes += (group + GGML_MAX_SRC - 1) / GGML_MAX_SRC;
    const auto maximum = static_cast<std::size_t>(INT32_MAX);
    const auto leaf_count = static_cast<std::size_t>(graph->n_leafs) + extra_roots.size();
    if (leaf_count > maximum ||
        static_cast<std::size_t>(graph->n_nodes) > maximum - leaf_count ||
        dep_nodes > maximum - leaf_count - static_cast<std::size_t>(graph->n_nodes))
      return Status::OutOfRange("ggml CUDA allocation graph count overflows");
    const auto overhead = ggml_tensor_overhead();
    const auto byte_max = static_cast<std::size_t>(PTRDIFF_MAX) - (GGML_MEM_ALIGN - 1);
    if (overhead == 0 || dep_nodes > byte_max / overhead)
      return Status::OutOfRange("ggml CUDA allocation metadata overflows");
    HYLE_ASSIGN_OR_RETURN(auto metadata,
                          ggml_runtime::MetadataArena::create(dep_nodes * overhead, allocator));
    allocation_arena = std::move(metadata);
    allocation_nodes = AllocationTensors(allocator);
    allocation_leafs = AllocationTensors(allocator);
    if (!allocation_nodes.try_reserve(static_cast<std::size_t>(graph->n_nodes) + dep_nodes) ||
        !allocation_leafs.try_reserve(leaf_count))
      return Status::ResourceExhausted("ggml CUDA allocation graph metadata failed");
    // Initialize hidden physical roots before any original NONE aliases.
    for (auto *root : extra_roots)
      allocation_leafs.push_back(root);
    for (int i = 0; i < graph->n_leafs; ++i)
      allocation_leafs.push_back(graph->leafs[i]);
    std::size_t next = 0;
    for (int i = 0; i < graph->n_nodes; ++i) {
      allocation_nodes.push_back(graph->nodes[i]);
      while (next < deps.size() && deps[next].until == i) {
        auto *dep = ggml_view_tensor(allocation_arena.get(), deps[next].tensor);
        for (int source = 0; source < GGML_MAX_SRC && next < deps.size() && deps[next].until == i;
             ++source, ++next)
          dep->src[source] = deps[next].tensor;
        allocation_nodes.push_back(dep);
      }
    }
    // ggml-alloc only reads nodes/leafs and their counts. All other shallow
    // fields still belong to the original graph and are never mutated here.
    allocation_graph = *graph;
    allocation_graph.nodes = allocation_nodes.data();
    allocation_graph.n_nodes = static_cast<int>(allocation_nodes.size());
    allocation_graph.size = static_cast<int>(std::max(allocation_nodes.size(), allocation_leafs.size()));
    allocation_graph.leafs = allocation_leafs.data();
    allocation_graph.n_leafs = static_cast<int>(allocation_leafs.size());
    return Status::Ok();
  }

'''
text = replace(text, '  Status finish_bind() {\n', method + '  Status finish_bind() {\n')
text = replace(text, 'ggml_gallocr_alloc_graph(graph_allocator, graph)',
               'ggml_gallocr_alloc_graph(graph_allocator, allocation_plan())')
text = replace(text, 'ggml_gallocr_reserve(graph_allocator, graph)',
               'ggml_gallocr_reserve(graph_allocator, allocation_plan())')
text = replace(text, '''    bind_views();
    if (!metadata_only) {''', '''    bind_views();
    HYLE_RETURN_IF_ERROR(build_allocation_plan(allocator));
    if (!metadata_only) {''')
after[key] = text

diffs = []
receipt = []
for key, source in files.items():
    old = STAGE / 'before' / key
    new = STAGE / 'source' / key
    old.parent.mkdir(parents=True, exist_ok=True)
    new.parent.mkdir(parents=True, exist_ok=True)
    old.write_bytes(source.read_bytes())
    new.write_text(after[key], encoding='utf-8', newline='\n')
    diffs.extend(difflib.unified_diff(before[key].splitlines(True), after[key].splitlines(True),
                                    fromfile='a/' + key, tofile='b/' + key))
    receipt.append({'target': key, 'origin': identity(source), 'before': identity(old), 'after': identity(new)})
(STAGE / 'changes.diff').write_text(''.join(diffs), encoding='utf-8', newline='\n')
(STAGE / 'relocation-proof.json').write_text(json.dumps({
    'state': 'Static source transformation check only; not a compiler or runtime proof.',
    'original_call_sites': len(dispatches),
    'dispatches': dispatches,
    'normalized_original_and_moved_matcher_equal': True,
    'normalization': ['Remove unused src aliases/count assignments and dispatch-vs-result statements',
                      'Remove private require_bound argument and its address-check wrapper',
                      'Normalize whitespace only; retain remaining branch/precision/GLU/layout/closure logic'],
    'normalized_body_sha256': hashlib.sha256(normalized_before.encode()).hexdigest(),
    'upstream_optimizer': 'Original weighted-MoE registration preserved; only shared disable flag replaces local static',
}, indent=2) + '\n', encoding='utf-8')

native_key = 'native/src/ggml-cuda/ggml-cuda.cu'
native_before, native_after = before[native_key], after[native_key]
def section(body, begin, end):
    left = body.index(begin)
    return body[left:body.index(end, left)]
edits = [
    {'before': section(native_before, marker, 'static bool ggml_cuda_should_fuse_mul_mat('),
     'after': section(native_after, '// Actual carrier reads,', 'static bool ggml_cuda_should_fuse_mul_mat(')},
    {'before': section(native_before, 'static bool ggml_cuda_should_fuse_mul_mat_vec_q(', 'static bool ggml_cuda_bfloat_matvec('),
     'after': section(native_after, 'static bool ggml_cuda_should_fuse_mul_mat_vec_q(', 'static bool ggml_cuda_bfloat_matvec(')},
    {'before': section(native_before, 'static bool ggml_cuda_can_fuse(', '// BF16 fusion elides stores'),
     'after': section(native_after, 'static bool ggml_cuda_can_fuse(', '// BF16 fusion elides stores')},
    {'before': original_block, 'after': dispatch},
    {'before': 'static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {\n',
     'after': matcher + 'static int ggml_cuda_try_fuse(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph, int i) {\n'},
    {'before': '    static bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));\n    if (disable_fusion) {',
     'after': '    if (ggml_cuda_fusion_disabled()) {'},
    {'before': '    static const bool disable_fusion = getenv("GGML_CUDA_DISABLE_FUSION") != nullptr && std::atoi(getenv("GGML_CUDA_DISABLE_FUSION"));\n    if (!disable_fusion) {',
     'after': '    if (!ggml_cuda_fusion_disabled()) {'},
]
replayed = native_before
for edit in edits:
    replayed = replace(replayed, edit['before'], edit['after'])
assert replayed == native_after
(STAGE / 'replacements.json').write_text(json.dumps({'files': [{
    'path': 'src/ggml-cuda/ggml-cuda.cu',
    'before_path': str(NATIVE.relative_to(REPO)),
    'before_sha256': NATIVE_SHA,
    'after_sha256': identity(STAGE / 'source' / native_key)['sha256'],
    'edits': edits,
}]}, indent=2) + '\n', encoding='utf-8')
(STAGE / 'review.json').write_text(json.dumps({
    'state': 'Scratch-only final review; no apply, C++ compilation, GPU or performance run.',
    'scope': ['Nine existing MMVF/MMVQ call sites share one relocated matcher/result',
              'One eight-input readset feeds qualification and cold storage-root reporting',
              'Private bridge callback is (user, actual_root, original_until_node_ordinal)',
              'Invocation alone owns an allocation-only shallow graph, nodes/leafs and NONE-dep metadata',
              'reserve and first alloc_graph use that same graph; compute/capture use the original graph'],
    'preserved': ['Precision parameters, OAI alpha/limit, carrier arithmetic, original branch order and closure rules',
                  'Hot bound-pointer/alignment/padding/range/RESTRICT checks',
                  'Original execution graph nodes/order/src/usecounts/hash/flags',
                  'Upstream optimizer weighted-MoE actual-read registration; no new MoE collector or scheduler change'],
    'allocator_and_failure': ['New persistent pointer arrays use zero-inline SmallVector with Invocation AllocatorRef',
                              'Temporary deps, extra roots and hash-set buckets/nodes use StdAllocator with same AllocatorRef',
                              'In-place sort; no stable_sort hidden buffer; no added native std::vector in the collector',
                              'Counts include hidden NONE storage-root leaves; node+leaf INT32 and byte-overflow checks precede native allocation',
                              'Failure does not publish a prepared invocation; ResourceExhausted is preserved through existing bad_alloc translation',
                              'Native ggml context/gallocr malloc/assert limitations remain; not an all-OOM recoverability claim'],
    'roots': ['Normal views retain original n_views accounting; report actual storage root instead of adding children to NONE proxy aliases',
              'Unvisited roots may be added as leaves only when OP_NONE, view_src is null, and src[] is empty',
              'Extra roots precede original leaf aliases for init_tensor ordering; no invented math producer or payload copy'],
    'limits': ['Cold match is conservative; pointer/padding rejection can retain more workspace without a physical fusion',
               'Dependency liveness cannot legalize explicit inplace/restrict overlap; actual hot guard remains authoritative',
               'Allocation-only shallow graph is pinned-ggml private and must never be passed to graph traversal/compute APIs',
               'No assertion of fusion hit, speedup or runtime correctness before root validation'],
    'independent_review': {'agent': 'alias_index_audit', 'scope': 'Host allocation-plan ownership/capacity/failure semantics',
                           'resolved': ['C4267 size_t-to-int conversion fixed with checked explicit cast/max counts'],
                           'remaining_blockers_reported': 0},
    'next_compile_scope': ['One native ggml-cuda.cu; existing mmvf/mmvq/unary objects and 56-byte fusion ABI unchanged',
                           'One host ggml_cuda_provider.cc (also refreshed provider source-version identity)',
                           'Root/test agent modified stable_silu_test.cc; native_bridge.h declarations have no public ABI change'],
    'baseline_links': '.scratch/architecture-refactor-2026-10-18/recurrent-gdn-schema/checks/20261019T113131/{qwen,cuda}-link-plan.json',
    'checks_done': ['Python generator assertions', 'Exact unique replacement replay',
                    'Normalized original/relocated nine-branch source equality', 'Before snapshots are byte-identical to origins'],
}, indent=2) + '\n', encoding='utf-8')
(STAGE / 'source-freeze.json').write_text(json.dumps({
    'state': 'Scratch overlay only; not applied, compiled or executed.',
    'baseline_native_sha256': NATIVE_SHA,
    'baseline_host_plan': '.scratch/architecture-refactor-2026-10-18/recurrent-gdn-schema/checks/20261019T113131/plan.json',
    'files': receipt,
    'diff': identity(STAGE / 'changes.diff'),
    'relocation_proof': identity(STAGE / 'relocation-proof.json'),
    'replacements': identity(STAGE / 'replacements.json'),
    'review': identity(STAGE / 'review.json'),
}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(files), 'diff': identity(STAGE / 'changes.diff'),
                  'freeze': identity(STAGE / 'source-freeze.json')}, indent=2))
