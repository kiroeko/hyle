"""Run only the new allocation cases and existing layout/precision neighbours."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('allocation_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
if not c.read(plan_path.parent / 'summary.json')['passed']:
    raise ValueError('Successful incremental build required')
out = plan_path.parent / 'run-cuda'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
env, directories = b.environment(plan['links']['cuda']['command'], plan['links']['cuda']['inputs'], out)
c.save(out / 'runtime-environment.json', {'runtime_link_input_paths': plan['links']['cuda']['inputs'],
    'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
c.execute('cuda', [plan['links']['cuda']['image'], '--gtest_color=no',
    '--gtest_filter=GgmlCudaFusionAllocation.*:GgmlCudaFusionLayout.*:GgmlCudaFusionPrecision.*',
    '--gtest_output=xml:' + str(out / 'cuda.xml')], env, out)
root = ET.parse(out / 'cuda.xml').getroot()
counts = {key: int(root.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
counts['skipped'] = sum(int(row.attrib.get('skipped', '0')) for row in root.findall('testsuite'))
passed = counts['tests'] == 10 and not any(counts[key] for key in ('failures', 'disabled', 'errors', 'skipped'))
c.save(out / 'summary.json', {'passed': passed, 'counts': counts, 'physical_fusion_proof': False,
    'image': b.identity(plan['links']['cuda']['image']), 'runner': b.identity(Path(__file__))})
if not passed:
    raise ValueError('Expected10 related cases, zero failure or skip')
print('ALLOCATION_TESTS', counts, flush=True)
