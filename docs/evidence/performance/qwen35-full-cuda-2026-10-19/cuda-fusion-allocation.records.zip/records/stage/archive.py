"""Archive final v21 allocation-dependency evidence, preserving both failed builds."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T115201/plan.json'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-fusion-allocation.zip'
EXCLUDED = {'.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.dll', '.pyc'}
DOCS = (
    'docs/architecture/compute-design.md', 'docs/developer/current-work.md',
    'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md',
)
SUPPORT = (
    'recurrent-gdn-schema/build.py', 'immutable-alias-index/build.py',
    'cuda-fusion-precision/build.py', 'cuda-fusion-layout/build.py',
    'cuda-gdn-l2-epilogue/build.py', 'cuda-explicit-rope/build.py',
    'cuda-bf16-dual-projection/build_current.py', 'cuda-projection-fusion/build.py',
    'cold-constant-retirement/cold_check.py', 'cuda-bf16-dual-projection/compare_numerics.py',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def verify(row):
    if identity(row['path']) != row:
        raise ValueError('Retained source/evidence identity drift: ' + row['path'])
    return Path(row['path']).resolve()


def main():
    if DEST.exists():
        raise ValueError('Archive exists; refusing replacement')
    plan = read(PLAN)
    freeze = read(STAGE / 'native-source-freeze.json')
    reviewed = read(STAGE / 'source-freeze.json')
    application = read(STAGE / 'application.json')
    if freeze['source_id'] != '52e46f2bb4908ab3' or plan['native_source_id'] != freeze['source_id']:
        raise ValueError('Expected tested corrected v21 source identity')
    if plan['native_TUs'] != 1 or plan['host_TUs'] != 2:
        raise ValueError('Expected the measured one-native/two-host closure')
    for relative, expected in freeze['sources'].items():
        if identity(STAGE / 'native-source' / relative)['sha256'] != expected:
            raise ValueError('Corrected sealed native source differs')
    for row in reviewed['files']:
        verify(row['before'])
        verify(row['after'])
        if row['target'].startswith('native/'):
            actual = identity(STAGE / 'native-source' / row['target'][len('native/'):])
        else:
            actual = identity(ROOT / row['target'])
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Reviewed applied source differs: ' + row['target'])
    for row in application['applied']:
        if identity(row['target'])['sha256'] != row['after_sha256']:
            raise ValueError('Applied product drift')
    tests = read(STAGE / 'tests-source-freeze.json')
    verify(tests['after'])
    if identity(ROOT / 'tests/graph_route_cuda/stable_silu_test.cc')['sha256'] != tests['after']['sha256']:
        raise ValueError('Tested stable test source drift')

    failed = []
    for stamp, tag in (('20261019T115026', 'ggml-cuda-compile'), ('20261019T115115', 'provider-compile')):
        result = STAGE / 'checks' / stamp / (tag + '.result.json')
        row = read(result)
        if not row.get('terminal') or row.get('exit') == 0:
            raise ValueError('Missing original terminal compiler failure')
        failed.append({'result': identity(result), 'exit': row['exit']})
    correction = read(STAGE / 'source-correction-review.json')
    if not correction['first_failure']['correction']['exactly_one_reference_replacement_verified']:
        raise ValueError('Missing explicit correction/proof boundary')
    old = (STAGE / 'before-index-correction/ggml-cuda.cu').read_bytes()
    current = (STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu').read_bytes()
    if old.count(b'bias_node->src[2] != ids') != 1 or old.replace(
            b'bias_node->src[2] != ids', b'bias_node->src[2] != mm_node->src[2]', 1) != current:
        raise ValueError('Original-reference correction does not match the final native bytes')

    files, expected_payloads = [], {}
    for row in plan['frozen']:
        path = verify(row)
        if path.is_relative_to(STAGE) or path.suffix.lower() in EXCLUDED:
            continue
        if not path.is_relative_to(ROOT):
            raise ValueError('Unexpected non-workspace frozen text')
        name = 'tested-inputs/' + path.relative_to(ROOT).as_posix()
        files.append((name, path))
        expected_payloads[name] = row
    closure_path = ARCH / 'cuda-fusion-precision/header-closure.json'
    closure = read(closure_path)
    if closure['header_count'] != 89:
        raise ValueError('Expected reused coherent89-header receipt')
    for row in closure['headers']:
        path = ARCH / 'cuda-fusion-precision/native-source' / row['path']
        if identity(path)['sha256'] != row['sha256']:
            raise ValueError('Reused coherent header differs')
        name = 'tested-inputs/' + path.relative_to(ROOT).as_posix()
        if name not in expected_payloads:
            raise ValueError('Coherent header not frozen in successful plan')

    build = read(PLAN.parent / 'summary.json')
    checks = read(PLAN.parent / 'run-cuda/summary.json')
    model = read(STAGE / 'correctness/summary.json')
    profile = read(STAGE / 'profile-tests/analysis.json')
    if not all(row['passed'] for row in (build, checks, model, profile)):
        raise ValueError('Missing successful final observations')
    if checks['counts'] != {'tests': 10, 'failures': 0, 'disabled': 0, 'errors': 0, 'skipped': 0}:
        raise ValueError('Expected10 related cases without failures/skips')
    if model['observation']['equal_vectors'] != 64 or not model['observation']['all_outputs_finite']:
        raise ValueError('Expected64 exact finite full-model vectors')
    if not profile['full_GLU_observed_for_all_six_candidates'] or (
            profile['observed_fused_MMVF'], profile['observed_unfused_MMVF'], profile['observed_standalone_OAI_GLU']) != (6, 12, 6):
        raise ValueError('Unexpected actual physical GLU observation')
    images = {}
    for arm, count in (('cuda', 133), ('qwen', 125)):
        link = read(PLAN.parent / (arm + '-link-plan.json'))
        if len(link['inputs']) != count or len({key(row['path']) for row in link['inputs']}) != count:
            raise ValueError('Actual latest link closure differs')
        images[arm] = read(PLAN.parent / (arm + '-image.json'))
        verify(images[arm])
    for row in plan['compile']:
        verify(row['source'])
        verify(read(PLAN.parent / (row['tag'] + '-identity.json'))['object'])

    profile_analysis = read(STAGE / 'profile-tests/inputs.json')['analysis']
    path = verify(profile_analysis)
    files.append(('analysis-support/' + path.relative_to(ROOT).as_posix(), path))
    for relative in SUPPORT:
        path = ARCH / relative
        files.append(('replay-support/' + path.relative_to(ROOT).as_posix(), path))
    for relative in ('src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
                     'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py',
                     'third_party/ggml_cuda_runtime/iq1-patches.json'):
        path = ROOT / relative
        files.append(('replay-support/' + relative, path))
    files.extend(('documentation/' + relative, ROOT / relative) for relative in DOCS)
    if (ROOT / 'test.ps1').is_file():
        files.append(('cleanup-plan/test.ps1', ROOT / 'test.ps1'))

    scope = {
        'source_id': freeze['source_id'], 'plan_sha256': sha(PLAN.read_bytes()),
        'tested_images': images, 'native_TUs': 1, 'host_TUs': 2,
        'actual_link_inputs': {'cuda': 133, 'qwen': 125},
        'reused_coherent_header_count': 89,
        'tests': 10, 'model_equal_vectors': 64,
        'physical_raw_GLU': {'fused_MMVF': 6, 'unfused_oracle_MMVF': 12, 'standalone_oracle_OAI_GLU': 6},
        'first_two_failed_compiler_results': failed,
        'source_correction_review': identity(STAGE / 'source-correction-review.json'),
        'normalized_source_proof_is_not_def_use_or_semantic_proof': True,
        'CMake_change_scope': 'Two tested CMake targets mark only third-party GGML src includes SYSTEM; Hyle /W4 and /WX remain enabled.',
        'documentation_context': list(DOCS),
        'support_scripts_scope': 'Only scripts referenced by actual build/numerical/profile/seal runners, hashed in the payload manifest; not additional tested product changes.',
        'cleanup_scripts_are_unexecuted_plans_at_archive_time': True,
        'other_agent_batch_reset_drafts_included': False,
        'historical_pre_correction_records_are_preserved_with_their_original_source_ids': True,
        'SDK_models_binary_cache_maps_tmp_excluded': True,
        'throughput_claim': False,
    }
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8', newline='\n')
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if not path.is_file() or 'tmp' in path.relative_to(STAGE).parts or path.suffix.lower() in EXCLUDED:
            continue
        if path.name == 'archive-verification.json':
            raise ValueError('Unexpected old archive receipt')
        files.append(('stage/' + path.relative_to(STAGE).as_posix(), path))
    if len({name for name, _ in files}) != len(files):
        raise ValueError('Duplicate archive entry')
    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in files:
            data = path.read_bytes()
            record = {'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)}
            expected = expected_payloads.get(name)
            if expected and (record['bytes'], record['sha256']) != (expected['bytes'], expected['sha256']):
                raise ValueError('Frozen file changed while archiving')
            records.append(record)
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC failure')
        if len(archive.namelist()) != len(records) + 1:
            raise ValueError('Archive entry count differs')
        for row in records:
            data = archive.read(row['entry'])
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError('Payload SHA or size differs')
        if any(Path(name).suffix.lower() in EXCLUDED or 'tmp' in Path(name).parts for name in archive.namelist()):
            raise ValueError('Excluded binary/map/tmp in archive')
    receipt = {
        'path': str(DEST), 'sha256': sha(DEST.read_bytes()), 'bytes': DEST.stat().st_size,
        'payloads': len(records), 'entries_including_manifest': len(records) + 1,
        'uncompressed_payload_bytes': sum(row['bytes'] for row in records),
        'CRC_and_every_payload_SHA_verified': True,
        'source_id': freeze['source_id'], 'coherent_header_count': 89,
        'failed_compiler_records_preserved': 2,
        'source_correction_and_normalized_proof_limit_documented': True,
        'tests': 10, 'model_equal_vectors': 64, 'physical_full_GLU_candidates': 6,
        'SDK_models_objects_executables_maps_tmp_excluded': True,
        'other_unapplied_agent_drafts_excluded': True,
    }
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text, encoding='utf-8', newline='\n')
    DEST.with_name('cuda-fusion-allocation-archive.json').write_text(text, encoding='utf-8', newline='\n')
    print(text, flush=True)


if __name__ == '__main__':
    main()
