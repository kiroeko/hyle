"""Prepare only the existing stable_silu TU test overlay; do not apply/build/run."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
RELATIVE = 'tests/graph_route_cuda/stable_silu_test.cc'


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


before = ROOT / RELATIVE
text = before.read_text(encoding='utf-8')
assert 'namespace native_fusion_allocation_test' not in text
marker = '#include <ggml-alloc.h>\n'
assert text.count(marker) == 1
after_text = text.replace(marker, marker + '#include <ggml-impl.h>\n', 1)
fragment = STAGE / 'allocation-tests.inc'
after_text += fragment.read_text(encoding='utf-8')
target = STAGE / 'test-overlay' / RELATIVE
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(after_text, encoding='utf-8', newline='\n')
diff = STAGE / 'tests-change.diff'
diff.write_text(''.join(difflib.unified_diff(text.splitlines(True), after_text.splitlines(True),
    fromfile='a/' + RELATIVE, tofile='b/' + RELATIVE)), encoding='utf-8', newline='\n')
receipt = {
    'state': 'Scratch-only test overlay; not applied, compiled or executed.',
    'before': identity(before), 'after': identity(target), 'fragment': identity(fragment), 'diff': identity(diff),
    'tests': [
        'GgmlCudaFusionAllocation.MatmulBiasUsesUnpublishedStorageRoots',
        'GgmlCudaFusionAllocation.FullGluUsesUnpublishedStorageRoots',
        'GgmlCudaFusionAllocation.ExplicitOutputOverlapKeepsOriginalRangeGuards',
        'GgmlCudaFusionAllocation.ProviderMeasuredWorkspaceBindsInternalProducerAndReplays',
    ],
    'bridge_signature': 'void collect_allocation_dependencies(ggml_backend*, ggml_cgraph*, void(*)(void*,ggml_tensor* root,int until_node),void*)',
    'native_input_OUTPUT_used': False,
    'oracle_OUTPUT_scope': 'Original mathematical MM/ADD intermediates only; never mathematical source roots.',
    'NONE_view_root_ownership': 'A real external native buffer is prebound; ordinary allocator VIEW accounting is not fabricated.',
    'allocator_graph_scope': 'Private bridge metadata is consumed only by gallocr. Original execution graph nodes/src/readers are checked unchanged and are the sole graph submitted.',
    'public_provider_scope': 'Only final output is published. An internal dynamic Copy producer feeds two MatMuls+bias+separate SwiGLU, two invocations rebind twice in command/capture modes. Exact Graph workspace budget succeeds, one-byte-short budget declines.',
    'physical_claim': False,
    'trace_plan': {
        'MatmulBiasUsesUnpublishedStorageRoots': '6 candidate MM+ADD runs, each should need one true fused carrier; their ordinary oracle MM outputs are published.',
        'FullGluUsesUnpublishedStorageRoots': '6 candidate GLU spans: a full GLU uses6 true carriers, partial MM+ADD-only uses12. Trace this exact test alone to distinguish them.',
        'ExplicitOutputOverlapKeepsOriginalRangeGuards': '2 explicit native output/bias alias candidates retain ordinary math and must not use a full GLU carrier; partial MM+ADD carriers remain permitted.',
        'limits': 'These are source predictions, not observed physical fusion. Official CSV/SQLite must determine the actual result. Do not infer a full GLU from a logical node list or has_fusion=true alone.',
    },
    'host_recipe_requirement': 'Fresh stable-test command must add v20 coherent native-source/src before old GGML paths for ggml-impl.h, and coherent native-source/include first for matching public GGML declarations.',
    'unrun': ['C++ compilation', 'GPU tests', 'workspace budget behavior', 'Nsight physical trace'],
}
(STAGE / 'tests-source-freeze.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'after': receipt['after'], 'receipt': identity(STAGE / 'tests-source-freeze.json')}))
