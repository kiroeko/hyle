"""Thin offline reuse of the retained stable-SiLU SQLite analysis functions.

Supply this round's trace stem, launch receipts and final image SHA explicitly.
Writes only profile-analysis* records in this stage; never starts GPU/tools.
"""
from pathlib import Path
import argparse
import bisect
import collections
import importlib.util
import json
import re
import sqlite3
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
PRIOR = STAGE.parent / "cuda-stable-silu"
spec = importlib.util.spec_from_file_location("retained_stable_silu_analysis", PRIOR / "profile-analysis-stable.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def embedded_records(path):
    con = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    try:
        diagnostics = [dict(row) for row in con.execute("select * from DIAGNOSTIC_EVENT")]
        streams = list(con.execute("select a.filename,s.value,a.globalPid from ANALYSIS_FILE a "
                                  "join StringIds s on s.id=a.contentId"))
    finally:
        con.close()
    path = STAGE / "profile-analysis-diagnostics.json"
    a.save(path, diagnostics)
    result = dict(diagnostics=a.identity(path), target_logs={})
    for kind in ("stdout", "stderr"):
        selected = [row for row in streams if "/streams/" in row[0].replace("\\", "/")
                    and ("stderr_" in row[0]) == (kind == "stderr")]
        path = STAGE / ("profile-analysis-target-" + kind + ".log")
        path.write_text("\n".join(row[1] for row in selected), encoding="utf-8")
        result["target_logs"][kind] = dict(receipt=a.identity(path),
            sources=[dict(filename=row[0], globalPid=row[2]) for row in selected])
    return result


def per_phase_other_changes(candidate, baseline, cp, bp):
    if len(cp["phases"]) != 32 or len(bp["phases"]) != 32:
        return None
    def counters(data, phases):
        ends = [row["token_D2H_end_ns"] for row in phases["phases"]]
        rows = [collections.Counter() for _ in ends]
        for kernel in data["kernels"]:
            index = bisect.bisect_left(ends, kernel["start"])
            if index < len(rows):
                rows[index][kernel["name"]] += 1
        return rows
    result = []
    for index, (current, old) in enumerate(zip(counters(candidate, cp), counters(baseline, bp))):
        result.append(dict(phase="prefill" if index == 0 else "decode" + str(index),
            changes=[dict(name=name, baseline=old[name], candidate=current[name])
                     for name in sorted(current.keys() | old.keys())
                     if current[name] != old[name] and a.classify(name)["family"] == "other"]))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace-stem", type=Path, required=True, help="Path without .sqlite or .nsys-rep")
    parser.add_argument("--inputs", type=Path, required=True, help="This trace's captured image/command receipt")
    parser.add_argument("--result", type=Path, required=True, help="This nsys process's terminal result")
    parser.add_argument("--image-sha256", required=True, help="Final candidate SHA announced for this round")
    parser.add_argument("--metrics", type=Path, required=True, help="This candidate's unprofiled correctness metrics")
    parser.add_argument("--performance", type=Path, default=STAGE / "performance-summary.json")
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-fA-F]{64}", args.image_sha256):
        parser.error("--image-sha256 requires64 hexadecimal characters")
    sqlite_path = Path(str(args.trace_stem) + ".sqlite")
    csv_path = Path(str(args.trace_stem) + "_cuda_gpu_kern_sum.csv")
    baseline_stem = PRIOR / "profile/qwen-stable-silu-trace"
    candidate = a.load(sqlite_path, csv_path, candidate=False)
    baseline = a.load(Path(str(baseline_stem) + ".sqlite"),
                      Path(str(baseline_stem) + "_cuda_gpu_kern_sum.csv"), candidate=False)
    cp, bp = a.phases(candidate), a.phases(baseline)
    inputs, terminal, metrics = a.read(args.inputs), a.read(args.result), a.read(args.metrics)
    current, old = candidate["target"]["output"], baseline["target"]["output"]
    checks = dict(candidate_phase_binning_valid=cp["valid"], baseline_phase_binning_valid=bp["valid"],
        candidate_csv_sqlite_equal=candidate["receipt"]["csv_sqlite_per_symbol_counts_equal"],
        baseline_csv_sqlite_equal=baseline["receipt"]["csv_sqlite_per_symbol_counts_equal"],
        profiler_terminal_zero=terminal.get("terminal") is True and terminal.get("exit") == 0,
        bound_to_announced_candidate=inputs.get("image", {}).get("sha256", "").lower() == args.image_sha256.lower(),
        target_pid_found=bool(candidate["receipt"]["target_pids"]),
        graph_api_returns_zero=not candidate["receipt"]["graph_api_failures"],
        target_has_32_ids=bool(current and len(current.get("generated_ids", [])) == 32),
        target_has_31_fixed_decode_inputs=bool(current and len(current.get("decode_input_ids", [])) == 31),
        generated_ids_match_stable_baseline=bool(current and old and current["generated_ids"] == old["generated_ids"]),
        fixed_decode_inputs_match_stable_baseline=bool(current and old and current["decode_input_ids"] == old["decode_input_ids"]),
        source_id_matches_stable_baseline=bool(current and old and current.get("source_id") == old.get("source_id")),
        generated_ids_match_unprofiled_current=bool(current and current["generated_ids"] == metrics.get("ids")))
    records = embedded_records(sqlite_path)
    templates_path = STAGE / "profile-analysis-templates.json"
    a.save(templates_path, dict(candidate=a.template_inventory(candidate), baseline=a.template_inventory(baseline)))
    performance = dict(available=args.performance.is_file(), profiled_timings_used_for_speed=False)
    if args.performance.is_file():
        performance.update(receipt=a.identity(args.performance), unprofiled_summary=a.read(args.performance))
    report = dict(schema="hyle.reshape_reuse.profile_analysis.v1",
        status="official_exports_analysed" if all(checks.values()) else "evidence_incomplete_or_structural_check_failed",
        checks=checks, failed_checks=[key for key, passed in checks.items() if not passed],
        reused_analyzer=a.identity(PRIOR / "profile-analysis-stable.py"),
        candidate=dict(receipt=candidate["receipt"], phases=cp, target=candidate["target"],
            nsys_process=terminal, inputs_receipt=a.identity(args.inputs), bound_image=inputs.get("image"),
            unprofiled_metrics_receipt=a.identity(args.metrics), embedded_records=records),
        baseline=dict(receipt=baseline["receipt"], phases=bp, target=baseline["target"],
            profile_inputs_receipt=a.identity(PRIOR / "profile-qwen-stable-silu-inputs.json")),
        comparison=a.compare(candidate, baseline, cp, bp),
        per_phase_other_kernel_changes=per_phase_other_changes(candidate, baseline, cp, bp),
        templates=a.identity(templates_path), performance=performance,
        expected_but_not_asserted="Prefill may acquire18 F32 stable-SiLU Mul true-template invocations. Report actual dtype, standalone, conversion and total changes; neither18 hits nor a fixed total count is a pass condition.",
        boundaries=["Baseline is the retained final stable-SiLU physical trace, not the older1794-kernel baseline.",
            "Deleted old executables are not required or reopened. The retained baseline image receipt and trace establish comparison identity; the newly linked baseline may have a different binary SHA despite the same object closure.",
            "Logical regions and7 GraphLaunch calls do not prove physical fusion; full stable-helper/dtype/round_unary template identity and invocation counts are reported.",
            "Unrelated conversions or math routes may change; compare all32 phase symbol counts, not only the net kernel reduction.",
            "Numeric equality requires this round's directed tests and exact output comparisons. Speed conclusions use this round's unprofiled pairs only."],
        additional_compilation=False, additional_GPU_execution=False, additional_profiling=False)
    output = STAGE / "profile-analysis-summary.json"
    a.save(output, report)
    print(json.dumps(dict(summary=a.identity(output), status=report["status"], checks=checks,
        prefill_candidate=cp["phases"][0] if cp["phases"] else None,
        prefill_baseline=bp["phases"][0] if bp["phases"] else None,
        warm_delta=report["comparison"]["warm_phase_delta"]), indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
