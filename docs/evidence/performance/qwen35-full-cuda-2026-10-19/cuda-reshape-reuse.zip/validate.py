"""Two host TUs and cached closures. No SDK/native rebuild or object copy."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import statistics
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
ROOT = ARCH.parents[1]
PRIOR = ARCH / 'cuda-stable-silu'
spec = importlib.util.spec_from_file_location('reshape_build', ARCH / 'cuda-bf16-chain-fusion/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
sys.modules['build'] = b
spec = importlib.util.spec_from_file_location('reshape_runs', ARCH / 'cuda-bf16-chain-fusion/run.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)

def compile_host(tag):
    source = ROOT / ('src/compute_provider_ggml_cuda/tensor_program.cc'
                     if tag == 'tensor' else 'tests/graph_route_cuda/stable_silu_test.cc')
    original = b.read(PRIOR / (tag + '-identity.json'))
    argv, skip = [], False
    for arg in original['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
        elif not (arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith('.cc')):
            argv.append(arg)
    argv += ['/sourceDependencies', str(OUT / (tag + '-deps.json')), str(source),
             '/Fo' + str(OUT / (tag + '.obj')), '/Fd' + str(OUT / (tag + '.pdb'))]
    before = b.ident(source)
    b.execute(tag + '-compile' + args.suffix, argv)
    assert b.ident(source) == before
    b.save(tag + '-identity.json', dict(source=before, object=b.ident(OUT / (tag + '.obj')), command=argv))

def link(name):
    original = b.read(PRIOR / (('cuda-tests' if name == 'cuda-tests' else 'candidate') + '-link-plan.json'))
    for row in original['inputs']:
        assert row == b.ident(row['path']), 'Cached input changed: ' + row['path']
    argv = original['command']
    replacements = {} if name == 'baseline' else {str(PRIOR / 'tensor.obj'): str(OUT / 'tensor.obj')}
    if name == 'cuda-tests':
        replacements[str(PRIOR / 'stable-test.obj')] = str(OUT / 'stable-test.obj')
    assert all(argv.count(path) == 1 for path in replacements)
    argv = [replacements.get(arg, arg) for arg in argv
            if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    argv += ['/OUT:' + str(OUT / (name + '.exe')), '/MAP:' + str(OUT / (name + '.map')),
             '/IMPLIB:' + str(OUT / (name + '.lib'))]
    inputs = [b.ident(arg) for arg in argv if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
    b.save(name + '-link-plan.json', dict(command=argv, inputs=inputs,
        compared_to=b.ident(PRIOR / 'candidate-link-plan.json'), replacements=replacements,
        SDK_rebuild=False, native_rebuild=False, object_copy=False))
    b.execute(name + '-link' + args.suffix, argv)
    b.save(name + '-image.json', dict(image=b.ident(OUT / (name + '.exe')),
        link_plan=b.ident(OUT / (name + '-link-plan.json'))))

def tests():
    assert args.filter
    r.image('cuda-tests')
    tag = 'directed-tests' + args.suffix
    b.execute(tag, [OUT / 'cuda-tests.exe', '--gtest_color=no', '--gtest_filter=' + args.filter,
                   '--gtest_output=xml:' + str(OUT / (tag + '.xml'))])
    root = ET.parse(OUT / (tag + '.xml')).getroot()
    cases = root.findall('.//testcase')
    assert cases and not root.findall('.//failure') and not root.findall('.//skipped')
    assert not any(mark in args.filter for mark in '*?-')
    assert len(cases) == len(args.filter.split(':'))
    b.save(tag + '-summary.json', dict(count=len(cases), failures=0, skipped=0,
        cases=[p.attrib['classname']+'.'+p.attrib['name'] for p in cases]))

def verify():
    before = PRIOR / 'correctness-candidate-preferred/trace'
    after = OUT / 'correctness-candidate/trace'
    paths = [sorted(p.relative_to(root) for p in root.rglob('*') if p.suffix in ('.bf16', '.f32'))
             for root in (before, after)]
    assert len(paths[0]) == 64 and paths[0] == paths[1]
    rows = []
    for path in paths[0]:
        a, c = b.ident(before / path), b.ident(after / path)
        assert a['bytes'] == c['bytes'] and a['sha256'] == c['sha256'], path
        rows.append(dict(path=path.as_posix(), bytes=c['bytes'], sha256=c['sha256']))
    a, c = [b.read(root / (name + '-metrics.json')) for root, name in (
        (PRIOR, 'correctness-candidate-preferred'), (OUT, 'correctness-candidate'))]
    assert a['ids'] == c['ids'] and len(c['ids']) == 32
    assert a['capture_counts'] == c['capture_counts']
    image = r.image('candidate')
    assert b.read(OUT / 'correctness-candidate-inputs.json')['image'] == image
    old_image = b.read(PRIOR / 'correctness-candidate-preferred-inputs.json')['image']
    b.save('correctness-summary.json', dict(vectors=dict(files=64, equal_files=64, manifest=rows),
        IDs_equal=True, capture_counts_equal=True, candidate=image, prior_probe=old_image,
        comparison='Retained stable-silu probe; current baseline uses exactly that source/object closure.',
        scope='128 prompt+31 fixed decode; final hidden BF16/logits F32, not independent quality acceptance.'))
    print('Exact64/64 hidden/logits and32IDs; captures identical.', flush=True)

def performance():
    proof = b.read(OUT / 'correctness-summary.json')
    assert proof['vectors']['files'] == proof['vectors']['equal_files'] == 64
    expected = b.read(OUT / 'correctness-candidate-metrics.json')['ids']
    order = ('baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate')
    b.save('performance-plan.json', dict(order=order, prompt=128, decode=31, capacity=256,
        full_step=True, profiler=False, memory_monitor=False))
    runs = []
    for i, arm in enumerate(order, 1):
        row = r.trial(f'perf-{i:02d}-{arm}', arm)
        assert row['ids'] == expected
        runs.append(row)
        b.save('performance-results.json', dict(runs=runs, remaining=len(order)-len(runs)))
    keys = ('prefill_tokens_per_second', 'full31_tokens_per_second', 'warm7_31_tokens_per_second')
    groups = {arm:{key:dict(samples=[p[key] for p in runs if p['arm'] == arm],
        median=statistics.median(p[key] for p in runs if p['arm'] == arm)) for key in keys}
        for arm in ('baseline', 'candidate')}
    ratios = {key:groups['candidate'][key]['median']/groups['baseline'][key]['median'] for key in keys}
    b.save('performance-summary.json', dict(groups=groups, ratios=ratios,
        statistical_significance=False, IDs_equal=True, quality_acceptance=False))
    print(json.dumps(dict(groups=groups, ratios=ratios)), flush=True)

def profile(mode):
    nsys = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
    (OUT / 'profile').mkdir(exist_ok=True)
    stem = OUT / 'profile/qwen-reshape-trace'
    if mode == 'profile':
        image = r.image('candidate')
        target = b.read(OUT / 'perf-02-candidate.command.json')['command']
        assert target[0] == image['path'] and '--trace' not in target
        argv = [str(nsys), 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
                '--cuda-graph-trace=node:host-only', '--discard-environment=true', '--output=' + str(stem), *target]
        b.save('profile-inputs.json', dict(image=image, link_plan=b.ident(OUT / 'candidate-link-plan.json'),
            target=target, correctness=b.ident(OUT / 'correctness-summary.json'),
            performance=b.ident(OUT / 'performance-summary.json'), memory_monitor=False,
            use_profiled_timings_for_speed=False))
    elif mode == 'export':
        argv = [str(nsys), 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep']
    else:
        argv = [str(nsys), 'stats', '--report', 'cuda_api_sum,cuda_gpu_kern_sum', '--format', 'csv',
                '--output=' + str(stem), str(stem) + '.nsys-rep']
    b.execute(mode + '-qwen', argv)

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('compile','link','tests','qwen','verify','performance','profile','export','stats'))
parser.add_argument('names', nargs='*')
parser.add_argument('--filter')
parser.add_argument('--suffix', default='')
args = parser.parse_args()
if args.mode in ('compile','link','qwen'):
    assert args.names
    for name in args.names:
        if args.mode == 'compile': compile_host(name)
        elif args.mode == 'link': link(name)
        else: r.trial('correctness-' + name, name, trace=True)
elif args.mode == 'tests': tests()
elif args.mode == 'verify': verify()
elif args.mode == 'performance': performance()
else: profile(args.mode)
