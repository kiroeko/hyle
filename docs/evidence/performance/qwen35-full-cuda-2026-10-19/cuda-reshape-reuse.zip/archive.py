"""Verify compact evidence and prepare exact image cleanup, never delete."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
DOC=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
OUT=DOC/'cuda-reshape-reuse.zip'
def ident(p):
    raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
for row in json.loads((STAGE/'source-freeze.json').read_text())['files']:
    current=ident(ROOT/row['path'])
    assert all(current[k]==row[k] for k in ('bytes','sha256'))
images=[ident(STAGE/(arm+ext)) for arm in ('baseline','candidate','cuda-tests')
        for ext in ('.exe','.map','.lib','.exp')]
objects=[ident(STAGE/(tag+'.obj')) for tag in ('tensor','stable-test')]
traces=[ident(STAGE/'profile'/('qwen-reshape-trace'+ext)) for ext in ('.nsys-rep','.sqlite')]
save(STAGE/'image-artifacts.json',dict(files=images,retained_objects=objects,retained_traces=traces))
old=DOC/'cuda-stable-silu.zip'
references=[]
with zipfile.ZipFile(old) as archive:
    for phase in ('prefill','decode31'):
        for name in ('hidden.bf16','logits.f32'):
            key='correctness-baseline/trace/'+phase+'/'+name
            raw=archive.read(key)
            current=ident(STAGE/'correctness-candidate/trace'/phase/name)
            assert len(raw)==current['bytes'] and hashlib.sha256(raw).hexdigest()==current['sha256']
            references.append(dict(archive_entry=key,**current))
save(STAGE/'vector-reference.json',dict(archive=ident(old),representative_vectors=references,
    all64_hashes='correctness-summary.json',all64_originals_retained=True))
files={}
def add(p,key=None):
    if p.is_file():
        key=key or p.relative_to(STAGE).as_posix()
        assert key not in files
        files[key]=p
for p in STAGE.iterdir():
    if p.is_file() and p.suffix in ('.py','.json','.log','.diff','.cc','.xml') and p.name not in (
        'archive-result.json','cleanup-plan.json','cleanup-receipt.json','live.json'):
        add(p)
for directory in ('final-source','profile','correctness-candidate/trace/routes'):
    for p in sorted((STAGE/directory).rglob('*')):add(p)
for name in ('build.py','run.py'):
    add(ARCH/'cuda-bf16-chain-fusion'/name,'references/helpers/'+name)
add(ARCH/'cuda-stable-silu/profile-analysis-stable.py','references/profile-analysis-stable.py')
for name in ('docs/architecture/compute-design.md','docs/implementation/model-operators.md',
             'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
    add(ROOT/name,'current-docs/'+name)
manifest={key:ident(p) for key,p in sorted(files.items())}
assert not OUT.exists()
with zipfile.ZipFile(OUT,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for key,p in sorted(files.items()):archive.write(p,key)
    archive.writestr('payload-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for key,row in manifest.items():
        raw=archive.read(key)
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
result=dict(archive=ident(OUT),payload_files=len(files),CRC_and_SHA_verified=True,
    sources_unchanged=True,images_SDK_and_weights_copied=False)
save(STAGE/'archive-result.json',result)
save(STAGE/'cleanup-plan.json',dict(archive=result['archive'],files=images,
    retain_objects=objects,retain_traces=traces,retained_raw_vector_files=64,
    total_bytes=sum(row['bytes'] for row in images)))
print(json.dumps(result),flush=True)
