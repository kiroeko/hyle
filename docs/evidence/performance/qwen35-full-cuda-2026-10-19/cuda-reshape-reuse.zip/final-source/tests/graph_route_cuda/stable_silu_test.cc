#include "hyle/graph/cuda.h"
#include "hyle/graph/providers/ggml_cuda.h"

#include "../compute_provider_ggml_cuda/tensor_test_support.h"
#include "../graph_provider_ggml_cuda/region_test_support.h"
#include "hyle/compute/providers/cublas.h"
#include "hyle/compute/providers/cuda.h"

#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <limits>
#include <type_traits>
#include <utility>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
using BF16 = hyle::simd::bfloat16_t;
using hyle::mem::Buffer;
using ggml_cuda_tensor_test::dense;
using ggml_cuda_tensor_test::output_buffer;
using ggml_cuda_tensor_test::upload;
constexpr std::int64_t kWidth = 32, kInner = 8;

// Independent FP64 reference: in particular, exp(+100) is never evaluated,
// and ordinary Unary's limiting value at -infinity is positive zero.
double stable_silu(double x) {
  if (x == -std::numeric_limits<double>::infinity())
    return 0.0;
  const double e = std::exp(-std::abs(x));
  return x * (x >= 0 ? 1.0 / (1.0 + e) : e / (1.0 + e));
}

template <class T> T activated(T x) {
  return half_test::encode<T>(static_cast<float>(stable_silu(half_test::decode(x))));
}

template <class T> T multiplied(T x, T y) {
  return half_test::encode<T>(static_cast<float>(half_test::decode(x)) *
                              static_cast<float>(half_test::decode(y)));
}

template <class T> void expect_value(T actual, T expected) {
  const auto a = half_test::decode(actual), e = half_test::decode(expected);
  if (std::isnan(e)) {
    EXPECT_TRUE(std::isnan(a));
  } else if constexpr (std::is_same_v<T, BF16>) {
    EXPECT_EQ(actual.bits, expected.bits);
  } else if (std::isinf(e) || e == 0.0) {
    EXPECT_EQ(std::bit_cast<std::uint32_t>(actual),
              std::bit_cast<std::uint32_t>(expected));
  } else {
    // expf's subnormal rounding is magnified by |x| in the negative tail.
    // This budget covers it while still rejecting zero for our -80..-100
    // samples; the independent SGLang comparison below is bit-exact.
    EXPECT_NEAR(a, e, std::abs(e) * 3e-6 +
                          256.0 * std::numeric_limits<float>::denorm_min());
  }
}

template <class T>
void check(const Buffer &buffer, const std::vector<T> &expected) {
  const auto actual = half_test::read<T>(buffer);
  ASSERT_EQ(actual.size(), expected.size());
  for (std::size_t i = 0; i < actual.size(); ++i) {
    SCOPED_TRACE(i);
    expect_value(actual[i], expected[i]);
  }
}

template <class T>
void unchanged(const Buffer &buffer, const std::vector<T> &snapshot) {
  const auto actual = half_test::read<T>(buffer);
  ASSERT_EQ(actual.size(), snapshot.size());
  for (std::size_t i = 0; i < actual.size(); ++i) {
    if constexpr (std::is_same_v<T, BF16>)
      EXPECT_EQ(actual[i].bits, snapshot[i].bits) << i;
    else
      EXPECT_EQ(std::bit_cast<std::uint32_t>(actual[i]),
                std::bit_cast<std::uint32_t>(snapshot[i])) << i;
  }
}

template <class T>
void direct_result(c::Provider provider, const std::vector<T> &host,
                   std::vector<T> &observed) {
  auto context = c::Context::create(c::cuda::device(0).value(), provider).value();
  auto memory = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice).value();
  const auto description = dense(half_test::data_type<T>(), {1, kWidth});
  auto input = upload<T>(memory.ref(), host);
  auto output = output_buffer(memory.ref(), description);
  const auto source = c::ConstTensorView::create(description, input.view()).value();
  const auto destination = c::TensorView::create(description, output.view()).value();
  auto prepared = c::prepare(context, c::Unary{c::UnaryKind::kSilu},
                             description, memory.ref());
  ASSERT_TRUE(prepared) << prepared.error().message();
  EXPECT_EQ(prepared->provider().id, provider.identity().id);
  auto workspace = ggml_cuda_test::workspace_buffer(*prepared, memory.ref());
  auto queue = context.create_queue().value();
  auto invocation = prepared->create_invocation(workspace.view()).value();
  auto done = invocation.submit(queue, source, destination);
  ASSERT_TRUE(done) << done.error().message();
  ASSERT_TRUE(done->wait().ok());
  observed = half_test::read<T>(output);
}

template <class T> void direct() {
  SCOPED_TRACE(int(half_test::data_type<T>()));
  const float inf = std::numeric_limits<float>::infinity();
  const std::array<float, kWidth> values{
      -100, -96, -94, -92, -90, -88, -86, -84, -82, -80,
      -inf, inf, std::numeric_limits<float>::quiet_NaN(), 0.0F, -0.0F,
      -7.8125F, -4.125F, -3.5F, -2.25F, -1.0F, -0.25F, 0.125F,
      0.5F, 0.875F, 1.125F, 2.25F, 4.125F, 8.0F, 20.0F, 32.0F, 80, 100};
  std::vector<T> host;
  for (const auto value : values)
    host.push_back(half_test::encode<T>(value));
  std::vector<T> native, mature;
  direct_result(c::ggml_cuda::provider(), host, native);
  direct_result(c::cuda_native::sglang_provider(), host, mature);
  ASSERT_EQ(native.size(), host.size());
  ASSERT_EQ(mature.size(), host.size());
  for (std::size_t i = 0; i < host.size(); ++i) {
    SCOPED_TRACE(i);
    expect_value(native[i], activated(host[i]));
    // Compare the new marked native path with the existing precise SGLang
    // ordinary Unary branch, never its separately specified packed gate.
    if (std::isnan(half_test::decode(mature[i]))) {
      EXPECT_TRUE(std::isnan(half_test::decode(native[i])));
    } else if constexpr (std::is_same_v<T, BF16>) {
      EXPECT_EQ(native[i].bits, mature[i].bits);
    } else {
      EXPECT_EQ(std::bit_cast<std::uint32_t>(native[i]),
                std::bit_cast<std::uint32_t>(mature[i]));
    }
  }
}

template <class T> struct Inputs {
  std::vector<T> gate, left, weight, silu, product;
};

template <class T> Inputs<T> inputs(int phase, int slot) {
  Inputs<T> result;
  const auto seed = 1 + slot + phase * 3;
  for (std::int64_t k = 0; k < kInner; ++k)
    result.left.push_back(half_test::encode<T>(
        (k % 2 == 0 ? 1.0 : -0.5) + seed / 16.0));
  for (std::int64_t k = 0; k < kInner; ++k)
    for (std::int64_t col = 0; col < kWidth; ++col)
      result.weight.push_back(half_test::encode<T>(
          ((k * 7 + col * 3) % 23 - 11) / 16.0 + seed / 32.0));
  std::size_t rounding_witnesses = 0;
  for (std::int64_t col = 0; col < kWidth; ++col) {
    const auto gate = half_test::encode<T>(col < 5 ? -80.0 - 5.0 * col
        : (col % 19 - 9) / 4.0 + seed / 64.0);
    result.gate.push_back(gate);
    double sum = 0;
    for (std::int64_t k = 0; k < kInner; ++k)
      sum += half_test::decode(result.left[k]) *
             half_test::decode(result.weight[k * kWidth + col]);
    // Every dot product is a short sum of binary rationals, exact in F32.
    const auto up = half_test::encode<T>(static_cast<float>(sum));
    const auto silu = activated(gate);
    const auto product = multiplied(silu, up);
    result.silu.push_back(silu);
    result.product.push_back(product);
    if constexpr (std::is_same_v<T, BF16>)
      rounding_witnesses += product.bits != half_test::encode<T>(
          static_cast<float>(stable_silu(half_test::decode(gate))) *
          static_cast<float>(half_test::decode(up))).bits;
  }
  if constexpr (std::is_same_v<T, BF16>)
    EXPECT_GT(rounding_witnesses, 0U);
  return result;
}

template <class T> void noncontiguous_region() {
  SCOPED_TRACE(int(half_test::data_type<T>()));
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice).value();
  const auto type = half_test::data_type<T>();
  const auto description = dense(type, {1, kWidth});
  const auto left_description = dense(type, {1, kInner});
  const auto weight_description = dense(type, {kInner, kWidth});
  auto builder = g::GraphBuilder::create().value();
  const auto gate = builder.input(description).value();
  const auto left = builder.input(left_description).value();
  const auto weight = builder.input(weight_description).value();
  const auto silu = builder.add(c::Unary{c::UnaryKind::kSilu}, gate).value();
  // Preserve the real insertion order. The up projection is independent of
  // SiLU, but its output is an external input of the proposed two-node region.
  const auto up = builder.add(c::MatMul{}, left, weight).value();
  const auto product = builder.add(
      c::Binary{c::BinaryKind::kMultiply}, silu, up).value();
  ASSERT_TRUE(builder.publish(product).ok());
  auto logical = std::move(builder).finish().value();
  const auto silu_node = logical.producer(silu).value();
  const auto up_node = logical.producer(up).value();
  const auto product_node = logical.producer(product).value();
  ASSERT_LT(silu_node.ordinal(), up_node.ordinal());
  ASSERT_LT(up_node.ordinal(), product_node.ordinal());
  const std::array required{
      g::NodeProviderConstraint{up_node, c::cublas::kProviderId}};
  auto compiled = g::cuda::compile(logical, context, memory.ref(),
                                    {.node_providers = required});
  ASSERT_TRUE(compiled) << compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(), 2U);
  ASSERT_TRUE(compiled->report.mixed_providers());
  const auto projection = compiled->report.step(0).value();
  const auto region = compiled->report.step(1).value();
  EXPECT_EQ(projection.provider.id, c::cublas::kProviderId);
  ASSERT_EQ(projection.node_count, 1U);
  EXPECT_EQ(compiled->report.step_node(0, 0).value(), up_node);
  EXPECT_EQ(region.kind, g::CompileStepKind::kProviderRegion);
  EXPECT_EQ(region.provider.id, c::ggml_cuda::kProviderId);
  EXPECT_EQ(region.implementation, c::ProviderImplementationId{3});
  const c::RoutePolicyId silu_multiply_policy{0x48594c4547474355ULL, 2, 1};
  EXPECT_EQ(region.policy, silu_multiply_policy);
  ASSERT_EQ(region.node_count, 2U);
  EXPECT_FALSE(region.nodes_contiguous);
  EXPECT_EQ(compiled->report.step_node(1, 0).value(), silu_node);
  EXPECT_EQ(compiled->report.step_node(1, 1).value(), product_node);
  ASSERT_TRUE(projection.runtime.capture_compatible);
  ASSERT_TRUE(region.runtime.capture_compatible);

  // Owners precede queues/invocations: all borrowed bindings and retained
  // capture addresses survive native invocation teardown.
  std::vector<Buffer> retained;
  std::array queues{context.create_queue().value(), context.create_queue().value()};
  std::array runs{compiled->executable.create_invocation().value(),
                  compiled->executable.create_invocation().value()};
  std::vector<T> old;
  for (int phase = 0; phase < 2; ++phase) {
    std::array<Buffer, 2> gates, lefts, weights, outputs;
    std::array<Inputs<T>, 2> host;
    for (int slot = 0; slot < 2; ++slot) {
      host[slot] = inputs<T>(phase, slot);
      gates[slot] = upload<T>(memory.ref(), host[slot].gate);
      lefts[slot] = upload<T>(memory.ref(), host[slot].left);
      weights[slot] = upload<T>(memory.ref(), host[slot].weight);
      outputs[slot] = output_buffer(memory.ref(), description);
      ASSERT_TRUE(runs[slot].bind(gate, c::ConstTensorView::create(
          description, gates[slot].view()).value()).ok());
      ASSERT_TRUE(runs[slot].bind(left, c::ConstTensorView::create(
          left_description, lefts[slot].view()).value()).ok());
      ASSERT_TRUE(runs[slot].bind(weight, c::ConstTensorView::create(
          weight_description, weights[slot].view()).value()).ok());
      ASSERT_TRUE(runs[slot].bind(product, c::TensorView::create(
          description, outputs[slot].view()).value()).ok());
    }
    for (const auto mode : {g::ReplayMode::kCommands,
                            g::ReplayMode::kRequireCapture}) {
      std::array<c::Completion, 2> done;
      for (int slot = 0; slot < 2; ++slot) {
        const auto prepared = g::cuda::prepare_replay(runs[slot], queues[slot],
            {.mode = mode, .host_wait = g::HostWaitPolicy::kReject});
        ASSERT_TRUE(prepared.ok()) << prepared.message();
        EXPECT_EQ(runs[slot].replay_route(), mode == g::ReplayMode::kCommands
            ? g::ReplayRoute::kCommands : g::ReplayRoute::kCaptured);
      }
      for (int slot = 0; slot < 2; ++slot) {
        auto submitted = runs[slot].submit(queues[slot]);
        ASSERT_TRUE(submitted) << submitted.error().message();
        done[slot] = std::move(*submitted);
      }
      ASSERT_TRUE(done[1].wait().ok());
      ASSERT_TRUE(done[0].wait().ok());
      for (int slot = 0; slot < 2; ++slot)
        check(outputs[slot], host[slot].product);
    }
    for (int slot = 0; slot < 2; ++slot) {
      if (phase == 0 && slot == 0)
        old = half_test::read<T>(outputs[slot]);
      retained.push_back(std::move(gates[slot]));
      retained.push_back(std::move(lefts[slot]));
      retained.push_back(std::move(weights[slot]));
      retained.push_back(std::move(outputs[slot]));
    }
    // All phase-zero allocations remain live, so both slots really bind new
    // addresses. The old externally held output must retain its exact bits.
    if (phase == 1)
      unchanged(retained[3], old);
  }
}

enum class Escape { kPublished, kExtraReader, kBothMultiplyInputs };

void escaped_intermediate(Escape escape) {
  SCOPED_TRACE(int(escape));
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice).value();
  const auto description = dense(c::DataType::kBFloat16, {1, kWidth});
  const auto host = inputs<BF16>(0, 1);
  std::vector<BF16> other, expected, observed;
  for (std::size_t i = 0; i < host.gate.size(); ++i) {
    other.push_back(half_test::encode<BF16>((int(i % 7) - 3) / 4.0));
    expected.push_back(multiplied(host.silu[i],
        escape == Escape::kBothMultiplyInputs ? host.silu[i] : other.back()));
    observed.push_back(escape == Escape::kExtraReader
        ? half_test::encode<BF16>(-half_test::decode(host.silu[i])) : host.silu[i]);
  }
  auto gate_buffer = upload<BF16>(memory.ref(), host.gate);
  auto other_buffer = upload<BF16>(memory.ref(), other);
  auto output = output_buffer(memory.ref(), description);
  auto intermediate = output_buffer(memory.ref(), description);
  auto builder = g::GraphBuilder::create().value();
  const auto gate = builder.input(description).value();
  const auto second = escape == Escape::kBothMultiplyInputs
      ? gate : builder.input(description).value();
  const auto silu = builder.add(c::Unary{c::UnaryKind::kSilu}, gate).value();
  const auto product = builder.add(c::Binary{c::BinaryKind::kMultiply}, silu,
      escape == Escape::kBothMultiplyInputs ? silu : second).value();
  auto visible = silu;
  if (escape == Escape::kExtraReader)
    visible = builder.add(c::Unary{c::UnaryKind::kNeg}, silu).value();
  if (escape != Escape::kBothMultiplyInputs)
    ASSERT_TRUE(builder.publish(visible).ok());
  ASSERT_TRUE(builder.publish(product).ok());
  auto logical = std::move(builder).finish().value();
  auto compiled = g::cuda::compile(logical, context, memory.ref());
  ASSERT_TRUE(compiled) << compiled.error().message();
  // A generic region may still compute this graph. Correct published/extra
  // readers and the self-use are the contract; do not forbid all regions.
  for (std::size_t i = 0; i < compiled->report.step_count(); ++i) {
    const auto step = compiled->report.step(i).value();
    if (step.provider.id == c::ggml_cuda::kProviderId)
      EXPECT_NE(step.implementation, c::ProviderImplementationId{3});
  }
  auto queue = context.create_queue().value();
  auto run = compiled->executable.create_invocation().value();
  ASSERT_TRUE(run.bind(gate, c::ConstTensorView::create(
      description, gate_buffer.view()).value()).ok());
  if (escape != Escape::kBothMultiplyInputs)
    ASSERT_TRUE(run.bind(second, c::ConstTensorView::create(
        description, other_buffer.view()).value()).ok());
  ASSERT_TRUE(run.bind(product, c::TensorView::create(
      description, output.view()).value()).ok());
  if (escape != Escape::kBothMultiplyInputs)
    ASSERT_TRUE(run.bind(visible, c::TensorView::create(
        description, intermediate.view()).value()).ok());
  ASSERT_TRUE(g::cuda::prepare_replay(run, queue).ok());
  auto done = run.submit(queue);
  ASSERT_TRUE(done) << done.error().message();
  ASSERT_TRUE(done->wait().ok());
  check(output, expected);
  if (escape != Escape::kBothMultiplyInputs)
    check(intermediate, observed);
}

template <class T> void rank4_round_trip(bool published) {
  SCOPED_TRACE(::testing::Message() << "dtype=" << int(half_test::data_type<T>())
                                  << ", published=" << published);
  // Keep both branches on the native GGML composition. Default placement may
  // keep a published ordinary SiLU on SGLang and miss this reshape boundary.
  auto context = c::Context::create(c::cuda::device(0).value(),
                                    g::ggml_cuda::provider()).value();
  auto memory = c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice).value();
  const auto description = dense(half_test::data_type<T>(), {1, 2, 3, 128});
  auto builder = g::GraphBuilder::create().value();
  const auto input = builder.input(description).value();
  const auto silu = builder.add(c::Unary{c::UnaryKind::kSilu}, input).value();
  // The same external input has two readers. Only SiLU's private result may
  // disappear; neither reuse of the input nor rank restoration is a Copy.
  const auto product = builder.add(
      c::Binary{c::BinaryKind::kMultiply}, silu, input).value();
  auto extra = silu;
  if (published) {
    extra = builder.add(c::Unary{c::UnaryKind::kNeg}, silu).value();
    ASSERT_TRUE(builder.publish(silu).ok());
    ASSERT_TRUE(builder.publish(extra).ok());
  }
  ASSERT_TRUE(builder.publish(product).ok());
  const std::array domains{g::StorageDomain{.resource = memory.ref()}};
  const std::array targets{g::ExecutionTarget{
      .source = g::ExecutionSource::acquire(context).value(),
      .default_storage = g::StorageDomainId{0}}};
  const std::array lanes{g::ExecutionLane{.target = g::ExecutionTargetId{0}}};
  auto compiled = g::compile(std::move(builder).finish().value(),
      {.storage_domains = domains, .targets = targets, .lanes = lanes});
  ASSERT_TRUE(compiled) << compiled.error().message();

  std::vector<Buffer> retained;
  std::array queues{context.create_queue().value(), context.create_queue().value()};
  std::array runs{compiled->executable.create_invocation().value(),
                  compiled->executable.create_invocation().value()};
  std::vector<T> old_product, old_silu, old_extra;
  std::size_t old_output_index = 0;
  for (int phase = 0; phase < 2; ++phase) {
    std::array<Buffer, 2> sources, outputs, intermediates, readers;
    std::array<std::vector<T>, 2> host, expected, activated_values, negated;
    std::array<c::Completion, 2> done;
    for (int slot = 0; slot < 2; ++slot) {
      const auto seed = 1 + slot + phase * 3;
      std::size_t witnesses = 0;
      for (std::size_t i = 0; i < description.element_count().value(); ++i) {
        const auto x = half_test::encode<T>((int(i % 41) - 20) / 8.0 + seed / 64.0);
        const auto rounded_silu = activated(x);
        const auto rounded_product = multiplied(rounded_silu, x);
        host[slot].push_back(x);
        activated_values[slot].push_back(rounded_silu);
        expected[slot].push_back(rounded_product);
        negated[slot].push_back(half_test::encode<T>(-half_test::decode(rounded_silu)));
        if constexpr (std::is_same_v<T, BF16>)
          witnesses += rounded_product.bits != half_test::encode<T>(
              static_cast<float>(stable_silu(half_test::decode(x))) *
              static_cast<float>(half_test::decode(x))).bits;
      }
      if constexpr (std::is_same_v<T, BF16>)
        EXPECT_GT(witnesses, 0U);
      sources[slot] = upload<T>(memory.ref(), host[slot]);
      outputs[slot] = output_buffer(memory.ref(), description);
      ASSERT_TRUE(runs[slot].bind(input, c::ConstTensorView::create(
          description, sources[slot].view()).value()).ok());
      ASSERT_TRUE(runs[slot].bind(product, c::TensorView::create(
          description, outputs[slot].view()).value()).ok());
      if (published) {
        intermediates[slot] = output_buffer(memory.ref(), description);
        readers[slot] = output_buffer(memory.ref(), description);
        ASSERT_TRUE(runs[slot].bind(silu, c::TensorView::create(
            description, intermediates[slot].view()).value()).ok());
        ASSERT_TRUE(runs[slot].bind(extra, c::TensorView::create(
            description, readers[slot].view()).value()).ok());
      }
      const std::array bindings{g::QueueBinding{g::ExecutionLaneId{0}, &queues[slot]}};
      ASSERT_TRUE(runs[slot].prepare_replay(bindings).ok());
    }
    for (int slot = 0; slot < 2; ++slot) {
      auto submitted = runs[slot].submit(queues[slot]);
      ASSERT_TRUE(submitted) << submitted.error().message();
      done[slot] = std::move(*submitted);
    }
    ASSERT_TRUE(done[1].wait().ok());
    ASSERT_TRUE(done[0].wait().ok());
    for (int slot = 0; slot < 2; ++slot) {
      check(outputs[slot], expected[slot]);
      if (published) {
        check(intermediates[slot], activated_values[slot]);
        check(readers[slot], negated[slot]);
      }
      if (phase == 0 && slot == 0) {
        old_output_index = retained.size() + 1;
        old_product = half_test::read<T>(outputs[slot]);
        if (published) {
          old_silu = half_test::read<T>(intermediates[slot]);
          old_extra = half_test::read<T>(readers[slot]);
        }
      }
      retained.push_back(std::move(sources[slot]));
      retained.push_back(std::move(outputs[slot]));
      if (published) {
        retained.push_back(std::move(intermediates[slot]));
        retained.push_back(std::move(readers[slot]));
      }
    }
    // Retaining every old allocation forces new addresses in both slots and
    // keeps every previously published output independently observable.
    if (phase == 1) {
      unchanged(retained[old_output_index], old_product);
      if (published) {
        unchanged(retained[old_output_index + 1], old_silu);
        unchanged(retained[old_output_index + 2], old_extra);
      }
    }
  }
}

TEST(CudaStableSilu, DirectOrdinarySiluKeepsStableTailsAndNonfiniteContract) {
  direct<float>();
  direct<BF16>();
}

TEST(CudaStableSilu, NoncontiguousSiluMulRegionCrossesCublasAndRebindsBothSlots) {
  noncontiguous_region<float>();
  noncontiguous_region<BF16>();
}

TEST(CudaStableSilu, PublishedExtraReaderAndSelfMultiplyKeepRoundedIntermediate) {
  for (const auto escape : {Escape::kPublished, Escape::kExtraReader,
                             Escape::kBothMultiplyInputs})
    escaped_intermediate(escape);
}

TEST(CudaStableSilu, DefaultRank2ProjectionKeepsBlasLeafPreference) {
  auto context = g::cuda::create_context().value();
  // No provider constraint: capability for plain rank2 MatMul must not make
  // the generic norm/add region consume the default cuBLAS projection.
  ggml_cuda_graph_test::exercise(context, true,
      [&](const g::Graph &logical, hyle::mem::MemoryResourceRef resource) {
        return g::cuda::compile(logical, context, resource);
      });
  // The ordinary full island would tie at preference400 and consume MatMul,
  // even though that leaf has a better cuBLAS300 implementation. Exercise
  // expert rankings through common Graph compilation, without route policy.
  const std::array providers{
      c::ProviderBinding{g::ggml_cuda::provider(), 400},
      c::ProviderBinding{c::cublas::provider(), 300}};
  auto expert = c::Context::create(c::cuda::device(0).value(),
                                  {.providers = providers}).value();
  ggml_cuda_graph_test::exercise(expert, true,
      [&](const g::Graph &logical, hyle::mem::MemoryResourceRef resource) {
        const std::array domains{g::StorageDomain{.resource = resource}};
        const std::array targets{g::ExecutionTarget{
            .source = g::ExecutionSource::acquire(expert).value(),
            .default_storage = g::StorageDomainId{0}}};
        const std::array lanes{
            g::ExecutionLane{.target = g::ExecutionTargetId{0}}};
        return g::compile(logical,
            {.storage_domains = domains, .targets = targets, .lanes = lanes});
      });
}

TEST(CudaStableSilu, Rank4RoundTripsKeepPublishedRoundingAndBothSlots) {
  for (const bool published : {false, true}) {
    rank4_round_trip<float>(published);
    rank4_round_trip<BF16>(published);
  }
}
} // namespace
