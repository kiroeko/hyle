from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('recipe',Path(__file__).with_name('run.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.compile_one('tests/graph_provider_ggml_cuda/region_test.cc','region-test-final')
plan=m.read(m.OUT/'link-plan.json')
argv=[str(m.OUT/'region-test-final.obj') if x==str(m.OUT/'region-test.obj') else x for x in plan['command']]
assert argv.count(str(m.OUT/'region-test-final.obj'))==1
m.save(m.OUT/'final-link-plan.json',dict(command=argv,base=m.ident(m.OUT/'link-plan.json'),only_change='region test object: accept actual InvalidArgument at cold prepare in alignment negative fixture; no product change'))
m.command('final-focused-tests-link',argv)
text=(m.OUT/'focused-tests.map').read_text(errors='replace')
m.save(m.OUT/'final-map-owners.json',dict(map=m.ident(m.OUT/'focused-tests.map'),selected=[dict(object=m.ident(p),map_mentions=sum(1 for line in text.splitlines() if Path(p).name in line)) for p in [m.OUT/'region-test-final.obj',m.OUT/'tensor-test.obj',m.ARCH/'ggml-cuda-liveness/provider.obj']]))
plan=m.read(m.OUT/'run-plan.json')
plan['command']=[str(m.OUT/'focused-tests.exe'),'--gtest_filter=GgmlCudaGraph.TypedSliceCopyBindsBeforeAlignedNativeMath','--gtest_color=no','--gtest_output=xml:'+str(m.OUT/'final-tests.xml')]
m.save(m.OUT/'final-run-plan.json',plan)
cleanup=m.read(m.OUT/'cleanup-windows.json')
cleanup['files']=[m.ident(x['path']) for x in cleanup['files']]
cleanup['retain'].append(m.ident(m.OUT/'region-test-final.obj'))
m.save(m.OUT/'cleanup-windows.json',cleanup)
