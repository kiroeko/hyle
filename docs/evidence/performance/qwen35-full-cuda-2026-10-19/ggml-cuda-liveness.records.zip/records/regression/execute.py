from pathlib import Path
import importlib.util,subprocess,sys,time
spec=importlib.util.spec_from_file_location('recipe',Path(__file__).with_name('run.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mode=sys.argv[1]
assert mode in {'before','candidate','final'}
plan=m.read(m.OUT/({'before':'before-run-plan.json','candidate':'run-plan.json','final':'final-run-plan.json'}[mode]))
rows=m.read(m.OUT/'commands.json')
stem=f'{len(rows)+1:03d}-{mode}-run'
assert not any(r['tag']==mode+'-run' for r in rows)
row=dict(tag=mode+'-run',command=plan['command'],cwd=str(m.ROOT),started=time.time(),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
rows.append(row);m.save(m.OUT/'commands.json',rows)
print('START',stem,flush=True)
with (m.OUT/row['stdout']).open('wb') as so,(m.OUT/row['stderr']).open('wb') as se:
 proc=subprocess.Popen(row['command'],cwd=m.ROOT,env=m.ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
 row['pid']=proc.pid;m.save(m.OUT/'live.json',row);m.save(m.OUT/'commands.json',rows)
 row['exit']=proc.wait()
row['seconds']=time.time()-row['started'];row['terminal']=True;m.save(m.OUT/'commands.json',rows);m.save(m.OUT/'live.json',row)
print('END',stem,row['exit'],round(row['seconds'],3),flush=True)
print((m.OUT/row['stdout']).read_text(errors='replace'),flush=True)
print((m.OUT/row['stderr']).read_text(errors='replace'),flush=True)
