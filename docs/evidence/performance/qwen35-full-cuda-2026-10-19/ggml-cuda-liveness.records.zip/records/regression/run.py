from pathlib import Path
import difflib, hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, v): Path(p).write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8')
def ident(p):
 p=Path(p); b=p.read_bytes(); return dict(path=str(p.resolve()), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
TEMPLATE = read(ARCH / 'cuda-admitted-ggml-stream-implementation/provider-test-identity.json')['command']
BASE_PATH = ARCH / 'qwen-gpu-comparison/hyle-link-plan.json'
BASE = read(BASE_PATH)['command']
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': TEMPLATE[0]})
ENV['VSLANG']='1033'
ENV['PATH']=os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE if Path(v).is_absolute() and v.lower().endswith('.lib')))+os.pathsep+ENV['PATH']
FILTER='GgmlCudaGraph.NonAttentionChainReusesDeadNativeIntermediates:GgmlCudaGraph.TensorRegionPreservesRoundingPublishedIntermediatesAndOldResults:GgmlCudaGraph.TypedSliceCopyBindsBeforeAlignedNativeMath:GgmlCudaGraph.CheckedIdsKeepEveryPublishedOutputAndOtherConsumersIntact:GgmlCudaTensor.BatchedF32MatMulRebindsIndependentSlotsWithoutNarrowing'

def command(tag, argv):
 rows=read(OUT/'commands.json') if (OUT/'commands.json').exists() else []
 stem=f'{len(rows)+1:03d}-{tag}'
 row=dict(tag=tag, command=list(map(str,argv)),cwd=str(ROOT),started=time.time(),exit=None,stdout=stem+'.stdout.log',stderr=stem+'.stderr.log')
 rows.append(row);save(OUT/'commands.json',rows)
 print('START',stem,flush=True)
 with (OUT/row['stdout']).open('wb') as so, (OUT/row['stderr']).open('wb') as se:
  proc=subprocess.Popen(row['command'], cwd=ROOT, env=ENV,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  row['pid']=proc.pid;save(OUT/'live.json',row);save(OUT/'commands.json',rows)
  row['exit']=proc.wait()
 row['seconds']=time.time()-row['started'];row['terminal']=True;save(OUT/'commands.json',rows);save(OUT/'live.json',row)
 print('END',stem,row['exit'],round(row['seconds'],3),flush=True)
 if row['exit']:
  print((OUT/row['stdout']).read_text(errors='replace')[-7000:],flush=True)
  print((OUT/row['stderr']).read_text(errors='replace')[-5000:],flush=True)
  raise SystemExit(row['exit'])

def compile_one(source,name):
 src=ROOT/source;before=ident(src);obj=OUT/(name+'.obj')
 argv=[x for x in TEMPLATE if not x.lower().startswith(('/fo','/fd')) and not x.lower().endswith('.cc')]
 argv += ['/sourceDependencies',str(OUT/(name+'-deps.json')),str(src),'/Fo'+str(obj)]
 command(name+'-compile',argv)
 assert ident(src)==before
 deps=read(OUT/(name+'-deps.json'))
 includes=deps['Data']['Includes']
 hyle=[ident(v) for v in includes if Path(v).resolve().is_relative_to(ROOT.resolve())]
 save(OUT/(name+'-identity.json'),dict(source=before,object=ident(obj),command=argv,hyle_dependencies=hyle))
 dst=OUT/'candidate'/source;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())

def build():
 compile_one('tests/graph_provider_ggml_cuda/region_test.cc','region-test')
 compile_one('tests/compute_provider_ggml_cuda/tensor_test.cc','tensor-test')
 original=str(ARCH/'cuda-admitted-ggml-stream-implementation/provider.obj')
 provider=ARCH/'ggml-cuda-liveness/provider.obj'
 receipt=read(ARCH/'ggml-cuda-liveness/candidate-source.json')
 assert ident(provider)==receipt['object']
 consumer=str(ARCH/'qwen-gpu-comparison/hyle-consumer.obj')
 assert BASE.count(original)==BASE.count(consumer)==1
 argv=[str(provider) if v==original else v for v in BASE if v!=consumer and not v.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 argv[6:6]=[str(OUT/'region-test.obj'),str(OUT/'tensor-test.obj')]
 argv += [str(ROOT/'.scratch/build-compute-v2-dev/lib'/name) for name in ['gtest_main.lib','gtest.lib']]
 argv += ['/OUT:'+str(OUT/'focused-tests.exe'),'/MAP:'+str(OUT/'focused-tests.map'),'/IMPLIB:'+str(OUT/'focused-tests.lib')]
 assert all(Path(v).is_file() for v in argv if Path(v).is_absolute() and Path(v).suffix.lower() in {'.obj','.lib'})
 save(OUT/'link-plan.json',dict(command=argv,base=ident(BASE_PATH),provider=receipt,only_changes=['provider object','replace qwen consumer by 2 test TUs','gtest libraries','output paths']))
 command('focused-tests-link',argv)
 text=(OUT/'focused-tests.map').read_text(errors='replace')
 expected=[str(OUT/'region-test.obj'),str(OUT/'tensor-test.obj'),str(provider)]
 save(OUT/'map-owners.json',dict(map=ident(OUT/'focused-tests.map'),selected=[dict(object=ident(p),map_mentions=sum(1 for line in text.splitlines() if Path(p).name in line)) for p in expected]))
 save(OUT/'run-plan.json',dict(command=[str(OUT/'focused-tests.exe'),'--gtest_filter='+FILTER,'--gtest_color=no','--gtest_output=xml:'+str(OUT/'tests.xml')],cwd=str(ROOT),path_prepend=[str(Path(v).parent) for v in BASE if Path(v).is_absolute() and v.lower().endswith('.lib')],not_run=True))
 before=OUT/'before/tests/graph_provider_ggml_cuda/region_test.cc'
 after=ROOT/'tests/graph_provider_ggml_cuda/region_test.cc'
 (OUT/'source.diff').write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='before/tests/graph_provider_ggml_cuda/region_test.cc',tofile='tests/graph_provider_ggml_cuda/region_test.cc')),encoding='utf-8')
 save(OUT/'summary.json',dict(status='compiled_linked_not_run',tests=FILTER.split(':'),source=ident(after),provider=receipt,image=ident(OUT/'focused-tests.exe'),commands=len(read(OUT/'commands.json')),numerical_or_memory_result='not_run',no_native_or_sdk_build=True))
 cleanup=[ident(OUT/name) for name in ['focused-tests.exe','focused-tests.map','focused-tests.exp','focused-tests.lib'] if (OUT/name).exists()]
 save(OUT/'cleanup-windows.json',dict(root=str(OUT.resolve()),files=cleanup,retain=[ident(OUT/'region-test.obj'),ident(OUT/'tensor-test.obj')]))

if __name__=='__main__':
 if len(sys.argv)!=2 or sys.argv[1]!='build': raise SystemExit('build only; GPU run is coordinated by parent')
 build()
