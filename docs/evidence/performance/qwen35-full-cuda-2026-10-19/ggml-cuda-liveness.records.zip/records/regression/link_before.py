from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('recipe',Path(__file__).with_name('run.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=m.read(m.OUT/'link-plan.json')
old=m.ARCH/'cuda-admitted-ggml-stream-implementation/provider.obj'
new=m.ARCH/'ggml-cuda-liveness/provider.obj'
argv=[str(old) if x==str(new) else x for x in plan['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
assert argv.count(str(old))==1 and str(new) not in argv
argv+=['/OUT:'+str(m.OUT/'before-tests.exe'),'/MAP:'+str(m.OUT/'before-tests.map'),'/IMPLIB:'+str(m.OUT/'before-tests.lib')]
m.save(m.OUT/'before-link-plan.json',dict(command=argv,current_plan=m.ident(m.OUT/'link-plan.json'),only_change='provider object and output paths',provider=m.read(m.ARCH/'cuda-admitted-ggml-stream-implementation/provider-identity.json')))
m.command('before-tests-link',argv)
current=m.read(m.OUT/'run-plan.json')
before=dict(current)
before['command']=[str(m.OUT/'before-tests.exe'),'--gtest_filter=GgmlCudaGraph.NonAttentionChainReusesDeadNativeIntermediates','--gtest_color=no','--gtest_output=xml:'+str(m.OUT/'before-tests.xml')]
before['expected']='fails retained native bytes < 128 MiB, all math unchanged'
m.save(m.OUT/'before-run-plan.json',before)
summary=m.read(m.OUT/'summary.json');summary['before_image']=m.ident(m.OUT/'before-tests.exe');summary['commands']=len(m.read(m.OUT/'commands.json'));summary['before_not_run']=True;m.save(m.OUT/'summary.json',summary)
cleanup=m.read(m.OUT/'cleanup-windows.json')
cleanup['files'] += [m.ident(m.OUT/name) for name in ['before-tests.exe','before-tests.map','before-tests.exp','before-tests.lib'] if (m.OUT/name).exists()]
m.save(m.OUT/'cleanup-windows.json',cleanup)
text=(m.OUT/'before-tests.map').read_text(errors='replace')
m.save(m.OUT/'before-map-owners.json',dict(map=m.ident(m.OUT/'before-tests.map'),selected=[dict(object=m.ident(p),map_mentions=sum(1 for line in text.splitlines() if Path(p).name in line)) for p in [m.OUT/'region-test.obj',m.OUT/'tensor-test.obj',old]]))
