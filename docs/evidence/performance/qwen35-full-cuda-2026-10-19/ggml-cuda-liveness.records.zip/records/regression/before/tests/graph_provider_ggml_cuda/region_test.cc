#include "hyle/graph/providers/ggml_cuda.h"
#include "../model_fragment_test_support.h"
#include "../sparse_fragment_test_support.h"
#include "region_test_support.h"
#include "softmax_test_support.h"
#include "tensor_test_support.h"
#include "../compute_models/d5_gguf_test_support.h"
#include "../compute_models/gdn_region_test.h"
#include "../graph_ggml_constant_test.h"
#include "../compute_models/gather_elements_fixture.h"

#include <ggml.h>

#include <algorithm>

#include "hyle/compute/low_precision.h"

TEST(GgmlCudaGraph, ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs) {
  auto context = hyle::compute::Context::create(
      hyle::compute::cuda::device(0).value(), hyle::graph::ggml_cuda::provider()).value();
  auto memory = hyle::compute::cuda::MemoryResource::create(
      context, hyle::compute::cuda::MemoryKind::kDevice).value();
  ggml_constant_test::dense_rhs(context, memory.ref());
}

namespace {
void bfloat_expert_constants(bool single_node) {
  using namespace ggml_cuda_graph_test;
  using BF16 = hyle::simd::bfloat16_t;
  constexpr std::int64_t experts = 3, columns = 7, reduction = 37;
  constexpr std::int64_t tokens = 3, slots = 2;
  const auto weight_desc = compute::TensorDesc::dense(compute::DataType::kBFloat16,
      std::array{experts, columns, reduction}).value();
  const auto activation_desc = compute::TensorDesc::dense(compute::DataType::kFloat32,
      std::array{tokens, slots, reduction}).value();
  const auto ids_desc = compute::TensorDesc::dense(compute::DataType::kInt32,
      std::array{tokens, slots}).value();
  const auto output_desc = compute::TensorDesc::dense(compute::DataType::kFloat32,
      std::array{tokens, slots, columns}).value();
  for (const bool constant : {true, false}) {
    SCOPED_TRACE(constant);
    auto context = compute::Context::create(cuda::device(0).value(),
                                            graph::ggml_cuda::provider()).value();
    auto memory = cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
    auto weights = mem::Buffer::create(memory.ref(), weight_desc.required_bytes().value(), 256).value();
    auto activations = mem::Buffer::create(memory.ref(), activation_desc.required_bytes().value(), 256).value();
    auto ids = mem::Buffer::create(memory.ref(), ids_desc.required_bytes().value(), 256).value();
    std::array results{ggml_cuda_tensor_test::output_buffer(memory.ref(), output_desc),
                       ggml_cuda_tensor_test::output_buffer(memory.ref(), output_desc)};
    std::array negative{ggml_cuda_tensor_test::output_buffer(memory.ref(), output_desc),
                        ggml_cuda_tensor_test::output_buffer(memory.ref(), output_desc)};
    std::vector<BF16> w(experts * columns * reduction);
    const auto write_weights = [&](int phase) {
      for (std::size_t i = 0; i < w.size(); ++i)
        w[i] = half_test::encode<BF16>((int((i * 19 + phase * 13) % 47) - 23) * 0.01371);
      return weights.view().write(std::as_bytes(std::span(w)));
    };
    ASSERT_TRUE(write_weights(0).ok());
    auto builder = graph::GraphBuilder::create().value();
    const auto weight = (constant ? builder.constant(weight_desc) : builder.input(weight_desc)).value();
    const auto x = builder.input(activation_desc).value();
    const auto indices = builder.input(ids_desc).value();
    const std::array inputs{weight, x, indices};
    const auto product = builder.result(builder.add_node(
        compute::model_ops::grouped_matmul(), inputs).value()).value();
    const auto neg = single_node ? product :
        builder.add(compute::Unary{compute::UnaryKind::kNeg}, product).value();
    ASSERT_TRUE(builder.publish(product).ok());
    if (!single_node) ASSERT_TRUE(builder.publish(neg).ok());
    auto logical = std::move(builder).finish().value();
    const std::array domains{graph::StorageDomain{.resource = memory.ref()}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    const std::array constants{graph::ConstantBinding{weight,
        compute::ConstTensorView::create(weight_desc, weights.view()).value()}};
    auto compiled = graph::compile(logical,
        {.storage_domains = domains, .targets = targets, .lanes = lanes},
        {.constants = constant ? std::span(constants) : std::span<const graph::ConstantBinding>{}});
    ASSERT_TRUE(compiled) << compiled.error().message();
    ASSERT_EQ(compiled->report.step_count(), 1u);
    EXPECT_EQ(compiled->report.packed_constant_count(), constant ? 1u : 0u);
    EXPECT_EQ(compiled->report.packed_constant_bytes(),
              constant ? std::size_t(experts * columns * reduction * sizeof(float)) : 0u);
    std::array invocations{compiled->executable.create_invocation().value(),
                           compiled->executable.create_invocation().value()};
    std::array queues{context.create_queue().value(), context.create_queue().value()};
    for (std::size_t lane = 0; lane < invocations.size(); ++lane) {
      if (!constant)
        ASSERT_TRUE(invocations[lane].bind(weight, compute::ConstTensorView::create(
            weight_desc, weights.view()).value()).ok());
      ASSERT_TRUE(invocations[lane].bind(x, compute::ConstTensorView::create(
          activation_desc, activations.view()).value()).ok());
      ASSERT_TRUE(invocations[lane].bind(indices, compute::ConstTensorView::create(
          ids_desc, ids.view()).value()).ok());
      ASSERT_TRUE(invocations[lane].bind(product, compute::TensorView::create(
          output_desc, results[lane].view()).value()).ok());
      if (!single_node) ASSERT_TRUE(invocations[lane].bind(neg, compute::TensorView::create(
          output_desc, negative[lane].view()).value()).ok());
      const std::array bindings{graph::QueueBinding{
          .lane = graph::ExecutionLaneId{0}, .queue = &queues[lane]}};
      ASSERT_TRUE(invocations[lane].prepare_replay(bindings).ok());
    }
    std::vector<float> old;
    for (int phase = 0; phase < 2; ++phase) {
      if (!constant && phase != 0) ASSERT_TRUE(write_weights(phase).ok());
      std::vector<float> a(tokens * slots * reduction);
      std::vector<std::int32_t> selected(tokens * slots);
      for (std::size_t i = 0; i < a.size(); ++i)
        a[i] = float((int((i * 11 + phase * 7) % 43) - 21) * 0.01913);
      for (std::size_t i = 0; i < selected.size(); ++i)
        selected[i] = std::int32_t((i / 2 + phase) % experts); // repeated experts remain legal
      ASSERT_TRUE(activations.view().write(std::as_bytes(std::span(a))).ok());
      ASSERT_TRUE(ids.view().write(std::as_bytes(std::span(selected))).ok());
      auto done = invocations[phase].submit(queues[phase]);
      ASSERT_TRUE(done) << done.error().message();
      if (phase == 1) {
        compiled->executable = {};
        invocations = {};
        ASSERT_TRUE(context.close().ok());
      }
      ASSERT_TRUE(done->wait().ok());
      const auto actual = half_test::read<float>(results[phase]);
      const auto inverted = single_node ? std::vector<float>{} : half_test::read<float>(negative[phase]);
      for (std::size_t row = 0; row < selected.size(); ++row)
        for (std::size_t column = 0; column < std::size_t(columns); ++column) {
          double expected = 0;
          for (std::size_t k = 0; k < std::size_t(reduction); ++k)
            expected += double(a[row * reduction + k]) * half_test::decode(
                w[(std::size_t(selected[row]) * columns + column) * reduction + k]);
          const auto index = row * columns + column;
          const auto budget = 2e-6 + std::abs(expected) * 6e-6;
          EXPECT_NEAR(actual[index], expected, budget) << index;
          if (!single_node) EXPECT_NEAR(inverted[index], -expected, budget) << index;
        }
      if (phase == 0) old = actual;
      else EXPECT_EQ(half_test::read<float>(results[0]), old);
    }
  }
}

} // namespace

TEST(GgmlCudaGraph, BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable) {
  bfloat_expert_constants(false);
}
TEST(GgmlCudaGraph, SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable) {
  bfloat_expert_constants(true);
}

TEST(GgmlCudaGraph, CheckedIdsKeepEveryPublishedOutputAndOtherConsumersIntact) {
  using namespace ggml_cuda_graph_test;
  using namespace ggml_cuda_tensor_test;
  constexpr std::int64_t columns = 2, reduction = 32;
  const auto w3desc = dense(compute::DataType::kFloat32, {3, columns, reduction});
  const auto w2desc = dense(compute::DataType::kFloat32, {2, columns, reduction});
  const auto adesc = dense(compute::DataType::kFloat32, {1, 2, reduction});
  const auto idesc = dense(compute::DataType::kInt32, {1, 2});
  const auto ydesc = dense(compute::DataType::kFloat32, {1, 2, columns});
  auto context = compute::Context::create(cuda::device(0).value(),
      graph::ggml_cuda::provider()).value();
  auto memory = cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  const std::vector<float> wa(3 * columns * reduction, 1.0F);
  const std::vector<float> wb(2 * columns * reduction, 2.0F);
  const std::vector<float> activation(2 * reduction, 0.25F);
  auto weights3 = upload<float>(memory.ref(), wa);
  auto weights2 = upload<float>(memory.ref(), wb);
  auto a = upload<float>(memory.ref(), activation);
  auto ids = output_buffer(memory.ref(), idesc);
  auto builder = graph::GraphBuilder::create().value();
  const auto w3 = builder.input(w3desc).value(), w2 = builder.input(w2desc).value();
  const auto x = builder.input(adesc).value(), index = builder.input(idesc).value();
  const auto product = [&](graph::ValueId w) {
    const std::array inputs{w, x, index};
    return builder.result(builder.add_node(compute::model_ops::grouped_matmul(), inputs).value()).value();
  };
  const auto y3 = product(w3), y2 = product(w2);
  const auto neg = builder.add(compute::Unary{compute::UnaryKind::kNeg}, y3).value();
  for (const auto value : {y3, y2, neg}) ASSERT_TRUE(builder.publish(value).ok());
  const auto logical = std::move(builder).finish().value();
  const std::array domains{graph::StorageDomain{.resource = memory.ref()}};
  const std::array targets{graph::ExecutionTarget{
      .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
  const std::array lanes{graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
  auto compiled = graph::compile(logical,
      {.storage_domains = domains, .targets = targets, .lanes = lanes});
  ASSERT_TRUE(compiled) << compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(), 1U);
  EXPECT_EQ(compiled->report.step(0)->provider.id, compute::ggml_cuda::kProviderId);
  std::array calls{compiled->executable.create_invocation().value(),
                   compiled->executable.create_invocation().value()};
  std::array queues{context.create_queue().value(), context.create_queue().value()};
  std::array buffers{output_buffer(memory.ref(), ydesc), output_buffer(memory.ref(), ydesc),
                     output_buffer(memory.ref(), ydesc), output_buffer(memory.ref(), ydesc),
                     output_buffer(memory.ref(), ydesc), output_buffer(memory.ref(), ydesc)};
  for (std::size_t slot = 0; slot < calls.size(); ++slot) {
    ASSERT_TRUE(calls[slot].bind(w3, compute::ConstTensorView::create(w3desc, weights3.view()).value()).ok());
    ASSERT_TRUE(calls[slot].bind(w2, compute::ConstTensorView::create(w2desc, weights2.view()).value()).ok());
    ASSERT_TRUE(calls[slot].bind(x, compute::ConstTensorView::create(adesc, a.view()).value()).ok());
    ASSERT_TRUE(calls[slot].bind(index, compute::ConstTensorView::create(idesc, ids.view()).value()).ok());
    const std::array values{y3, y2, neg};
    for (std::size_t port = 0; port < values.size(); ++port)
      ASSERT_TRUE(calls[slot].bind(values[port], compute::TensorView::create(
          ydesc, buffers[slot * 3 + port].view()).value()).ok());
    const std::array bindings{graph::QueueBinding{
        .lane = graph::ExecutionLaneId{0}, .queue = &queues[slot]}};
    ASSERT_TRUE(calls[slot].prepare_replay(bindings).ok());
    const std::array<std::int32_t, 2> valid{std::int32_t(slot), 0};
    ASSERT_TRUE(ids.view().write(std::as_bytes(std::span(valid))).ok());
    auto done = calls[slot].submit(queues[slot]);
    ASSERT_TRUE(done) << done.error().message();
    ASSERT_TRUE(done->wait().ok());
    for (std::size_t port = 0; port < values.size(); ++port)
      EXPECT_EQ(half_test::read<float>(buffers[slot * 3 + port]),
                std::vector<float>(4, port == 0 ? 8.0F : port == 1 ? 16.0F : -8.0F));
  }
  // ID 2 is valid for one consumer and invalid for the other. Neither partial
  // success nor downstream nodes may publish; the original ID must stay 2.
  const std::array<std::int32_t, 2> invalid{1, 2};
  ASSERT_TRUE(ids.view().write(std::as_bytes(std::span(invalid))).ok());
  auto failed = calls[1].submit(queues[1]);
  ASSERT_TRUE(failed) << failed.error().message();
  calls = {};
  compiled->executable = {};
  ASSERT_TRUE(context.close().ok());
  EXPECT_TRUE(failed->wait().IsOutOfRange());
  for (std::size_t slot = 0; slot < 2; ++slot)
    for (std::size_t port = 0; port < 3; ++port)
      EXPECT_EQ(half_test::read<float>(buffers[slot * 3 + port]),
                std::vector<float>(4, port == 0 ? 8.0F : port == 1 ? 16.0F : -8.0F));
  EXPECT_EQ(half_test::read<std::int32_t>(ids),
            std::vector<std::int32_t>(invalid.begin(), invalid.end()));
}

TEST(GgmlCudaGraph, GatherElementsAndNegativeShareLinearPerRowResults) {
  using namespace ggml_cuda_graph_test;
  using namespace ggml_cuda_tensor_test;
  namespace fixture = gather_elements_test;
  const auto ddesc = dense(compute::DataType::kFloat32, {3, 5});
  const auto idesc = dense(compute::DataType::kInt32, {3, 7});
  const auto ydesc = dense(compute::DataType::kFloat32, {3, 7});
  for (const auto bounds : {compute::IndexBoundsPolicy::kChecked,
                            compute::IndexBoundsPolicy::kUnchecked}) {
    SCOPED_TRACE(static_cast<int>(bounds));
    auto context = compute::Context::create(cuda::device(0).value(),
        graph::ggml_cuda::provider()).value();
    auto memory = cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
    auto data = output_buffer(memory.ref(), ddesc), ids = output_buffer(memory.ref(), idesc);
    auto output = output_buffer(memory.ref(), ydesc), negative = output_buffer(memory.ref(), ydesc);
    auto builder = graph::GraphBuilder::create().value();
    const auto x = builder.input(ddesc).value(), index = builder.input(idesc).value();
    const std::array inputs{x, index};
    const auto selected = builder.result(builder.add_node(
        compute::model_ops::gather_elements(1, bounds), inputs).value()).value();
    const auto neg = builder.add(compute::Unary{compute::UnaryKind::kNeg}, selected).value();
    ASSERT_TRUE(builder.publish(selected).ok());
    ASSERT_TRUE(builder.publish(neg).ok());
    const auto logical = std::move(builder).finish().value();
    const std::array domains{graph::StorageDomain{.resource = memory.ref()}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    auto compiled = graph::compile(logical,
        {.storage_domains = domains, .targets = targets, .lanes = lanes});
    ASSERT_TRUE(compiled) << compiled.error().message();
    ASSERT_EQ(compiled->report.step_count(), 1U);
    EXPECT_EQ(compiled->report.step(0)->provider.id, compute::ggml_cuda::kProviderId);
    auto call = compiled->executable.create_invocation().value();
    auto queue = context.create_queue().value();
    ASSERT_TRUE(call.bind(x, compute::ConstTensorView::create(ddesc, data.view()).value()).ok());
    ASSERT_TRUE(call.bind(index, compute::ConstTensorView::create(idesc, ids.view()).value()).ok());
    ASSERT_TRUE(call.bind(selected, compute::TensorView::create(ydesc, output.view()).value()).ok());
    ASSERT_TRUE(call.bind(neg, compute::TensorView::create(ydesc, negative.view()).value()).ok());
    const std::array bindings{graph::QueueBinding{
        .lane = graph::ExecutionLaneId{0}, .queue = &queue}};
    ASSERT_TRUE(call.prepare_replay(bindings).ok());
    for (int phase = 0; phase < 2; ++phase) {
      const auto source = fixture::data(phase);
      const auto indices = fixture::indices(phase);
      std::vector<float> stored;
      for (const auto value : source) stored.push_back(static_cast<float>(value));
      ASSERT_TRUE(data.view().write(std::as_bytes(std::span(stored))).ok());
      ASSERT_TRUE(ids.view().write(std::as_bytes(std::span(indices))).ok());
      auto done = call.submit(queue);
      ASSERT_TRUE(done) << done.error().message();
      ASSERT_TRUE(done->wait().ok());
      const auto actual = half_test::read<float>(output), inverted = half_test::read<float>(negative);
      const auto reference = fixture::reference(source, indices);
      for (std::size_t i = 0; i < reference.size(); ++i) {
        EXPECT_EQ(actual[i], reference[i]) << i;
        EXPECT_EQ(inverted[i], -reference[i]) << i;
      }
    }
  }
}

TEST(GgmlCudaGraph, GatedDeltaNetRegionsKeepBothSnapshotOutputs) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider()).value();
  auto memory = cuda::MemoryResource::create(
      context, cuda::MemoryKind::kDevice).value();
  gdn_region_test::exercise(context, memory.ref(), [&](const graph::Graph &logical) {
    const std::array storage{graph::StorageDomain{.resource = memory.ref()}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    return graph::compile(logical,
        {.storage_domains = storage, .targets = targets, .lanes = lanes});
  });
}

TEST(GgmlCudaGraph, NativeQ8GraphImportsGgufBytesAndReplays) {
  using namespace ggml_cuda_graph_test;
  d5_gguf_test::QuantizerCleanup cleanup;
  for (const auto format : {compute::GgufQuantizedType::kQ4_0,
       compute::GgufQuantizedType::kQ4_1, compute::GgufQuantizedType::kQ2K,
       compute::GgufQuantizedType::kIq2Xxs, compute::GgufQuantizedType::kIq2Xs,
       compute::GgufQuantizedType::kIq2S, compute::GgufQuantizedType::kIq1S,
       compute::GgufQuantizedType::kIq1M, compute::GgufQuantizedType::kQ8_0}) {
    SCOPED_TRACE(static_cast<int>(format));
    constexpr std::int64_t reduction = 256;
    constexpr std::int64_t columns = 2;
    const auto left_desc =
        ggml_cuda_tensor_test::dense(compute::DataType::kFloat32, {1, reduction});
    const auto right_desc = compute::gguf_weight_description(
        format, compute::DataType::kFloat32, reduction,
        columns);
    ASSERT_TRUE(right_desc) << right_desc.error().message();
    const auto output_desc =
        ggml_cuda_tensor_test::dense(compute::DataType::kFloat32, {1, columns});
    auto builder = graph::GraphBuilder::create().value();
    const auto left = builder.input(left_desc).value();
    const auto right = builder.input(*right_desc).value();
    const auto output = builder.add(compute::MatMul{}, left, right).value();
    ASSERT_TRUE(builder.publish(output).ok());
    auto context = compute::Context::create(cuda::device(0).value(),
                                            graph::ggml_cuda::provider())
                       .value();
    auto memory =
        cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
    const std::array domains{graph::StorageDomain{.resource = memory.ref()}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{
        graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    auto compiled = graph::compile(
        std::move(builder).finish().value(),
        {.storage_domains = domains, .targets = targets, .lanes = lanes});
    ASSERT_TRUE(compiled) << compiled.error().message();
    ASSERT_EQ(compiled->report.step_count(), 1U);
    EXPECT_EQ(compiled->report.step(0)->provider.id,
              compute::ggml_cuda::kProviderId);

    std::vector<float> left_values(static_cast<std::size_t>(reduction), 0.25F);
    std::vector<float> physical_weights(
        static_cast<std::size_t>(reduction * columns));
    std::fill_n(physical_weights.begin(), reduction, 1.0F);
    std::fill_n(physical_weights.begin() + reduction, reduction, -2.0F);
    const auto packed = d5_gguf_test::pack(format, physical_weights,
        columns, reduction, *right_desc->required_bytes());
    auto left_buffer =
        ggml_cuda_tensor_test::upload<float>(memory.ref(), left_values);
    auto right_buffer =
        ggml_cuda_tensor_test::upload<std::byte>(memory.ref(), packed.bytes);
    auto output_buffer =
        ggml_cuda_tensor_test::output_buffer(memory.ref(), output_desc);
    auto invocation = compiled->executable.create_invocation().value();
    ASSERT_TRUE(invocation
                    .bind(left, compute::ConstTensorView::create(
                                    left_desc, left_buffer.view())
                                    .value())
                    .ok());
    ASSERT_TRUE(invocation
                    .bind(right, compute::ConstTensorView::create(
                                     *right_desc, right_buffer.view())
                                     .value())
                    .ok());
    ASSERT_TRUE(invocation
                    .bind(output, compute::TensorView::create(
                                      output_desc, output_buffer.view())
                                      .value())
                    .ok());
    auto queue = context.create_queue().value();
    const std::array queues{
        graph::QueueBinding{.lane = graph::ExecutionLaneId{0}, .queue = &queue}};
    ASSERT_TRUE(invocation.prepare_replay(queues).ok());
    for (int repeat = 0; repeat < 2; ++repeat) {
      auto done = invocation.submit(queue);
      ASSERT_TRUE(done) << done.error().message();
      ASSERT_TRUE(done->wait().ok());
      const auto actual = half_test::read<float>(output_buffer);
      const auto scale = repeat == 0 ? 1.0F : 2.0F;
      ASSERT_EQ(actual.size(), 2U);
      for (std::size_t column = 0; column < actual.size(); ++column) {
        float expected = 0.0F;
        for (std::int64_t k = 0; k < reduction; ++k)
          expected += packed.decoded[column * reduction + k] * 0.25F * scale;
        EXPECT_NEAR(actual[column], expected, std::abs(expected) * 0.002F + 1.0e-5F);
      }
      if (repeat == 0) {
        std::fill(left_values.begin(), left_values.end(), 0.5F);
        ASSERT_TRUE(
            left_buffer.view().write(std::as_bytes(std::span(left_values))).ok());
      }
    }
  }
}

TEST(GgmlCudaGraph, MatureMoeAndHyperConnectionBatchUsesOrdinaryGraphEntry) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  auto memory =
      cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  for (const auto &test : model_fragment_test::cases()) {
    SCOPED_TRACE(test.name);
    std::vector<mem::Buffer> storage;
    std::vector<graph::ValueId> inputs;
    auto builder = graph::GraphBuilder::create().value();
    storage.reserve(test.inputs.size());
    inputs.reserve(test.inputs.size());
    for (std::size_t i = 0; i < test.inputs.size(); ++i) {
      storage.push_back(mem::Buffer::create(
                            memory.ref(), test.inputs[i].required_bytes().value(),
                            256)
                            .value());
      ASSERT_TRUE(storage.back().view().write(test.payloads[i]).ok());
      inputs.push_back(builder.input(test.inputs[i]).value());
    }
    const auto node = builder.add_node(test.operation, inputs).value();
    const auto output = builder.result(node).value();
    ASSERT_TRUE(builder.publish(output).ok());
    auto logical = std::move(builder).finish().value();
    const std::array domains{
        graph::StorageDomain{.resource = memory.ref()}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{
        graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    auto compiled = graph::compile(
        logical,
        {.storage_domains = domains, .targets = targets, .lanes = lanes});
    ASSERT_TRUE(compiled) << compiled.error().message();
    ASSERT_EQ(compiled->report.step_count(), 1U);
    EXPECT_EQ(compiled->report.step(0)->provider.id,
              compute::ggml_cuda::kProviderId);
    auto invocation = compiled->executable.create_invocation().value();
    for (std::size_t i = 0; i < inputs.size(); ++i)
      ASSERT_TRUE(invocation
                      .bind(inputs[i], compute::ConstTensorView::create(
                                           test.inputs[i], storage[i].view())
                                           .value())
                      .ok());
    auto result = mem::Buffer::create(memory.ref(),
                                      test.output.required_bytes().value(), 256)
                      .value();
    ASSERT_TRUE(invocation
                    .bind(output, compute::TensorView::create(
                                      test.output, result.view())
                                      .value())
                    .ok());
    auto queue = context.create_queue().value();
    const std::array queues{graph::QueueBinding{
        .lane = graph::ExecutionLaneId{0}, .queue = &queue}};
    ASSERT_TRUE(invocation.prepare_replay(queues).ok());
    auto done = invocation.submit(queue);
    ASSERT_TRUE(done) << done.error().message();
    ASSERT_TRUE(done->wait().ok());
    const auto actual = half_test::read<float>(result);
    ASSERT_EQ(actual.size(), test.expected.size());
    for (std::size_t i = 0; i < actual.size(); ++i)
      EXPECT_NEAR(actual[i], test.expected[i], 2.0e-5F) << i;
  }
}

TEST(GgmlCudaGraph, MatureLightningIndexerUsesOrdinaryGraphEntry) {
  using namespace ggml_cuda_graph_test;
  const sparse_fragment_test::Fixture test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  auto memory =
      cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  auto builder = graph::GraphBuilder::create().value();
  std::array<graph::ValueId, 4> inputs;
  std::vector<mem::Buffer> storage;
  for (std::size_t i = 0; i < inputs.size(); ++i) {
    inputs[i] = builder.input(test.inputs[i]).value();
    storage.push_back(mem::Buffer::create(
                          memory.ref(), test.inputs[i].required_bytes().value(),
                          256)
                          .value());
    ASSERT_TRUE(storage.back().view().write(test.payloads[i]).ok());
  }
  const auto node = builder.add_node(test.operation, inputs).value();
  const auto output = builder.result(node).value();
  ASSERT_TRUE(builder.publish(output).ok());
  auto logical = std::move(builder).finish().value();
  const std::array domains{graph::StorageDomain{.resource = memory.ref()}};
  const std::array targets{graph::ExecutionTarget{
      .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
  const std::array lanes{
      graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
  auto compiled = graph::compile(
      logical,
      {.storage_domains = domains, .targets = targets, .lanes = lanes})
                      .value();
  ASSERT_EQ(compiled.report.step_count(), 1U);
  EXPECT_EQ(compiled.report.step(0)->provider.id,
            compute::ggml_cuda::kProviderId);
  auto invocation = compiled.executable.create_invocation().value();
  for (std::size_t i = 0; i < inputs.size(); ++i)
    ASSERT_TRUE(invocation
                    .bind(inputs[i], compute::ConstTensorView::create(
                                         test.inputs[i], storage[i].view())
                                         .value())
                    .ok());
  auto result = mem::Buffer::create(
                    memory.ref(), test.output.required_bytes().value(), 256)
                    .value();
  ASSERT_TRUE(invocation
                  .bind(output, compute::TensorView::create(
                                    test.output, result.view())
                                    .value())
                  .ok());
  auto queue = context.create_queue().value();
  const std::array queues{graph::QueueBinding{
      .lane = graph::ExecutionLaneId{0}, .queue = &queue}};
  ASSERT_TRUE(invocation.prepare_replay(queues).ok());
  for (int repeat = 0; repeat < 2; ++repeat) {
    auto done = invocation.submit(queue);
    ASSERT_TRUE(done) << done.error().message();
    ASSERT_TRUE(done->wait().ok());
    const auto actual = half_test::read<float>(result);
    for (std::size_t i = 0; i < actual.size(); ++i)
      EXPECT_NEAR(actual[i], test.expected[i], 2.0e-5F) << i;
  }
}

TEST(GgmlCudaGraph, SoftmaxRegionPublishesLogicalAxesAndRetainsOldResults) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  const auto compile = [&](const graph::Graph &logical,
                           mem::MemoryResourceRef resource) {
    const std::array storage{graph::StorageDomain{.resource = resource}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{
        graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    return graph::compile(
        logical,
        {.storage_domains = storage, .targets = targets, .lanes = lanes});
  };
  exercise_softmax_graph<float>(context, compile);
  exercise_softmax_graph<hyle::simd::float16_t>(context, compile);
  exercise_softmax_graph<hyle::simd::bfloat16_t>(context, compile);
}

TEST(GgmlCudaGraph, WholeOriginalRegionUsesIndependentInvocations) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  exercise(
      context, false,
      [&](const graph::Graph &logical, mem::MemoryResourceRef resource) {
        const std::array storage{graph::StorageDomain{.resource = resource}};
        const std::array targets{graph::ExecutionTarget{
            .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
        const std::array lanes{
            graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
        return graph::compile(
            logical,
            {.storage_domains = storage, .targets = targets, .lanes = lanes});
      });
}

TEST(GgmlCudaGraph,
     TensorRegionPreservesRoundingPublishedIntermediatesAndOldResults) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  const auto compile = [&](const graph::Graph &logical,
                           mem::MemoryResourceRef resource) {
    const std::array storage{graph::StorageDomain{.resource = resource}};
    const std::array targets{graph::ExecutionTarget{
        .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
    const std::array lanes{
        graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
    return graph::compile(
        logical,
        {.storage_domains = storage, .targets = targets, .lanes = lanes});
  };
  exercise_tensor_graph<float>(context, compile);
  exercise_tensor_graph<hyle::simd::float16_t>(context, compile);
  exercise_tensor_graph<hyle::simd::bfloat16_t>(context, compile);
}

TEST(GgmlCudaGraph, VariadicPortsReserveMetadataEvenWhenValuesRepeat) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  auto memory =
      cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  Tensor input(memory.ref(), 1, 7), joined(memory.ref(), 1, 490),
      output(memory.ref(), 1, 490);
  const auto values = input.write(0);
  auto builder = graph::GraphBuilder::create().value();
  const auto x = builder.input(input.description).value();
  std::array<graph::ValueId, 70> ports;
  ports.fill(x);
  auto node = builder.add_node(compute::Operation(compute::Concat{-1}), ports);
  ASSERT_TRUE(node) << node.error().message();
  const auto concat = builder.result(*node).value();
  const auto y =
      builder.add(compute::Unary{compute::UnaryKind::kNeg}, concat).value();
  ASSERT_TRUE(builder.publish(concat).ok());
  ASSERT_TRUE(builder.publish(y).ok());
  auto logical = std::move(builder).finish().value();
  const std::array storage{graph::StorageDomain{.resource = memory.ref()}};
  const std::array targets{graph::ExecutionTarget{
      .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
  const std::array lanes{
      graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
  auto compiled = graph::compile(
      logical,
      {.storage_domains = storage, .targets = targets, .lanes = lanes});
  ASSERT_TRUE(compiled) << compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(), 1u);
  auto invocation = compiled->executable.create_invocation();
  ASSERT_TRUE(invocation) << invocation.error().message();
  ASSERT_TRUE(invocation->bind(x, input.view.as_const()).ok());
  ASSERT_TRUE(invocation->bind(concat, joined.view).ok());
  ASSERT_TRUE(invocation->bind(y, output.view).ok());
  auto queue = context.create_queue().value();
  const std::array queues{
      graph::QueueBinding{graph::ExecutionLaneId{0}, &queue}};
  ASSERT_TRUE(invocation->prepare_replay(queues).ok());
  auto done = invocation->submit(queue);
  ASSERT_TRUE(done) << done.error().message();
  ASSERT_TRUE(done->wait().ok());
  const auto positive = joined.read(), negative = output.read();
  for (std::size_t i = 0; i < positive.size(); ++i) {
    EXPECT_EQ(positive[i], values[i % 7]);
    EXPECT_EQ(negative[i], -values[i % 7]);
  }
}

TEST(GgmlCudaGraph, TypedSliceCopyBindsBeforeAlignedNativeMath) {
  using namespace ggml_cuda_graph_test;
  auto context = compute::Context::create(cuda::device(0).value(),
                                          graph::ggml_cuda::provider())
                     .value();
  auto memory =
      cuda::MemoryResource::create(context, cuda::MemoryKind::kDevice).value();
  Tensor backing(memory.ref(), 1, 8), copied(memory.ref(), 1, 7),
      output(memory.ref(), 1, 7), unaligned_output(memory.ref(), 1, 8);
  const auto values = backing.write(2);
  auto builder = graph::GraphBuilder::create().value();
  const auto x = builder.input(copied.description).value();
  const auto copy = builder.add(compute::Copy{}, x).value();
  const auto y =
      builder.add(compute::Unary{compute::UnaryKind::kNeg}, copy).value();
  ASSERT_TRUE(builder.publish(copy).ok());
  ASSERT_TRUE(builder.publish(y).ok());
  auto logical = std::move(builder).finish().value();
  const std::array storage{graph::StorageDomain{.resource = memory.ref()}};
  const std::array targets{graph::ExecutionTarget{
      .source = hyle::graph::ExecutionSource::acquire(context).value(), .default_storage = graph::StorageDomainId{0}}};
  const std::array lanes{
      graph::ExecutionLane{.target = graph::ExecutionTargetId{0}}};
  auto compiled = graph::compile(
      logical,
      {.storage_domains = storage, .targets = targets, .lanes = lanes});
  ASSERT_TRUE(compiled) << compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(), 1u);
  auto queue = context.create_queue().value();
  const std::array queues{
      graph::QueueBinding{graph::ExecutionLaneId{0}, &queue}};
  const auto input =
      compute::ConstTensorView::create(
          copied.description, backing.storage.view()
                                  .subview(sizeof(float), 7 * sizeof(float))
                                  .value())
          .value();
  auto invocation = compiled->executable.create_invocation().value();
  ASSERT_TRUE(invocation.bind(x, input).ok());
  ASSERT_TRUE(invocation.bind(copy, copied.view).ok());
  ASSERT_TRUE(invocation.bind(y, output.view).ok());
  ASSERT_TRUE(invocation.prepare_replay(queues).ok());
  auto done = invocation.submit(queue);
  ASSERT_TRUE(done) << done.error().message();
  ASSERT_TRUE(done->wait().ok());
  const auto a = copied.read(), b = output.read();
  for (std::size_t i = 0; i < 7; ++i) {
    EXPECT_EQ(a[i], values[i + 1]);
    EXPECT_EQ(b[i], -values[i + 1]);
  }
  // The published copy is also a math input, so writer alignment alone must
  // not permit binding it at a four-byte offset.
  auto rejected = compiled->executable.create_invocation().value();
  ASSERT_TRUE(rejected.bind(x, input).ok());
  ASSERT_TRUE(rejected.bind(y, output.view).ok());
  const auto bad_output =
      compute::TensorView::create(copied.description,
                                  unaligned_output.storage.view()
                                      .subview(sizeof(float), 7 * sizeof(float))
                                      .value())
          .value();
  const auto bound = rejected.bind(copy, bad_output);
  if (bound.ok()) {
    ASSERT_TRUE(rejected.prepare_replay(queues).ok());
    auto attempt = rejected.submit(queue);
    EXPECT_TRUE(!attempt || !attempt->wait().ok());
  } else {
    EXPECT_TRUE(bound.IsInvalidArgument());
  }
}
