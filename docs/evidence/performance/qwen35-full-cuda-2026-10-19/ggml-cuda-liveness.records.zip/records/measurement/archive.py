"""Preserve this measured fix without SDK, objects, images or duplicate raw vectors."""
from pathlib import Path
import hashlib, json, zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
TESTS = OUT.parent / 'ggml-cuda-liveness-tests'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-liveness.zip'
EXCLUDED = {'.obj', '.exe', '.map', '.lib', '.exp', '.pdb', '.dll', '.so', '.a', '.o', '.zip', '.pyc'}
ALLOWED = {'.py', '.json', '.log', '.cc', '.cpp', '.h', '.diff', '.xml', '.txt', '.md', '.f32', '.bf16', '.ps1', '.tsv', '.csv'}
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(b): return dict(bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

assert not DEST.exists()
summary = read(OUT / 'summary.json')
assert summary['sampled_peak_gpu_saving_bytes'] == 1201676288
assert all(x['all_byte_identical'] for x in summary['decision_vector_parity'].values())
tests = read(TESTS / 'summary.json')
assert tests['before_not_run'] is False
entries = []
payloads = {}
canonical = {}
for directory, prefix in [(OUT, 'measurement'), (TESTS, 'regression')]:
    for p in sorted(directory.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.name == 'archive-receipt.json': continue
        assert not p.is_symlink(), str(p)
        if p.suffix.lower() in EXCLUDED: continue
        assert p.suffix.lower() in ALLOWED, str(p)
        data = p.read_bytes(); identity = digest(data)
        name = prefix + '/' + p.relative_to(directory).as_posix()
        key = (identity['bytes'], identity['sha256'])
        stored = canonical.setdefault(key, name)
        if stored == name: payloads[name] = p
        entries.append(dict(name=name, source=str(p), stored_as=stored, **identity))
for relative in ['docs/architecture/compute-design.md', 'tools/qwen35_text/main.cc', 'tests/graph_provider_ggml_cuda/region_test.cc']:
    p = ROOT / relative; data = p.read_bytes(); name = 'current-product/' + relative
    identity = digest(data); stored = canonical.setdefault((identity['bytes'], identity['sha256']), name)
    if stored == name: payloads[name] = p
    entries.append(dict(name=name, source=str(p), stored_as=stored, **identity))
manifest = dict(schema='hyle.ggml.cuda.liveness.archive.v1', entries=entries,
    scope='Original-closure one-host-object change; 3 paired fresh-process T128 comparisons, one T21 pair; separate byte-parity diagnostics; original memory control and five regression cases across original4pass+fixture-stage-corrected1pass.',
    note='Identical payloads are stored once; each logical file names its stored_as ZIP entry and SHA256. Initial test fixture failure is preserved, not reported as pass.',
    intentionally_excluded=sorted(EXCLUDED),
    incomplete='Cross-region caller workspace design is read-only; full architecture goal and model/platform coverage remain open.')
raw = sum(x['bytes'] for x in entries); unique = sum(p.stat().st_size for p in payloads.values())
assert raw < 150*1024**2 and unique < 100*1024**2
with zipfile.ZipFile(DEST, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in payloads.items(): z.writestr(name, path.read_bytes())
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(payloads)+1
    for row in entries:
        expected = {k:row[k] for k in ['bytes','sha256']}
        assert digest(z.read(row['stored_as'])) == expected, row['name']
        assert digest(Path(row['source']).read_bytes()) == expected, row['source']
receipt = dict(destination=str(DEST), **digest(DEST.read_bytes()), zip_entries=len(payloads)+1,
    logical_files=len(entries), raw_logical_bytes=raw, unique_bytes=unique, identical_bytes_not_recopied=raw-unique,
    zip_crc_verified=True, every_payload_sha256_verified=True, source_drift=False, deleted_files=0)
(OUT/'archive-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
