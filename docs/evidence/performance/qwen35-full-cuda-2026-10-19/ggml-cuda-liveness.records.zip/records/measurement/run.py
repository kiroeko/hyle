"""Incremental host-only comparison of existing ggml CUDA allocation paths."""
from pathlib import Path
import difflib, hashlib, json, os, re, subprocess, sys, threading, time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
sys.path.insert(0, str(ARCH / 'qwen-gpu-comparison/memory-probe'))
from memory_probe import MemoryProbe

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value): Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def identity(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

BASE = read(ARCH / 'qwen-gpu-comparison/hyle-link-plan.json')['command']
TEMPLATE = read(ARCH / 'cuda-sdpa-mask/fresh-identities.json')[0]['command']
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': TEMPLATE[0]})
ENV['VSLANG'] = '1033'
ENV['PATH'] = os.pathsep.join(dict.fromkeys(str(Path(v).parent) for v in BASE if v.endswith('.lib') and Path(v).is_absolute())) + os.pathsep + ENV['PATH']
assert not ENV.get('GGML_CUDA_DISABLE_GRAPHS')

def command(tag, argv):
    assert not (OUT / (tag + '.result.json')).exists(), tag
    row = dict(argv=list(map(str, argv)), started=time.time())
    save(OUT / (tag + '.command.json'), row)
    with (OUT / (tag + '.stdout.log')).open('wb') as so, (OUT / (tag + '.stderr.log')).open('wb') as se:
        p = subprocess.Popen(row['argv'], cwd=ROOT, env=ENV, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = p.pid; save(OUT / 'live.json', row); row['exit'] = p.wait()
    row.update(terminal=True, finished=time.time()); save(OUT / (tag + '.result.json'), row)
    print(tag, row['exit'], round(row['finished'] - row['started'], 3), flush=True)
    if row['exit']:
        print((OUT / (tag + '.stdout.log')).read_text(errors='replace')[-5000:])
        print((OUT / (tag + '.stderr.log')).read_text(errors='replace')[-5000:])
        raise SystemExit(1)

def link(name, replacement=None):
    argv = [x for x in BASE if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    original = str(ARCH / 'cuda-admitted-ggml-stream-implementation/provider.obj')
    assert argv.count(original) == 1
    if replacement: argv[argv.index(original)] = str(replacement)
    assert all(Path(x).is_file() for x in argv if Path(x).is_absolute() and Path(x).suffix.lower() in {'.obj', '.lib'}), 'Missing cached link input'
    argv += ['/OUT:' + str(OUT / (name + '.exe')), '/MAP:' + str(OUT / (name + '.map')), '/IMPLIB:' + str(OUT / (name + '.lib'))]
    save(OUT / (name + '-link-plan.json'), dict(command=argv, original_link_plan=identity(ARCH / 'qwen-gpu-comparison/hyle-link-plan.json'), provider_object=identity(replacement or original)))
    command(name + '-link', argv)

def baseline():
    source = ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
    if (OUT / 'before.cc').exists():
        assert (OUT / 'before.cc').read_bytes() == source.read_bytes()
    else:
        (OUT / 'before.cc').write_bytes(source.read_bytes())
    save(OUT / 'baseline-source.json', identity(source))
    link('before')

def candidate():
    source = ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
    (OUT / 'candidate.cc').write_bytes(source.read_bytes())
    (OUT / 'source.diff').write_text(''.join(difflib.unified_diff((OUT / 'before.cc').read_text(encoding='utf-8').splitlines(True), source.read_text(encoding='utf-8').splitlines(True), fromfile='before.cc', tofile='candidate.cc')), encoding='utf-8')
    argv = [v for v in TEMPLATE if not v.lower().startswith(('/fo', '/fd')) and not v.lower().endswith('.cc')]
    argv += [str(source), '/Fo' + str(OUT / 'provider.obj')]
    command('provider-compile', argv)
    save(OUT / 'candidate-source.json', dict(source=identity(source), object=identity(OUT / 'provider.obj')))
    link('candidate', OUT / 'provider.obj')

def marker(line):
    for prefix, name in [('weights_load_seconds=', 'model_loaded'), ('initialized ', 'ready_before_prefill'), ('prefill tokens=', 'prefill_complete'), ('decode31 tokens=', 'inference_complete')]:
        if line.startswith(prefix): return name

def trial(tag, engine, prompt, trace=False):
    stage = OUT / tag; stage.mkdir(exist_ok=False)
    inputs = ARCH / ('qwen-gpu-comparison/128-prefill/inputs' if prompt == 128 else 'qwen-fixed-decode/science-inputs')
    tape = ARCH / ('qwen-gpu-comparison/128-prefill/decode.ids' if prompt == 128 else 'qwen-fixed-decode/science-decode.ids')
    argv = [OUT / (engine + '.exe'), '--inputs', inputs, '--decode-ids', tape, '--capacity', '256', '--progress', 'direct']
    if trace: argv += ['--trace', stage / 'trace', '--trace-level', 'decisions']
    row = dict(argv=list(map(str, argv)), engine=engine, prompt_tokens=prompt, trace=trace, binary=identity(argv[0]), started=time.time(), markers=[])
    save(stage / 'command.json', row)
    def reader(stream, output):
        for raw in iter(stream.readline, b''):
            output.write(raw)
            line = raw.decode('utf-8', errors='replace').rstrip(); name = marker(line)
            if name: row['markers'].append(dict(name=name, timestamp_ns=time.perf_counter_ns(), line=line))
    with MemoryProbe(interval_s=.05) as memory, (stage / 'stdout.log').open('wb') as so, (stage / 'stderr.log').open('wb') as se:
        row['popen_perf_ns'] = time.perf_counter_ns()
        p = subprocess.Popen(row['argv'], cwd=ROOT, env=ENV, stdout=so, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = p.pid; save(OUT / 'live.json', row)
        thread = threading.Thread(target=reader, args=(p.stderr, se), daemon=True); thread.start()
        memory.start(p.pid)
        row['exit'] = p.wait(); thread.join(); memory.stop(); save(stage / 'memory.json', memory.result())
        row['finished_perf_ns'] = time.perf_counter_ns()
    row.update(terminal=True, finished=time.time()); save(stage / 'result.json', row)
    print(tag, row['exit'], 'trace' if trace else 'performance', flush=True)
    if row['exit']:
        print((stage / 'stderr.log').read_text(errors='replace')[-6000:]); raise SystemExit(1)
    raw = json.loads((stage / 'stdout.log').read_text().splitlines()[-1])
    phases = []
    for line in (stage / 'stderr.log').read_text().splitlines():
        if re.match(r'^(prefill|decode\d+)\s+tokens=', line):
            parts = line.split(); fields = dict(x.split('=', 1) for x in parts[1:])
            phases.append(dict(phase=parts[0], tokens=int(fields['tokens']), seconds=float(fields['step_seconds']), predicted_id=int(fields['next'])))
    assert len(phases) == len(raw['generated_ids']) == 32
    assert phases[0]['tokens'] == prompt
    report = dict(engine=engine, trace=trace, phases=phases, predictions=raw['generated_ids'],
        prefill_tokens_per_second=prompt / phases[0]['seconds'], decode_tokens_per_second=31 / sum(x['seconds'] for x in phases[1:]),
        post_first_six_decode_tokens_per_second=25 / sum(x['seconds'] for x in phases[7:]), memory_peaks=read(stage / 'memory.json')['peaks'])
    save(stage / 'metrics.json', report)
    print('  pp', round(report['prefill_tokens_per_second'], 2), 'decode', round(report['post_first_six_decode_tokens_per_second'], 2), 'GPU_GiB', round(report['memory_peaks']['sampled_peak_gpu_dedicated_bytes'] / 1024**3, 4), flush=True)

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'baseline': baseline()
    elif mode == 'candidate': candidate()
    elif mode == 'trial': trial(sys.argv[2], sys.argv[3], int(sys.argv[4]), len(sys.argv) > 5 and sys.argv[5] == 'trace')
    elif mode == 'performance':
        for index, engine in [(1, 'before'), (2, 'candidate'), (3, 'candidate'), (4, 'before'), (5, 'before'), (6, 'candidate')]:
            trial(f'perf128-{index:02d}-{engine}', engine, 128)
        trial('perf21-before', 'before', 21)
        trial('perf21-candidate', 'candidate', 21)
    else: raise SystemExit('baseline/candidate/trial')
