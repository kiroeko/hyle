from pathlib import Path
import hashlib, json, statistics

OUT = Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def stats(xs): return dict(median=statistics.median(xs), min=min(xs), max=max(xs), values=xs)

engines = {}
for engine in ['before', 'candidate']:
    rows = []
    for p in sorted(OUT.glob('perf128-*-' + engine)):
        m, r = read(p / 'metrics.json'), read(p / 'result.json')
        assert r['terminal'] and r['exit'] == 0 and not m['trace']
        ready = next(x['timestamp_ns'] for x in r['markers'] if x['name'] == 'ready_before_prefill')
        rows.append(dict(trial=p.name, prefill_tokens_per_second=m['prefill_tokens_per_second'],
            decode_tokens_per_second=m['decode_tokens_per_second'],
            post_first_six_decode_tokens_per_second=m['post_first_six_decode_tokens_per_second'],
            process_to_ready_seconds=(ready - r['popen_perf_ns']) / 1e9, predictions=m['predictions'], **m['memory_peaks']))
    assert len(rows) == 3 and all(x['predictions'] == rows[0]['predictions'] for x in rows)
    engines[engine] = dict(trials=rows, statistics={k: stats([x[k] for x in rows]) for k in rows[0] if k not in {'trial', 'predictions'}})
assert engines['before']['trials'][0]['predictions'] == engines['candidate']['trials'][0]['predictions']
comparisons = {}
for tokens in [21, 128]:
    r = read(OUT / f'{tokens}-decision-parity.json')
    assert r['vectors'] == 64 and r['all_same']
    comparisons[str(tokens)] = dict(vectors=r['vectors'], all_byte_identical=r['all_same'])
before = engines['before']['statistics']; after = engines['candidate']['statistics']
report = dict(schema='hyle.ggml.cuda.liveness-comparison.v1',
    scope='Same current Hyle closure with one provider host object changed; 128 prompt tokens plus31 fixed decode inputs; same own state, two slots per shape, context256; 3 paired fresh processes B/A,A/B,B/A; no trace/profiler in performance runs.',
    short_control={e: read(OUT / ('perf21-' + e) / 'metrics.json') for e in engines},
    engines=engines, decision_vector_parity=comparisons,
    sampled_peak_gpu_saving_bytes=before['sampled_peak_gpu_dedicated_bytes']['median']-after['sampled_peak_gpu_dedicated_bytes']['median'],
    post_warm_decode_ratio=after['post_first_six_decode_tokens_per_second']['median']/before['post_first_six_decode_tokens_per_second']['median'],
    limits=['One region internal liveness only; independent region/shape/slot workspaces remain.',
        'First real binding installs reserved tensor metadata, not a zero-overhead first submit claim.',
        'Native auto-fusion can be affected by physical aliasing; full selected-model fusion coverage remains open.',
        'Same logits/hidden on these two input tapes is not general quality or numerical acceptance.',
        '50ms per-process Dedicated GPU sampling gives observed peak lower bounds; RAM WS includes shared/mapped pages.',
        'No new peer run; comparison with llama uses the original separately archived reference baseline.'])
(OUT / 'summary.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(saving_GiB=report['sampled_peak_gpu_saving_bytes']/1024**3,
    peak_gpu_GiB={e: r['statistics']['sampled_peak_gpu_dedicated_bytes']['median']/1024**3 for e,r in engines.items()},
    decode_tokens_per_second={e:r['statistics']['post_first_six_decode_tokens_per_second']['median'] for e,r in engines.items()},
    byte_identical_vectors=sum(x['vectors'] for x in comparisons.values())), indent=2))
