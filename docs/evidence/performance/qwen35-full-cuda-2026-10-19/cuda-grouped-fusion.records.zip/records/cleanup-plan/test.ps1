param([switch]$ReclaimCudaGroupedFusion)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimCudaGroupedFusion) { throw 'Use -ReclaimCudaGroupedFusion for this batch.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18'))
$taskStage = Join-Path $taskRoot 'cuda-grouped-fusion'
$archiveReceipt = Get-Content -LiteralPath (Join-Path $taskStage 'archive-verification.json') -Raw | ConvertFrom-Json
if (-not $archiveReceipt.CRC_and_every_payload_SHA_verified -or (Get-FileHash -LiteralPath $archiveReceipt.path -Algorithm SHA256).Hash -ne $archiveReceipt.sha256) { throw 'Verified archive required.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskStage 'reclaim-targets.json') -Raw | ConvertFrom-Json)
$retained = @(Get-Content -LiteralPath (Join-Path $taskStage 'retained-images.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  if ($resolved -in $retained.path) { throw "Retained image in deletion set: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes) { throw "Target changed: $resolved" }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $retained) {
  if ((Get-Item -LiteralPath $entry.path).Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Retained image changed: $($entry.path)" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
foreach ($entry in $targets) { if (Test-Path -LiteralPath $entry.path) { throw "Target still exists: $($entry.path)" } }
foreach ($entry in $retained) { if (-not (Test-Path -LiteralPath $entry.path)) { throw "Retained image missing: $($entry.path)" } }
@{targets=$targets;bytes=($targets | Measure-Object bytes -Sum).Sum;recursive=$false;objects_retained=$true;latest_qwen_cuda_and_shared_peer_retained=$true;old_baseline_relinkable=$true} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskStage 'reclaim-receipt.json') -Encoding utf8
