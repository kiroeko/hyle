"""Compose RoPE edits against locked upstream; apply only after exact replay."""
from pathlib import Path
import copy
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('rope_retained_seal', ARCH / 'cuda-bf16-dual-projection/seal_native.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
UPSTREAM = s.UPSTREAM
VERSION = s.VERSION.replace('-v15', '-explicit-rope-v17')


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    if s.sha(data) != row['before_sha256']:
        raise ValueError('Upstream source drift: ' + row['path'])
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        if data.count(before) != 1:
            raise ValueError('Nonunique patch context: ' + row['path'])
        data = data.replace(before, after, 1)
    return data


def main():
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    manifest_path = vendor / 'patches.json'
    runtime = ROOT / 'src/compute_ggml_runtime'
    before = STAGE / 'before-seal'
    before.mkdir(exist_ok=False)
    for name, path in (('patches.json', manifest_path), ('NOTICE.md', vendor / 'NOTICE.md'),
        ('dependency-lock.json', ROOT / 'cmake/HyleDependencyLock.json'),
        ('numerical_contract.h', ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h')):
        (before / name).write_bytes(path.read_bytes())
    draft = copy.deepcopy(s.read(manifest_path))
    delta = s.read(STAGE / 'native-overlay/replacements.json')
    native_records = {row['path']: row for row in s.read(STAGE / 'native-overlay/source-freeze.json')['files']}
    for change in delta['files']:
        if change['path'].startswith('hyle/'):
            continue
        row = next((row for row in draft['files'] if row['path'] == change['path']), None)
        if row is None:
            row = {'path': change['path'], 'before_sha256': s.sha((UPSTREAM / change['path']).read_bytes().replace(b'\r\n', b'\n')), 'edits': []}
            draft['files'].append(row)
        row['edits'].extend(change['edits'])
        row['after_sha256'] = s.sha(replay(row))
    proposed = STAGE / 'patches.rope-draft.json'
    s.save(proposed, draft)
    mixed, combined = STAGE / 'mixed-cpu-manifest.json', STAGE / 'combined-manifest.json'
    s.load('rope_mixed_cpu', runtime / 'prepare_mixed_cpu_manifest.py').derive(UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    s.load('rope_cuda_iq1', runtime / 'prepare_cuda_iq1_manifest.py').derive(UPSTREAM, mixed,
        proposed, vendor / 'iq1-patches.json', combined)
    materialized = {}
    for row in s.read(combined)['files']:
        data = replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Combined source hash differs: ' + row['path'])
        if row['path'] not in native_records:
            continue
        if s.sha(data) != native_records[row['path']]['after_sha256']:
            raise ValueError('Combined result differs from reviewed overlay: ' + row['path'])
        path = STAGE / 'native-source' / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        materialized[row['path']] = s.sha(data)
    if len(materialized) != 3:
        raise ValueError('Expected exactly the native main/unary/rope-header changes')
    contract = STAGE / 'native-overlay/source/hyle/numerical_contract.h'
    if s.sha(contract.read_bytes()) != native_records['hyle/numerical_contract.h']['after_sha256']:
        raise ValueError('Private numerical contract drift')
    provider = s.read(STAGE / 'provider-source-freeze.json')
    provider_path = ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'
    if s.sha(provider_path.read_bytes()) != provider['before_sha256']:
        raise ValueError('Provider source drift')
    # Apply the verified files. The original sources/manifests remain above.
    manifest_path.write_bytes(proposed.read_bytes())
    (ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h').write_bytes(contract.read_bytes())
    provider_path.write_bytes(Path(provider['overlay']).read_bytes())
    notice = vendor / 'NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip() + '''

Explicit-frequency RoPE has a private single-kernel NVIDIA CUDA carrier in the
existing precise unary translation unit. It preserves I32-to-F32 RN conversion,
F32 frequency multiplication, separate strict sin/cos, the original independent
RN/FTZ products and add/subtract, and the final typed rounding. Trigonometry is
shared by heads and matching batches without scratch allocation. Exact internal
dense input reuse is safe; partial overlaps and position/frequency overlap are
rejected through the existing native failure boundary. The private marker keeps
these explicit frequencies out of inverse-factor/YaRN kernels and fusers. Other
backends retain the existing decomposed graph. Runtime and performance results
remain separate from this source integration description.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'], cuda['vendored']['tree_sha256'] = VERSION, s.tree(vendor)
    for item in cuda['license']['files']:
        if item['root'] == 'hyle' and item['path'].endswith('NOTICE.md'):
            item['sha256'] = s.sha(notice.read_bytes())
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    s.save(STAGE / 'native-source-freeze.json', {'version': VERSION, 'source_id': source_id,
        'vendor_tree_sha256': cuda['vendored']['tree_sha256'], 'sources': materialized,
        'all_mixed_CPU_IQ1_CUDA_edits_replayed': True, 'SDK_modified': False,
        'public_API_changed': False, 'numerical_contract_changed': False})
    audit = 'include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\n'
    audit += 'hyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n'
    (STAGE / 'audit-native-lock.cmake').write_text(audit, encoding='utf-8')
    print('APPLIED', source_id, 'native files', len(materialized), flush=True)


if __name__ == '__main__':
    main()
