"""Retain the successful three production objects; compile the corrected fixture."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('grouped_resume_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
out = STAGE / 'checks/20261019T123025'
old = c.read(out / 'plan.json')
tests = c.read(STAGE / 'tests-source-freeze.json')
row = tests['files'][0]
product = ROOT / row['target']
before = Path(row['after']['path']).read_bytes()
after = product.read_bytes()
needle = b'#include "hyle/compute/providers/cuda.h"\n'
if before.count(needle) != 1 or before.replace(needle, needle+b'#include "hyle/compute/low_precision.h"\n', 1) != after:
    raise ValueError('Only the missing explicit public declaration header may change')
backup = STAGE / 'before-test-include-correction'
backup.mkdir(exist_ok=False)
for name in ('tests-source-freeze.json', 'tests-plan.json', 'application.json', 'tests.diff'):
    (backup / name).write_bytes((STAGE / name).read_bytes())
(backup / 'stable_silu_test.cc').write_bytes(before)
Path(row['after']['path']).write_bytes(after)
row['after'] = b.identity(row['after']['path'])
c.save(STAGE / 'tests-source-freeze.json', tests)
test_plan = c.read(STAGE / 'tests-plan.json')
test_plan['compile'][0]['source'] = b.identity(product)
test_plan['compile'][0]['overlay'] = b.identity(row['after']['path'])
c.save(STAGE / 'tests-plan.json', test_plan)
application = c.read(STAGE / 'application.json')
target = next(x for x in application['files'] if x['path'] == str(product))
target['after_sha256'] = b.identity(product)['sha256']
c.save(STAGE / 'application.json', application)
changed = {c.key(x) for x in (product, STAGE/'tests-source-freeze.json', STAGE/'tests-plan.json', STAGE/'application.json')}
for identity in old['frozen']:
    if c.key(identity['path']) not in changed and not b.same(identity):
        raise ValueError('Unexpected source/recipe/header drift')
plan = c.read(out / 'plan.json')
plan['frozen'] = [b.identity(x['path']) if c.key(x['path']) in changed else x for x in plan['frozen']]
plan['frozen'].extend(b.identity(x) for x in (Path(__file__), ROOT/'include/hyle/compute/low_precision.h'))
fixture = next(x for x in plan['compile'] if x['tag'] == 'stable-test')
fixture['source'] = b.identity(product)
plan['fixture_header_correction'] = 'Explicitly include low_precision.h; original compiler failure/source retained.'
path = out / 'plan-corrected-test.json'
c.save(path, plan)
build.check(plan)
build.check_cached(plan)
fresh = []
for entry in plan['compile']:
    if entry['tag'] == 'stable-test':
        continue
    identity = c.read(out / (entry['tag'] + '-identity.json'))['object']
    if not b.same(identity):
        raise ValueError('Successful production object drift')
    fresh.append(identity)
env, _ = b.environment(plan['links']['qwen']['command'], plan['links']['qwen']['inputs'], out)
c.execute('stable-test-corrected-compile', fixture['command'], env, out)
build.check(plan)
identity = b.identity(fixture['object'])
fresh.append(identity)
c.save(out/'stable-test-identity.json', {'command':fixture['command'], 'source':fixture['source'], 'object':identity})
for tag, link in plan['links'].items():
    c.execute(tag+'-link', link['command'], env, out)
    build.check(plan)
    c.save(out/(tag+'-image.json'),b.identity(link['image']))
build.check_cached(plan)
identities = {c.key(x['path']):x for x in [*plan['cached_inputs'],*fresh]}
for tag, link in plan['links'].items():
    c.save(out/(tag+'-link-plan.json'),{'command':link['command'],'inputs':[identities[c.key(x)] for x in link['inputs']]})
c.save(out/'summary.json',{'passed':True,'native_TUs':1,'host_TUs':3,'SDK_build':False,'GPU_run':False,
    'reused_successful_production_compiles':3,'failed_fixture_compile_preserved':True,'native_source_id':plan['native_source_id']})
c.save(STAGE/'test-include-correction.json',{'before':b.identity(backup/'stable_silu_test.cc'),'after':b.identity(product),
    'only_missing_explicit_header_added':True,'prior_failure':b.identity(out/'stable-test-compile.result.json'),
    'successful_production_objects_recompiled':False,'plan':b.identity(path)})
print('BUILD_COMPLETE',path,flush=True)
