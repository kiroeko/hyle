"""Two short Q8 grouped-GLU traces; report actual control/candidate carriers."""
from pathlib import Path
import argparse
import collections
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
TEST='GgmlCudaGroupedFusion.Q8TopTenFinalOnlyUsesPublicGraphAcrossTwoTokenExtents'
ARMS=('control-cuda','cuda')
PREDICTIONS={
    'control-cuda':{'standard_fused':0,'standard_unfused':8,'MoE_fused':0,'MoE_unfused':8,'standalone_GLU':16},
    'cuda':{'standard_fused':4,'standard_unfused':0,'MoE_fused':4,'MoE_unfused':0,'standalone_GLU':8},
}


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build=load('grouped_profile_build',STAGE/'build.py')
a=load('grouped_profile_analysis',ARCH/'cuda-fusion-precision/profile-analysis.py')
b,c=build.b,build.c


def boolean(argument):
    value=''.join(argument.split())
    if value in ('true','(bool)1'):return True
    if value in ('false','(bool)0'):return False
    return None


def inspect(arm,out):
    directory=out/arm
    stem=directory/'grouped-glu'
    a.PROFILE=directory
    data=a.load(Path(str(stem)+'.sqlite'),Path(str(stem)+'_cuda_gpu_kern_sum.csv'),candidate=True)
    symbols=collections.Counter(row['name'] for row in data['kernels'])
    carriers=[]
    for name,count in symbols.items():
        for family,kernel in (('MoE','mul_mat_vec_q_moe'),('standard','mul_mat_vec_q')):
            arguments=a.template_arguments(name,kernel)
            if not arguments:continue
            carriers.append({'family':family,'symbol':name,'count':count,
                'template_arguments':arguments,'has_fusion':boolean(arguments[2]) if len(arguments)>2 else None})
            break
    standalone=[]
    for name,count in symbols.items():
        arguments=a.template_arguments(name,'unary_gated_op_kernel')
        if arguments and 'op_silu' in arguments[0]:
            standalone.append({'symbol':name,'count':count,'template_arguments':arguments})
    observed={key:0 for key in PREDICTIONS[arm]}
    for row in carriers:
        if row['has_fusion'] is not None:
            observed[row['family']+('_fused' if row['has_fusion'] else '_unfused')]+=row['count']
    observed['standalone_GLU']=sum(row['count'] for row in standalone)
    moe=[row for row in data['kernels'] if a.template_arguments(row['name'],'mul_mat_vec_q_moe')]
    geometry=collections.Counter((row['gridX'],row['gridY'],row['gridZ'],row['blockX'],row['blockY'],row['blockZ']) for row in moe)
    geometry_rows=[{'grid':list(key[:3]),'block':list(key[3:]),'count':count} for key,count in sorted(geometry.items())]
    target=ET.parse(directory/'target.xml').getroot()
    counts={key:int(target.attrib.get(key,'0')) for key in ('tests','failures','disabled','errors')}
    counts['skipped']=sum(int(row.attrib.get('skipped','0')) for row in target.findall('testsuite'))
    cases=target.findall('.//testcase')
    profile=c.read(directory/'profile.result.json')
    checks={
        'CSV_SQLite_per_symbol_equal':data['receipt']['csv_sqlite_per_symbol_counts_equal'],
        'no_graph_API_errors':not data['receipt']['graph_api_failures'],
        'target_process_terminal_zero':profile.get('terminal') is True and profile['exit']==0,
        'single_requested_test_passed':counts=={'tests':1,'failures':0,'disabled':0,'errors':0,'skipped':0},
        'actual_XML_case_completed':len(cases)==1 and cases[0].get('name')==TEST.split('.',1)[1] and
            cases[0].get('status')=='run' and cases[0].get('result')=='completed' and
            not cases[0].findall('failure') and not cases[0].findall('skipped'),
        'MMVQ_fusion_flags_resolved':all(row['has_fusion'] is not None for row in carriers),
    }
    ancillary={
        'quantize_Q8_1':sum(count for name,count in symbols.items() if 'quantize_q8_1' in name),
        'checked_index_guard':sum(count for name,count in symbols.items()
            if 'hyle::compute::ggml_cuda::internal' in name and '::check(' in name),
        'checked_publish_guard':sum(count for name,count in symbols.items()
            if 'hyle::compute::ggml_cuda::internal' in name and '::publish(' in name),
    }
    result={'trace_integrity_passed':all(checks.values()),'checks':checks,'receipt':data['receipt'],
        'arm':arm,'test':TEST,'target':counts,'carriers':carriers,'standalone_GLU_symbols':standalone,
        'observed':observed,'prediction':PREDICTIONS[arm],
        'prediction_observed':observed==PREDICTIONS[arm],
        'MoE_launch_geometry':geometry_rows,
        'MoE_matches_T2_top10_geometry':bool(moe) and all(row['gridX']==4 and row['gridY']==10 and row['gridZ']==1 and
            row['blockX']==32 and row['blockY']==2 and row['blockZ']==1 for row in moe),
        'ancillary_kernel_counts':ancillary,'all_kernel_counts':dict(symbols),
        'physical_kernel_instances':len(data['kernels']),
        'expected_candidate_Graph_submissions':8,'independent_standalone_GLU_oracles':8,
        'complete_model_trace':False,'throughput_claim':False,
        'interpretation':'T1 uses standard MMVQ; T2 uses the dedicated MoE MMVQ. This selected graph has no bias/scales, so a resolved true fusion carrier plus oracle-only standalone GLU and passing math can establish a full gate/up GLU. Actual observations are retained even when they miss the prediction.'}
    c.save(directory/'analysis.json',result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan',type=Path)
    parser.add_argument('--analyze',action='store_true')
    args=parser.parse_args()
    plan_path=args.plan.resolve()
    plan=c.read(plan_path)
    out=STAGE/'profile-tests'
    if not args.analyze:
        build.a.check(plan)
        if not c.read(plan_path.parent/'summary.json')['passed'] or not c.read(plan_path.parent/'run-cuda-final/summary.json')['passed']:
            raise ValueError('Successful build and passing five-case candidate tests required')
        out.mkdir(exist_ok=False)
        original=c.read(ARCH/'cuda-reshape-reuse/profile-qwen.command.json')['command']
        binary_index=original.index('--inputs')-1
        for arm in ARMS:
            directory=out/arm
            directory.mkdir(exist_ok=False)
            (directory/'tmp').mkdir()
            stem=directory/'grouped-glu'
            link=plan['links'][arm]
            image=b.identity(link['image'])
            if image!=c.read(plan_path.parent/(arm+'-image.json')):
                raise ValueError('Actual profiled image differs: '+arm)
            profile=[('--output='+str(stem)) if value.startswith('--output=') else value for value in original[:binary_index]]
            profile += [image['path'],'--gtest_color=no','--gtest_filter='+TEST,'--gtest_output=xml:'+str(directory/'target.xml')]
            commands={
                'profile':profile,
                'export':[original[0],'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],
                'stats':[original[0],'stats','--report=cuda_gpu_kern_sum,cuda_api_sum','--format=csv','--output='+str(stem),str(stem)+'.sqlite'],
            }
            env,runtime=b.environment(link['command'],link['inputs'],directory)
            c.save(directory/'inputs.json',{'image':image,'plan':b.identity(plan_path),'runner':b.identity(Path(__file__)),
                'analysis':b.identity(ARCH/'cuda-fusion-precision/profile-analysis.py'),
                'checklist':b.identity(STAGE/'analysis-checklist.json'),'commands':commands,
                'runtime_link_inputs':link['inputs'],'runtime_directories':runtime,
                'prediction':PREDICTIONS[arm],'profiler_collections':1,'throughput_claim':False,
                'test_source':c.read(STAGE/'tests-source-freeze.json')['files'][0]['after']})
            for tag,command in commands.items():
                c.execute(tag,command,env,directory)
    reports={arm:inspect(arm,out) for arm in ARMS}
    integrity=all(row['trace_integrity_passed'] for row in reports.values())
    full=reports['cuda']['prediction_observed'] and reports['cuda']['MoE_matches_T2_top10_geometry']
    control=reports['control-cuda']['prediction_observed']
    summary={'passed':integrity and full and control,'trace_integrity_passed':integrity,
        'candidate_full_grouped_GLU_observed':full,'control_original_split_observed':control,
        'arms':reports,'profiler_collections':2,'complete_model_trace':False,'throughput_claim':False,
        'limits':['Only the requested Q8 top10 T1/T2 public Graph filter was traced.',
            'MXFP4/mixed-format/published-intermediate/extent-negative tests are outside these short traces.',
            'One logical Graph step is not a physical fusion proof; counts come from official CSV/SQLite.',
            'Profiler timing is not a throughput result, model-quality result, or cross-platform validation.']}
    c.save(out/'analysis.json',summary)
    print('GROUPED_PHYSICAL',{'passed':summary['passed'],'control':reports['control-cuda']['observed'],
        'candidate':reports['cuda']['observed'],'full_grouped_GLU':full},flush=True)
    if not summary['passed']:
        raise ValueError('Retained physical trace does not establish the requested full grouped-GLU change')


if __name__=='__main__':
    main()
