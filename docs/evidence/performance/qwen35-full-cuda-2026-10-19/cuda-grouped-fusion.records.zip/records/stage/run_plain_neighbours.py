"""Cover unchanged duplicate-ID slot expansion in the changed plain lowering."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('grouped_plain_build',STAGE/'build.py')
build=importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b,c=build.b,build.c
path=Path(sys.argv[1]).resolve()
plan=c.read(path)
build.check(plan)
out=path.parent/'run-plain'
out.mkdir(exist_ok=False)
(out/'tmp').mkdir()
link=plan['links']['cuda']
env,dirs=b.environment(link['command'],link['inputs'],out)
selected=':'.join('GgmlCudaTensor.'+name for name in (
    'DenseBfloatGroupedExpertsUseNativeMulMatIdAndReplay',
    'LargeGroupedF32RowsRetainNonTf32OperandsAndRepeatedIds',
    'CheckedExpertIdsKeepOutputAndAllowRecreatedInvocationRetry'))
c.save(out/'runtime-environment.json',{'actual_link_inputs':link['inputs'],'runtime_dirs':dirs})
c.execute('plain-neighbours',[link['image'],'--gtest_color=no','--gtest_filter='+selected,
    '--gtest_output=xml:'+str(out/'target.xml')],env,out)
root=ET.parse(out/'target.xml').getroot()
counts={key:int(root.attrib.get(key,'0')) for key in ('tests','failures','disabled','errors')}
counts['skipped']=sum(int(row.attrib.get('skipped','0')) for row in root.findall('testsuite'))
passed=counts=={'tests':3,'failures':0,'disabled':0,'errors':0,'skipped':0}
c.save(out/'summary.json',{'passed':passed,'counts':counts,'runner':b.identity(Path(__file__)),
    'scope':'Existing F32/BF16 plain grouped duplicate-ID path and checked failure/recreated-slot regression; no full-model coverage claim.'})
if not passed:raise ValueError('Expected three plain neighbours without skips')
print('PLAIN_NEIGHBOURS',counts,flush=True)
