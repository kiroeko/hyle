"""Apply reviewed grouped topology and exactly replay the native CUDA patch."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('grouped_native_replay', STAGE.parent / 'cuda-explicit-rope/seal.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
s = prior.s


def verify(row):
    path = Path(row['path'])
    if not path.is_absolute():
        path = ROOT / path
    data = path.read_bytes()
    if len(data) != row['bytes'] or s.sha(data) != row['sha256']:
        raise ValueError('Reviewed identity differs: ' + str(path))
    return data


def main():
    host = s.read(STAGE / 'source-freeze.json')
    tests = s.read(STAGE / 'tests-source-freeze.json')
    applied = []
    for row in host['files'] + tests['files']:
        product = ROOT / row.get('product', row.get('target'))
        before, after = verify(row['before']), verify(row['after'])
        if product.read_bytes() != before:
            raise ValueError('Product drift: ' + str(product))
        applied.append({'path': str(product), 'before_sha256': s.sha(before),
                        'after_sha256': s.sha(after)})
    verify(host['diff'])
    verify(tests['diff'])
    verify(tests['fragment'])
    native = s.read(STAGE / 'native-overlay/source-freeze.json')
    delta = s.read(STAGE / 'native-overlay/replacements.json')['files']
    if len(delta) != 1:
        raise ValueError('Expected only one native translation unit')
    change = delta[0]
    relative = change['path']
    original = Path(native['source']).read_bytes()
    target = (STAGE / 'native-overlay/source' / relative).read_bytes()
    if s.sha(original) != native['before_sha256'] or s.sha(target) != native['after_sha256']:
        raise ValueError('Reviewed native source drift')
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    runtime = ROOT / 'src/compute_ggml_runtime'
    mixed = STAGE / 'mixed-cpu-manifest.json'
    s.load('grouped_mixed', runtime / 'prepare_mixed_cpu_manifest.py').derive(prior.UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    composer = s.load('grouped_iq1', runtime / 'prepare_cuda_iq1_manifest.py')
    initial = STAGE / 'before-combined.json'
    composer.derive(prior.UPSTREAM, mixed, vendor / 'patches.json', vendor / 'iq1-patches.json', initial)
    current = next(row for row in s.read(initial)['files'] if row['path'] == relative)
    if prior.replay(current) != original:
        raise ValueError('Current combined native baseline differs')
    manifest = s.read(vendor / 'patches.json')
    row = next(row for row in manifest['files'] if row['path'] == relative)
    row['edits'].extend(change['edits'])
    row['after_sha256'] = s.sha(prior.replay(row))
    proposed = STAGE / 'patches.draft.json'
    s.save(proposed, manifest)
    combined = STAGE / 'combined-manifest.json'
    composer.derive(prior.UPSTREAM, mixed, proposed, vendor / 'iq1-patches.json', combined)
    for row in s.read(combined)['files']:
        data = prior.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Combined replay SHA mismatch: ' + row['path'])
        if row['path'] == relative and data != target:
            raise ValueError('Reviewed target differs from full combined replay')
    before = STAGE / 'before-seal'
    before.mkdir(exist_ok=False)
    for name, path in (('patches.json', vendor / 'patches.json'), ('NOTICE.md', vendor / 'NOTICE.md'),
                       ('dependency-lock.json', ROOT / 'cmake/HyleDependencyLock.json')):
        (before / name).write_bytes(path.read_bytes())
    destination = STAGE / 'native-source' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(target)
    for row in host['files'] + tests['files']:
        (ROOT / row.get('product', row.get('target'))).write_bytes(verify(row['after']))
    (vendor / 'patches.json').write_bytes(proposed.read_bytes())
    notice = vendor / 'NOTICE.md'
    notice.write_text(notice.read_text(encoding='utf-8').rstrip() + '''

Indexed quantized MMVQ fusion uses the token axis for its batch qualification;
the selected expert slots remain channels. Launch qualification uses the actual
device grid.y limits captured during the existing device-info initialization,
for both activation staging and output slots. Backend support rejects only the
MMVQ domain that would otherwise select an invalid launch; larger-token MMQ
qualification, plain floating MMVF, numerical math, and shared CUDA ABI remain
unchanged. Hyle's cold lowering shares checked IDs only for identical original
tensor/count/extent, interns dense metadata by actual tensor and shape, and
retains native grouped producer edges for eligible separate GLU. Public values,
extra readers, duplicate IDs, per-consumer checks and failure publication remain
protected; no payload copies or additional execution mechanism are introduced.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v22'
    cuda['vendored']['tree_sha256'] = s.tree(vendor)
    for item in cuda['license']['files']:
        if item['root'] == 'hyle' and item['path'].endswith('NOTICE.md'):
            item['sha256'] = s.sha(notice.read_bytes())
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    s.save(STAGE / 'native-source-freeze.json', {'version': cuda['version'], 'source_id': source_id,
        'sources': {relative: s.sha(target)}, 'vendor_tree_sha256': cuda['vendored']['tree_sha256'],
        'all_mixed_CPU_IQ1_CUDA_edits_replayed': True, 'SDK_modified': False,
        'private_fusion_argument_ABI_changed': False, 'public_API_changed': False,
        'numerical_contract_changed': False})
    s.save(STAGE / 'application.json', {'files': applied, 'native_source_id': source_id,
        'native_sha256': s.sha(target), 'validation_run': False})
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED', source_id, flush=True)


if __name__ == '__main__':
    main()
