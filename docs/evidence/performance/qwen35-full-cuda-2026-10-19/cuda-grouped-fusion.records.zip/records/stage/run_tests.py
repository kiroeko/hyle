"""Run same-test old grid admission control, then all changed-owner neighbours."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('grouped_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
build.check(plan)
if not c.read(path.parent / 'summary.json')['passed']:
    raise ValueError('Successful build required')
out = path.parent / 'run-cuda-final'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()


def counts(name):
    root = ET.parse(out / (name + '.xml')).getroot()
    result = {k: int(root.attrib.get(k, '0')) for k in ('tests', 'failures', 'disabled', 'errors')}
    result['skipped'] = sum(int(x.attrib.get('skipped', '0')) for x in root.findall('testsuite'))
    return result


for arm in ('control-cuda', 'cuda'):
    link = plan['links'][arm]
    env, directories = b.environment(link['command'], link['inputs'], out)
    c.save(out / (arm + '-runtime-environment.json'), {'runtime_link_input_paths': link['inputs'],
        'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
    selected = ('GgmlCudaGroupedFusion.NativeIndexedChannelsRespectActualDeviceGridY' if arm == 'control-cuda' else
        'CudaStableSilu.*:GgmlCudaDualProjection.*:GgmlCudaExplicitRope.*:GgmlCudaFusionLayout.*:'
        'GgmlCudaFusionPrecision.*:GgmlCudaFusionAllocation.*:GgmlCudaGroupedFusion.*')
    command = [link['image'], '--gtest_color=no', '--gtest_filter=' + selected,
               '--gtest_output=xml:' + str(out / (arm + '.xml'))]
    try:
        c.execute(arm, command, env, out)
    except RuntimeError:
        if arm != 'control-cuda':
            raise
    actual = counts(arm)
    if arm == 'control-cuda':
        expected = {'tests': 1, 'failures': 1, 'disabled': 0, 'errors': 0, 'skipped': 0}
        root = ET.parse(out / (arm + '.xml')).getroot()
        failures = root.findall('.//failure')
        if actual != expected or len(failures) != 1 or 'supported(maximum+1)' not in failures[0].attrib.get('message', ''):
            raise ValueError('Old native must reproduce only the metadata grid qualification failure')
    else:
        expected = {'tests': 25, 'failures': 0, 'disabled': 0, 'errors': 0, 'skipped': 0}
        if actual != expected:
            raise ValueError('Expected25 relevant cases without skip/failure')
c.save(out / 'summary.json', {'passed': True, 'counts': counts('cuda'),
    'old_native_metadata_control': counts('control-cuda'), 'runner': b.identity(Path(__file__)),
    'physical_fusion_proof': False, 'invalid_grid_submitted': False})
print('GROUPED_TESTS', counts('cuda'), flush=True)
