"""Freeze a single existing CUDA test owner; no product edits/build/GPU."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
relative='tests/graph_route_cuda/stable_silu_test.cc'
fragment=STAGE/'grouped-tests.inc'
before=(ROOT/relative).read_bytes()
assert hashlib.sha256(before).hexdigest()=='f5581caa08a066b3af4bff7c7dc435aa8b26887edcf5ca5c1977e71b46a1df9e'
after=before+b'\n'+fragment.read_bytes()
target=STAGE/'test-overlay'/relative
target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes(after)
(STAGE/'tests.diff').write_text(''.join(difflib.unified_diff(before.decode('utf-8').splitlines(True),after.decode('utf-8').splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)),encoding='utf-8')

def identity(path):
    path=Path(path)
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

baseline=ARCH/'cuda-fusion-allocation/checks/20261019T115201/stable-test-identity.json'
recipe=json.loads(baseline.read_text(encoding='utf-8-sig'))
command=recipe['command']
tests=dict(state='Scratch-only final test source; not applied, compiled, or executed.',
    files=[dict(target=relative,before=identity(ROOT/relative),after=identity(target))],
    fragment=identity(fragment),diff=identity(STAGE/'tests.diff'))
(STAGE/'tests-source-freeze.json').write_text(json.dumps(tests,indent=2)+'\n',encoding='utf-8')
plan=dict(state='Prepared commands and regression scope only; no tests/build/GPU run.',
    compile=[dict(tag='stable-test',source={**identity(target),'path':str(ROOT/relative)},
                  overlay=identity(target),command_template=command,recipe=identity(baseline),old_object=recipe['object'])],
    filter='GgmlCudaGroupedFusion.*',tests=5,
    cases=['Q8TopTenFinalOnlyUsesPublicGraphAcrossTwoTokenExtents',
           'Mxfp4TopTenFinalOnlyUsesPublicGraphAcrossTwoTokenExtents',
           'PublishedQuantizedProjectionsAndReadersRemainObservable',
           'CheckedIdsSeparateExpertExtentsAndRecoverAcrossInvocations',
           'NativeIndexedChannelsRespectActualDeviceGridY'],
    functional_domains=dict(storage=['Q8_0/Q8_0','MXFP4/MXFP4','Q8_0/MXFP4'],
        positive_shapes=['E12,K32,N8,T1,S10','E12,K32,N8,T2,S10'],
        repeated_ids=True,invocations=2,rebind_rounds=2,
        constants_are_not_math_outputs=True,only_final_glu_is_published_in_positive_cases=True,
        diagnostics_publish=['GLU','gate','up','Neg(gate)'],
        extent_control='gate logicalE11 before upE12; physical dynamic bank buffers retain E12. IDs -1,11,12 preserve every published output; same invocation valid retry must succeed.',
        integer_input_is_immutable=True,
        oracle='CPU GGML traits decode actual stored weights, independent FP64 single-nonzero dot; activation127/128 times binary power has exact Q8_1 representation. Separate original one-op CUDA GLU cannot share a MatMul fusion.',
        tolerance='Published dot/Neg and preserved outputs are bit-exact; GLU uses the existing stable_silu_test.cc expect_value<float> domain without enlargement.',
        metadata_only_grid='Actual cudaDeviceProp.maxGridSize[1]; S10 supports true, S=maxY+1 supports false when native int32 extent can represent it. No payload allocation, submission, or deliberately invalid kernel launch.'),
    physical_trace=dict(filter='GgmlCudaGroupedFusion.Q8TopTenFinalOnlyUsesPublicGraphAcrossTwoTokenExtents',
        expected_candidates=8,expected_independent_standalone_glu=8,
        observation='Classify actual MMVQ_moe has_fusion=true/false instances and standalone GLU from official CSV/SQLite; report observed counts even if lower than eight. Graph step_count alone is not physical proof.',
        no_profiler_run_yet=True),
    minimal_closure=dict(host=['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
        'src/compute_provider_ggml_cuda/tensor_program.cc',relative],
        private_header_consumers='rg confirms tensor_program.h/lower_tensor_operation only in those two provider owners.',
        native=['ggml-cuda.cu'],
        base_links={name:str(ARCH/f'batch-layout-query-reuse/checks/20261019T120828-test-define/{name}-link-plan.json') for name in ('cuda','qwen')},
        replacement_counts={'cuda':4,'qwen':3},link_input_counts={'cuda':133,'qwen':125},
        SDK_rebuild=False,new_test_TU=False,
        reused_coherent_headers=str(ARCH/'cuda-fusion-precision/header-closure.json'),
        provider_recipe=str(ARCH/'cuda-fusion-allocation/checks/20261019T115201/provider-identity.json'),
        tensor_program_recipe=str(ARCH/'recurrent-gdn-schema/checks/20261019T113131/22-compute_provider_ggml_cuda-tensor_program-identity.json')))
(STAGE/'tests-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(source=identity(target),freeze=identity(STAGE/'tests-source-freeze.json'),plan=identity(STAGE/'tests-plan.json')),indent=2))
