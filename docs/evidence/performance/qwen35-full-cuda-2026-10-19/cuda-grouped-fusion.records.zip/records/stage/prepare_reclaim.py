"""Record exact rebuildable files after the retained candidate/control observations."""
from pathlib import Path
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=STAGE.parents[2]
out=STAGE/'checks/20261019T123025'
base=ARCH/'batch-layout-query-reuse/checks/20261019T120828-test-define'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path=path.resolve()
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}


paths=[]
for path in (base/'qwen-image.json',base/'cuda-image.json',out/'control-cuda-image.json'):
    expected=read(path)
    actual=identity(Path(expected['path']))
    if actual!=expected:raise ValueError('Historical/control image identity differs')
    paths.append(Path(actual['path']))
for stem in ('cuda','qwen','control-cuda'):
    for suffix in ('.map','.lib','.exp'):
        path=out/(stem+suffix)
        if path.exists():paths.append(path)
retained=[read(out/(name+'-image.json')) for name in ('cuda','qwen')]
retained.append(identity(ARCH/'cuda-explicit-rope/performance-prepared/peer.exe'))
for row in retained:
    if identity(Path(row['path']))!=row:raise ValueError('Retained image differs')
targets=[]
for path in paths:
    if not path.resolve().is_relative_to(ARCH) or path.is_dir() or path.suffix.lower() not in ('.exe','.map','.lib','.exp'):
        raise ValueError('Cleanup target outside exact allowed scope')
    if any(str(path.resolve()).casefold()==x['path'].casefold() for x in retained):
        raise ValueError('Retained image in cleanup set')
    targets.append(identity(path))
if len({x['path'].casefold() for x in targets})!=len(targets):raise ValueError('Duplicate cleanup target')
(STAGE/'reclaim-targets.json').write_text(json.dumps(targets,indent=2)+'\n',encoding='utf-8')
(STAGE/'retained-images.json').write_text(json.dumps(retained,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(targets),'bytes':sum(x['bytes'] for x in targets),'retained_images':len(retained)}),flush=True)
