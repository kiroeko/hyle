"""Correct indexed MMVQ batch axes and retain actual launch-grid qualification."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
BASE = STAGE.parent / 'cuda-fusion-allocation/native-source/src/ggml-cuda/ggml-cuda.cu'
EXPECTED = '1035fba8c1c56a8f96723d2d8f39d57437a68173d688beeebfda75af7e5ce4fc'
old = BASE.read_bytes()
if hashlib.sha256(old).hexdigest() != EXPECTED:
    raise ValueError('Expected the retained v21 native main')
text, edits = old.decode(), []


def replace(before, after):
    global text
    if text.count(before) != 1:
        raise ValueError('Nonunique native patch context')
    text = text.replace(before, after, 1)
    edits.append({'before': before, 'after': after})


replace('static ggml_cuda_device_info ggml_cuda_init() {', '''// Private launch limits share the original device-info initialization. No
// shared header/ABI changes or additional hot CUDA attribute queries.
static std::array<int, GGML_CUDA_MAX_DEVICES> ggml_cuda_mmvq_grid_y{};

static ggml_cuda_device_info ggml_cuda_init() {''')
replace('''        CUDA_CHECK(cudaGetDeviceProperties(&prop, physical_id));

        // a virtual device owns''', '''        CUDA_CHECK(cudaGetDeviceProperties(&prop, physical_id));
        ggml_cuda_mmvq_grid_y[id] = prop.maxGridSize[1];

        // a virtual device owns''')
replace('static bool ggml_cuda_should_fuse_mul_mat_vec_q(const ggml_tensor * tensor, bool require_bound = true) {', '''// Indexed MMVQ stages activation channels and launches output slots on grid.y.
// Read only limits captured by the same completed device-info initialization.
static bool ggml_cuda_indexed_mmvq_grid(const ggml_tensor * tensor, int device) {
    ggml_cuda_info();
    const int limit = ggml_cuda_mmvq_grid_y[device];
    return limit > 0 && tensor->src[1]->ne[1] <= limit && tensor->ne[1] <= limit;
}

static bool ggml_cuda_should_fuse_mul_mat_vec_q(const ggml_tensor * tensor, bool require_bound = true) {''')
replace('''    bool use_mul_mat_vec_q = ggml_is_quantized(src0->type) && !bad_padding_clear && src1->type == GGML_TYPE_F32 &&
                             dst->type == GGML_TYPE_F32 && src1->ne[1] <= MMVQ_MAX_BATCH_SIZE;

    // fusion is not universally faster on Pascal
    const int cc = ggml_cuda_info().devices[ggml_cuda_get_device()].cc;''', '''    // MMID's ne1 is the selected-slot/channel axis; its actual batch is ne2.
    const int64_t batch = tensor->op == GGML_OP_MUL_MAT_ID ? src1->ne[2] : src1->ne[1];
    bool use_mul_mat_vec_q = ggml_is_quantized(src0->type) && !bad_padding_clear && src1->type == GGML_TYPE_F32 &&
                             dst->type == GGML_TYPE_F32 && batch <= MMVQ_MAX_BATCH_SIZE;

    // fusion is not universally faster on Pascal
    const int device = ggml_cuda_get_device();
    const int cc = ggml_cuda_info().devices[device].cc;
    if (tensor->op == GGML_OP_MUL_MAT_ID && !ggml_cuda_indexed_mmvq_grid(tensor, device)) {
        return false;
    }''')
replace('''                struct ggml_tensor * a = op->src[0];
                struct ggml_tensor * b = op->src[1];
                if (op->type == GGML_TYPE_BF16) {''', '''                struct ggml_tensor * a = op->src[0];
                struct ggml_tensor * b = op->src[1];
                if (op->op == GGML_OP_MUL_MAT_ID && ggml_is_quantized(a->type) &&
                        b->type == GGML_TYPE_F32 && op->type == GGML_TYPE_F32 &&
                        op->ne[2] <= MMVQ_MAX_BATCH_SIZE) {
                    const int cc = ggml_cuda_info().devices[dev_ctx->device].cc;
                    if (op->ne[2] <= get_mmvq_mmid_max_batch(a->type, cc) &&
                            !ggml_cuda_indexed_mmvq_grid(op, dev_ctx->device)) {
                        return false;
                    }
                }
                if (op->type == GGML_TYPE_BF16) {''')
stage = STAGE / 'native-overlay'
before, after = stage / 'before/src/ggml-cuda/ggml-cuda.cu', stage / 'source/src/ggml-cuda/ggml-cuda.cu'
before.parent.mkdir(parents=True, exist_ok=True)
after.parent.mkdir(parents=True, exist_ok=True)
before.write_bytes(old)
after.write_text(text, encoding='utf-8', newline='\n')
change = {'path': 'src/ggml-cuda/ggml-cuda.cu', 'before_sha256': EXPECTED,
          'after_sha256': hashlib.sha256(after.read_bytes()).hexdigest(), 'edits': edits}
(stage / 'replacements.json').write_text(json.dumps({'files': [change]}, indent=2) + '\n', encoding='utf-8')
(stage / 'changes.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True), text.splitlines(True),
    fromfile='a/src/ggml-cuda/ggml-cuda.cu', tofile='b/src/ggml-cuda/ggml-cuda.cu')), encoding='utf-8')
(stage / 'source-freeze.json').write_text(json.dumps({'state': 'Scratch only, not applied or compiled.',
    'source': str(BASE), 'before_sha256': EXPECTED, 'after_sha256': change['after_sha256'],
    'private_shared_header_ABI_changed': False, 'new_hot_CUDA_queries': 0,
    'changed_native_TUs': 1, 'new_model_or_dtype_whitelist': False}, indent=2) + '\n', encoding='utf-8')
print('NATIVE_OVERLAY', change['after_sha256'], flush=True)
