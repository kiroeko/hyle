"""Archive tested grouped topology/fusion evidence; never build, run GPU or clean."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T123025/plan-verified-fixture.json'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-grouped-fusion.zip'
EXCLUDED = {'.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.dll', '.pyc', '.tmp', '.zip'}
EXCLUDED_DIRS = {'tmp', '__pycache__', 'cache'}
DOCS = ('docs/architecture/compute-design.md', 'docs/developer/current-work.md',
        'docs/implementation/model-operators.md', 'docs/implementation/model-quantizations.json',
        'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md')
SUPPORT = ('cuda-fusion-allocation/build.py', 'recurrent-gdn-schema/build.py',
           'immutable-alias-index/build.py', 'cuda-fusion-precision/build.py',
           'cuda-fusion-layout/build.py', 'cuda-gdn-l2-epilogue/build.py',
           'cuda-explicit-rope/build.py', 'cuda-bf16-dual-projection/build_current.py',
           'cuda-projection-fusion/build.py', 'cold-constant-retirement/cold_check.py',
           'cuda-bf16-dual-projection/compare_numerics.py',
           'cuda-explicit-rope/seal.py', 'cuda-bf16-dual-projection/seal_native.py',
           'cuda-fusion-precision/profile-analysis.py')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def absolute(path):
    path = Path(path)
    return (path if path.is_absolute() else ROOT / path).resolve()


def key(path):
    return str(absolute(path)).casefold()


def main():
    if DEST.exists() or (STAGE / 'archive-verification.json').exists():
        raise ValueError('Existing archive/receipt; refusing replacement')
    # Repeated identities in three links/receipts are read only once. Archive
    # payloads are separately checked against the frozen hash when written.
    identities = {}

    def identity(path):
        path = absolute(path)
        if key(path) not in identities:
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                    digest.update(block)
            identities[key(path)] = dict(path=str(path), bytes=path.stat().st_size,
                                         sha256=digest.hexdigest())
        return identities[key(path)]

    def verify(row):
        actual = identity(row['path'])
        if any(actual[field] != row[field] for field in ('bytes', 'sha256')):
            raise ValueError('Frozen input drift: ' + row['path'])
        return absolute(row['path'])

    plan, freeze = read(PLAN), read(STAGE / 'native-source-freeze.json')
    if freeze['source_id'] != 'a80c353ef5972ed2' or plan['native_source_id'] != freeze['source_id']:
        raise ValueError('Expected tested v22 source identity')
    if (plan['native_TUs'], plan['host_TUs']) != (1, 3) or len(plan['compile']) != 4:
        raise ValueError('Expected one-native/three-host final closure')
    if not read(PLAN.parent / 'summary.json')['passed']:
        raise ValueError('Missing final successful build')
    for relative, expected in freeze['sources'].items():
        if identity(STAGE / 'native-source' / relative)['sha256'] != expected:
            raise ValueError('Sealed native source drift')
    application = read(STAGE / 'application.json')
    if len(application['files']) != 4:
        raise ValueError('Expected three host files plus final fixture')
    for row in application['files']:
        if identity(row['path'])['sha256'] != row['after_sha256']:
            raise ValueError('Applied source drift')
    for row in read(STAGE / 'source-freeze.json')['files']:
        verify(row['before']); verify(row['after'])
        if identity(ROOT / row['product'])['sha256'] != row['after']['sha256']:
            raise ValueError('Reviewed final host source drift')
    for row in read(STAGE / 'tests-source-freeze.json')['files']:
        verify(row['after'])
        if identity(ROOT / row['target'])['sha256'] != row['after']['sha256']:
            raise ValueError('Reviewed final fixture source drift')
        # Its original "before" identity names the then-current product path.
        # The retained first failed fixture appended to that exact source;
        # recover and hash-check the original prefix rather than pretending
        # today's product still has those old bytes.
        old = (STAGE / 'before-test-include-correction/stable_silu_test.cc').read_bytes()[:row['before']['bytes']]
        if len(old) != row['before']['bytes'] or sha(old) != row['before']['sha256']:
            raise ValueError('Original fixture prefix differs from before identity')
        snapshot = STAGE / 'before' / row['target']
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(old)
        verify(dict(row['before'], path=str(snapshot)))

    files, expected = {}, {}

    def add(name, path, frozen=None):
        path = absolute(path)
        if path.suffix.lower() in EXCLUDED or any(part.casefold() in EXCLUDED_DIRS for part in path.parts):
            return
        if not path.is_relative_to(ROOT) or path.is_symlink() or not path.is_file():
            raise ValueError('Unexpected external/missing/symlink payload: ' + str(path))
        if name in files and files[name] != path:
            raise ValueError('Duplicate archive entry: ' + name)
        files[name] = path
        if frozen:
            if name in expected and any(expected[name][field] != frozen[field] for field in ('bytes', 'sha256')):
                raise ValueError('Conflicting expected payload identity')
            expected[name] = frozen

    for row in plan['frozen']:
        path = verify(row)
        if not path.is_relative_to(STAGE):
            add('tested-inputs/' + path.relative_to(ROOT).as_posix(), path, row)
    for row in plan['cached_inputs']:
        verify(row)  # Existing objects/libraries are verified, never copied.
    compiled = []
    for row in plan['compile']:
        verify(row['source'])
        receipt = read(PLAN.parent / (row['tag'] + '-identity.json'))
        if receipt['source'] != row['source'] or receipt['command'] != row['command'] or key(receipt['object']['path']) != key(row['object']):
            raise ValueError('Actual compile/source receipt differs: ' + row['tag'])
        verify(receipt['object'])
        compiled.append(dict(tag=row['tag'], source=row['source'], object=receipt['object']))
    images, counts = {}, {'cuda': 133, 'qwen': 125, 'control-cuda': 133}
    for arm, count in counts.items():
        link = read(PLAN.parent / (arm + '-link-plan.json'))
        if len(link['inputs']) != count or len({key(row['path']) for row in link['inputs']}) != count:
            raise ValueError('Actual link closure differs: ' + arm)
        if link['command'] != plan['links'][arm]['command']:
            raise ValueError('Actual link command differs: ' + arm)
        for row in link['inputs']:
            verify(row)
        images[arm] = read(PLAN.parent / (arm + '-image.json'))
        verify(images[arm])
    closure = read(ARCH / 'cuda-fusion-precision/header-closure.json')
    if closure['header_count'] != 89:
        raise ValueError('Expected coherent89 headers')
    frozen_keys = {key(row['path']) for row in plan['frozen']}
    for row in closure['headers']:
        path = ARCH / 'cuda-fusion-precision/native-source' / row['path']
        if key(path) not in frozen_keys or identity(path)['sha256'] != row['sha256']:
            raise ValueError('Coherent header absent from tested freeze or changed')

    def xml_counts(path):
        root = ET.parse(path).getroot()
        return {field: int(root.get(field, '0')) for field in
                ('tests', 'failures', 'disabled', 'errors', 'skipped')}

    good = lambda count: dict(tests=count, failures=0, disabled=0, errors=0, skipped=0)
    final = read(PLAN.parent / 'run-cuda-final/summary.json')
    plain = read(PLAN.parent / 'run-plain/summary.json')
    if not final['passed'] or final['counts'] != good(25) or not plain['passed'] or plain['counts'] != good(3):
        raise ValueError('Expected25+3 related CUDA cases without skips')
    if xml_counts(PLAN.parent / 'run-cuda-final/cuda.xml') != good(25) or xml_counts(PLAN.parent / 'run-plain/target.xml') != good(3):
        raise ValueError('Final actual XML differs')
    old_control = dict(tests=1, failures=1, disabled=0, errors=0, skipped=0)
    if xml_counts(PLAN.parent / 'run-cuda-final/control-cuda.xml') != old_control or final['invalid_grid_submitted']:
        raise ValueError('Expected old metadata qualification failure without invalid launch')
    initial = xml_counts(PLAN.parent / 'run-cuda/cuda.xml')
    if initial != dict(tests=25, failures=1, disabled=0, errors=0, skipped=0):
        raise ValueError('Missing original24/25 failed fixture observation')
    compiler_failures = []
    for name in ('stable-test-compile.result.json', 'stable-test-corrected-compile.result.json'):
        path = PLAN.parent / name
        result = read(path)
        if not result.get('terminal') or result['exit'] == 0:
            raise ValueError('Missing original terminal compiler failure')
        compiler_failures.append(dict(result=identity(path), exit=result['exit']))
    model = read(STAGE / 'correctness/summary.json')
    observation = model['observation']
    if not model['passed'] or observation['equal_vectors'] != 64 or len(observation['vectors']) != 64 or not observation['all_outputs_finite'] or not observation['same_greedy_ids_as_reference'] or not observation['capture_32_phases_with_7_ranges']:
        raise ValueError('Missing exact64 finite model vectors/IDs/capture regression')
    verify(observation['image'])
    for row in observation['vectors']:
        if not row['byte_equal'] or any(row['actual'][field] != row['reference'][field] for field in ('bytes', 'sha256')):
            raise ValueError('Model comparison identity differs')
        path = absolute(row['actual']['path'])
        add('stage/' + path.relative_to(STAGE).as_posix(), path, row['actual'])

    profile = read(STAGE / 'profile-tests/analysis.json')
    if not profile['passed'] or not profile['candidate_full_grouped_GLU_observed'] or not profile['control_original_split_observed'] or profile['profiler_collections'] != 2:
        raise ValueError('Missing two-arm actual fusion observations')
    for arm, total, carriers, quant in (
        ('control-cuda', 80, dict(standard_fused=0, standard_unfused=8, MoE_fused=0, MoE_unfused=8, standalone_GLU=16), 16),
        ('cuda', 56, dict(standard_fused=4, standard_unfused=0, MoE_fused=4, MoE_unfused=0, standalone_GLU=8), 8)):
        record = profile['arms'][arm]
        if record['physical_kernel_instances'] != total or record['observed'] != carriers or record['ancillary_kernel_counts'] != dict(quantize_Q8_1=quant, checked_index_guard=16, checked_publish_guard=8):
            raise ValueError('Actual traced carriers/checks differ: ' + arm)
        for operation in ('profile', 'export', 'stats'):
            result = read(STAGE / 'profile-tests' / arm / (operation + '.result.json'))
            if not result.get('terminal') or result['exit'] != 0:
                raise ValueError('Profiler/export/stats not terminal0')
        for field in ('sqlite', 'official_csv'):
            row = record['receipt'][field]
            path = verify(row)
            add('stage/' + path.relative_to(STAGE).as_posix(), path, row)
        inputs = read(STAGE / 'profile-tests' / arm / 'inputs.json')
        for field in ('image', 'plan', 'runner', 'analysis', 'test_source'):
            verify(inputs[field])

    for relative in SUPPORT:
        path = ARCH / relative
        add('replay-support/' + path.relative_to(ROOT).as_posix(), path)
    for relative in ('src/compute_ggml_runtime/prepare_source.py',
                     'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
                     'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py',
                     'third_party/ggml_cuda_runtime/iq1-patches.json'):
        add('replay-support/' + relative, ROOT / relative)
    for relative in DOCS:
        add('documentation/' + relative, ROOT / relative)
    if (ROOT / 'test.ps1').is_file():
        add('cleanup-plan/test.ps1', ROOT / 'test.ps1')
    scope = dict(source_id=freeze['source_id'], final_plan=identity(PLAN),
        applied_sources=application['files'], native_TUs=1, host_TUs=3,
        actual_link_inputs=counts, actual_images=images, compiled=compiled,
        coherent_headers=89, CUDA_tests=28, model_equal_vectors=64,
        preserved_compiler_failures=compiler_failures, original_test_result=initial,
        old_metadata_control=old_control, physical_test_kernels=dict(old=80, current=56),
        actual_profile_scope='Q8 top10 T1/T2 directed Graph only; no complete-model physical or throughput claim',
        accepted_failure_recovery='Failed accepted Graph slots are recreated from the same Executable, never reset into reuse.',
        documentation_context=DOCS, throughput_claim=False, quality_acceptance=False,
        cleanup_not_executed_at_archive_time=True, SDK_and_rebuildable_binaries_excluded=True)
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8')
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected stage symlink')
        if path.is_file():
            add('stage/' + path.relative_to(STAGE).as_posix(), path)
    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            row = dict(entry=name, source=str(path), bytes=len(data), sha256=sha(data))
            frozen = expected.get(name)
            if frozen and any(row[field] != frozen[field] for field in ('bytes', 'sha256')):
                raise ValueError('Frozen payload drift while archiving: ' + name)
            records.append(row)
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    # ZipFile.read checks the CRC too; one readback pass verifies CRC and SHA.
    with zipfile.ZipFile(DEST) as archive:
        if len(archive.namelist()) != len(records) + 1:
            raise ValueError('Archive entry count differs')
        archive.read('manifest.json')
        for row in records:
            data = archive.read(row['entry'])
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError('Payload SHA/length differs')
        if any(Path(name).suffix.lower() in EXCLUDED or any(part.casefold() in EXCLUDED_DIRS for part in Path(name).parts) for name in archive.namelist()):
            raise ValueError('Excluded binary/cache/tmp in ZIP')
    receipt = dict(**identity(DEST), payloads=len(records),
        uncompressed_payload_bytes=sum(row['bytes'] for row in records),
        CRC_and_every_payload_SHA_verified=True, source_id=freeze['source_id'],
        native_TUs=1, host_TUs=3, CUDA_tests=28, model_equal_vectors=64,
        physical_directed_kernels=dict(old=80, current=56),
        compiler_failures_preserved=2, original24of25_and_old_metadata_failure_preserved=True,
        cleanup_executed=False, throughput_claim=False, quality_acceptance=False)
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text, encoding='utf-8')
    DEST.with_name('cuda-grouped-fusion-archive.json').write_text(text, encoding='utf-8')
    print(text, flush=True)


if __name__ == '__main__':
    main()
