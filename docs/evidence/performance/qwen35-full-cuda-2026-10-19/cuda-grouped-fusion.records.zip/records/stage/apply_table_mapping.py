"""Populate existing artifact coverage with bounded, source-only contract reviews."""
from pathlib import Path
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
catalog=ROOT/'docs/implementation/model-quantizations.json'
audit=STAGE/'table-audit/first-eight-artifact-mapping.json'
original=catalog.read_bytes()
data=json.loads(original.decode('utf-8-sig'))
mapping=json.loads(audit.read_text(encoding='utf-8-sig'))
if len(mapping['artifacts'])!=8:
    raise ValueError('Expected eight reviewed artifact identities')
for row in mapping['artifacts']:
    target=data['artifacts'][row['index']]
    if any(target[key]!=row[key] for key in ('model_id','repository','revision')) or target['provider_coverage'] is not None:
        raise ValueError('Artifact identity or original coverage differs')
    coverage=row['provider_coverage']
    if coverage['review']!='static_contract_review' or coverage['artifact_execution_verified'] is not False:
        raise ValueError('Unverified execution must remain explicit')
    target['provider_coverage']=coverage
data['limitations']=[
    'Physical GEMM accumulation, activation rounding and kernel fusion remain unverified for these artifacts; populated provider_coverage records identify conditional source contracts only.' if line.startswith('Physical GEMM accumulation,') else
    'Initial publisher discovery metadata is preserved; subsequent provider_coverage entries are bounded local source reviews, without artifact tensor-header or end-to-end execution verification.' if line=='Model scope/catalog/MD/product files were not changed.' else line
    for line in data['limitations']]
before=STAGE/'table-audit/before-model-quantizations.json'
if before.exists():raise ValueError('Refusing to replace original catalog snapshot')
before.write_bytes(original)
catalog.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
after=json.loads(catalog.read_text(encoding='utf-8'))
for index,(left,right) in enumerate(zip(json.loads(original)['artifacts'],after['artifacts'])):
    left.pop('provider_coverage')
    right.pop('provider_coverage')
    if left!=right:raise ValueError('Publisher snapshot changed')
receipt={'catalog':str(catalog),'before_sha256':hashlib.sha256(original).hexdigest(),
    'after_sha256':hashlib.sha256(catalog.read_bytes()).hexdigest(),
    'source_audit_sha256':hashlib.sha256(audit.read_bytes()).hexdigest(),
    'artifacts':33,'source_contract_reviews':8,'remaining_unreviewed':25,
    'artifact_execution_verified':False,'publisher_metadata_changed':False}
(STAGE/'table-audit/application.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt),flush=True)
