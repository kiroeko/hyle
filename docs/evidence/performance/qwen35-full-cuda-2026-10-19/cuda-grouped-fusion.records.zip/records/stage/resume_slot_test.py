"""Correct the new fixture's recovery policy; keep all product objects/images."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
spec=importlib.util.spec_from_file_location('grouped_slot_build',STAGE/'build.py')
build=importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b,c=build.b,build.c
out=STAGE/'checks/20261019T123025'
plan=c.read(out/'plan-final.json')
tests=c.read(STAGE/'tests-source-freeze.json')
record=tests['files'][0]
product=ROOT/record['target']
before=Path(record['after']['path']).read_bytes()
after=product.read_bytes()
anchor=b'          auto recovered=calls[lane].submit(queues[lane]);ASSERT_TRUE(recovered)<<recovered.error().message();\n'
start=after.index(b'          // Accepted failure retires this slot.')
end=after.index(anchor,start)
if after[:start]+after[end:]!=before:
    raise ValueError('Only explicit failed-slot reconstruction may change')
backup=STAGE/'before-test-lifecycle-correction'
backup.mkdir(exist_ok=False)
for name in ('tests-source-freeze.json','tests-plan.json','application.json','tests.diff'):
    (backup/name).write_bytes((STAGE/name).read_bytes())
(backup/'stable_silu_test.cc').write_bytes(before)
Path(record['after']['path']).write_bytes(after)
record['after']=b.identity(record['after']['path'])
# The original product before the whole batch, not a corrected fixture.
baseline=(STAGE/'before-test-include-correction/stable_silu_test.cc').read_bytes()
fragment=(STAGE/'grouped-tests.inc').read_bytes()
if not baseline.endswith(fragment):
    raise ValueError('Original fixture suffix differs')
base=baseline[:record['before']['bytes']]
if hashlib.sha256(base).hexdigest()!=record['before']['sha256']:
    raise ValueError('Cannot recover exact original source for final diff')
(STAGE/'tests.diff').write_text(''.join(difflib.unified_diff(base.decode().splitlines(True),after.decode().splitlines(True),
    fromfile='a/'+record['target'],tofile='b/'+record['target'])),encoding='utf-8')
tests['diff']=b.identity(STAGE/'tests.diff')
c.save(STAGE/'tests-source-freeze.json',tests)
test_plan=c.read(STAGE/'tests-plan.json')
test_plan['compile'][0]['source']=b.identity(product)
test_plan['compile'][0]['overlay']=record['after']
test_plan['functional_domains']['extent_control']='gate logicalE11 before upE12; IDs -1,11,12 preserve public outputs and immutable IDs. Failed accepted slot rejects reset/retry; fresh Invocation from same Executable rebinds and recovers.'
c.save(STAGE/'tests-plan.json',test_plan)
application=c.read(STAGE/'application.json')
next(x for x in application['files'] if c.key(x['path'])==c.key(product))['after_sha256']=b.identity(product)['sha256']
c.save(STAGE/'application.json',application)
changed={c.key(x) for x in (product,STAGE/'tests-source-freeze.json',STAGE/'tests-plan.json',STAGE/'application.json')}
for item in plan['frozen']:
    if c.key(item['path']) not in changed and not b.same(item):
        raise ValueError('Unrelated frozen input differs')
plan['frozen']=[b.identity(x['path']) if c.key(x['path']) in changed else x for x in plan['frozen']]
plan['frozen'].append(b.identity(Path(__file__)))
fixture=next(x for x in plan['compile'] if x['tag']=='stable-test')
fixture['source']=b.identity(product)
plan['fixture_lifecycle_correction']='Accepted terminal failure requires a new Invocation, per executable.h.'
path=out/'plan-verified-fixture.json'
c.save(path,plan)
build.check(plan)
build.check_cached(plan)
fresh=[]
for entry in plan['compile']:
    if entry['tag']!='stable-test':
        identity=c.read(out/(entry['tag']+'-identity.json'))['object']
        if not b.same(identity):raise ValueError('Successful product object drift')
        fresh.append(identity)
env,_=b.environment(plan['links']['qwen']['command'],plan['links']['qwen']['inputs'],out)
c.execute('stable-test-lifecycle-compile',fixture['command'],env,out)
build.check(plan)
identity=b.identity(fixture['object'])
fresh.append(identity)
c.save(out/'stable-test-identity.json',{'command':fixture['command'],'source':fixture['source'],'object':identity})
for tag in ('cuda','control-cuda'):
    link=plan['links'][tag]
    c.execute(tag+'-lifecycle-link',link['command'],env,out)
    build.check(plan)
    c.save(out/(tag+'-image.json'),b.identity(link['image']))
build.check_cached(plan)
identities={c.key(x['path']):x for x in [*plan['cached_inputs'],*fresh]}
for tag in ('cuda','control-cuda'):
    link=plan['links'][tag]
    c.save(out/(tag+'-link-plan.json'),{'command':link['command'],'inputs':[identities[c.key(x)] for x in link['inputs']]})
c.save(out/'summary.json',{'passed':True,'native_TUs':1,'host_TUs':3,'SDK_build':False,'GPU_run':False,
    'reused_successful_production_compiles':3,'prior_fixture_failures_preserved':True,'native_source_id':plan['native_source_id']})
c.save(STAGE/'test-lifecycle-correction.json',{'before':b.identity(backup/'stable_silu_test.cc'),'after':b.identity(product),
    'public_contract':'include/hyle/graph/executable.h:990','product_execution_semantics_changed':False,
    'failed_run':b.identity(out/'run-cuda/cuda.xml'),'qwen_relinked':False,'plan':b.identity(path)})
print('BUILD_COMPLETE',path,flush=True)
