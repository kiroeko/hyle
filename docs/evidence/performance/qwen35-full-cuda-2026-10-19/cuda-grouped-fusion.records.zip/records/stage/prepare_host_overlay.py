"""Generate the three-file host overlay. No compilation, application or GPU work."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
FILES = ["src/compute_provider_ggml_cuda/tensor_program.h",
         "src/compute_provider_ggml_cuda/tensor_program.cc",
         "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc"]

def replace(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new)

sources = {name: (ROOT / name).read_text(encoding="utf-8") for name in FILES}
after = dict(sources)
h = after[FILES[0]]
h = replace(h, "#include <ggml.h>", "#include <array>\n#include <unordered_map>\n\n#include <ggml.h>\n\n#include \"hyle/mem/std_allocator.h\"")
h = replace(h, "struct ScalarConstant final {", '''// Build-local forms are keyed by native tensor identity, never payload address.
// The public values retain their original shape and ownership/reader edges.
class TensorBuildFrame final {
 public:
  TensorBuildFrame(std::size_t values, mem::AllocatorRef allocator);
  ggml_tensor *matrix_form(ggml_context *, ggml_tensor *, const TensorDesc &);
  ggml_tensor *reshape(ggml_context *, ggml_tensor *,
                       std::array<std::int64_t, 3> shape, std::uint8_t rank);
  void remember_grouped(std::uint32_t value, ggml_tensor *producer) noexcept {
    grouped_[value] = producer;
  }
  ggml_tensor *grouped(std::uint32_t value) const noexcept {
    return grouped_[value];
  }

 private:
  struct ShapeKey final {
    ggml_tensor *source = nullptr;
    std::array<std::int64_t, 3> shape{};
    std::uint8_t rank = 0;
    bool operator==(const ShapeKey &) const = default;
  };
  struct ShapeHash final {
    std::size_t operator()(const ShapeKey &) const noexcept;
  };
  using ViewEntry = std::pair<const ShapeKey, ggml_tensor *>;
  std::unordered_map<ShapeKey, ggml_tensor *, ShapeHash,
      std::equal_to<ShapeKey>, mem::StdAllocator<ViewEntry>> views_;
  std::vector<ggml_tensor *, mem::StdAllocator<ggml_tensor *>> grouped_;
};

struct ScalarConstant final {''')
h = replace(h, "std::span<ggml_tensor *> matrix_values,", "TensorBuildFrame &,")
after[FILES[0]] = h

c = after[FILES[1]]
c = replace(c, "} // namespace\n\nbool tensor_operation_supports", '''} // namespace

std::size_t TensorBuildFrame::ShapeHash::operator()(
    const ShapeKey &key) const noexcept {
  auto hash = std::hash<ggml_tensor *>{}(key.source);
  const auto combine = [&](std::size_t part) {
    hash ^= part + std::size_t{0x9e3779b9} + (hash << 6) + (hash >> 2);
  };
  combine(key.rank);
  for (const auto extent : key.shape)
    combine(std::hash<std::int64_t>{}(extent));
  return hash;
}

TensorBuildFrame::TensorBuildFrame(std::size_t values,
                                  mem::AllocatorRef allocator)
    : views_(0, ShapeHash{}, std::equal_to<ShapeKey>{},
             mem::StdAllocator<ViewEntry>{allocator}),
      grouped_(values, nullptr, mem::StdAllocator<ggml_tensor *>{allocator}) {}

ggml_tensor *TensorBuildFrame::matrix_form(ggml_context *context,
                                          ggml_tensor *source,
                                          const TensorDesc &description) {
  const ShapeKey key{source, {columns(description), rows(description), 1}, 2};
  if (const auto found = views_.find(key); found != views_.end())
    return found->second;
  auto *result = matrix(context, source, description);
  views_.emplace(key, result);
  return result;
}

ggml_tensor *TensorBuildFrame::reshape(ggml_context *context,
                                      ggml_tensor *source,
                                      std::array<std::int64_t, 3> shape,
                                      std::uint8_t rank) {
  GGML_ASSERT(rank == 2 || rank == 3);
  // Only the existing dense grouped activation/IDs and MMID result use this
  // entry. Noncontiguous matrix inputs keep the original CONT construction.
  GGML_ASSERT(ggml_is_contiguous(source));
  const ShapeKey key{source, shape, rank};
  if (const auto found = views_.find(key); found != views_.end())
    return found->second;
  auto *result = rank == 2
      ? ggml_reshape_2d(context, source, shape[0], shape[1])
      : ggml_reshape_3d(context, source, shape[0], shape[1], shape[2]);
  views_.emplace(key, result);
  return result;
}

bool tensor_operation_supports''')
c = replace(c, "std::span<ggml_tensor *> matrix_values,", "TensorBuildFrame &forms,")
c = replace(c, '''    auto &cached = matrix_values[id];
    if (!cached)
      cached = matrix(context, values[id], recipe.values[id]);
    return cached;''', '''    return forms.matrix_form(context, values[id], recipe.values[id]);''')
c = replace(c, '''  } else if (const auto *gate = node.operation.get_if<GatedActivation>()) {
    auto *a = input(0);
    if (a->type == GGML_TYPE_BF16)
      a = as_float(context, a);
    if (gate->inputs == GatedInputKind::kPackedHalves) {
      result = ggml_swiglu(context, a);
    } else {
      auto *b = input(1);
      if (b->type == GGML_TYPE_BF16)
        b = as_float(context, b);
      result = ggml_swiglu_split(context, a, b);
    }
  } else if (const auto *rms = node.operation.get_if<RmsNorm>())''', '''  } else if (const auto *gate = node.operation.get_if<GatedActivation>()) {
    if (gate->inputs == GatedInputKind::kPackedHalves) {
      auto *a = input(0);
      if (a->type == GGML_TYPE_BF16)
        a = as_float(context, a);
      result = ggml_swiglu(context, a);
    } else {
      // Preserve the grouped rank-3 producer edges before requesting matrix
      // forms. Public readers retain their original shape and ownership.
      auto *raw_a = forms.grouped(node.inputs[0]);
      auto *raw_b = forms.grouped(node.inputs[1]);
      const auto grouped_order = [&](ggml_tensor *raw, std::uint32_t id) {
        return raw && raw->op == GGML_OP_MUL_MAT_ID &&
               raw->type == GGML_TYPE_F32 &&
               recipe.values[id].data_type() == DataType::kFloat32 &&
               ggml_is_contiguous(raw) && raw->ne[3] == 1 &&
               raw->ne[0] == columns(recipe.values[id]) &&
               static_cast<std::size_t>(ggml_nelements(raw)) ==
                   elements(recipe.values[id]);
      };
      if (grouped_order(raw_a, node.inputs[0]) &&
          grouped_order(raw_b, node.inputs[1]) &&
          ggml_are_same_shape(raw_a, raw_b)) {
        result = ggml_swiglu_split(context, raw_a, raw_b);
      } else {
        auto *a = input(0);
        if (a->type == GGML_TYPE_BF16)
          a = as_float(context, a);
        auto *b = input(1);
        if (b->type == GGML_TYPE_BF16)
          b = as_float(context, b);
        result = ggml_swiglu_split(context, a, b);
      }
    }
  } else if (const auto *rms = node.operation.get_if<RmsNorm>())''')
c = replace(c, '''      activations = ggml_reshape_3d(context, activations, activations->ne[0],
                                    1, slots * tokens);
      ids = ggml_reshape_2d(context, ids, 1, slots * tokens);''', '''      activations = forms.reshape(context, activations,
          {activations->ne[0], 1, slots * tokens}, 3);
      ids = forms.reshape(context, ids, {1, slots * tokens, 1}, 2);''')
c = replace(c, '''    if (recipe.values[node.inputs[0]].is_plain())
      result = ggml_reshape_3d(context, result, result->ne[0], slots, tokens);
  } else if (const auto descriptor =''', '''    forms.remember_grouped(node.outputs[0], result);
    if (recipe.values[node.inputs[0]].is_plain())
      result = forms.reshape(context, result, {result->ne[0], slots, tokens}, 3);
  } else if (const auto descriptor =''')
after[FILES[1]] = c

p = after[FILES[2]]
p = replace(p, "#include <unordered_set>", "#include <unordered_map>\n#include <unordered_set>")
p = replace(p, "struct Invocation final {", '''struct CheckedIndicesKey final {
  ggml_tensor *source = nullptr;
  std::size_t count = 0;
  std::int64_t extent = 0;
  bool operator==(const CheckedIndicesKey &) const = default;
};
struct CheckedIndicesHash final {
  std::size_t operator()(const CheckedIndicesKey &key) const noexcept {
    auto hash = std::hash<ggml_tensor *>{}(key.source);
    const auto combine = [&](std::size_t part) {
      hash ^= part + std::size_t{0x9e3779b9} + (hash << 6) + (hash >> 2);
    };
    combine(key.count);
    combine(std::hash<std::int64_t>{}(key.extent));
    return hash;
  }
};

struct Invocation final {''')
p = replace(p, '''    // One matrix form per recipe value and native build. Reuse a necessary
    // CONT/reshape without equating different values that share storage.
    std::vector<ggml_tensor *> matrix_values(count, nullptr);''', '''    internal::TensorBuildFrame forms(count, allocator);
    using CheckedEntry = std::pair<const CheckedIndicesKey, ggml_tensor *>;
    std::unordered_map<CheckedIndicesKey, ggml_tensor *, CheckedIndicesHash,
        std::equal_to<CheckedIndicesKey>, mem::StdAllocator<CheckedEntry>> checked{
        0, CheckedIndicesHash{}, std::equal_to<CheckedIndicesKey>{},
        mem::StdAllocator<CheckedEntry>{allocator}};''')
p = replace(p, "      ggml_tensor *original_matrix = nullptr;\n", "")
p = replace(p, '''        original_matrix = matrix_values[index_id];
        auto *safe = internal::create_tensor_input(arena.get(),
                                                    recipe.values[index_id]);
        ggml_set_input(safe);''', '''        const CheckedIndicesKey key{original_ids, check.count, check.extent};
        auto found = checked.find(key);
        if (found == checked.end()) {
          auto *safe = internal::create_tensor_input(
              arena.get(), recipe.values[index_id]);
          ggml_set_input(safe);
          found = checked.emplace(key, safe).first;
        }
        auto *safe = found->second;''')
p = replace(p, "        matrix_values[index_id] = nullptr;\n", "")
p = replace(p, "arena.get(), recipe, node, tensors, matrix_values, constants,", "arena.get(), recipe, node, tensors, forms, constants,")
p = replace(p, "        matrix_values[index_id] = original_matrix;\n", "")
after[FILES[2]] = p

def identity(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)).replace("\\", "/"),
            "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

records, diffs = [], []
for name in FILES:
    before_path, after_path = STAGE / "before" / name, STAGE / "source" / name
    before_path.parent.mkdir(parents=True, exist_ok=True)
    after_path.parent.mkdir(parents=True, exist_ok=True)
    before_path.write_bytes((ROOT / name).read_bytes())
    after_path.write_text(after[name], encoding="utf-8", newline="\n")
    records.append({"product": name, "before": identity(before_path),
                    "after": identity(after_path)})
    diffs.extend(difflib.unified_diff(sources[name].splitlines(True),
                 after[name].splitlines(True), fromfile="a/" + name,
                 tofile="b/" + name, n=5))
(STAGE / "changes.diff").write_text("".join(diffs), encoding="utf-8", newline="\n")
(STAGE / "source-freeze.json").write_text(json.dumps({
    "scope": "scratch-only host topology; no native/product application or execution",
    "files": records, "diff": identity(STAGE / "changes.diff"),
    "limitations": ["Physical fusion requires independent native qualification and runtime trace.",
      "All original checked-index launches remain; this does not claim their removal.",
      "Plain floating MMVF batching and original public schemas are unchanged."]
}, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(identity(STAGE / "source-freeze.json")))
