"""One retained three-arm rotation, isolating the resource-binding index."""
from pathlib import Path
import argparse
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
spec = importlib.util.spec_from_file_location('latest_retained_rotation', ARCH / 'batch-layout-query-reuse/compare_three.py')
rotation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rotation)
b, c, r = rotation.b, rotation.c, rotation.r
rotation.STAGE = STAGE
r.PREPARED = STAGE / 'prepared'
CURRENT = ARCH / 'mlx-affine-widths/cuda/checks/20261019T135721'


def prepare():
    r.PREPARED.mkdir(exist_ok=False)
    (r.PREPARED / 'tmp').mkdir()
    current = c.read(CURRENT / 'qwen-link-plan.json')
    for row in current['inputs']:
        r.require_same(row)
    old = c.read(ARCH / 'immutable-alias-index/checks/20261019T111822/4-resources-identity.json')
    r.require_same(old['object'])
    expected = c.read(ARCH / 'decode-host-path-review/source-freeze.json')['files'][0]['before']
    assert all(old['source'][key] == expected[key] for key in ('bytes', 'sha256'))
    new_resource = [row for row in current['inputs'] if Path(row['path']).name == 'resources.obj']
    assert len(new_resource) == 1
    old_path, new_path = old['object']['path'], new_resource[0]['path']
    command = [old_path if arg.casefold() == new_path.casefold() else arg
        for arg in current['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = r.PREPARED / 'baseline.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = [old['object'] if row['path'].casefold() == new_path.casefold() else row for row in current['inputs']]
    assert len(inputs) == 127 and sum(arg.casefold() == old_path.casefold() for arg in command) == 1
    env, _ = b.environment(command, [row['path'] for row in inputs], r.PREPARED)
    c.execute('baseline-link', command, env, r.PREPARED)
    baseline = dict(command=command, inputs=inputs, image=str(image))
    build = dict(links={'qwen': dict(**current, image=str(CURRENT / 'qwen.exe')), 'baseline': baseline},
        comparison='Current exact CUDA model image versus same127inputs with only resources.obj restored before cold binding index',
        old_resources=old, new_resources=new_resource[0], source_or_SDK_compilations=0, Hyle_links=1, peer_links=0)
    c.save(r.PREPARED / 'build-plan.json', build)
    retained = c.read(ARCH / 'batch-layout-query-reuse/performance-prepared/plan.json')
    images = dict(baseline=b.identity(image), current=c.read(CURRENT / 'qwen-image.json'),
                  llama=c.read(ARCH / 'cuda-explicit-rope/performance-prepared/peer-image.json'))
    peer = c.read(r.PEER_PLAN)
    for row in list(images.values()) + peer['inputs']:
        r.require_same(row)
    frozen = [row for row in retained['frozen'] if row['path'] != retained['build_plan']['path']]
    for row in frozen:
        r.require_same(row)
    frozen += [b.identity(Path(__file__)), b.identity(r.PREPARED / 'build-plan.json'),
        b.identity(CURRENT / 'qwen-link-plan.json'),
        b.identity(ARCH / 'mlx-affine-widths/cuda/correctness/summary.json')]
    plan = {key: retained[key] for key in ('schema_version', 'status', 'fixed', 'source_id',
        'expected_baseline_ids', 'order', 'metric_contract')}
    requests = []
    for request in retained['requests']:
        argv = request['command'].copy()
        argv[0] = images[request['arm']]['path']
        requests.append(dict(**request, command=argv))
    plan.update(build_plan=b.identity(r.PREPARED / 'build-plan.json'), images=images,
        peer_inputs=peer['inputs'], frozen=frozen, requests=requests,
        source_or_SDK_compilations=0, Hyle_links=1, peer_links=0, GPU_runs=0,
        profiler=False, external_memory_monitor=False,
        precision='Current unchanged BF16 weight / BF16 Hyle intermediate recipe; peer decode F32 intermediates differ.',
        resource_index_isolation=True)
    c.save(r.PREPARED / 'plan.json', plan)
    print('PREPARED_NO_GPU', r.PREPARED / 'plan.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        rotation.run(r.PREPARED / 'plan.json', STAGE / 'rotation')
    else:
        prepare()
