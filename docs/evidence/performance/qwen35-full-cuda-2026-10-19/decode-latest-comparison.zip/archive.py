from pathlib import Path
import datetime as dt
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/decode-latest-comparison.zip'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


summary = json.loads((STAGE / 'rotation-a1/summary.json').read_text())
processes = [json.loads(path.read_text()) for path in (STAGE / 'rotation-a1').glob('*.result.json')]
started = min(row['started'] for row in processes)
finished = max(row['finished'] for row in processes)
zone = dt.timezone(dt.timedelta(hours=8))
report = dict(scope='Latest paired throughput; same current CUDA closure except old resources.obj in baseline',
    started=dt.datetime.fromtimestamp(started, zone).isoformat(),
    finished=dt.datetime.fromtimestamp(finished, zone).isoformat(),
    terminal_zero=summary['terminal_zero'], groups=summary['groups'],
    current_over_baseline=summary['current_over_baseline'],
    current_over_llama=summary['current_over_llama'],
    predictions_same_all9=summary['same_baseline_predictions_all9'],
    baseline_difference='Only resources.obj; exact127input closure otherwise equal. Same public/private headers, no resource ABI change.',
    precision_limit='Same-source BF16 weights and fixed128+31 input tape; Hyle and reference intermediate precision differ.',
    statistics='Three independent processes per arm, nine-process interleaving; ranges overlap for isolated resource index; no stable speedup proven.',
    cold_limit='Shape preparation/load sub-boundaries differ; prefill step is not cold end-to-end. No file-cache eviction.',
    memory_limit='No peak-memory measurement this batch.', source_or_SDK_compilations=0,
    Hyle_links=1, peer_links=0, profiler=False,
    excluded=['SDKs', 'models', 'objects', 'executables', 'maps', 'duplicate earlier numerical vectors'])
(STAGE / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
files = []
for path in STAGE.rglob('*'):
    if not path.is_file() or path.suffix.lower() in ('.exe', '.obj', '.lib', '.exp', '.map', '.pdb', '.pyc'):
        continue
    if any(part in ('tmp', '__pycache__') for part in path.relative_to(STAGE).parts):
        continue
    files.append(path)
files.sort(key=lambda path: path.relative_to(STAGE).as_posix())
manifest = {path.relative_to(STAGE).as_posix(): identity(path) for path in files}
assert summary['terminal_zero'] == 9 and len(summary['groups']) == 3
assert not DEST.exists()
with zipfile.ZipFile(DEST, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        archive.write(path, path.relative_to(STAGE).as_posix())
    archive.writestr('payload-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    for name, row in manifest.items():
        data = archive.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = dict(archive=identity(DEST), payload_count=len(manifest), CRC_verified=True, payload_SHA256_verified=True,
    started=report['started'], finished=report['finished'], report='report.json')
DEST.with_name(DEST.stem + '-archive.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
