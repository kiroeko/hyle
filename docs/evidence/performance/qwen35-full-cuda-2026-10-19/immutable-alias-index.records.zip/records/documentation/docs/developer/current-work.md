# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 尽快完成独立的 Qwen3.5-2B 纯文本、无 MTP、无多模态、完整 CUDA C++ 推理消费者，
   在同系统、同设备、同源权重与匹配精度/输入条件下对比 llama.cpp 的 prefill/decode tokens/s。
   通过实际调用发现接口、布局、状态管理和执行成本问题，不把外部参考或片段算作完整引擎。
   2026-10-19 已完成全CUDA正常greedy生成及两组各3对独立进程的[实际性能对照](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)。
   首轮128-token场景首次prefill更快，加载、decode和显存有实际输项；中间精度差异及长期吞吐仍未验收。
   后续已统一ggml CUDA普通区域与attention的原生临时寿命复用，三对A/B显存6.431→5.312 GiB，128份决策向量逐字节不变；
   [修复与剩余边界](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)记录长链184→8 MiB及相关回归，decode尚无明显改善。
   再沿既有caller workspace接通共同Graph HB规划，三对A/B显存5.312→3.972 GiB，128份决策向量仍逐字节不变；
   两region各8 MiB需求加8 MiB边界只需16 MiB，相关10项通过。跨shape/并发槽仍独立，decode与加载输项未消除。
   后续8个测试/fixture文件的9处Direct调用已迁移workspace；8个CUDA owner TU增量编译及8个代表用例通过，
   CPU共享fixture分支未跑。[证据与边界](../evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-workspace-consumers.zip)
   另记录冷Status常量工厂的异常退休源码合同缺口：未修复、未复现UAF，不与本次调用者迁移混作已解决。
   随后沿原CUDA模板接通BF16逐算子承载，保留每节点RNE；128-token三对A/B的prefill 1589.1→1765.1、
   warm decode 77.32→79.84 tokens/s，显存3.972→3.939 GiB，128份决策向量逐字节不变。
   Direct/IQ1及修正fixture后的Graph共3个不同回归通过，保留初失败；非质量或全平台验收。
   [本轮源码与原始记录](../evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bfloat-elementwise.zip)。
   普通Graph现按实际backend身份能力复用同址录制，reset/rebind重新核准权限，配置/资源变化先失效。
   CPU11与CUDA6共17个不同用例通过；完整Qwen21+3最终单对8份输出逐字节相同，后续decode复用7段录制。
   最终同镜像三对Commands/PreferCapture的warm decode7–31为62.32→77.46 tokens/s，prefill回退；
   历史差异与剩余性能输项仍需排查。[记录与边界](../evidence/performance/qwen35-full-cuda-2026-10-19/cuda-capture-reuse.zip)。
   随后同窗三对PreferCapture/llama参考的warm为83.36/95.16 tokens/s；当前Nsight每步1794/558个kernel、7/1次GraphLaunch。
   已确认完整FFN等融合候选/lowering覆盖不足，仍须区分精度合同、准备费用与实际GPU收益；
   [定量分析](../evidence/performance/qwen35-full-cuda-2026-10-19/cuda-current-peer.zip)含Nsight Systems/Compute原始数据。
   后续已补连续BF16 Add/Mul的逐节点RNE融合，3个定向用例通过、完整Qwen的64份hidden/logits逐字节相同；
   定向trace命中真实融合，但完整Qwen未命中，三对warm吞吐中位79.04→77.80 tokens/s，未见提升。
   完整FFN等模型融合与准备成本仍待处理；[本轮记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)。
7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

2026-10-18，当前主线调整为 Compute/Graph 推理执行架构的设计与全量重构。
先把整体调用链和所有权设计清楚，再纵向迁移实现；目标同时包括算子自然扩展、推理全过程衔接和性能。
目标架构、动态变化边界、迁移次序与完成条件集中在[推理执行体系的重构形状](../architecture/compute-design.md#推理执行体系的重构形状)，
本页不另复制一套设计。

2026-10-19，冷常量准备／复制的失败寿命已修复，当前继续检查实际投影吞吐、融合和准备开销。
后续按以下顺序推进，前 3 项沿实际调用链交叉修复：

1. 收完当前 Qwen 真实推理热点，再对照加载、prefill、decode、显存与内存；按等价工作和实际测量决定优化。
2. 按现行模型总表补融合、量化接线与旧功能审查遗留，范围是 8 个模型、24 个已锁定基线配置及新增的
   Unsloth/HF 主流量化；24 不是上限。核对逐角色格式、算子和实际 Provider 路由。
3. 收敛 Windows/Linux/macOS 的 CPU、单 GPU、CPU＋GPU 公共调用链，补齐变长、状态、并发槽和失败恢复的剩余疏漏。
4. 删除重复旧实现，收拢公共接口、构建脚本与文档，完成当前 Compute/Graph 重构；新增普通算子不应牵动共同调度和资源核心。
5. 完成 MTP 的真实消费者闭环，复用已有状态与接受前缀底座。
6. 补图像 encoder/projector（mmproj）及图像输入到文本推理的实际链路。

前 4 项是当前重构的收工范围；MTP 完整消费者与多模态随后分别推进。单个模型成功不代替底座覆盖。

当前 Qwen CUDA 已将常量表达式及卷积权重转换移入冷准备，接通61组weighted／18组unscaled typed RMS、
36组保留原树与舍入的GDN L2、24组无权重副本的BF16 decode FFN，以及显式频率RoPE的单kernel承载；
L2标量分子用真实零步幅View读取，并在私有结果上融合保留BF16舍入的F32扩宽。
warm每步实际740个kernel、7次GraphLaunch，BF16/F32独立转换核163个，Repeat为0。
普通投影仍保留cuBLAS叶偏好。原Invocation缓存成功的batch槽选择，省去每token六次全计划扫描，
保留layout／Queue／结果退休检查及失败恢复；CPU多Context与真实地址身份保护的定向回归已通过。
测试消费者用公共FileMapping上传原权重，并将日志移出step计时；不会为融合复制至少1.125GiB的gate/up权重。

最新L2批次同窗旧Hyle／新Hyle／llama各3进程交错：完整31步decode为93.82／94.79／103.11 tokens/s，
warm第7–31步为98.30／98.50／105.66。观察到+1.03%／+0.20%，样本重叠，未证明稳定提速；
当前完整decode低同窗参考8.07%、warm低6.78%。三个引擎均比上一窗口快，不能跨窗口相减归因。
新Hyle首token2.021秒、参考1.819秒。32项相关CUDA通过；完整64份hidden/logits与改前逐byte相同、32预测及7段capture旅程一致。
这不消除前批FFN点积树相对Lt/Torch的已有差异，也不替代模型质量判断。
下一步调查实际投影吞吐和准备／提交关键路径，并继续收敛非投影577／395中的conv/GDN/gate边界；
不由kernel数推导时间收益，不重测已近似持平的普通MMVF替换。核心审查未发现模型名或Qwen尺寸准入，
后端融合的布局资格及跨模型／量化／平台真实旅程仍须补齐；总显存／内存峰值也未全量核定。
随后已修复CUDA九处旧MMVF/MMVQ融合的实际布局／读集资格，以及量化核将stride误作尾行界的问题。
同一新测试下旧实现3项全失败、新实现35项相关CUDA通过，完整64份Qwen向量保持；未重测吞吐。
小trace确认真实局部融合保留，但fixture中的完整GLU链未命中；不能用逻辑候选代替分配后的物理融合。
随后已修复F16融合的原MatMul精度传递，以及普通／量化／MoE融合中的OAI alpha/limit传播；
同一新测试旧native三项断言失败，新38项相关CUDA通过，完整64份向量保持，小trace确认三条OAI路线各4次真实融合。
该融合批次未重测吞吐，不能据正确性修复宣称提速。随后共同输出bind接入不可变allocation冷索引，
9项相关CPU及64份完整CUDA模型向量通过；动态权限与alias检查保留，未消除batch reset带来的全部重绑。
索引批次同窗旧／新／参考各3进程，warm中位85.65／86.27／94.05 tokens/s，样本重叠，未证明稳定提速；
不将与上一窗口不同的绝对速度归因于本批。下一项收敛公共RecurrentGatedDeltaNet的非数学尺寸限制与真实后端资格。
用户随后要求先调研精度设计：现行对照的decode采用F32中间值，prefill又可能以BF16操作数计算，不能把零独立Cast核当作相同数学图。
先按[精度配方与冷编译](../architecture/compute-design.md#精度配方与冷编译)收敛数学、转换承载与内存代价；
BF16/F32消费者开关与混合MatMul草稿仅留在scratch，尚未接入、构建或执行，不据此改变当前默认精度。
各批次源码、失败、物理trace、数值与计时边界集中在[实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)，本页不重复实验历史。

- 统一模型语义图、冷编译、不可变计划、独立执行槽、prepare/layout 更新与严格 submit；普通引擎中间层
  不判断平台、Provider 或原生算子，同一后端的承载事实供 Direct/Graph 共用。
- 纳入原生生成结果的真实所有权，收拢计划、执行槽和退休；保留 caller-buffer 快路径、原生融合与异步进度。
- 贯通 prefill、cached continuation、decode、多请求、页与状态反馈，以及已有分支/接受前缀、失败/重试/关闭能力；
  同时消除具体 op/Provider 在共同资源核心中的特殊判断。
- 以性能约束架构：路由和规划冷生成，动态变化有明确准备边界；追查重复分配、转换、上传、搬运、host 等待及
  时间/空间复杂度问题。单 GPU 不强制 CPU 数学 Context 或额外调度运行时，必要原生开销如实保留并报告。
- 独立 Qwen3.5-2B 文本 CUDA 消费者尽早贯穿新主链，作为实际接口与性能反馈；多模态模型接线和完整 MTP 引擎
  政策不在本 goal 内，其已有底座能力不得退化。普通 API、构建依赖与文档随迁移收拢，不增加治理或繁复验证。
  该引擎是架构测试产物，用真实模型推理发现并回修底座 gap，不作为正式推理引擎产品扩张。

当前普通调用链已回到一份Graph计划与原Invocation：

最新一轮由实际变长attention补齐Apple/Vulkan普通Graph接线：复用原Program/Invocation，
统一冷布局与受保护的metadata绑定，保留各实现的数学镜像和零尾部费用。真实双CPU资源消费又消除了
CPU搬运的system-resource身份白名单，改用稳定主机地址能力证明别名。
Windows最终19项合跑及CPU搬运6项通过（1项重叠，共24个用例），Air最终11项通过；
源码与失败过程见[本轮归档](../evidence/correctness/inference-foundation-review-2026-10-18/native-ragged-graph.zip)。
未扩张compact RaggedMLA，也未据此签收整模型精度或持续吞吐。
Linux后续使用当前源码、原数学缓存完成现闭包增量编译链接，唯一原CPU＋CUDA finite-family用例实际通过；
未混用旧Graph/Provider宿主对象，[源码与记录](../evidence/correctness/inference-foundation-review-2026-10-18/linux-current-graph.zip)保留190对象身份及源码漂移0核对，不代签其余Linux功能。

沿8模型/22制品续查已修复Qwen3.8-2.4T的CUDA GQA16接线：删除历史比例名单，由整除、索引及实际原生数学/资源域决定承载。
Windows默认Direct/普通Graph的3项回归通过，含30次数学校验及容量拒绝；[证据](../evidence/correctness/inference-foundation-review-2026-10-18/qwen38-gqa16-current.zip)不代签整模型精度或吞吐。

- Direct/Graph共用实际承载分析；selected prepared说明端口、输出表示、阻塞与资源事实。
  共同核心核依赖、权限、alias和寿命，不再为具体row-cache算子或Provider复制准入名单。
- ExecutionSource保活真实Context/Runtime，QueueRef/QueueSequence负责真实队列身份与本次接纳；
  SubmissionCursor按原依赖的O(S+E)前沿推进。可选prepare_progress只驱动该游标，阻塞粗片段交原BlockingPool。
- caller输出与Apple/Vulkan生成结果共用GraphOutput及退休合同；跨存储搬运使用实际CopyRecording。
  finite family、canonical常量与冷packing共享原制品，可变bindings、workspace、layout与结果代际归独立槽。
- typed WeightBatch、ready/pending分页与状态控制附着原Invocation；owned layout区分Q活动行与KV容量。
  GQA三载荷、MLA两载荷不再要求引擎装配另一套batch Provider或专用协调器。

CPU＋CUDA旧运行时以及CPU＋Apple/Vulkan旧Plan、Invocation、driver均已归档删除，不保兼容入口。
CUDA仅保留冷环境helper；三条混合路线的权重、custom/finite、effects、pipeline和分页消费者复用普通入口。
本批实际Windows/Vulkan与MacBook Air/Apple检查包括64轮页消费、双槽与旧结果、D512/576 MLA、
真实多源pending及取消/关闭/abandon；冷OOM逐点检查没有放宽原数学预算。具体范围见[证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

真实消费者修出的共同问题包括：ready同布局帧替换缺失、pending冷准备半提交、drain遗漏observer回调尾部，
以及metadata分配失败被误当成可换路由的资源拒绝。已修复并保留对应失败恢复控制。
设备差异继续留在真实适配处：Vulkan固定backing的逃逸结果阻止复用，Apple独立生成Array可跨后续准备保活；
Scheduler空闲不等于GPU退休，取消须显式请求，close只停止接纳，drain等待实际完成。

性能尚未完成收工：Scheduler每轮task/stack仍有原有成本；native metadata镜像容量与必要上传保留，
Apple变KV布局仍可能构建eager数组图，不能宣传零热分配或全部数学域覆盖。
低维vector两pass现沿原MLX统一F32 partial、保最终dtype，删除架构后缀精度预测和默认Graph的低精度拒绝分支；
普通GQA也已修复跨batch KV基址遗漏。Air新4项通过，覆盖Direct/普通Graph、F16溢出与BF16抵消、
两槽旧结果、ragged和one-pass/full邻接及非零Q/K的B2消费。原数学控制明确失败，未放宽原容差。
同一旅程修复了分页Graph封存前遗漏释放内部已完成结果owner的问题，原生读者与公共旧结果gate保留。
F16/BF16 partial载荷从2B变4B，原Q/K/V存储不扩大；未测新吞吐或总显存峰值。
可选IO已收拢为显式 `compute_stream` 服务产品，默认Compute/Graph不带IO；四个薄桥接复用真实copy program，
CPU/CUDA文件搬运不要求数学Provider。已修复写回引用阻止读范围回收及GPU源producer观察问题；
Windows CPU14/14、Vulkan5/5、CUDA7/7及Air6/6通过，纯CPU shared安装/查包与独立file/mapping字节往返样例通过。
可选主机推进也已改为显式`graph_progress`服务产品；普通Graph不因同时安装Scheduler而带入该服务。
安装元数据静态/共享隔离夹具通过，复用原缓存增量13个TU、2个DLL的shared服务安装及独立消费者通过；
这只验证服务交付，不代签完整数学SDK。
CPU默认Direct/Graph已共用原Provider装配，同一ggml实例承载普通操作和region；6项定向回归保原偏好、数值及寿命。
冷编译的静态placement与coverage事实现每compile准备一次，实际资源权限与制品回滚仍逐attempt核对；
4项原重试/预算/OOM控制通过，Air复用原CPU→Apple→CPU双槽64轮消费者通过。
共同冷编译文件的其余职责仍按实际链路收敛，不增加转发层或第二套核心状态。
后续实测修复了可选原地写遗漏同存储View读者、已发布私有View被改写及跨lane只凭节点序号复用的问题。
冷编译先建立必须别名、汇总组寿命，再复用原segment依赖证明所有读者先于写；同lane原地快路径保留。
新4项及原重试/预算/OOM4项共8/8通过，修前数值与偏序反例保留；未新增热路径分析或Plan/Invocation字段。
Vulkan分页seal也已释放内部已完成结果后才过原reuse gate；新core与该修复合跑CPU/Vulkan Q18/Q2/Q0、
双槽和旧结果保护通过。上述均非新整模型数值或性能验收。
不可变输入source重准备现复用原槽的两个整数scratch容器；固定source、轮换普通绑定的4个观测轮次，
原12次metadata分配降为0，仍逐次重核route；连同原pending/失败控制4/4通过，非整次运行零分配声明。
Vulkan typed BF16已接原FullF32 flash逐tile读cache与最终原IREE RNE Cast；D256 plain分页/ragged及Q8、
紧凑MLA576→512的Direct/普通Graph双槽新2项通过，原F16低/高维与Q8三项正控保持。多request保持F32
至拼接完成后只转换一次；随后解耦现有F16/BF16 Q、成对KV与output轴，三种mixed组合及原控制共6/6通过，
含双槽、固定绑定重放和空输出；没有整KV宽化或新shader，未测pending精度、吞吐或整模型。
跨Apple Runtime的晚句柄现有producer原复制桥已通过Air实际消费：一份图、两个原槽，A原FIFO保留真实pending，
A原复制录制写合法共享存储，已有HostWait前沿再接B；Reject政策明确拒绝。新回归核两槽共四次不同输入、
旧GraphOutput和导出ReadLease保活，1/1通过；只新编当前core/input/ops和test四个C++ TU，未增加产品机制或重建SDK。
压缩行分页的权限投影和冷配置现已统一查询选定单算子/region，移除ordinary singleton限制；Vulkan从实际
lowering和最终dispatch提供checked bank事实，逻辑节点映射到真实Graph边界端口。设备metadata沿原Source冷上传，
实际退休后才publish；没有把bank改成host资源。新FP8 ready padding→Decode→Sink的融合/分拆、乱序页、
双槽、同槽换请求分组/页序、旧结果、真空史全writer与越权拒绝，连同原独立消费和CPU ready/pending共6/6通过。
原对象闭包在相同首次准备处明确失败。随后将原生pending输入能力从分页attention程序独立出来，
原Apple/Vulkan分页与Vulkan行缓存共用source factory、精确frame validate/commit和原退休合同，旧分页专属字段删除。
Vulkan FP8融合/分拆及FP4 D128的真实pending来源、短copy覆盖不足拒绝、旧结果与Update回收通过，
连同上述ready/CPU控制共9/9；FP8继续核原Sink预算，FP4核实际支持的解码行/mask/转换。
原分页联合消费者在Windows及Air均通过原64步/活动Q2和18/双槽控制，Air含F16与BF16。
所有SDK/native数学/shader沿用；本轮没有整模型精度或吞吐验收。
Apple普通Graph随后接通FP8/FP4行缓存ready读取，真实Map/Decode可融合或分拆；冷事实由实际lowering给出，
bank地址导入与准确页权限分开，同槽换layout先释放旧输入读owner。普通checked decoder也移除非法ID回退row0。
Air新6/6通过，含两槽、旧结果、真空史全writer、未授权页writer、plain非法ID与越权拒绝；FP8 Sink保原FP64预算。
融合冷准备不再实体化整个逻辑bank：2,449,473,536B容量的cold peak为3,900,296B，未创建真实arena/Invocation。
旧2.45GB控制被总字节索引门拒绝，旧1.22GB控制实际cold peak为1,228,637,018B；不是OOM或吞吐结果。
原SDK/metallib与选行kernel源身份沿用，仅增量7个产品host TU。
Apple行页pending随后与原native分页attention共用实际CopyOutcomeSource、原Invocation和页guard退休；
FP8融合/分拆及FP4新3项、ready6项、Direct/分页/indexer8项共17/17通过，原native分页F16/BF16各64步亦通过。
Direct/Graph的冷bank端口也收敛到同一数学实现事实，删去两个warmup算子bool与组合reader的假decoder注记。
随后确认并修复来源接纳后失败、最终仅挡发布却仍执行decoder的问题：原Apple Job在读取pending页前
复核真实Update的全部phase，失败跳过resolve/eval；借用源由原DependentCompletion保活，无新owner或公开observer。
原生decoder的独立探针使旧产品两个取消反例均明确失败，修复后19/19及原native F16/BF16各64步通过；
含早期写页phase取消、独立最后phase成功的反例，不能只看latest前缀。Direct receiver接入同一原Job检查，未另做Direct故障注入。

默认CUDA普通四口SDPA已接通dense F32 additive mask，沿原ggml F32程序与query分块；
同时修正原CUDA因果mask减FLT_MAX无法排除未来正无穷的问题。默认Direct/Graph新4项及原无mask回归共5/5通过，
原CU同用例失败对照保留；没有新增Graph特殊判断或融合/吞吐结论。

完整Qwen3.5-2B CUDA测试消费者已执行24层的23-token prefill→4-token续算→1-token decode，
此前已接现有可选进度驱动：direct与scheduler两模式各完整执行，150个观察tensor彼此及与上一冻结结果均逐字节相同。
别名寿命/InputSources更新后的direct重放仍逐字节相同。随后从实际Q/K/V切片补通用strided零拷贝reshape，
只在无法表达的flatten及caller固定输出保留Copy；当前direct三phase共150个tensor仍逐字节相同，
Copy节点85→25、报告步骤1252→1204，workspace略增；未重跑scheduler或据单次计时接受吞吐。
随后ggml CUDA直接借用本次Queue stream，删除逐片段双event桥及无条件私有root stream；失败辅助工作
在原CUDA EventSlot保留独立退休证明，观察错误/abandon继续由原reaper保活。新4项及原6项定向检查共10/10通过，
最终完整旅程150个tensor仍逐字节相同。同条件旧新各3次短请求，首decode中位33.59→20.27ms，
样本区间不重叠；正常EOS在第二decode结束，尚非持续warm decode或llama.cpp对照。
Model显式drain原槽后才结束runtimes、释放状态；共享tokens/KV/state仍须顺序evaluate，不推导同Model并发。
实际`rms_norm_f32<1024,true,false>`的归约mean与已保存Torch variance在首传播点差2个F32 ULP，
原拓扑重演和后续F32两乘解释该BF16中点分歧；Cast符合RNE，未改产品数学或容差。
单norm诊断另编原CU控制/插桩各一次，保留FFMA观测扰动和Torch中间仅离线推演的限制，不是重建SDK。
这不证明完整24层约2%的logits差异均同源；数值接受、公平tokens/s及Linux新旅程仍未完成。
首个full-attention层现已用候选真实Q/K/V做独立回放：原50份prefill结果及完整路由不变，RoPE对F32/F64
控制的最终BF16投影零差。attention对整行FP64的BF16投影差6678/47104，按实际16+7在线tile及BF16
未归一化权重重放后为51/47104；该控制仍不模拟native MMA/SFU/reciprocal指令顺序，未改产品或容差。
这定位了本层主要精度差异，尚未解释全部24层logits误差；整模型数值接受仍需继续。
随后独立Torch参考的RoPE单因素诊断先复现全部150份结果，再只将RoPE中间改F32、最终Q/K保BF16。
Hyle未改，三phase相对该参考的logits relL2从2.151%／1.957%／2.459%变为1.940%／1.490%／2.127%。
这只是固定输入上的部分因果贡献，top1一致且relL2降低不构成模型准确率、产品精度或性能验收。
随后[固定输入32阶段](../evidence/correctness/inference-foundation-review-2026-10-18/qwen-fixed-decode.zip)
将真实状态反馈推进到可见52个token；Direct与Scheduler的64份决策向量逐字节一致，当前CUDA/FI host更新后再放亦相同。
独立参考先复现原150份结果，再运行同一输入；eager的top1相同31/32，唯一差异步为最高两token并列，
logits相对L2均值1.166%、KL均值6.462e-4。此序列来自既有参考生成，只证明这条数值/状态旅程，
独立质量语料、持续吞吐及公平llama.cpp对照仍未完成。
实际capture审查未支持进一步碎分Graph段；消费者已补step_seconds，计入输入上传、布局、绑定及重放准备，
后续性能对照不用漏计这些费用的旧seconds。[审查与计时边界](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)
保留外层Commands与原生内部capture的区别。

后续按现行模型与制品范围补原功能审查遗留，核对融合、量化接线、状态/接受前缀、稀疏分页与连续推理旅程。
Apple/Vulkan五输入分页scorer数学与普通Graph接线已实现，实际bank1资格来自其原生lowering事实。
沿用原ready/pending页权限与来源检查；两端新6项均通过，Windows另有12项、Air此前19项相邻控制通过。
实际评分→TopK→FP8解码→Sink消费还发现并修复了部分placement下最大候选互相重叠的问题，
冷发现复用原writer补单节点候选，不增加热路由。完整scores仍为O(T×C)，未验收整模型或新吞吐。
架构迁移不等于功能完成，此前约75%仅是旧审查的粗估，不作为当前完成比例。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode，并完成上述短程性能对照；
  数值接受、长期稳态性能与其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 2026-10-19 用户移除旧 DeepSeek-V4-Pro/Flash preview 及其 GGUF 衍生制品的支持要求，
  同时加入 V4 系列正式版 Pro-0813、Flash-0731，现行范围为 8 个文本模型，已锁定24个官方/GGUF基线配置；
  两个正式版各选官方、同版本 UD-Q4_K_XL 与 UD-Q8_K_XL，身份已锁定，GGUF 的逐角色 codec 与 DSpark 覆盖仍待核，
  见[模型—制品—算子总表](../implementation/model-operators.md)。不能把 API 别名或旧 preview 的制品身份当成正式版。
  用户随后明确还须覆盖这些模型的 Unsloth 与 Hugging Face 主流量化制品；24不是范围上限，
  按实际模型版本、角色和精确 codec/packing/数值合同扩充，不凭位宽或量化名称代替接线覆盖。
  先补正反向关系，再删除已证明仅服务旧 preview、正式版与其他现行模型均不需要的非通用实现，
  随后检查各量化精度的融合接线。正式版仍有 FP4 expert、hash routing、压缩与 mHC，不能整组删除。
  共享算子、独立公共能力及历史源码/日志/数据不因模型名删除；旧八模型审查仅提供历史事实。
- 后续融合和量化接线以该现行范围为准，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 讨论起点

并行准备最小开发入口与真实文本引擎，用实际引擎旅程核对三种执行模式的底座能力。
重点检查驻留与增量状态、布局与 dtype 承载、动态形状与重放、异步搬运与 CPU 预算、
取消/失败/关闭、可观测性、安装包最小消费者，以及正常规模下的性能与显存。
后续实施顺序和具体改动继续按用户讨论推进，不将本页扩展为新的治理流程。

后续接口检查线索：锁定 ggml 的 CUDA GDN/causal conv 原实现要求 F32；这不是已证实的
BF16/FP8 接入遗漏。本轮已接通锁定 ggml 的多 token recurrent snapshot；
默认仍只输出最终状态，MTP 验证块显式请求快照，并按接受前缀恢复。

首个完整消费者重点确认：prepare/repack 是否留在冷路径；KV 有效长度变化是否导致重编译或多余绑定；
GDN、conv、attention 之间是否出现实体转置、dtype 转换或 host 同步；常量与状态能否按真实寿命复用。
`TensorDesc::transposed()` 仅改变描述，不搬运 payload。静态合同无误不代表实际转换次数或热路径成本合理，
不提前规定新的统一布局或合并各原生 runtime。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这批早期参考材料覆盖公式与片段；完整 CUDA 消费者及实测结果见第六项。
加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版已按第六项约定关闭 MTP/视觉；与 llama.cpp 对照的权重、精度和计时边界见该项实测记录。
