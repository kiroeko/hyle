"""Run only the nine actual alias/owner/rollback consumers affected here."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alias_run_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
build.check(plan)
if not c.read(path.parent / 'summary.json')['passed']:
    raise ValueError('Successful host increment required')
out = path.parent / 'run-cpu'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
env, _ = b.environment(plan['links']['cpu']['command'], [r['path'] for r in plan['cached_inputs']], out)
image = b.identity(plan['links']['cpu']['image'])
if image != c.read(path.parent / 'cpu-image.json'):
    raise ValueError('CPU image differs')
command = [image['path'], '--gtest_filter=' + ':'.join(plan['exact_tests']),
           '--gtest_color=no', '--gtest_output=xml:' + str(out / 'result.xml')]
c.save(out / 'inputs.json', {'runner': b.identity(Path(__file__)), 'plan': b.identity(path),
                           'image': image, 'requested_tests': plan['exact_tests']})
c.execute('cpu', command, env, out)
xml = ET.parse(out / 'result.xml').getroot()
counts = {key: int(xml.get(key, 0)) for key in ('tests', 'failures', 'disabled', 'errors')}
cases = [case for case in xml.iter('testcase')]
names = [case.get('classname') + '.' + case.get('name') for case in cases]
passed = (set(names) == set(plan['exact_tests']) and counts['tests'] == 9 and
          not any(counts[key] for key in ('failures', 'disabled', 'errors')) and
          all(case.get('status') == 'run' and case.find('skipped') is None for case in cases))
c.save(out / 'summary.json', {'passed': passed, **counts, 'cases': names,
                            'limits': 'Nine related CPU cases, not a full current suite or cross-platform run.'})
if not passed:
    raise ValueError('Expected all nine exact related cases to execute successfully')
print('CPU_CHECK', counts, flush=True)
