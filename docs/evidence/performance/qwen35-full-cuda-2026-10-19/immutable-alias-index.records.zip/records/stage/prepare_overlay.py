"""Prepare the reviewed alias index and two existing CPU fixtures; no build."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
OLD = STAGE.parent / 'cuda-fusion-layout/alias-overlay'


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Expected unique fixture anchor: ' + old[:100])
    return text.replace(old, new)


def main():
    sources = {}
    for name in ('src/graph/executable.cc', 'src/graph/plan_state.h'):
        before = (OLD / 'before' / name).read_bytes()
        if (ROOT / name).read_bytes() != before:
            raise ValueError('Frozen product base drift: ' + name)
        sources[name] = (before, (OLD / 'source' / name).read_bytes())

    name = 'tests/graph/executable_test.cc'
    original = (ROOT / name).read_bytes()
    text = original.decode('utf-8').replace('\r\n', '\n')
    extra = r'''
TEST(Invocation, ImmutableAllocationGroupsKeepViewOffsetsAcrossReset) {
  auto provider = hyle::compute::aten_cpu::provider();
  ASSERT_TRUE(provider.valid());
  const std::array providers{hyle::compute::ProviderBinding{provider, 100}};
  auto context = Context::create(hyle::compute::cpu::device(),
                                  {.providers = providers}).value();
  auto queue = context.create_queue().value();
  const auto root_description = TensorDesc::dense(DataType::kFloat32,
      std::array<std::int64_t, 5>{1, 1, 1, 1, 4}).value();
  const auto description = TensorDesc::dense(DataType::kFloat32,
      std::array<std::int64_t, 5>{1, 1, 1, 1, 2}).value();
  auto builder = GraphBuilder::create().value();
  const auto first = builder.constant(root_description).value();
  const auto second = builder.constant(root_description).value();
  const auto third = builder.constant(root_description).value();
  const auto selected = builder.add(View::slice(4, 1, 2).value(), first).value();
  const auto output = builder.add(Unary{UnaryKind::kNeg}, selected).value();
  for (const auto value : {first, second, third, selected, output})
    ASSERT_TRUE(builder.publish(value).ok());
  const auto graph = std::move(builder).finish().value();
  auto bank = make_tensor(row(12));
  auto separate = make_tensor(root_description);
  const std::array bank_values{1.F, -2.F, 3.F, -4.F,
      5.F, -6.F, 7.F, -8.F, 91.F, 92.F, 93.F, 94.F};
  const std::array separate_values{9.F, -10.F, 11.F, -12.F};
  write(bank, bank_values);
  write(separate, separate_values);
  const auto first_source = TensorView::create(root_description,
      bank.buffer.view().subview(0, 4 * sizeof(float)).value()).value();
  const auto second_source = TensorView::create(root_description,
      bank.buffer.view().subview(4 * sizeof(float), 4 * sizeof(float)).value()).value();
  // Input binding order differs from graph order; both bank ranges share the
  // actual allocation token while the third root has a different allocation.
  const std::array constants{
      ConstantBinding{third, separate.view.as_const()},
      ConstantBinding{second, second_source.as_const()},
      ConstantBinding{first, first_source.as_const()}};
  auto compiled = hyle::graph::compile(graph, context, {.constants = constants});
  ASSERT_TRUE(compiled) << compiled.error().message();
  auto run = compiled->executable.create_invocation().value();
  auto old_destination = make_tensor(description);
  auto new_destination = make_tensor(description);
  const auto unused_bank_range = TensorView::create(description,
      bank.buffer.view().subview(8 * sizeof(float), 2 * sizeof(float)).value()).value();
  for (int round = 0; round < 3; ++round) {
    if (round != 0) ASSERT_TRUE(run.reset().ok());
    // Check every same-token range, including one that overlaps only the
    // second constant and another that straddles the two root boundaries.
    for (const auto offset : {sizeof(float), 3 * sizeof(float), 5 * sizeof(float)}) {
      const auto overlapping = TensorView::create(description,
          bank.buffer.view().subview(offset, 2 * sizeof(float)).value()).value();
      EXPECT_TRUE(run.bind(output, overlapping).IsInvalidArgument());
    }
    const auto other_overlap = TensorView::create(description,
        separate.buffer.view().subview(sizeof(float), 2 * sizeof(float)).value()).value();
    EXPECT_TRUE(run.bind(output, other_overlap).IsInvalidArgument());
    const auto destination = round == 0 ? old_destination.view
        : round == 1 ? unused_bank_range : new_destination.view;
    ASSERT_TRUE(run.bind(output, destination).ok());
    // Repeated binding keeps normal invalidation and all dynamic gates.
    ASSERT_TRUE(run.bind(output, destination).ok());
    ASSERT_TRUE(run.submit(queue)->wait().ok());
    expect_near(read(destination.as_const(), 2), std::array{2.F, -3.F});
    expect_near(read(run.output(first).value(), 4),
                std::span(bank_values).first(4));
    expect_near(read(run.output(second).value(), 4),
                std::span(bank_values).subspan(4, 4));
    expect_near(read(run.output(third).value(), 4), separate_values);
    expect_near(read(run.output(selected).value(), 2), std::array{-2.F, 3.F});
    expect_near(read(old_destination, 2), std::array{2.F, -3.F});
    if (round == 0) expect_near(read(bank, 12), bank_values);
    else {
      auto expected = bank_values;
      expected[8] = 2.F; expected[9] = -3.F;
      expect_near(read(bank, 12), expected);
    }
    expect_near(read(separate, 4), separate_values);
  }
}

'''
    text = replace_once(text, 'TEST(GraphCompile, ReusesInternalStorageForLifetimeSafeInPlaceOperations) {',
                        extra + 'TEST(GraphCompile, ReusesInternalStorageForLifetimeSafeInPlaceOperations) {')
    newline = '\r\n' if b'\r\n' in original else '\n'
    sources[name] = (original, text.replace('\n', newline).encode('utf-8'))

    name = 'tests/graph/region_provider_test.cc'
    original = (ROOT / name).read_bytes()
    text = original.decode('utf-8').replace('\r\n', '\n')
    text = replace_once(text, '  std::vector<std::array<float, 4>> source_values;\n',
        '  std::vector<std::array<float, 4>> source_values;\n'
        '  // Borrowed observer of the fixture\'s actual mutable payload owner.\n'
        '  hyle::mem::BufferView prepared_backing{};\n')
    text = replace_once(text,
        '    for (std::size_t port = 0; port < context.output_count; ++port)\n'
        '      HYLE_RETURN_IF_ERROR(data->buffer.write(port * sizeof(values),\n'
        '          std::as_bytes(std::span(values))));\n    return Status::Ok();\n',
        '    for (std::size_t port = 0; port < context.output_count; ++port)\n'
        '      HYLE_RETURN_IF_ERROR(data->buffer.write(port * sizeof(values),\n'
        '          std::as_bytes(std::span(values))));\n'
        '    context.probe->prepared_backing = data->buffer.view();\n'
        '    return Status::Ok();\n')
    anchor = 'TEST(GraphRegions, ReadyOnlyConstantsShareOwnedOutputsAcrossSlotsAndOldResults) {'
    begin = text.index(anchor)
    end = text.index('\nTEST(', begin + len(anchor))
    case = text[begin:end]
    case = replace_once(case,
        '  EXPECT_EQ(ready.factories, 1U);\n  ASSERT_TRUE(source.buffer.reset().ok());',
        '  EXPECT_EQ(ready.factories, 1U);\n'
        '  ASSERT_TRUE(ready.prepared_backing.valid());\n'
        '  ASSERT_EQ(ready.prepared_backing.size(), 8 * sizeof(float));\n'
        '  const auto reject_prepared_alias = [&](hyle::graph::Invocation &slot) {\n'
        '    for (const auto offset : {std::size_t{0}, sizeof(float), 4 * sizeof(float)}) {\n'
        '      const auto overlap = TensorView::create(row(4),\n'
        '          ready.prepared_backing.subview(offset, 4 * sizeof(float)).value()).value();\n'
        '      EXPECT_TRUE(slot.bind(logical.outputs[0], overlap).IsInvalidArgument());\n'
        '    }\n'
        '    std::array<float, 8> retained{};\n'
        '    EXPECT_TRUE(ready.prepared_backing.read(\n'
        '        std::as_writable_bytes(std::span(retained))).ok());\n'
        '    EXPECT_EQ(retained, (std::array{-1.F, 2.F, -3.F, 4.F, -1.F, 2.F, -3.F, 4.F}));\n'
        '  };\n  ASSERT_TRUE(source.buffer.reset().ok());')
    case = replace_once(case,
        '  for (std::size_t slot = 0; slot < slots.size(); ++slot) {\n'
        '    for (std::size_t port',
        '  for (std::size_t slot = 0; slot < slots.size(); ++slot) {\n'
        '    reject_prepared_alias(slots[slot]);\n    for (std::size_t port')
    case = replace_once(case,
        '      ASSERT_TRUE(slots[1].reset().ok());\n'
        '      for (std::size_t port',
        '      ASSERT_TRUE(slots[1].reset().ok());\n'
        '      reject_prepared_alias(slots[1]);\n      for (std::size_t port')
    text = text[:begin] + case + text[end:]
    newline = '\r\n' if b'\r\n' in original else '\n'
    sources[name] = (original, text.replace('\n', newline).encode('utf-8'))

    changes, rows = [], []
    for name, (before, after) in sources.items():
        for directory, data in (('before', before), ('source', after)):
            target = STAGE / directory / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        changes.extend(difflib.unified_diff(before.decode().splitlines(True),
            after.decode().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
        rows.append({'source': name, 'before': identity(STAGE/'before'/name),
                     'after': identity(STAGE/'source'/name)})
    (STAGE/'changes.diff').write_text(''.join(changes).replace('\r\n', '\n'), encoding='utf-8')
    (STAGE/'source-freeze.json').write_text(json.dumps({
        'state': 'Scratch-only overlay; not applied, built or tested.',
        'base_alias_freeze': identity(OLD/'source-freeze.json'),
        'files': rows, 'diff': identity(STAGE/'changes.diff')}, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'files': len(rows), 'diff': identity(STAGE/'changes.diff')}))


if __name__ == '__main__':
    main()
