"""Retained B/C/L rotation and metric parsers; no numerical-approval gate."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import statistics
import sys
import traceback

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
spec = importlib.util.spec_from_file_location('rope_retained_rotation', ARCH / 'cuda-bf16-dual-projection/compare_three_dual.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
r.PREPARED = STAGE / 'performance-prepared'
r.PEER_PLAN = ARCH / 'cuda-bf16-dual-projection/metadata-fix/performance-prepared/peer-link-plan.json'
r.BASELINE_IDS = ARCH / 'cuda-explicit-rope/correctness/current/qwen.stdout.log'
b, c = r.b, r.c


def run(prepared, output):
    plan = c.read(prepared)
    if plan['status'] != 'prepared_not_run' or plan['order'] != r.ORDER:
        raise ValueError('Expected the retained nine-process rotation')
    for row in plan['frozen'] + plan['peer_inputs'] + list(plan['images'].values()):
        r.require_same(row)
    build, peer = c.read(plan['build_plan']['path']), c.read(r.PEER_PLAN)
    if not output.is_relative_to(STAGE) or output in (STAGE, r.PREPARED):
        raise ValueError('Output must be a new child of this stage')
    output.mkdir(parents=True, exist_ok=False)
    (output / 'tmp').mkdir()
    env, runtime = r.runtime_environment(build, peer, output)
    c.save(output / 'inputs.json', {'prepared_plan': b.identity(prepared), 'images': plan['images'],
        'fixed': plan['fixed'], 'order': r.ORDER, 'runtime': runtime,
        'profiler': False, 'quality_acceptance': False, 'operator_approval_gate': False})
    runs = []
    summary = {'status': 'incomplete', 'quality_acceptance': False, 'runs': runs}
    try:
        for request in plan['requests']:
            for row in plan['images'].values():
                r.require_same(row)
            command = [x.replace('{output}', str(output)) for x in request['command']]
            process = r.execute(request['tag'], command, env, output)
            observed = (r.peer_result(output / (request['tag'] + '-peer-result.json'), plan)
                if request['arm'] == 'llama' else r.hyle_result(output, request, plan))
            runs.append({'arm': request['arm'], 'tag': request['tag'], 'pid': process['pid'],
                'exit': process['exit'], 'command': command,
                'process_wall_seconds': process['finished'] - process['started'], **observed})
            c.save(output / 'runs.json', runs)
        groups = {arm: {key: {'samples': [x['metrics'][key] for x in runs if x['arm'] == arm],
            'median': statistics.median(x['metrics'][key] for x in runs if x['arm'] == arm),
            'min': min(x['metrics'][key] for x in runs if x['arm'] == arm),
            'max': max(x['metrics'][key] for x in runs if x['arm'] == arm)}
            for key in r.COMMON_METRICS} for arm in ('baseline', 'current', 'llama')}
        summary = {'status': 'nine_fresh_unprofiled_processes_terminal_zero', 'terminal_zero': len(runs),
            'order': r.ORDER, 'groups': groups, 'images': plan['images'],
            'current_over_baseline': {k: groups['current'][k]['median'] / groups['baseline'][k]['median'] for k in r.COMMON_METRICS},
            'current_over_llama': {k: groups['current'][k]['median'] / groups['llama'][k]['median'] for k in r.COMMON_METRICS},
            'same_baseline_predictions_all9': all(x['same_baseline_predictions'] for x in runs),
            'predictions_deterministic_within_each_arm': all(len({tuple(x['generated_ids']) for x in runs if x['arm'] == arm}) == 1 for arm in groups),
            'capture_results': {arm: [x['capture_counts'] for x in runs if x['arm'] == arm] for arm in groups},
            'metric_contract': plan['metric_contract'], 'profiler': False, 'external_memory_monitor': False,
            'statistical_significance': False, 'independent_quality_acceptance': False,
            'limits': ['Three fresh processes per image in one rotated window; drift remains possible.',
                'No historical timing samples or profiler durations enter these medians.',
                'Hyle prepares both shapes before prefill; peer graph maintenance remains in step.',
                'Weight loading and context preparation have different engine sub-boundaries.',
                'Same fixed128+31 inputs; current predictions are reported, not used as an approval gate.',
                'Matching predictions are not independent language-model quality acceptance.']}
        c.save(output / 'summary.json', summary)
        print('NINE_PROCESS_ROTATION_COMPLETE', output / 'summary.json', flush=True)
    except Exception as error:
        summary.update(error=str(error), terminal_zero=len(runs))
        c.save(output / 'summary.json', summary)
        (output / 'failure.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise


def prepare(build_path):
    build_path = build_path.resolve()
    build = c.read(build_path)
    if not c.read(build_path.parent / 'summary.json')['passed']:
        raise ValueError('Successful host increment required')
    # Reuse the existing fair input contract and peer image, with no relink.
    retained = c.read(ARCH / 'cuda-gdn-l2-epilogue/performance-prepared/plan.json')
    images = {'baseline': c.read(build_path.parent / 'baseline-image.json'),
              'current': c.read(build_path.parent / 'qwen-image.json'),
              'llama': c.read(ARCH / 'cuda-explicit-rope/performance-prepared/peer-image.json')}
    for row in images.values():
        r.require_same(row)
    if images['baseline']['path'] != build['links']['baseline']['image'] or images['current']['path'] != build['links']['qwen']['image']:
        raise ValueError('Build image identity differs')
    # The baseline is the retained, already linked v20 image, not a fresh link.
    peer = c.read(r.PEER_PLAN)
    for row in peer['inputs']:
        r.require_same(row)
    frozen = []
    for row in retained['frozen']:
        # Keep input/model/recipe facts; do not pretend the historical build
        # describes the current implementation.
        if row['path'] == retained['build_plan']['path']:
            continue
        r.require_same(row)
        frozen.append(row)
    frozen.extend([b.identity(Path(__file__)), b.identity(build_path),
                   b.identity(build_path.parent / 'run-cpu/summary.json'),
                   b.identity(STAGE / 'correctness/summary.json')])
    plan = {key: retained[key] for key in (
        'schema_version', 'status', 'fixed', 'source_id', 'expected_baseline_ids',
        'order', 'metric_contract')}
    requests = []
    for request in retained['requests']:
        command = request['command'].copy()
        command[0] = images[request['arm']]['path']
        requests.append({**request, 'command': command})
    plan.update(build_plan=b.identity(build_path), images=images,
        peer_inputs=peer['inputs'], frozen=frozen, requests=requests,
        source_or_SDK_compilations=0, Hyle_links=0, peer_links=0, GPU_runs=0,
        peer_image_reused=True, baseline_image_reused=True, profiler=False,
        numerical_acceptance='Previously executed 64-vector exact comparison; not independent model quality acceptance.')
    r.PREPARED.mkdir(exist_ok=False)
    c.save(r.PREPARED / 'plan.json', plan)
    print('PREPARED_NO_GPU', r.PREPARED / 'plan.json', flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-plan', type=Path)
    p.add_argument('--run', action='store_true')
    p.add_argument('--prepared-plan', type=Path, default=r.PREPARED / 'plan.json')
    p.add_argument('--out', type=Path)
    args = p.parse_args()
    if args.run:
        if args.build_plan:
            raise ValueError('Preparation and timed rotation are separate invocations')
        run(args.prepared_plan.resolve(), args.out.resolve() if args.out else STAGE / ('performance-rotation-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')))
    else:
        if not args.build_plan:
            raise ValueError('--build-plan is required')
        prepare(args.build_plan)


if __name__ == '__main__':
    main()
