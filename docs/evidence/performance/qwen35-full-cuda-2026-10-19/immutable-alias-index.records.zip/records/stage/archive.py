"""Archive the tested immutable alias index, without caches or link maps."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T111822/plan.json'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/immutable-alias-index.zip'
EXCLUDED = {'.exe', '.obj', '.pdb', '.lib', '.exp', '.dll', '.pyc', '.map'}
DOCS = (
    'docs/architecture/compute-design.md',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
    'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify(row):
    path = Path(row['path']).resolve()
    data = path.read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Frozen file drift: ' + str(path))
    return path


def same_content(path, row):
    data = path.read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Snapshot/product content differs: ' + str(path))


def main():
    if DEST.exists():
        raise ValueError('Archive already exists; refusing replacement')
    freeze = read(STAGE / 'source-freeze.json')
    application = read(STAGE / 'application.json')
    plan = read(PLAN)
    if plan['host_TUs'] != 11 or plan['native_TUs'] != 0:
        raise ValueError('Expected tested eleven-host closure')
    verify(application['freeze'])
    for row in freeze['files']:
        verify(row['before'])
        verify(row['after'])
        same_content(ROOT / row['source'], row['after'])
    verify(freeze['diff'])
    for row in freeze['records']:
        verify(row)
    for row in application['files']:
        verify(row)

    # Test every actual compiled source and its retained snapshot, including
    # the otherwise unchanged owners of the modified private PlanState header.
    snapshots = []
    for row in plan['compile']:
        source = verify(row['source'])
        relative = source.relative_to(ROOT)
        snapshot = STAGE / 'source' / relative
        same_content(snapshot, row['source'])
        snapshots.append({'path': relative.as_posix(), 'sha256': row['source']['sha256'],
                          'bytes': row['source']['bytes']})
    if len(snapshots) != 11 or len({row['path'] for row in snapshots}) != 11:
        raise ValueError('Expected eleven distinct tested source snapshots')
    expected_snapshots = {row['path'] for row in snapshots} | {'src/graph/plan_state.h'}
    actual_snapshots = {path.relative_to(STAGE / 'source').as_posix()
                        for path in (STAGE / 'source').rglob('*') if path.is_file()}
    if actual_snapshots != expected_snapshots:
        raise ValueError('Unexpected or missing source overlay; refusing untested material')

    external = []
    for row in plan['frozen']:
        path = verify(row)
        if path.is_relative_to(STAGE) or path.suffix.lower() in EXCLUDED:
            continue
        if not path.is_relative_to(ROOT):
            raise ValueError('Unexpected non-workspace frozen text input')
        external.append(('tested-inputs/' + path.relative_to(ROOT).as_posix(), path))
    for tag in ('cpu', 'qwen'):
        verify(read(PLAN.parent / (tag + '-image.json')))

    build = read(PLAN.parent / 'summary.json')
    cpu = read(PLAN.parent / 'run-cpu/summary.json')
    model = read(STAGE / 'correctness/summary.json')
    rotation = read(STAGE / 'performance-rotation/summary.json')
    if not all(report['passed'] for report in (build, cpu, model)):
        raise ValueError('Expected retained successful build/CPU/model observations')
    if model['observation']['equal_vectors'] != 64:
        raise ValueError('Expected64 exact model vectors')
    if rotation['terminal_zero'] != 9:
        raise ValueError('Expected nine fresh process results')
    results = sorted((STAGE / 'performance-rotation').glob('*.result.json'))
    if len(results) != 9 or any(read(path).get('exit') != 0 or not read(path).get('terminal') for path in results):
        raise ValueError('Nine raw terminal-zero process records not found')
    for row in read(STAGE / 'performance-rotation/inputs.json')['images'].values():
        verify(row)

    scope = {
        'plan_sha256': sha(PLAN.read_bytes()),
        'freeze_sha256': sha((STAGE / 'source-freeze.json').read_bytes()),
        'application_sha256': sha((STAGE / 'application.json').read_bytes()),
        'applied_product_after_files_verified': len(freeze['files']),
        'compiled_source_snapshots': snapshots,
        'private_header_snapshot': 'src/graph/plan_state.h',
        'build': {'host_TUs': 11, 'native_TUs': 0, 'cpu_link_inputs': 112, 'qwen_link_inputs': 125},
        'CPU_test_count': cpu['tests'], 'model_equal_vectors': model['observation']['equal_vectors'],
        'fresh_processes_terminal_zero': 9,
        'documentation_is_current_context_not_a_tested_product_source': list(DOCS),
        'unapplied_GDN_overlays_included': False,
        'unfrozen_product_sources_included': False,
        'SDKs_models_binary_caches_and_maps_excluded': True,
        'source_freeze_state_text_is_the_historical_pre_application_record': True,
        'current_applied_and_tested_state_is_established_by_application_and_actual_build_records': True,
    }
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8', newline='\n')
    files = external + [('documentation/' + relative, ROOT / relative) for relative in DOCS]
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if not path.is_file() or 'tmp' in path.relative_to(STAGE).parts or path.suffix.lower() in EXCLUDED:
            continue
        if path.name == 'archive-verification.json':
            raise ValueError('Unexpected old archive receipt')
        files.append(('stage/' + path.relative_to(STAGE).as_posix(), path))
    names = [name for name, _ in files]
    if len(names) != len(set(names)) or any('gdn' in name.lower() for name in names):
        raise ValueError('Duplicate entry or unexpected GDN source overlay')

    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in files:
            data = path.read_bytes()
            records.append({'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)})
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC failure')
        if len(archive.namelist()) != len(records) + 1:
            raise ValueError('Archive entry count differs')
        for row in records:
            data = archive.read(row['entry'])
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError('Archive payload hash differs')
        if any(Path(name).suffix.lower() in EXCLUDED for name in archive.namelist()):
            raise ValueError('Excluded cache or map entered archive')
    receipt = {
        'path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': sha(DEST.read_bytes()),
        'payloads': len(records), 'entries_including_manifest': len(records) + 1,
        'uncompressed_payload_bytes': sum(row['bytes'] for row in records),
        'CRC_and_every_payload_SHA_verified': True,
        'applied_product_after_files_verified': 4, 'compiled_source_snapshots_verified': 11,
        'private_header_snapshot_verified': True,
        'build_CPU_model_and_nine_process_records_included': True,
        'SDKs_models_objects_executables_maps_excluded': True,
        'unapplied_GDN_overlays_excluded': True,
    }
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text, encoding='utf-8', newline='\n')
    DEST.with_name('immutable-alias-index-archive.json').write_text(text, encoding='utf-8', newline='\n')
    print(text, flush=True)


if __name__ == '__main__':
    main()
