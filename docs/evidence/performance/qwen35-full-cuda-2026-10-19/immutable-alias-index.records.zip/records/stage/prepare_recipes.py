"""Inventory the existing CPU closure and literal fresh-source recipes only."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCH = STAGE.parent
BASE = ARCH / 'immutable-constant-alias/checks/20261019T063301-1d108b74'
LAST = ARCH / 'immutable-constant-alias/checks/20261019T063738-35becef7'
CORE = ['src/graph/executable.cc', 'src/graph/constant_artifact.cc',
        'src/graph/input_sources.cc', 'src/graph/region_access.cc',
        'src/graph/resources.cc', 'src/graph/resource_report.cc',
        'src/graph/submission.cc', 'src/graph_progress/progress.cc']
TESTS = ['tests/graph/constant_artifact_cache_test.cc',
         'tests/graph/region_provider_test.cc']


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def main():
    base, last = read(BASE/'plan.json'), read(LAST/'plan.json')
    link = read(LAST/'cpu-link-plan.json')
    inputs = {key(row['path']): row for row in link['inputs']}
    rows = []
    for name in CORE + TESTS:
        plan = base if name in CORE else last
        folder = BASE if name in CORE else LAST
        row = next(row for row in plan['compile'] if key(row['source']['path']) == key(ROOT/name))
        if key(row['object']) not in inputs:
            raise ValueError('Replacement missing from CPU closure: ' + name)
        receipt = folder/(row['tag']+'-identity.json')
        actual = read(receipt)
        if actual['object']['sha256'] != inputs[key(row['object'])]['sha256']:
            raise ValueError('Recipe object identity differs from linked input')
        source = STAGE/'source'/name
        if not source.exists(): source = ROOT/name
        rows.append({'source_name': name, 'source': identity(source),
            'application_target': str(ROOT/name), 'operation': 'replace',
            'old_object': inputs[key(row['object'])], 'recipe': identity(receipt),
            'command_template': row['command']})
    name = 'tests/graph/executable_test.cc'
    receipt = ARCH/'immutable-constant-alias/commands.json'
    command = read(receipt)[2]
    if command['tag'] != 'executable-test-overlap-compile' or command['exit'] != 0:
        raise ValueError('Expected the recorded successful executable fixture recipe')
    rows.append({'source_name': name, 'source': identity(STAGE/'source'/name),
        'application_target': str(ROOT/name), 'operation': 'add',
        'old_object': None, 'recipe': identity(receipt), 'recipe_index': 2,
        'command_template': command['command']})
    missing = [row['path'] for row in link['inputs'] if not Path(row['path']).is_file()]
    if missing: raise ValueError('Missing cached CPU input: ' + repr(missing))
    out = {'state': 'Recipes only. No compile/link/test commands executed.',
        'private_PlanState_ABI_change': True, 'public_ABI_change': False,
        'base_cpu_link_plan': identity(LAST/'cpu-link-plan.json'),
        'absolute_inputs': len(inputs), 'missing_inputs': missing,
        'fresh_compile_count': len(rows), 'compile': rows,
        'link_edit': 'Replace exactly these 10 old objects, append the fresh executable_test object, and change output paths into this stage/checks. Reuse all other CPU inputs in place.',
        'command_adaptation': 'After applying the frozen overlay, retain each template compiler/flags/includes, replace its source path and /Fo,/Fd,/sourceDependencies outputs. Do not compile the scratch copy of executable.cc without a matching local private-header include root.',
        'cached_input_validation': 'All 111 absolute input files exist. Use their existing linked bytes/SHA identities for the actual build check; this inventory did not rehash large SDK libraries.',
        'unlinked_private_header_tests': ['tests/graph/aggregate_native_retirement_test.cc'],
        'unlinked_note': 'If aggregate_native_retirement_test is added later, compile it fresh as another PlanState consumer; it is absent here.',
        'unchanged': 'No native CUDA/SDK/provider math rebuild, public region extension increment, new target or executor. graph_batch/providers do not include the private PlanState header in this audited closure.',
        'scope': 'This selected CPU regression closure is reused from an earlier successful run. It is not a claim that every unrelated cached source or the complete current CPU test suite was rebuilt.',
        'exact_tests': [
            'Invocation.ImmutableAllocationGroupsKeepViewOffsetsAcrossReset',
            'Invocation.ImmutableConstantsAndTheirViewsNeverUseDestructiveAliases',
            'Invocation.AllowsOnlyLifetimeSafeExactExternalInPlaceAlias',
            'Invocation.RepeatedOutputBindingKeepsAliasChecksForChangedInputsAndRanges',
            'GraphCompile.MaterializedConstantMetadataFailuresRollBack',
            'GraphCompile.MaterializedPublishedConstantsAndViewsPreserveExactLayout',
            'GraphRegions.ReadyOnlyConstantsShareOwnedOutputsAcrossSlotsAndOldResults',
            'GraphRegions.ImmutableConstantViewsPreserveDenseReshapeAndSliceBindings',
            'GraphRegions.ZeroDispatchRejectsIncompletePreparedOutputs']}
    (STAGE/'host-recipes.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
    freeze = read(STAGE/'source-freeze.json')
    freeze['records'] = [identity(STAGE/name) for name in (
        'prepare_overlay.py', 'prepare_recipes.py', 'review.json', 'host-recipes.json')]
    (STAGE/'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'fresh_TUs': len(rows), 'inputs': len(inputs), 'tests': len(out['exact_tests'])}))


if __name__ == '__main__':
    main()
