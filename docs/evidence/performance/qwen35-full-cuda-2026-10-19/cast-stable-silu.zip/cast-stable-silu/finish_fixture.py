"""Refresh only the corrected test owner; preserve original Qwen and four owners."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cast_fixture_build', S/'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b, c = m.b, m.c
old_path = Path(sys.argv[1]).resolve()
old = c.read(old_path)
out = S/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-fixture-correction')
out.mkdir(exist_ok=False); (out/'tmp').mkdir()
plan = c.read(old_path)
row = next(r for r in plan['compile'] if r['tag'] == 'cast-test')
prior = c.read(old_path.parent/'cast-test-identity.json')
row['recipe'] = b.identity(old_path.parent/'cast-test-identity.json')
row['source'] = b.identity(row['source']['path'])
row['command'] = b.host_command(prior['command'], Path(row['source']['path']), 'cast-test', out)
row['object'] = str(out/'cast-test.obj')
snapshot = out/'compiled-source/tests/graph_provider_ggml_cuda/cast_stable_silu_test.cc'
snapshot.parent.mkdir(parents=True); snapshot.write_bytes(Path(row['source']['path']).read_bytes())
plan['frozen'] = [b.identity(r['path']) for r in plan['frozen']
    if not ('compiled-source' in r['path'] and r['path'].endswith('cast_stable_silu_test.cc'))]
plan['frozen'] += [b.identity(snapshot), b.identity(__file__), row['recipe']]
identities = {c.key(r['path']):r for r in plan['cached_inputs']}
for item in old['compile']:
    record = c.read(old_path.parent/(item['tag']+'-identity.json'))
    if not b.same(record['object']): raise ValueError('Previous owner changed')
    identities[c.key(record['object']['path'])] = record['object']
plan['cached_inputs'] = list(identities.values())
cast = plan['links']['cast']
cast['command'] = [row['object'] if c.key(x)==c.key(prior['object']['path']) else x
    for x in cast['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
cast['image'] = str(out/'cast.exe')
cast['command'] += ['/OUT:'+cast['image'], '/MAP:'+str(out/'cast.map'), '/IMPLIB:'+str(out/'cast.lib')]
cast['inputs'] = [row['object'] if c.key(x)==c.key(prior['object']['path']) else x for x in cast['inputs']]
plan['fixture_correction'] = dict(prior_plan=b.identity(old_path), fresh_TUs=1,
    reused_product_TUs=4, Qwen_relinked=False, Qwen_image=c.read(old_path.parent/'qwen-image.json'),
    first_tests=b.identity(S/'tests-first-failure/summary.json'))
path = out/'plan.json'; c.save(path, plan); m.check(plan)
env,_ = b.environment(cast['command'], cast['inputs'], out)
c.execute('cast-test-compile-1', row['command'], env, out); m.check(plan)
data = c.read(out/'cast-test-deps.json')['Data']
record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
    dependencies=[b.identity(p) for p in [data['Source'], *data['Includes']]])
c.save(out/'cast-test-identity.json', record)
identities[c.key(row['object'])] = record['object']
c.execute('cast-link-1', cast['command'], env, out); m.check(plan)
c.save(out/'cast-link-plan.json', dict(command=cast['command'], inputs=[identities[c.key(p)] for p in cast['inputs']]))
c.save(out/'cast-image.json', b.identity(cast['image']))
for arm in ('qwen-link-plan.json', 'qwen-image.json'):
    (out/arm).write_bytes((old_path.parent/arm).read_bytes())
for item in old['compile']:
    if item['tag'] != 'cast-test':
        name = item['tag']+'-identity.json'; (out/name).write_bytes((old_path.parent/name).read_bytes())
c.save(out/'summary.json', dict(passed=True, initial_host_TUs=3, initial_native_TUs=2,
    fixture_correction_host_TUs=1, SDK_build=False, GPU_run=False, Qwen_relinked=False))
c.save(S/'latest-check.json', dict(plan=str(path)))
print('FIXTURE_BUILD_COMPLETE', path, flush=True)
