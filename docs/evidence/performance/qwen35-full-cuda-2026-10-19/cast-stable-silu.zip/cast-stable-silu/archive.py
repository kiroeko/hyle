"""Archive the completed Cast/stable-SiLU batch; no build, GPU run or deletion."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cast-stable-silu.zip'
PREFIX = 'cast-stable-silu/'
spec = importlib.util.spec_from_file_location('conv_archive_helpers', ARCH/'conv-typed-load/archive.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
read, identity, check, save, digest = old.read, old.identity, old.check, old.save, old.digest
OMIT = old.OMIT | {'.raw', '.pt', '.safetensors', '.gguf', '.so', '.dylib'}
DOCS = ('docs/architecture/compute-design.md', 'docs/architecture/graph-design.md',
        'docs/user/graph.md', 'docs/developer/current-work.md',
        'docs/implementation/model-operators.md',
        'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md',
        'docs/evidence/research/conv-output-fusion-design-2026-10-20.json')


def eligible(path):
    parts = {x.lower() for x in path.relative_to(STAGE).parts}
    return (path.suffix.lower() not in OMIT and
            not parts.intersection({'tmp', '__pycache__', 'sdk', 'cache', 'trace'}) and
            path.name not in {'archive-receipt.json', 'archive-source-index.json',
                              'archive-scope.json', 'archive-support.json'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', type=Path,
        default=STAGE/'checks/20261019T180346-fixture-correction/plan.json')
    args = parser.parse_args(); plan_path = args.build_plan.resolve()
    assert plan_path.is_relative_to(STAGE/'checks')
    plan, plan_id = read(plan_path), identity(plan_path)
    production_path = Path(plan['fixture_correction']['prior_plan']['path'])
    check(plan['fixture_correction']['prior_plan'])
    production = read(production_path)
    initial, final = read(production_path.parent/'summary.json'), read(plan_path.parent/'summary.json')
    assert initial['passed'] and initial['host_TUs']==3 and initial['native_TUs']==2
    assert final['passed'] and final['fixture_correction_host_TUs']==1 and not final['Qwen_relinked']
    qwen = read(plan_path.parent/'qwen-image.json'); check(qwen)
    assert qwen == read(production_path.parent/'qwen-image.json')
    assert read(plan_path.parent/'qwen-link-plan.json') == read(production_path.parent/'qwen-link-plan.json')
    assert len(read(plan_path.parent/'qwen-link-plan.json')['inputs']) == 129
    tests = read(STAGE/'tests/summary.json'); check(tests['image'])
    cases = ET.parse(STAGE/'tests/results.xml').findall('.//testcase')
    names = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    assert tests['passed'] and tests['cases']==len(cases)==5 and tests['skipped']==0
    assert set(names)==set(read(STAGE/'tests-source-freeze.json')['tests'])
    assert all(not any(x.find(t) is not None for t in ('failure','error','skipped')) for x in cases)
    assert tests['build_plan']==plan_id and read(STAGE/'tests/cast.result.json')['exit']==0
    first = read(STAGE/'tests-first-failure/summary.json')
    assert not first['passed'] and first['cases']==5
    assert read(STAGE/'tests-first-failure/cast.result.json')['exit']==1
    correction = read(STAGE/'fixture-correction.json')
    check(correction['before_source']); check(correction['after_source'])

    model = read(STAGE/'correctness/summary.json'); observed = model['observation']
    assert model['passed'] and observed['equal_vectors']==len(observed['vectors'])==64
    assert observed['all_outputs_finite'] and observed['same_greedy_ids_as_reference']
    assert observed['same_fixed_decode_inputs'] and len(observed['generated_ids'])==32
    assert model['single_outer_range_32_phases'] and model['route']=='hybrid'
    assert observed['image']==qwen and read(STAGE/'correctness/inputs.json')['plan']==plan_id
    assert all(r['byte_equal'] and r['actual']['sha256']==r['reference']['sha256']
               and r['actual']['bytes']==r['reference']['bytes'] for r in observed['vectors'])
    perf, runs = read(STAGE/'performance-rotation/summary.json'), read(STAGE/'performance-rotation/runs.json')
    assert perf['terminal_zero']==len(runs)==9 and not perf['profiler']
    assert [r['arm'] for r in runs]==perf['order'] and all(r['exit']==0 for r in runs)
    profile = read(STAGE/'profile/summary.json')
    assert profile['passed'] and read(STAGE/'profile/analysis.json')['passed']
    assert read(STAGE/'profile/plan.json')['build_plan']==plan_id
    assert read(STAGE/'profile/plan.json')['image']==qwen
    for tag in ('profile','export','stats'):
        assert read(STAGE/'profile'/(tag+'.result.json'))['exit']==0
    for name in ('capture.nsys-rep','capture.sqlite','capture_cuda_gpu_kern_sum.csv'):
        assert (STAGE/'profile'/name).is_file()

    payloads, sources, owners, support = {}, [], [], set()
    def add(path, name):
        path = Path(path).resolve()
        assert path.is_file() and path.is_relative_to(ROOT), path
        assert name not in payloads or payloads[name]==path, name
        payloads[name] = path
    def add_source(row, name):
        check(row); add(row['path'], PREFIX+name); sources.append(row)

    native = read(STAGE/'native-source-freeze.json')
    assert len(native['files'])==3 and len(native['product_files'])==3
    for row in native['files'] + native['product_files']:
        for version in ('before','after'):
            add_source(row[version], version+'-source/'+row['path'])
    for freeze in ('host-source-freeze.json','tests-source-freeze.json'):
        for row in read(STAGE/freeze)['files']:
            rel = row.get('path',row.get('source'))
            if row.get('before') and row['before'].get('exists',True):
                add_source(row['before'],'before-source/'+rel)
            add_source(row['after'],'after-source/'+rel)
    headers = read(STAGE/'native-header-closure.json')['headers']
    assert len(headers)==89
    for row in headers: check(row, STAGE/'native-source'/row['path'])
    # Four product/native receipts are retained from the original production
    # build. The corrected test receipt is independent; do not invent a Qwen link.
    receipt_paths = {r['tag']:production_path.parent/(r['tag']+'-identity.json')
                     for r in production['compile'] if r['tag']!='cast-test'}
    receipt_paths['cast-test'] = plan_path.parent/'cast-test-identity.json'
    for tag, receipt_path in receipt_paths.items():
        record = read(receipt_path); check(record['source'])
        for row in [record['source'], *record['dependencies']]:
            path = Path(row['path']).resolve()
            if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('include','src','tests','third_party','cmake'):
                check(row); add(path, PREFIX+'dependency-source/'+path.relative_to(ROOT).as_posix())
        owners.append(dict(tag=tag, receipt=identity(receipt_path), source=record['source'], object=record['object']))
    for row in plan['frozen']:
        path = Path(row['path']).resolve()
        if path.suffix.lower() in OMIT: continue
        check(row)
        if not path.is_relative_to(STAGE) and not path.is_relative_to(ARCH/'cuda-fusion-precision/native-source'):
            support.add(path)
    # Only small literal helper imports are followed, never entire older stages.
    pending, seen = list(STAGE.rglob('*.py')), set()
    while pending:
        path = pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts: continue
        assert path.is_file() and path.is_relative_to(ROOT), path
        seen.add(path)
        for var, base in (('ARCH',ARCH),('STAGE',path.parent),('ROOT',ROOT)):
            pending += [base/value for value in re.findall(var+r"\s*/\s*['\"]([^'\"]+\.py)['\"]",path.read_text(encoding='utf-8'))]
        if not path.is_relative_to(STAGE): support.add(path)
    inputs = read(STAGE/'correctness/inputs.json')
    for key in ('manifest','prompt','decode'):
        check(inputs[key]); support.add(Path(inputs[key]['path']))
    # Raw64 paths and SHA identities are already in the actual comparison.
    # These existing receipts establish provenance without duplicating vectors.
    support.update(ROOT/p for p in DOCS)
    support.update(ARCH/p for p in ('binding-port-reuse/archive-receipt.json',
        'conv-typed-load/archive-receipt.json','batch-graph-capture/archive-receipt.json'))
    support.add(ROOT/'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
    for path in sorted(support):
        assert path.suffix.lower() not in OMIT
        add(path, PREFIX+'support/'+path.resolve().relative_to(ROOT).as_posix())
    for path in STAGE.rglob('*'):
        if path.is_file() and eligible(path): add(path,PREFIX+path.relative_to(STAGE).as_posix())
    scope = dict(source_id=native['source_id'], production_plan=identity(production_path),
        final_plan=plan_id, initial_host_TUs=3, initial_native_TUs=2, additional_fixture_host_TUs=1,
        Qwen_relinked_for_fixture=False, owners=owners, native_headers=89, sources=sources,
        first_test_run='5 failures from treating output() borrowed ConstTensorView as a result lease; numerical/provider/route checks did not fail.',
        result_contract='result() GraphOutput holds the result count and still blocks reset. The fixture covers output() borrowed old view plus caller-owned backing bytes; no GraphOutput exception is asserted.',
        final_tests=names,equal_vectors=64,unprofiled_processes=9,physical_observations=profile,
        limits='Fixed-tape and directed CUDA regression, not independent quality or statistically stable speed proof. Profile duration is not unprofiled throughput.',
        excluded='SDK/model/binary/object/debug/tmp/cache and duplicate64 raw tensors; exact vector SHA/path comparisons remain.',cleanup_executed=False)
    scope_bytes = (json.dumps(scope,ensure_ascii=False,indent=2)+'\n').encode()
    manifest = {name:identity(path) for name,path in sorted(payloads.items())}
    manifest_bytes = (json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(payloads.items()): archive.write(path,name)
        archive.writestr('archive-scope.json',scope_bytes)
        archive.writestr('payload-sha256.json',manifest_bytes)
    expected = {name:r['sha256'] for name,r in manifest.items()}
    expected.update({'archive-scope.json':digest(scope_bytes),'payload-sha256.json':digest(manifest_bytes)})
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist())==len(expected)
        for info in archive.infolist():
            h,crc,size = hashlib.sha256(),0,0
            with archive.open(info) as stream:
                while chunk := stream.read(1024*1024):
                    h.update(chunk);crc=zlib.crc32(chunk,crc);size+=len(chunk)
            assert size==info.file_size and crc&0xffffffff==info.CRC,info.filename
            assert h.hexdigest()==expected[info.filename],info.filename
    receipt = dict(**identity(DEST),entries=len(expected),payloads=len(manifest),
        crc_verified=True,payload_sha256_verified=True,verification_passes=1,
        build_plan=plan_id,production_plan=identity(production_path),source_id=native['source_id'],
        initial_host_TUs=3,native_TUs=2,fixture_host_TUs=1,tests=5,equal_vectors=64,
        unprofiled_processes=9,physical_expectations_met=profile.get('physical_expectations_met'),
        duplicate_raw_vectors_omitted=True,cleanup_executed=False)
    save(STAGE/'archive-receipt.json',receipt)
    save(DEST.with_name('cast-stable-silu-archive.json'),receipt)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


if __name__ == '__main__': main()
