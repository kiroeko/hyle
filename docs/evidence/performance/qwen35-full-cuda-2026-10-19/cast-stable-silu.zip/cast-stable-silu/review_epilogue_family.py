"""Offline same-stream Conv epilogue pairing; never a throughput comparison."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sqlite3
import statistics

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def conv(name):
    return bool(re.search(r'\bssm_conv_f32<', name))


def narrow(name):
    return bool(re.search(r'\bcpy_scalar_contiguous<float,\s*__nv_bfloat16>', name))


def old_activation(name):
    return ('sglang_vendor::act_kernel<__nv_bfloat16,' in name and
            '(hyle::compute::cuda_native::sglang_vendor::ActivationKind)0' in name)


def fused(name):
    return bool(re.search(r'\bhyle_cast_stable_silu\s*\(', name))


def review(stage, current):
    database = stage / 'profile/capture.sqlite'
    con = sqlite3.connect('file:' + database.resolve().as_posix() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    strings = dict(con.execute('SELECT id,value FROM StringIds'))
    kernels = []
    for record in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start'):
        row = dict(record)
        kernels.append(dict(start=row['start'], end=row['end'], ns=row['end']-row['start'],
            name=strings[row['demangledName']], device=row['deviceId'], context=row['contextId'],
            stream=row['streamId'], pid=row['globalPid'], graphNodeId=row['graphNodeId']))
    tokens = [dict(row) for row in con.execute('SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY end')
              if row['copyKind'] == 2 and row['bytes'] == 4]
    con.close()
    assert len(tokens) == 32 and len({row['end'] for row in tokens}) == 32
    phases, d7_pairs, unmatched = [], [], []
    for phase in range(7, 32):
        lo, hi = tokens[phase-1]['end'], tokens[phase]['end']
        selected = [row for row in kernels if lo < row['start'] and row['end'] <= hi]
        assert not any(row['start'] < hi and row['end'] > lo and row not in selected for row in kernels)
        streams = collections.defaultdict(list)
        for row in selected:
            streams[(row['pid'],row['device'],row['context'],row['stream'])].append(row)
        pairs = []
        for key, ordered in streams.items():
            for index, first in enumerate(ordered):
                if not conv(first['name']):
                    continue
                following = ordered[index+1:index+(2 if current else 3)]
                valid = (len(following) == (1 if current else 2) and
                         (fused(following[0]['name']) if current else
                          narrow(following[0]['name']) and old_activation(following[1]['name'])) and
                         first['end'] <= following[0]['start'] and
                         all(x['end'] <= y['start'] for x,y in zip(following,following[1:])))
                if not valid:
                    unmatched.append(dict(phase=phase, conv=first, following=following))
                    continue
                pairs.append(dict(conv=first, epilogue=following,
                    conv_ns=first['ns'], epilogue_gpu_ns=sum(row['ns'] for row in following),
                    post_conv_span_ns=following[-1]['end']-first['end'],
                    epilogue_gap_ns=following[-1]['end']-first['end']-sum(row['ns'] for row in following)))
        conv_ns = sum(row['conv_ns'] for row in pairs)
        epilogue_ns = sum(row['epilogue_gpu_ns'] for row in pairs)
        phases.append(dict(phase=phase, kernels=len(selected), paired_convs=len(pairs),
            all_conv_kernels=sum(conv(row['name']) for row in selected),
            all_narrow_kernels=sum(narrow(row['name']) for row in selected),
            all_original_BF16_SGLang_SiLU=sum(old_activation(row['name']) for row in selected),
            all_new_fused_epilogues=sum(fused(row['name']) for row in selected),
            conv_gpu_us=conv_ns/1000, epilogue_gpu_us=epilogue_ns/1000,
            narrow_gpu_us=sum(row['ns'] for pair in pairs for row in pair['epilogue'] if narrow(row['name']))/1000,
            original_silu_gpu_us=sum(row['ns'] for pair in pairs for row in pair['epilogue'] if old_activation(row['name']))/1000,
            post_conv_span_us=sum(row['post_conv_span_ns'] for row in pairs)/1000,
            post_conv_gap_us=sum(row['epilogue_gap_ns'] for row in pairs)/1000,
            all_kernel_gpu_us=sum(row['ns'] for row in selected)/1000,
            other_kernel_gpu_us=(sum(row['ns'] for row in selected)-conv_ns-epilogue_ns)/1000))
        if phase == 7:
            d7_pairs = pairs
    fields = ('epilogue_gpu_us','narrow_gpu_us','original_silu_gpu_us','conv_gpu_us',
              'post_conv_span_us','post_conv_gap_us','all_kernel_gpu_us','other_kernel_gpu_us')
    return dict(database=identity(database), analysis=identity(stage/'profile/analysis.json'),
        complete_pairing=not unmatched and all(row['paired_convs']==row['all_conv_kernels']==18 for row in phases),
        phases=phases, decode7_pairs=d7_pairs, unmatched=unmatched,
        per_phase_sum_us={field:dict(median=statistics.median(row[field] for row in phases),
            min=min(row[field] for row in phases),max=max(row[field] for row in phases)) for field in fields},
        pair_count=sum(row['paired_convs'] for row in phases))


def main():
    old, new = review(ARCH/'conv-typed-load',False), review(STAGE,True)
    complete = old['complete_pairing'] and new['complete_pairing']
    old_us = old['per_phase_sum_us']['epilogue_gpu_us']['median']
    new_us = new['per_phase_sum_us']['epilogue_gpu_us']['median']
    report = dict(status='offline_existing_traces_only', adequate_family_separation=complete,
        method='Decode7..31 use actual32 token4B D2H end anchors. Within each phase, pair Conv with the immediately following kernel(s) on identical pid/device/context/stream, checking source-specific names and nonoverlapping timestamp order.',
        source_order_evidence=['tools/qwen35_text/main.cc:364-366: Conv F32 -> explicit Cast BF16 -> ordinary SiLU.',
            'third_party/sglang_activation/activation.cuh:98-135: original ordinary BF16 stable activation, distinct from packed GLU.',
            'cast-stable-silu/native-source-freeze.json and native-source/src/ggml-cuda/unary.cu: new F32 input -> BF16RNE -> widen -> same stable helper -> BF16RNE.'],
        baseline=old,current=new,
        observed_comparison=dict(baseline_18_narrow_plus_18_SiLU_per_phase_median_gpu_us=old_us,
            current_18_fused_per_phase_median_gpu_us=new_us,
            current_minus_baseline_us=new_us-old_us,
            narrow_savings_scope='Only the18 casts immediately after the18 Conv kernels; the other36 of the old54 narrow casts are excluded.',
            conv_median_us_old=old['per_phase_sum_us']['conv_gpu_us']['median'],
            conv_median_us_new=new['per_phase_sum_us']['conv_gpu_us']['median'],
            other_kernels_median_us_old=old['per_phase_sum_us']['other_kernel_gpu_us']['median'],
            other_kernels_median_us_new=new['per_phase_sum_us']['other_kernel_gpu_us']['median']),
        inference=('New fused family does not show a larger median GPU duration sum than the replaced pair family in these traces.' if new_us<=old_us else
            'New fused family shows a larger median GPU duration sum than the replaced pair family in these traces; this alone is not throughput causality.'),
        limits=['One separate all-API profiled process per image, not paired unprofiled timing or a causal throughput comparison.',
            'Source role and same-stream immediate temporal ordering support family separation; Nsight does not expose actual tensor pointers/dataflow or every compiler rounding operation.',
            'Durations are GPU activity sums. Post-Conv spans include gaps and are reported separately; sums are not wall-time attribution.',
            'No new GPU, profiler, compilation, assembly or hardware counter collection. Other-family duration shifts may reflect independent profile windows and cannot be blamed on this epilogue.'],
        script=identity(Path(__file__)),new_GPU_processes=0,throughput_claim=False)
    path=STAGE/'profile/epilogue-family-review.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(path=str(path),adequate_family_separation=complete,
        baseline_us=old_us,current_us=new_us,delta_us=new_us-old_us,
        old_pairs=old['pair_count'],new_pairs=new['pair_count'])))


if __name__ == '__main__':
    main()
