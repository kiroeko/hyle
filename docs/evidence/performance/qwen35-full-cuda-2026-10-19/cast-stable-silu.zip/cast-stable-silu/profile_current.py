"""Prepare, or explicitly collect one production-image CUDA/API trace."""
from pathlib import Path
import argparse
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
OUT = STAGE / 'profile'
NATIVE_FREEZE = STAGE / 'native-source-freeze.json'
RETAINED_NATIVE_FREEZE = ARCH / 'gdn-typed-load/native-source-freeze.json'
RETAINED_GDN_OWNER = ARCH / 'gdn-typed-load/checks/20261019T163125/native-gdn-identity.json'
BASELINE_ANALYSIS = ARCH / 'conv-typed-load/profile/analysis.json'
RETAINED_CONV_FREEZE = ARCH / 'conv-typed-load/native-source-freeze.json'
RETAINED_CONV_OWNER = ARCH / 'conv-typed-load/checks/20261019T171411/native-conv-identity.json'
EXPECTED_NATIVE_ID = 'e2d446afee1c93d5'
PRODUCTION_BUILD_PLAN = STAGE / 'checks/20261019T180121/plan.json'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_current(b, c, plan_path):
    plan = c.read(plan_path)
    summary = c.read(plan_path.parent / 'summary.json')
    if not summary['passed']:
        raise ValueError('Successful current final build required')
    # A test-fixture-only amendment need not recompile or relink production.
    # Read actual successful production-owner receipts, not the old mutable
    # test-freeze checks embedded in its historical build helper.
    production = c.read(PRODUCTION_BUILD_PLAN)
    production_summary = c.read(PRODUCTION_BUILD_PLAN.parent / 'summary.json')
    if (not production_summary['passed'] or production_summary['host_TUs'] != 3
            or production_summary['native_TUs'] != 2):
        raise ValueError('Original successful three-host/two-native production build required')
    if c.key(c.read(STAGE / 'latest-check.json')['plan']) != c.key(plan_path):
        raise ValueError('Expected this stage latest build')
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Current build identity changed: ' + row['path'])
    for freeze_path in (STAGE / 'host-source-freeze.json', STAGE / 'tests-source-freeze.json'):
        for row in c.read(freeze_path)['files']:
            name = row.get('path', row.get('source'))
            expected = row['after']
            actual = b.identity(ROOT / name)
            if any(actual[key] != expected[key] for key in ('bytes', 'sha256')):
                raise ValueError('Current product differs from its freeze: ' + name)
    native = c.read(NATIVE_FREEZE)
    if native['source_id'] != EXPECTED_NATIVE_ID:
        raise ValueError('Expected current v25 native identity')
    if {row['path'] for row in native['files']} != {
            'src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/unary.cu', 'src/ggml-cuda/unary.cuh'}:
        raise ValueError('Expected exact main/strict-unary/header native set')
    for row in native['files']:
        if not b.same(row['after']):
            raise ValueError('Current native source changed: ' + row['path'])
    for row in native['product_files']:
        if not b.same(row['after']):
            raise ValueError('Applied native product identity changed: ' + row['path'])
    header_closure = c.read(STAGE / 'native-header-closure.json')
    if len(header_closure['headers']) != 89:
        raise ValueError('Expected coherent 89-header closure')
    for row in header_closure['headers']:
        actual = b.identity(STAGE / 'native-source' / row['path'])
        if any(actual[key] != row[key] for key in ('bytes','sha256')):
            raise ValueError('Native header identity changed: ' + row['path'])
    link = c.read(plan_path.parent / 'qwen-link-plan.json')
    image = c.read(plan_path.parent / 'qwen-image.json')
    if not b.same(image):
        raise ValueError('Current production Qwen image changed')
    compiled = {row['tag']:row for row in production['compile']}
    for tag in ('provider', 'adapter'):
        row = compiled[tag]
        owner = c.read(PRODUCTION_BUILD_PLAN.parent / (tag + '-identity.json'))
        if (not b.same(owner['source']) or owner['source'] != row['source']
                or owner['object'] not in link['inputs'] or not b.same(owner['object'])):
            raise ValueError('Current Qwen link omitted an unchanged fresh production host owner: ' + tag)
    for tag, name in [('native-main','ggml-cuda.cu'),('native-unary','unary.cu')]:
        row = compiled[tag]
        expected = next(value['after'] for value in native['files'] if value['path'].endswith('/'+name))
        owner = c.read(PRODUCTION_BUILD_PLAN.parent / (tag + '-identity.json'))
        if row['source'] != expected or owner['source'] != expected:
            raise ValueError('Fresh native owner source differs: ' + tag)
        if owner['command'] != row['command'] or owner['object'] not in link['inputs'] or not b.same(owner['object']):
            raise ValueError('Current Qwen link omitted a fresh native owner: ' + tag)
        include_roots = [Path(arg[2:]) for arg in row['command'] if arg.startswith('-I')]
        for header_name in ('common.cuh','unary.cuh','gated_delta_net.cuh','ssm-conv.cuh'):
            effective = next((root / header_name for root in include_roots if (root / header_name).is_file()),None)
            frozen = next(value for value in header_closure['headers'] if value['path'].endswith('/'+header_name))
            if effective is None or any(b.identity(effective)[key] != frozen[key] for key in ('bytes','sha256')):
                raise ValueError('Effective native header is not the current coherent closure: ' + header_name)
    unary_command = compiled['native-unary']['command']
    unsafe = [arg for arg in unary_command if 'use_fast_math' in arg or any(
        flag in arg.lower() for flag in ('ftz=true','ftz=1','prec-div=false','prec-div=0','prec-sqrt=false','prec-sqrt=0'))]
    if unsafe:
        raise ValueError('Strict unary compilation domain changed: ' + repr(unsafe))
    provider_version = STAGE / 'provider-version.h'
    if EXPECTED_NATIVE_ID not in provider_version.read_text() or not any(
            str(provider_version).lower() in arg.lower() for arg in compiled['provider']['command']):
        raise ValueError('Fresh provider command lacks current forced native version')
    for freeze_path, owner_path, names in (
            (RETAINED_NATIVE_FREEZE, RETAINED_GDN_OWNER, ('gated_delta_net.cu','gated_delta_net.cuh')),
            (RETAINED_CONV_FREEZE, RETAINED_CONV_OWNER, ('ssm-conv.cu','ssm-conv.cuh'))):
        retained = {row['path']:row['after'] for row in c.read(freeze_path)['files'] if Path(row['path']).name in names}
        if len(retained) != 2 or not all(b.same(row) for row in retained.values()):
            raise ValueError('Retained typed GDN/Conv source identity differs')
        original_cu = next(row for path,row in retained.items() if path.endswith('.cu'))
        owner = c.read(owner_path)
        if owner['source'] != original_cu or owner['object'] not in link['inputs'] or not b.same(owner['object']):
            raise ValueError('Current production link omitted a retained typed GDN/Conv owner')
    tests = c.read(STAGE / 'tests/summary.json')
    if not tests['passed'] or tests['cases'] != 5 or tests['skipped'] != 0:
        raise ValueError('Current five exact Cast/stable-SiLU cases without skips required')
    cases = ET.parse(STAGE / 'tests/results.xml').findall('.//testcase')
    actual = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
    required = c.read(STAGE / 'tests-source-freeze.json')['tests']
    if (len(actual) != tests['cases'] or len(set(actual)) != len(actual)
            or set(actual) != set(tests['names']) or set(actual) != set(tests['exact_filters'])
            or set(actual) != set(required)
            or any(row.find(tag) is not None for row in cases for tag in ('failure','error','skipped'))):
        raise ValueError('Current XML disagrees with exact successful test summary')
    if (tests['build_plan'] != b.identity(plan_path) or not b.same(tests['image'])
            or tests['image'] != c.read(plan_path.parent / 'cast-image.json')):
        raise ValueError('CUDA tests used a different plan or image')
    correctness = c.read(STAGE / 'correctness/summary.json')
    observed = correctness['observation']
    if (not correctness['passed'] or observed['equal_vectors'] != 64
            or not observed['all_outputs_finite'] or observed['image'] != image):
        raise ValueError('Current fixed-input 64-exact model regression required')
    return plan


def prepare(b, c, plan_path):
    if (OUT / 'plan.json').exists():
        raise ValueError('Refuse to overwrite trace plan')
    plan = verify_current(b, c, plan_path)
    rotation_path = STAGE / 'performance-prepared/plan.json'
    rotation = c.read(rotation_path)
    request = next(row for row in rotation['requests'] if row['arm'] == 'current')
    if rotation['build_plan'] != b.identity(plan_path):
        raise ValueError('Current fixed-input plan belongs to another build')
    command = request['command'].copy()
    image = c.read(plan_path.parent / 'qwen-image.json')
    if b.identity(command[0]) != image or rotation['images']['current'] != image:
        raise ValueError('Exact production image differs')
    if '--trace' in command or '--trace-level' in command:
        raise ValueError('No tensor dumps in this physical trace')
    assert command[command.index('--steps') + 1] == '32'
    assert command[command.index('--capacity') + 1] == '256'
    assert len(rotation['fixed']['prompt_ids']) == 128 and len(rotation['fixed']['decode_input_ids']) == 31
    prompt_path = Path(command[command.index('--inputs') + 1]) / 'prompt.ids'
    decode_path = Path(command[command.index('--decode-ids') + 1])
    if (list(map(int,prompt_path.read_text().split())) != rotation['fixed']['prompt_ids'] or
            list(map(int,decode_path.read_text().split())) != rotation['fixed']['decode_input_ids']):
        raise ValueError('Actual prompt128 or fixed decode31 tape differs')
    if command[command.index('--replay')+1] != 'prefer-capture':
        raise ValueError('Expected the production capture preference')
    nsys = c.read(ARCH / 'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0]
    stem = OUT / 'capture'
    commands = dict(
        profile=[nsys, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-trace-all-apis=true', '--cuda-graph-trace=node:host-only',
            '--discard-environment=true', '--output=' + str(stem), *command],
        export=[nsys, 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        stats=[nsys, 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum,cuda_gpu_mem_time_sum,cuda_gpu_mem_size_sum',
               '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'])
    OUT.mkdir(exist_ok=False)
    (OUT / 'tmp').mkdir()
    c.save(OUT / 'plan.json', dict(status='prepared_not_run', build_plan=b.identity(plan_path),
        runner=b.identity(Path(__file__)), analyzer=b.identity(STAGE / 'analyze_profile.py'),
        production_build_plan=b.identity(PRODUCTION_BUILD_PLAN),
        production_owner_receipts=[b.identity(PRODUCTION_BUILD_PLAN.parent / (tag + '-identity.json'))
            for tag in ('native-main','native-unary','provider','adapter')],
        image=image, link_plan=b.identity(plan_path.parent / 'qwen-link-plan.json'),
        current_freezes=[b.identity(STAGE / 'host-source-freeze.json'), b.identity(NATIVE_FREEZE),
                         b.identity(STAGE / 'native-header-closure.json'), b.identity(STAGE / 'tests-source-freeze.json')],
        retained_native_freeze=b.identity(RETAINED_NATIVE_FREEZE),
        retained_GDN_owner=b.identity(RETAINED_GDN_OWNER), retained_Conv_owner=b.identity(RETAINED_CONV_OWNER),
        retained_Conv_freeze=b.identity(RETAINED_CONV_FREEZE), baseline_analysis=b.identity(BASELINE_ANALYSIS),
        native_source_id=c.read(NATIVE_FREEZE)['source_id'],
        test_summary=b.identity(STAGE / 'tests/summary.json'),
        test_XML=b.identity(STAGE / 'tests/results.xml'),
        correctness_summary=b.identity(STAGE / 'correctness/summary.json'),
        retained_input_plan=b.identity(rotation_path), fixed_input_identities=[b.identity(prompt_path),b.identity(decode_path)],
        strict_unary_command=next(row['command'] for row in c.read(PRODUCTION_BUILD_PLAN)['compile'] if row['tag']=='native-unary'),
        fixed=rotation['fixed'], source_id=rotation['source_id'],
        expected_generated_ids=c.read(STAGE / 'correctness/summary.json')['observation']['generated_ids'],
        commands=commands, consumer_command=command, GPU_model_processes_planned=1,
        baseline_reprofiled=False, baseline_launch_count_reference=668,
        expected_not_asserted=dict(decode7_kernels=650, BF16_to_F32=55, F32_to_BF16=36,
            CastStableSiLU=18,
            transpose_F32=0, Conv=18, Conv_BF16=18, GDN=18, GDN_V_BF16_beta_BF16=18,
            RMS_unscaled_BF16_BF16=18),
        tensor_dumps=False, all_CUDA_APIs=True, compilations=0, links=0, throughput_claim=False,
        timed_rotation_required_before_collection=False,
        limits='One current trace, all-API profiling perturbs timing. Physical instantiations/counts only; source/IDs and existing64vector proof are separate. No inferred CPU attribution from unmarked gaps.'))
    print('PROFILE_PREPARED_NO_GPU', OUT / 'plan.json', flush=True)


def run(b, c, plan_path):
    if not (OUT / 'plan.json').exists():
        prepare(b, c, plan_path)
    current = verify_current(b, c, plan_path)
    plan = c.read(OUT / 'plan.json')
    assert plan['build_plan'] == b.identity(plan_path)
    for row in [plan['runner'], plan['analyzer'], plan['image'], plan['link_plan'],
                plan['production_build_plan'], *plan['production_owner_receipts'],
                plan['retained_native_freeze'], plan['retained_GDN_owner'], plan['retained_Conv_freeze'],
                plan['retained_Conv_owner'], plan['baseline_analysis'], *plan['fixed_input_identities'],
                plan['retained_input_plan'],
                plan['test_summary'], plan['test_XML'], plan['correctness_summary'],
                *plan['current_freezes']]:
        if not b.same(row):
            raise ValueError('Prepared trace identity changed: ' + row['path'])
    link = c.read(Path(plan['link_plan']['path']))
    paths = [row['path'] if isinstance(row, dict) else row for row in link['inputs']]
    env, runtime = b.environment(link['command'], paths, OUT)
    forbidden = ('GGML_CUDA_DISABLE_GRAPHS', 'GGML_CUDA_DISABLE_FUSION', 'GGML_CUDA_GRAPH_OPT',
                 'HYLE_RMS_DIAG', 'HYLE_GDN_L2_DIAG')
    if any(key in env for key in forbidden):
        raise ValueError('Non-production graph/diagnostic override')
    c.save(OUT / 'runtime.json', dict(runtime_library_directories_from_own_link=runtime,
        link_input_count=len(paths), unrelated_CPU_or_peer_DLL_union_used=False,
        CUDA_MODULE_LOADING=env.get('CUDA_MODULE_LOADING'), forbidden_overrides_absent=list(forbidden)))
    for tag, command in plan['commands'].items():
        if (OUT / (tag + '.command.json')).exists() or (OUT / (tag + '.result.json')).exists():
            raise ValueError('No implicit profile/export/stats retry: ' + tag)
        c.execute(tag, command, env, OUT)
    c.save(OUT / 'collection-summary.json', dict(passed=True, fresh_model_processes=1,
        profile_exit=c.read(OUT / 'profile.result.json')['exit'],
        export_exit=c.read(OUT / 'export.result.json')['exit'],
        stats_exit=c.read(OUT / 'stats.result.json')['exit'], throughput_claim=False))
    load('cast_silu_physical_analysis', STAGE / 'analyze_profile.py').analyze()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan', type=Path)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--analyze', action='store_true')
    args = parser.parse_args()
    if args.run and args.analyze:
        raise ValueError('Choose collection or offline analysis')
    if args.analyze:
        load('cast_silu_physical_analysis', STAGE / 'analyze_profile.py').analyze()
    else:
        h = load('cast_silu_profile_build_helpers', STAGE / 'build.py')
        run(h.b, h.c, args.plan.resolve()) if args.run else prepare(h.b, h.c, args.plan.resolve())
