"""Apply the reviewed Cast/stable-SiLU native patch, without building code."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
VENDOR = ROOT / 'third_party/ggml_cuda_runtime'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def replay(row, check_after=True):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256'], row['path']
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, row['path']
        data = data.replace(before, after, 1)
    if check_after:
        assert sha(data) == row['after_sha256'], row['path']
    return data


def tree(root):
    # Same portable relative-path order and newline normalization as the lock.
    lines = []
    for path in sorted(root.rglob('*'), key=lambda p: p.relative_to(root).as_posix()):
        assert not path.is_symlink()
        if path.is_file():
            data = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
            lines.append(path.relative_to(root).as_posix() + '|' + sha(data) + '\n')
    return sha(''.join(lines).encode())


def main():
    draft_freeze = read(STAGE / 'native-source-freeze.json')
    assert draft_freeze['status'] == 'scratch_draft_not_applied'
    assert not (STAGE / 'native-application.json').exists(), 'Do not reseal this applied batch'
    # Fail before product mutation if any recorded input or reviewed source moved.
    for record in draft_freeze['baseline']['inputs']:
        assert sha((ROOT / record['path']).read_bytes()) == record['sha256'], record['path']
        assert sha(Path(record['snapshot']).read_bytes()) == record['sha256'], record['snapshot']
    for record in draft_freeze['files']:
        for side in ['before', 'after']:
            assert identity(record[side]['path']) == record[side], record['path']
    original = STAGE / 'native-before'
    before_combined = read(STAGE / 'before-combined.json')
    before_sources = {row['path']: replay(row) for row in before_combined['files']}
    for record in draft_freeze['files']:
        name = record['path']
        data = before_sources.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        assert sha(data) == record['before']['sha256'], name
    product_paths = [VENDOR / 'patches.json', VENDOR / 'NOTICE.md', ROOT / 'cmake/HyleDependencyLock.json']
    old_lock = read(product_paths[2])
    selected = next(row for row in old_lock['dependencies'] if row['name'] == 'ggml_cuda_runtime_patches')
    assert selected['version'] == 'hyle-ggml-cuda-resource-iq1-inference-v24'
    assert tree(VENDOR) == selected['vendored']['tree_sha256']
    notice_record = next(row for row in selected['license']['files'] if row['path'].endswith('/NOTICE.md'))
    assert sha(product_paths[1].read_bytes()) == notice_record['sha256']
    product_before = {}
    for path in product_paths:
        relative = path.relative_to(ROOT)
        snapshot = original / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists():
            assert snapshot.read_bytes() == path.read_bytes(), str(relative)
        else:
            snapshot.write_bytes(path.read_bytes())
        product_before[relative.as_posix()] = identity(snapshot)
    # Keep the exact reviewed draft receipts as distinct pre-application history.
    for name in ['native-source-freeze.json', 'native-review.json']:
        target = STAGE / name.replace('native-', 'native-draft-', 1)
        if target.exists():
            assert target.read_bytes() == (STAGE / name).read_bytes()
        else:
            target.write_bytes((STAGE / name).read_bytes())
    draft = read(product_paths[0])
    changes = read(STAGE / 'native-overlay/replacements.json')['files']
    for change in changes:
        row = next((row for row in draft['files'] if row['path'] == change['path']), None)
        if row is None:
            row = dict(path=change['path'], before_sha256=sha((UPSTREAM / change['path']).read_bytes().replace(b'\r\n', b'\n')), edits=[])
            draft['files'].append(row)
        row['edits'].extend(change['edits'])
        row['after_sha256'] = sha(replay(row, False))
    proposed = STAGE / 'native-patches.proposed.json'
    save(proposed, draft)
    combined = STAGE / 'combined-manifest.json'
    load('cast_silu_seal_composer', original / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').derive(
        UPSTREAM, STAGE / 'mixed-cpu-manifest.json', proposed,
        original / 'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    replayed = {row['path']: replay(row) for row in read(combined)['files']}
    changed_names = {row['path'] for row in changes}
    # A previously unpatched upstream header acquires a manifest row here.
    # Existing rows must all remain; added rows must be reviewed changes.
    assert set(before_sources) <= set(replayed)
    assert set(replayed) - set(before_sources) <= changed_names
    for name, data in replayed.items():
        if name not in changed_names:
            assert data == before_sources[name], 'Unrelated combined source changed: ' + name
    for change in changes:
        target = (STAGE / 'native-overlay/source' / change['path']).read_bytes()
        assert sha(target) == change['after_sha256'] and replayed[change['path']] == target
        native = STAGE / 'native-source' / change['path']
        native.parent.mkdir(parents=True, exist_ok=True)
        native.write_bytes(target)
    # Exactly the established coherent header closure; never copy a cached SDK.
    previous_closure = STAGE.parent / 'conv-typed-load/native-header-closure.json'
    headers = []
    for record in read(previous_closure)['headers']:
        name = record['path']
        data = replayed.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        if name not in changed_names:
            assert sha(data) == record['sha256'], 'Unrelated header changed: ' + name
        target = STAGE / 'native-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        headers.append(dict(path=name, bytes=len(data), sha256=sha(data)))
    assert len(headers) == 89
    retained = []
    for batch, names in [('gdn-typed-load', ['gated_delta_net.cu', 'gated_delta_net.cuh']),
                         ('conv-typed-load', ['ssm-conv.cu', 'ssm-conv.cuh'])]:
        original_freeze = STAGE.parent / batch / 'native-source-freeze.json'
        for record in read(original_freeze)['files']:
            if Path(record['path']).name in names:
                assert sha(replayed[record['path']]) == record['after']['sha256']
                retained.append(dict(path=record['path'], sha256=record['after']['sha256'], origin=identity(original_freeze)))
    assert len(retained) == 4
    save(STAGE / 'native-header-closure.json', dict(headers=headers, header_count=89,
        total_header_bytes=sum(row['bytes'] for row in headers),
        selected_dependency_list_origin=identity(previous_closure), retained_GDN_v23_SSM_v24=retained,
        only_changed_header='src/ggml-cuda/unary.cuh', shared_by_value_struct_changed=False, SDK_modified=False))
    notice = product_paths[1].read_text(encoding='utf-8').rstrip() + '''

A private F32-to-BF16 Cast followed by marked ordinary stable BF16 SiLU can
execute as one kernel in the existing strict unary compilation unit. It first
performs the original BF16 round-to-nearest-even, widens that rounded value,
calls the existing stable ordinary SiLU helper, then performs the final BF16
round-to-nearest-even. The original convolution math and F32 materialization
remain unchanged. Cold qualification preserves CPY destination self-reference,
private actual readers, published values and escaping view/OP_NONE aliases.
The actual F32 source read is retained through the fused terminal using the
existing allocation-only dependency mechanism. Encoding checks real CUDA
owners, device, capacity, alignment, launch limits and disjoint input/output
ranges. Existing private main launch caps are named for their shared purpose;
no shared device-info or other by-value structure changes. General Cast,
Unary, GDN, SSM and old marked-SiLU exclusion behavior remain intact.
No public operation, model-specific admission, extra executor or precision
policy is introduced. This source change alone is not an executed numeric,
artifact, full-model or throughput result.
'''
    # Product scope: two selected vendored files and only its lock record.
    product_paths[0].write_bytes(proposed.read_bytes())
    product_paths[1].write_text(notice, encoding='utf-8', newline='\n')
    lock = read(product_paths[2])
    cuda = next(row for row in lock['dependencies'] if row['name'] == 'ggml_cuda_runtime_patches')
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v25'
    cuda['vendored']['tree_sha256'] = tree(VENDOR)
    for record in cuda['license']['files']:
        if record['root'] == 'hyle' and record['path'] == 'third_party/ggml_cuda_runtime/NOTICE.md':
            record['sha256'] = sha(product_paths[1].read_bytes())
    assert [row for row in lock['dependencies'] if row['name'] != cuda['name']] == [
        row for row in old_lock['dependencies'] if row['name'] != cuda['name']]
    assert {k:v for k,v in lock.items() if k != 'dependencies'} == {k:v for k,v in old_lock.items() if k != 'dependencies'}
    save(product_paths[2], lock)
    entries = {row['name']: row for row in lock['dependencies']}
    source_identity = (entries['ggml_runtime_patches']['vendored']['tree_sha256'] +
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) +
        cuda['vendored']['tree_sha256'])
    source_id = sha(source_identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    products = [dict(path=path.relative_to(ROOT).as_posix(),before=product_before[path.relative_to(ROOT).as_posix()],after=identity(path)) for path in product_paths]
    sources = [dict(path=row['path'], before=identity(original / row['path']), after=identity(STAGE / 'native-source' / row['path'])) for row in changes]
    save(STAGE / 'native-source-freeze.json', dict(version=cuda['version'], source_id=source_id,
        vendor_tree_sha256=cuda['vendored']['tree_sha256'], files=sources, product_files=products,
        sources={row['path']:row['after']['sha256'] for row in sources},
        all_mixed_CPU_IQ1_CUDA_edits_replayed=True, all_other_replayed_sources_unchanged=True,
        shared_by_value_struct_changed=False, native_TUs_requiring_refresh=['ggml-cuda.cu','unary.cu'],
        private_header='unary.cuh declarations only; existing inline/device/by-value math is unchanged',
        retained_GDN_v23_SSM_v24=retained, SDK_modified=False, compile_run=False, GPU_run=False))
    save(STAGE / 'native-application.json', dict(applied=products, source_id=source_id, native_sources=sources,
        all_baseline_inputs_verified=True, all_other_dependency_entries_unchanged=True,
        all_other_replayed_sources_unchanged=True, sglang_untouched=True, SDK_modified=False, compile_run=False, GPU_run=False))
    save(STAGE / 'native-seal.json', dict(source_id=source_id, source_freeze=identity(STAGE/'native-source-freeze.json'),
        header_closure=identity(STAGE/'native-header-closure.json'), application=identity(STAGE/'native-application.json'),
        baseline_draft=identity(STAGE/'native-draft-source-freeze.json'), replacements=identity(STAGE/'native-overlay/replacements.json'),
        combined_manifest=identity(combined), replayed_files=len(replayed), changed_native_files=sorted(changed_names),
        actual_build_or_GPU_validation=False))
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT/'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED_NATIVE_V25', source_id)


if __name__ == '__main__':
    main()
