"""Write exact archived-file cleanup to root test.ps1; never deletes."""
from pathlib import Path
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))


def identity(path):
    path=path.resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def check(row,path=None):
    actual=identity(path or Path(row['path']))
    assert all(actual[k]==row[k] for k in ('bytes','sha256')),(row,actual)
    return actual


out=STAGE/'checks/20261019T180346-fixture-correction'
dest=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
evidence=[]
for name in ('binding-port-reuse','cast-stable-silu'):
    record=read(dest/(name+'-archive.json'))
    assert record['crc_verified'] and record['payload_sha256_verified']
    check(record)
    evidence += [identity(dest/(name+'.zip')),identity(dest/(name+'-archive.json'))]
retained=[check(read(out/'qwen-image.json')),
    check(read(ARCH/'binding-port-reuse/checks/20261019T174851/cpu-image.json')),
    check(read(ARCH/'binding-port-reuse/checks/20261019T174851/qwen-image.json')),
    check(read(ARCH/'cuda-explicit-rope/performance-prepared/peer-image.json'))]
observation=read(STAGE/'correctness/summary.json')['observation']
assert observation['equal_vectors']==len(observation['vectors'])==64
references=[check(row['reference']) for row in observation['vectors']]
targets={}


def target(path):
    path=path.resolve()
    assert path.is_file() and path.is_relative_to(ROOT/'.scratch')
    targets[str(path).casefold()]=identity(path)


bases=[STAGE/'checks/20261019T180121/cast',out/'cast',
    ARCH/'conv-typed-load/checks/20261019T171411/qwen',
    ARCH/'prepare-replay-cold-index/checks/20261019T173829/qwen',
    ARCH/'prepare-replay-cold-index/checks/20261019T173829/cpu']
for base in bases:
    assert base.with_suffix('.exe').is_file(),base
    for suffix in ('.exe','.map','.exp','.lib','.pdb'):
        path=base.with_suffix(suffix)
        if path.exists():target(path)
for folder in (STAGE,ARCH/'binding-port-reuse'):
    observed=read(folder/'correctness/summary.json')['observation']
    assert observed['equal_vectors']==len(observed['vectors'])==64
    for row in observed['vectors']:
        actual=check(row['actual'],folder/'correctness/trace'/row['path'])
        assert row['byte_equal'] and actual['sha256']==row['reference']['sha256']
        target(Path(actual['path']))
build=read(out/'plan.json')
inputs={str(Path(p).resolve()).casefold() for link in build['links'].values() for p in link['inputs']}
assert not set(targets).intersection(inputs)
assert not set(targets).intersection(str(Path(row['path']).resolve()).casefold()
    for row in [*retained,*references,*evidence])
plan=dict(evidence=evidence,retained_images=retained,retained_vectors=references,
    current_build_plan=identity(out/'plan.json'),targets=list(targets.values()),count=len(targets),
    total_bytes=sum(row['bytes'] for row in targets.values()),recursive=False,
    scope='Five temporary/superseded test or validation images with their link side products and128 duplicate vectors; current Qwen/CPU, exact before baseline, peer, all source/object/SDK/log/profiles and64original vectors retained.')
path=STAGE/'cleanup-plan.json';assert not path.exists()
path.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=(ROOT/'test.ps1').read_bytes();(STAGE/'test-before-reclaim.ps1').write_bytes(old)
# This script has no multiline literals. Normalize blank separators instead of
# repeatedly translating old CRLF bytes into additional CRs on Windows.
script='\n'.join(line for line in old.decode('utf-8-sig').splitlines() if line.strip())+'\n'
previous=identity(ARCH/'prepare-replay-cold-index/cleanup-plan.json')['sha256']
assert previous in script
script=script.replace('prepare-replay-cold-index\\cleanup-plan.json','cast-stable-silu\\cleanup-plan.json')
script=script.replace('prepare-replay-cold-index\\cleanup-result.json','cast-stable-silu\\cleanup-result.json')
script=script.replace(previous,identity(path)['sha256'])
assert 'prepare-replay-cold-index\\cleanup-' not in script
for target_script in (ROOT/'test.ps1',STAGE/'executed-reclaim.ps1'):
    with target_script.open('w',encoding='utf-8',newline='\n') as handle:handle.write(script)
print(json.dumps(dict(plan=identity(path),count=plan['count'],bytes=plan['total_bytes'],
    MiB=plan['total_bytes']/1024**2,deletion_executed=False),indent=2))
