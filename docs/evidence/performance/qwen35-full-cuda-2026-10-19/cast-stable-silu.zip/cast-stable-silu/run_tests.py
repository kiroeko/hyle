"""Run the five exact Cast/stable-SiLU reference and escape cases."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('conv_test_build',STAGE/'build.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,c=m.b,m.c
path=Path(sys.argv[1]).resolve(); plan=c.read(path); m.check(plan)
assert c.read(path.parent/'summary.json')['passed']
out=STAGE/'tests'; out.mkdir(exist_ok=False); (out/'tmp').mkdir()
names=c.read(STAGE/'tests-source-freeze.json')['tests']
link=plan['links']['cast']; image=b.identity(link['image'])
assert image==c.read(path.parent/'cast-image.json')
env,_=b.environment(link['command'],link['inputs'],out)
command=[image['path'],'--gtest_filter='+':'.join(names),'--gtest_output=xml:'+str(out/'results.xml')]
try: c.execute('cast',command,env,out)
finally:
    cases=ET.parse(out/'results.xml').findall('.//testcase') if (out/'results.xml').exists() else []
    actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases]
    passed=(len(cases)==len(names) and set(actual)==set(names) and all(not any(r.find(tag) is not None
        for tag in ('failure','error','skipped')) for r in cases))
    c.save(out/'summary.json',dict(passed=passed,cases=len(cases),names=actual,exact_filters=names,
        skipped=sum(r.find('skipped') is not None for r in cases),image=image,build_plan=b.identity(path),GPU_run=True,
        original_Direct_Cast_and_default_SGLang_reference=True,SDK_rebuild=False))
if not passed: raise ValueError('Expected all5 exact CUDA cases without skip/failure')
print('CAST_STABLE_SILU_TESTS',len(cases),'passed',flush=True)
