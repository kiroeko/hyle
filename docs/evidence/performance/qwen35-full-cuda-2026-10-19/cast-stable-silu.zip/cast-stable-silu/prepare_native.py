"""Prepare a private exact Cast/stable-SiLU draft from the current full lock.

This script writes only this scratch directory. It neither seals a product
manifest nor compiles code. Immutable input snapshots make the draft replayable.
"""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def replace(text, before, after):
    assert text.count(before) == 1, before[:120]
    return text.replace(before, after, 1)


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256'], row['path']
    for edit in row['edits']:
        before, after = edit['before'].encode(), edit['after'].encode()
        assert data.count(before) == 1, row['path']
        data = data.replace(before, after, 1)
    assert sha(data) == row['after_sha256'], row['path']
    return data


PREDICATE = r'''
// Exact metadata carrier only. Published/readers and real buffer ownership are
// graph/encode facts checked by the native private matcher, not by sizing.
bool ggml_cuda_supports_cast_stable_silu(const ggml_tensor * cast, const ggml_tensor * silu) {
    if (!cast || !silu || cast->op != GGML_OP_CPY || cast->type != GGML_TYPE_BF16 ||
        cast->src[1] != cast || cast->view_src || silu->view_src ||
        silu->op != GGML_OP_UNARY || silu->type != GGML_TYPE_BF16 ||
        silu->src[0] != cast || !ggml_hyle_stable_silu(silu)) return false;
    const ggml_tensor * const x = cast->src[0];
    if (!x || x == cast || x == silu || x->type != GGML_TYPE_F32) return false;
    for (int port = 2; port < GGML_MAX_SRC; ++port) {
        if (cast->src[port]) return false;
    }
    for (int port = 1; port < GGML_MAX_SRC; ++port) {
        if (silu->src[port]) return false;
    }
    const ggml_tensor * const tensors[] = {x, cast, silu};
    for (const auto * tensor : tensors) {
        uint64_t count = 1;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            // The original dense unary carrier uses a signed int count.
            if (tensor->ne[axis] <= 0 || uint64_t(tensor->ne[axis]) > uint64_t(INT32_MAX) / count ||
                tensor->nb[axis] > uint64_t(INT64_MAX) ||
                tensor->nb[axis] % ggml_type_size(tensor->type)) return false;
            count *= uint64_t(tensor->ne[axis]);
        }
        if (!ggml_is_contiguous(tensor) || !ggml_are_same_shape(tensor, cast)) return false;
    }
    return true;
}

static __global__ void hyle_cast_stable_silu(const float * __restrict__ x,
        nv_bfloat16 * __restrict__ dst, int64_t count) {
    ggml_cuda_pdl_lc();
    const int64_t index = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (index >= count) return;
    ggml_cuda_pdl_sync();
    // Both public BF16 boundaries remain. In particular do not apply SiLU to
    // the original float value and narrow only its final result.
    const nv_bfloat16 rounded = __float2bfloat16_rn(x[index]);
    const float value = __bfloat162float(rounded);
    dst[index] = __float2bfloat16_rn(op_hyle_stable_silu(value));
}

void ggml_cuda_op_cast_stable_silu(ggml_backend_cuda_context & ctx,
        const ggml_tensor * cast, ggml_tensor * silu) {
    if (!ggml_cuda_supports_cast_stable_silu(cast, silu)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid Cast/stable SiLU metadata");
    }
    const int64_t count = ggml_nelements(silu);
    const unsigned blocks = unsigned((count + CUDA_SILU_BLOCK_SIZE - 1) / CUDA_SILU_BLOCK_SIZE);
    // The main encoder has checked actual owners, capacities, device, bounds,
    // alignment, disjointness and the cold device launch limits before entry.
    ggml_cuda_kernel_launch(hyle_cast_stable_silu,
        ggml_cuda_kernel_launch_params(blocks, CUDA_SILU_BLOCK_SIZE, 0, ctx.stream()),
        static_cast<const float *>(cast->src[0]->data), static_cast<nv_bfloat16 *>(silu->data), count);
}

'''


BOUND = r'''
// No pointer query or new shared device-info ABI: use the original cold caps.
static bool ggml_cuda_cast_stable_silu_device(const ggml_tensor * cast,
        const ggml_tensor * silu, int device) {
    const auto & info = ggml_cuda_info();
    if (device < 0 || device >= info.device_count ||
        !GGML_CUDA_CC_IS_NVIDIA(info.devices[device].cc) ||
        !ggml_cuda_supports_cast_stable_silu(cast, silu)) return false;
    const int64_t blocks = (ggml_nelements(silu) + CUDA_SILU_BLOCK_SIZE - 1) / CUDA_SILU_BLOCK_SIZE;
    const auto & limits = ggml_cuda_launch_limits[device];
    return blocks <= limits[0] && limits[2] >= CUDA_SILU_BLOCK_SIZE;
}

static bool ggml_cuda_cast_stable_silu_bound(const ggml_tensor * cast,
        const ggml_tensor * silu, int device) {
    if (!ggml_cuda_cast_stable_silu_device(cast, silu, device)) return false;
    // The elided BF16 Cast payload is not read. Retain/check the actual F32
    // source and BF16 terminal output, including real dense offset views.
    const ggml_tensor * const tensors[] = {cast->src[0], silu};
    for (const auto * tensor : tensors) {
        if (!tensor->data || !tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (!owner || owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        const uintptr_t begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t bytes = ggml_nbytes(tensor);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        if (begin % ggml_type_size(tensor->type) || begin < base || begin - base > capacity ||
            bytes > capacity - (begin - base) || bytes > UINTPTR_MAX - begin) return false;
    }
    const uintptr_t x = reinterpret_cast<uintptr_t>(cast->src[0]->data);
    const uintptr_t y = reinterpret_cast<uintptr_t>(silu->data);
    // No exact-in-place exception across the different element widths/restrict
    // contracts. Unsafe aliases simply keep the original two native operations.
    return x + ggml_nbytes(cast->src[0]) <= y || y + ggml_nbytes(silu) <= x;
}

'''


MATCHER = r'''
// Ordinary Views have src[] edges counted by private_fusion_closed. Also reject
// raw OP_NONE aliases with only view_src: they can observe an elided Cast store
// without contributing to the native graph's source-reference use count.
static bool ggml_cuda_cast_has_escaping_view(const ggml_cgraph * graph, const ggml_tensor * cast) {
    const auto aliases_cast = [cast](const ggml_tensor * value) {
        for (const ggml_tensor * root = value->view_src; root; root = root->view_src) {
            if (root == cast) return true;
        }
        return false;
    };
    for (int index = 0; index < graph->n_nodes; ++index) {
        if (aliases_cast(graph->nodes[index])) return true;
    }
    for (int index = 0; index < graph->n_leafs; ++index) {
        if (aliases_cast(graph->leafs[index])) return true;
    }
    return false;
}

static bool ggml_cuda_match_cast_stable_silu(const ggml_cgraph * graph, int begin,
        int device, bool require_bound) {
    if (!graph || begin < 0 || begin >= graph->n_nodes || graph->n_nodes - begin < 2) return false;
    const ggml_tensor * const cast = graph->nodes[begin];
    const ggml_tensor * const silu = graph->nodes[begin + 1];
    return ggml_cuda_cast_stable_silu_device(cast, silu, device) &&
        ggml_cuda_private_fusion_closed(graph, begin, 2) &&
        !ggml_cuda_cast_has_escaping_view(graph, cast) &&
        (!require_bound || ggml_cuda_cast_stable_silu_bound(cast, silu, device));
}

'''


def change_main(data):
    text = data.decode()
    # The existing three cold caps now serve both SSM and unary launches.
    # Rename only the TU-private array, never the shared device-info layout.
    assert text.count('ggml_cuda_ssm_conv_limits') == 3
    text = text.replace('ggml_cuda_ssm_conv_limits', 'ggml_cuda_launch_limits')
    text = replace(text, '// New typed reads retain their actual original buffers. Cold supports never\n',
        BOUND + '// New typed reads retain their actual original buffers. Cold supports never\n')
    text = replace(text, '// The three intermediates are private BF16 values. A weight transpose is\n',
        MATCHER + '// The three intermediates are private BF16 values. A weight transpose is\n')
    # This cold pass already visits each possible native fusion start. Keep the
    # actual read through the terminal ordinal, like the existing fused matvec
    # read set, so gallocr cannot recycle it as the mixed-width final output.
    text = replace(text,
        '    for (int i = 0; i < cgraph->n_nodes; ++i) {\n        ggml_cuda_matvec_fusion_match matvec;\n',
        '    for (int i = 0; i < cgraph->n_nodes; ++i) {\n'
        '#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)\n'
        '        // Refine exactly the same metadata/closed graph pattern used by\n'
        '        // encode, and retain its actual F32 read through the terminal.\n'
        '        if (ggml_cuda_match_cast_stable_silu(cgraph, i, cuda_ctx->device, false)) {\n'
        '            keep(cgraph->nodes[i]->src[0], i + 1);\n'
        '            continue;\n'
        '        }\n'
        '#endif\n'
        '        ggml_cuda_matvec_fusion_match matvec;\n')
    text = replace(text,
        '#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)\n    if (node->op == GGML_OP_MUL_MAT && node->type == GGML_TYPE_BF16) {',
        '#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)\n'
        '    if (node->op == GGML_OP_CPY &&\n'
        '        ggml_cuda_match_cast_stable_silu(cgraph, i, cuda_ctx->device, true)) {\n'
        '        ggml_cuda_op_cast_stable_silu(*cuda_ctx, node, cgraph->nodes[i + 1]);\n'
        '        return 1;\n'
        '    }\n\n'
        '    if (node->op == GGML_OP_MUL_MAT && node->type == GGML_TYPE_BF16) {')
    return text.encode()


def unique_edits(old, new):
    left, right = old.decode().splitlines(True), new.decode().splitlines(True)
    edits, data = [], old
    for group in difflib.SequenceMatcher(None, left, right, autojunk=False).get_grouped_opcodes(4):
        first, last = group[0], group[-1]
        before, after = ''.join(left[first[1]:last[2]]), ''.join(right[first[3]:last[4]])
        assert data.count(before.encode()) == 1
        data = data.replace(before.encode(), after.encode(), 1)
        edits.append(dict(before=before, after=after))
    assert data == new
    return edits


def main():
    names = ['third_party/ggml_runtime/patches.json', 'third_party/ggml_cpu_runtime/patches.json',
        'third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/iq1-patches.json',
        'cmake/HyleDependencyLock.json', 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
        'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py']
    inputs = []
    for name in names:
        snapshot = STAGE / 'native-before' / name
        if not snapshot.exists():
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes((ROOT / name).read_bytes())
        inputs.append(dict(path=name, snapshot=str(snapshot), sha256=sha(snapshot.read_bytes())))
    before = STAGE / 'native-before'
    mixed, combined = STAGE / 'mixed-cpu-manifest.json', STAGE / 'before-combined.json'
    load('cast_silu_mixed', before / names[-2]).derive(UPSTREAM, before / names[0], before / names[1], mixed)
    load('cast_silu_combined', before / names[-1]).derive(UPSTREAM, mixed, before / names[2], before / names[3], combined)
    baseline = {row['path']: replay(row) for row in json.loads(combined.read_text())['files']}
    paths = ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/unary.cu', 'src/ggml-cuda/unary.cuh']
    files, replacements, diffs = [], [], []
    for name in paths:
        old = baseline.get(name, (UPSTREAM / name).read_bytes().replace(b'\r\n', b'\n'))
        if name.endswith('ggml-cuda.cu'):
            new = change_main(old)
        elif name.endswith('unary.cu'):
            new = replace(old.decode(), 'static __device__ __forceinline__ float op_tanh(float x) {',
                PREDICATE + 'static __device__ __forceinline__ float op_tanh(float x) {').encode()
        else:
            new = replace(old.decode(), 'void ggml_cuda_op_silu(ggml_backend_cuda_context & ctx, ggml_tensor * dst);',
                'void ggml_cuda_op_silu(ggml_backend_cuda_context & ctx, ggml_tensor * dst);\n\n'
                '// Private exact F32 Cast -> marked ordinary BF16 stable SiLU.\n'
                '// The metadata predicate is address-free and shared by cold/encode.\n'
                'bool ggml_cuda_supports_cast_stable_silu(const ggml_tensor * cast, const ggml_tensor * silu);\n'
                'void ggml_cuda_op_cast_stable_silu(ggml_backend_cuda_context & ctx,\n'
                '    const ggml_tensor * cast, ggml_tensor * silu);').encode()
        for folder, data in [('native-before', old), ('native-overlay/source', new)]:
            path = STAGE / folder / name
            path.parent.mkdir(parents=True, exist_ok=True)
            if folder == 'native-before' and path.exists(): assert path.read_bytes() == data
            else: path.write_bytes(data)
        replacements.append(dict(path=name, before_sha256=sha(old), after_sha256=sha(new), edits=unique_edits(old, new)))
        files.append(dict(path=name, before=dict(path=str(STAGE/'native-before'/name),sha256=sha(old),bytes=len(old)),
            after=dict(path=str(STAGE/'native-overlay/source'/name),sha256=sha(new),bytes=len(new))))
        diffs.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
    save(STAGE/'native-overlay/replacements.json',dict(files=replacements))
    (STAGE/'native-changes.diff').write_text(''.join(diffs),encoding='utf-8')
    lock=json.loads((before/'cmake/HyleDependencyLock.json').read_text())
    save(STAGE/'native-source-freeze.json',dict(status='scratch_draft_not_applied',files=files,
        baseline=dict(complete_mixed_CPU_CUDA_IQ1_replay=str(combined),sha256=sha(combined.read_bytes()),inputs=inputs),
        public_API_changed=False,shared_by_value_struct_changed=False,native_TUs_requiring_refresh=['ggml-cuda.cu','unary.cu'],
        header_refresh_scope='unary.cuh declarations only; no existing inline or by-value layout changed',
        product_patch_lock_or_NOTICE_modified=False,build_or_GPU_run=False))
    print('READY',STAGE/'native-source-freeze.json')


if __name__ == '__main__':
    main()
