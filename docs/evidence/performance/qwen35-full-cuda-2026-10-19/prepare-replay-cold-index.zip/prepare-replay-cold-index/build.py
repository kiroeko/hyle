"""Refresh actual PlanState owners, retaining current CPU/Qwen and SDK closures."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
CPU=ARCH/'decode-next-cold/checks/20261019T155819'
QWEN=ARCH/'conv-typed-load/checks/20261019T171411'
MAPPING=STAGE/'core-owner-recipes.json'
spec=importlib.util.spec_from_file_location('prepare_index_build_helpers',ARCH/'cold-capture-topology/build.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
b,c=helper.b,helper.c

EXACT_TESTS=[
 'GraphRegions.OrdinaryColdBindingsRetryWithoutExecutingAndTrackRebinds',
 'GraphRegions.CapturesAndReplaysACommandSegmentWithoutRewalkingItsSteps',
 'GraphRegions.UnknownCaptureIdentityRepreparesAfterSameTupleBindingEpisode',
 'GraphRegions.FailedSelectedConfigurationInvalidatesBeforeItsCallback',
 'GraphRegions.PreparedReplayChecksReplacedQueueOwnerAndClosedContext',
 'Invocation.PreparedReplayFollowsQueueIdentityAcrossPublicHandleMoves',
 'Invocation.PublishedViewReusesItsSourceBinding',
 'GraphViews.MetadataOnlyChainNeedsNoProviderOrPreparationBudget',
 'GraphViews.EveryExactCompileAllocationFailureCleansUpAndRetries',
 'GraphRegions.ReadyOnlyConstantsShareOwnedOutputsAcrossSlotsAndOldResults',
 'GraphRegions.ExposesAndCanRejectAHostDependencyBeforeSubmission',
 'GraphRegions.RejectsAnUnavailableTransferBeforeAnySegmentIsSubmitted',
 'SubmissionFrontier.SameQueueKeepsTheLatestAcceptedPrefixAfterReordering',
 'GraphConstants.BorrowedReplicasKeepViewOffsetsAndNeverCopyAtReplay',
 'GraphDomain.CrossStorageCopyUsesConcreteByteCountNotEnvelope',
 'GraphCompile.PlacesAcrossTargetsWithoutFalseStorageCopies',
 'GraphRegions.ReadyOnlyRegionAndViewsExecuteWithoutAnyQueue',
 'GraphRegions.DeferredPortsBindOriginalSourcesAndProjectOnlyAfterSuccess',
 'GraphRegions.ExposesADelegatedHostWaitBeforeAcceptingAnyWork',
 'GraphViews.MetadataControlDependencyOrdersCommandsAcrossTargets',
]


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):raise ValueError('Source/header/recipe changed: '+row['path'])


def prepare(out):
    seal_path=STAGE/'source-freeze.json'
    seal=c.read(seal_path)
    frozen=[b.identity(p) for p in (Path(__file__),STAGE/'run_tests.py',seal_path,MAPPING)]
    changed=set()
    for row in seal['files']:
        rel=row.get('source') or row['path'];actual=b.identity(ROOT/rel)
        if any(actual[k]!=row['after'][k] for k in ('bytes','sha256')):raise ValueError('Sealed source differs: '+rel)
        frozen.append(actual);changed.add(c.key(ROOT/rel))
    bases={arm:c.read(folder/(arm+'-link-plan.json')) for arm,folder in [('cpu',CPU),('qwen',QWEN)]}
    cached={c.key(row['path']):row for link in bases.values() for row in link['inputs']}
    mapping=c.read(MAPPING)
    assert mapping['owner_count']==len(mapping['owners'])==8 and not mapping['additional_linked_owner_with_plan_state']
    specifications=[dict(source=row['source'],recipe=row['recipe'],old_object=row['old_object'],arms=['cpu','qwen'])
                    for row in mapping['owners']]
    # This fixture itself includes PlanState. The other existing CPU fixture
    # executable_test does not; its unchanged cached object remains usable.
    fixture_receipt=CPU/'41-graph-region_provider_test-identity.json'
    fixture=c.read(fixture_receipt)
    assert any(c.key(row['path'])==c.key(ROOT/'src/graph/plan_state.h') for row in fixture['dependencies'])
    specifications.append(dict(source=fixture['source']['path'],recipe=str(fixture_receipt),
        old_object=fixture['object'],arms=['cpu']))
    rows=[]
    for index,specification in enumerate(specifications):
        source=Path(specification['source']);recipe_path=Path(specification['recipe']);recipe=c.read(recipe_path)
        old=specification['old_object'];assert recipe['object']==old and cached[c.key(old['path'])]==old
        assert all(old in bases[arm]['inputs'] for arm in specification['arms'])
        current=b.identity(source)
        if c.key(source) not in changed and any(current[k]!=recipe['source'][k] for k in ('bytes','sha256')):
            raise ValueError('An unmodified owner unexpectedly differs from its actual old recipe: '+str(source))
        tag=f'{index:02d}-'+source.parent.name+'-'+source.stem
        command=b.host_command(recipe['command'],source,tag,out)
        rows.append(dict(tag=tag,kind='host',source=current,recipe=b.identity(recipe_path),
            previous_source=recipe['source'],old_object=old,object=str(out/(tag+'.obj')),
            command=command,arms=specification['arms'],requires_PlanState=True))
        frozen += [current,b.identity(recipe_path)]
        frozen += [b.identity(path) for path in b.host_dependencies(recipe['command'])]
        snapshot=out/'compiled-source'/source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes())
        frozen.append(b.identity(snapshot))
    assert len(rows)==9
    links={}
    for arm,base in bases.items():
        replaces={c.key(row['old_object']['path']):row['object'] for row in rows if arm in row['arms']}
        assert len(replaces)==(9 if arm=='cpu' else 8)
        command=[replaces.get(c.key(arg),arg) for arg in base['command']
                 if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        image=out/(arm+'.exe')
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[arg for arg in command if Path(arg).is_absolute() and arg.lower().endswith(('.obj','.lib'))
                and not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        assert len(inputs)==len(base['inputs'])==(115 if arm=='cpu' else 129)
        assert len(set(map(c.key,inputs)))==len(inputs)
        links[arm]=dict(command=command,image=str(image),inputs=inputs,
            replacements=len(replaces),new_link_inputs=0)
        frozen.append(b.identity((CPU if arm=='cpu' else QWEN)/(arm+'-link-plan.json')))
    return dict(compile=rows,links=links,cached_inputs=list(cached.values()),
        frozen=list({c.key(row['path']):row for row in frozen}.values()),
        base_links={arm:b.identity(folder/(arm+'-link-plan.json')) for arm,folder in [('cpu',CPU),('qwen',QWEN)]},
        baseline_images={arm:c.read(folder/(arm+'-image.json')) for arm,folder in [('cpu',CPU),('qwen',QWEN)]},
        private_ABI_owners=8,private_CPU_fixture_owners=1,host_TUs=9,native_TUs=0,
        SDK_build=False,GPU_run=False,exact_tests=EXACT_TESTS,
        scope='Only8actual production PlanState owners and1actual CPU private fixture; current115/129 link closures unchanged in size.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build',action='store_true');p.add_argument('--resume',type=Path)
    args=p.parse_args()
    if args.resume:
        path=args.resume.resolve();out=path.parent;plan=c.read(path)
    else:
        out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
        plan=prepare(out);path=out/'plan.json';c.save(path,plan)
    print('PLAN',path,flush=True)
    if not args.build:return
    check(plan)
    for row in plan['cached_inputs']:
        if not b.same(row):raise ValueError('Actual cached object/library differs: '+row['path'])
    identities={c.key(row['path']):row for row in plan['cached_inputs']}
    env,_=b.environment(plan['links']['qwen']['command'],[row['path'] for row in plan['cached_inputs']],out)
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                identities[c.key(old['object']['path'])]=old['object'];print('REUSE',row['tag'],flush=True);continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt),row['command'],env,out);check(plan)
        deps=c.read(out/(row['tag']+'-deps.json'))['Data']
        depids=[b.identity(source) for source in [deps['Source'],*deps['Includes']]]
        assert any(c.key(d['path'])==c.key(ROOT/'src/graph/plan_state.h') for d in depids),row['tag']
        record=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=depids)
        c.save(receipt,record);identities[c.key(record['object']['path'])]=record['object']
        print('COMPILED',row['tag'],flush=True)
    for arm,link in plan['links'].items():
        receipt=out/(arm+'-image.json')
        if receipt.exists() and b.same(c.read(receipt)):continue
        env,_=b.environment(link['command'],link['inputs'],out)
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')))
        c.execute(arm+'-link-'+str(attempt),link['command'],env,out);check(plan)
        c.save(out/(arm+'-link-plan.json'),dict(command=link['command'],
            inputs=[identities[c.key(obj)] for obj in link['inputs']]))
        c.save(receipt,b.identity(link['image']))
    for row in plan['cached_inputs']:
        if not b.same(row):raise ValueError('Cached object/library changed during build: '+row['path'])
    c.save(out/'summary.json',dict(passed=True,host_TUs=9,native_TUs=0,
        private_ABI_owners=8,private_CPU_fixture_owners=1,SDK_build=False,GPU_run=False))
    c.save(STAGE/'latest-check.json',dict(plan=str(path)))
    print('BUILD_COMPLETE',path,flush=True)


if __name__=='__main__':main()
