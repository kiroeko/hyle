"""One current-image diagnostic with scratch-only Graph/main timing markers."""
from pathlib import Path
import collections
import importlib.util
import json
import re
import statistics
import sys
sys.dont_write_bytecode = True
STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
CONV=ARCH/'conv-typed-load'
OUT=STAGE/'probe'
spec=importlib.util.spec_from_file_location('prepare_probe_build',CONV/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c


def replace(code,old,new):
    assert code.count(old)==1,old[:120]
    return code.replace(old,new,1)


def instrument(code):
    support=r'''
#include <chrono>
#include <cstdio>
namespace {
using HyleProbeClock=std::chrono::steady_clock;
enum HyleProbeTime {HP_Total,HP_Queue,HP_BindPhase,HP_Transfer,HP_Dependency,
  HP_InputSources,HP_ReserveCommit,HP_Ranges,HP_BindBody,HP_Views,
  HP_Materialized,HP_ProviderHooks,HP_Seal,HP_TimeCount};
enum HyleProbeCount {HP_BindCalls,HP_BindCached,HP_Steps,HP_ViewSteps,
  HP_ViewOutputs,HP_MaterializedSteps,HP_InputPorts,HP_OutputPorts,HP_Alignment,
  HP_PhysicalCompares,HP_RegionHooks,HP_OperationHooks,HP_Generated,
  HP_SealVisits,HP_SealRegions,HP_TransferVisits,HP_CopySteps,HP_Lanes,
  HP_DependencyEdges,HP_InputSourcePresent,HP_Candidates,HP_Reused,HP_Recorded,
  HP_CountCount};
struct HyleProbeData { bool active=false; int phase=-1;
  HyleProbeClock::time_point last{};
  unsigned long long ns[HP_TimeCount]{}; unsigned long long count[HP_CountCount]{};
};
thread_local HyleProbeData hyle_probe;
void hyle_probe_count(int id,unsigned long long n=1) noexcept {
  if(hyle_probe.active)hyle_probe.count[id]+=n;
}
void hyle_probe_phase(int next) noexcept {
  if(!hyle_probe.active)return;
  const auto now=HyleProbeClock::now();
  if(hyle_probe.phase>=0)hyle_probe.ns[hyle_probe.phase]+=static_cast<unsigned long long>(
    std::chrono::duration_cast<std::chrono::nanoseconds>(now-hyle_probe.last).count());
  hyle_probe.last=now;hyle_probe.phase=next;
}
struct HyleProbeScope {
  int id;bool active;HyleProbeClock::time_point start;
  explicit HyleProbeScope(int value) noexcept:id(value),active(hyle_probe.active),
    start(active?HyleProbeClock::now():HyleProbeClock::time_point{}){}
  ~HyleProbeScope(){if(active)hyle_probe.ns[id]+=static_cast<unsigned long long>(
    std::chrono::duration_cast<std::chrono::nanoseconds>(HyleProbeClock::now()-start).count());}
};
struct HyleProbeEpisode {
  HyleProbeClock::time_point start;
  HyleProbeEpisode() noexcept:start(HyleProbeClock::now()){
    hyle_probe.active=true;hyle_probe.last=start;hyle_probe.phase=HP_Queue;}
  ~HyleProbeEpisode(){hyle_probe_phase(-1);hyle_probe.ns[HP_Total]+=static_cast<unsigned long long>(
    std::chrono::duration_cast<std::chrono::nanoseconds>(HyleProbeClock::now()-start).count());
    hyle_probe.active=false;}
};
}
extern "C" void hyle_prepare_probe_reset() noexcept {hyle_probe={};}
extern "C" void hyle_prepare_probe_print(const char*phase) noexcept {
  constexpr const char*times[]={"total","queue","binding_phase","transfer","dependency",
    "input_sources","reserve_commit","ranges","binding_body","views",
    "materialized_inclusive","provider_hooks_nested","seal_nested"};
  constexpr const char*counts[]={"binding_calls","binding_cached","steps","view_steps",
    "view_outputs","materialized_steps","input_ports","output_ports","alignment_calls",
    "physical_compares","region_hooks","operation_hooks","generated_outputs",
    "seal_visits","seal_regions","transfer_visits","copy_steps","lanes",
    "dependency_edges","input_source_present","capture_candidates","capture_reused","capture_recorded"};
  std::fprintf(stderr,"prepare_internal phase=%s",phase);
  for(int i=0;i<HP_TimeCount;++i)std::fprintf(stderr," %s_ns=%llu",times[i],hyle_probe.ns[i]);
  for(int i=0;i<HP_CountCount;++i)std::fprintf(stderr," %s=%llu",counts[i],hyle_probe.count[i]);
  std::fprintf(stderr,"\n");
}
'''
    code=replace(code,'namespace hyle::graph {',support+'\nnamespace hyle::graph {')
    code=replace(code,'    std::uint32_t instance, mem::ConstBufferView view) noexcept {',
        '    std::uint32_t instance, mem::ConstBufferView view) noexcept {\n  hyle_probe_count(HP_Alignment);')
    code=replace(code,'                          compute::ConstTensorView right) noexcept {',
        '                          compute::ConstTensorView right) noexcept {\n  hyle_probe_count(HP_PhysicalCompares);')
    code=replace(code,'    std::size_t step_index, std::size_t port) noexcept {',
        '    std::size_t step_index, std::size_t port) noexcept {\n  hyle_probe_count(HP_Generated);')
    code=replace(code,'Status seal_invocation_bindings(detail::InvocationState &invocation) noexcept {',
        'Status seal_invocation_bindings(detail::InvocationState &invocation) noexcept {\n  HyleProbeScope hyle_seal_scope{HP_Seal};\n  hyle_probe_count(HP_SealVisits,invocation.plan->steps.size());')
    code=replace(code,'    const auto status = invocation.invocations[index].region.seal_bindings();',
        '    hyle_probe_count(HP_SealRegions);\n    const auto status = invocation.invocations[index].region.seal_bindings();')
    code=replace(code,'prepare_invocation_bindings(detail::InvocationState &invocation) noexcept {',
        'prepare_invocation_bindings(detail::InvocationState &invocation) noexcept {\n  HyleProbeScope hyle_binding_scope{HP_BindBody};\n  hyle_probe_count(HP_BindCalls);\n  hyle_probe_count(HP_BindCached,invocation.bindings_prepared?1:0);')
    start=code.index('prepare_invocation_bindings(detail::InvocationState &invocation) noexcept {')
    end=code.index('\ncompute::Queue *candidate_queue',start)
    body=code[start:end]
    body=replace(body,'    const detail::PlanStep &step = plan.steps[step_index];',
        '    hyle_probe_count(HP_Steps);\n    const detail::PlanStep &step = plan.steps[step_index];')
    body=replace(body,'    if (step.kind == detail::PlanStepKind::kView) {',
        '    if (step.kind == detail::PlanStepKind::kView) {\n      HyleProbeScope hyle_view_scope{HP_Views};\n      hyle_probe_count(HP_ViewSteps);\n      hyle_probe_count(HP_ViewOutputs,step.output_count);')
    body=replace(body,'    auto &cached = invocation.step_bindings[step_index];',
        '    HyleProbeScope hyle_material_scope{HP_Materialized};\n    hyle_probe_count(HP_MaterializedSteps);\n    hyle_probe_count(HP_InputPorts,step.input_count);\n    hyle_probe_count(HP_OutputPorts,step.output_count);\n    auto &cached = invocation.step_bindings[step_index];')
    old='''      if (changed)
        HYLE_RETURN_IF_ERROR(invocation.invocations[step_index].region.prepare_bindings(
            std::span<const RegionValue>(invocation.native_inputs).first(step.input_count),
            std::span<const compute::TensorView>(invocation.submission_outputs)
                .subspan(step.output_begin, step.output_count)));'''
    new='''      if (changed) {
        HyleProbeScope hyle_hook_scope{HP_ProviderHooks};
        hyle_probe_count(HP_RegionHooks);
        HYLE_RETURN_IF_ERROR(invocation.invocations[step_index].region.prepare_bindings(
            std::span<const RegionValue>(invocation.native_inputs).first(step.input_count),
            std::span<const compute::TensorView>(invocation.submission_outputs)
                .subspan(step.output_begin, step.output_count)));
      }'''
    body=replace(body,old,new)
    body=replace(body,'    } else if (changed && step.kind == detail::PlanStepKind::kOperation) {',
        '    } else if (changed && step.kind == detail::PlanStepKind::kOperation) {\n      HyleProbeScope hyle_hook_scope{HP_ProviderHooks};\n      hyle_probe_count(HP_OperationHooks);')
    code=code[:start]+body+code[end:]
    code=replace(code,'                                ReplayReport &report) noexcept {',
        '                                ReplayReport &report) noexcept {\n  hyle_probe_count(HP_TransferVisits,invocation.plan->steps.size()*2);')
    code=replace(code,'    if (step.kind != detail::PlanStepKind::kCopy)\n      continue;',
        '    if (step.kind != detail::PlanStepKind::kCopy)\n      continue;\n    hyle_probe_count(HP_CopySteps);')
    code=replace(code,'                                  ReplayOptions options) noexcept {',
        '                                  ReplayOptions options) noexcept {\n  HyleProbeEpisode hyle_probe_episode;')
    code=replace(code,'  Status bindings = prepare_invocation_bindings(*state_);',
        '  hyle_probe_count(HP_Lanes,state_->plan->lanes.size());\n  hyle_probe_count(HP_DependencyEdges,state_->plan->segment_dependencies.size());\n  hyle_probe_phase(HP_BindPhase);\n  Status bindings = prepare_invocation_bindings(*state_);')
    code=replace(code,'  ReplayReport transfer_report{};',
        '  hyle_probe_phase(HP_Transfer);\n  ReplayReport transfer_report{};')
    code=replace(code,'  auto dependency_report =\n      prepare_dependency_routes(*state_, options.host_wait);',
        '  hyle_probe_phase(HP_Dependency);\n  auto dependency_report =\n      prepare_dependency_routes(*state_, options.host_wait);')
    code=replace(code,'  HYLE_RETURN_IF_ERROR(detail::prepare_input_sources(*state_, queues, options.host_wait));',
        '  hyle_probe_phase(HP_InputSources);\n  hyle_probe_count(HP_InputSourcePresent,state_->input_sources?1:0);\n  HYLE_RETURN_IF_ERROR(detail::prepare_input_sources(*state_, queues, options.host_wait));\n  hyle_probe_phase(HP_ReserveCommit);')
    code=replace(code,'  for (const auto &candidate : state_->plan->capture_ranges) {',
        '  hyle_probe_phase(HP_Ranges);\n  hyle_probe_count(HP_Candidates,state_->plan->capture_ranges.size());\n  for (const auto &candidate : state_->plan->capture_ranges) {')
    code=replace(code,'      ++reused_range_count;',
        '      hyle_probe_count(HP_Reused);\n      ++reused_range_count;')
    code=replace(code,'    ++recorded_range_count;',
        '    hyle_probe_count(HP_Recorded);\n    ++recorded_range_count;')
    return code


def linked_source_audit(link):
    wanted={c.key(r['path']):r for r in link['inputs'] if Path(r['path']).suffix.lower()=='.obj'}
    found={}
    for folder in {Path(r['path']).parent for r in wanted.values()}:
        for path in folder.glob('*identity*.json'):
            try:row=c.read(path)
            except (ValueError,KeyError):continue
            obj=row.get('object')
            if not isinstance(obj,dict) or c.key(obj.get('path','')) not in wanted:continue
            expected=wanted[c.key(obj['path'])]
            if any(obj.get(k)!=expected.get(k)for k in ('bytes','sha256')):continue
            found[c.key(obj['path'])]=(path,row)
    checked={};owners=[];mismatches=[]
    for key,(recipe,row) in found.items():
        local=[]
        for dep in [row.get('source',{}),*row.get('dependencies',[])]:
            if not isinstance(dep,dict)or'path'not in dep:continue
            p=Path(dep['path'])
            if not any(p.is_relative_to(ROOT/q)for q in ('src','include','tools')):continue
            frozen=OUT/'before'/p.relative_to(ROOT)
            if p.parent==ROOT/'src/graph' and p.suffix=='.h':
                frozen=OUT/'frozen-graph'/p.name
            actual=checked.setdefault(c.key(p),b.identity(frozen if frozen.is_file()else p))
            local.append(actual)
            if any(actual.get(k)!=dep.get(k)for k in ('bytes','sha256')):
                mismatches.append(dict(recipe=str(recipe),compiled=dep,current=actual))
        owners.append(dict(recipe=b.identity(recipe),object=row['object'],source=row.get('source'),product_dependencies=local))
    result=dict(link_plan_input_objects=len(wanted),identity_mapped_objects=len(found),owners=owners,
        product_sources_and_headers=list(checked.values()),mismatches=mismatches,
        unresolved_objects=[r for k,r in wanted.items()if k not in found],
        libraries='Retain current exact link-plan identities; no SDK/library rebuild or duplicate library hash loop. All actual object hashes checked once before and once after the diagnostic.')
    c.save(OUT/'closure-source-audit.json',result)
    if mismatches:raise ValueError('Current product source/header drift in retained actual owner; see closure-source-audit.json')
    return result


def prepare():
    OUT.mkdir(exist_ok=True);(OUT/'tmp').mkdir(exist_ok=True)
    executable_recipe=ARCH/'decode-next-cold/checks/20261019T155819/33-graph-executable-identity.json'
    main_recipe=ARCH/'decode-next-cold/checks/20261019T155819/29-qwen35_text-main-identity.json'
    link_path=Path(c.read(CONV/'latest-check.json')['plan']).parent/'qwen-link-plan.json'
    link=c.read(link_path)
    rows=[]
    for tag,recipe_path,product in [('executable',executable_recipe,ROOT/'src/graph/executable.cc'),('main',main_recipe,ROOT/'tools/qwen35_text/main.cc')]:
        recipe=c.read(recipe_path)
        before=OUT/'before'/product.relative_to(ROOT);before.parent.mkdir(parents=True,exist_ok=True)
        if not before.exists():before.write_bytes(product.read_bytes())
        assert all(b.identity(before)[k]==recipe['source'][k]for k in ('bytes','sha256'))
        if tag=='executable':code=instrument(before.read_text())
        else:
            code=(CONV/'host-probe/main.cc').read_text()
            code=replace(code,'#include <algorithm>','extern "C" void hyle_prepare_probe_reset() noexcept;\nextern "C" void hyle_prepare_probe_print(const char*) noexcept;\n#include <algorithm>')
            code=replace(code,'      host_probe[2] = Clock::now();','      hyle_prepare_probe_reset();\n      host_probe[2] = Clock::now();')
            code=replace(code,'    std::cerr << "host_probe phase=" << name;','    hyle_prepare_probe_print(name.c_str());\n    std::cerr << "host_probe phase=" << name;')
        source=OUT/(tag+'.cc');source.write_text(code,encoding='utf-8')
        command=b.host_command(recipe['command'],source,tag,OUT)
        command[1:1]=['/I'+str(OUT/'frozen-graph'),'/I'+str(product.parent)]
        rows.append(dict(tag=tag,source=b.identity(source),original_source=recipe['source'],recipe=b.identity(recipe_path),command=command,old_object=recipe['object'],object=str(OUT/(tag+'.obj'))))
    replacements={c.key(r['old_object']['path']):r['object']for r in rows}
    assert set(replacements)<={c.key(r['path'])for r in link['inputs']}
    command=[replacements.get(c.key(x),x)for x in link['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    image=OUT/'qwen-probe.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    request=next(r['command']for r in c.read(CONV/'performance-prepared/plan.json')['requests']if r['arm']=='current').copy();request[0]=str(image)
    assert '--trace'not in request
    plan=dict(compile=rows,link=dict(command=command,original=b.identity(link_path),original_inputs=link['inputs'],image=str(image)),run=request,
        current_product_math='Conv v24 sourceID d09406b4be8cc51e; only scratch main/executable objects replaced',
        required_ids=c.read(CONV/'correctness/summary.json')['observation']['generated_ids'],model_processes=1,throughput_claim=False,
        clock_limit='Per-step scoped clocks perturb timing. Materialized scope includes nested provider hooks; binding includes View/materialized/seal. Inclusive/exclusive subtraction is diagnostic, not an uninstrumented cost estimate.')
    c.save(OUT/'plan.json',plan)
    linked_source_audit(link)
    return plan


def run():
    plan=prepare();link=plan['link'];paths=[r['path']for r in link['original_inputs']]
    env,runtime=b.environment(link['command'],paths,OUT)
    cached={r['path']:r for r in link['original_inputs']if Path(r['path']).suffix.lower()=='.obj'}
    for row in cached.values():assert b.same(row),'Cached object changed:'+row['path']
    for row in plan['compile']:
        c.execute(row['tag']+'-compile',row['command'],env,OUT)
        data=c.read(OUT/(row['tag']+'-deps.json'))['Data']
        c.save(OUT/(row['tag']+'-identity.json'),dict(command=row['command'],source=row['source'],object=b.identity(Path(row['object'])),dependencies=[b.identity(Path(p))for p in [data['Source'],*data['Includes']]]))
    c.execute('probe-link',link['command'],env,OUT);c.save(OUT/'qwen-image.json',b.identity(Path(link['image'])))
    c.execute('probe',plan['run'],env,OUT)
    output=c.read(OUT/'probe.stdout.log');assert output['generated_ids']==plan['required_ids']
    internal=[];caller=[]
    for line in (OUT/'probe.stderr.log').read_text().splitlines():
        if line.startswith('prepare_internal phase='):
            fields=dict(x.split('=',1)for x in line.split()[1:]);internal.append(dict(phase=fields.pop('phase'),**{k:int(v)for k,v in fields.items()}))
        if line.startswith('host_probe phase='):
            caller.append(dict(phase=line.split()[1].split('=',1)[1],seconds=[float(v)for v in re.findall(r' part=([0-9.eE+\-]+)',line)]))
    assert len(internal)==len(caller)==32 and all(r['phase']==('prefill'if i==0 else'decode'+str(i))for i,r in enumerate(internal))
    warm=internal[7:];names=[k for k in warm[0]if k!='phase']
    summaries={k:dict(mean=statistics.mean(r[k]for r in warm),median=statistics.median(r[k]for r in warm),min=min(r[k]for r in warm),max=max(r[k]for r in warm))for k in names}
    for row in cached.values():assert b.same(row),'Cached object changed after diagnostic:'+row['path']
    c.save(OUT/'summary.json',dict(passed=True,processes=1,raw_phases=internal,caller_phases=caller,warm25=summaries,
        expected_ids_same=True,image=b.identity(Path(link['image'])),runtime=runtime,throughput_claim=False,
        product_edits=False,SDK_build=False,native_build=False,host_TUs=2,limits=plan['clock_limit']))
    print('PROBE_COMPLETE',json.dumps(summaries),flush=True)


if __name__=='__main__':run()
