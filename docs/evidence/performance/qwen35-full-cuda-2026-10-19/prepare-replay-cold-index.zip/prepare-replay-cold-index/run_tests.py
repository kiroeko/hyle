"""Run only the20related existing CPU regressions with exact XML accounting."""
from pathlib import Path
import argparse
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('plan',type=Path);args=p.parse_args()
    spec=importlib.util.spec_from_file_location('prepare_index_test_build',STAGE/'build.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b,c=m.b,m.c
    path=args.plan.resolve();plan=c.read(path);m.check(plan)
    assert c.read(path.parent/'summary.json')['passed']
    out=STAGE/'tests';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    names=plan['exact_tests'];assert len(names)==len(set(names))==20
    link=c.read(path.parent/'cpu-link-plan.json');image=c.read(path.parent/'cpu-image.json')
    assert b.identity(image['path'])==image
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']],out)
    c.save(out/'runtime.json',dict(link_plan=b.identity(path.parent/'cpu-link-plan.json'),
        runtime_library_directories=runtime,unrelated_CUDA_or_Qwen_DLL_union_used=False))
    command=[image['path'],'--gtest_filter='+':'.join(names),'--gtest_output=xml:'+str(out/'results.xml')]
    try:
        c.execute('cpu',command,env,out)
    finally:
        cases=ET.parse(out/'results.xml').findall('.//testcase') if (out/'results.xml').exists() else []
        actual=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases]
        passed=(len(cases)==20 and set(actual)==set(names) and len(set(actual))==20
            and all(row.find(tag) is None for row in cases for tag in ('failure','error','skipped')))
        c.save(out/'summary.json',dict(passed=passed,cases=len(cases),names=actual,exact_filters=names,
            skipped=sum(row.find('skipped') is not None for row in cases),image=image,
            build_plan=b.identity(path),CPU_only=True,GPU_run=False,
            limit='CPU mock/host transfer and dependency contracts; no physical CUDA peer-transfer or full-model validation.'))
    if not passed:raise ValueError('Expected all20exact CPU cases, zero failure/error/skip')
    print('PREPARE_REPLAY_CPU_TESTS',len(cases),'passed',flush=True)


if __name__=='__main__':main()
