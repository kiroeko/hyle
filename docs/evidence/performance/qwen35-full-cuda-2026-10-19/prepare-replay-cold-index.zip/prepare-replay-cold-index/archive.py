"""Archive the completed host cold-index batch; never builds, runs or deletes."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE=Path(__file__).resolve().parent
ARCH=STAGE.parent
ROOT=ARCH.parents[1]
PREFIX='prepare-replay-cold-index/'
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/prepare-replay-cold-index.zip'
OMIT={'.exe','.obj','.o','.map','.lib','.a','.exp','.pdb','.dll','.pyc','.tmp',
      '.bf16','.f16','.f32','.bin','.npy','.zip'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=sha(data))


def check(row,path=None):
    actual=identity(path or row['path'])
    assert all(actual[key]==row[key] for key in ('bytes','sha256')),(row,actual)
    return actual


def save(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def eligible(path):
    parts={part.lower() for part in path.relative_to(STAGE).parts}
    return (path.suffix.lower() not in OMIT and not parts.intersection({'tmp','__pycache__','sdk','cache'})
        and not (path.parent==STAGE and path.name=='archive-receipt.json'))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build-plan',type=Path,required=True);args=p.parse_args()
    plan_path=args.build_plan.resolve();assert plan_path.is_relative_to(STAGE/'checks')
    plan=read(plan_path);build=read(plan_path.parent/'summary.json');plan_id=identity(plan_path)
    assert build['passed'] and build['host_TUs']==9 and build['native_TUs']==0 and not build['SDK_build']
    assert plan['private_ABI_owners']==8 and plan['private_CPU_fixture_owners']==1
    assert len(plan['compile'])==9 and all(row['kind']=='host' for row in plan['compile'])
    assert len(read(plan_path.parent/'cpu-link-plan.json')['inputs'])==115
    assert len(read(plan_path.parent/'qwen-link-plan.json')['inputs'])==129

    tests=read(STAGE/'tests/summary.json');process=read(STAGE/'tests/cpu.result.json')
    cases=ET.parse(STAGE/'tests/results.xml').findall('.//testcase')
    names=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases]
    assert tests['passed'] and tests['cases']==len(cases)==20 and tests['skipped']==0
    assert len(set(names))==20 and set(names)==set(plan['exact_tests'])==set(tests['exact_filters'])
    assert all(row.find(tag) is None for row in cases for tag in ('failure','error','skipped'))
    assert process['exit']==0 and process['pid']>0 and tests['build_plan']==plan_id
    assert tests['image']==read(plan_path.parent/'cpu-image.json')

    model=read(STAGE/'correctness/summary.json');observation=model['observation']
    assert model['passed'] and observation['equal_vectors']==len(observation['vectors'])==64
    assert observation['all_outputs_finite'] and observation['same_greedy_ids_as_reference']
    assert observation['same_fixed_decode_inputs'] and len(observation['decode_input_ids'])==31
    assert len(observation['generated_ids'])==32 and model['single_outer_range_32_phases']
    assert model['route']=='hybrid' and observation['image']==read(plan_path.parent/'qwen-image.json')
    inputs=read(STAGE/'correctness/inputs.json');assert inputs['plan']==plan_id
    assert read(STAGE/'correctness/qwen.result.json')['exit']==0
    for row in observation['vectors']:
        assert row['byte_equal'] and row['actual']['bytes']==row['reference']['bytes']
        assert row['actual']['sha256']==row['reference']['sha256']
    perf=read(STAGE/'performance-rotation/summary.json');runs=read(STAGE/'performance-rotation/runs.json')
    assert perf['terminal_zero']==len(runs)==9 and not perf['profiler']
    assert [row['arm'] for row in runs]==perf['order']
    assert all(row['exit']==0 and row['decode_input_ids']==observation['decode_input_ids'] for row in runs)
    assert all(len(perf['groups'][arm]['full31_seconds']['samples'])==3 for arm in ('baseline','current','llama'))

    payloads={}
    def add(path,name):
        path=Path(path).resolve();assert path.is_file() and path.is_relative_to(ROOT),path
        assert name not in payloads or payloads[name]==path,name
        payloads[name]=path

    seal_path=STAGE/'source-freeze.json';seal=read(seal_path)
    assert len(seal['files'])==2
    before_by_source={str(Path(row['source']).resolve()).casefold():row for row in read(STAGE/'probe-source-before.json')}
    source_rows=[]
    for row in seal['files']:
        rel=Path(row.get('source') or row['path']);source=ROOT/rel
        after=check(row['after'],source);check(row['after'],STAGE/'source'/rel)
        before=before_by_source[str(source.resolve()).casefold()]
        check(row['before'],before['snapshot'])
        source_rows.append(dict(source=rel.as_posix(),before=check(before,before['snapshot']),after=after))

    support=set();owners=[];dependencies={}
    for row in plan['frozen']:
        path=Path(row['path']).resolve()
        if path.suffix.lower() in OMIT:continue
        check(row)
        if not path.is_relative_to(STAGE):support.add(path)
    for owner in plan['compile']:
        receipt_path=plan_path.parent/(owner['tag']+'-identity.json');record=read(receipt_path)
        assert record['command']==owner['command'];check(owner['source'])
        source=Path(owner['source']['path']).resolve()
        check(owner['source'],plan_path.parent/'compiled-source'/source.relative_to(ROOT))
        assert any(Path(row['path']).resolve()==(ROOT/'src/graph/plan_state.h').resolve() for row in record['dependencies'])
        for row in [record['source'],*record['dependencies']]:
            path=Path(row['path']).resolve()
            if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('src','include','tests','cmake','third_party'):
                check(row);key=str(path).casefold()
                assert key not in dependencies or dependencies[key]['sha256']==row['sha256']
                dependencies[key]=row
        check(owner['recipe']);support.add(Path(owner['recipe']['path']).resolve())
        owners.append(dict(tag=owner['tag'],source=record['source'],object=record['object'],receipt=identity(receipt_path)))
    for row in dependencies.values():
        path=Path(row['path']).resolve();add(path,PREFIX+'dependency-source/'+path.relative_to(ROOT).as_posix())

    # Follow literal small helper files, never prior stage trees or SDKs.
    pending=[*STAGE.rglob('*.py'),ARCH/'conv-typed-load/build.py'];seen=set()
    while pending:
        path=pending.pop().resolve()
        if path in seen or '__pycache__' in path.parts:continue
        assert path.is_file() and path.is_relative_to(ROOT),path
        seen.add(path);code=path.read_text(encoding='utf-8')
        for variable,base in (('ARCH',ARCH),('STAGE',path.parent),('ROOT',ROOT)):
            pending += [base/value for value in re.findall(variable+r"\s*/\s*['\"]([^'\"]+\.py)['\"]",code)]
        if not path.is_relative_to(STAGE):support.add(path)
    for key in ('manifest','prompt','decode'):
        check(inputs[key]);support.add(Path(inputs[key]['path']).resolve())
    support.add(ROOT/'docs/implementation/tasks/compute/qwen35-2b-local-input.json')
    for rel in ('docs/architecture/compute-design.md','docs/architecture/graph-design.md',
                'docs/developer/current-work.md','docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md'):
        support.add(ROOT/rel)
    for rel in ('conv-typed-load/archive-receipt.json','conv-typed-load/profile/summary.json',
                'batch-graph-capture/archive-receipt.json','batch-graph-capture/correctness-final/summary.json',
                'batch-graph-capture/correctness-final/inputs.json'):
        support.add(ARCH/rel)
    prior_physical=read(ARCH/'conv-typed-load/profile/summary.json')
    assert prior_physical['passed'] and prior_physical['observed_counts']['decode7_kernels']==668
    for path in sorted(support):
        assert path.suffix.lower() not in OMIT
        add(path,PREFIX+'support/'+path.relative_to(ROOT).as_posix())
    for path in STAGE.rglob('*'):
        if path.is_file() and eligible(path):add(path,PREFIX+path.relative_to(STAGE).as_posix())

    scope=dict(source_freeze=identity(seal_path),sources=source_rows,owners=owners,
        host_TUs=9,native_TUs=0,production_PlanState_owners=8,private_CPU_fixture_owners=1,
        CPU_cases=names,CPU_zero_skip=True,equal_vectors=64,unprofiled_processes=9,
        current_batch_physical_trace=False,
        before_Conv_trace_reference=dict(archive=read(ARCH/'conv-typed-load/archive-receipt.json'),
            profile_summary=identity(ARCH/'conv-typed-load/profile/summary.json'),
            observed_counts=prior_physical['observed_counts'],not_a_new_batch_profile=True),
        local_dependencies=list(dependencies.values()),
        reference_vectors='Retained batch-graph-capture archive/reference provenance plus all64actual/reference SHA comparisons; duplicate tensors omitted.',
        retained='Current/before source, cold-index independent review, all9actual owner recipes/dependencies, CPU20XML and logs, model64comparison,9process performance records, scratch before-source timing probe and its frozen private headers, every historical failure in this stage,4current docs snapshots.',
        excluded='Executable/object/library/debug/linkmap/tmp/SDK/model payloads and duplicate64raw tensors; no recursive historical source/SDK copy.',
        limits='CPU transfer/owner/view/capture regressions and one fixed-input CUDA model are distinct scopes. Probe timings are diagnostic; no hardware peer-transfer, independent quality or statistically stable speed acceptance is implied.',
        cleanup_executed=False)
    scope_bytes=(json.dumps(scope,ensure_ascii=False,indent=2)+'\n').encode()
    manifest={name:identity(path) for name,path in sorted(payloads.items())}
    manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,path in sorted(payloads.items()):archive.write(path,name)
        archive.writestr('archive-scope.json',scope_bytes);archive.writestr('payload-sha256.json',manifest_bytes)
    expected={name:row['sha256'] for name,row in manifest.items()}
    expected.update({'archive-scope.json':sha(scope_bytes),'payload-sha256.json':sha(manifest_bytes)})
    # One decompressed pass, checking each payload's CRC32 and SHA256 together.
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist())==len(expected)
        for info in archive.infolist():
            h,crc,size=hashlib.sha256(),0,0
            with archive.open(info) as handle:
                while chunk:=handle.read(1024*1024):
                    h.update(chunk);crc=zlib.crc32(chunk,crc);size+=len(chunk)
            assert size==info.file_size and crc&0xffffffff==info.CRC,info.filename
            assert h.hexdigest()==expected[info.filename],info.filename
    receipt=dict(**identity(DEST),entries=len(expected),payloads=len(manifest),
        build_plan=plan_id,source_freeze=identity(seal_path),host_TUs=9,native_TUs=0,
        CPU_tests=20,equal_vectors=64,unprofiled_processes=9,new_profile=False,
        crc_verified=True,payload_sha256_verified=True,verification_passes=1,
        CRC_and_every_payload_SHA_verified=True,duplicate_raw_vectors_omitted=True,cleanup_executed=False)
    save(STAGE/'archive-receipt.json',receipt)
    save(DEST.with_name('prepare-replay-cold-index-archive.json'),receipt)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
