from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
BASE_PATH = ARCH / 'cuda-bfloat-elementwise-build/candidate-link-plan.json'
FIXTURE = 'tests/compute_provider_ggml_cuda/bfloat_elementwise_test_support.h'
SOURCES = [('tests/compute_provider_ggml_cuda/tensor_test.cc', 'tensor-test'),
           ('tests/graph_provider_ggml_cuda/region_test.cc', 'region-test')]
TESTS = ['GgmlCudaTensor.BfloatTypedElementwiseBroadcastsAndRebindsIndependentSlots',
         'GgmlCudaGraph.BfloatTypedElementwiseMatchesFloatRecipeAndKeepsEveryRoundingBoundary',
         'GgmlCudaIq1.OriginalDecodeMmvqAndMmqExecuteAndReplay']
ATTEMPT = ('-reset-fixed' if '--reset-fixed' in sys.argv[2:] else
           '-graph-api-fixed' if '--graph-api-fixed' in sys.argv[2:] else
           '-fixture-fixed' if '--fixture-fixed' in sys.argv[2:] else '')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


BASE = read(BASE_PATH)['command']
TEMPLATE = read(ARCH / 'ggml-cuda-caller-workspace-tests/tensor-test-identity.json')['command']
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': TEMPLATE[0]})
ENV['VSLANG'] = '1033'
LIB_DIRS = list(dict.fromkeys(str(Path(v).parent) for v in BASE
                            if Path(v).is_absolute() and v.lower().endswith('.lib')))
ENV['PATH'] = os.pathsep.join(LIB_DIRS) + os.pathsep + ENV['PATH']


def execute(tag, argv):
    commands = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    assert not any(row['tag'] == tag for row in commands), 'Preserve actual attempts; no implicit retries'
    stem = f'{len(commands)+1:03d}-{tag}'
    row = dict(tag=tag, command=list(map(str, argv)), cwd=str(ROOT), started=time.time(),
               exit=None, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log')
    commands.append(row)
    save('commands.json', commands)
    print('START', stem, flush=True)
    with (OUT / row['stdout']).open('wb') as so, (OUT / row['stderr']).open('wb') as se:
        process = subprocess.Popen(row['command'], cwd=ROOT, env=ENV, stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = process.pid
        save('live.json', row)
        save('commands.json', commands)
        print('PID', process.pid, flush=True)
        row['exit'] = process.wait()
    row.update(terminal=True, finished=time.time())
    save('live.json', row)
    save('commands.json', commands)
    print('END', stem, row['exit'], round(row['finished']-row['started'], 3), flush=True)
    if row['exit']:
        print((OUT / row['stdout']).read_text(errors='replace')[-7000:], flush=True)
        print((OUT / row['stderr']).read_text(errors='replace')[-5000:], flush=True)
        raise SystemExit(row['exit'])


def prepare():
    freeze = read(ARCH / 'cuda-bfloat-elementwise/source-freeze.json')
    wanted = {source for source, name in SOURCES} | {FIXTURE}
    identities = []
    for row in freeze['sources']:
        if row['path'] not in wanted:
            continue
        source = ROOT / row['path']
        got = ident(source)
        assert got['bytes'] == row['bytes'] and got['sha256'] == row['sha256']
        destination = OUT / 'candidate' / row['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
        identities.append(got)
    assert len(identities) == 3
    save('source-identities.json', dict(source_freeze=ident(ARCH / 'cuda-bfloat-elementwise/source-freeze.json'),
                                       sources=identities))
    save('run-plan.json', dict(command=[str(OUT / 'bfloat-tests.exe'),
        '--gtest_filter='+':'.join(TESTS), '--gtest_color=no',
        '--gtest_output=xml:'+str(OUT / 'tests.xml')], cwd=str(ROOT),
        path_prepend=LIB_DIRS, tests=TESTS, not_run=True,
        scope='Only two new BF16 cases plus one existing canonical IQ1 integrity case. '
              'No GPU execution until parent explicitly releases the window.'))
    print('Prepared exact three-case run-plan; no GPU launched.', flush=True)


def compile_one(source, name):
    source = ROOT / source
    before = ident(source)
    receipt = OUT / (name+'-identity.json')
    if receipt.exists():
        existing = read(receipt)
        if existing['source'] == before:
            assert ident(existing['object']['path']) == existing['object']
            print('REUSE unchanged successful fresh test object:', name, flush=True)
            return
        assert ATTEMPT == '-reset-fixed' and name == 'region-test', 'Unexpected source drift'
    argv = []
    skip = False
    for item in TEMPLATE:
        if skip:
            skip = False
            continue
        if item.lower() == '/sourcedependencies':
            skip = True
            continue
        if item.lower().startswith(('/fo', '/fd')) or item.lower().endswith('.cc'):
            continue
        argv.append(item)
    assert '/W4' in argv and '/WX' in argv
    argv += ['/sourceDependencies', str(OUT / (name+'-deps.json')), str(source),
             '/Fo'+str(OUT / (name+'.obj'))]
    execute(name+'-compile'+ATTEMPT, argv)
    assert ident(source) == before
    includes = read(OUT / (name+'-deps.json'))['Data']['Includes']
    local = [ident(p) for p in includes if Path(p).resolve().is_relative_to(ROOT)]
    assert any(Path(row['path']) == ROOT / FIXTURE for row in local)
    save(name+'-identity.json', dict(source=before, object=ident(OUT / (name+'.obj')),
                                    command=argv, hyle_dependencies=local))


def build():
    prepare()
    products = []
    for name in ['ggml-cuda', 'binbcast', 'unary', 'tensor-current']:
        receipt = read(ARCH / 'cuda-bfloat-elementwise-build' / (name+'-identity.json'))
        obj = receipt['object']
        assert ident(obj['path']) == obj
        assert BASE.count(obj['path']) == 1
        products.append(dict(name=name, object=obj,
                             compile_receipt=ident(ARCH / 'cuda-bfloat-elementwise-build' / (name+'-identity.json'))))
    for name in ['provider', 'adapter']:
        obj = ARCH / 'ggml-cuda-caller-workspace' / (name+'.obj')
        assert BASE.count(str(obj)) == 1
        products.append(dict(name='caller-'+name, object=ident(obj)))
    iq1 = read(ARCH / 'ggml-cuda-caller-workspace-tests/iq1-test-identity.json')
    assert ident(iq1['object']['path']) == iq1['object']
    save('reused-iq1-identity.json', iq1)
    for source, name in SOURCES:
        compile_one(source, name)
    consumer = str(ARCH / 'qwen-gpu-comparison/hyle-consumer.obj')
    assert BASE.count(consumer) == 1
    argv = [x for x in BASE if x != consumer and
            not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    argv[1:1] = [str(OUT / (name+'.obj')) for source, name in SOURCES] + [iq1['object']['path']]
    argv += [str(ROOT / '.scratch/build-compute-v2-dev/lib' / name)
             for name in ['gtest_main.lib', 'gtest.lib']]
    argv += ['/OUT:'+str(OUT / 'bfloat-tests.exe'), '/MAP:'+str(OUT / 'bfloat-tests.map'),
             '/IMPLIB:'+str(OUT / 'bfloat-tests.lib')]
    assert not any('cuda-native-matvec' in x or 'cuda-vector-matmul' in x for x in argv)
    assert all(Path(x).is_file() for x in argv if Path(x).is_absolute()
               and Path(x).suffix.lower() in {'.obj', '.lib'})
    save('link-plan.json', dict(command=argv, base=ident(BASE_PATH), selected_products=products,
        only_changes=['remove Qwen consumer', 'insert two fresh test objects and one reused IQ1 object',
                      'gtest libraries and output image/map paths']))
    execute('bfloat-tests-link'+ATTEMPT, argv)
    lines = (OUT / 'bfloat-tests.map').read_text(errors='replace').splitlines()
    old_members = [line for line in lines if 'ggml-cuda.lib:' in line.lower() and
                   any(name in line.lower() for name in
                       ['binbcast.cu.obj', 'unary.cu.obj', 'ggml-cuda.cu.obj'])]
    selected = products + [dict(name=name, object=ident(OUT / (name+'.obj')))
                           for source, name in SOURCES] + [dict(name='reused-iq1', object=iq1['object'])]
    for row in selected:
        matches = [line for line in lines if line.split() and
                   line.split()[-1].lower() == Path(row['object']['path']).name.lower()]
        assert matches, row['name']+' not present in actual map'
        row['map_mentions'] = len(matches)
        row['sample_map_lines'] = matches[:5]
    save('map-owners.json', dict(map=ident(OUT / 'bfloat-tests.map'), selected=selected,
                                old_replaced_native_library_members=old_members))
    assert not old_members
    save('summary.json', dict(status='two_fresh_test_TUs_linked_not_run', tests=TESTS,
        source_identities=ident(OUT / 'source-identities.json'),
        fresh_test_objects=[read(OUT / (name+'-identity.json'))['object'] for source, name in SOURCES],
        reused_iq1=iq1['object'], selected_products=products,
        map_owners=ident(OUT / 'map-owners.json'), image=ident(OUT / 'bfloat-tests.exe'),
        commands=[dict(tag=row['tag'], exit=row['exit']) for row in read(OUT / 'commands.json')],
        product_or_native_compilation=False, gpu_execution=False, sdk_rebuild=False))
    save('cleanup-windows.json', dict(root=str(OUT), files=[ident(OUT / ('bfloat-tests'+suffix))
        for suffix in ['.exe', '.map', '.lib', '.exp'] if (OUT / ('bfloat-tests'+suffix)).exists()],
        retain=[read(OUT / (name+'-identity.json'))['object'] for source, name in SOURCES],
        delete_executed=False))
    print('FROZEN: two strict test compilations and matched link terminal success; GPU not run.', flush=True)


if __name__ == '__main__':
    assert sys.argv[1:] in [['prepare'], ['build'], ['build', '--fixture-fixed'],
                           ['build', '--graph-api-fixed'], ['build', '--reset-fixed']]
    build() if sys.argv[1] == 'build' else prepare()
