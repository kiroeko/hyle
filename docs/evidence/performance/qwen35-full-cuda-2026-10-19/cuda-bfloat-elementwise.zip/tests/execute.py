from pathlib import Path
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

spec = importlib.util.spec_from_file_location('test_build_recipe', Path(__file__).with_name('build.py'))
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
plan = recipe.read(recipe.OUT / 'run-plan.json')
graph_only = sys.argv[1:] in [['--graph-only'], ['--collect-graph-only']]
assert sys.argv[1:] in [[], ['--graph-only'], ['--collect-graph-only']]
if graph_only:
    command = [plan['command'][0], '--gtest_filter='+recipe.TESTS[1], '--gtest_color=no',
               '--gtest_output=xml:'+str(recipe.OUT / 'graph-final-tests.xml')]
    recipe.save('graph-final-run-plan.json', dict(command=command, cwd=str(recipe.ROOT),
        path_prepend=recipe.LIB_DIRS, scope='Only previously failing Graph fixture, Direct/IQ1 not repeated.'))
    if sys.argv[1:] == ['--collect-graph-only']:
        recorded = next(row for row in recipe.read(recipe.OUT / 'commands.json')
                        if row['tag'] == 'bfloat-graph-final-test-run')
        assert recorded['exit'] == 0 and recorded['terminal']
    else:
        recipe.execute('bfloat-graph-final-test-run', command)
else:
    recipe.execute('bfloat-three-tests-run', plan['command'])
xml = ET.parse(recipe.OUT / ('graph-final-tests.xml' if graph_only else 'tests.xml')).getroot()
assert xml.attrib['tests'] == ('1' if graph_only else '3')
assert xml.attrib['failures'] == xml.attrib['errors'] == '0'
assert len(list(xml.iter('testcase'))) == (1 if graph_only else 3)
summary = recipe.read(recipe.OUT / 'summary.json')
if graph_only:
    old_xml = ET.parse(recipe.OUT / '006-tests.xml').getroot()
    passed = [case.attrib['classname']+'.'+case.attrib['name'] for case in old_xml.iter('testcase')
              if case.find('failure') is None]
    assert passed == [recipe.TESTS[0], recipe.TESTS[2]]
    before = recipe.read(recipe.OUT / '006-run-summary.json')
    assert {row['name']: row['object'] for row in before['selected_products']} == {
        row['name']: row['object'] for row in summary['selected_products']}
    summary.update(status='three_unique_cases_passed_across_initial_and_corrected_graph_runs',
        gpu_execution=True, tests_passed=3, tests_failed=0,
        earlier_run=dict(xml=recipe.ident(recipe.OUT / '006-tests.xml'), passed=passed, failed=recipe.TESTS[1]),
        final_graph_xml=recipe.ident(recipe.OUT / 'graph-final-tests.xml'),
        scope_note='Original run2/3, corrected Graph fixture1/1. Product owners unchanged; '
                   'Direct/IQ1 passes not repeated and not represented as a single final3/3 run.')
else:
    summary.update(status='three_exact_cases_terminal_pass', gpu_execution=True,
                   tests_passed=3, tests_failed=0, xml=recipe.ident(recipe.OUT / 'tests.xml'))
recipe.save('summary.json', summary)
print('All3 unique cases PASS across recorded runs; GPU process exited. No further tests launched.')
