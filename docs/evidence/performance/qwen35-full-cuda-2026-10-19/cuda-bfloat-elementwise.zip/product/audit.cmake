include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)
message(STATUS "BF16 elementwise manifest and license identity PASS")
