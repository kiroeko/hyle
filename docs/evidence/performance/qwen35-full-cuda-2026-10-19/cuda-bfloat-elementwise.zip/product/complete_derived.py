from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
path = ROOT/'.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/build.py'
spec = importlib.util.spec_from_file_location('canonical_native_source', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
contents, manifest, source_id = module.generate(False)
identities=[]
for name in ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/binbcast.cu', 'src/ggml-cuda/unary.cu']:
    data=contents[name]
    output=STAGE/'native-source'/name
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(data)
    identities.append(dict(path=str(output),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
name='src/ggml-cuda/common.cuh'
common=contents[name]
reference=ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows'/name
assert common == reference.read_bytes(), 'current canonical common must match reference headers'
identities.append(dict(path=str(reference),bytes=len(common),sha256=hashlib.sha256(common).hexdigest(),current_canonical_match=True))
assert contents['src/ggml-cuda/ggml-cuda.cu'].count(b'case GGML_TYPE_IQ1_XS:') == 1
(STAGE/'complete-source-identities.json').write_text(json.dumps(dict(source_id=source_id,canonical_generator=str(path),files=identities),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(source_id=source_id,files=identities),indent=2))
