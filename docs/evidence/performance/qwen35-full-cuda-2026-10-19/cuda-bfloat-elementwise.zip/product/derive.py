from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST = ROOT / 'third_party/ggml_cuda_runtime/patches.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def append_edit(item, text, before, after):
    assert text.count(before) == 1, (item['path'], text.count(before), before)
    item['edits'].append(dict(before=before, after=after))
    return text.replace(before, after)

manifest = json.loads(MANIFEST.read_text())
texts = {}
for item in manifest['files']:
    data = (RAW / item['path']).read_bytes()
    assert sha(data) == item['before_sha256'], item['path']
    text = data.decode()
    for edit in item['edits']:
        assert text.count(edit['before']) == 1, item['path']
        text = text.replace(edit['before'], edit['after'])
    assert sha(text.encode()) == item['after_sha256'], item['path']
    texts[item['path']] = text

main = next(x for x in manifest['files'] if x['path'] == 'src/ggml-cuda/ggml-cuda.cu')
text = texts[main['path']]
text = append_edit(main, text,
    '    if (node->op == GGML_OP_ADD || node->op == GGML_OP_MUL) {\n        int     n_fuse = 0;',
    '    // Each BF16 operation has its own public rounding boundary.\n'
    '    if ((node->op == GGML_OP_ADD || node->op == GGML_OP_MUL) && node->type != GGML_TYPE_BF16) {\n        int     n_fuse = 0;')
text = append_edit(main, text,
    '        case GGML_OP_UNARY:\n            switch (ggml_get_unary_op(op)) {',
    '        case GGML_OP_UNARY:\n'
    '            if (op->src[0]->type == GGML_TYPE_BF16 || op->type == GGML_TYPE_BF16) {\n'
    '                if (op->src[0]->type != GGML_TYPE_BF16 || op->type != GGML_TYPE_BF16) {\n'
    '                    return false;\n'
    '                }\n'
    '                switch (ggml_get_unary_op(op)) {\n'
    '                    case GGML_UNARY_OP_ABS:\n'
    '                    case GGML_UNARY_OP_NEG:\n'
    '                    case GGML_UNARY_OP_EXP:\n'
    '                    case GGML_UNARY_OP_TANH:\n'
    '                    case GGML_UNARY_OP_SIGMOID:\n'
    '                        return ggml_is_contiguous(op->src[0]);\n'
    '                    default:\n'
    '                        return false;\n'
    '                }\n'
    '            }\n'
    '            switch (ggml_get_unary_op(op)) {')
text = append_edit(main, text,
    '                // the CUDA REPEAT path only implements F32/F16; other types assert at runtime\n'
    '                ggml_type src0_type = op->src[0]->type;\n'
    '                return src0_type == GGML_TYPE_F32 || src0_type == GGML_TYPE_F16;',
    '                // Typed REPEAT is a bit-preserving broadcast for these carriers.\n'
    '                ggml_type src0_type = op->src[0]->type;\n'
    '                return src0_type == GGML_TYPE_F32 || src0_type == GGML_TYPE_F16 ||\n'
    '                       (src0_type == GGML_TYPE_BF16 && op->type == GGML_TYPE_BF16);')
text = append_edit(main, text,
    '            return (op->src[0]->type == GGML_TYPE_F32 || op->src[0]->type == GGML_TYPE_F16) &&\n'
    '                   (op->src[1]->type == GGML_TYPE_F32 || op->src[1]->type == GGML_TYPE_F16) &&\n'
    '                   (op->type         == GGML_TYPE_F32 || op->type         == GGML_TYPE_F16);',
    '            return ((op->src[0]->type == GGML_TYPE_F32 || op->src[0]->type == GGML_TYPE_F16) &&\n'
    '                    (op->src[1]->type == GGML_TYPE_F32 || op->src[1]->type == GGML_TYPE_F16) &&\n'
    '                    (op->type         == GGML_TYPE_F32 || op->type         == GGML_TYPE_F16)) ||\n'
    '                   (op->src[0]->type == GGML_TYPE_BF16 &&\n'
    '                    op->src[1]->type == GGML_TYPE_BF16 && op->type == GGML_TYPE_BF16);')
main['after_sha256'] = sha(text.encode())
texts[main['path']] = text

for name in ['binbcast', 'unary']:
    path = f'src/ggml-cuda/{name}.cu'
    assert all(x['path'] != path for x in manifest['files'])
    data = (RAW / path).read_bytes()
    item = dict(path=path, before_sha256=sha(data), after_sha256='', edits=[])
    text = data.decode()
    if name == 'binbcast':
        text = append_edit(item, text,
            '    GGML_ASSERT(src1->type == GGML_TYPE_F32 || src1->type == GGML_TYPE_F16);\n\n'
            '    if (src0->type == GGML_TYPE_F32 && dst->type == GGML_TYPE_F32) {',
            '    if (src0->type == GGML_TYPE_BF16 && src1->type == GGML_TYPE_BF16 && dst->type == GGML_TYPE_BF16) {\n'
            '        op()(src0, src1, dst, (const nv_bfloat16 *)src0_dd, (const nv_bfloat16 *)src1_dd, (nv_bfloat16 *)dst_dd, stream);\n'
            '        return;\n'
            '    }\n\n'
            '    GGML_ASSERT(src1->type == GGML_TYPE_F32 || src1->type == GGML_TYPE_F16);\n\n'
            '    if (src0->type == GGML_TYPE_F32 && dst->type == GGML_TYPE_F32) {')
    else:
        tail = ('\n    GGML_ASSERT(src0->type == dst->type);\n\n'
                '    if (src0->type == GGML_TYPE_F16) {\n'
                '        unary_cuda<op>((const half *)src0_d, (half *)dst_d, ggml_nelements(src0), stream);')
        text = append_edit(item, text,
            '    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);\n'
            '    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);' + tail,
            '    if constexpr (op == op_abs || op == op_neg || op == op_exp || op == op_log ||\n'
            '                  op == op_sqrt || op == op_tanh || op == op_sigmoid) {\n'
            '        if (src0->type == GGML_TYPE_BF16 && dst->type == GGML_TYPE_BF16) {\n'
            '            unary_cuda<op>((const nv_bfloat16 *)src0_d, (nv_bfloat16 *)dst_d, ggml_nelements(src0), stream);\n'
            '            return;\n'
            '        }\n'
            '    }\n\n'
            '    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);\n'
            '    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);' + tail)
    item['after_sha256'] = sha(text.encode())
    manifest['files'].append(item)
    texts[path] = text

MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
identities=[]
for path, text in texts.items():
    output=STAGE/'derived'/path
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(text, encoding='utf-8', newline='\n')
    identities.append(dict(path=path, bytes=len(text.encode()), sha256=sha(text.encode())))
(STAGE/'derived-identities.json').write_text(json.dumps(identities,indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(identities,indent=2))
