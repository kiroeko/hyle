"""Archive this bounded BF16 change without repeating baseline vectors or SDKs."""
from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
BUILD = ARCH / "cuda-bfloat-elementwise-build"
TESTS = ARCH / "cuda-bfloat-elementwise-tests"
EVIDENCE = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19"
TARGET = EVIDENCE / "cuda-bfloat-elementwise.zip"
BASELINE = EVIDENCE / "ggml-cuda-caller-workspace.zip"
BASELINE_SHA = "d44a9be92dfc6df6c86e56d4dfe27aa7bd38aa3be9986336fa563d2d639e50dd"
ALLOWED = {".json", ".diff", ".cc", ".h", ".cu", ".cuh", ".py", ".log", ".xml", ".txt", ".tsv", ".csv", ".cmake", ".md", ".d"}
GENERATED = {"archive-inventory.json", "archive-receipt.json"}


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))


def decision_reference():
    baseline = identity(BASELINE)
    assert baseline["sha256"] == BASELINE_SHA
    parity = read(BUILD / "decisions-parity.json")
    assert parity["equal_vectors"] == parity["total_vectors"] == len(parity["vectors"]) == 128
    rows = []
    verified_stored = {}
    with zipfile.ZipFile(BASELINE) as archive:
        manifest = read_manifest = json.loads(archive.read("manifest.json"))
        logical = {item["name"]: item for item in manifest["entries"]}
        for item in parity["vectors"]:
            assert item["equal"]
            relative = item["path"].replace("\\", "/")
            raw = BUILD / f"candidate{item['scene']}-decisions/trace" / relative
            raw_identity = identity(raw)
            assert (raw_identity["bytes"], raw_identity["sha256"]) == (item["bytes"], item["sha256"])
            name = f"measurement/candidate{item['scene']}-decisions/trace/{relative}"
            prior = logical[name]
            assert (prior["bytes"], prior["sha256"]) == (item["bytes"], item["sha256"])
            stored = prior["stored_as"]
            if stored not in verified_stored:
                data = archive.read(stored)
                verified_stored[stored] = (len(data), sha(data))
            assert verified_stored[stored] == (item["bytes"], item["sha256"])
            rows.append(dict(scene=item["scene"], logical_path=relative,
                             retained_raw=raw_identity, baseline_logical=name,
                             baseline_stored_as=stored))
    result = dict(baseline_archive=baseline, vectors=rows, matched_vectors=128,
                  unique_baseline_payloads_verified=len(verified_stored),
                  raw_data_deleted=False, raw_data_in_this_archive=False,
                  note="All current decision vectors retain their scratch copies and exactly match the referenced previous archive payloads.")
    (BUILD / "decision-payload-reference.json").write_bytes(encoded(result))
    return result


def validate_results():
    sources = read(OUT / "source-freeze.json")["sources"]
    for item in sources:
        actual = identity(ROOT / item["path"])
        assert (actual["bytes"], actual["sha256"]) == (item["bytes"], item["sha256"]), item["path"]
    perf = read(BUILD / "performance-summary.json")
    assert perf["decision_vectors_bit_identical"] == 128
    assert perf["all_prediction_ids_equal"]
    for arm in ["before", "candidate"]:
        assert len(perf["groups"][arm]["decode_warm_tokens_per_second"]["samples"]) == 3
    for path in BUILD.glob("perf128-*/result.json"):
        assert read(path)["exit"] == 0
    original = list(ET.parse(TESTS / "006-tests.xml").getroot().iter("testcase"))
    final = list(ET.parse(TESTS / "graph-final-tests.xml").getroot().iter("testcase"))
    assert len(original) == 3 and len(final) == 1
    passed = {item.attrib["classname"] + "." + item.attrib["name"] for item in original if not item.findall("failure")}
    failed = {item.attrib["classname"] + "." + item.attrib["name"] for item in original if item.findall("failure")}
    final_passed = {item.attrib["classname"] + "." + item.attrib["name"] for item in final if not list(item)}
    assert len(passed) == 2 and failed == final_passed and len(final_passed) == 1
    return dict(unique_regressions_passed=sorted(passed | final_passed),
                original_three_case_run="2 passed; Graph fixture failed",
                corrected_graph_only_run="1 passed", source_drift=0,
                performance="Three unprofiled paired fresh processes per arm; no peer rerun or quality acceptance.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--trace-summary", type=Path)
    parser.add_argument("--trace-receipt", type=Path)
    args = parser.parse_args()
    results = validate_results()
    vectors = decision_reference()
    payloads = {}
    excluded = []
    for prefix, folder in [("product", OUT), ("build", BUILD), ("tests", TESTS)]:
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            name = prefix + "/" + path.relative_to(folder).as_posix()
            if path.name in GENERATED or path.suffix.lower() not in ALLOWED or any(x in path.parts for x in ["__pycache__", "tmp"]):
                excluded.append(dict(path=name, bytes=path.stat().st_size))
                continue
            payloads[name] = (path, path.read_bytes())
    if args.trace_summary or args.trace_receipt:
        assert args.trace_summary and args.trace_receipt
        for name, path in [("trace/summary.json", args.trace_summary), ("trace/archive-receipt.json", args.trace_receipt)]:
            payloads[name] = (path, path.read_bytes())
    elif args.write:
        raise SystemExit("Final write requires the frozen small trace summary and independent archive receipt.")
    entries = [dict(path=name, bytes=len(data), sha256=sha(data)) for name, (_, data) in sorted(payloads.items())]
    inventory = dict(schema="hyle.cuda.bfloat.elementwise.archive.v1", output=str(TARGET), files=entries,
                     payload_files=len(entries), payload_bytes=sum(item["bytes"] for item in entries),
                     excluded=excluded, results=results,
                     baseline_vector_archive=vectors["baseline_archive"], referenced_vectors=128,
                     exclusions="No objects, images, maps, libraries, SDK/model copies, raw decision vectors, raw profiler reports or previous ZIP payloads.",
                     deletion_performed=False)
    manifest = encoded(inventory)
    (OUT / "archive-inventory.json").write_bytes(manifest)
    if not args.write:
        print(json.dumps({key: inventory[key] for key in ["payload_files", "payload_bytes", "referenced_vectors"]}))
        return
    with zipfile.ZipFile(TARGET, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (_, data) in sorted(payloads.items()):
            archive.writestr(name, data)
        archive.writestr("archive-manifest.json", manifest)
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(entries) + 1
        assert archive.read("archive-manifest.json") == manifest
        for item in entries:
            data = archive.read(item["path"])
            assert (len(data), sha(data)) == (item["bytes"], item["sha256"])
    for path, data in payloads.values():
        assert path.read_bytes() == data, str(path)
    receipt = dict(archive=identity(TARGET), entries=len(entries) + 1,
                   payload_files=len(entries), payload_bytes=inventory["payload_bytes"],
                   crc_verified=True, every_payload_sha256_verified=True, source_drift=0,
                   baseline_decision_vectors_verified=128, copied_decision_vectors=0,
                   retained_scratch_raw_data=True, deleted_files=0,
                   cleanup_candidates=identity(BUILD / "cleanup-candidates.json"))
    (OUT / "archive-receipt.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
