from pathlib import Path
import ctypes
import hashlib
import json
import subprocess

stage = Path(__file__).resolve().parent
root = stage.parents[3]
plan_path = root / '.scratch/architecture-refactor-2026-10-18/cuda-fusion-layout/checks/20261019T105435/cuda-link-plan.json'
plan = json.loads(plan_path.read_text())
dumpbin = Path(plan['command'][0]).with_name('dumpbin.exe')
objects = []
for name in ('ggml-cuda.obj', 'mmvf.obj', 'mmvq.obj', 'unary.obj'):
    candidates = [r for r in plan['inputs'] if Path(r['path']).name == name]
    assert len(candidates) == 1
    row = candidates[0]
    path = Path(row['path'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    run = subprocess.run([str(dumpbin), '/symbols', str(path)], capture_output=True, text=True)
    assert run.returncode == 0, run.stderr
    symbols = [line.strip() for line in run.stdout.splitlines()
               if 'External' in line and '| ?ggml_cuda_mul_mat_vec_f@@' in line]
    objects.append({'path':str(path.relative_to(root)), 'sha256':row['sha256'], 'host_carrier_symbols':symbols})
for row in objects:
    name = Path(row['path']).name
    if name in ('mmvq.obj', 'unary.obj'):
        assert not row['host_carrier_symbols']
    else:
        assert len(row['host_carrier_symbols']) == 1
        assert ('UNDEF' in row['host_carrier_symbols'][0]) == (name == 'ggml-cuda.obj')

new_fields = [(name, ctypes.c_void_p) for name in ('x_bias','gate','gate_bias','x_scale','gate_scale')]
new_fields += [('glu_op',ctypes.c_int),('glu_limit',ctypes.c_float),('glu_alpha',ctypes.c_float)]
class Old(ctypes.Structure):
    _fields_ = new_fields[:-1]
class New(ctypes.Structure):
    _fields_ = new_fields
assert ctypes.sizeof(ctypes.c_void_p) == 8
assert ctypes.sizeof(Old) == 48 and ctypes.sizeof(New) == 56
assert New.glu_limit.offset == Old.glu_limit.offset == 44
assert New.glu_alpha.offset == 48

# Check new deltas also apply before the retained IQ1 edits, as sealing does.
deltas = json.loads((stage/'replacements.json').read_text())['files']
iq1 = {r['path']:r for r in json.loads((root/'third_party/ggml_cuda_runtime/iq1-patches.json').read_text())['files']}
cuda = {r['path']:r for r in json.loads((root/'.scratch/architecture-refactor-2026-10-18/cuda-fusion-layout/patches.draft.json').read_text())['files']}
upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
composition = []
for row in deltas:
    prior = cuda[row['path']]
    old = (upstream/row['path']).read_bytes().replace(b'\r\n',b'\n').decode()
    assert hashlib.sha256(old.encode()).hexdigest() == prior['before_sha256']
    for edit in prior['edits']:
        assert old.count(edit['before']) == 1
        old = old.replace(edit['before'],edit['after'],1)
    assert hashlib.sha256(old.encode()).hexdigest() == prior['after_sha256']
    edits = iq1.get(row['path'], {}).get('edits', [])
    original = old
    for edit in edits:
        assert original.count(edit['before']) == 1
        original = original.replace(edit['before'],edit['after'],1)
    assert hashlib.sha256(original.encode()).hexdigest() == row['before_sha256']
    for edit in [*row['edits'],*edits]:
        assert old.count(edit['before']) == 1
        old = old.replace(edit['before'],edit['after'],1)
    assert hashlib.sha256(old.encode()).hexdigest() == row['after_sha256']
    composition.append({'path':row['path'],'IQ1_after_new_delta':True,'IQ1_edits':len(edits)})

result = {'state':'Read-only source and retained COFF symbol review; no compile/GPU.',
          'objects':objects,
          'mandatory_precision_callers':'Four ordinary plus three fused callers, all in main. No MMVQ/unary reference to this host carrier symbol.',
          'old_struct_incremental_closure':'Precision-only change needs fresh main/mmvf. Full OAI changes the by-value fusion struct, so fresh main/mmvf/mmvq/unary are required even though two do not call the host MMVF symbol.',
          'x64_layout_model':{'old_bytes':ctypes.sizeof(Old),'new_bytes':ctypes.sizeof(New),
                              'old_limit_offset':Old.glu_limit.offset,'new_limit_offset':New.glu_limit.offset,
                              'new_alpha_offset':New.glu_alpha.offset},
          'composition':composition}
(stage/'closure-review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'retained_objects_checked':len(objects),'compositions_checked':len(composition),
                  'replacements_sha256':hashlib.sha256((stage/'replacements.json').read_bytes()).hexdigest(),
                  'freeze_sha256':hashlib.sha256((stage/'source-freeze.json').read_bytes()).hexdigest()}))
