from pathlib import Path
import difflib
import hashlib
import json
import re

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
V19 = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-fusion-layout'
PRECISION = STAGE.parent / 'native-overlay'
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()

def replay(relative):
    row = next(r for r in json.loads((V19 / 'combined-manifest.json').read_text())['files'] if r['path'] == relative)
    text = (UPSTREAM / relative).read_bytes().replace(b'\r\n', b'\n').decode()
    assert sha(text) == row['before_sha256']
    for edit in row['edits']:
        assert text.count(edit['before']) == 1
        text = text.replace(edit['before'], edit['after'], 1)
    assert sha(text) == row['after_sha256']
    return text

files, diffs = [], []
def emit(relative, before, after, before_path):
    target = STAGE / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after, encoding='utf-8', newline='\n')
    old_lines, new_lines = before.splitlines(True), after.splitlines(True)
    context = 3
    while True:
        edits = [{'before': ''.join(old_lines[g[0][1]:g[-1][2]]),
                  'after': ''.join(new_lines[g[0][3]:g[-1][4]])}
                 for g in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_grouped_opcodes(context)]
        result = before
        for edit in edits:
            if not edit['before'] or result.count(edit['before']) != 1:
                break
            result = result.replace(edit['before'], edit['after'], 1)
        else:
            if result == after:
                break
        context *= 2
        assert context < len(old_lines) * 2
    files.append({'path':relative, 'before_path':str(before_path.relative_to(ROOT)),
                  'before_sha256':sha(before), 'after_sha256':sha(after), 'edits':edits})
    diffs.append(''.join(difflib.unified_diff(old_lines, new_lines, fromfile='a/'+relative, tofile='b/'+relative)))

precision_files = {r['path']:r for r in json.loads((PRECISION / 'source-freeze.json').read_text())['files']}
for relative in ('src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/mmvf.cuh', 'src/ggml-cuda/mmvf.cu'):
    row = precision_files[relative]
    before_path = ROOT / row['before_path']
    before = before_path.read_text(encoding='utf-8')
    assert sha(before) == row['before_sha256']
    after = (PRECISION / 'source' / relative).read_text(encoding='utf-8')
    assert sha(after) == row['after_sha256']
    if relative.endswith('ggml-cuda.cu'):
        old = '''    // These existing OAI epilogues hard-code their scalar parameters.
    // Arbitrary alpha/limit remain supported by the original separate GLU.
    if (ggml_get_glu_op(glu) == GGML_GLU_OP_SWIGLU_OAI &&
        (ggml_get_op_params_f32(glu, 2) != 1.702f || ggml_get_op_params_f32(glu, 3) != 7.0f)) {
        return false;
    }
'''
        assert after.count(old) == 1
        after = after.replace(old, '', 1)
        pattern = re.compile(r'(?m)^( +)fusion_data\.glu_limit( +)= ggml_get_op_params_f32\(glu, 3\);$')
        assert len(pattern.findall(after)) == 6
        after = pattern.sub(lambda match: match.group(0) + '\n' + match.group(1) +
                            'fusion_data.glu_alpha' + match.group(2) + '= ggml_get_op_params_f32(glu, 2);', after)
    elif relative.endswith('mmvf.cuh'):
        old = 'ggml_cuda_op_swiglu_oai_single(gate_value, value)'
        assert after.count(old) == 1
        after = after.replace(old, 'ggml_cuda_op_swiglu_oai_single(gate_value, value, fusion.glu_alpha, glu_limit)', 1)
    else:
        old = '        fusion_local.glu_limit = fusion->glu_limit;'
        assert after.count(old) == 1
        after = after.replace(old, old + '\n        fusion_local.glu_alpha = fusion->glu_alpha;', 1)
    emit(relative, before, after, before_path)

relative = 'src/ggml-cuda/mmvq.cu'
before_path = V19 / 'native-source' / relative
before = before_path.read_text(encoding='utf-8')
assert sha(before) == '23e8381243054cf41c8c96e28ba31715c32d4bbaffd0bde09e6b7558e4f1bc81'
after = before
old = 'ggml_cuda_op_swiglu_oai_single(gate_value, result)'
assert after.count(old) == 2
after = after.replace(old, 'ggml_cuda_op_swiglu_oai_single(gate_value, result, fusion.glu_alpha, glu_limit)')
old = '        fusion_local.glu_limit = fusion->glu_limit;'
assert after.count(old) == 1
after = after.replace(old, old + '\n        fusion_local.glu_alpha = fusion->glu_alpha;', 1)
emit(relative, before, after, before_path)

relative = 'src/ggml-cuda/common.cuh'
before_path = STAGE / 'before/common.cuh'
if before_path.is_file():
    before = before_path.read_text(encoding='utf-8')
else:
    before = replay(relative)
    before_path.parent.mkdir(parents=True, exist_ok=True)
    before_path.write_text(before, encoding='utf-8', newline='\n')
assert sha(before) == '120d79b9df46d0973018bee2666ac7ed4c5cb137b96434056e7e7311682685b2'
old = '    float glu_limit = 0.0f;\n};'
assert before.count(old) == 2
after = before.replace(old, '    float glu_limit = 0.0f;\n    float glu_alpha = 1.702f;\n};')
emit(relative, before, after, before_path)

# Recompile the unchanged precise unary source next to the changed private
# headers. Quoted includes then cannot silently pick an older cached MMVF TU.
unary_path = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-explicit-rope/native-source/src/ggml-cuda/unary.cu'
unary = unary_path.read_bytes()
assert hashlib.sha256(unary).hexdigest() == '7a283d50fe91f958c544ede60b27fdbdb579ae413ac3b86893b5d5eb57b6b13b'
(STAGE / 'source/src/ggml-cuda/unary.cu').write_bytes(unary)

(STAGE / 'replacements.json').write_text(json.dumps({'files':files}, indent=2)+'\n', encoding='utf-8', newline='\n')
(STAGE / 'changes.diff').write_text(''.join(diffs), encoding='utf-8', newline='\n')
freeze = {'state':'Independent complete precision+OAI overlay against current v19, no product/compile/GPU changes.',
          'files':[{k:v for k,v in row.items() if k!='edits'} for row in files],
          'unchanged_recompile_sources':[{'path':'src/ggml-cuda/unary.cu', 'before_path':str(unary_path.relative_to(ROOT)),
                                         'sha256':hashlib.sha256(unary).hexdigest()}],
          'precision_callers':{'ordinary':4,'fused':3,'mandatory_private_argument':True},
          'OAI':{'original_GLU_parameters':'op_params[2]=alpha, op_params[3]=limit',
                 'main_construct_sites':6,'host_to_device_copy_sites':2,'device_epilogues':3,
                 'struct_layout':'On retained x64 ABI, both private fusion structs append alpha after existing limit; 48->56 bytes, no existing field offset moved.',
                 'fresh_TUs':['ggml-cuda.cu','mmvf.cu','mmvq.cu','unary.cu'],
                 'reuse_forbidden':'Do not link cached SDK by-value MMVF/MMVQ or unary shared-template instances with the new fusion structs.',
                 'no_special_case_fallback':'Nondefault alpha/limit now reach the existing same OAI helper; the temporary parameter restriction has been removed.'}}
(STAGE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'files':len(files),'unchanged_fresh_TUs':1,
                  'freeze_sha256':hashlib.sha256((STAGE/'source-freeze.json').read_bytes()).hexdigest(),
                  'sources':[(row['path'],row['after_sha256']) for row in files]}))
