from pathlib import Path
import hashlib
import json

stage = Path(__file__).resolve().parent
root = stage.parents[3]
source = stage / 'source/src/ggml-cuda'
read = lambda name: (source/name).read_text(encoding='utf-8')
main, mmvf, header, mmvq, common = (read(name) for name in ('ggml-cuda.cu','mmvf.cu','mmvf.cuh','mmvq.cu','common.cuh'))
assert main.count('= ggml_get_op_params_f32(glu, 2);') == 6
assert main.count('= ggml_get_op_params_f32(glu, 3);') == 6
for text in (mmvf, mmvq):
    assert text.count('fusion_local.glu_alpha = fusion->glu_alpha;') == 1
    assert text.count('fusion_local.glu_limit = fusion->glu_limit;') == 1
assert header.count('ggml_cuda_op_swiglu_oai_single(gate_value, value, fusion.glu_alpha, glu_limit)') == 1
assert mmvq.count('ggml_cuda_op_swiglu_oai_single(gate_value, result, fusion.glu_alpha, glu_limit)') == 2
assert common.count('    float glu_limit = 0.0f;\n    float glu_alpha = 1.702f;\n};') == 2
assert 'hard-code their scalar parameters' not in main
start = mmvf.index('void ggml_cuda_mul_mat_vec_f(')
end = mmvf.index('\nvoid ggml_cuda_op_mul_mat_vec_f(',start)
assert 'dst->op_params[0]' not in mmvf[start:end]
carrier_calls = [line.strip() for line in main.splitlines() if 'ggml_cuda_mul_mat_vec_f(' in line]
assert len(carrier_calls) == 7 and all('ggml_prec(' in line for line in carrier_calls)
old_mmvf = (root/'.scratch/architecture-refactor-2026-10-18/cuda-bf16-dual-projection/metadata-fix/native-source/src/ggml-cuda/mmvf.cu').read_text()
old_end = old_mmvf.index('\nvoid ggml_cuda_op_mul_mat_vec_f(')
assert old_mmvf[old_end:] == mmvf[end:]  # ordinary partitioned callback unchanged

result = {'state':'Final source self-review only, no compile/GPU or broad numerical claim.',
          'OAI_parameter_flow':{'main_actual_alpha_and_limit_reads':6,'host_alpha_copies':2,'host_limit_copies':2,
                                'MMVF_device_calls':1,'MMVQ_std_device_calls':1,'MMVQ_moe_device_calls':1},
          'default_math':'For an OAI node with alpha1.702 and limit7, the explicit arguments equal the previous helper defaults. The helper body is untouched. Other GLU cases ignore the new alpha field; their existing limit flow is unchanged. Compiled equivalence remains to be tested.',
          'precision':'All seven calls explicitly supply original MatMul metadata; host no longer interprets ADD/GLU params as MatMul precision. Existing hardware normalization and ordinary partitioned callback remain unchanged.',
          'ABI':'Private host/device fusion args append alpha after existing limit, requiring fresh main/mmvf/mmvq/unary. Unchanged unary source is copied next to the new shared headers to prevent stale by-value instances.',
          'no_extra_runtime_resources':'No GPU buffer, constant pack, queue, executor, allocation or payload transfer was introduced.',
          'independent_review':'bf16_fusion_review reported no source blocker for six metadata reads, two bridges, three device calls and four-TU closure.',
          'source_freeze_sha256':hashlib.sha256((stage/'source-freeze.json').read_bytes()).hexdigest()}
(stage/'self-review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))
