from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
MAIN_BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-fusion-layout/native-source'
MMVF_BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-bf16-dual-projection/metadata-fix/native-source'
files = []
patch = ''

def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()

def emit(relative, before, after, before_path):
    global patch
    target = STAGE / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after, encoding='utf-8', newline='\n')
    old_lines, new_lines = before.splitlines(True), after.splitlines(True)
    context = 3
    while True:
        edits = [{'before': ''.join(old_lines[g[0][1]:g[-1][2]]),
                  'after': ''.join(new_lines[g[0][3]:g[-1][4]])}
                 for g in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_grouped_opcodes(context)]
        replayed = before
        for edit in edits:
            if not edit['before'] or replayed.count(edit['before']) != 1:
                break
            replayed = replayed.replace(edit['before'], edit['after'], 1)
        else:
            if replayed == after:
                break
        context *= 2
        assert context < len(old_lines) * 2
    files.append({'path':relative, 'before_path':str(before_path.relative_to(ROOT)),
                  'before_sha256':sha(before), 'after_sha256':sha(after), 'edits':edits})
    patch += ''.join(difflib.unified_diff(old_lines, new_lines, fromfile='a/'+relative, tofile='b/'+relative))

path = MAIN_BASE / 'src/ggml-cuda/ggml-cuda.cu'
main = path.read_text(encoding='utf-8')
assert sha(main) == '6f9f53d1003d4afc7a8cf2094be68d30f94d5269563ab50bfe610a685a90047f'
after = main
replacements = [
    ('ggml_cuda_mul_mat_vec_f(ctx, src0, src1, nullptr, dst);',
     'ggml_cuda_mul_mat_vec_f(ctx, src0, src1, nullptr, dst, ggml_prec(dst->op_params[0]));', 2),
    ('ggml_cuda_mul_mat_vec_f(ctx, src1, src0, nullptr, &dst_vec);',
     'ggml_cuda_mul_mat_vec_f(ctx, src1, src0, nullptr, &dst_vec, ggml_prec(dst->op_params[0]));', 1),
    ('ggml_cuda_mul_mat_vec_f(ctx, src0, src1, ids, dst);',
     'ggml_cuda_mul_mat_vec_f(ctx, src0, src1, ids, dst, ggml_prec(dst->op_params[0]));', 1),
]
for old, new, count in replacements:
    assert after.count(old) == count
    after = after.replace(old, new)
old = 'ggml_cuda_mul_mat_vec_f(*cuda_ctx, src0, src1, ids, glu, &fusion_data);'
assert after.count(old) == 2
first = after.index(old)
after = after[:first] + after[first:].replace(old,
    'ggml_cuda_mul_mat_vec_f(*cuda_ctx, src0, src1, ids, glu, ggml_prec(up_n->op_params[0]), &fusion_data);', 1)
assert after.count(old) == 1
after = after.replace(old,
    'ggml_cuda_mul_mat_vec_f(*cuda_ctx, src0, src1, ids, glu, ggml_prec(up->op_params[0]), &fusion_data);', 1)
old = 'ggml_cuda_mul_mat_vec_f(*cuda_ctx, src0, src1, ids, bias_node, &fusion_data);'
assert after.count(old) == 1
after = after.replace(old,
    'ggml_cuda_mul_mat_vec_f(*cuda_ctx, src0, src1, ids, bias_node, ggml_prec(mm_node->op_params[0]), &fusion_data);', 1)

old = '''    if (ffn_up->src[1] != ffn_gate->src[1]) {
        return false;
    }
'''
new = old + '''
    // A single F16 MMVF carrier has one accumulation domain for both banks.
    // Keep independent projections when their actual native domains differ.
    // On hardware without fast FP16 both are already normalized to F32.
    if (ffn_up->src[0]->type == GGML_TYPE_F16 &&
        (ggml_prec(ffn_up->op_params[0]) == GGML_PREC_DEFAULT) !=
            (ggml_prec(ffn_gate->op_params[0]) == GGML_PREC_DEFAULT) &&
        fast_fp16_available(ggml_cuda_info().devices[ggml_cuda_get_device()].cc)) {
        return false;
    }
'''
assert after.count(old) == 1
after = after.replace(old, new, 1)
old = '''    if (const bool swapped = ggml_get_op_params_i32(glu, 1); swapped) {
        return false;
    }
'''
new = '''    // These existing OAI epilogues hard-code their scalar parameters.
    // Arbitrary alpha/limit remain supported by the original separate GLU.
    if (ggml_get_glu_op(glu) == GGML_GLU_OP_SWIGLU_OAI &&
        (ggml_get_op_params_f32(glu, 2) != 1.702f || ggml_get_op_params_f32(glu, 3) != 7.0f)) {
        return false;
    }
''' + old
assert after.count(old) == 1
after = after.replace(old, new, 1)
emit('src/ggml-cuda/ggml-cuda.cu', main, after, path)

path = MMVF_BASE / 'src/ggml-cuda/mmvf.cuh'
header = path.read_text(encoding='utf-8')
assert sha(header) == '9ef9614d0623dd930937f783d1a4649b2674bec09bd0cce416887a93555d31f5'
old = '''void ggml_cuda_mul_mat_vec_f(ggml_backend_cuda_context & ctx, const ggml_tensor * src0, const ggml_tensor * src1, const ggml_tensor * ids, ggml_tensor * dst,
    const ggml_cuda_mm_fusion_args_host * fusion = nullptr);'''
new = '''// Precision belongs to the original MatMul, independently of its final
// fused output node's ADD/GLU parameter layout. Every caller supplies it.
void ggml_cuda_mul_mat_vec_f(ggml_backend_cuda_context & ctx, const ggml_tensor * src0, const ggml_tensor * src1, const ggml_tensor * ids, ggml_tensor * dst,
    enum ggml_prec precision, const ggml_cuda_mm_fusion_args_host * fusion = nullptr);'''
assert header.count(old) == 1
emit('src/ggml-cuda/mmvf.cuh', header, header.replace(old, new, 1), path)

path = MMVF_BASE / 'src/ggml-cuda/mmvf.cu'
mmvf = path.read_text(encoding='utf-8')
assert sha(mmvf) == '6263cba641d367c3ffaf73c31f94be098eebc109c694b33eec27029a94a741d9'
start = mmvf.index('void ggml_cuda_mul_mat_vec_f(')
end = mmvf.index('\nvoid ggml_cuda_op_mul_mat_vec_f(', start)
host = mmvf[start:end]
old = '''    const ggml_cuda_mm_fusion_args_host * fusion) {'''
assert host.count(old) == 1
host = host.replace(old, '''    enum ggml_prec precision, const ggml_cuda_mm_fusion_args_host * fusion) {''', 1)
old = 'const enum ggml_prec prec = fast_fp16_available(cc) ? ggml_prec(dst->op_params[0]) : GGML_PREC_F32;'
assert host.count(old) == 1
host = host.replace(old, 'const enum ggml_prec prec = fast_fp16_available(cc) ? precision : GGML_PREC_F32;', 1)
old = 'ne1 == 1 && ne11 == 1 && ggml_prec(dst->op_params[0]) == GGML_PREC_F32'
assert host.count(old) == 1
host = host.replace(old, 'ne1 == 1 && ne11 == 1 && precision == GGML_PREC_F32', 1)
assert 'dst->op_params[0]' not in host
after = mmvf[:start] + host + mmvf[end:]
emit('src/ggml-cuda/mmvf.cu', mmvf, after, path)

(STAGE / 'replacements.json').write_text(json.dumps({'files':files}, indent=2)+'\n', encoding='utf-8', newline='\n')
(STAGE / 'changes.diff').write_text(patch, encoding='utf-8', newline='\n')
freeze = {'state':'Scratch only; no product/compile/GPU changes.',
          'files':[{k:v for k,v in f.items() if k!='edits'} for f in files],
          'private_abi':'One required ggml_prec argument on the existing ggml_cuda_mul_mat_vec_f declaration and host definition; no overload/default precision/new fusion struct field.',
          'callers':{'ordinary':4,'fused':3},
          'precision':'Ordinary calls pass original MatMul metadata unchanged; fused calls pass original producing MatMul metadata. Preserve the existing hardware normalization and reduction arithmetic. Unequal F16 actual accumulation domains keep original separate projections.',
          'OAI':'Existing fused implementations support only their actual hard-coded alpha1.702/limit7; other public parameters keep the existing complete separate GLU, without losing functionality.'}
(STAGE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'files':len(files),'freeze_sha256':hashlib.sha256((STAGE/'source-freeze.json').read_bytes()).hexdigest(),
                  'sources':[(f['path'],f['after_sha256']) for f in files]}))
