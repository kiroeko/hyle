"""Replay and integrate the native layout-qualification fix, without SDK mutation."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('layout_retained_seal', STAGE.parent / 'cuda-fusion-layout/seal.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
s = prior.s


def main():
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    before = STAGE / 'before-seal'
    before.mkdir(exist_ok=False)
    for name, path in (('patches.json', vendor / 'patches.json'), ('NOTICE.md', vendor / 'NOTICE.md'),
                       ('dependency-lock.json', ROOT / 'cmake/HyleDependencyLock.json')):
        (before / name).write_bytes(path.read_bytes())
    manifest = s.read(vendor / 'patches.json')
    changes = s.read(STAGE / 'oai-overlay/replacements.json')['files']
    expected = {r['path']: r for r in changes}
    for row in s.read(STAGE / 'oai-overlay/source-freeze.json')['unchanged_recompile_sources']:
        expected[row['path']] = {'after_sha256': row['sha256']}
    runtime = ROOT / 'src/compute_ggml_runtime'
    mixed, combined = STAGE / 'mixed-cpu-manifest.json', STAGE / 'combined-manifest.json'
    s.load('layout_mixed_cpu', runtime / 'prepare_mixed_cpu_manifest.py').derive(s.UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    compose = s.load('layout_cuda_iq1', runtime / 'prepare_cuda_iq1_manifest.py')
    before_combined = STAGE / 'before-combined.json'
    compose.derive(s.UPSTREAM, mixed, vendor / 'patches.json', vendor / 'iq1-patches.json', before_combined)
    current = {r['path']: r for r in s.read(before_combined)['files']}
    for change in changes:
        predecessor = current.get(change['path'])
        data = (prior.prior.prior.replay(predecessor) if predecessor else
                (s.UPSTREAM / change['path']).read_bytes().replace(b'\r\n', b'\n'))
        if s.sha(data) != change['before_sha256']:
            raise ValueError('Native starting point differs')
        row = next((r for r in manifest['files'] if r['path'] == change['path']), None)
        if row is None:
            row = {'path': change['path'], 'before_sha256': s.sha(
                (s.UPSTREAM / change['path']).read_bytes().replace(b'\r\n', b'\n')), 'edits': []}
            manifest['files'].append(row)
        row['edits'].extend(change['edits'])
        row['after_sha256'] = s.sha(prior.prior.prior.replay(row))
    proposed = STAGE / 'patches.draft.json'
    s.save(proposed, manifest)
    compose.derive(s.UPSTREAM, mixed, proposed, vendor / 'iq1-patches.json', combined)
    outputs = {}
    for row in s.read(combined)['files']:
        data = prior.prior.prior.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Mixed source replay differs')
        if row['path'] in expected:
            if s.sha(data) != expected[row['path']]['after_sha256']:
                raise ValueError('Reviewed overlay differs')
            overlay = STAGE / 'oai-overlay/source' / row['path']
            if overlay.read_bytes() != data:
                raise ValueError('Reviewed native file differs')
            outputs[row['path']] = data
    if set(outputs) != set(expected):
        raise ValueError('Native output set differs')
    tests = s.read(STAGE / 'tests-source-freeze.json')
    test_path, test_overlay = Path(tests['before']['path']), Path(tests['after']['path'])
    if s.sha(test_path.read_bytes()) != tests['before']['sha256'] or s.sha(test_overlay.read_bytes()) != tests['after']['sha256']:
        raise ValueError('Reviewed test overlay differs')
    (before / test_path.name).write_bytes(test_path.read_bytes())
    for relative, data in outputs.items():
        target = STAGE / 'native-source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    (vendor / 'patches.json').write_bytes(proposed.read_bytes())
    test_path.write_bytes(test_overlay.read_bytes())
    notice = vendor / 'NOTICE.md'
    old = notice.read_text(encoding='utf-8')
    old = old.replace('original repeated numerator remain actual inputs. The repeat and following\npublic cast are not removed.',
                      'original repeated numerator remain actual inputs in the original dense\nvariant. Scalar and private-output variants are described below.')
    notice.write_text(old.rstrip() + '''

MMVF receives the original MatMul accumulation precision explicitly, rather
than reading a fused ADD/GLU node's unrelated parameter storage. Unequal F16
projection domains retain their original independent arithmetic. The existing
private fusion arguments now carry the actual OAI alpha and limit to the same
floating, quantized and multi-token expert epilogues. The private by-value
argument layout changes, so main/MMVF/MMVQ and unary shared-template instances
must be compiled together. No public precision policy, compatibility overload,
new executor or GPU shadow buffer is introduced.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {r['name']: r for r in lock['dependencies']}
    cuda = entries['ggml_cuda_runtime_patches']
    cuda['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v20'
    cuda['vendored']['tree_sha256'] = s.tree(vendor)
    for item in cuda['license']['files']:
        if item['root'] == 'hyle' and item['path'].endswith('NOTICE.md'):
            item['sha256'] = s.sha(notice.read_bytes())
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += cuda['vendored']['tree_sha256']
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    s.save(STAGE / 'native-source-freeze.json', {'version': cuda['version'], 'source_id': source_id,
        'vendor_tree_sha256': cuda['vendored']['tree_sha256'],
        'sources': {relative: s.sha(data) for relative, data in outputs.items()},
        'all_mixed_CPU_IQ1_CUDA_edits_replayed': True, 'SDK_modified': False,
        'public_API_changed': False, 'numerical_contract_changed': False})
    (STAGE / 'audit-native-lock.cmake').write_text('include("' + (ROOT / 'cmake/HyleDependencyVersions.cmake').as_posix() + '")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n', encoding='utf-8')
    print('APPLIED', source_id, flush=True)


if __name__ == '__main__':
    main()
