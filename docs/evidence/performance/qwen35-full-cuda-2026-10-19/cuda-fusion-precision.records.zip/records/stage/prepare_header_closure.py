"""Materialize only the GGML headers used by the four native CUDA TUs.

This does not compile, modify a manifest, or overwrite a sealed source. Header
contents are replayed from the pinned upstream and the current combined manifest.
"""
from pathlib import Path
import hashlib
import json


STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCH = STAGE.parent
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
NATIVE = STAGE / 'native-source'
DEPENDENCIES = [
    STAGE / 'checks/20261019T110758/ggml-cuda.d',
    ARCH / 'cuda-fusion-layout/native-build/20261019T104704/ggml-cuda.d',
    ARCH / 'cuda-fusion-layout/native-build/20261019T104704/mmvq.d',
    ARCH / 'cuda-explicit-rope/checks/20261019T100154/unary.d',
    ARCH / 'cuda-bf16-dual-projection/checks/20261019T084721/mmvf.d',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def relative(path):
    return path.relative_to(ROOT).as_posix()


manifest_path = STAGE / 'combined-manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
rows = {row['path']: row for row in manifest['files']}
assert len(rows) == len(manifest['files']), 'duplicate manifest file rows'
freeze_path = STAGE / 'native-source-freeze.json'
freeze = json.loads(freeze_path.read_text(encoding='utf-8'))
for path, expected in freeze['sources'].items():
    assert digest((NATIVE / path).read_bytes()) == expected, ('sealed source changed', path)

origins = {}
excluded_project_headers = set()
for dependency in DEPENDENCIES:
    # NVCC emits one dependency per continued line. Only spaces are escaped in
    # these paths; preserve drive separators until after unescaping Make spaces.
    for line in dependency.read_text(encoding='utf-8').splitlines()[1:]:
        value = line.strip()
        if value.endswith(' \\'):
            value = value[:-2]
        value = value.replace('\\ ', ' ').replace('\\#', '#').replace('\\$', '$').replace('\\', '/')
        if not value.endswith(('.h', '.cuh')):
            continue
        candidates = []
        for segment in ('/src/', '/include/'):
            index = value.rfind(segment)
            if index >= 0:
                candidates.append(value[index + 1:])
        for path in candidates:
            if (UPSTREAM / path).is_file():
                origins.setdefault(path, set()).add(relative(dependency))
                break
        else:
            if '/src/compute_provider_ggml_cuda/' in value:
                excluded_project_headers.add(value)

assert origins, 'empty native GGML header dependency union'
headers = []
created = 0
for path in sorted(origins):
    data = (UPSTREAM / path).read_bytes().replace(b'\r\n', b'\n')
    row = rows.get(path)
    if row is not None:
        assert digest(data) == row['before_sha256'], ('upstream hash mismatch', path)
        text = data.decode('utf-8')
        for index, edit in enumerate(row['edits']):
            assert text.count(edit['before']) == 1, ('nonunique manifest edit', path, index)
            text = text.replace(edit['before'], edit['after'], 1)
        data = text.encode('utf-8')
        assert digest(data) == row['after_sha256'], ('replayed hash mismatch', path)
    target = NATIVE / path
    if target.exists():
        assert target.read_bytes() == data, ('existing source differs; refusing overwrite', path)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        created += 1
    headers.append({
        'path': path,
        'sha256': digest(data),
        'bytes': len(data),
        'materialized_path': target.as_posix(),
        'patched': row is not None,
        'dependency_files': sorted(origins[path]),
    })

# Every previously sealed CU/header must remain byte-for-byte unchanged.
for path, expected in freeze['sources'].items():
    assert digest((NATIVE / path).read_bytes()) == expected, ('sealed source changed', path)

receipt = {
    'source_id': freeze['source_id'],
    'upstream_revision': manifest['upstream_revision'],
    'upstream_directory': UPSTREAM.as_posix(),
    'combined_manifest_sha256': digest(manifest_path.read_bytes()),
    'sealed_source_freeze_sha256': digest(freeze_path.read_bytes()),
    'dependency_files': [
        {'path': relative(path), 'sha256': digest(path.read_bytes())}
        for path in DEPENDENCIES
    ],
    'header_count': len(headers),
    'total_header_bytes': sum(header['bytes'] for header in headers),
    'patched_header_count': sum(header['patched'] for header in headers),
    'headers': headers,
    'excluded_hyle_private_headers': sorted(excluded_project_headers),
    'sealed_sources_unchanged': freeze['sources'],
    'include_directories_in_order': [
        (NATIVE / 'include').as_posix(),
        (NATIVE / 'src').as_posix(),
        (NATIVE / 'src/ggml-cuda').as_posix(),
    ],
    'old_GGML_overlay_and_reference_include_directories_must_be_removed': True,
    'compiled': False,
    'GPU_executed': False,
}
receipt_path = STAGE / 'header-closure.json'
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({
    'receipt': relative(receipt_path),
    'receipt_sha256': digest(receipt_path.read_bytes()),
    'header_count': receipt['header_count'],
    'header_bytes': receipt['total_header_bytes'],
    'patched_headers': receipt['patched_header_count'],
    'newly_created_headers': created,
    'sealed_sources_unchanged': True,
}))
