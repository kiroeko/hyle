"""Archive frozen v20 sources and actual evidence, without binary caches."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T111328/plan.json'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-fusion-precision.zip'
EXCLUDED = {'.exe', '.obj', '.pdb', '.lib', '.exp', '.dll', '.pyc'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    if DEST.exists():
        raise ValueError('Archive already exists; refusing replacement')
    plan = read(PLAN)
    freeze = read(STAGE / 'native-source-freeze.json')
    headers = read(STAGE / 'header-closure.json')
    if plan['native_source_id'] != freeze['source_id'] or freeze['source_id'] != '866a383d696d3931':
        raise ValueError('Expected the tested v20 source identity')
    for path, expected in freeze['sources'].items():
        if sha((STAGE / 'native-source' / path).read_bytes()) != expected:
            raise ValueError('Sealed source drift: ' + path)
    for row in headers['headers']:
        data = (STAGE / 'native-source' / row['path']).read_bytes()
        if sha(data) != row['sha256'] or len(data) != row['bytes']:
            raise ValueError('Header closure drift: ' + row['path'])
    if not all(read(path)['passed'] for path in (
        PLAN.parent / 'summary.json', PLAN.parent / 'run-cuda/summary.json',
        STAGE / 'correctness/summary.json', STAGE / 'profile-tests/analysis.json',
    )):
        raise ValueError('Expected the retained completed v20 observations')

    # Only externally located inputs already frozen by the tested build are
    # eligible. Do not collect any later, untested product source or document.
    external = []
    for row in plan['frozen']:
        path = Path(row['path']).resolve()
        data = path.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Frozen build input drift; refusing current replacement: ' + str(path))
        if path.is_relative_to(STAGE):
            continue
        if path.suffix.lower() in EXCLUDED:
            continue
        if not path.is_relative_to(ROOT):
            raise ValueError('Unexpected non-workspace frozen text input')
        external.append(('frozen-inputs/' + path.relative_to(ROOT).as_posix(), path))

    images = {tag: read(PLAN.parent / (tag + '-image.json')) for tag in ('qwen', 'cuda', 'cuda-before')}
    # Identities remain even though the reproducible binary cache is excluded.
    for row in images.values():
        data = Path(row['path']).read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('Tested image identity drift')
    scope = {
        'source_id': freeze['source_id'], 'plan_sha256': sha(PLAN.read_bytes()),
        'tested_images': images, 'header_count': headers['header_count'],
        'header_bytes': headers['total_header_bytes'],
        'profile': read(STAGE / 'profile-tests/analysis.json')['observed_fused_launches'],
        'unfrozen_product_sources_included': False,
        'external_text_inputs_are_hash_matched_to_tested_build_plan': True,
        'all_stage_sources_are_v20_frozen_overlays_or_validation_scripts': True,
        'later_architecture_changes_in_working_tree_are_not_collected': True,
        'SDK_models_binary_caches_excluded': True,
    }
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8', newline='\n')

    files = list(external)
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if not path.is_file() or 'tmp' in path.relative_to(STAGE).parts:
            continue
        if path.suffix.lower() in EXCLUDED:
            continue
        if path.name == 'archive-verification.json':
            raise ValueError('Unexpected old archive receipt')
        files.append(('stage/' + path.relative_to(STAGE).as_posix(), path))
    names = [name for name, _ in files]
    if len(names) != len(set(names)):
        raise ValueError('Duplicate archive entry')
    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in files:
            data = path.read_bytes()
            records.append({'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)})
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC failure')
        if len(archive.namelist()) != len(records) + 1:
            raise ValueError('Archive entry count differs')
        for row in records:
            data = archive.read(row['entry'])
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError('Archive payload hash differs')
        if any(Path(name).suffix.lower() in EXCLUDED for name in archive.namelist()):
            raise ValueError('Excluded binary cache entered archive')
    receipt = {
        'path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': sha(DEST.read_bytes()),
        'payloads': len(records), 'entries_including_manifest': len(records) + 1,
        'uncompressed_payload_bytes': sum(row['bytes'] for row in records),
        'CRC_and_every_payload_SHA_verified': True,
        'source_id': freeze['source_id'], 'header_count': headers['header_count'],
        'SDKs_models_objects_executables_excluded': True,
        'later_unfrozen_product_sources_excluded': True,
    }
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text, encoding='utf-8', newline='\n')
    DEST.with_name('cuda-fusion-precision-archive.json').write_text(text, encoding='utf-8', newline='\n')
    print(text, flush=True)


if __name__ == '__main__':
    main()
