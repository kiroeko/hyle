"""One short physical OAI carrier trace using the already-tested v20 image."""
from pathlib import Path
import argparse
import collections
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('precision_profile_build', STAGE / 'build.py')
a = load('precision_profile_analysis', STAGE / 'profile-analysis.py')
b, c = build.b, build.c
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('plan', type=Path)
parser.add_argument('--analyze', action='store_true')
args = parser.parse_args()
out = STAGE / 'profile-tests'
stem = out / 'oai-tests'
test = 'GgmlCudaFusionPrecision.OaiParametersReachFloatingQuantizedAndMoeEpilogues'
if not args.analyze:
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if not c.read(plan_path.parent / 'run-cuda/summary.json')['passed']:
        raise ValueError('Successful existing red/green regression required')
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = b.identity(plan['links']['cuda']['image'])
    if image != c.read(plan_path.parent / 'cuda-image.json'):
        raise ValueError('Current CUDA image differs')
    original = c.read(ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    index = original.index('--inputs') - 1
    profile = [('--output=' + str(stem)) if x.startswith('--output=') else x for x in original[:index]]
    profile += [image['path'], '--gtest_color=no', '--gtest_filter=' + test,
                '--gtest_output=xml:' + str(out / 'target.xml')]
    commands = {
        'profile': profile,
        'export': [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        'stats': [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum', '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'],
    }
    c.save(out / 'inputs.json', {
        'image': image, 'plan': b.identity(plan_path), 'runner': b.identity(Path(__file__)),
        'analysis': b.identity(STAGE / 'profile-analysis.py'),
        'commands': commands, 'profiler_collections': 1, 'throughput_claim': False,
        'pre_observation_prediction': {'MMVF': 4, 'MMVQ_std': 4, 'MMVQ_MoE': 4, 'total': 12},
    })
    env, _ = b.environment(plan['links']['cuda']['command'], [r['path'] for r in plan['cached_inputs']], out)
    for tag, command in commands.items():
        c.execute(tag, command, env, out)

a.PROFILE = out
data = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'), candidate=True)
symbols = collections.Counter(kernel['name'] for kernel in data['kernels'])
carriers = []
for name, count in symbols.items():
    for kernel, family, fusion_index in (
        ('mul_mat_vec_f', 'MMVF', 4),
        ('mul_mat_vec_q', 'MMVQ_std', 2),
        ('mul_mat_vec_q_moe', 'MMVQ_MoE', 2),
    ):
        arguments = a.template_arguments(name, kernel)
        if arguments:
            fused = arguments[fusion_index] in ('true', '(bool)1') if len(arguments) > fusion_index else None
            carriers.append({'family': family, 'symbol': name, 'count': count, 'has_fusion': fused})
            break
fused = {family: sum(row['count'] for row in carriers if row['family'] == family and row['has_fusion'] is True)
         for family in ('MMVF', 'MMVQ_std', 'MMVQ_MoE')}
target = ET.parse(out / 'target.xml').getroot()
target_counts = {key: int(target.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
target_counts['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in target.findall('testsuite'))
checks = {
    'CSV_SQLite_per_symbol_equal': data['receipt']['csv_sqlite_per_symbol_counts_equal'],
    'no_graph_API_errors': not data['receipt']['graph_api_failures'],
    'single_requested_test_passed': target_counts['tests'] == 1 and not any(target_counts[key] for key in ('failures', 'disabled', 'errors', 'skipped')),
}
report = {
    'checks': checks, 'passed': all(checks.values()), 'receipt': data['receipt'],
    'target': target_counts, 'test': test, 'carrier_symbols': carriers,
    'observed_fused_launches': fused, 'observed_total_fused_launches': sum(fused.values()),
    'pre_observation_prediction': c.read(out / 'inputs.json')['pre_observation_prediction'],
    'all_kernel_counts': dict(symbols), 'analysis_runner': b.identity(Path(__file__)),
    'profiler_collections': 1, 'complete_model_trace': False, 'throughput_claim': False,
    'limits': ['This trace establishes the actual has_fusion template instances for one exact-parameter regression test.',
               'The counts are observations, not acceptance requirements; an ordinary fallback remains a valid result.',
               'Numerical assertions were already covered by the retained red/green run; no full model or benchmark was rerun.'],
}
c.save(out / 'analysis.json', report)
print('PHYSICAL_OAI_TEST', {'checks': checks, 'observed_fused_launches': fused, 'total': sum(fused.values())}, flush=True)
if not report['passed']:
    raise ValueError('OAI physical trace has unresolved evidence')
