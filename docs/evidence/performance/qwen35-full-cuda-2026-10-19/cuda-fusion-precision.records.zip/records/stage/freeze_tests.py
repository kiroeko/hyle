import difflib
import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
REL = Path('tests/graph_route_cuda/stable_silu_test.cc')

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

before = ROOT / REL
assert identity(before)['sha256'] == '76e01a04c7a912b82724dc1cde0c13866b10bcb4f54ba61100fa49460873c464'
original = before.read_text(encoding='utf-8')
fragment = (STAGE / 'precision-tests.inc').read_text(encoding='utf-8')
after = STAGE / 'test-overlay' / REL
after.parent.mkdir(parents=True, exist_ok=True)
after.write_text(original.rstrip() + '\n' + fragment, encoding='utf-8', newline='\n')
delta = ''.join(difflib.unified_diff(original.splitlines(keepends=True),
    after.read_text(encoding='utf-8').splitlines(keepends=True),
    fromfile='a/' + REL.as_posix(), tofile='b/' + REL.as_posix()))
(STAGE / 'tests-change.diff').write_text(delta, encoding='utf-8', newline='\n')
plan = {
    'scope': 'Scratch-only addition to existing raw-native CUDA test TU; one new TEST; no product/CMake changes.',
    'tests': ['GgmlCudaFusionPrecision.F16WeightsKeepOriginalFloatAccumulationThroughEpilogues'],
    'shape_and_types': 'Native W F16[32,8], x F32[32,1], bias/output F32[8,1]; MM accumulation explicitly F32.',
    'witnesses': [
        {'weight_k0': 65504, 'activation_k0': 2, 'other_k': 0,
         'dot_F32': 131008, 'half_product': 'positive infinity',
         'reason': 'F32 accumulation/source arithmetic required by original MM; finite vs overflow without reduction-order dependence.'},
        {'weight_k0': '1+2^-10', 'activation_k0': '1+2^-10', 'other_k': 0,
         'dot_F32': '1+2^-9+2^-20', 'half_product': '1+2^-9',
         'reason': 'Both operands exactly F16-representable; isolates product rounding, not F32 input narrowing.'},
    ],
    'epilogues': ['MM+ADD: red witness because final ADD op_params[0]=0 is not the source MM precision.',
        'MM+ADD+MM+ADD+SwiGLU: preservation positive; current SWIGLU op_params[0]=2 already selects float in old code, so not claimed as a red witness.'],
    'oracle': 'Independent original GPU graph with both MM/ADD outputs published to prevent fusion; exact dyadic FP64 dot also checks original MM. Nonlinear output uses only original GPU SwiGLU, never CPU exp.',
    'checks': ['Exact output F32 bits and finite oracle values.',
        'Native operation adjacency/dtypes/explicit MM F32 accumulation and unchanged ADD params.',
        'No host-only getter is offered as execution proof.'],
    'liveness_review': {
        'rebase': 'Original v19 product now marks both float layout bias roots OUTPUT because that fixture postreads their backing; both corrections are inherited unchanged.',
        'precision_roots': 'No w/x/b/wu/bu backing is read after compute. INPUT is used only for early allocation, not a post-consumption lifetime guarantee.',
        'precision_reads': 'MM is read only in oracle and marked OUTPUT. ADD is read in oracle (OUTPUT), or plain candidate where it is the final OUTPUT. Fused SwiGLU candidate reads only final out (OUTPUT).',
        'metadata': 'Post-compute op_params reads inspect live metadata in Owners.ctx, not an unretained native data buffer.',
        'fragment_changed': False,
    },
    'limits': ['No GPU execution/compilation performed by this preparation.',
        'Witness targets native fast-FP16 capable hardware; on hardware forcing F32 the old implementation may already pass.',
        'Existing v19 and earlier BF16/F32 numerical regressions remain in the unchanged original TU.',
        'Separate native backend per candidate/reference; tests establish numerical preservation, not new capture/slot behavior.'],
    'compiled': False, 'gpu_run': False,
}
(STAGE / 'tests-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
freeze = {name: identity(path) for name, path in [
    ('before', before), ('after', after), ('fragment', STAGE / 'precision-tests.inc'),
    ('diff', STAGE / 'tests-change.diff'), ('plan', STAGE / 'tests-plan.json')]}
freeze.update(product_edited=False, compiled=False, gpu_run=False)
(STAGE / 'tests-source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'before': freeze['before'], 'after': freeze['after'], 'tests': plan['tests']}, indent=2))
