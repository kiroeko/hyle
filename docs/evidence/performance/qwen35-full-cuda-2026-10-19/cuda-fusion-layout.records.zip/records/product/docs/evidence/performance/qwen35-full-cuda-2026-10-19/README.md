# Qwen3.5-2B 全 CUDA 实际对照

2026-10-19，Windows / RTX 4070 12GB / driver 617.14。双方完整执行官方同源2B文本模型24层，
不执行视觉或MTP，权重在推理前全部驻留GPU；同为BF16权重、BF16 KV、单请求、context容量256、GPU greedy。
llama.cpp为本地d9e03f1074dbd2979126d91dce1b5d304ec8394e，复用与其GGML pin 456相符的原CUDA数学闭包，
不是本地较新HEAD，也不把既有Hyle资源集成补丁隐藏为纯上游未修改构建。

以下首表保留修改前基线。本日后续先统一普通ggml CUDA区域的临时寿命复用，再接入共同Graph workspace，
并补齐BF16逐算子承载；当前128-token场景Hyle显存降至3.939 GiB。各阶段变更与同源A/B见文末，
不能把旧表6.431 GiB当作修复后的数值。

每个场景3对独立进程，按H/L、L/H、H/L顺序运行，表列中位数。输入前缀和31个decode输入逐token一致，
两边分别反馈自己的KV/conv/GDN状态；未读取对方状态、hidden或logits。所有吞吐测量未挂profiler。
21-token场景另有一次关闭内存监控的对照，两端预热后decode分别76.14和106.16 tokens/s，未作开销修正。

| 指标 | Hyle | llama.cpp |
|---|---:|---:|
| 128-token场景：权重/模型加载子段 | 3.086 s | 1.603 s |
| 有效载荷加载率 | 1.136 GiB/s | 2.188 GiB/s |
| 进程启动到可推理 | 3.892 s | 1.772 s |
| 进程启动到首token | 3.968 s | 1.877 s |
| 首次prefill，128 tokens | 1680.1 tokens/s | 1223.6 tokens/s |
| decode，全部31步，含原生预热 | 69.3 tokens/s | 104.1 tokens/s |
| decode7–31，预热后25步 | 77.4 tokens/s | 105.8 tokens/s |
| 进程Dedicated显存采样峰值 | 6.431 GiB | 3.946 GiB |
| 进程RAM Working Set峰值 | 1.501 GiB | 4.069 GiB |

短输入控制：21-token首次prefill为286.6 / 222.4 tokens/s，预热后decode为78.1 / 106.7 tokens/s，
Dedicated显存峰值为4.327 / 3.825 GiB，RAM Working Set峰值为1.501 / 4.069 GiB。
128-token场景中，Hyle预热后decode低约26.9%，进程启动到ready耗时约2.20倍，Dedicated显存多约2.484 GiB。
这是当前配置的实际输项；首次prefill更快不能抵销加载、decode和显存问题，也不能外推长prefill或质量等价。

加载子段的前端工作不同：Hyle从原safetensors按manifest读取、分配并同步上传320个张量，
llama从单份官方converter生成的text-only/no-MTP GGUF加载，含原格式的metadata和tokenizer处理。
原text payload为3,763,655,360B，GGUF的有效text payload为3,764,747,520B（187 BF16＋133 F32无损例外）。
因此同时保留从进程启动到ready和首token的完整端点，不单用加载子段宣称等工作胜负。
Hyle的ready计入prefill/T1原冷编译；双方都不额外预跑数学。首次prefill仍包含各自原生首次执行开销。

完整step从输入准备前开始，到GPU选出的token在host可读为止，包含布局、绑定、重放准备和完成等待。
仅使用旧Hyle submit→token的seconds会漏费用，本表使用step_seconds。
原生预热没有被删除：全31步与实际decode7–31窗口分别列出；后者不是长期运行或热稳定性承诺。
llama原公开tensor_buft_overrides将默认在CPU的input embedding置于CUDA0，并与tied output共享原tensor/backing；
实际25/25层、6个KV层、18个recurrent层均CUDA0，32次GPU sampler快路，没有CPU采样fallback。
其原框架仍额外回读248320个sampled logits，费用保留；未修改上游以消除该工作。

显存采用本PID的Windows GPU Process Memory Dedicated/Shared，50ms采样，峰值为采样下界；
本机WDDM的NVML进程显存为N/A，未把整卡占用当本进程VRAM。RAM为PSAPI Working Set，含映射/共享驻留页，
不能据此推导整机物理RAM节省相同数量。PrivateUsage/PeakPagefileUsage另存为提交量，不能与GPU Shared相加当物理内存。
短场景的完整独立memory-review保留阶段前后点、时间偏差和缺样；尤其不能将释放后的最近点冒充推理驻留。

提示21→128 tokens、context容量始终256时，Hyle显存峰值增加2.104 GiB，peer仅增加0.121 GiB。
128场景每组model_loaded→ready间均有9个有效样本，ready前已观察到约6.23–6.30 GiB；
这之前尚未首次提交数学。自loaded后首样本至峰值的增长中，92.8%–95.3%已在ready前存在，
该区间包含状态初始化和prefill/T1各两个执行槽，不能把全部费用归因于某一allocator。
源码确认ggml非tiled Invocation逐非view/nonexternal tensor独立分配buffer并随槽保留，没有原生liveness复用；
这是首要调查候选，尚未逐buffer定量。显式Graph workspace增长仅约33.3 MiB，
默认GDN仅保最终状态，不是误保所有token状态。逐样本与有界静态算术见128-prefill/memory-review.json。
128场景推理期间RAM Working Set中位数为1.108 / 4.069 GiB，Private Commit为8.254 / 4.882 GiB；
因此Hyle Working Set较低不能直接解释为主机内存总体代价更低。

双方中间精度仍有差异：Hyle多处保BF16边界，peer多处为F32。短场景预测top1为30/32相同（decode23、29不同），
128-token场景为32/32；这些都不是独立质量评测或整模型精度接受。
各场景源代码、命令、逐步计时、预测IDs与进程内存样本见[性能原始记录](qwen-full-cuda-comparison.zip)，
正常64-token greedy生成也在包内，达到步数上限而非EOS。模型转换/设备/ABI身份及原始peer构建见
[llama参考准备](llama-reference-preparation.zip)；
不包含SDK、object、image或额外模型副本。原生capture观测另见
[实际trace](../../correctness/inference-foundation-review-2026-10-18/qwen-native-graph-observation.zip)。

归档后通过根目录test.ps1精确删除20个已完成实验exe/map/lib/exp及1个写错checkout位置的证据zip副本，
共664,878,137B；可复用object、SDK、原模型及单份转换GGUF保留。[清理记录](qwen-benchmark-reclaim.zip)

## 原生临时缓冲寿命复用

同日沿原Invocation将普通区域与分块attention统一到原生gallocr：冷reserve临时空间，
真实绑定后仅安装已有地址；保持常量、校验输入、输出/root、各槽所有权及退休顺序。
移除了普通区域逐张量独立分配的分支，没有新增公共选项、执行器或数学实现。
只替换一个provider宿主object，未重编native/SDK。同一128-token场景重新运行3对独立进程B/A、A/B、B/A：

| 指标 | 修改前 | 修改后 |
|---|---:|---:|
| PID Dedicated显存峰值 | 6.431 GiB | 5.312 GiB |
| 首次prefill | 1647.6 tokens/s | 1653.0 tokens/s |
| decode7–31 | 77.32 tokens/s | 77.36 tokens/s |

显存三次均减少1,201,676,288B（1.119 GiB），吞吐无明显变化。21-token单对控制为4.327→4.159 GiB。
21/128-token各32阶段的logits和最后hidden共128份向量与旧实现逐字节相同；不是新的通用质量接受。
原24层Add长链只publish最终输出，实际native retained从184降到8 MiB，旧实现明确不满足128 MiB宽限，
新实现通过且精确输出25*x、原输入不变。published view/root、旧结果、checked失败不发布、双slot换地址等4项通过；
原TypedSlice负控错误地强制prepare成功，允许它在prepare按InvalidArgument提前拒绝坏对齐后，该项单独1/1通过。
原失败日志、初版fixture及更正后记录均保留，没有把006原4/5记成全过。

该阶段仍比原llama参考峰值高约1.365 GiB；每region/shape/slot的独立原生workspace当时尚未接入共同Graph liveness，
原生首次执行、融合地址条件及其他模型功能继续审查。本次不据此宣布架构goal完成。
[源码、原始A/B、决策数据与回归](ggml-cuda-liveness.zip)另含下一步沿既有caller workspace接线的只读设计，未将设计当作已实现。
本修复归档对相同决策payload去重，保存全部逻辑文件身份；经test.ps1精确清理16个已完成image/map/lib/exp，
回收599,196,703B，保留4个新增复用object及全部源码/日志/数据/SDK。[清理记录](ggml-cuda-liveness-reclaim.zip)

## 接入共同 workspace

第二阶段沿既有ProviderPrepared.workspace与create_invocation(BufferView)接线，不增加公共API或新执行器。
冷编译用空地址的真实buffer描述测量精确chunk span，不分配device payload、不上传常量、不执行数学；
普通Invocation将原gallocr chunk映射到真实caller workspace，逐项核对size/offset，禁止容量不足时另开私有池。
返回的buffer保留canonical CUDA类型；原安全ID/常量和原生BLAS/pool/cache仍独立持有。
Graph adapter转发真实需求，由现有HB/liveness规划复用有序region的空间。Direct调用按标准requirement提供并持有workspace，
Graph消费者入口不变。显式冷constant packing仍自行持有临时空间，未把它变成普通执行的隐藏fallback。

只替换provider与Graph adapter两个宿主object，native数学、共同Graph/Compute owner及SDK均复用。
同一128-token固定输入再次按B/A、A/B、B/A运行3对独立进程，性能运行均无trace/profiler：

| 指标 | 仅区域内复用 | 接入共同workspace |
|---|---:|---:|
| PID Dedicated显存峰值 | 5.312 GiB | 3.972 GiB |
| 首次prefill | 1702.0 tokens/s | 1706.4 tokens/s |
| decode7–31 | 77.47 tokens/s | 77.95 tokens/s |
| 进程启动到ready | 3.777 s | 3.772 s |

显存三次均减少1,438,658,560B（1.340 GiB）；吞吐与启动变化不足以宣称改善。21-token单对控制为4.159→3.872 GiB。
从首轮6.431 GiB累计降至3.972 GiB，仍比原llama参考的3.946 GiB高约26 MiB；peer本阶段未重跑。
21/128-token各32阶段共128份logits/hidden向量与上一阶段逐字节相同，数学与中间精度未调整。
新两region测试中，各原生需求8 MiB，加上8 MiB边界张量后Graph总空间16 MiB，证明共用而非相加。
8个相关测试TU鲜编，唯一过滤运行10/10通过，覆盖普通attention、GDN快照重绑、checked失败不发布/重建、
abandon/close、view/root、旧结果和双slot。两次首次编译配方/警告失败及修正均保留，未重编native或SDK。
多chunk与其他模型的完整旅程仍未因此实测验收，独立shape与并发slot仍各自持有backing，decode和加载输项继续处理。
[源码、精确命令、A/B原始数据与回归](ggml-cuda-caller-workspace.zip)。
本阶段归档后经根目录test.ps1精确清理12个已完成image/map/lib/exp，回收451,978,680B；
2个产品与8个测试object、全部数据/源码/日志和SDK保留。[清理记录](ggml-cuda-caller-workspace-reclaim.zip)

后续全库调用者扫描另迁移8个测试/fixture文件中的9处Direct调用：按实际prepared operation的
workspace_requirement分配并持有所选resource的缓冲，零需求仍传空view。8个CUDA测试TU增量编译成功，
8个代表用例全部通过、无跳过，83项实际依赖复核无漂移；CPU共享fixture分支未运行，未重建native或SDK。
[迁移源码、精确命令和回归记录](ggml-cuda-workspace-consumers.zip)保留扫描边界与未修改的零需求调用者。
归档核对后经根目录test.ps1精确删除4个已完成image/map/lib/exp，回收153,514,557B，保留8个新object。
[清理记录](ggml-cuda-workspace-consumers-reclaim.zip)

同包另含冷常量打包的只读审查：在已接纳原生工作后，若checked drain与析构drain均未证明退休，
当前Status工厂仍进入原生对象和失败产物清理，违反其返回前完成准备的合同。该缺口未修复，未复现UAF；
普通free可能同步、终态设备错误及实际context销毁的情况分别记录，不能把观察错误直接当作仍有活内核。

## Decode 成本复核

较早共同workspace候选（capture复用之前）的三轮128-token历史记录中，decode7–31每步耗时中位数为12.67–12.80ms。
上传、layout更新、绑定和重放准备合计中位数0.33–0.35ms，约2.7%；submit返回前为4.37–4.58ms，
约35%，包含驱动调用和可能的阻塞，与GPU执行重叠，不能直接当作可节省的CPU费用。
此前capacity64的软件trace中，预热后每步有401次原生Graph launch；它说明提交粒度较碎，
不能代替本阶段双方GPU关键路径对照，也未定量证明BF16、转换或路由是decode差距主因。
加载消费者则逐张量读取、分配并同步上传320份权重，尚未流水化；加载与decode问题分别调查。
[历史离线重算脚本、逐步统计及旧trace结构边界](qwen-decode-cost-review.zip)。

最新同窗三对里，Hyle PreferCapture的准备为0.499–0.726ms/步，submit调用0.128–0.133ms，
返回后到完成读回11.142–11.556ms。Peer的batch准备0.14–0.19µs，decode返回0.161–0.243ms，
同步10.205–10.360ms，token访问与采样合计0.018–0.027ms。准备、submit/decode调用、等待的边界不同，
调用期间还可能与GPU交叠；不能把等待全算作GPU内核，也不能把两端分段差全算作独占CPU成本。
每对在入队API返回前的墙钟差为0.454–0.693ms，占对应完整step差的27–43%；
因此准备/入队仍是当前剩余差距的重要候选，不能用历史105.8的跨时目标排除它。

## 原生向量路由实验已撤回

同一128-token输入和31步固定decode的软件trace显示，decode7–31每步Hyle为2400个kernel、401次原生Graph launch，
peer为558个kernel、1次Graph launch；187个Hyle投影实际走cuBLAS gemvx，peer为163个ggml mmvf。
peer的24次差值集中在6144输出行的融合kernel组，但未采集逐逻辑node参数，不能据此要求消除Hyle的BF16舍入边界。
[双方原始trace、分箱和精度边界](qwen-decode-native-route.zip)保留实际记录；软件profile时长不用于公平吞吐比较。

随后仅改两个宿主owner，将187个单向量投影交给原ggml mmvf，保留公共BF16输入/输出边界，未重编native或SDK。
候选实际全部走mmvf，却每步新增374个scalar cast（两向各187），kernel增至2774、Graph launch增至569；
冷Graph步骤减少19并不代表实际提交更少。[候选唯一trace](qwen-decode-native-route-candidate.zip)保留这一反例。
独立无profile的3对B/A、A/B、B/A中，首次prefill中位数1670.7→1503.4 tokens/s，
预热后decode中位数78.042→76.090 tokens/s，显存采样峰值3.972→4.009 GiB，因此撤回默认路由修改及实验测试源码。
这没有证明新增cast是全部回退原因，也没有证明mmvf在其他装配中普遍更慢。

两个定向数学/寿命测试通过，21/128-token决策旅程预测IDs一致，但128份hidden/logits向量仅2份逐字节相同；
这些结果不构成精度、质量或完整模型接受。四个源文件的精确恢复收据、冻结before/candidate/diff、全部失败编链日志、
原始性能数据及去重后的双方决策向量见[已否定实验归档](cuda-native-matvec-rejected.zip)。

## BF16 逐算子直接承载

同日为原ggml CUDA binary/unary模板补齐同BF16输入/输出，以及广播所需的typed Repeat，
消除原先逐节点先转F32、运算后再转回BF16的临时张量。每个算子仍有自己的BF16落存边界，
BF16连续Add/Mul禁用跨节点融合以保留逐节点RNE；未改变原F32/F16与Rsqrt数学。
仅重编3个原CUDA TU和1个Hyle宿主TU，unary保持原precise参数，无整套SDK重建。
原CUDA头的C4819警告保留；初次runtime-only源码派生漏掉IQ1扩展，在编译前被拒绝，
随后使用含IQ1的完整canonical派生，未把该初版用于运行。

同一128-token＋31个固定decode输入、context容量256、两个原槽，3对无profiler独立进程按B/A、A/B、B/A运行；
两端均使用原50ms PID显存采样，表列中位数：

| 指标 | 修改前 | 修改后 |
|---|---:|---:|
| 首次prefill | 1589.1 tokens/s | 1765.1 tokens/s |
| decode7–31 | 77.32 tokens/s | 79.84 tokens/s |
| PID Dedicated显存采样峰值 | 3.972 GiB | 3.939 GiB |

首次prefill提高约11.1%，预热后decode提高约3.25%，显存三次均减少34 MiB。
加载和启动未见改善，llama参考本轮未重跑；采样峰值仍是下界。21/128-token各32阶段共128份
logits/hidden与旧caller-workspace产物逐字节相同，不构成独立质量或全平台验收。
回归有3个不同用例通过：原联合运行Direct与IQ1通过、Graph因fixture借入buffer寿命失败；
修正fixture重置顺序后，Graph单独重跑通过。初版BF16比较和Graph调用API编译失败也保留，未记作首轮全过。
[源码、派生纠正、精确构建、原始A/B与回归记录](cuda-bfloat-elementwise.zip)保存上述边界；
相同决策向量引用旧归档的精确payload哈希，scratch原始数据仍保留。

独立一次Nsight观测确认decode7–31每步实际执行BF16 Add 84、Mul 102、Sigmoid 24次，
BF16→F32 / F32→BF16转换从原801 / 427降为405 / 217；原生GraphLaunch仍为401次，187个cuBLAS投影仍在。
该trace只用于接线和调用计数，不用其时长代替上表吞吐；[完整原始trace](cuda-bfloat-elementwise-trace.zip)独立保留。

归档后通过根目录test.ps1精确清理22个已完成image/map/lib/exp与1个已撤回且未引用的实验header，共808,658,511B；保留10个新增object、8份原始Nsight/SQLite及全部决策数据、源码、SDK和模型。[清理记录](cuda-decode-investigation-reclaim.zip)

## 普通 Graph 的冷绑定与连续捕获

普通算子和区域共用原 Invocation 的冷绑定；连续合格命令可在原 segment 内一起录制，
保留不能捕获的命令及原 Completion 退休边界。ggml CUDA 复用原编码器直接录制，
不执行私有图 warmup 或嵌套 GraphLaunch；原 metadata 启用逻辑保持 Mean 的 CUB 数学选择。
10个不同用例分轮通过：2个Softplus跨provider/双槽用例、5个CPU合同控制、2个旧CUDA capture/checked控制、
1个宽度50000的Mean冷录制与逐bit对照。最初rank-2 MatMul fixture拒绝、CUB宏资格误判及旧owner链接失败均保留，
未记作首轮全过；调整过的旧TensorRegion helper本轮未另运行。

该轮完整Qwen仅运行1对功能探针：21-token prompt＋3个固定decode，Commands与PreferCapture各进程成功，
8份hidden/logits逐字节相同，实际路由分别为Commands和Hybrid。首次prefill冷准备为2.05与51.72ms，
三个decode的冷准备分别落在0.61–1.49与6.40–9.28ms。该轮每步reset/rebind会重新录制，
这不是摊销后的capture吞吐对照，不能宣称decode性能缺口已闭合，也不构成独立精度或质量验收。
[源码、失败经过、精确构建和原始结果](cuda-coarse-capture.zip)保存本轮证据；
决策向量引用既有归档中已逐SHA核实的相同payload，scratch原始数据全部保留。

根目录 test.ps1 已精确清理本轮12个 image/map/lib/exp，共402,821,651B；保留53个对象、16份原始向量，主ZIP不变。[已执行清理记录](cuda-coarse-capture-reclaim.zip)

后续已将同址录制保留在原Invocation：reset/rebind撤销执行权限，重新准备后可复用实际参数未变的录制；
配置或原生资源变化先销毁对应录制，失败也不例外。CommandCapture v2的身份能力默认未知，
由实际后端证明相同TensorView仍代表相同物理参数；不靠Provider或模型名单。ggml CUDA也复用既有指针绑定，
每次仍校验全部端口，仅省去地址未变时重复的Scope、bind与finish_bind。

CPU11与最终CUDA6共17个不同用例通过，两次初始CPU链接配方失败保留；未重编原生数学或SDK。
最终21-token prompt＋3步固定decode单对的8份hidden/logits逐字节等于旧caller归档；prefill及前两次decode各新录7段，
第三次decode新录0段、复用7段。最终同镜像128-token＋31步decode按B/A、A/B、B/A运行三对独立进程，
无profiler或显存监控；以下均按包含上传、冷准备、submit与读回的完整step计时，列三次中位数：

| 指标 | Commands | PreferCapture |
|---|---:|---:|
| 首次prefill | 1716.43 tokens/s | 1660.51 tokens/s |
| decode1–31 | 57.80 tokens/s | 74.06 tokens/s |
| decode7–31 | 62.32 tokens/s | 77.46 tokens/s |

六次定时运行的32个预测ID一致，只有上述独立功能对提供逐bit向量检查。Prefill仍有回退。
旧BF16的79.84同样按完整step的decode7–31统计；复原119个输入的旧闭包同窗控制为68.47/66.07，
该组发生最终绑定去重之前。初轮运行后观测到用户后台GPU竞争，不能据此归因各轮时长，
也不能宣称超过旧79.84或历史差异已经消除。本轮未重测llama、显存或独立质量。
[源码、17项回归、三组独立对照与原始记录](cuda-capture-reuse.zip)保留初轮、历史控制和最终结果；
32份scratch向量均核对旧ZIP的精确payload后引用，未重复复制。

根目录 test.ps1 已按两份归档及精确身份清理本轮33个文件（24个image/map/lib/exp与9个已替代对象），共878,181,587B；保留18个最终本轮对象、1个既有Direct测试对象与32份原始向量，主ZIP不变。[已执行清理记录](cuda-capture-reuse-reclaim.zip)

最新同窗按H/L、L/H、H/L完成三对无profiler、无外部显存监控的128＋31步对照：Hyle PreferCapture/peer的prefill中位1711.33/1278.20、decode1–31为78.60/93.32、decode7–31为83.36/95.16 tokens/s；32个预测ID一致。当前warm差约1.49ms/步（Hyle吞吐低12.4%），不是历史105.8对77.5的跨时差；本轮只确认完整step差距，不宣称内核主因或质量验收。

独立Nsight Systems观测确认当前每步1794/558个kernel与7/1次GraphLaunch，Hyle其中622个BF16↔F32转换；
capture已聚合提交，尚未消除数学节点。当前FFN的rank-2投影与Silu不被同一ggml region接纳，需真实融合lowering，
不能只删除支持谓词或舍去BF16中间舍入。Hyle准备约0.50–0.73ms/步仍是差距候选；软件profile时长不能加总解释未profile的1.49ms。
Nsight Compute各采同一LM-head权重形状的一颗kernel，两端DRAM吞吐约491/489GB/s、峰值占比97.55/97.04%；
该单核观测支持其已接近带宽上限，不代表全部投影或全模型。两端activation/output精度不同，缓存与时钟未锁定。

[当前同窗基线、Nsight/Ncu原始记录与融合边界](cuda-current-peer.zip)保留首次Ncu运行环境失败及peer辅助JSON被命令元数据覆盖的限制；单个LM-head计数器不是全模型性能结论，融合与cold-pack方案尚未实施。

根目录 test.ps1 已精确清理本轮6个image/map/lib/exp，共208,092,023B；保留91个对象、6份原始Nsight/SQLite/Ncu数据，主ZIP不变。[已执行清理记录](cuda-current-peer-reclaim.zip)

## 保留逐节点舍入的 BF16 连续融合

后续在原 ggml CUDA multi-Add/Mul 路径接通 BF16，2–8 个同类节点的每次结果在寄存器中执行 BF16 RNE，
检查广播、单用、发布输出与实际地址重叠，保留不合格后缀的普通执行。原 F32/F16 数学分支不变；
没有新增共同 Graph 路由或执行器。仅重编两个 CUDA TU、两个受当前头文件影响的测试 TU，复用依赖缓存。
三个定向用例通过，覆盖深度2/3/8、广播、双槽换址及发布中间值；3×17形状不覆盖unravel路径。
128-token prefill＋31步固定decode的64份hidden/logits与本轮旧实现逐字节相同，32个预测ID相同。

三对无profiler、无显存监控的独立进程按B/C、C/B、B/C执行，prefill中位1655.49→1668.36、
decode1–31为74.99→74.22、decode7–31为79.04→77.80 tokens/s。warm中位低约1.57%，
本轮未证明性能改善，也未据此归因差异。独立trace确认定向用例真实执行多源BF16 kernel；
完整Qwen没有命中该模式，每步仍有BF16 Add84、Mul102，不能把局部融合能力当作模型优化。
Nsight软件观测只用于调用计数，原driver/collector版本警告保留，不用于吞吐对照。

[实现、精确构建、原始结果及两次trace](cuda-bf16-chain-fusion.zip)记录上述边界。
首轮锁文件树哈希因排序方式错误被CMake拒绝，改为与CMake一致的排序后定向审计通过；
完整FFN等模型融合、准备成本及cold-pack来源/退休所有权缺口仍未修复。

根目录 test.ps1 已精确清理本轮12个image/map/lib/exp，共450,119,947B；保留4个新对象、
128份原始向量与两次原始trace/SQLite，主ZIP不变。[已执行清理记录](cuda-bf16-chain-fusion-reclaim.zip)

## 投影接线与输入/累加精度

尝试让ggml CUDA承接plain rank2与transpose-dense RHS后，Qwen的49个MatMul改路由：
18个in_proj_a、18个in_proj_b、6个q_proj、6个k_proj及LM head；72个FFN投影仍为cuBLAS。
公开step从1204降为1185，但初次候选warm探针仅5.66/9.15 tokens/s；紧邻旧路径为89.88。
这不是性能改善。32个预测ID相同，但64份hidden/logits均非bit-identical，最大绝对差0.25。

一次独立Nsight trace确认每步1977颗kernel（旧1794），GraphLaunch仍为7；新增98次BF16→F32原生转换。
其中一次尺寸恰好248320×2048的LM head转换，每步产生约1.89GiB F32数据；25步转换与后续F32 GEMV
占所记录kernel时长约88.2%。无GPU活动记录的空隙不足以解释主要退化；奇偶步长尾不能由此断言是纯数学或分页。

原生`GGML_PREC_F32`累加请求强制了F32 operands。修复仅限fast NVIDIA、双BF16来源、F32输出：
沿既有BF16 GEMM保留输入，仍用F32累加/输出和公开BF16 RNE；F32 strict、F16、mixed来源及ENV覆盖保持。
仅重编一份CUDA TU，产品patch与v9锁已更新；完整mixed/IQ1生成源码逐字节等于被测源码，CMake定向锁审计通过。
该候选64/64向量逐字节等于旧路径，6项定向测试通过；没有再采修复后的profile，不据此报告新kernel计数。

三对无profiler、无显存监控的新进程按B/C、C/B、B/C执行，128-token prompt、31个固定decode输入、容量256、
Direct进度与PreferCapture相同，按含prepare的完整step计时：

| 指标 | 旧路径中位数 | 扩大rank2接线＋累加修复候选中位数 |
|---|---:|---:|
| 首次prefill tokens/s | 1753.25 | 1239.61 |
| decode1–31 tokens/s | 86.35 | 81.10 |
| decode7–31 tokens/s | 91.39 | 91.03 |

warm基本持平，首次prepare/capture成本增加；未证明净收益。因此最终恢复原plain rank2准入边界，
保留native BF16输入/F32累加修复及batched transpose-dense RHS能力，不新增模型/Provider名单或修改共同Graph。
交付版本重编3个受影响host TU、6个定向用例通过；一次完整128＋31功能探针的64份向量、32个ID、路由与边界均逐字节等于旧路径。
不把该单次运行当性能结论，不代表完整FFN融合、独立质量验收或其他平台/设备验证。

[候选源码、初始失败、数值/路由对照、三对实测与原始trace](cuda-dense-projection.zip)保留推进及撤回依据。
最初Graph测试误把零拷贝View计为无step、修正时误用Result为指针，以及首轮把CUDA单层manifest哈希当mixed/IQ1哈希的集成断言失败均未记作通过。

归档后通过根目录test.ps1精确清理本轮36个image/map/lib/exp，共1,359,901,065B；
保留8个对象、原始trace/SQLite、全部256份向量和复现源码/命令。[已执行清理记录](cuda-dense-projection-reclaim.zip)

## 稳定 SiLU 融合与普通区域的冷偏好

单算子提案只发现一次，region回调借用当前target、实际Provider槽的叶排名。ggml普通组合不覆盖已知更优叶；
真实融合独立提案，不靠普通大岛固定高优先级或屏蔽rank2能力。删去SDPA的旧优先级拒绝，数学准入仍由原Provider负责。
默认cuBLAS投影及raw Context的GGML400/cuBLAS300同分反例均保留独立投影，原187个cuBLAS MatMul节点不变。
没有增加热路由、第二执行器或模型名单，也不承诺完整普通大岛作为另一份packing/workspace预算后备。

F32/BF16普通SiLU现在保留stable-tail和`-Inf→+0`，融合Mul时保留BF16中间RNE，不能替换成另一数值合同的GLU。
按def-use识别可收缩的非连续节点集，公开结果、额外读者、自乘及地址重叠仍受保护；F16该变体仍未接入。
仅重编2个CUDA TU及受本轮接口/源码影响的host TU，复用SDK与依赖。8个CPU、最终12个CUDA用例通过，无skip；
包含双槽换址与旧结果持有、published中间值、数值尾部/非有限值、rank2/batched转置RHS及自然路由。
两次初始缓存配方元数据字段假设失败发生在编译启动前，修正后定向构建通过；不是首轮全部成功。

128-token prompt＋31个固定decode输入、容量256、Direct进度与PreferCapture下，最终候选64份hidden/logits、32个ID
与旧路径逐字节相同。T1/T128均选42个融合候选，公开step1204→1180；capture均首3阶段各record7，随后29阶段各reuse7。
这只证明这条固定旅程的等价，不代替独立模型质量或跨平台验收。

三对无profiler、无外部显存监控的新进程按B/C、C/B、B/C运行，完整step包含准备、提交、等待及token读取：

| 指标 | 旧路径中位数 | 本轮候选中位数 |
|---|---:|---:|
| 首次prefill tokens/s | 1642.54 | 1604.92 |
| decode1–31 tokens/s | 76.99 | 77.19 |
| decode7–31 tokens/s | 81.23 | 80.21 |

本轮未证明提速；warm样本范围旧72.73–81.98、新72.80–84.12。prefill中位低2.29%、warm低1.26%，
不能忽略这些差异，也不能仅凭三对波动归因。现有日志未见冷prepare或submit一致增加；submit返回至token的区段
混合GPU执行、等待与读取，不是纯GPU时长。本轮没有重测llama、内存峰值或独立质量。

独立一次Nsight trace及官方SQLite/CSV确认：decode1–31每步实际执行24个BF16＋18个F32稳定SiLU/Mul融合kernel，
总kernel1794→1752，graph-node1777→1735，GraphLaunch仍7；prefill仅24个BF16物理融合，1932→1908。
全部32阶段除SiLU/Mul相关符号外的kernel次数均相同，转换与cuBLAS未增加；18个卷积后BF16 SiLU仍走SGLang。
driver13.4与collector13.3兼容警告原样保留，profile时长不用于上表吞吐比较。
prefill的18个F32逻辑候选未物理融合仍需处理。源码核对发现SSM的`[1,T,16,128]`在Unary前展成二维，
输出恢复四维后又被Binary展回二维；T128形成`UNARY→RESHAPE4→RESHAPE2→MUL`，破坏原生连续匹配及直接引用条件，
T1则省掉两个同值reshape。这个确定的lowering链与物理计数吻合，尚未逐实例观测guard返回；
后续应在共同lowering消除合法的逆reshape，不另加模型或融合名单。完整gate/up投影融合、其余量化接线、
准备与常量packing寿命缺口也未完成。

[源码、构建与回归、数值对照、三对实测和原始trace](cuda-stable-silu.zip)保留上述区别，避免把区域数当作功能或性能完成。

归档逐CRC/SHA核验后，通过根目录test.ps1精确清理本轮16个image/map/lib/exp，共557,035,045B；
保留11个对象、192份原始向量和原始Nsight/SQLite，不复制SDK或模型。[已执行清理记录](cuda-stable-silu-reclaim.zip)

## 相邻逆 reshape 与 prefill 融合

已消除上述prefill断边：ggml CUDA的`matrix()`仅检查相邻、零偏移、同dtype且连续的reshape，
若其直接源已是目标二维布局则复用该源；O(1)检查，不跨Cast/CONT/Transpose/非零View，不新增缓存或名单。
公开结果仍标记原tensor与root，多读者及原生地址重叠检查保留。只重编2个host TU，SDK、原生CUDA对象与其余链接输入均复用。

8个定向用例通过，无skip。新rank4消费case覆盖F32/BF16、公开SiLU与额外reader、双槽两轮新址及旧结果；
另核norm/unary、9种GGUF矩阵格式、Q8 grouped experts、转置RHS与原BF16逐节点舍入。
量化用例含原生CPU表初始化，整组约42.8秒，未据此扩大验证矩阵。
128-token prompt＋31个固定decode输入的64份hidden/logits与上一轮候选逐字节相同，32个ID、capture计数相同。
当前对照baseline重链接自上一轮最终对象闭包，先逐SHA核对所有输入；不是拿未融合的旧版冒作本轮baseline。

三对无profiler、无显存监控的新进程按B/C、C/B、B/C执行，同一完整step边界：

| 指标 | 修复前中位数 | 修复后中位数 |
|---|---:|---:|
| 首次prefill tokens/s | 1667.86 | 1707.41 |
| decode1–31 tokens/s | 76.54 | 77.46 |
| decode7–31 tokens/s | 81.85 | 81.08 |

prefill中位提高2.37%、完整decode提高1.20%，warm低0.94%；三对样本不证明统计显著性或decode改善。
warm原样本79.05–82.44、新80.15–82.33，不能跨轮拼接吞吐。未新增llama对照、显存峰值或独立质量验收。

独立一次Nsight和官方SQLite/CSV确认，prefill原18个F32独立SiLU及18个Mul被18个稳定gated kernel替代，
1908→1890；其余24个BF16融合保留。decode每步1752、graph-node1735和GraphLaunch7完全不变；
所有32阶段转换次数不变，没有新增多源Add/Mul融合。结合前轮，当前prefill/decode分别比原路径少42个kernel。
driver13.4/collector13.3兼容警告保留，profile只证明调用计数，不用于上表速度归因。

[最小源码改动、回归、逐bit对照、配对实测和原始trace](cuda-reshape-reuse.zip)保留完整依据。
完整投影融合、更多量化接线及冷packing失败退休所有权仍需继续处理；本轮没有修改公共ABI或共同执行器。

归档逐CRC/SHA核验后，根目录test.ps1精确清理12个image/map/lib/exp，共453,720,716B；
保留2个host对象、64份原始向量与原始Nsight/SQLite，复用的native/SDK输入不动。[已执行清理记录](cuda-reshape-reuse-reclaim.zip)

## BF16 向量投影的直接承载

[本轮源码、命令、离线分析与配对数据](cuda-bfloat-matvec.zip)先核原有1752-kernel trace：
warm7–31的kernel时长总和中，187次BF16 GEMV占83.20%，其中48次gate/up占26.88%、
24次down占12.13%、词表head占22.55%；622次BF16/F32转换占5.13%。24个FFN稳定SiLU/Mul
融合仅占0.238%，与gate/up之间没有额外cast。这里的角色按源码和顺序推断；原始CUDA活动可直接
证明计数与时长。该单次profile绑定reshape阶段镜像，不作为最新镜像的速度或差距主因证明。

在同一MMVF模板接通BF16权重、activation和output：精确load-widen、原F32累加/归约、BF16 RNE store，
限定单向量、偶数K、连续且无batch/IDs/fusion；其他形状和原F32实例保留原程序。
相应lowering让这条原生向量路径无需整份activation扩宽和output缩窄。公共MatMul描述不变，
默认Provider优先级未改，也没有添加模型名单、权重副本、GLU或普通SiLU epilogue。
CUDA补丁版本为v11，完整CPU/IQ1/CUDA组合重放source ID为`7caf606377daf938`。

仅增量编译2个native和3个host TU（含准确的Provider版本信息），未重编SDK；首个NVCC attempt因
子cmd未找到cl而失败并保留，缩短PATH并显式固定host compiler后完成。两个新增测试通过、无skip，
覆盖两种RHS布局、两方向ties-to-even、双槽两轮新地址与旧结果、奇数K及F32控制；5项既有CUDA
packing/专家/控制边回归亦通过。默认Qwen128prompt＋31fixed-decode的64份hidden/logits逐byte一致，
32个ID及capture计数相同；这不表示新MMVF已经成为该默认模型路径，也不是独立质量验收。

筛选使用公开Graph的真实RequireCapture和同一份benchmark镜像，每种形状3对AB/BA/AB独立进程。
gate/up和down各轮换3份25,165,824B权重，超过4070的L2；head单份1,017,118,720B。
每进程预热至少3个完整轮换周期，随后128步。下面为各进程中位数再取三轮中位数，单位µs：

| 形状K→N | cuBLAS完整调用 | typed MMVF完整调用 | cuBLAS stream区间 | typed MMVF stream区间 |
| --- | ---: | ---: | ---: | ---: |
| gate/up 2048→6144 | 66.00 | 65.90 | 57.344 | 55.296 |
| down 6144→2048 | 66.50 | 65.50 | 58.160 | 57.152 |
| head 2048→248320 | 2179.95 | 2188.55 | 2154.580 | 2169.340 |

完整调用含event API、submit及wait，stream区间含host接纳/launch间隙，都不是kernel-only时间；
它们也不是模型完整step。小差异与进程间抖动并存，尚未建立统计显著收益，因此保留cuBLAS默认路由。
新载体为后续保留各舍入点的投影融合提供基础；更多转换、归一化子图、冷常量表达式与完整投影融合仍待审查。

归档317项payload共15,490,900B，SHA256
`5bb79e2b6192c9f0d2d13f4e7c2e30c3b48168b1b3eab9a8ddef433013f68388`，CRC与逐项SHA核对通过。
随后经根目录test.ps1精确清理12个image/map/lib/exp，回收449,169,876B；
保留本轮objects、原SDK和64份raw vectors。[已执行清理回执](cuda-bfloat-matvec-reclaim.json)

## 常量表达式冷准备与 RMSNorm 融合

选定 CUDA provider 现沿实际不可变、owned、ready 根发现纯常量子图，仍用原生 Recipe 和原 QueueSequence
计算，保留 dtype、数值顺序与 BF16 RNE。多输出共享一次准备；相同只读 Cast 共享物理结果。
常量 key 增加由 cache 拷贝保活的精确 opaque identity，region extension 为29，共同核心不解释算子。
所有未发布输出均有合法 ready owner、且没有效果或运行工作时，零 dispatch region 保留逻辑/控制依赖，
无需 Queue、原生槽或占位 kernel。普通动态输入与公开 writable 输出保留原合同。

本轮29次host TU编译（含修正后的增量），没有重编native数学或SDK。CPU13与CUDA10个不同用例通过、无skip，
覆盖精确缓存身份/临时key寿命、跨target控制链、全图零Queue、双槽/旧结果、动态与published负控、原packing/专家及BF16载体。
CUDA首轮9/10：原重复Cast共享用例发现packed bytes翻倍；实现修复后原字节断言通过，没有放宽。
另保留旧CPU闭包混入过期Vulkan接线的3次链接失败；CPU测试仅消费CPU/fake provider，最终剔除无关GPU host对象。
这不构成本轮跨平台、完整Vulkan或安装构建验收。

完整Qwen128prompt＋31fixed decode的64份hidden/logits逐byte不变，32个ID不变。新Nsight官方CSV/SQLite一致，
warm7–31每步均为1528 kernels；保留的reshape trace为1752。实际差值是79次BF16→F32 Cast、61次F32 Add、
18次Exp和18次Neg移入冷准备，以及48次F32 Mul并入原有RMSNorm。1024-thread scaled RMS从1→49次/步，
unscaled从48→0；GraphLaunch仍为7次/步。该旧trace只对照物理计数，不能用profile时长声称提速。

单RTX4070/driver617.14、相同权重/输入/精度/容量、AB/BA/AB各3个独立进程，均无profiler或内存采样。
以下为进程中位数；tokens/s使用包含upload、layout、binding、capture准备、submit与wait的`step_seconds`：

| 项目 | 原实现 | 冷表达式准备后 |
| --- | ---: | ---: |
| 首次prefill tokens/s | 1761.42 | 1956.94（+11.10%） |
| 全31步decode tokens/s | 86.10 | 88.20（+2.43%） |
| warm7–31 decode tokens/s | 91.00 | 93.13（+2.33%） |
| 权重加载 seconds | 3.05771 | 3.05267 |
| 形状准备 seconds | 0.314309 | 0.408473 |
| 启动至ready seconds | 3.45598 | 3.54707 |
| 启动至首token seconds | 3.52850 | 3.61272 |
| T128 caller workspace bytes/slot | 35,553,792 | 37,052,416 |
| T1 caller workspace bytes/slot | 2,201,984 | 2,291,584 |

热执行获益伴随约94ms额外形状准备、约84ms首token回退及workspace小幅增加；这些费用没有摊掉或漏计。
仅3对，不宣称统计显著、独立质量验收、总显存峰值改善或新的llama.cpp差距。主要投影数学仍走原cuBLAS。
此前194次常量候选中已移走176次；外部metadata View后的18次conv weight Cast、typed RMS、
GDN L2逐舍入点融合与完整投影融合仍待处理，不能写成冷准备或模型总表已全覆盖。

[源码、失败过程、23项回归、64份向量、配对原始数据与官方trace](cuda-constant-expressions.zip)支持上述结论。
归档622项payload、19,624,311B，SHA256
`b0c8a22d636b618cf65553433c801361e72b86bf9978e2e11b2ede8d7eaebca3`；CRC及逐项SHA核验通过。
随后执行根目录test.ps1，精确删除37个image/map/lib/exp、回收962,971,205B；全部对象缓存、
原始向量与trace保留，源码冻结无漂移。[已执行清理回执](cuda-constant-expressions-reclaim.json)

## metadata View 常量来源与卷积权重冷转换

Graph 现向 region 提供不可变输入的实际物理绑定、真实常量根和根内偏移，owner/ready 资格逐物理副本核定；
声明域中尚待运行期确定偏移的 alias 保留原路径。缓存按边界、根、偏移与精确描述隔离，CUDA 多根表达式
也将全部实际使用的根及偏移纳入 opaque identity。extension 为30；外部 View 仍是原 metadata alias，
没有增加原生 View 算术或改动 Cast 数学、逐节点舍入、默认投影路由。

21次 host TU 编译（首轮19，随后只修两个测试TU），没有重编 native 数学或SDK。最终 CPU19＋CUDA12
共31项通过、无skip，覆盖相同描述的不同切片/根、finite variant、实际跨域副本owner、原borrow lease、
双槽/换址/旧结果、外部View单例Cast无需热Queue、公开结果与动态输入保护。原Cast准入也实际支持并检查了
非连续permute来源。CPU首轮16/19：共用factory读首float时漏取4B subview，另一个多队列fixture漏
prepare_replay后直接解引用失败结果；仅修夹具并重链CPU，产品来源与所有权检查未放宽。初失败保留。

完整128prompt＋31fixed decode的64份hidden/logits逐字节不变，32个ID不变。一次新Nsight trace与官方
CSV/SQLite计数一致；warm7–31的25步每步1510 kernels，前轮留存trace为1528。唯一symbol差值为
BF16→F32 Cast从326→308次/步，对应18份卷积权重转换；GraphLaunch仍为7次。当前Qwen镜像SHA256为
`8bae44757f12381ed34570755e1ffec576cad82ca4542b48be51b2f50535bda9`。
stats首尝试因导出文件mtime检查拒绝；直接读取已成功导出的SQLite完成报告，没有重跑GPU。

本轮没有新的无profiler配对计时，不由kernel减少推导tokens/s、加载时间、显存峰值或llama.cpp差距改善。
typed norm/GDN L2、完整投影融合及其他模型/量化/平台仍未完成。
[源码、构建和初失败、31项回归、原始向量与官方trace](cuda-constant-view-origins.zip)保留本轮依据。
归档466项payload、19,335,291B，SHA256
`15118c9dba4e67466ae96eafe0623f13347b70b176c7dee1c31b709217d8f2c8`，CRC及逐项SHA核验通过。
经根目录test.ps1精确删除16个image/map/lib/exp，回收412,338,576B；对象、SDK、原始向量和trace保留，
源码冻结无漂移。[已执行清理回执](cuda-constant-view-origins-reclaim.json)

## BF16 RMSNorm 的扩宽与写回融合

复用原CUDA RMSNorm模板的F32逐线程累加、256/1024线程归约及rsqrt，接通
BF16→F32 Cast→RMSNorm→可选F32 scale→BF16 Cast。BF16在读取时精确扩宽，归一化与缩放后显式RNE写回；
F32原分支不改。另有BF16 norm→F32 scale的链路仍保中间BF16舍入，不并入weighted变体。
匹配按实际边、dtype、布局、读者与地址，正确计入CPY self引用；公开中间值和额外读者保原计算，
输出与实际输入/scale（含OP_NONE叶）重叠时保守回退。没有新增公共descriptor、Provider或Graph特殊分支。

成功增量为2个native TU＋3个host TU，没有重建SDK。初次native编译因验证overlay缺少父级include路径，
误取原norm.cuh而失败；修验证脚本后编译通过。第一次CUDA执行实际15项全过，但exact筛选另需一个
未被原闭包链接的旧norm控制，检查器如实失败；追加该测试TU，仅重链CUDA后最终16项通过、无skip。
新3项含独立GPU F32 oracle、微小数/FTZ/Inf/NaN、两种中间舍入合同、双槽换址/旧结果与RequireCapture。
仅NaN按类别核定，其余逐bit；F32既有FMA合同不放宽。保留初失败和检查器拒绝。

完整Qwen128prompt＋31fixed decode的64份hidden/logits逐byte不变，32个ID和7段capture复用不变。
一次新Nsight trace的官方CSV/SQLite计数一致：warm7–31每步1414 kernels，前轮留存trace为1510。
48个1024线程weighted RMS改为BF16直接输入/输出，BF16→F32 Cast从308→260、反向从217→169次/步；
其余norm只是模板符号增加类型参数，物理次数不变。仍有1个1024线程weighted、12个256线程weighted、
18个256线程unscaled走原F32路径，未把这些31项写成已覆盖；未用role推断代替原生匹配原因证明。

无profiler或内存监控的AB/BA/AB共三对独立进程，对照为前轮View常量修复后的原镜像，权重、输入、精度、
容量、消费者与计时边界相同；tokens/s仍使用包含upload/layout/binding/capture准备/submit/wait的step_seconds：

| 项目 | 原路径中位 | 融合后中位 |
| --- | ---: | ---: |
| 首次prefill tokens/s | 1937.36 | 1909.53（−1.44%） |
| 全31步decode tokens/s | 87.47 | 88.04（+0.65%） |
| warm7–31 decode tokens/s | 91.82 | 92.06（+0.26%） |
| 权重加载 seconds | 3.08638 | 3.06454 |
| 形状准备 seconds | 0.416200 | 0.416687 |
| T128 caller workspace bytes/slot | 38,191,104 | 38,191,104 |
| T1 caller workspace bytes/slot | 2,115,712 | 2,115,712 |

prefill三个原样本为2015.17/1937.36/1880.71，新样本为1910.95/1871.00/1909.53 tokens/s，范围重叠且存在漂移。
本轮没有证明端到端改善或统计显著性，也未排除小幅prefill回退；保留原始差异继续调查。
减少kernel不能推导显存下降：原native allocator仍可为被省略的中间结果预留槽。本轮未测总显存峰值、
新llama.cpp差距或独立模型质量；GDN L2、完整投影融合及其余模型/量化/平台仍待处理。

补丁v12按生产mixed CPU＋CUDA IQ1工具重放，三份变化源码及vendor lock均核对；
source ID为`f2f72269789731e6`，实际Provider版本沿生产CMake形式绑定此ID。
[源码、构建和初失败、16项回归、原始向量、配对计时与官方trace](cuda-rms-cast-fusion.zip)保留本轮依据。
归档315项payload、18,713,667B，SHA256
`1406ad467a8c79ae2dd826f9be2bf06c4628d4321f7ff95aab2853e7b34c8893`，CRC及逐项SHA核验通过。
经根目录test.ps1精确删除16个image/map/lib/exp，回收607,916,618B；对象、SDK、原始向量和trace保留，
源码冻结无漂移。[已执行清理回执](cuda-rms-cast-fusion-reclaim.json)

## RMS 同址分配的实际拒绝原因与修复

对原v12镜像只增临时host元数据日志，完成一次128-token prefill＋1步decode诊断；每个shape精确覆盖
48个已命中和31个原路径RMS，无日志截断。31个中，18个完整BF16 widen→RMS→narrow因输入/输出同址被拒，
实际ne/nb/字节区间完全相同；其余13个原生region入口为F32，未追到Graph ValueId来源，不能归为同址或直接伪装BF16。

v13仅修输入alias资格：同址、同BF16 dtype、同shape/strides、两端连续、同字节范围且不溢出时允许原地执行。
原256/1024线程block归约同步全部初读，每线程随后只读写自己的列；其他row不相交，scale仍须严格disjoint。
部分重叠、不同映射、广播、公开中间值/额外读者等保护不放宽；原kernel、RNE、epsilon、分配及公共API不改。
生产补丁按mixed CPU＋CUDA IQ1重放，source ID为`94060dde81cf1bbd`；本轮只编1个native main和2个host TU。

17项CUDA通过、无skip，新增实图覆盖内部BF16 producer、两种block宽度、公开F32中间值对照、双槽换址/旧结果和RequireCapture；
原Direct GPU逐步运算作oracle。完整128＋31固定输入的64份hidden/logits逐byte不变，32个ID和7段capture复用不变。
一次新官方trace的CSV/SQLite逐symbol计数一致：25个warm步全部1414→1378 kernels，18个unscaled RMS换typed读写，
BF16→F32从260→242、反向169→151，其他物理kernel次数不变。workspace仍为T128的38,191,104B与T1的2,115,712B/slot。

无profiler/内存监控、与v12同闭包的AB/BA/AB三对独立进程：

| 项目 | v12中位 | v13中位 |
| --- | ---: | ---: |
| 首次prefill tokens/s | 1867.29 | 1862.15（−0.28%） |
| 全31步decode tokens/s | 77.68 | 77.37（−0.39%） |
| warm7–31 decode tokens/s | 81.49 | 82.00（+0.62%） |
| 权重加载 seconds | 3.19187 | 3.21990 |
| 形状准备 seconds | 0.449098 | 0.447860 |

warm原样本89.58/80.52/81.49，新样本87.13/80.29/82.00；有明显跨进程漂移，不能宣称稳定提速，
也不能将本轮绝对速度与前轮约92tokens/s直接比较。没有重测llama.cpp、总显存峰值或模型质量。
36组GDN L2及完整投影/FFN仍待融合；现有读写转换393次/步也不意味着都能直接删除。

[诊断日志、源码与审查、17项回归、64份向量、配对计时和官方trace](cuda-rms-inplace.zip)保留本轮依据。
验证脚本的封存过滤/字段名、首次两步参数与31份decode输入不匹配、筛选器去重数量未同步等初失败亦保留；
这些均发生在封存或消费者/检查器的执行前检查，没有重编SDK或把失败写成通过。

## GDN L2 的逐节点舍入融合与冷布局复用

一次128prompt＋1步decode元数据诊断完整记录72个L2原生图，无截断。每个核心含11个native节点、10个实际kernel：
BF16平方、扩宽、metadata reshape、F32 sum、BF16 sum、BF16加epsilon、扩宽、严格sqrt、fast div、BF16缩放值、BF16乘原输入。
REPEAT numerator与最后BF16→F32转换在核心外。T128还发现同一pitched输入被三次CONT/reshape；T1直接用相同leaf。

CUDA私有lowering现按本次build的ValueId缓存matrix结果，复用同一值的连续化；checked ID临时生产者同步清空/恢复缓存。
没有按裸地址或存储根合并不同值，也不引入热CSE、全局缓存或另一套执行槽。新native matcher只剥真正同源的连续零偏移reshape，
按完整数据流、CPY self引用、公开输出/额外读者及实际别名检查；读取最终Mul的真实x，拒绝部分重叠及epsilon/numerator重叠。

新核保留SUM_ROWS原512/32/128线程选择、八路部分和顺序和thread-zero结果。square、sum、加epsilon、整个Rsqrt、末乘共五处BF16 RNE；
明确的RN sqrt与原fast division分别执行，未换成rsqrtf或挪动epsilon。限定函数的SASS导出确认转换边界和独立division；
编译器可用RSQ及修正/特殊值路径实现RN sqrt，不能仅看某条MUFU或FTZ指令就判为近似替换。对象无PTX，
该结论结合源码合同、SASS和实际数值测试，不是全IEEE/NaN payload形式证明。

增量仅2个native＋3个host TU，未重编SDK。19项CUDA通过、无skip，含独立Direct GPU逐步oracle、T1/T128/T2、
1024列线程分支、正/零/负/最小正规BF16 epsilon、微小数/Inf/NaN、双槽换址/旧结果/RequireCapture，
以及全部中间值公开、额外sum reader和padded输入。完整Qwen64份hidden/logits逐byte不变，32个ID和7段capture复用保持。
生产mixed CPU＋CUDA IQ1补丁source ID为`5a1fced46d7403e2`，当前Qwen镜像SHA256为
`8070f3517db1c3a000ac04a58bd57f09cea07ab96d80c51a6b89c32df8bab285`。

官方trace/CSV逐symbol计数一致：25个warm步全部1378→1054 kernels，36个L2核心全部10→1；两向Cast各少72次。
含冷准备的prefill首窗口同样少324个kernel，另少72次512KiB D2D/2Dcopy、共36MiB，符合36条链各三份CONT变一份。
这项copy变化不计入kernel数。两个trace的部分重放节点bytes标签另有不一致，无法由SQLite离线确定真实descriptor；
因此不由整表SUM(bytes)推断总带宽改善或回退，保留逐节点调查和限制。未重新收集GPU trace以追这些metadata差异。

无profiler/外部内存监控的v13/v14 AB/BA/AB三对，同固定输入/精度/容量/消费者与full-step边界：

| 项目 | v13中位 | v14中位 |
| --- | ---: | ---: |
| 首次prefill tokens/s | 1866.13 | 1862.96（−0.17%） |
| 全31步decode tokens/s | 79.55 | 82.28（+3.43%） |
| warm7–31 decode tokens/s | 83.20 | 86.15（+3.55%） |
| 权重加载 seconds | 3.21579 | 3.16833 |
| 形状准备 seconds | 0.460686 | 0.440474 |
| T128 / T1 workspace bytes/slot | 38,191,104 / 2,115,712 | 相同 |

warm原样本83.20/82.63/84.95，新样本86.15/86.02/94.16；decode三个相邻配对均快，末对幅度也明显变大。
本轮观察到正向decode收益，但样本有漂移，不固定其长期提升幅度；prefill中位基本持平。
没有总显存峰值或独立质量验收；13处RMS区域切口、完整投影/FFN、其余模型/量化和平台仍未收完。
[源码、诊断、19项回归、64份向量、编译数学依据、配对计时和官方trace](cuda-gdn-l2-fusion.zip)保留本轮依据。

### 当前版本与 llama.cpp 的新同窗对照

参考仍为原d9e03f1、同源BF16转换GGUF与原公开GPU greedy；重新核实9个obj/lib及模型/输入身份，仅重链一次peer，
没有重新编译或改采样。首次六进程结果也保留，但发现Hyle `prepared` 的cerr输出落在step内，而peer报告在计时外。
测试消费者现保存准备时长，在token完成的finished之后输出日志；输入上传、batch/layout、绑定、replay、submit/wait/readback仍全部计时。
仅重编1个consumer TU，新镜像再核64份向量/32个ID相同；随后复用同一peer镜像，另开目录完成H/L、L/H、H/L三对，未覆盖首次记录。

| 项目 | Hyle | llama.cpp |
| --- | ---: | ---: |
| prefill step tokens/s | 1978.29 | 1289.08 |
| 全31步decode tokens/s | 81.82 | 91.96 |
| warm7–31 decode tokens/s | 85.74 | 93.31 |
| 权重/模型加载 seconds | 3.18993 | 1.83199 |
| 形状/ctx准备 seconds | 0.447684 | 0.007693 |
| 启动到ready seconds | 3.72945 | 1.91595 |
| 启动到首token seconds | 3.79363 | 2.01724 |

warm三样本Hyle86.10/85.74/84.29、peer93.31/95.25/90.32，中位Hyle仍低8.11%；全31步低11.03%。
Hyle在step前预建两种shape，peer的decode图维护在step内，因此首个prefill step数字不能宣称完整冷prefill更快；
启动到首token已含各自加载和准备，Hyle仍有明确输项。不同权重容器和加载API的细项不能混称为同一函数边界。
前后组有漂移，不能把Hyle首次组77.96到本组85.74全部归因于移出日志；原L2 v13/v14配对的两臂日志边界相同。
全部固定输入和32个预测相同，但中间数值边界并不bit等价，也没有独立质量targets。

另一次fresh peer trace确认warm每步558个kernel、1次GraphLaunch，官方CSV/SQLite一致且无graph API错误；
同轮Hyle数学镜像为1054个、7次。peer每步另有993280B sampled-logits回读，不能与32条4B token端点混成64步；
两类端点间无kernel，分别分窗得到相同计数。物理count仍不等于吞吐比例，也不由这些不同时间的trace计算同窗端到端差。
workspace之外的Hyle新总显存/内存峰值未重测。`peer-comparison-reporting/interpretation.json`、原组、peer trace及计时改动源码都在上述归档中。

## RMS 区域切口与映射加载

13处漏掉的typed RMS来自保守外部frontier：scale Cast/Add在先，激活的外部Gather/View引发切分，随后RMS又首次遇到scale。
Provider现按真实边补充私有Cast→RMS→Cast短链，复用原叶偏好、route/implementation和共同收缩检查；
已在同一普通区域的66条链不重复提案，scale仍独立冷准备，不改共同Graph或native数学。
新增回归覆盖正链、公开两个F32中间值、外部控制读者、冷scale及双槽换址/旧结果/RequireCapture。

消费者复用公共只读FileMapping，源范围检查后直接同步上传，替掉320份临时host vector及总3.763GB的分配、零初始化和文件复制。
仍是320次设备分配和同步上传；参考mmap分支也逐tensor同步，不能将加载差全部归为异步上传。
映射、上传和设备所有权沿现成合同，没有增加loader或异步pool。独立CMake显式链接Mem产品。

仅增量编译3个host TU，零native/SDK编译。首次Qwen手工link漏了platform_fs，保留失败后追加已有库并重链，未重编任何TU；
正常CMake的mem_vm公开依赖已含该库。20项CUDA零失败/skip，完整64份hidden/logits逐字节一致，32个ID及7段capture复用保持。
镜像SHA256为`6ebf57e026299db17b99ac68b55762f9f00b9fa96e320b51f3806e25c66a2d1a`。

一次独立官方trace确认每个warm步1054→1028 kernels，两向Cast各少13次，其他kernel次数不变；
typed RMS共61 weighted＋18 unscaled（49个1024线程weighted、12个256线程weighted）。T128/T1 workspace分别38,191,104/2,115,712→36,618,240/2,103,424B每槽。
workspace是报告值，不代表总显存峰值；物理count与吞吐仍分别判断。

随后同一窗口按旧H/新H/L、L/旧H/新H、新H/L/旧H交错九个独立进程，全部固定128prompt＋31decode、容量256，
无profiler或外部内存监控；旧新Hyle的日志都在step计时外。同源权重、固定输入和32预测全部一致，参考仍为原d9e03f1公开GPU greedy。

| 项目（3进程中位） | 改前Hyle | 当前Hyle | llama.cpp |
| --- | ---: | ---: | ---: |
| prefill step tokens/s | 1885.09 | 1960.17 | 1321.18 |
| 全31步decode tokens/s | 82.74 | 82.27 | 93.09 |
| warm7–31 decode tokens/s | 86.66 | 85.68 | 95.28 |
| 权重/模型加载秒 | 3.14169 | 1.23386 | 1.79653 |
| shape/ctx准备秒 | 0.433810 | 0.436926 | 0.007782 |
| 启动到ready秒 | 3.66737 | 2.13070 | 1.87501 |
| 启动到首token秒 | 3.73567 | 2.19494 | 1.97754 |

加载阶段中位少60.7%，完整启动到首token少41.2%，当前首token仍比参考慢约11.0%。加载细项API边界不同，完整首token时间已含各自准备。
warm旧样本86.66/85.18/86.71，新84.95/85.68/89.09，参考94.14/96.19/95.28；当前较旧中位低1.13%，
没有观察到本批decode收益，也不足以由这三点证明稳定回退。与同窗参考仍差10.07%，不能用减少26个kernel宣称解决。
prefill step仍有预建shape边界差异，不用该数字宣称完整冷prefill胜出。未测新内存/显存峰值，未独立验收模型质量或其他平台。

后续优先查原执行槽每token重复发现的6次全计划扫描及FFN双投影。peer少24次projection来自gate/up配对，
另30个projection epilogue融合来自24次down/residual及6次attention输出/residual；这由模型源码、顺序和grid交叉归因，trace本身无逻辑node标签。
不能将peer未保留中间BF16舍入的融合直接替换现数学。简单拼接权重会额外保留1.125GiB，且原bank和两种shape计划仍持有原租约，
因此不作为当前默认修复；无复制的双weight实现和复用成熟Lt的方案需要分别评估数学、寿命与实测收益。

[源码、20项回归、64份向量、九进程对照、原始trace及初次链接失败](cuda-rms-candidate-frontier.zip)保留本批依据。

## 原执行槽中的 batch 选择复用

普通prepare此前每token做六次全计划visitor，清理并重新发现固定的batch能力、执行槽和metadata槽。
现只在原Invocation资源payload中缓存一次成功的选择；当前Qwen把对1167个步骤的重复扫描改为遍历六个实际attention槽。
原reset的busy/结果/退休检查、owner、NodeId、完整layout/schema、Queue/options、native配置和metadata更新均保留。
只缓存不可变top-level身份，调用级QueueRef/layout/metadata-source在每次退出清除；失败不保留可用资格，pending模式继续原动态发现。
未增加公共API、Plan索引、执行器或payload副本。缓存向量保留已分配容量，不据此宣称整个prepare无分配。

仅鲜编1个CUDA配置的host batch TU；Qwen的64份hidden/logits逐字节一致、32个预测及capture旅程相同。
另用CPU配置鲜编batch和既有多Context测试，增加move、暖态重复layout/错误Queue拒绝、拒绝提交旧配置及数值恢复。
首跑发现手工闭包仍含旧CPU复制对象，只接受system_resource，实际错误与当前源码不同。未放宽fixture或产品检查；
鲜编当前mem/resource、batch_transfer和CPU复制测试后，两个定向case通过、零失败/skip，覆盖未证明映射拒绝及wrapper别名重叠。
合计6个host编译命令、零native/SDK编译。Vulkan旧闭包的Graph/RegionExtension ABI已漂移，该GPU用例本轮未运行。

同一九进程交错窗口，旧新Hyle的124个链接输入中仅batch.obj不同，其余123项逐SHA相同；所有固定输入和32个预测一致。
当前Hyle镜像SHA256为`d84bbdb0fd1bdbbcda5e8de2fb2d6f1fd2a695fc34981ccbff6d1e1514755602`。

| 项目（3进程中位） | 改前Hyle | 本批Hyle | llama.cpp |
| --- | ---: | ---: | ---: |
| prefill step tokens/s | 1958.42 | 1914.89 | 1263.72 |
| 全31步decode tokens/s | 81.75 | 82.61 | 93.88 |
| warm7–31 decode tokens/s | 85.03 | 86.77 | 95.50 |
| 权重/模型加载秒 | 1.24923 | 1.23381 | 1.80255 |
| shape/ctx准备秒 | 0.455602 | 0.448561 | 0.007486 |
| 启动到首token秒 | 2.24190 | 2.23026 | 1.99142 |

warm样本旧86.23/85.03/84.58、新87.78/85.74/86.77，中位观察到+2.04%，仍低于同窗参考9.15%；
prefill step中位回退2.22%，且它仍存在预建shape的边界差异。没有显著性或稳定幅度结论。
六个Hyle进程均32次prepare，recorded21/reused203；warm cold_batch每进程中位数之中位数0.3979→0.3863ms，
但每进程均值没有稳定下降。该字段还含layout、绑定与prepare_replay，不能当作被缓存扫描的独立CPU耗时。
本轮无新physical trace、显存/内存峰值或独立模型质量验收，不能从相同数学对象声称重新观测了kernel数。

[源码、完整模型核对、CPU先失败后通过、九进程计时和离线分析](cuda-hot-prepare-selection.zip)保留全部边界。

## BF16 FFN 双投影与实际原生图

本批在CUDA provider私有候选中接入单token、连续BF16激活与两份BF16权重的gate/up→普通稳定SiLU→Mul，
不拼接或复制整份权重，不接管prefill及其他量化域。原MMVF模板复用双投影累加与归约，新增epilogue在既有strict unary TU实例化；
gate投影G、up投影U、SiLU结果A和最终Y各保留BF16 RNE，SiLU仍用普通稳定公式。
F32点积的归约树允许与成熟Lt路径不同；逐节点舍入保留不等于完整MatMul逐bit相同，也不等于模型质量已验收。
Provider拒绝候选时保留原路由；已选候选若native matcher未命中，其普通ggml回退也不能称为Lt。

首稿按连续四个math节点匹配，遗漏真实原生图插入的权重TRANSPOSE：冷路由虽选中24个impl4，官方trace却全部零命中，
每步退为两次MMVF＋SiLU＋Mul，原SiLU/Mul融合也被切断，kernel从1028增至1052，首组测速回退。
修复只接纳四个math之间实际被另一投影读取的一个只读权重TRANSPOSE，核对同源、零offset、dtype、精确shape/strides、
唯一reader及无OUTPUT；实际跨度五节点返回skip4，数学值的真实usecount、公开输出、额外读者、别名和精度保护不放宽，L2闭包未变。
首稿零命中、原测速及全部失败过程保留，不能用冷选择或测试通过代替物理命中。

最终mixed CPU＋CUDA IQ1版本v16，source ID为`e0bf7135273ee756`，Qwen镜像SHA256为
`f1300408225479e73870a0b43cc655f43389c3499ee889ca74a57b439e068fef`。
修复仅鲜编native主TU与provider版本host TU后重链；28项CUDA全部通过、零skip，含三个新增数值/逃逸/长点积用例及25项既有回归。
最终官方CSV与SQLite逐symbol计数一致：31个decode步各实际命中24次dual epilogue，单步kernel从1028降至980，
原24个BF16稳定SiLU/Mul核被吸收，18个F32稳定SiLU/Mul核保持；prefill仍1554个kernel且无dual，GraphLaunch始终每步7次。
Nsight的driver13.4／collector13.3兼容警告原样保留，无graph API错误；trace用于核实物理结构，不用于推导无profiler吞吐。
T128/T1报告workspace每槽由36,618,240/2,103,424B变为36,618,240/2,054,272B，未重测总显存峰值。

同固定128prompt＋31份decode输入、容量256，在旧Hyle/新Hyle/llama.cpp交错九个独立进程中计时，无profiler或外部内存监控：

| 项目（3进程中位） | 改前Hyle | v16 Hyle | llama.cpp |
| --- | ---: | ---: | ---: |
| prefill step tokens/s | 1971.61 | 1887.66 | 1277.56 |
| 全31步decode tokens/s | 79.0476 | 79.9241 | 91.5089 |
| warm7–31 decode tokens/s | 82.8346 | 83.1370 | 91.2554 |
| 权重/模型加载秒 | 1.27240 | 1.28846 | 1.77992 |
| shape/ctx准备秒 | 0.452063 | 0.449415 | 0.007677 |
| 启动到ready秒 | 2.19348 | 2.20699 | 1.86193 |
| 启动到首token秒 | 2.25883 | 2.27865 | 1.96194 |

full中位观察到+1.11%、warm +0.365%，prefill step低4.26%；warm三样本旧81.68/83.91/82.83、新86.43/83.14/82.33，
参考89.07/101.83/91.26，存在明显漂移，未证明稳定提速。当前full仍比同窗参考低12.66%、warm低8.90%，首token慢16.14%，输项没有解决。
加载和准备细项的API边界不同，Hyle在step前准备两种shape，peer图维护仍在step内；不能用prefill step宣称完整冷prefill领先。
九进程固定输入和32个greedy ID均相同，不以kernel减少比例推算吞吐收益。

完整模型数值诊断中，baseline的64份hidden/logits与旧reference逐byte相同；新路径仅prefill两份相同，decode的62份有差异，
但所有输出有限、32个greedy ID相同。相对baseline，hidden/logits最大relative L2分别1.5200%/1.8023%，最大绝对差0.5/0.2109375；
每份向量的RMS、relative、ULP及原始数据均保留，不能用同32个ID宣布质量通过。
metadata修复后的64份向量与v15未命中的MMVF回退逐byte相同，说明本次命中未再引入该组输入上的数值差异；
这不消除相对Lt基线的变化，也不是全域等价证明。

同一组128prompt＋31份输入的独立Torch参考随后实际完成；eager与既有F32-RoPE诊断变体各从空cache独立跑32步，
只读取原权重和输入，不接纳Hyle的hidden、logits或state。两臂对两参考均32/32 top1相同，但误差指标并非一致改善：
对eager，logits平均relative L2旧1.1614%／新1.2634%，平均KL(reference→Hyle)旧0.00043108／新0.00045233；
对F32-RoPE，平均relative L2旧1.1904%／新1.1838%，平均KL旧0.00030783／新0.00052187。
31份固定下一输入的平均NLL旧1.5193117／新1.5204487；这是benchmark tape的诊断，末步没有目标，不是独立语料质量验收。
没有事后新增容差，也不能据同32个ID或某一个均值宣布模型质量通过。脚本、真实环境、逐phase指标与原始向量均保留。

本轨迹自身163次投影占kernel duration sum的88.85%，其中139次为普通cuBLASLt、24次为新dual MMVF；
FFN gate/up＋down占投影时间47.38%、head占26.51%。这只能定位本身热点，不能直接解释相对另一时间采集参考的差额。
既有三种真实尺寸的18进程独立筛选已含head K2048/N248320，且同为BF16直接输入／F32累加／BF16输出；
Lt与普通MMVF的head wall中位约2179.95／2188.55us，不能盲目重复“全部单投影改走GGML”的假设。

当前两边投影数均163，非投影实际为817／395，净多422次。按物理symbol家族对齐：

| 家族（每warm步） | Hyle | llama.cpp | 差额 |
| --- | ---: | ---: | ---: |
| BF16/F32 Cast | 223 | 0 | +223 |
| F32二元计算 | 138 | 36 | +102 |
| BF16二元计算 | 54 | 0 | +54 |
| Repeat | 48 | 0 | +48 |
| 单独激活 | 60 | 18 | +42 |
| Concat | 42 | 18 | +24 |
| I32/F32 Cast | 12 | 0 | +12 |
| RoPE或三角函数 | 24 | 12 | +12 |
| 其他家族合计 | 216 | 311 | -95 |
| 合计 | 817 | 395 | +422 |

其他家族合并了attention/merge、token选择、GDN、conv、cache、normalization、copy、gated activation、scale和gather，
完整正负项见`metadata-fix/non-projection-gap.json`。归一化把Hyle L2 core与RMS合并计数后双方均115，
但数学合同仍分开；peer projection epilogue也会吸收表外独立运算。计数差不是可直接删除的逻辑算子清单。
下一批先查这些转换／逐点／repeat的实际来源与寄存器内舍入承载，特别是显式频率RoPE的分解路径；不因其自身耗时占比小而略过。

原始源码、编译/测试日志、独立参考与数值向量、两次物理trace和两组九进程计时见[本批证据](cuda-bf16-dual-projection.zip)。

## 中间精度与转换的源码调研

本节仅检查锁定源码、输入清单与既有 trace，没有新增构建、GPU 执行或质量/性能通过结论。
用户要求先调研设计；消费者 BF16/F32 开关与混合 MatMul 都仅为 `.scratch/architecture-refactor-2026-10-18/cuda-activation-precision/`
下的未接入草稿。产品 `tools/qwen35_text/main.cc` 仍为 SHA256
`38ee18ff552ee4db15663469457d293219d4f6e4bbbef3ae4037af8c16350869`。

本地官方 Qwen3.5 Python 源 `modeling_qwen3_5.py` 的 SHA256 为
`0e7410f5251e5c324a5628c5340ee3551f7a6a505ce398569fcc3b5f3ac07f7a`。
config 的 BF16 不是全图要求：320 份文本权重中实际 284 BF16、36 F32，后者是18层的 A_log 与 GDN norm scale。
模型中的 norm、softmax、GDN、RoPE 和反馈状态有各自的升精度与舍入边界。
其中 HF 的 RoPE 将 F32 sin/cos 转回输入类型后旋转；Hyle 当前显式频率 RoPE 保持 F32 旋转、仅末尾窄化，
不能把它称为完全相同的逐步舍入。已选正式 Flash-0731 的官方实现又同时包含 FP4 权重、动态 FP8 操作数、
F32 累加与 BF16 输出，进一步说明权重格式不能推导所有计算精度。

实际对照的 `llama-matched-consumer/ggml-package/ggml-config.cmake` 指向既有静态库与
`.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d`，
ggml version 为 `456172ec733a135778adcd32d00e576a58232e45-hyle`；不是本批 Hyle v16 的源码。
转换清单中实际是187份 BF16、133份 F32，其中97份原 BF16 小权重精确扩宽为 F32；总数仍为320。

| 路径 | 实际行为与限制 |
| --- | --- |
| peer 激活图 | ggml GET_ROWS 与普通 MUL_MAT 输出 F32；FFN 不保留 Hyle G/U/SiLU 逐节点 BF16 RNE |
| peer decode | MMVF 直接读取 BF16 权重，逐项扩宽后与 F32 激活相乘并 F32 累加、输出 F32；不先生成整份 F32 权重 |
| peer T128 prefill | 此尺寸离开 MMVF/MMF，默认 cuBLAS 将 F32 激活临时转为 BF16，以 BF16 操作数、F32 累加产生 F32 输出 |
| peer KV/state | 本对照显式选择 BF16 KV；hybrid recurrent/conv history 保持 F32，与激活或权重格式独立 |
| Hyle 普通 F32 MatMul | 同 dtype 的输入/输出及 F32 累加；CUDA 另要求 F32 来源精度，不凭累加字段允许 TF32/BF16 乘法 |

源码定位：peer `src/ggml.c` 的 GET_ROWS/MUL_MAT 类型推断；`src/ggml-cuda/ggml-cuda.cu` 的
1822–1824/1884–1895（MMVF）、1520–1528/1561–1568/1672（cuBLAS），以及 `mmvf.cu` 的
280–292/347–379/657–659。prefill 与 decode 不能仅按输出 F32 这个名字认定为相同乘法精度。
既有 peer SQLite 中 F32→BF16 转换186次、BF16→half 12次均位于含冷准备的首个阶段窗口；
decode 1–31 两类均为零。首窗口不等于纯 prefill；warm 零外部转换核也不等于整个运行没有转换。

因此817／395的非投影核差额既包含融合/承载不足，也包含数值配方不同；不能把223个独立 Cast 全部称为冗余，
也不能用 peer 作为当前 BF16 逐节点舍入的 bit oracle。反过来，保留这些舍入并不要求独立 kernel 或显存往返。
现行 Hyle 的157次扩宽、66次窄化中，198次来自18层 conv/GDN/gate，24次来自RoPE、1次来自head；
48次 Repeat 中36次来自L2标量分子广播、12次来自RoPE频率广播。这里是源码与实际物理网格的数量对齐，
不是逐节点 NVTX 归因，也不证明全部可删除或贡献了同等比例的时间。

共同 MatMul 目前要求同 logical dtype，cuBLAS 与 ggml CUDA admission 也保留该限制；这不必然要求立即扩展公共 API。
`X:F32 × Cast(W:BF16→F32)` 已能表达数学，缺口可以在冷 lowering 融合精确扩宽、直接读取原权重。
但现有常量表达式/packing 会先物化 F32 结果，新的承载须在物化/分配前保留原源与真实读者，
不能只删除热 Cast。若直接放宽当前 ggml CUDA admission，严格 F32 的大矩阵路径还可能每次将 BF16 权重
扩入原生池；head 单份 F32 scratch 为2,034,237,440B，且池可按活跃槽保留，不能把这种草稿称为省显存方案。

设计收敛见[精度配方与冷编译](../../../architecture/compute-design.md#精度配方与冷编译)：
先分清等价的融合/转换承载与改变数值配方，再以实际路径检查质量、吞吐和资源代价。
本轮尚未选择另一精度配方作为默认，也未证明全 F32 或全 BF16 更快、更准。

## 保持精度的显式频率 RoPE 承载

本批保留现有 BF16 激活/端口与 F32 旋转数学，CUDA 私有 lowering 将原 RoPE 分解改为单个 native 节点。
位置先 I32→F32 RN，再乘实际频率，独立 strict sin/cos、四个 RN/FTZ 乘积和独立加减，最后回原输出类型；
partial tail 保留原宽化/窄化语义。没有切换为 HF 的另一套中间舍入、逆频率或近似三角函数。
频率 shape 本身决定旋转宽度，避免重复 int32 参数缩小已有维数域；同 phase 的三角函数供各 head/batch 复用，
单 launch 不申请临时 payload。内部完全相同的 dense 输入映射可复用，部分重叠及覆盖位置/频率拒绝，公共 alias 不变。
私有 marker 不进入原 YaRN/逆频率融合；新的绑定失败通过既有 native failure 边界返回。

锁定版本为 `...-bf16-dual-explicit-rope-v17`，source ID `96da4225333d2bd6`，
vendor tree SHA256 为 `d0d2a342d335334c21bdb83616bf0bebe73b34fc60f746d19814bd9c36088c2c`。
所有 mixed CPU＋CUDA IQ1 patch 均逐条唯一重放并核 SHA，CMake dependency lock audit 通过。
增量仅2个 native（main/unary）和3个 host（tensor/provider/test）TU，没有 SDK 或全量构建；
首编发现 initializer_list 混入 const/nonconst 指针不能推导，改为明确类型的数组后全闭包编译/链接通过，失败日志保留。
主测试消费者源码未改；当前镜像 SHA256 为 `a6b8fa6ac6997a92d956c3976678ece4c2d2112d412da9eb83f1d6a33dd3ddf2`。

30项相关 CUDA 测试全部通过、零失败/skip，其中两项新增测试含6个定向 tuple：F16/BF16/F32、两种布局、
共享/批次位置、静态/逐序列频率、partial tail、超过2^24的I32位置、负值、subnormal、零、Inf/NaN。
GPU oracle 直接运行旧 `explicit_rope.h` primitive 图，检查不含新 RoPE，公开中间值以保留独立计算边界；
有限值、Inf、符号零逐 bit 比较，NaN比较分类。候选含双槽、换址、Commands/RequireCapture、
内部单读者 producer、公开 producer 和旧结果检查；没有新增公共测试数学接口或 CMake 依赖。
实际 unary 对象的 SASS 保留独立 FMUL.FTZ 与 FADD.FTZ 序列；sin/cos 内部仍可包含其合法 FMA，不能声称全函数无FMA。

完整128prompt＋31固定decode输入的两次独立旅程中，改前镜像使用原 v16 的124项对象闭包；
两臂各64份 hidden/logits 均与保留的 v16 current 向量逐 byte 相同，所有结果有限、32个预测及7段capture旅程一致。
这只证明本次输入上的数值保持，不消除上批FFN点积树相对Lt/Torch的已有差异，也不替代独立语料质量判断。

一次官方 Nsight CSV/SQLite 计数一致，prefill和31个decode阶段各实际执行12个新RoPE kernel，GraphLaunch均保持7次：

| 每warm步实际kernel | v16 | 本批 |
| --- | ---: | ---: |
| 全部 | 980 | 812 |
| BF16/F32独立转换 | 223 | 199 |
| I32/F32独立转换 | 12 | 0 |
| Repeat | 48 | 36 |
| F32二元计算 | 138 | 54 |
| Concat | 42 | 18 |
| 独立sin/cos | 24 | 0 |
| 新显式RoPE | 0 | 12 |

prefill实际1554→1362 kernels。投影163次保持，非投影817→649；peer历史同输入轨迹非投影395，
剩余差额仍含数学配方差异，不能视为全可删除。T128/T1 workspace每槽
36,618,240/2,054,272→33,964,032/2,033,408B；未重测总显存/内存峰值。
driver13.4／collector13.3兼容警告保留，未见graph API错误；profile耗时不进入以下吞吐结果。

同窗旧Hyle／新Hyle／llama各3个fresh进程交错，无profiler或外部内存监控：

| 3进程中位 | v16 Hyle | 本批 Hyle | llama.cpp |
| --- | ---: | ---: | ---: |
| prefill step tokens/s | 1888.11 | 2021.39 | 1290.57 |
| 全31步decode tokens/s | 80.5688 | 82.8350 | 88.3265 |
| warm7–31 decode tokens/s | 83.7385 | 85.6576 | 90.3880 |
| 启动到首token秒 | 2.23753 | 2.24595 | 2.00046 |

观察到full +2.81%、warm +2.29%、prefill step +7.06%，但每臂仅3进程；warm样本旧83.74/82.17/84.44、
新86.52/83.98/85.66、参考90.39/87.06/91.68，仍有漂移，没有稳定幅度或显著性结论。
当前full低同窗参考6.22%、warm低5.23%；不能与上一窗口12.66%直接相减，将全部差额变化归因于本批。
Hyle仍在step前准备两种shape，prefill step与peer不是完整冷工作对齐；首token比较也仍输。
九进程固定输入、预测和Hyle捕获旅程一致；保留peer原采样与readback，没有改变输出工作量。

接下来仍需处理199个BF16/F32独立转换中的conv/GDN/gate边界与head、36个L2分子广播，以及投影/首次录图成本。
不把这批CUDA结果推导为其他模型、量化或平台已经补全。[源码、失败、对象身份、全部向量及原始实测](cuda-explicit-rope.zip)。

## 标量广播与保留舍入的 L2 输出融合

本批没有新增模型特例、公共算子或另一套执行器。CUDA 私有 lowering 对 F32 首标量 Divide 和 Rsqrt 分子
构造真实只读 scalar View，再冷设置广播 shape 与零步幅；底层 owner、依赖与读取范围仍是一个元素。
没有要求 Repeat 在原生节点序中紧邻 L2，也不物化重复数组。其他 Binary 仍保留原承载：原生普通二元核
支持零步幅，不代表旧 MatMul＋bias/GLU 融合的 dense 读取同样合法，旧 bias matcher 的布局资格仍待补全。

L2 原核增加实际 scalar numerator 读取与 F32 输出变体，保留原 SUM_ROWS 的八路局部累加、block/tree、
严格 sqrt、fast div/FTZ 及五处 BF16 RNE。最后先做 BF16 RNE，再精确扩宽到 F32；不是直接写未舍入 F32。
只接受真实单元素 source、零偏移与零步幅的只读 View，动态 numerator 从实际地址读取；原 dense row numerator 路径保留。
最终 BF16 值私有时可融合 BF16→F32 CPY；公开值或额外读者保留原可见边界。
F32 目的须与输入、epsilon、numerator 不重叠，原 BF16 完全同址 dense 映射继续按原合同处理。

版本 `hyle-ggml-cuda-resource-iq1-inference-v18`，source ID `971b3d4968812a0f`，vendor tree
`82b4452dae9332bdb5a1f294c3d62f0cc32d7b8b0aaaa27a984001064748e815`。
mixed CPU＋CUDA IQ1 manifest 逐条唯一重放、全部 SHA 与 CMake lock audit 通过。
仅增量编译2个 native TU（main/norm）及3个 host TU（tensor/provider/既有 L2 测试），两次链接通过；
复用旧 v17 baseline 和 peer 镜像，没有另复制 SDK、权重或重编公共 Graph/消费者。
新消费者镜像 SHA256 `b1c4f5d2c9740527473a9c4fc7b18443b6ddff0285330d49079725b4cf72b893`。

32项相关 CUDA 测试全部通过，零失败/skip。新增覆盖 T1/T128、逐行非均匀 numerator、BF16 公开中间值及额外读者、
不带扩宽的 BF16 输出；动态 scalar 为 −0.75、2.5、Inf/NaN，并含 F32/F16 普通标量左除法。
oracle 在 host 独立复制 dense numerator，GPU 仍执行原分阶段数学，未复用新广播 View；有限 witness 检查最后 BF16 舍入。
候选检查双槽、两轮换址、Commands/RequireCapture 和旧结果。完整128prompt＋31固定decode输入的两个新旅程中，
两臂各64份 hidden/logits 与保留 v17 current 逐 byte 相同、全部有限，32预测、31输入及32阶段×7段capture一致。
这不消除早先 FFN 点积树相对 Lt/Torch 的已有差异，也不代替独立模型质量判断。

单次官方 Nsight 采集的 CSV/SQLite 计数一致，无 graph API 错误；每个阶段实际命中36个
`hyle_bf16_l2_core<float, (bool)1>`，12个显式RoPE保持。首次离线解析只匹配字面 `true`，
漏掉 demangle 的 `(bool)1`；保存旧解析与结果后只重跑离线分析，未重采 GPU。

| 每warm步实际kernel | v17 | 本批 |
| --- | ---: | ---: |
| 全部 | 812 | 740 |
| BF16/F32独立转换 | 199 | 163 |
| 其中 BF16→F32 | 145 | 109 |
| Repeat | 36 | 0 |
| L2 core（本批为scalar/F32变体） | 36 | 36 |
| 投影 | 163 | 163 |
| GraphLaunch | 7 | 7 |

prefill 1362→1290 kernels；非投影649→577，peer历史同输入非投影395仍不是等价工作量。
T128/T1 workspace每槽33,964,032/2,033,408→33,947,648/2,033,152B；未重测总显存／内存峰值。
driver13.4／collector13.3兼容警告保留。profile耗时不进入吞吐比较。

同窗旧Hyle／新Hyle／llama各3个fresh进程交错，无profiler或外部监控：

| 3进程中位 | v17 Hyle | 本批 Hyle | llama.cpp |
| --- | ---: | ---: | ---: |
| prefill step tokens/s | 2059.00 | 2044.25 | 1280.72 |
| 全31步decode tokens/s | 93.8228 | 94.7909 | 103.1100 |
| warm7–31 decode tokens/s | 98.3019 | 98.4952 | 105.6618 |
| 启动到首token秒 | 2.04139 | 2.02101 | 1.81920 |

观察到full +1.03%、warm +0.20%、prefill step −0.72%，每臂仅3进程；warm旧98.65/98.30/97.71、
新100.18/98.50/97.94、参考105.66/104.37/106.80，样本重叠，未证明稳定提速。
当前full低同窗参考8.07%、warm低6.78%。三个引擎均比上一窗口更快，不能把跨窗口速度或差距变化归因于本批。
Hyle仍在step前准备两种shape，prefill step不代表完整冷工作领先，首token仍输。
九进程输入、32预测和Hyle捕获旅程一致；peer原采样/readback不变。

离线复查旧 v17 实际轨迹，投影占其自身kernel时长和89.64%，199个转换占2.00%、36个Repeat占0.57%；
这是同一轨迹内的耗时构成，不是端到端占比，也不能与peer另一轨迹相减估算可提速幅度。
下一步更多调查实际投影与准备／提交关键路径。现有host区间可含等待并与GPU重叠，尚无函数级CPU归因，
不能把7次GraphLaunch或Completion wait全算成可删除CPU成本。

本次静态架构复查未在共同Graph/graph_batch发现按Qwen模型名或尺寸准入的分支；RoPE/FFN/L2按数学、dtype、
真实边、布局和读者匹配。CPU默认排名仍含实测精确shape偏好，实际能力须先由实现承认，不等于模型支持名单。
主要剩余是原生融合布局资格、共同编译/执行代码的职责收拢，以及跨模型、量化、状态和平台的真实调用链；
当前Qwen成功不能证明八模型齐备，也不足以宣布架构最终稳定。继续复用现有合同和总表，不增加审查框架。
[本批源码、构建、回归、静态审查及原始实测](cuda-gdn-l2-epilogue.zip)。

## 原生融合的布局、读集与量化尾行界

这批修复通用后端合同，未加入Qwen模型名、尺寸、CMake选项或新公共算子。九处旧MMVF/MMVQ的
MatMul/bias/scale/GLU承载共用一处资格：bias实际活跃轴须符合最终输出索引，ADD_ID另核专家轴；
gate bank、scale、dtype、元素步长和对齐按真实kernel读取检查。保留合法offset、padding和singleton无关stride，
不以全contiguous代替实际合同。真实读取包含OP_NONE叶及view祖先，不能来自被消除的producer，
也不能与dst重叠；即使逐元素bias看似可原地，载体的restrict合同仍要求拒绝该融合，保留独立计算。

另发现MMVQ standard核用`stride_col_dst`作尾行掩码；列pitch不等于行数，普通padded输出或odd-N indexed
输出可多预取／写一行。现将已有host真实`nrows_x`传入原kernel，修正bias预取和最终store两处掩码；
不复制设备调参表、不禁用所有padding、不改归约或launch选择，多token专用MoE核原真N路径不变。

版本`hyle-ggml-cuda-resource-iq1-inference-v19`，source ID `470dd6082f0c063e`，vendor tree
`4d9b09e716d5f1e7f6443d124df0729151db9b66810b6ebcf2397257e18d17bd`。
新增MMVQ edits在CUDA manifest先应用，再与原8项IQ1 edits唯一重放，全部mixed SHA及CMake lock audit通过。
复用原SDK/库和对象，仅鲜编main/MMVQ两个native TU、provider身份和既有stable_silu测试两个host TU；
新MMVQ对象在原archive解析前提供同一外部入口，没有重建SDK。当前Qwen125、CUDA133输入闭包，
旧反例镜像为原132项CUDA闭包只换同一新测试对象。主消费者源码未改。

新增3个测试，包含F32普通bias的dense offset／隔列／零步幅，GLU的dense及单lane隔列bias，
indexed bias的dense及padded专家stride；Q8_0另查K32/N7普通padded目标与单token两slot专家选择。
各两组输入。原生metadata先展开，断言真实MM→ADD等相邻序列；公共lowering会先CONT非连续bias，
且没有普通ADD_ID primitive，因此这些负控使用既有raw ggml测试接缝，不声称公有入口直接触发。
F32 oracle公开原MM/ADD，仍运行原GPU GLU；Q8使用相同packed bytes的普通dense MM计算全部专家行后
按IDs选取，不把旧odd-N ID作为oracle。真实backing保留额外权重行和输出哨兵，旧错误仍落在分配内。

首次新实现35项中34通过，GLU fixture在执行后读取bias根，却仅标INPUT。gallocr的INPUT只提前分配，
首bias最后读者结束后可合法回收给later upMM；首异常0.0625恰为upMM首元素。
修正测试给两个实际后读根OUTPUT寿命，不公开数学中间值、不放宽根未变和最终bit断言；
失败源码、日志和修正diff均保留，native代码未因此更改。随后同一修正测试下：

| 实际执行 | 结果 |
| --- | --- |
| 原native＋同一新测试 | 3项全部assert失败，正常GoogleTest exit1，无skip/设备崩溃 |
| 修复native＋相关闭包 | 35项全通过，零失败/skip |
| 一次fresh完整128prompt＋31固定输入 | 64份hidden/logits与保留v18逐byte相同，全部有限，32预测／31输入／32×7capture一致 |

当前Qwen镜像SHA256 `e0d11c1eafa5bd92cb54b61697c9f949dcbcea9a377cc1028f00378ff9a06fb2`。
这批没有重跑九进程吞吐、完整模型profile或总内存峰值，不据正确性变化宣称提速或独立质量验收。

只对前两个小测试采集一次官方Nsight：CSV/SQLite逐symbol一致，共88个kernel，其中MMVF fused10、
unfused32、独立GLU8、Add20、ADD_ID6、gather12。driver13.4／collector13.3警告保留，无graph API错误。
初始静态预期8次融合假定dense GLU整段命中，实际仍拆分为合法MM＋bias；保存原失败分析后仅离线修正解释，
未重采GPU。真实10次证明融合没有全部关闭，不能据此宣布完整GLU命中或所有机会都已覆盖。
原未融合分配可回收已消费的weight/input，完整融合却仍需读取它们；新增range guard须拒绝重叠。
这与当前分解一致，但本trace没有tensor地址，具体复用哪个backing尚未直接观测。需要时应在分配前表达真实融合依赖，
不能放宽读写保护或复制影子buffer来追命中数。

另两项源码审查已形成后续草稿，尚未应用／构建／GPU验证：F16 MMVF融合误从最终ADD/GLU参数读取精度，
应显式传原MatMul精度；非默认OAI alpha/limit不能被默认融合吞掉。共同warm输出bind在每token reset后
反复扫描常量，当前消费者源码有51输出与418常量，即每轮至少21,318次常量check迭代，另加51P；
这是迭代数，不是耗时。冷索引草稿保持原动态权限、输入/输出和planned alias检查，尚不能宣称已省去这些开销。
[本批源码、失败、红绿结果及原始小trace](cuda-fusion-layout.zip)。
