"""Generate only scratch sources/diff for immutable-allocation alias lookup."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)


helpers = '''// The index contains positions in the existing immutable physical binding
// arrays, not another payload/permission owner. Values below constant_ids.size()
// are C entries; the remaining positions are P entries in prepared_values.
ByteRange immutable_alias_range(const detail::PlanState &plan,
                               std::size_t index) noexcept {
  if (index < plan.constant_ids.size())
    return byte_range(plan.constant_bindings[index].storage());
  return byte_range(
      plan.prepared_values[index - plan.constant_ids.size()].binding.storage());
}

// Opaque handles are only equality/order keys here, never interpreted as CPU
// addresses. std::less supplies a total pointer order across allocations.
bool allocation_less(ByteRange left, ByteRange right) noexcept {
  const auto *a = &left.resource.resource();
  const auto *b = &right.resource.resource();
  if (a != b)
    return std::less<const mem::MemoryResource *>{}(a, b);
  return std::less<void *>{}(left.handle, right.handle);
}

Status build_immutable_alias_index(detail::PlanState &plan) noexcept {
  auto &order = plan.immutable_alias_order;
  order.clear();
  const auto constants = plan.constant_ids.size();
  if (plan.prepared_values.size() > SIZE_MAX - constants ||
      !order.try_reserve(constants + plan.prepared_values.size()))
    return plan_allocation_failure();
  for (std::size_t index = 0; index < constants; ++index) {
    // Match the old C loop's physical-instance eligibility. Its remaining
    // same-value/bound/planned-alias checks still run at bind time below.
    const auto instance =
        plan.external_instances[plan.constant_ids[index].ordinal()];
    if (instance != detail::kNoWorkspaceRequest &&
        plan.constant_bindings[index].storage().size() != 0 &&
        !order.try_push_back(index))
      return plan_allocation_failure();
  }
  for (std::size_t index = 0; index < plan.prepared_values.size(); ++index)
    if (plan.prepared_values[index].binding.storage().size() != 0 &&
        !order.try_push_back(constants + index))
      return plan_allocation_failure();
  std::sort(order.begin(), order.end(), [&](std::size_t left, std::size_t right) {
    const auto a = immutable_alias_range(plan, left);
    const auto b = immutable_alias_range(plan, right);
    if (allocation_less(a, b)) return true;
    if (allocation_less(b, a)) return false;
    // Preserve the original C-before-P and per-array order in each group.
    return left < right;
  });
  return Status::Ok();
}

'''

old_loops = '''    for (ValueId constant : plan.constant_ids) {
      Status status = check(constant);
      if (!status.ok())
        return status;
    }
    for (const auto &prepared : plan.prepared_values) {
      if (overlaps(candidate, byte_range(prepared.binding.storage())))
        return Status::InvalidArgument(
            "external graph output overlaps an immutable prepared value");
    }
'''
new_loops = '''    // Only immutable physical allocations are indexed. Every dynamic input,
    // output, effect, resource/owner and binding permission gate is unchanged.
    const auto &order = plan.immutable_alias_order;
    auto current = std::lower_bound(order.begin(), order.end(), candidate,
        [&](std::size_t index, ByteRange range) {
          return allocation_less(immutable_alias_range(plan, index), range);
        });
    for (; current != order.end(); ++current) {
      const auto immutable = immutable_alias_range(plan, *current);
      if (!same_allocation(candidate, immutable))
        break;
      if (*current < plan.constant_ids.size()) {
        // Keep all old C semantics, including same-value/unbound skips and
        // matches_planned_alias; a constant is not unconditionally disjoint.
        HYLE_RETURN_IF_ERROR(check(plan.constant_ids[*current]));
      } else if (overlaps(candidate, immutable)) {
        return Status::InvalidArgument(
            "external graph output overlaps an immutable prepared value");
      }
    }
'''

paths = ['src/graph/executable.cc', 'src/graph/plan_state.h']
before = {path: (ROOT / path).read_text(encoding='utf-8') for path in paths}
after = dict(before)
path = paths[0]
after[path] = replace(after[path], 'Status validate_external_alias(', helpers + 'Status validate_external_alias(')
after[path] = replace(after[path], old_loops, new_loops)
after[path] = replace(after[path], '    plan.prepared_values.clear();\n',
    '    plan.immutable_alias_order.clear();\n    plan.prepared_values.clear();\n')
after[path] = replace(after[path], '    CompiledStorageReport storage_report;\n',
    '    if (status.ok())\n      HYLE_RETURN_IF_ERROR(build_immutable_alias_index(plan));\n    CompiledStorageReport storage_report;\n')
path = paths[1]
after[path] = replace(after[path], 'constant_artifacts(allocator_value), prepared_values(allocator_value),\n',
    'constant_artifacts(allocator_value), prepared_values(allocator_value),\n        immutable_alias_order(allocator_value),\n')
after[path] = replace(after[path],
    '  container::SmallVector<PreparedValue, 0, mem::AllocatorRef> prepared_values;\n',
    '  container::SmallVector<PreparedValue, 0, mem::AllocatorRef> prepared_values;\n'
    '  // Cold allocation-key order into constant_bindings then prepared_values.\n'
    '  // No dynamic native outputs, extra payload owners or permission cache.\n'
    '  container::SmallVector<std::size_t, 0, mem::AllocatorRef> immutable_alias_order;\n')

diff, records = [], []
for path in paths:
    source = ROOT / path
    for directory, text in [('before', before[path]), ('source', after[path])]:
        target = STAGE / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        # Preserve the source's line-ending convention and exact before bytes.
        if directory == 'before':
            target.write_bytes(source.read_bytes())
        else:
            raw = source.read_bytes()
            newline = '\r\n' if raw.count(b'\r\n') == raw.count(b'\n') else '\n'
            target.write_bytes(text.replace('\n', newline).encode('utf-8'))
    records.append(dict(before=identity(STAGE/'before'/path), after=identity(STAGE/'source'/path)))
    diff.extend(difflib.unified_diff(before[path].splitlines(keepends=True),
        after[path].splitlines(keepends=True), fromfile='a/'+path, tofile='b/'+path))
(STAGE/'changes.diff').write_text(''.join(diff), encoding='utf-8')
(STAGE/'source-freeze.json').write_text(json.dumps(dict(
    scope='Scratch-only; no product application/build/GPU.', files=records,
    lookup_complexity='O(log(C+P)+K), K is immutable ranges sharing actual resource+opaque allocation handle',
    persistent_index_bytes='8*capacity on this x64 build, allocated once by the Plan metadata allocator',
    permissions_cached=False, public_API_changed=False, private_Plan_ABI_changed=True), indent=2)+'\n', encoding='utf-8')
print(STAGE/'changes.diff')
