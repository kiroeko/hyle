param([switch]$ReclaimScalarL2)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimScalarL2) { throw 'Use -ReclaimScalarL2 for this batch.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18'))
$taskStage = Join-Path $taskRoot 'cuda-gdn-l2-epilogue'
$archiveReceipt = Get-Content -LiteralPath (Join-Path $taskStage 'archive-verification.json') -Raw | ConvertFrom-Json
if (-not $archiveReceipt.CRC_and_payload_SHA_verified -or (Get-FileHash -LiteralPath $archiveReceipt.path -Algorithm SHA256).Hash -ne $archiveReceipt.sha256) { throw 'Verified archive required.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskStage 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes) { throw "Target changed: $resolved" }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
@{targets=$targets;bytes=($targets | Measure-Object bytes -Sum).Sum;recursive=$false;objects_retained=$true;latest_qwen_cuda_and_shared_peer_retained=$true;old_baseline_relinkable=$true} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskStage 'reclaim-receipt.json') -Encoding utf8
