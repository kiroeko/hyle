from pathlib import Path
import difflib
import hashlib
import json
import re

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-gdn-l2-epilogue/native-source/src/ggml-cuda/ggml-cuda.cu'
before = BASE.read_text(encoding='utf-8')
sha = lambda value: hashlib.sha256(value.encode()).hexdigest()
assert sha(before) == 'fe01504e910a901c3eeea4a3a896a4e28af14a42c1d8a1719d9c412da9da10cf'

helper = r'''// MMVF/MMVQ receive weight/input/output strides, but their epilogues do
// not receive separate bias strides. Admit the actual mapping they read,
// including legal offset views and padding shared with the final output.
static bool ggml_cuda_matvec_fusion_layout(const ggml_cgraph * graph, int first, int count,
        const ggml_tensor * mm, const ggml_tensor * dst, const ggml_cuda_mm_fusion_args_host & fusion) {
    if (!mm || !dst || !mm->src[0] || !mm->src[1] ||
        (mm->op != GGML_OP_MUL_MAT && mm->op != GGML_OP_MUL_MAT_ID) ||
        mm->type != GGML_TYPE_F32 || dst->type != GGML_TYPE_F32 ||
        !ggml_are_same_shape(mm, dst) || dst->nb[0] != sizeof(float)) {
        return false;
    }
    const bool indexed = mm->op == GGML_OP_MUL_MAT_ID;
    const ggml_tensor * weight = mm->src[0];
    const ggml_tensor * input = mm->src[1];
    const ggml_tensor * ids = indexed ? mm->src[2] : nullptr;
    const bool quantized = ggml_is_quantized(weight->type);
    if (input->type != GGML_TYPE_F32 || input->nb[0] != sizeof(float) ||
        weight->nb[0] != ggml_type_size(weight->type)) {
        return false;
    }
    for (int axis = 1; axis < GGML_MAX_DIMS; ++axis) {
        if ((dst->ne[axis] > 1 && dst->nb[axis] % sizeof(float)) ||
            (input->ne[axis] > 1 && input->nb[axis] % sizeof(float)) ||
            (weight->ne[axis] > 1 && weight->nb[axis] % ggml_type_size(weight->type))) {
            return false;
        }
    }
    if (!quantized) {
        // MMVF's activation loads are float2. Its selected column stride is
        // divided by two even for a singleton column, as in the old carrier.
        if (reinterpret_cast<uintptr_t>(input->data) % alignof(float2) ||
            input->nb[indexed ? 2 : 1] % sizeof(float2)) {
            return false;
        }
        for (int axis = 1; axis < GGML_MAX_DIMS; ++axis) {
            if (input->ne[axis] > 1 && input->nb[axis] % sizeof(float2)) {
                return false;
            }
        }
    }
    if (indexed && (!ids || ids->type != GGML_TYPE_I32 || ids->nb[0] != sizeof(int32_t) ||
                    (ids->ne[1] > 1 && ids->nb[1] % sizeof(int32_t)))) {
        return false;
    }
    if (fusion.gate && (fusion.gate->type != weight->type ||
        !ggml_are_same_shape(fusion.gate, weight) || !ggml_are_same_stride(fusion.gate, weight))) {
        return false;
    }
    const auto bias_layout = [&](const ggml_tensor * bias) {
        if (!bias) {
            return true;
        }
        if (bias->type != GGML_TYPE_F32 || bias->ne[0] != dst->ne[0] ||
            (bias->ne[0] > 1 && bias->nb[0] != sizeof(float))) {
            return false;
        }
        if (indexed) {
            // ADD_ID reads bias[row, expert_id], not bias[row, selected_slot].
            // Both matvec epilogues use dst.nb[1] for that expert stride.
            return bias->ne[1] == weight->ne[2] &&
                (weight->ne[2] == 1 || bias->nb[1] == dst->nb[1]);
        }
        if (!ggml_are_same_shape(bias, dst)) {
            return false;
        }
        for (int axis = 1; axis < GGML_MAX_DIMS; ++axis) {
            if (dst->ne[axis] > 1 && bias->nb[axis] != dst->nb[axis]) {
                return false;
            }
        }
        return true;
    };
    const auto scale_layout = [&](const ggml_tensor * scale) {
        return !scale || (weight->type == GGML_TYPE_NVFP4 && scale->type == GGML_TYPE_F32 &&
            ggml_is_contiguous(scale) && ggml_nelements(scale) == (indexed ? weight->ne[2] : 1));
    };
    if (!bias_layout(fusion.x_bias) || !bias_layout(fusion.gate_bias) ||
        !scale_layout(fusion.x_scale) || !scale_layout(fusion.gate_scale)) {
        return false;
    }
    const auto range = [](const ggml_tensor * tensor, uintptr_t & begin, uintptr_t & end) {
        if (!tensor || !tensor->data) {
            return false;
        }
        begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t bytes = ggml_nbytes(tensor);
        if (bytes > UINTPTR_MAX - begin) {
            return false;
        }
        end = begin + bytes;
        return true;
    };
    uintptr_t dst_begin = 0, dst_end = 0;
    if (!range(dst, dst_begin, dst_end) || dst_begin % alignof(float)) {
        return false;
    }
    // Include OP_NONE leaves; the older generic range checker skips them.
    // Matrix/activation/ids/scale reads can be reused across output blocks.
    const ggml_tensor * reads[] = {weight, input, ids, fusion.gate,
        fusion.x_bias, fusion.gate_bias, fusion.x_scale, fusion.gate_scale};
    for (const auto * read : reads) {
        if (!read) {
            continue;
        }
        // The carrier reads these from memory. A scalar scale derived from
        // an elided projection (e.g. a one-row mm*mm) is not an external input.
        for (const ggml_tensor * source = read; source; source = source->view_src) {
            for (int node = first; node < first + count; ++node) {
                if (source == graph->nodes[node]) {
                    return false;
                }
            }
        }
        uintptr_t begin = 0, end = 0;
        if (!range(read, begin, end) ||
            ((read == input || read == ids || read == fusion.x_bias || read == fusion.gate_bias ||
              read == fusion.x_scale || read == fusion.gate_scale) && begin % alignof(float))) {
            return false;
        }
        if (!quantized && (read == weight || read == fusion.gate) &&
            begin % (2 * ggml_type_size(weight->type))) {
            return false;
        }
        // Both carriers declare dst RESTRICT. Even an exact pointwise bias
        // alias must keep the original MatMul plus separate inplace ADD.
        if (begin < dst_end && dst_begin < end) {
            return false;
        }
    }
    return true;
}

'''
anchor = 'static bool ggml_cuda_should_fuse_mul_mat(const ggml_tensor * ffn_up,'
assert before.count(anchor) == 1
after = before.replace(anchor, helper + anchor, 1)
start = after.index('static int ggml_cuda_try_fuse(')
prefix, tail = after[:start], after[start:]
calls = [
    ('q', 'up_n', 'cgraph->nodes[glu_idx]', 'n_ops'),
    ('q', 'up_n', 'cgraph->nodes[glu_idx]', 'n_ops'),
    ('f', 'up_n', 'glu', '5'), ('q', 'up_n', 'glu', '5'),
    ('f', 'up', 'glu', '3'), ('q', 'up', 'glu', '3'),
    ('q', 'mm_node', 'out_node', 'n_ops'),
    ('f', 'mm_node', 'bias_node', '2'), ('q', 'mm_node', 'bias_node', '2'),
]
pattern = re.compile(r'(?m)^( +)ggml_cuda_mul_mat_vec_([fq])\(\*cuda_ctx, src0, src1, ids, (.+), &fusion_data\);$')
matches = list(pattern.finditer(tail))
assert len(matches) == len(calls), len(matches)
for match, (kind, mm, dst, count) in reversed(list(zip(matches, calls))):
    assert match.group(2) == kind and match.group(3) == dst
    indent = match.group(1)
    guard = (f'{indent}if (!ggml_cuda_matvec_fusion_layout(cgraph, i, {count}, {mm}, {dst}, fusion_data)) {{\n'
             f'{indent}    continue;\n{indent}}}\n')
    tail = tail[:match.start()] + guard + tail[match.start():]
after = prefix + tail

relative = 'src/ggml-cuda/ggml-cuda.cu'
out = STAGE / 'source' / relative
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(after, encoding='utf-8', newline='\n')
old_lines, new_lines = before.splitlines(True), after.splitlines(True)
context = 3
while True:
    edits = [{'before': ''.join(old_lines[g[0][1]:g[-1][2]]),
              'after': ''.join(new_lines[g[0][3]:g[-1][4]])}
             for g in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_grouped_opcodes(context)]
    replayed = before
    for edit in edits:
        if not edit['before'] or replayed.count(edit['before']) != 1:
            break
        replayed = replayed.replace(edit['before'], edit['after'], 1)
    else:
        if replayed == after:
            break
    context *= 2
    assert context < len(old_lines) * 2
files = [{'path': relative, 'before_path': str(BASE.relative_to(ROOT)),
          'before_sha256': sha(before), 'after_sha256': sha(after), 'edits': edits}]
diff = ''.join(difflib.unified_diff(old_lines, new_lines, fromfile='a/'+relative, tofile='b/'+relative))

# Replay the current mixed+CUDA+IQ1 source once; keep this small changed input
# locally so deleting an unrelated dependency cache cannot alter a replay.
q_relative = 'src/ggml-cuda/mmvq.cu'
q_snapshot = STAGE / 'before/mmvq.cu'
if q_snapshot.is_file():
    q_before = q_snapshot.read_text(encoding='utf-8')
else:
    combined = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-gdn-l2-epilogue/combined-manifest.json'
    row = next(row for row in json.loads(combined.read_text(encoding='utf-8'))['files'] if row['path'] == q_relative)
    upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
    q_before = (upstream / q_relative).read_bytes().replace(b'\r\n', b'\n').decode()
    assert sha(q_before) == row['before_sha256']
    for edit in row['edits']:
        assert q_before.count(edit['before']) == 1
        q_before = q_before.replace(edit['before'], edit['after'], 1)
    assert sha(q_before) == row['after_sha256']
    q_snapshot.parent.mkdir(parents=True, exist_ok=True)
    q_snapshot.write_text(q_before, encoding='utf-8', newline='\n')
assert sha(q_before) == 'aed17acc08480240340b2b4fc0f53dd209e4c2757dd3d38364c17b3fdee03355'
q_after = q_before
old = 'const uint32_t ncols_x, const uint3 nchannels_y, const uint32_t stride_row_x'
new = 'const uint32_t ncols_x, const uint32_t nrows_x, const uint3 nchannels_y, const uint32_t stride_row_x'
assert q_after.count(old) == 2  # std kernel and switch_fusion signature
q_after = q_after.replace(old, new)
old = 'vx, vy, ids, fusion, dst, ncols_x, nchannels_y, stride_row_x'
new = 'vx, vy, ids, fusion, dst, ncols_x, nrows_x, nchannels_y, stride_row_x'
assert q_after.count(old) == 2  # fusion and ordinary standard kernel launch
q_after = q_after.replace(old, new)
old = 'vx, vy, ids, fusion, dst, ncols_x, nchannels_y_fd, stride_row_x'
new = 'vx, vy, ids, fusion, dst, ncols_x, nrows_x, nchannels_y_fd, stride_row_x'
assert q_after.count(old) == 8  # c_ncols_dst=1..8 standard switch calls
q_after = q_after.replace(old, new)
for old, new in [
    ('uint32_t(row0 + threadIdx.x) < stride_col_dst', 'uint32_t(row0 + threadIdx.x) < nrows_x'),
    ('uint32_t(row0 + i) < stride_col_dst', 'uint32_t(row0 + i) < nrows_x'),
]:
    assert q_after.count(old) == 1
    q_after = q_after.replace(old, new, 1)
q_old_lines, q_new_lines = q_before.splitlines(True), q_after.splitlines(True)
context = 3
while True:
    q_edits = [{'before': ''.join(q_old_lines[g[0][1]:g[-1][2]]),
                'after': ''.join(q_new_lines[g[0][3]:g[-1][4]])}
               for g in difflib.SequenceMatcher(None, q_old_lines, q_new_lines, autojunk=False).get_grouped_opcodes(context)]
    replayed = q_before
    for edit in q_edits:
        if not edit['before'] or replayed.count(edit['before']) != 1:
            break
        replayed = replayed.replace(edit['before'], edit['after'], 1)
    else:
        if replayed == q_after:
            break
    context *= 2
    assert context < len(q_old_lines) * 2
q_out = STAGE / 'source' / q_relative
q_out.write_text(q_after, encoding='utf-8', newline='\n')
files.append({'path':q_relative, 'before_path':str(q_snapshot.relative_to(ROOT)),
              'before_sha256':sha(q_before), 'after_sha256':sha(q_after), 'edits':q_edits})
diff += ''.join(difflib.unified_diff(q_old_lines, q_new_lines, fromfile='a/'+q_relative, tofile='b/'+q_relative))
(STAGE / 'replacements.json').write_text(json.dumps({'files': files}, indent=2) + '\n', encoding='utf-8', newline='\n')
(STAGE / 'changes.diff').write_text(diff, encoding='utf-8', newline='\n')
freeze = {'state': 'Scratch-only v18 fusion-layout overlay; no product/build/GPU changes.',
          'files': [{k:v for k,v in f.items() if k != 'edits'} for f in files],
          'guarded_call_sites': len(calls)}
(STAGE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n', encoding='utf-8', newline='\n')
review = {'scope': 'All nine old float/quantized MMVF/MMVQ MatMul/MatMulID fusion calls: bias, scale+bias and GLU lanes. Kernel arithmetic, route tables and reader closure are unchanged.',
          'counterexamples': ['ordinary ADD bias ne=[N,1], nb0=8 (or0) is legal binary input; epilogue reads bias[row] instead', 'ADD_ID bias expert nb1 padded differently from dst.nb1; independent ADD_ID honors bias.nb1, epilogue indexes expert*dst.nb1'],
          'legal_boundaries': ['disjoint offset views remain admissible', 'singleton bias axes have no stride restriction', 'active bias axes may be padded if their actual mapping matches dst; no all-contiguous test', 'all output/read overlaps keep the original math chain because carrier dst is RESTRICT; ordinary bias inplace ADD remains available independently'],
          'other_real_assumptions': ['F32 bias/scale and output', 'MMVF float2 activation/pair alignment and selected column stride', 'final dst row axis is unit float; active higher strides use exact element units', 'gate weight type/shape/strides match up bank; scale reads original contiguous scalar/expert vector'],
          'mmvq_row_bound': 'Pass the existing nrows_x through standard kernel/switch_fusion calls; bias prefetch and store masks use true logical row count, not stride_col_dst. Preserve padded final outputs without a dense-only gate. Indexed and unfused standard calls share the fix; existing multi-token Moe kernel already uses true nrows_x.',
          'fallback': 'guard returns false only; original native graph and operations execute without provider changes or matcher exceptions.',
          'verification': 'Unique replacement replay and exact before/after SHA only; no compiler/GPU results.'}
(STAGE / 'review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({'before':sha(before), 'after':sha(after), 'edits':len(edits), 'calls':len(calls),
                  'freeze_sha256':hashlib.sha256((STAGE/'source-freeze.json').read_bytes()).hexdigest()}))
