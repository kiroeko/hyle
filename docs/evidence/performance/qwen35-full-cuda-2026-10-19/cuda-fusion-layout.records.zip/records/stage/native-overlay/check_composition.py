from pathlib import Path
import hashlib
import json

stage = Path(__file__).resolve().parent
root = stage.parents[3]
changes = json.loads((stage / 'replacements.json').read_text())['files']
delta = next(row for row in changes if row['path'] == 'src/ggml-cuda/mmvq.cu')
combined = root / '.scratch/architecture-refactor-2026-10-18/cuda-gdn-l2-epilogue/combined-manifest.json'
prior = next(row for row in json.loads(combined.read_text())['files'] if row['path'] == delta['path'])
upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
source = (upstream / delta['path']).read_bytes().replace(b'\r\n', b'\n').decode()
sha = lambda value: hashlib.sha256(value.encode()).hexdigest()
assert sha(source) == prior['before_sha256']
# CUDA manifest edits execute before the retained eight IQ1 edits.
for edit in [*delta['edits'], *prior['edits']]:
    assert source.count(edit['before']) == 1
    source = source.replace(edit['before'], edit['after'], 1)
assert sha(source) == delta['after_sha256']
result = {'CUDA_then_IQ1_replay': True, 'native_delta_edits': len(delta['edits']),
          'retained_IQ1_edits': len(prior['edits']), 'mmvq_after_sha256': sha(source),
          'replacements_sha256': hashlib.sha256((stage / 'replacements.json').read_bytes()).hexdigest(),
          'freeze_sha256': hashlib.sha256((stage / 'source-freeze.json').read_bytes()).hexdigest(),
          'sources': [{k: row[k] for k in ('path', 'before_sha256', 'after_sha256')} for row in changes]}
(stage / 'composition-check.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result))
