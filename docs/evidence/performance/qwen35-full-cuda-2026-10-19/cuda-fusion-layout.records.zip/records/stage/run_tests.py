"""Prove the layout regression on old native code, then run the related closure."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('layout_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
out = plan_path.parent / 'run-cuda'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
filters = ['GgmlCudaFusionLayout.*']
old_command = c.read(build.V18 / 'run-cuda/cuda.command.json')['command']
filters.append(next(x.split('=', 1)[1] for x in old_command if x.startswith('--gtest_filter=')))
env, _ = b.environment(plan['links']['cuda']['command'], [r['path'] for r in plan['cached_inputs']], out)


def summary(path):
    root = ET.parse(path).getroot()
    row = {key: int(root.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
    row['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in root.findall('testsuite'))
    return row


before_command = [plan['links']['cuda-before']['image'], '--gtest_color=no',
    '--gtest_filter=GgmlCudaFusionLayout.*', '--gtest_output=xml:' + str(out / 'before.xml')]
try:
    c.execute('before', before_command, env, out)
except Exception:
    # An ordinary GoogleTest assertion failure is expected. Device faults,
    # missing XML, skips or a process exception are not a valid red result.
    pass
before = summary(out / 'before.xml')
result = c.read(out / 'before.result.json')
if before['tests'] != 3 or before['failures'] != 3 or any(before[k] for k in ('disabled', 'errors', 'skipped')):
    raise ValueError('Expected three reachable assertion-failing layout/row-bound cases')
if not result.get('terminal') or result.get('exit') != 1:
    raise ValueError('Expected GoogleTest terminal1, not a crash')
c.execute('cuda', [plan['links']['cuda']['image'], '--gtest_color=no',
    '--gtest_filter=' + ':'.join(filters), '--gtest_output=xml:' + str(out / 'cuda.xml')], env, out)
after = summary(out / 'cuda.xml')
passed = after['tests'] == 35 and not any(after[k] for k in ('failures', 'disabled', 'errors', 'skipped'))
report = {'old_native': before, 'new_native': after, 'passed': passed,
    'same_new_tests_both_arms': True, 'baseline_test_only_relink': True,
    'old_terminal_is_assertion_failure': True, 'physical_fusion_proof': False}
c.save(out / 'summary.json', report)
if not passed:
    raise ValueError('Expected35 cases, zero fail/skip')
print('CUDA_RED_GREEN', report, flush=True)
