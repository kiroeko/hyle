"""One small physical trace of the two floating layout tests, not a benchmark."""
from pathlib import Path
import argparse
import collections
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


build = load('layout_profile_build', STAGE / 'build.py')
a = load('layout_profile_analysis', ARCH / 'cuda-stable-silu/profile-analysis-stable.py')
b, c = build.b, build.c
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('plan', type=Path)
parser.add_argument('--analyze', action='store_true')
args = parser.parse_args()
out = STAGE / 'profile-tests'
stem = out / 'layout-tests'
if not args.analyze:
    plan_path = args.plan.resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if not c.read(plan_path.parent / 'run-cuda/summary.json')['passed']:
        raise ValueError('Successful red/green regression required')
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = b.identity(plan['links']['cuda']['image'])
    if image != c.read(plan_path.parent / 'cuda-image.json'):
        raise ValueError('Current CUDA image differs')
    original = c.read(ARCH / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    index = original.index('--inputs') - 1
    tests = 'GgmlCudaFusionLayout.BiasViewsUseActualActiveStrides:GgmlCudaFusionLayout.GluAndSelectedBiasKeepTheirPhysicalLayouts'
    profile = [('--output=' + str(stem)) if x.startswith('--output=') else x for x in original[:index]]
    profile += [image['path'], '--gtest_color=no', '--gtest_filter=' + tests]
    commands = {'profile': profile,
        'export': [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite', str(stem) + '.nsys-rep'],
        'stats': [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum', '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite']}
    c.save(out / 'inputs.json', {'image': image, 'plan': b.identity(plan_path), 'runner': b.identity(Path(__file__)),
        'commands': commands, 'profiler_collections': 1, 'throughput_claim': False})
    env, _ = b.environment(plan['links']['cuda']['command'], [r['path'] for r in plan['cached_inputs']], out)
    for tag, command in commands.items():
        c.execute(tag, command, env, out)
a.PROFILE = out
data = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'), candidate=True)
symbols = collections.Counter(k['name'] for k in data['kernels'])
mmvf = []
for name, count in symbols.items():
    arguments = a.template_arguments(name, 'mul_mat_vec_f')
    if not arguments:
        continue
    fused = arguments[4] in ('true', '(bool)1') if len(arguments) > 4 else None
    mmvf.append({'symbol': name, 'count': count, 'has_fusion': fused})
fused = sum(r['count'] for r in mmvf if r['has_fusion'] is True)
checks = {'CSV_SQLite_per_symbol_equal': data['receipt']['csv_sqlite_per_symbol_counts_equal'],
    'no_graph_API_errors': not data['receipt']['graph_api_failures'],
    'eight_legal_fused_launches_retained': fused == 8}
report = {'checks': checks, 'receipt': data['receipt'], 'mmvf_symbols': mmvf,
    'all_kernel_counts': dict(symbols), 'passed': all(checks.values()),
    'throughput_claim': False, 'complete_model_trace': False,
    'limits': ['Only the two floating tests are traced. Q8 row bounds are covered by red/green numerical and sentinel checks.',
        'Unfused oracle kernels may use MMF/cuBLAS, so total34 or false26 MMVF counts are not requirements.',
        'The8 fused calls include legal partial fusion in the strided-GLU fallback, not just full GLU chains.']}
c.save(out / 'analysis.json', report)
print('PHYSICAL_LAYOUT_TESTS', checks, flush=True)
if not report['passed']:
    raise ValueError('Physical fusion retention has unresolved evidence')
