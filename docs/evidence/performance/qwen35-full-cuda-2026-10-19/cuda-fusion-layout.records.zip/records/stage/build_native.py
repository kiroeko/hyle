"""Compile the two frozen native sources while the host regression is prepared."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('layout_native_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
out = STAGE / 'native-build' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
freeze_path = STAGE / 'native-overlay/source-freeze.json'
freeze = c.read(freeze_path)
recipe_path = build.V18 / 'ggml-cuda-identity.json'
recipe = c.read(recipe_path)
frozen = [b.identity(Path(__file__)), b.identity(freeze_path), b.identity(recipe_path), recipe['object']]
rows = []
for tag, relative in (('ggml-cuda', 'src/ggml-cuda/ggml-cuda.cu'), ('mmvq', 'src/ggml-cuda/mmvq.cu')):
    source = STAGE / 'native-overlay/source' / relative
    expected = next(r['after_sha256'] for r in freeze['files'] if r['path'] == relative)
    if b.identity(source)['sha256'] != expected:
        raise ValueError('Reviewed native source differs')
    command = b.native_command(build.previous.previous.original.strip_ccbin(recipe['command']), source, tag, out)
    command[1:1] = ['-I' + str(STAGE / 'native-overlay/source/src'), '-I' + str(STAGE / 'native-overlay/source/src/ggml-cuda')]
    frozen.append(b.identity(source))
    rows.append({'tag': tag, 'command': command, 'source': b.identity(source), 'object': str(out / (tag + '.obj'))})
plan = {'compile': rows, 'frozen': frozen, 'cached_inputs': [], 'SDK_build': False,
    'configuration': 'Retained ggml CUDA target flags: sm89, C++17, original fast-math and dependencies',
    'native_TUs': 2, 'host_TUs': 0, 'GPU_run': False}
c.save(out / 'plan.json', plan)
build.check(plan)
print('NATIVE_PLAN', out / 'plan.json', flush=True)
link = c.read(build.V18 / 'qwen-link-plan.json')
env, _ = b.environment(link['command'], [r['path'] for r in link['inputs']], out)
for row in rows:
    c.execute(row['tag'] + '-compile', row['command'], env, out)
    build.check(plan)
    c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'], 'source': row['source'], 'object': b.identity(row['object'])})
c.save(out / 'summary.json', {'passed': True, 'native_TUs': 2, 'host_TUs': 0, 'GPU_run': False})
print('NATIVE_COMPLETE', out, flush=True)
