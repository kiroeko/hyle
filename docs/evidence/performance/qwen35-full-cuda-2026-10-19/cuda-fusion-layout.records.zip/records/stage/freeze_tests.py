import difflib
import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
REL = Path('tests/graph_route_cuda/stable_silu_test.cc')

def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

before = ROOT / REL
expected = 'bd106c3f5953633b4bb129341dbd8a352528ba45e87ed2a06647344af31364bb'
assert identity(before)['sha256'] == expected, 'Product source changed; do not overwrite a newer owner.'
original = before.read_text(encoding='utf-8')
fragment = (STAGE / 'layout-tests.inc').read_text(encoding='utf-8')
after = STAGE / 'test-overlay' / REL
after.parent.mkdir(parents=True, exist_ok=True)
after.write_text(original.rstrip() + '\n' + fragment, encoding='utf-8', newline='\n')
delta = ''.join(difflib.unified_diff(original.splitlines(keepends=True),
    after.read_text(encoding='utf-8').splitlines(keepends=True),
    fromfile='a/' + REL.as_posix(), tofile='b/' + REL.as_posix()))
(STAGE / 'tests-change.diff').write_text(delta, encoding='utf-8', newline='\n')
names = [
    'GgmlCudaFusionLayout.BiasViewsUseActualActiveStrides',
    'GgmlCudaFusionLayout.GluAndSelectedBiasKeepTheirPhysicalLayouts',
    'GgmlCudaFusionLayout.QuantizedOddRowsPreservePaddedDestinationsAndSelectedSlots',
]
plan = {
    'scope': 'Scratch-only overlay; one existing test TU; no CMake/public interface changes.',
    'tests': names,
    'float_domains': ['plain dense offset / inactive singleton padded strides',
        'plain nb0=8 strided bias', 'plain nb0=0 bias',
        'GLU dense bias', 'GLU strided gate bias and dense up bias',
        'ID dense offset bias', 'ID padded expert stride bias'],
    'quantized_domains': ['Q8_0 K32 N7 ordinary MM+bias with independent padded final output',
        'Q8_0 K32 N7 E3 single token slots2 IDs {2,1}/{1,2}, dense logical output in oversized sentinel backing'],
    'repetitions': 'Two seeds per domain; separate candidate/oracle native graphs, updated x/weights/biases/IDs.',
    'oracle': {
        'float': 'Original raw GPU graph with every MM and ADD marked OUTPUT; GLU remains the original GPU op. Exact dyadic host dots additionally check oracle MM/bias, never CPU exp.',
        'quantized': 'Same ggml_quantize_chunk Q8_0 backing bytes; ordinary MM computes all N*E rows into a dense output, MM OUTPUT prevents fusion. Plain uses original ADD; selected IDs choose from all expert rows on host. Never uses odd-N ID as oracle.',
        'comparison': 'Exact F32 bits; no new tolerance.',
    },
    'safety': [
        'Metadata bias/weight views expanded first; exact native MM+ADD(/MM+ADD+GLU) adjacency asserted.',
        'Bias roots contain finite sentinels, all actual footprints fit real allocations, roots checked unchanged.',
        'Quantized root has eight additional real encoded rows; oversized final output has independently bound sentinel observer. Old rounded row loads/stores remain inside actual allocations.',
        'Candidate padded output is disjoint from bias/x/weights, so restrict-overlap guard cannot hide row-bound regression.',
        'Q8 ID is pure MUL_MAT_ID with canonical dense output and extra real trailing storage. ADD_ID is not assigned padded output: its existing standalone kernel hardcodes a dense destination.',
    ],
    'trace_first_two_tests': {
        'dense_plain_true_per_seed': 1,
        'dense_glu_true_per_seed': 1,
        'dense_id_true_per_seed': 1,
        'strided_glu_dense_up_bias_true_per_seed': 1,
        'expected_total_has_fusion_true': 8,
        'other_candidates': 'strided/zero plain and padded ID must preserve correct original math; GLU negative may retain legal up MM+bias fusion.',
        'limits': 'Four-public-node/metadata adjacency is not physical proof. Total MMVF false count is not fixed: OUTPUT-protected ID oracle may use native MMF/cuBLAS fallback rather than MMVF. Third Q8 TEST is excluded from this tiny trace.',
    },
    'public_reachability': 'Public tensor lowering matrix() CONT-materializes non-dense bias, and exposes no ADD_ID; these negatives deliberately use existing private/raw ggml test seam.',
    'recipe': str(ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-explicit-rope/checks/20261019T100154/stable-test-identity.json'),
    'execution': {'compiled': False, 'gpu_run': False},
}
(STAGE / 'tests-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
freeze = {'before': identity(before), 'after': identity(after),
    'fragment': identity(STAGE / 'layout-tests.inc'),
    'diff': identity(STAGE / 'tests-change.diff'),
    'plan': identity(STAGE / 'tests-plan.json'),
    'product_edited': False, 'compiled': False, 'gpu_run': False}
(STAGE / 'tests-source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'before': freeze['before'], 'after': freeze['after'], 'tests': names}, indent=2))
