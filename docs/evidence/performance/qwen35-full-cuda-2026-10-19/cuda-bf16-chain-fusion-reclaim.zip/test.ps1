param([switch]$ReclaimBfloatChains)
$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$taskStage = Join-Path $taskRoot '.scratch/architecture-refactor-2026-10-18/cuda-bf16-chain-fusion'
$taskPlan = Get-Content -Raw -LiteralPath (Join-Path $taskStage 'cleanup-plan.json') | ConvertFrom-Json
function Assert-TaskFile($entry) {
    $target = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $target" }
    $item = Get-Item -LiteralPath $target -Force
    if ($item.PSIsContainer) { throw "Expected exact file: $target" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $target" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne [long]$entry.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Identity changed: $target" }
}
$taskTargets = @($taskPlan.delete_candidates)
$taskRetained = @($taskPlan.retain_objects) + @($taskPlan.retain_traces)
if (-not $taskPlan.archive_verified -or $taskTargets.Count -ne 12 -or $taskRetained.Count -ne 8 -or $taskPlan.retained_raw_vector_files -ne 128) { throw 'Unexpected cleanup plan' }
$taskArchive = Join-Path $taskRoot 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bf16-chain-fusion.zip'
if ($taskPlan.archive.path -ne $taskArchive) { throw 'Unexpected archive path' }
Assert-TaskFile $taskPlan.archive
$taskSeen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in $taskRetained) {
    if (-not $taskSeen.Add([string]$entry.path)) { throw 'Duplicate retained path' }
    Assert-TaskFile $entry
}
foreach ($entry in $taskTargets) {
    $target = [IO.Path]::GetFullPath([string]$entry.path)
    if ([IO.Path]::GetDirectoryName($target) -ne $taskStage -or @('baseline','candidate','fusion-tests') -notcontains [IO.Path]::GetFileNameWithoutExtension($target) -or @('.exe','.map','.lib','.exp') -notcontains [IO.Path]::GetExtension($target)) { throw "Unexpected deletion target: $target" }
    if (-not $taskSeen.Add($target)) { throw "Duplicate or retained target: $target" }
    Assert-TaskFile $entry
}
$taskBytes = ($taskTargets | Measure-Object bytes -Sum).Sum
if (-not $ReclaimBfloatChains) {
    $taskTargets | Select-Object path,bytes
    [pscustomobject]@{preview=$true; files=12; bytes=$taskBytes; retained_objects=4; retained_traces=4; retained_raw_vectors=128}
    return
}
$taskReceiptPath = Join-Path $taskStage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $taskReceiptPath) { throw 'Cleanup receipt already exists' }
$taskDeleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $taskTargets) {
    Assert-TaskFile $entry
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Target still exists: $($entry.path)" }
    $taskDeleted.Add($entry)
    [pscustomobject]@{deleted=$taskDeleted.ToArray(); files=$taskDeleted.Count; bytes=($taskDeleted | Measure-Object bytes -Sum).Sum; complete=($taskDeleted.Count -eq 12); archive=$taskPlan.archive; script_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $taskReceiptPath -Encoding utf8
}
foreach ($entry in $taskRetained) { Assert-TaskFile $entry }
[pscustomobject]@{deleted_files=12; reclaimed_bytes=$taskBytes; retained_objects=4; retained_traces=4; retained_raw_vectors=128}
