"""Replay the complete numerical and capture journey with the new host-only cache."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
    if len(sys.argv)!=3 or sys.argv[2]!='qwen':raise ValueError('Usage: plan.json qwen')
    b=load('hot_selection_build',STAGE/'build_current.py');b.check(b.c.read(Path(sys.argv[1])))
    runner=load('hot_selection_checks',b.ARCH/'cuda-normalization-review/run_checks.py');runner.b=b;runner.c=b.c;runner.STAGE=STAGE;runner.main()
if __name__=='__main__':main()
