from pathlib import Path
import difflib

stage=Path('.scratch/architecture-refactor-2026-10-18/cuda-hot-prepare-selection')
s=(stage/'batch.before.cc').read_text(encoding='utf-8')
def replace(old,new):
    global s
    assert s.count(old)==1, (s.count(old), old[:100])
    s=s.replace(old,new)
replace('''  PreparedEntry*metadata_source=nullptr;
};
bool same_allocator''','''  PreparedEntry*metadata_source=nullptr;
  const cd::ProviderExtensionRef*owner=nullptr;
  std::uint32_t step=UINT32_MAX;
};
using PreparedEntries=std::vector<PreparedEntry,mem::StdAllocator<PreparedEntry>>;
// Only these top-level selected identities survive the call. Current layouts,
// Queue references and the links into this workspace are always call-scoped.
struct EntryBindings final {
  PreparedEntries&entries;
  ~EntryBindings(){for(auto&entry:entries){entry.binding=nullptr;entry.queue=nullptr;
    entry.queue_owner={};entry.metadata_source=nullptr;}}
};
bool same_allocator''')
replace('''    std::span<const detail::NativeBatchRegionRef>native_regions,
    std::span<const NodeLayout>all_layouts)noexcept{''','''    std::span<const detail::NativeBatchRegionRef>native_regions,
    std::span<const NodeLayout>all_layouts,PreparedEntries*workspace=nullptr,
    bool selected=false)noexcept{''')
replace('''    std::vector<PreparedEntry,mem::StdAllocator<PreparedEntry>>entries{mem::StdAllocator<PreparedEntry>(options.allocator)};
    using Entries=decltype(entries);
    struct Visit{Entries*entries;Invocation*invocation;};Visit visit{&entries,&invocation};
    // This visit preserves the original busy/result/completion gate before any
    // native token, metadata binding or source permission is changed.
    HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
      if(view.prepared_vtable!=&region_table)return Status::Ok();
      auto&r=*static_cast<Region*>(view.prepared);
      if(!view.owner || view.owner->id()!=r.source.id() ||
          view.owner->provider_instance_id()!=r.source.provider_instance_id())
        return Status::InvalidArgument("native Graph capability owner differs");
      HYLE_RETURN_IF_ERROR(gd::RegionAccess::invalidate_commands(
          *static_cast<Visit*>(opaque)->invocation,view.step));
      try{static_cast<Visit*>(opaque)->entries->push_back({&r,static_cast<Slot*>(view.invocation),view.lane});}
      catch(...){return Status::ResourceExhausted("native Graph cold binding metadata");}
      return Status::Ok();
    },&visit));''','''    PreparedEntries local{mem::StdAllocator<PreparedEntry>(options.allocator)};
    auto&entries=workspace?*workspace:local;
    EntryBindings bindings{entries};
    // Every cached entry still passes the original owner and idle gate before
    // any token, metadata binding or source permission is changed.
    if(selected){
      for(const auto&entry:entries){const auto&r=*entry.region;
        if(!entry.owner || entry.owner->id()!=r.source.id() ||
            entry.owner->provider_instance_id()!=r.source.provider_instance_id())
          return Status::InvalidArgument("native Graph capability owner differs");
        HYLE_RETURN_IF_ERROR(gd::RegionAccess::invalidate_commands(invocation,entry.step));
      }
    }else{
      entries.clear();
      struct Visit{PreparedEntries*entries;Invocation*invocation;};Visit visit{&entries,&invocation};
      HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
        if(view.prepared_vtable!=&region_table)return Status::Ok();
        auto&r=*static_cast<Region*>(view.prepared);
        if(!view.owner || view.owner->id()!=r.source.id() ||
            view.owner->provider_instance_id()!=r.source.provider_instance_id())
          return Status::InvalidArgument("native Graph capability owner differs");
        HYLE_RETURN_IF_ERROR(gd::RegionAccess::invalidate_commands(
            *static_cast<Visit*>(opaque)->invocation,view.step));
        try{PreparedEntry entry{&r,static_cast<Slot*>(view.invocation),view.lane};
          entry.owner=view.owner;entry.step=view.step;
          static_cast<Visit*>(opaque)->entries->push_back(std::move(entry));}
        catch(...){return Status::ResourceExhausted("native Graph cold binding metadata");}
        return Status::Ok();
      },&visit));
    }''')
replace('''    frame_slots(mem::StdAllocator<Slot*>(a)),native_regions(mem::StdAllocator<detail::NativeBatchRegionRef>(a)),''','''    frame_slots(mem::StdAllocator<Slot*>(a)),selected_entries(mem::StdAllocator<PreparedEntry>(a)),
    shared_layouts(mem::StdAllocator<NodeLayout>(a)),native_regions(mem::StdAllocator<detail::NativeBatchRegionRef>(a)),''')
replace('''  std::vector<Slot*,mem::StdAllocator<Slot*>>frame_slots;
  detail::NativeBatchRegions native_regions;''','''  std::vector<Slot*,mem::StdAllocator<Slot*>>frame_slots;
  // Exact selections belong to this original InvocationState/Plan. No reset
  // replaces their top-level slots; destruction never dereferences them.
  PreparedEntries selected_entries;
  detail::NodeLayouts shared_layouts;
  bool selection_ready=false;
  detail::NativeBatchRegions native_regions;''')
replace('''Status upload_batch_metadata(graph::Invocation&invocation,BatchResources&p,
    std::span<const NodeLayout>layouts)noexcept{
  struct Call{Invocation*invocation;BatchResources*resources;}call{&invocation,&p};
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
    if(view.prepared_vtable!=&region_table)return Status::Ok();
    const auto&r=*static_cast<Region*>(view.prepared);if(!r.metadata.valid())return Status::Ok();
    const auto&s=*static_cast<Slot*>(view.invocation);const auto&call=*static_cast<Call*>(opaque);
    HYLE_ASSIGN_OR_RETURN(auto metadata,cd::BatchGraphAccess::metadata(s.native));
    return bind_layout_metadata(*call.invocation,*call.resources,r.metadata,s.layout,std::move(metadata));
  },&call));''','''Status upload_batch_metadata(graph::Invocation&invocation,BatchResources&p,
    std::span<const NodeLayout>layouts,bool selected=false)noexcept{
  if(selected){
    // frame_slots retain the original plan order (entries are node-sorted).
    for(const auto*slot:p.frame_slots){const auto&r=*slot->region;
      if(!r.metadata.valid())continue;
      const auto&s=*slot;
      HYLE_ASSIGN_OR_RETURN(auto metadata,cd::BatchGraphAccess::metadata(s.native));
      HYLE_RETURN_IF_ERROR(bind_layout_metadata(invocation,p,r.metadata,s.layout,std::move(metadata)));
    }
  }else{
    struct Call{Invocation*invocation;BatchResources*resources;}call{&invocation,&p};
    HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
      if(view.prepared_vtable!=&region_table)return Status::Ok();
      const auto&r=*static_cast<Region*>(view.prepared);if(!r.metadata.valid())return Status::Ok();
      const auto&s=*static_cast<Slot*>(view.invocation);const auto&call=*static_cast<Call*>(opaque);
      HYLE_ASSIGN_OR_RETURN(auto metadata,cd::BatchGraphAccess::metadata(s.native));
      return bind_layout_metadata(*call.invocation,*call.resources,r.metadata,s.layout,std::move(metadata));
    },&call));
  }''')
replace('''  HYLE_RETURN_IF_ERROR(invocation.reset());
  HYLE_RETURN_IF_ERROR(clear_native_frames(invocation));
  BatchResources*p=nullptr;
  const auto apply=[&]()noexcept->Status{''','''  HYLE_RETURN_IF_ERROR(invocation.reset());
  HYLE_ASSIGN_OR_RETURN(auto*p,resources(invocation));
  const bool cached=p && p->selection_ready && !options.max_source_completions;
  if(p && options.max_source_completions)p->selection_ready=false;
  // A successful cached selection was already cleared by the original payload
  // reset above. Fresh/partial discovery keeps the original complete sweep.
  if(!cached)HYLE_RETURN_IF_ERROR(clear_native_frames(invocation));
  const auto apply=[&]()noexcept->Status{''')
replace('''    detail::NativeBatchRegions native{mem::StdAllocator<detail::NativeBatchRegionRef>(options.allocator)};
    HYLE_RETURN_IF_ERROR(detail::collect_native_batch_regions(invocation,native));
    detail::NodeLayouts shared_layouts{mem::StdAllocator<NodeLayout>(options.allocator)};
    HYLE_RETURN_IF_ERROR(detail::split_native_batch_layouts(native,layouts,shared_layouts));
    HYLE_ASSIGN_OR_RETURN(p,resources(invocation));
    bool typed=!native.empty();
    HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
      if(view.prepared_vtable==&region_table)
        *static_cast<bool*>(opaque)=true;
      return Status::Ok();
    },&typed));
    if(typed || !rows.empty() || options.max_source_completions){HYLE_ASSIGN_OR_RETURN(p,ensure_resources(invocation,options));}
    if(p){p->pending_capacity=0;HYLE_RETURN_IF_ERROR(register_slots(invocation,*p));
      p->pending_regions.clear();
      if(options.max_source_completions)HYLE_RETURN_IF_ERROR(detail::collect_native_pending_regions(invocation,p->pending_regions));
      try{p->native_regions.assign(native.begin(),native.end());}
      catch(...){return Status::ResourceExhausted("native page original slot references");}''','''    detail::NativeBatchRegions local_native{mem::StdAllocator<detail::NativeBatchRegionRef>(options.allocator)};
    auto&native=cached?p->native_regions:local_native;
    if(!cached)HYLE_RETURN_IF_ERROR(detail::collect_native_batch_regions(invocation,native));
    detail::NodeLayouts local_layouts{mem::StdAllocator<NodeLayout>(options.allocator)};
    auto&shared_layouts=cached?p->shared_layouts:local_layouts;
    HYLE_RETURN_IF_ERROR(detail::split_native_batch_layouts(native,layouts,shared_layouts));
    if(!cached){
      bool typed=!native.empty();
      HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit(invocation,[](void*opaque,const gd::RegionAccessView&view)noexcept->Status{
        if(view.prepared_vtable==&region_table)
          *static_cast<bool*>(opaque)=true;
        return Status::Ok();
      },&typed));
      if(typed || !rows.empty() || options.max_source_completions){HYLE_ASSIGN_OR_RETURN(p,ensure_resources(invocation,options));}
    }
    if(p){p->pending_capacity=0;
      if(!cached)HYLE_RETURN_IF_ERROR(register_slots(invocation,*p));
      p->pending_regions.clear();
      if(options.max_source_completions)HYLE_RETURN_IF_ERROR(detail::collect_native_pending_regions(invocation,p->pending_regions));
      if(!cached){
        try{p->native_regions.assign(native.begin(),native.end());}
        catch(...){return Status::ResourceExhausted("native page original slot references");}
      }''')
replace('''    HYLE_RETURN_IF_ERROR(prepare_native(invocation,queues,shared_layouts,options,native_regions,layouts));''','''    const bool cache_selection=p && !options.max_source_completions;
    if(cache_selection){
      try{p->shared_layouts.reserve(shared_layouts.size());}
      catch(...){return Status::ResourceExhausted("native Graph cached layout partition");}
    }
    HYLE_RETURN_IF_ERROR(prepare_native(invocation,queues,shared_layouts,options,native_regions,layouts,
        cache_selection?&p->selected_entries:nullptr,cached));''')
replace('''      HYLE_RETURN_IF_ERROR(upload_batch_metadata(invocation,*p,layouts));
      HYLE_RETURN_IF_ERROR(upload_rows(invocation,*p,rows));
      HYLE_RETURN_IF_ERROR(prepare_pending(*p,options));
    }
    return Status::Ok();''','''      HYLE_RETURN_IF_ERROR(upload_batch_metadata(invocation,*p,layouts,cache_selection));
      HYLE_RETURN_IF_ERROR(upload_rows(invocation,*p,rows));
      HYLE_RETURN_IF_ERROR(prepare_pending(*p,options));
    }
    return Status::Ok();''')
replace('''  if(!status.ok()){
    if(p){p->pending_capacity=0;for(auto&row:p->rows){row.prepared=false;row.frame={};}}
    clear_native_frames(invocation).IgnoreError();invocation.reset().IgnoreError();
  }
  return status;''','''  if(!status.ok()){
    if(p){p->selection_ready=false;p->pending_capacity=0;
      for(auto&row:p->rows){row.prepared=false;row.frame={};}}
    clear_native_frames(invocation).IgnoreError();invocation.reset().IgnoreError();
  }else if(p && !options.max_source_completions){p->selection_ready=true;}
  // Cached layout capacity is reusable, but this call's owned versions are not
  // another persistent configuration. Dynamic validation ran above as before.
  if(p)p->shared_layouts.clear();
  return status;''')
out=stage/'overlay/src/graph_batch/batch.cc'
out.write_text(s,encoding='utf-8',newline='\n')
before=(stage/'batch.before.cc').read_text(encoding='utf-8')
(stage/'batch-change.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/src/graph_batch/batch.cc',tofile='b/src/graph_batch/batch.cc')),encoding='utf-8',newline='\n')
print(len(s.encode()),len((stage/'batch-change.diff').read_bytes()))
