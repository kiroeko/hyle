"""One nine-process rotation: previous/current Hyle and unchanged llama peer."""
from pathlib import Path
import importlib.util
import json
import re
import statistics
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frontier_peer_helpers',STAGE/'peer_compare.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);b=p.b;c=p.c

def main():
    plan_path=Path(sys.argv[1]).resolve();plan=c.read(plan_path);b.check(plan)
    proof=c.read(plan_path.parent/'run-qwen/summary.json');image=Path(plan['links']['qwen']['image'])
    if proof['equal_vectors']!=64 or not proof['same_generated_ids'] or not proof['same_decode_input_ids'] or b.b.identity(image)!=proof['image']:raise ValueError('Incomplete model proof')
    captures=[tuple(map(int,x)) for x in proof['capture_counts']]
    if captures != [(7,0)]*3+[(0,7)]*29:raise ValueError('Capture journey differs')
    expected=p.last_json(plan_path.parent/'run-qwen/qwen.stdout.log')
    fair=c.read(p.FAIR_PLAN);peer=c.read(p.PEER_PLAN);fixed=c.read(fair['fixed_inputs']['path'])
    prior_path=b.QWEN/'qwen-link-plan.json';prior=c.read(prior_path)
    fixtures=[fair[k] for k in ('prompt','fixed_inputs','tape')]+[c.read(p.MODEL_RECEIPT)]
    if len(peer['inputs'])!=9 or len(prior['inputs'])!=124:raise ValueError('Retained closures differ')
    for row in peer['inputs']+prior['inputs']+fixtures:
        if not b.b.same(row):raise ValueError('Input drift: '+row['path'])
    if list(map(int,Path(fair['prompt']['path']).read_text().split()))!=fixed['prompt_ids'] or list(map(int,Path(fair['tape']['path']).read_text().split()))!=fixed['decode_input_ids'] or len(fixed['prompt_ids'])!=128 or len(fixed['decode_input_ids'])!=31:raise ValueError('Fixed prompt/tape differ')
    out=STAGE/'comparison';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    cached=plan['cached_inputs']+peer['inputs']+prior['inputs']
    env,_=b.b.environment(plan['links']['qwen']['command'],[r['path'] for r in cached],out)
    for key in ('GGML_CUDA_DISABLE_GRAPHS','GGML_CUDA_DISABLE_FUSION','GGML_CUDA_GRAPH_OPT'):
        if env.get(key):raise ValueError('Unexpected reference environment '+key)
    images={'hyle':image,'baseline':out/'baseline.exe','peer':out/'peer.exe'}
    for name,recipe in (('baseline',prior),('peer',peer)):
        dest=images[name];command=[x for x in recipe['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command+=['/OUT:'+str(dest),'/MAP:'+str(dest.with_suffix('.map')),'/IMPLIB:'+str(dest.with_suffix('.lib'))]
        c.save(out/(name+'-link-plan.json'),{'command':command,'inputs':recipe['inputs']})
        p.execute(name+'-link',command,env,out)
    identities={k:b.b.identity(v) for k,v in images.items()}
    c.save(out/'inputs.json',{'images':identities,'current_plan':b.b.identity(plan_path),'baseline_plan':b.b.identity(prior_path),
        'peer_plan':b.b.identity(p.PEER_PLAN),'fixed':fixtures,'compiles':0,'profiler':False,'external_monitor':False,
        'timing':'Input upload through completed host token; diagnostics outside endpoint. Same reporting boundary in both Hyle images.'})
    hyle=next(r['argv'][:] for r in fair['requests'] if r['engine']=='hyle')
    order=['baseline','hyle','peer','peer','baseline','hyle','hyle','peer','baseline'];runs=[]
    for index,engine in enumerate(order,1):
        for name,path in images.items():
            if b.b.identity(path)!=identities[name]:raise ValueError('Image drift')
        tag=f'{index:02d}-{engine}';result=out/(tag+'-peer-result.json')
        command=[str(images[engine])]+(hyle[1:] if engine!='peer' else [fixtures[-1]['path'],fair['fixed_inputs']['path'],str(result)])
        terminal=p.execute(tag,command,env,out)
        if engine=='peer':values=p.checked_peer(result,fixed,expected['generated_ids'])
        else:
            observed=p.last_json(out/(tag+'.stdout.log'));text=(out/(tag+'.stderr.log')).read_text()
            actual=[tuple(map(int,x)) for x in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)',text)]
            phases=re.findall(r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+)',text,re.M)
            if observed['generated_ids']!=expected['generated_ids'] or observed['decode_input_ids']!=fixed['decode_input_ids'] or actual!=captures or phases!=[('prefill','128','128')]+[('decode'+str(i),'1',str(128+i)) for i in range(1,32)]:raise ValueError('Journey differs')
            values=p.metrics(out/(tag+'.stderr.log'))
        runs.append({'engine':engine,'tag':tag,'pid':terminal['pid'],'exit':terminal['exit'],'metrics':values});c.save(out/'runs.json',runs)
    groups={name:{key:{'samples':[r['metrics'][key] for r in runs if r['engine']==name],
        'median':statistics.median(r['metrics'][key] for r in runs if r['engine']==name)} for key in p.KEYS} for name in images}
    loading={}
    for name in ('baseline','hyle'):
        rows=[r['metrics'] for r in runs if r['engine']==name]
        loading[name]={key:statistics.median(r[key] for r in rows) for key in ('weights_load_seconds','shape_prepare_seconds','startup_to_ready_seconds','first_token_elapsed_seconds')}
    rows=[c.read(out/(r['tag']+'-peer-result.json'))['loading'] for r in runs if r['engine']=='peer']
    loading['peer']={key:statistics.median(r[key] for r in rows) for key in ('model_load_seconds','context_prepare_seconds','startup_to_ready_seconds','first_token_elapsed_seconds')}
    summary={'terminal_zero':9,'order':order,'groups':groups,'loading':loading,'same32_predictions_and_inputs':True,
        'hyle_over_baseline':{k:groups['hyle'][k]['median']/groups['baseline'][k]['median'] for k in p.KEYS},
        'hyle_over_peer':{k:groups['hyle'][k]['median']/groups['peer'][k]['median'] for k in p.KEYS},
        'statistical_significance':False,'independent_quality_acceptance':False,'memory_peaks_measured':False,
        'limits':['Three independent processes per image in one rotated window; no guarantee against drift.',
            'Hyle shape compilation is outside prefill step, peer graph maintenance is inside step; cold prefills compare startup-to-token.',
            'Same-source weights and32predictions; peer intermediate rounding and sampled-logit readback differ.',
            'Only Graph batch host selection/cache changed; all native/consumer/weight objects retained.']}
    c.save(out/'summary.json',summary);print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
