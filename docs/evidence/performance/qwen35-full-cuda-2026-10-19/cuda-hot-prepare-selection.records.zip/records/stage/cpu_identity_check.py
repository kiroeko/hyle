"""Close the retained CPU source gap: current resource/copy plus the copy guard test."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('hot_cpu_identity_base',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
PRIOR=STAGE/'checks/cpu-20261019T082439'
RECIPES=b.ARCH/'native-ragged-graph/validation/windows'
CASES=['TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates',
       'CpuCopyProgram.HostAddressCapabilityRejectsUnprovenMappingsAndDetectsWrapperAliases']

def main():
    prior=c.read(PRIOR/'plan.json');b.check(prior)
    old=c.read(PRIOR/'cpu-link-plan.json');out=STAGE/'checks'/('cpu-identity-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'));out.mkdir(exist_ok=False)
    frozen=prior['frozen']+[b.b.identity(Path(__file__))];compiles=[]
    for tag,relative,recipe_path in (
        ('mem-resource','src/mem/resource.cc',RECIPES/'compile-resource.command.json'),
        ('batch-transfer','src/compute/batch_transfer.cc',RECIPES/'compile-batch_transfer.command.json'),
        ('copy-test','tests/compute_backend_cpu/copy_program_test.cc',RECIPES/'compile-typed_capability_graph_test.command.json')):
        template=c.read(recipe_path)['argv'];source=b.ROOT/relative
        # Fresh host compilation keeps the retained dialect/ABI; strict warning
        # flags are also used for the small generic resource owner.
        for flag in ('/W4','/WX'):
            if flag not in template:template.append(flag)
        command=b.b.host_command(template,source,tag,out)
        compiles.append({'tag':tag,'command':command,'source':b.b.identity(source),'object':str(out/(tag+'.obj'))})
        frozen.extend(b.b.identity(x) for x in (recipe_path,source));frozen.extend(b.b.identity(x) for x in b.b.host_dependencies(template) if x.is_file())
    transfer=b.ARCH/'optional-file-stream/cuda/batch-transfer-final.obj';image=out/'cpu.exe'
    if sum(c.key(x['path'])==c.key(transfer) for x in old['inputs'])!=1:raise ValueError('Old copy owner not unique')
    command=[str(out/'batch-transfer.obj') if c.key(x)==c.key(transfer) else x for x in old['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[str(out/'mem-resource.obj'),str(out/'copy-test.obj')]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    if len(b.inputs(command))!=114:raise ValueError('Expected112existing inputs plus2newowners')
    plan={'compile':compiles,'links':{'cpu':{'command':command,'image':str(image),'inputs':b.inputs(command)}},
        'frozen':list({r['path']:r for r in frozen}.values()),'cached_inputs':list({r['path']:r for r in prior['cached_inputs']+old['inputs']}.values()),
        'native_TUs':0,'host_TUs':3,'SDK_build':False,'cases':CASES,'prior_failure':b.b.identity(PRIOR/'cpu-test.result.json')}
    target=out/'plan.json';c.save(target,plan);b.check(plan);print('PLAN',target,flush=True)
    (out/'tmp').mkdir();env,_=b.b.environment(command,[r['path'] for r in plan['cached_inputs']],out)
    for item in compiles:
        c.execute(item['tag']+'-compile',item['command'],env,out);b.check(plan)
        c.save(out/(item['tag']+'-identity.json'),dict(item,object=b.b.identity(item['object'])))
    c.execute('cpu-link',command,env,out);b.check(plan)
    c.save(out/'cpu-link-plan.json',{'command':command,'inputs':[b.b.identity(x) for x in b.inputs(command)]});c.save(out/'cpu-image.json',b.b.identity(image))
    xml=out/'tests.xml';c.execute('cpu-tests',[str(image),'--gtest_color=no','--gtest_filter='+':'.join(CASES),'--gtest_output=xml:'+str(xml)],env,out)
    tree=ET.parse(xml).getroot();actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in tree.findall('.//testcase')]
    if set(actual)!=set(CASES) or tree.findall('.//failure') or tree.findall('.//skipped'):raise ValueError('Exact CPU regression failed/skipped/missing')
    c.save(out/'summary.json',{'passed':True,'cases':actual,'failures':0,'skipped':0,'native_TUs':0,'SDK_build':False,'fresh_host_TUs':3})
    print('PASS two CPU cases',flush=True)

if __name__=='__main__':main()
