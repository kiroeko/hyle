"""One Graph batch host TU; retain the current124-input Qwen closure."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent;ARCH=STAGE.parent;ROOT=ARCH.parents[1]
spec=importlib.util.spec_from_file_location('hot_selection_base',ARCH/'cuda-projection-fusion/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
QWEN=ARCH/'cuda-rms-candidate-frontier/checks/platform-fs-relink-20261019T081124'
RECIPE=ARCH/'immutable-constant-alias/checks/20261019T063301-1d108b74/9-graph_batch-batch-identity.json'

def inputs(command):
    return [x for x in command if not x.startswith('/') and Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]

def check(plan):
    for row in plan['frozen']+plan['cached_inputs']:
        if not b.same(row):raise ValueError('Input drift: '+row['path'])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',action='store_true');args=p.parse_args()
    out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S');out.mkdir(parents=True,exist_ok=False)
    recipe=c.read(RECIPE);source=ROOT/'src/graph_batch/batch.cc';command=b.host_command(recipe['command'],source,'graph-batch',out)
    prior_path=QWEN/'qwen-link-plan.json';prior=c.read(prior_path)
    if len(prior['inputs'])!=124 or sum(c.key(r['path'])==c.key(recipe['object']['path']) for r in prior['inputs'])!=1:raise ValueError('Current baseline closure differs')
    image=out/'qwen.exe';link=[str(out/'graph-batch.obj') if c.key(x)==c.key(recipe['object']['path']) else x for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    frozen=[b.identity(x) for x in (Path(__file__),STAGE/'run_checks.py',source,RECIPE,prior_path,STAGE/'facts.json')]
    frozen.extend(b.identity(x) for x in b.host_dependencies(recipe['command']) if x.is_file())
    plan={'compile':[{'tag':'graph-batch','command':command,'source':b.identity(source),'object':str(out/'graph-batch.obj')}],
        'links':{'qwen':{'command':link,'image':str(image),'inputs':inputs(link)}},'cached_inputs':prior['inputs'],
        'frozen':list({x['path']:x for x in frozen}.values()),'native_TUs':0,'host_TUs':1,'SDK_build':False,'CMake_run':False}
    target=out/'plan.json';c.save(target,plan);check(plan);print('PLAN',target,flush=True)
    if not args.build:return
    (out/'tmp').mkdir();env,_=b.environment(link,[r['path'] for r in prior['inputs']],out)
    c.execute('graph-batch-compile',command,env,out);check(plan)
    c.save(out/'graph-batch-identity.json',{'command':command,'source':b.identity(source),'object':b.identity(out/'graph-batch.obj')})
    c.execute('qwen-link',link,env,out);check(plan)
    c.save(out/'qwen-link-plan.json',{'command':link,'inputs':[b.identity(x) for x in inputs(link)]});c.save(out/'qwen-image.json',b.identity(image))
    c.save(out/'summary.json',{'passed':True,'native_TUs':0,'host_TUs':1,'GPU_run':False});print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
