"""Offline only: summarize existing logs and verify retained link identities."""
from pathlib import Path
import hashlib
import json
import re
import statistics

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
COMPARISON = STAGE / "comparison"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def snapshot(path):
    label = path.relative_to(ROOT) if path.is_relative_to(ROOT) else path
    return {"path": str(label), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def receipt(path):
    data = read(path)
    return {**snapshot(path), "terminal": data.get("terminal"),
            "exit": data.get("exit"), "pid": data.get("pid")}


def main():
    current_path = STAGE / "checks/20261019T082235/plan.json"
    baseline_path = COMPARISON / "baseline-link-plan.json"
    current = read(current_path)
    baseline = read(baseline_path)
    current_inputs = set(current["links"]["qwen"]["inputs"])
    baseline_inputs = {entry["path"]: entry for entry in baseline["inputs"]}
    common = []
    mismatches = []
    for name in sorted(current_inputs & baseline_inputs.keys()):
        actual = snapshot(Path(name))
        expected = baseline_inputs[name]
        if any(actual[key] != expected[key] for key in ("bytes", "sha256")):
            mismatches.append(name)
        common.append({"path": name, "bytes": actual["bytes"],
                       "sha256": actual["sha256"]})
    identity_digest = hashlib.sha256(json.dumps(
        common, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    groups = {}
    captures = []
    for path in sorted(COMPARISON.glob("*-*.stderr.log")):
        if not any(label in path.name for label in ("-baseline.", "-hyle.")):
            continue
        rows = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("prepared "):
                rows.append({key: float(value) for key, value in re.findall(
                    r"(T|visible|cold_batch_seconds|capture_recorded|capture_reused)=([0-9.eE+-]+)", line)})
        assert len(rows) == 32, (path, len(rows))
        assert [int(row["T"]) for row in rows] == [128] + [1] * 31
        warm = [row["cold_batch_seconds"] * 1000 for row in rows[7:]]
        captures.append([(int(row["capture_recorded"]), int(row["capture_reused"])) for row in rows])
        group = "current" if "-hyle." in path.name else "baseline"
        groups.setdefault(group, []).append({
            "log": snapshot(path), "prepare_calls": len(rows),
            "prefill_calls": 1, "decode_calls": 31,
            "first_three_cold_batch_ms": [row["cold_batch_seconds"] * 1000 for row in rows[:3]],
            "warm_decode7_31_samples": len(warm),
            "warm_decode7_31_median_ms": statistics.median(warm),
            "warm_decode7_31_mean_ms": statistics.mean(warm),
            "warm_decode7_31_total_ms": sum(warm),
            "capture_recorded": sum(pair[0] for pair in captures[-1]),
            "capture_reused": sum(pair[1] for pair in captures[-1]),
            "capture_reuse_calls": sum(pair[1] != 0 for pair in captures[-1]),
        })
    aggregate = {}
    for group, runs in groups.items():
        aggregate[group] = {
            "processes": len(runs), "warm_samples": sum(run["warm_decode7_31_samples"] for run in runs),
            "median_of_process_medians_ms": statistics.median(run["warm_decode7_31_median_ms"] for run in runs),
            "median_of_process_means_ms": statistics.median(run["warm_decode7_31_mean_ms"] for run in runs),
            "first_three_process_medians_ms": [statistics.median(run["first_three_cold_batch_ms"][i] for run in runs) for i in range(3)],
        }
    fail = STAGE / "checks/cpu-20261019T082439"
    passed = STAGE / "checks/cpu-identity-20261019T082918"
    before = (STAGE / "typed-capability-test.before.cc").read_text(encoding="utf-8")
    now = (ROOT / "tests/graph_batch/typed_capability_graph_test.cc").read_text(encoding="utf-8")
    resource_class = lambda text: text.split("class HostResource final", 1)[1].split("TEST(", 1)[0]
    review = {
        "schema": 1, "analysis": "offline only; no build, GPU execution, profiler or monitor launched",
        "inputs": {"comparison": snapshot(COMPARISON / "inputs.json"),
                   "comparison_summary": snapshot(COMPARISON / "summary.json"),
                   "current_plan": snapshot(current_path), "baseline_link_plan": snapshot(baseline_path)},
        "link_identity": {
            "baseline_absolute_inputs": len(baseline_inputs), "current_absolute_inputs": len(current_inputs),
            "common_actual_sha256_checked": len(common), "common_actual_bytes": sum(x["bytes"] for x in common),
            "mismatches": mismatches, "common_identity_manifest_sha256": identity_digest,
            "manifest_encoding": "sorted by absolute path; JSON sorted keys, separators comma/colon; entries {path,bytes,sha256}; reconstruct using helper and baseline_link_plan",
            "removed": sorted(baseline_inputs.keys() - current_inputs),
            "added": sorted(current_inputs - baseline_inputs.keys()),
            "native_or_consumer_object_changed": False,
            "new_physical_trace": False,
        },
        "cold_batch_seconds_scope": "From after token/position uploads through layout version creation, gb::prepare, all dynamic bindings, prepare_replay and replay_report. Not isolated selection-cache or gb::prepare time.",
        "warm_window": "decode7 through decode31 inclusive, 25 samples per process",
        "per_process": groups, "aggregate": aggregate,
        "capture_pattern_equal_all_six_hyle_processes": all(pattern == captures[0] for pattern in captures),
        "cpu_failure_then_correction": {
            "initial_failure": receipt(fail / "cpu-test.result.json"),
            "initial_log": snapshot(fail / "cpu-test.stdout.log"),
            "initial_error": "CPU copy mutable carrier has no proven physical identity, at FIRST valid prepare",
            "cause": "CPU manual closure used old optional-file-stream/cuda/batch-transfer-final.obj and old system-resource facts; HostResource already forwards real system properties/map_host. No physical_binding_identity virtual method exists in current MemoryResource API.",
            "fixture_HostResource_class_unchanged": resource_class(before) == resource_class(now),
            "corrected_link": receipt(passed / "cpu-link.result.json"),
            "corrected_tests": receipt(passed / "cpu-tests.result.json"),
            "corrected_summary": read(passed / "summary.json"),
            "corrected_plan": snapshot(passed / "plan.json"),
            "corrected_absolute_inputs": len(read(passed / "cpu-link-plan.json")["inputs"]),
            "correction": "Fresh mem/resource.cc, compute/batch_transfer.cc and copy_program_test.cc; reused prior fresh batch.cc and typed_capability_graph_test.cc. Fixture identity flags and product copy checks unchanged.",
            "new_test_assertion": "Parent added an actual rejected submit after each warm prepare rejection, followed by numerical recovery.",
        },
        "source_audit": {
            "batch": snapshot(ROOT / "src/graph_batch/batch.cc"),
            "finding": "No correctness blocker found in read-only audit; not a proof for unrun backends.",
            "checked": ["cached identities belong to original InvocationState/Plan; move transfers same state",
                        "reset/result/busy/completion observation gates remain before mutation",
                        "owner/step checks and all current layout/Queue/options qualifications remain",
                        "call-local layout, QueueRef and metadata-source links cleared on every exit",
                        "selection_ready set only after complete success; failures clear and fully reset",
                        "max_source_completions transition bypasses cached selection and rediscovers",
                        "existing native extension inspect revalidates dynamic facts; replaceable slot controller/native plan not cached"],
        },
        "limits": [
            "Nine rotated processes comprise three baseline Hyle, three current Hyle and three peer; peer has no cold_batch_seconds field.",
            "Three processes per Hyle image, one window, no significance claim or control against drift/outliers.",
            "Per-process median cold times are slightly lower overall, but per-process means do not show a stable decrease; no reliable isolated host speedup established.",
            "Common native/consumer/weight input identity proves unchanged linked math code, not a newly observed physical kernel trace or kernel count.",
            "No new memory peak or storage saving measured.",
            "Old Windows Vulkan native-ragged closure inputs survive but Graph/RegionExtension ABI drift prevents claiming current coverage from batch+test-only relink; that GPU case was not run.",
            "Read-only source audit and two CPU cases are bounded evidence, not a full backend/concurrency matrix.",
        ],
    }
    assert not mismatches and len(common) == 123
    output = STAGE / "preparation-review.json"
    output.write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(snapshot(output)))


if __name__ == "__main__":
    main()
