"""Two CPU host TUs against111 retained inputs; one related numerical/lifetime case."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('hot_cpu_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c
CASE='TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates'
BASE=b.ARCH/'immutable-constant-alias/checks/20261019T063738-35becef7/cpu-link-plan.json'
RECIPE=b.ARCH/'immutable-constant-alias/checks/20261019T063301-1d108b74/102-graph_batch-batch-identity.json'
TEST_RECIPE=b.ARCH/'native-ragged-graph/validation/windows/compile-typed_capability_graph_test.command.json'

def main():
    out=STAGE/'checks'/('cpu-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'));out.mkdir(exist_ok=False)
    old=c.read(BASE);recipe=c.read(RECIPE);test_recipe=c.read(TEST_RECIPE)['argv']
    if len(old['inputs'])!=111:raise ValueError('Retained CPU closure differs')
    rows=[];frozen=[b.b.identity(x) for x in (BASE,RECIPE,TEST_RECIPE,Path(__file__),STAGE/'build_current.py')]
    for tag,source,command in (
        ('graph-batch-cpu',b.ROOT/'src/graph_batch/batch.cc',recipe['command']),
        ('typed-capability',b.ROOT/'tests/graph_batch/typed_capability_graph_test.cc',test_recipe)):
        rows.append({'tag':tag,'command':b.b.host_command(command,source,tag,out),'source':b.b.identity(source),'object':str(out/(tag+'.obj'))})
        frozen.append(b.b.identity(source));frozen.extend(b.b.identity(x) for x in b.b.host_dependencies(command) if x.is_file())
    image=out/'cpu.exe'
    link=[str(out/'graph-batch-cpu.obj') if c.key(x)==c.key(recipe['object']['path']) else x for x in old['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    link[1:1]=[str(out/'typed-capability.obj')]
    link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    if len(b.inputs(link))!=112:raise ValueError('Expected111retained inputs plus1testTU')
    plan={'compile':rows,'links':{'cpu':{'command':link,'image':str(image),'inputs':b.inputs(link)}},'cached_inputs':old['inputs'],
        'frozen':list({x['path']:x for x in frozen}.values()),'SDK_build':False,'native_TUs':0,'CPU_host_TUs':2,'case':CASE}
    target=out/'plan.json';c.save(target,plan);b.check(plan);print('PLAN',target,flush=True)
    (out/'tmp').mkdir();env,_=b.b.environment(link,[r['path'] for r in old['inputs']],out)
    for row in rows:
        c.execute(row['tag']+'-compile',row['command'],env,out);b.check(plan)
        c.save(out/(row['tag']+'-identity.json'),dict(row,object=b.b.identity(row['object'])))
    c.execute('cpu-link',link,env,out);b.check(plan)
    c.save(out/'cpu-link-plan.json',{'command':link,'inputs':[b.b.identity(x) for x in b.inputs(link)]});c.save(out/'cpu-image.json',b.b.identity(image))
    xml=out/'tests.xml';c.execute('cpu-test',[str(image),'--gtest_color=no','--gtest_filter='+CASE,'--gtest_output=xml:'+str(xml)],env,out)
    tree=ET.parse(xml).getroot();cases=[r.attrib['classname']+'.'+r.attrib['name'] for r in tree.findall('.//testcase')]
    if cases!=[CASE] or tree.findall('.//failure') or tree.findall('.//skipped'):raise ValueError('Missing/failing/skipped exact CPU case')
    c.save(out/'summary.json',{'passed':True,'cases':cases,'failures':0,'skipped':0,'CPU_host_TUs':2,'native_TUs':0,'SDK_build':False})
    print('PASS CPU case',flush=True)

if __name__=='__main__':main()
