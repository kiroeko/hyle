"""Keep the original Direct/Graph vocabulary helper in its own test image."""
from pathlib import Path
import importlib.util
import shutil
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('split_route_build', STAGE / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
assert 'route_fixture_split' not in plan
m.check(plan['frozen'])
out = path.parent
shutil.copyfile(path, out / 'plan-before-route-fixture-split.json')
failed = out / 'failed-combined-router-link'
failed.mkdir()
for p in out.glob('router-link.*'):
    shutil.copyfile(p, failed / p.name)
added = []
for index, route in enumerate(('compute_route_cuda', 'graph_route_cuda')):
    owner = next(row for row in plan['compile'] if row['source']['path'].endswith(route + '\\d5_qwen38_official_test.cc'))
    source = m.ROOT / 'tests' / route / 'd5_qwen_gguf_vocabulary_test.cc'
    tag = f'{43+index:02d}-' + route + '-vocabulary-helper'
    row = dict(tag=tag, source=b.identity(source), recipe=owner['recipe'],
        command=b.host_command(owner['command'], source, tag, out),
        object=str(out / (tag + '.obj')), old_object=None,
        arms=['router' if index == 0 else 'router-graph'], native=False,
        recipe_basis='Actual corresponding route fixture flags; current CMake already includes this vocabulary TU in the same test target.')
    added.append(row)
    plan['frozen'].append(b.identity(source))
    snapshot = out / 'compiled-source' / source.relative_to(m.ROOT)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    plan['frozen'].append(b.identity(snapshot))
plan['compile'].extend(added)
old_router = plan['links']['router']
fixtures = {route: [row['object'] for row in plan['compile']
    if (m.ROOT / 'tests' / route) == Path(row['source']['path']).parent]
    for route in ('compute_route_cuda', 'graph_route_cuda')}
all_fixture_objects = {c.key(p) for values in fixtures.values() for p in values}
core_command = [arg for arg in old_router['command'] if c.key(arg) not in all_fixture_objects
    and not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
fresh_native = next(row for row in plan['compile'] if row['native'])
for arm, route in [('router', 'compute_route_cuda'), ('router-graph', 'graph_route_cuda'),
                   ('router-old-math-control', 'compute_route_cuda')]:
    command = core_command.copy()
    command[1:1] = fixtures[route]
    if arm == 'router-old-math-control':
        command = [fresh_native['old_object']['path'] if c.key(arg) == c.key(fresh_native['object']) else arg for arg in command]
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    inputs = m.helper.helpers.link_inputs(command)
    assert len(set(map(c.key, inputs))) == len(inputs)
    plan['links'][arm] = dict(command=command, image=str(image), inputs=inputs)
plan['frozen'].append(b.identity(Path(__file__)))
plan['host_TUs'] = sum(not row['native'] for row in plan['compile'])
plan['route_fixture_split'] = dict(reason='Official fixtures call a shared check_head declaration whose route-specific definition is in the matching vocabulary TU. Preserve separate Direct/Graph consumers instead of linking one route helper into both.',
    additional_host_TUs=2, SDK_build=False,
    preserved_failure=str(failed), removed_combined_test_image=True)
c.save(path, plan)
print('SPLIT_ROUTE_FIXTURES', path, flush=True)
