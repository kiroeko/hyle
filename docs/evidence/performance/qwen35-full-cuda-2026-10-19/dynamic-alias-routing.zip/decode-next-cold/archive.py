"""Archive the completed dynamic-alias/routing batch; never builds or deletes."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
import zlib

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
ROUTING = ROOT / '.scratch/routing-normalization-2026-10-19'
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/dynamic-alias-routing.zip'
EXCLUDED_SUFFIXES = {'.exe', '.obj', '.o', '.map', '.lib', '.a', '.exp', '.pdb', '.dll',
                     '.pyc', '.tmp', '.bf16', '.f16', '.f32', '.bin', '.npy'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def check(row, path=None):
    actual = identity(path or row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256')), (row, actual)
    return actual


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def tests(folder, expected_failure=False):
    report = read(folder / 'summary.json')
    assert report['passed'] and report['control_expected_failure'] == expected_failure
    cases = ET.parse(folder / 'results.xml').findall('.//testcase')
    names = [case.attrib['classname'] + '.' + case.attrib['name'] for case in cases]
    failed = [name for name, case in zip(names, cases)
              if case.find('failure') is not None or case.find('error') is not None]
    skipped = [name for name, case in zip(names, cases) if case.find('skipped') is not None]
    assert cases and len(names) == len(set(names)) and not skipped
    assert set(names) == set(report['exact_filters']) and len(cases) == report['tests']
    if expected_failure:
        assert report['process_exit'] != 0 and set(failed) == set(names)
    elif report.get('process_count') == 2:
        assert folder.name == 'router-tests' and not failed
        assert 'pid' not in report and 'process_exit' not in report
        processes = report['processes']
        assert len(processes) == 2 and {row['arm'] for row in processes} == {'router', 'router-graph'}
        actual_names = []
        for row in processes:
            process = read(row['result'])
            assert process == row['process'] and process['exit'] == 0 and process['pid'] > 0
            child_cases = ET.parse(row['xml']).findall('.//testcase')
            child_names = [case.attrib['classname'] + '.' + case.attrib['name'] for case in child_cases]
            assert set(child_names) == set(row['exact_filters']) and row['passed']
            assert not any(case.find('failure') is not None or case.find('error') is not None or
                           case.find('skipped') is not None for case in child_cases)
            assert all(name.startswith('CudaMoeFragments.') == (row['arm'] == 'router') for name in child_names)
            actual_names.extend(child_names)
        assert len(actual_names) == len(names) == 9 and set(actual_names) == set(names)
        assert report['process_exits'] == [row['process']['exit'] for row in processes]
        assert report['images'] == [row['image'] for row in processes]
    else:
        assert report['process_exit'] == 0 and not failed
    return dict(tests=len(cases), expected_failure=expected_failure, names=names,
                processes=report.get('process_count', 1))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-plan', required=True, type=Path)
    args = parser.parse_args()
    plan_path = args.build_plan.resolve()
    assert plan_path.is_relative_to(STAGE / 'checks')
    plan = read(plan_path)
    assert read(plan_path.parent / 'summary.json')['passed']
    test_results = {name: tests(STAGE / (name + '-tests'), name == 'old-math-control')
                    for name in ('cpu', 'router', 'old-math-control')}
    model = read(STAGE / 'correctness/summary.json')
    observation = model['observation']
    assert model['passed'] and observation['equal_vectors'] == 64
    assert observation['all_outputs_finite'] and observation['same_greedy_ids_as_reference']
    assert observation['same_fixed_decode_inputs'] and len(observation['vectors']) == 64
    assert len(observation['generated_ids']) == 32 and len(observation['decode_input_ids']) == 31
    assert model['single_outer_range_32_phases'] and model['route'] == 'hybrid'
    for row in observation['vectors']:
        assert row['byte_equal'] and row['actual']['bytes'] == row['reference']['bytes']
        assert row['actual']['sha256'] == row['reference']['sha256']
    perf = read(STAGE / 'performance-rotation/summary.json')
    runs = read(STAGE / 'performance-rotation/runs.json')
    assert perf['terminal_zero'] == 9 and len(runs) == 9 and all(row['exit'] == 0 for row in runs)
    assert [row['arm'] for row in runs] == perf['order']
    assert all(len(perf['groups'][arm]['full31_seconds']['samples']) == 3
               for arm in ('baseline', 'current', 'llama'))
    assert all(row['decode_input_ids'] == observation['decode_input_ids'] for row in runs)
    assert not perf['profiler']

    # Fail before writing the archive if the frozen tested source was changed.
    snapshots = []
    for stage in (STAGE, ROUTING):
        frozen = read(stage / 'source-freeze.json')
        for row in frozen['files']:
            relative = Path(row.get('source', row.get('path')))
            assert not relative.is_absolute()
            check(row['after'], ROOT / relative)
            for version in ('before', 'after'):
                expected = row[version]
                named = Path(expected['path'])
                snapshot = named if named.is_absolute() else stage / ('source' if version == 'after' else 'before') / relative
                snapshots.append(check(expected, snapshot))

    # Keep actual current owner inputs, never entire external SDK/cache trees.
    # Original command/dependency records remain in checks even for failures.
    local_inputs = {}
    owner_records = []
    recipe_paths = []
    for row in plan['frozen']:
        path = Path(row['path']).resolve()
        if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('src', 'include', 'tests', 'third_party', 'cmake'):
            check(row)
            local_inputs[str(path).casefold()] = row
    for owner in plan['compile']:
        receipt_path = plan_path.parent / (owner['tag'] + '-identity.json')
        record = read(receipt_path)
        assert record['command'] == owner['command']
        check(owner['source'])
        relative = Path(owner['source']['path']).resolve().relative_to(ROOT)
        snapshot = plan_path.parent / 'compiled-source' / relative
        check(owner['source'], snapshot)
        for row in [record['source'], *record['dependencies']]:
            path = Path(row['path']).resolve()
            if path.is_relative_to(ROOT) and path.relative_to(ROOT).parts[0] in ('src', 'include', 'tests', 'third_party', 'cmake'):
                check(row)
                previous = local_inputs.get(str(path).casefold())
                assert previous is None or previous['sha256'] == row['sha256'], path
                local_inputs[str(path).casefold()] = row
        if owner.get('recipe'):
            recipe_paths.append(Path(owner['recipe']['path']))
            check(owner['recipe'])
        owner_records.append(dict(tag=owner['tag'], source=record['source'],
                                  object=record['object'], receipt=identity(receipt_path)))
    dependency_snapshots = []
    for row in local_inputs.values():
        path = Path(row['path']).resolve()
        relative = path.relative_to(ROOT)
        target = STAGE / 'archive-source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        dependency_snapshots.append(dict(**row, archive_path='decode-next-cold/archive-source/' + relative.as_posix()))
    save(STAGE / 'archive-source-index.json', dict(owners=owner_records,
        frozen_before_after=snapshots, local_source_and_header_snapshots=dependency_snapshots,
        scope='Current source/headers from final actual owner identities and frozen inputs. External SDK/library/object payloads are excluded; their exact recipe/dependency/link identities remain.'))

    # Small reusable helper/recipe files retain original repository-relative paths.
    pending = list(STAGE.glob('*.py'))
    seen = set()
    support = list(recipe_paths)
    while pending:
        path = pending.pop().resolve()
        if path in seen:
            continue
        seen.add(path)
        code = path.read_text(encoding='utf-8')
        for pattern, base in [(r"ARCH\s*/\s*['\"]([^'\"]+\.py)['\"]", ARCH),
                              (r"STAGE\s*/\s*['\"]([^'\"]+\.py)['\"]", path.parent)]:
            pending.extend(base / name for name in re.findall(pattern, code))
        if not path.is_relative_to(STAGE) and not path.is_relative_to(ROUTING):
            support.append(path)
    reference_receipt_path = ARCH / 'batch-graph-capture/archive-receipt.json'
    baseline_receipt = read(reference_receipt_path)
    # Prior ZIP identity is retained as a reference. The existing archive omitted
    # duplicate raw vectors too; it records their upstream provenance and hashes.
    support += [reference_receipt_path, ARCH / 'batch-graph-capture/correctness-final/summary.json',
        ARCH / 'batch-graph-capture/correctness-final/inputs.json']
    support_rows = []
    for path in dict.fromkeys(path.resolve() for path in support):
        assert path.is_relative_to(ROOT), path
        target = STAGE / 'support' / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        support_rows.append(dict(**identity(path), archive_path='decode-next-cold/support/' + path.relative_to(ROOT).as_posix()))
    save(STAGE / 'archive-support.json', support_rows)
    save(STAGE / 'archive-scope.json', dict(
        included=['Routing and alias before/source/freeze/diff/independent reviews; actual compiled-source snapshots and current local frozen/dependency headers.',
                  'All retained failed and successful build/test command logs, identities/deps, final CPU/router/negative-control XML, model logs/comparisons and nine fresh-process raw performance logs.'],
        excluded=['Executable/object/link/debug payloads, tmp/__pycache__, external SDK/cache trees and duplicate64raw hidden/logit vector payloads.',
                  'Other batches are referenced only by necessary small helpers/recipes and prior numeric proof; no unrelated draft or whole source tree is imported.'],
        baseline_vector_provenance=dict(archive=baseline_receipt,
            note='This earlier batch ZIP itself records upstream vector provenance rather than duplicating identical raw64payloads. Both current and reference exact per-vector identities are in correctness/summary.json.'),
        tests=test_results, equal_vectors=64, predictions=32, fixed_decode_inputs=31,
        model_processes=1, timed_processes=9, native_math_control='Original math control must fail precisely its required cases with no skips; it is not reported as an ordinary passing CUDA test.',
        source_and_SDK_builds_by_archiver=0, cleanup='None; root owns any later test.ps1 plan and execution.',
        limits='Fixed model tape and primitive routing regressions are not independent model-quality/full-artifact/cross-platform acceptance; rotated medians do not prove statistical significance.'))

    files = []
    for base, prefix in ((STAGE, 'decode-next-cold'), (ROUTING, 'routing-normalization-2026-10-19')):
        for path in base.rglob('*'):
            if not path.is_file() or path.suffix.lower() in EXCLUDED_SUFFIXES:
                continue
            relative = path.relative_to(base)
            if {'tmp', '__pycache__', 'SDK', 'sdk', 'cache'}.intersection(relative.parts):
                continue
            if path.name in ('archive-receipt.json',):
                continue
            files.append((path, prefix + '/' + relative.as_posix()))
    files.sort(key=lambda pair: pair[1])
    manifest = {name: identity(path) for path, name in files}
    assert len(manifest) == len(files)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, name in files:
            archive.write(path, name)
        archive.writestr('payload-sha256.json', manifest_bytes)
    expected = {name: row['sha256'] for name, row in manifest.items()}
    expected['payload-sha256.json'] = sha(manifest_bytes)
    # One decompressed read per entry verifies explicit CRC32 and SHA256.
    with zipfile.ZipFile(DEST) as archive:
        assert len(archive.infolist()) == len(expected)
        for info in archive.infolist():
            digest, crc, length = hashlib.sha256(), 0, 0
            with archive.open(info) as handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
                    crc = zlib.crc32(chunk, crc)
                    length += len(chunk)
            assert length == info.file_size and crc & 0xffffffff == info.CRC, info.filename
            assert digest.hexdigest() == expected[info.filename], info.filename
    receipt = dict(**identity(DEST), entries=len(expected), payloads=len(manifest),
        CRC_and_every_payload_SHA_verified=True, verification_passes=1,
        crc_verified=True, payload_sha256_verified=True, build_plan=identity(plan_path),
        fresh_host_TUs=plan['host_TUs'], fresh_native_TUs=plan['native_TUs'],
        tests=test_results, equal_vectors=64, unprofiled_processes=9,
        duplicate_raw_vectors_omitted=True, raw_vector_provenance=baseline_receipt,
        cleanup_executed=False)
    save(STAGE / 'archive-receipt.json', receipt)
    save(DEST.with_name('dynamic-alias-routing-archive.json'), receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
