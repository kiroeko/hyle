"""Refresh only the linked routing/header and Invocation-layout owners."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
ROUTING = ROOT / '.scratch/routing-normalization-2026-10-19'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

helper = load('alias_combined_helpers', ARCH / 'batch-graph-capture/build.py')
split_windows = load('alias_windows_split', ARCH / 'mlx-affine-widths/cuda/build.py').split_windows
b, c = helper.b, helper.c
check = helper.check

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--resume', type=Path)
    args = parser.parse_args()
    if args.resume:
        plan_path = args.resume.resolve()
        plan = c.read(plan_path)
        out = plan_path.parent
    else:
        out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        plan = prepare(out)
        plan_path = out / 'plan.json'
        c.save(plan_path, plan)
    print('PLAN', plan_path, flush=True)
    if not args.build:
        return
    check(plan['frozen'])
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Retained object/library changed: ' + row['path'])
    env, _ = b.environment(plan['links']['qwen']['command'],
                           [row['path'] for row in plan['cached_inputs']], out)
    identities = {c.key(row['path']): row for row in plan['cached_inputs']}
    for row in plan['compile']:
        receipt = out / (row['tag'] + '-identity.json')
        if receipt.exists():
            old = c.read(receipt)
            if (old['command'] == row['command'] and b.same(old['object']) and
                    all(b.same(dep) for dep in old['dependencies'])):
                identities[c.key(old['object']['path'])] = old['object']
                print('REUSE', row['tag'], flush=True)
                continue
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan['frozen'])
        if row['native']:
            dependencies = [b.identity(ROOT / 'src/compute_provider_cuda/sglang_router_kernel.cu')]
            # Preserve the actual nvcc dependency file, and hash all local
            # vendor inputs explicitly instead of treating host receipts as nvcc.
            dependencies += [b.identity(p) for p in sorted((ROOT / 'third_party/sglang_activation').rglob('*')) if p.is_file()]
            dependencies += [b.identity(ROOT / p) for p in (
                'src/compute_provider_cuda/sglang_router_kernel.h',
                'src/compute_provider_cuda/sglang_device_compat.cuh',
                'src/compute_backend_cuda/device_status_kernel.h')]
        else:
            dep = c.read(out / (row['tag'] + '-deps.json'))['Data']
            dependencies = [b.identity(p) for p in [dep['Source'], *dep['Includes']]]
        record = dict(command=row['command'], source=row['source'],
                      object=b.identity(row['object']), dependencies=dependencies)
        c.save(receipt, record)
        identities[c.key(record['object']['path'])] = record['object']
        print('COMPILED', row['tag'], flush=True)
    for arm, link in plan['links'].items():
        receipt = out / (arm + '-image.json')
        if receipt.exists() and b.same(c.read(receipt)):
            print('REUSE_IMAGE', arm, flush=True)
            continue
        c.execute(arm + '-link', link['command'], env, out)
        check(plan['frozen'])
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'],
            inputs=[identities[c.key(p)] for p in link['inputs']]))
        c.save(receipt, b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=plan['host_TUs'], native_TUs=1,
        SDK_build=False, GPU_run=False))
    c.save(STAGE / 'latest-check.json', dict(plan=str(plan_path)))
    print('BUILD_COMPLETE', plan_path, flush=True)

def prepare(out):
    base_path = ARCH / 'batch-graph-capture/checks/20261019T151524-fixture-include/plan.json'
    base = c.read(base_path)
    # The two inventories are derived from actual retained link closures and
    # sourceDependencies; callers may not silently substitute an old SDK owner.
    manifests = [ROUTING / 'current-header-owner-recipes.json', STAGE / 'build-owner-recipes.json']
    specs = []
    for path in manifests:
        manifest = c.read(path)
        if manifest.get('unknown') or manifest.get('missing_owner_recipes'):
            raise ValueError('Unknown owner recipes: ' + str(path))
        specs += manifest.get('owners', manifest.get('rows', []))
        specs += manifest.get('fixtures', manifest.get('additional_test_owners', []))
    frozen = [b.identity(p) for p in [Path(__file__), base_path, *manifests,
        ROOT / 'include/hyle/compute/model_ops.h', ROOT / 'src/graph/plan_state.h',
        ROUTING / 'source-freeze.json', STAGE / 'source-freeze.json',
        ROUTING / 'actual-native-command.json']]
    for path in [ROUTING / 'source-freeze.json', STAGE / 'source-freeze.json']:
        for row in c.read(path)['files']:
            relative = row.get('source', row.get('path'))
            product = b.identity(ROOT / relative)
            if product['sha256'] != row['after']['sha256']:
                raise ValueError('Frozen product differs: ' + relative)
            frozen.append(product)
    rows, seen = [], {}
    for spec in specs:
        source = Path(spec['source'])
        recipe_path = Path(spec['recipe'])
        recipe = c.read(recipe_path)
        old = spec.get('old_object')
        if old is None and any(c.key(row['source']['path']) == c.key(source) and
                               set(spec['arms']) <= set(row['arms']) for row in rows):
            continue # Existing CPU schema fixture was already a header owner.
        dedup = c.key(old['path']) if old else ('new:' + c.key(source))
        if dedup in seen:
            row = seen[dedup]
            if c.key(row['source']['path']) != c.key(source):
                raise ValueError('Owner source collision')
            row['arms'] = sorted(set(row['arms'] + spec['arms']))
            continue
        tag = f'{len(rows):02d}-' + source.parent.name + '-' + source.stem
        command = b.host_command(recipe['command'], source, tag, out)
        row = dict(tag=tag, source=b.identity(source), recipe=b.identity(recipe_path),
            command=command, object=str(out / (tag + '.obj')), old_object=old,
            arms=spec['arms'], native=False)
        rows.append(row)
        seen[dedup] = row
        frozen += [row['source'], row['recipe']]
        frozen += [b.identity(p) for p in b.host_dependencies(recipe['command'])]
    native_original = ROOT / '.scratch/b-cuda-d5/src/compute_provider_cuda/CMakeFiles/hyle_compute_provider_cuda.dir/sglang_router_kernel.cu.obj'
    command = split_windows(c.read(ROUTING / 'actual-native-command.json')['command_line'])
    stripped, skip = [], False
    for arg in command:
        if skip:
            skip = False
        elif arg in ('-MT', '-MF', '-c', '-o'):
            skip = True
        elif not arg.startswith('-Xcompiler=-Fd'):
            stripped.append(arg)
    tag = 'native-router'
    source = ROOT / 'src/compute_provider_cuda/sglang_router_kernel.cu'
    stripped += ['-MT', str(out / (tag + '.obj')), '-MF', str(out / (tag + '.d')),
        '-c', str(source), '-o', str(out / (tag + '.obj')),
        '-Xcompiler=-Fd' + str(out / (tag + '.pdb')) + ',-FS']
    if any('fast_math' in x or 'ftz=' in x for x in stripped):
        raise ValueError('Router arithmetic recipe unexpectedly relaxed')
    rows.append(dict(tag=tag, source=b.identity(source), command=stripped,
        object=str(out / (tag + '.obj')), old_object=b.identity(native_original),
        arms=['qwen', 'router'], native=True))
    frozen += [b.identity(p) for p in sorted((ROOT / 'third_party/sglang_activation').rglob('*')) if p.is_file()]
    frozen.append(b.identity(source))
    frozen += [b.identity(ROOT / p) for p in (
        'src/compute_provider_cuda/sglang_router_kernel.h',
        'src/compute_provider_cuda/sglang_device_compat.cuh',
        'src/compute_backend_cuda/device_status_kernel.h')]
    cached = {}
    for arm in ('cpu', 'qwen'):
        for p in base['links'][arm]['inputs']:
            cached[c.key(p)] = b.identity(p)
    gtests = [p for p in base['links']['cpu']['inputs'] if Path(p).name.lower() in ('gtest.lib', 'gtest_main.lib')]
    if len(gtests) != 2:
        raise ValueError('Two retained GTest libraries required')
    main = [row for row in rows if c.key(row['source']['path']) == c.key(ROOT / 'tools/qwen35_text/main.cc')]
    if len(main) != 1:
        raise ValueError('The actual Qwen header owner must be refreshed')
    links = {}
    for arm in ('cpu', 'qwen', 'router', 'router-old-math-control'):
        original = base['links']['cpu' if arm == 'cpu' else 'qwen']
        applicable = 'router' if arm.startswith('router') else arm
        selected = [row for row in rows if applicable in row['arms'] or
                    (applicable == 'router' and 'qwen' in row['arms'])]
        replacements = {c.key(row['old_object']['path']): row['object'] for row in selected if row['old_object']}
        if arm == 'router-old-math-control':
            replacements.pop(c.key(native_original))
        present = {c.key(p) for p in original['inputs']}
        if not set(replacements) <= present:
            raise ValueError('Replacement absent from actual ' + arm + ' closure: ' + str(set(replacements)-present))
        command = [replacements.get(c.key(x), x) for x in original['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if arm.startswith('router'):
            command = [x for x in command if c.key(x) != c.key(main[0]['object'])]
            command[1:1] = gtests
        command[1:1] = [row['object'] for row in selected if not row['old_object']]
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = helper.helpers.link_inputs(command)
        if len(set(map(c.key, inputs))) != len(inputs):
            raise ValueError('Duplicate link owner: ' + arm)
        links[arm] = dict(command=command, image=str(image), inputs=inputs)
    snapshots = []
    for row in rows:
        source = Path(row['source']['path'])
        target = out / 'compiled-source' / source.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        snapshots.append(b.identity(target))
    return dict(compile=rows, links=links, frozen=list({c.key(r['path']):r for r in frozen+snapshots}.values()),
        cached_inputs=list(cached.values()), base_plan=b.identity(base_path),
        host_TUs=sum(not row['native'] for row in rows), native_TUs=1, SDK_build=False, GPU_run=False)

if __name__ == '__main__':
    main()
