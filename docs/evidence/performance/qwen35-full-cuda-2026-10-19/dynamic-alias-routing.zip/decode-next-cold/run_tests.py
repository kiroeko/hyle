"""Bounded alias/storage/capture and selected model routing regression."""
from pathlib import Path
import copy
import importlib.util
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alias_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan['frozen'])
assert c.read(plan_path.parent / 'summary.json')['passed']
mode = sys.argv[2]
out = STAGE / (mode + '-tests')
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
required = c.read(build.ROUTING / 'refresh-plan.json')['required_filters']
if mode == 'cpu':
    record = c.read(STAGE / 'test-filters.json')
    filters = [row['name'] for row in record['tests']] if isinstance(record, dict) else record
    filters = list(dict.fromkeys(filters + [x for x in required if x.startswith(('SqrtSoftplusRouting.', 'SqrtSoftplusHashRouting.'))]))
    arm = 'cpu'
elif mode == 'router':
    filters = [x for x in required if not x.startswith(('SqrtSoftplusRouting.', 'SqrtSoftplusHashRouting.'))]
    arm = 'router'
elif mode == 'old-math-control':
    filters = ['CudaMoeFragments.D5OriginalRouterNativeBoundaries',
               'CudaMoeFragments.D5NativeHashRouterWarpTailsAndScoreBoundaries']
    arm = 'router-old-math-control'
else:
    raise ValueError('Unknown test arm')
if mode == 'router':
    # Direct and Graph vocab fixtures provide distinct route-local helpers;
    # never put both definitions in one image merely to run this filter set.
    partitions = [('direct', 'router', [x for x in filters if x.startswith('CudaMoeFragments.')]),
                  ('graph', 'router-graph', [x for x in filters if not x.startswith('CudaMoeFragments.')])]
    assert len(filters) == 9 and len(set(filters)) == 9
    records, xml_roots = [], []
    for label, selected_arm, selected_filters in partitions:
        assert selected_filters
        child = out / label
        child.mkdir()
        (child / 'tmp').mkdir()
        selected_link = plan['links'][selected_arm]
        selected_image = b.identity(selected_link['image'])
        assert selected_image == c.read(plan_path.parent / (selected_arm + '-image.json'))
        env, _ = b.environment(selected_link['command'], selected_link['inputs'], child)
        command = [selected_image['path'], '--gtest_filter=' + ':'.join(selected_filters),
                   '--gtest_output=xml:' + str(child / 'results.xml')]
        c.save(child / 'tests.command.json', dict(command=command))
        started = time.time_ns()
        with (child / 'tests.stdout.log').open('wb') as stdout, (child / 'tests.stderr.log').open('wb') as stderr:
            process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr)
            status = process.wait()
        result = dict(exit=status, pid=process.pid, start_unix_ns=started, end_unix_ns=time.time_ns())
        c.save(child / 'tests.result.json', result)
        xml = ET.parse(child / 'results.xml').getroot()
        cases = xml.findall('.//testcase')
        names = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
        failed = [name for name, row in zip(names, cases) if row.find('failure') is not None or row.find('error') is not None]
        skipped = [name for name, row in zip(names, cases) if row.find('skipped') is not None]
        passed = (status == 0 and len(names) == len(set(names)) and
                  set(names) == set(selected_filters) and not failed and not skipped)
        record = dict(arm=selected_arm, label=label, image=selected_image,
            process=result, exact_filters=selected_filters, tests=len(cases), names=names,
            failed=failed, skipped=skipped, passed=passed,
            command=str(child / 'tests.command.json'), result=str(child / 'tests.result.json'),
            xml=str(child / 'results.xml'))
        c.save(child / 'summary.json', record)
        records.append(record)
        xml_roots.append(xml)
    # Aggregate the two original testcase trees; there is no aggregate PID.
    combined = ET.Element('testsuites', name='AllTests')
    for key in ('tests', 'failures', 'disabled', 'errors'):
        combined.set(key, str(sum(int(root.attrib.get(key, '0')) for root in xml_roots)))
    combined.set('time', str(sum(float(root.attrib.get('time', '0')) for root in xml_roots)))
    for root in xml_roots:
        for suite in root.findall('testsuite'):
            combined.append(copy.deepcopy(suite))
    ET.ElementTree(combined).write(out / 'results.xml', encoding='utf-8', xml_declaration=True)
    cases = combined.findall('.//testcase')
    names = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
    failed = [name for name, row in zip(names, cases) if row.find('failure') is not None or row.find('error') is not None]
    skipped = [name for name, row in zip(names, cases) if row.find('skipped') is not None]
    passed = (all(record['passed'] for record in records) and len(cases) == 9 and
              len(names) == len(set(names)) and set(names) == set(filters) and not failed and not skipped)
    c.save(out / 'tests.result.json', dict(kind='sequential_process_aggregate',
        process_count=2, processes=[record['process'] for record in records]))
    c.save(out / 'summary.json', dict(passed=passed, control_expected_failure=False,
        process_count=2, process_exits=[record['process']['exit'] for record in records],
        processes=records, images=[record['image'] for record in records],
        tests=len(cases), failed=failed, skipped=skipped, names=names,
        exact_filters=filters, build_plan=b.identity(plan_path)))
    print('TESTS router', len(cases), 'processes=2 passed=', passed, flush=True)
    if not passed:
        raise ValueError('Direct/Graph routing outcomes differ from exact nine-case contract')
    raise SystemExit(0)
link = plan['links'][arm]
image = b.identity(link['image'])
assert image == c.read(plan_path.parent / (arm + '-image.json'))
env, _ = b.environment(link['command'], link['inputs'], out)
command = [image['path'], '--gtest_filter=' + ':'.join(filters),
           '--gtest_output=xml:' + str(out / 'results.xml')]
c.save(out / 'tests.command.json', dict(command=command))
started = time.time_ns()
with (out / 'tests.stdout.log').open('wb') as stdout, (out / 'tests.stderr.log').open('wb') as stderr:
    process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr)
    status = process.wait()
c.save(out / 'tests.result.json', dict(exit=status, pid=process.pid, start_unix_ns=started,
    end_unix_ns=time.time_ns()))
cases = ET.parse(out / 'results.xml').findall('.//testcase')
names = [row.attrib['classname'] + '.' + row.attrib['name'] for row in cases]
failed = [names[i] for i, row in enumerate(cases) if row.find('failure') is not None or row.find('error') is not None]
skipped = [names[i] for i, row in enumerate(cases) if row.find('skipped') is not None]
if mode == 'old-math-control':
    passed = status != 0 and set(names) == set(filters) and set(failed) == set(filters) and not skipped
else:
    passed = status == 0 and set(names) == set(filters) and not failed and not skipped
c.save(out / 'summary.json', dict(passed=passed, control_expected_failure=mode == 'old-math-control',
    process_exit=status, tests=len(cases), failed=failed, skipped=skipped, names=names,
    exact_filters=filters, image=image, build_plan=b.identity(plan_path)))
print('TESTS', mode, len(cases), 'passed=', passed, 'expected_failure=', mode == 'old-math-control', flush=True)
if not passed:
    raise ValueError('Test outcome differs from required exact-case contract')
