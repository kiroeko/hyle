"""Align two stale Ninja fixture recipes to the actual linked ggml headers."""
from pathlib import Path
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fixture_amend_build', STAGE / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, c = m.b, m.c
path = Path(sys.argv[1]).resolve()
plan = c.read(path)
assert 'fixture_recipe_correction' not in plan
m.check(plan['frozen'])
native = m.ARCH / 'cuda-fusion-precision/native-source'
base = m.ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
assert b.identity(native / 'src/ggml-common.h')['sha256'] == b.identity(base / 'src/ggml-common.h')['sha256']
shutil.copyfile(path, path.parent / 'plan-before-fixture-include.json')
failed = path.parent / 'failed-first-fixture'
failed.mkdir(exist_ok=True)
for p in path.parent.glob('30-compute_route_cuda-d5_qwen38_official_test-compile.*'):
    shutil.copyfile(p, failed / p.name)
for row in plan['compile']:
    if Path(row['source']['path']).name != 'd5_qwen38_official_test.cc':
        continue
    old_command = row['command']
    row['command'] = [x for x in old_command if not ('b-cuda-d5' in x and 'compute_ggml_runtime' in x)]
    row['command'][1:1] = ['/external:I' + str(native / 'include'),
        '/external:I' + str(native / 'src'), '/external:I' + str(base / 'src')]
    row['command'][1:1] = ['/DHYLE_STATIC', '/DHYLE_COMPUTE_GGML_CUDA=1']
    row['stale_ninja_recipe_command'] = old_command
paths = [Path(__file__), base / 'src/ggml-quants.h', base / 'src/ggml-common.h',
    native / 'include/ggml.h', native / 'src/ggml-common.h',
    m.ROOT / 'tests/compute_route_cuda/CMakeLists.txt',
    m.ROOT / 'tests/graph_route_cuda/CMakeLists.txt']
plan['frozen'] = list({c.key(r['path']):r for r in plan['frozen'] + [b.identity(p) for p in paths]}.values())
plan['fixture_recipe_correction'] = dict(reason='Retained Ninja target predates current private-ggml include declaration; compiler failed before code generation. Current CMake already declares private src includes.',
    actual_linked_public_header=b.identity(native / 'include/ggml.h'),
    actual_native_base_private_header=b.identity(base / 'src/ggml-quants.h'),
    native_common_header_matches_base=True, failed_attempt=str(failed),
    unchanged_successful_host_TUs=30, product_changes=0, SDK_build=False)
c.save(path, plan)
print('AMENDED_FIXTURE_INCLUDES', path, flush=True)
