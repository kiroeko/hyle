"""Read current link inputs/retained compile receipts; emit metadata only."""
from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
PLAN = ROOT / '.scratch/architecture-refactor-2026-10-18/batch-graph-capture/checks/20261019T151524-fixture-include/plan.json'
HEADER = ROOT / 'include/hyle/compute/model_ops.h'

def norm(path):
    return str(path).replace('\\', '/').lower()

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def object_identity(receipt, obj):
    item = receipt.get('object')
    assert isinstance(item, dict) and norm(item['path']) == norm(obj), (obj, item)
    assert obj.is_file() and obj.stat().st_size == item['bytes'], obj
    return item

def dependency_evidence(receipt, recipe):
    for key in ['dependencies', 'current_hyle_dependency_identities']:
        data = receipt.get(key)
        if isinstance(data, list) and data:
            return data, dict(path=str(recipe), member=key)
    command = receipt.get('command', [])
    for index, arg in enumerate(command[:-1]):
        if arg.lower() == '/sourcedependencies':
            depfile = Path(command[index + 1])
            if depfile.is_file():
                raw = read(depfile)
                includes = raw.get('Data', {}).get('Includes')
                if isinstance(includes, list):
                    return includes, identity(depfile)
    return None, None

plan = read(PLAN)
rows = {}
nonowners = []
gaps = []
for arm in ['cpu', 'qwen']:
    for value in plan['links'][arm]['inputs']:
        obj = Path(value['path'] if isinstance(value, dict) else value)
        if obj.suffix.lower() != '.obj':
            continue
        recipe = obj.with_name(obj.stem + '-identity.json')
        if not recipe.is_file():
            gaps.append(dict(arm=arm, object=str(obj),
                             reason='no adjacent compile/dependency identity; not silently classified as non-owner'))
            continue
        receipt = read(recipe)
        dependencies, evidence = dependency_evidence(receipt, recipe)
        if dependencies is None:
            gaps.append(dict(arm=arm, object=str(obj), recipe=str(recipe),
                             reason='compile identity has no dependency list'))
            continue
        matches = [d for d in dependencies if norm(d.get('path', '') if isinstance(d, dict) else d) == norm(HEADER)]
        if not matches:
            nonowners.append(dict(arm=arm, object=str(obj), recipe=str(recipe),
                                  dependency_evidence=evidence,
                                  reason='retained actual dependency list excludes model_ops.h'))
            continue
        key = norm(obj)
        if key in rows:
            rows[key]['arms'].append(arm)
            continue
        source = receipt['source']
        source = source['path'] if isinstance(source, dict) else source
        assert Path(source).is_file(), source
        assert isinstance(receipt.get('command'), list) and receipt['command'], recipe
        rows[key] = dict(source=source, recipe=str(recipe),
                         recipe_identity=identity(recipe),
                         old_object=object_identity(receipt, obj), arms=[arm],
                         header_dependency=matches[0],
                         dependency_evidence=evidence,
                         current_source=identity(Path(source)))

def windows_argv(command):
    count = ctypes.c_int()
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    argv = shell.CommandLineToArgvW(command, ctypes.byref(count))
    if not argv:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return [argv[i] for i in range(count.value)]
    finally:
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree(argv)

fixture_dir = STAGE / 'fixture-recipes'
fixture_dir.mkdir(exist_ok=True)
ninja_root = ROOT / '.scratch/b-cuda-d5'
additional = []
for tag, route in [('direct-official', 'compute_route_cuda'), ('graph-official', 'graph_route_cuda')]:
    source = ROOT / f'tests/{route}/d5_qwen38_official_test.cc'
    target = f'tests/{route}/CMakeFiles/hyle_{route}_test.dir/d5_qwen38_official_test.cc.obj'
    query = [shutil.which('ninja'), '-C', str(ninja_root), '-t', 'commands', '-s', target]
    result = subprocess.run(query, capture_output=True, text=True, check=True)
    lines = [line for line in result.stdout.splitlines() if line.strip()]
    assert len(lines) == 1, lines
    command = windows_argv(lines[0])
    assert norm(source) in [norm(v) for v in command]
    record = dict(source=identity(source), command=command, working_directory=str(ninja_root),
                  origin='actual retained Ninja single-object command; metadata query only',
                  extraction=dict(command=query, exit=result.returncode, stdout=result.stdout, stderr=result.stderr),
                  build_ninja=identity(ninja_root / 'build.ninja'),
                  note='Old target was configured as shared build; generic standalone builder must add HYLE_STATIC and fresh /sourceDependencies, replace output, preserve route-specific defines. SDK/source include roots must use current coherent build roots.')
    output = fixture_dir / f'{tag}-identity.json'
    output.write_text(json.dumps(record, indent=2) + '\n')
    additional.append(dict(source=str(source), recipe=str(output), recipe_identity=identity(output),
                           old_object=None, arms=['router']))

sglang = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-coarse-capture-tests/sglang-checked-test-identity.json'
sglang_receipt = read(sglang)
sglang_source = sglang_receipt['source']['path']
assert norm(sglang_source).endswith('/tests/graph_route_cuda/sglang_primitives_test.cc')
additional.append(dict(source=sglang_source, recipe=str(sglang), recipe_identity=identity(sglang),
                       old_object=None, arms=['router'], current_source=identity(Path(sglang_source))))
ops = next(row for row in rows.values() if norm(row['source']).endswith('/tests/compute_ops/operation_test.cc'))
additional.append(dict(source=ops['source'], recipe=ops['recipe'], recipe_identity=ops['recipe_identity'],
                       old_object=None, arms=['cpu'], already_in_rows=True))

refresh = read(STAGE / 'refresh-plan.json')
out = dict(status='metadata prepared; no compiler/linker/GPU execution', plan=identity(PLAN),
           links={arm:dict(input_count=len(plan['links'][arm]['inputs']), image=plan['links'][arm]['image']) for arm in ['cpu', 'qwen']},
           header=identity(HEADER), rows=list(rows.values()), additional_test_owners=additional,
           required_filters=refresh['required_filters'], optional_neighbours=refresh['optional_neighbours'],
           filters_by_arm={
               'cpu': [x for x in refresh['required_filters'] if x.startswith(('SqrtSoftplusRouting.', 'SqrtSoftplusHashRouting.'))],
               'router': [x for x in refresh['required_filters'] if not x.startswith(('SqrtSoftplusRouting.', 'SqrtSoftplusHashRouting.'))]},
           excluded_actual_dependency_nonowners=nonowners,
           dependency_receipt_gaps=gaps,
           missing_owner_recipes=[],
           notes=['Rows come from actual input object paths and adjacent successful compile identities, not source-name matching with an old inventory.',
                  'CPU and CUDA recipes for the same source remain separate unless the same exact object is shared by both links.',
                  'Object SHA is the retained successful compile identity; current existence and size checked without rereading every object/library.',
                  'Dependency-receipt gaps are explicit provenance limits; original native/generic cached objects are not presumed affected or unaffected from their names.',
                  'Native routing command is supplied separately by root in actual-native-command.json.',
                  'Additional CPU ops-test is already an existing owner row; do not add/link it twice.'])
(STAGE / 'current-header-owner-recipes.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(dict(rows=len(rows), arms={arm:sum(arm in x['arms'] for x in rows.values()) for arm in ['cpu', 'qwen']},
                      additional=len(additional), dependency_receipt_gaps=len(gaps),
                      manifest=identity(STAGE / 'current-header-owner-recipes.json')), indent=2))
