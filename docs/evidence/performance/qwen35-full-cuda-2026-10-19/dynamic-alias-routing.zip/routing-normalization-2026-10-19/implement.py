from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
FILES = [
    'include/hyle/compute/model_ops.h',
    'include/hyle/compute/providers/cuda.h',
    'third_party/sglang_activation/hash_topk.cuh',
    'third_party/sglang_activation/moe_gate.cuh',
    'third_party/sglang_activation/NOTICE',
    'third_party/sglang_activation/README.md',
    'third_party/sglang_activation/provenance.json',
    'cmake/HyleDependencyLock.json',
    'tests/compute_models/d5_moe_execution_fragments.h',
    'tests/compute_models/d5_qwen35_gguf_fragment_support.h',
    'tests/compute_route_cuda/d5_qwen38_official_test.cc',
    'tests/graph_route_cuda/d5_qwen38_official_test.cc',
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def normalized(data):
    return data.replace(b'\r\n', b'\n').replace(b'\r', b'\n')

def identity(path):
    data = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(data), sha256=sha(data))

def save(name, value):
    (STAGE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def tree_identity():
    base = ROOT / 'third_party/sglang_activation'
    rows = [(p.relative_to(base).as_posix(), sha(normalized(p.read_bytes())))
            for p in base.rglob('*') if p.is_file()]
    rows.sort()
    manifest = ''.join(f'{path}|{digest}\n' for path, digest in rows)
    return sha(manifest.encode()), rows

if (STAGE / 'before.json').exists():
    raise SystemExit('before.json exists: do not overwrite the original snapshot')
before = []
for rel in FILES:
    source = ROOT / rel
    target = STAGE / 'before' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    before.append(identity(source))
save('before.json', before)

def edit(rel, old, new, count=1):
    path = ROOT / rel
    raw = path.read_bytes()
    newline = '\r\n' if b'\r\n' in raw else '\n'
    text = raw.decode('utf-8').replace('\r\n', '\n')
    if text.count(old) != count:
        raise RuntimeError(f'{rel}: expected {count} exact matches; got {text.count(old)}')
    path.write_bytes(text.replace(old, new).replace('\n', newline).encode('utf-8'))

old_tree, _ = tree_identity()
lock = json.loads((ROOT / 'cmake/HyleDependencyLock.json').read_text(encoding='utf-8'))
entry = next(d for d in lock['dependencies'] if d['name'] == 'sglang_activation')
assert old_tree == entry['vendored']['tree_sha256'], (old_tree, entry['vendored'])

edit(FILES[0],
     '// Ties may select any valid top-k member; this is not stable generic TopK.\n',
     '// Selected sqrt(softplus) scores are divided by their sum, then scaled;\n'
     '// no epsilon or zero-sum fallback is applied (zero scores yield NaN).\n'
     '// Ties may select any valid top-k member; this is not stable generic TopK.\n')
edit(FILES[0], '0x445334524f555408ULL', '0x445334524f555409ULL')
edit(FILES[0],
     '// Weights use sqrt(softplus(logit))/(sum+1e-20); model scaling is separate.',
     '// Weights divide selected sqrt(softplus) scores by their sum, without an\n'
     '// epsilon or zero-sum fallback (zero scores yield NaN); scaling is separate.')
edit(FILES[0], '0x4453344841534801ULL', '0x4453344841534802ULL')
edit(FILES[1],
     '// Complete model_ops::SqrtSoftplusRouting uses the pinned original MoE gate\n'
     '// program: F32 [T,256/384] logits and [E] bias, top6 F32 weights/I32 IDs.\n'
     '// It preserves unbiased positive-sum normalization and output scaling, with',
     '// Complete model_ops::SqrtSoftplusRouting adapts the pinned MoE gate\n'
     '// program: F32 [T,256/384] logits and [E] bias, top6 F32 weights/I32 IDs.\n'
     '// Unbiased scores divide by their sum without a zero fallback, then scale;')
edit(FILES[1],
     '// native tie selection rather than generic stable TopK. No workspace/aliases;',
     '// native tie selection differs from generic stable TopK. No workspace/aliases;')
edit(FILES[2],
     '// Hash routing ignores scores, so an all-underflowed row would renorm 0/0 to NaN.\n'
     'constexpr float kRenormalizeSumEpsilon = 1e-20f;\n',
     '// Divide by the selected-score sum directly, including IEEE 0/0 for zero rows.\n')
edit(FILES[2], 'routed_weight / (routed_sum + kRenormalizeSumEpsilon)',
     'routed_weight / routed_sum')
edit(FILES[3],
     'const auto norm = renormalize && routed_sum > 0.0f ? routed_sum : 1.0f;',
     'const auto norm = renormalize ? routed_sum : 1.0f;', 2)
edit(FILES[4],
     'D5-F37 additionally retains the unchanged group128 quantizer',
     'The two sqrt-softplus routing adapters normalize selected unbiased scores\n'
     'by their actual sum, with no epsilon or zero-sum fallback. This explicitly\n'
     'adapts SGLang normalization to the official DeepSeek V4 Gate formula; an\n'
     'all-zero score row produces NaN weights. Selection, reduction, table order,\n'
     'bounds checks and launch policy are retained.\n\n'
     'D5-F37 additionally retains the unchanged group128 quantizer')
edit(FILES[5],
     '`hash_topk.cuh` retains the complete DeepSeek token-table routing program,\n'
     'stable sqrt-softplus, warp SUM and sum+1e-20 normalization. HYLE adds token\n'
     'and selected-expert bounds guards using its existing asynchronous device-status\n'
     'channel before either indirect payload read. Valid arithmetic and table order\n'
     'are unchanged. TVM host binding, PDL and fused shared experts are excluded;\n'
     'model output scaling stays in the consumer. D5-F32 qualification remains open.',
     '`hash_topk.cuh` retains the complete DeepSeek token-table routing program,\n'
     'stable sqrt-softplus and warp SUM. HYLE adapts normalization to the official\n'
     'Gate formula: selected scores divide by their actual sum without epsilon or\n'
     'zero-sum fallback; all-zero score rows produce NaN weights. Token and\n'
     'selected-expert bounds guards use the existing asynchronous device-status\n'
     'channel before either indirect payload read. Table order and duplicate IDs\n'
     'are retained. TVM host binding, PDL and fused shared experts are excluded;\n'
     'model output scaling stays in the consumer.')
edit(FILES[5],
     'SUM reduction and launch policy are retained. The original score load that',
     'SUM reduction and launch policy are retained; normalization divides directly\n'
     'by the selected-score sum without a zero-sum fallback. The score load that')
edit(FILES[6],
     'Normal input arithmetic, selection and reduction remain unchanged.',
     'Score arithmetic, selection and reduction remain unchanged; normalization is adapted explicitly below.')
edit(FILES[6],
     'no fused shared experts, positive-sum normalization and output scaling.',
     'no fused shared experts, direct selected-score-sum normalization and output scaling. Remove the upstream zero-sum fallback: an all-zero selected score row yields NaN weights, matching the official Gate divide-by-sum formula.')
edit(FILES[6],
     'warp SUM, sum+1e-20 normalization, table order and 128-thread launch.',
     'warp SUM, table order and 128-thread launch. Remove the upstream sum+1e-20 normalization: divide by the actual selected-score sum, including NaN for all-zero rows, matching the official Gate formula.')
edit(FILES[6],
     'Valid-input arithmetic is unchanged; failed outputs are not consumable',
     'Score arithmetic and index selection are unchanged; normalization is adapted above. Failed outputs are not consumable')

fragment = FILES[8]
edit(fragment,
     '    auto denominator = binary(f, c::BinaryKind::kAdd, sum(f, scores, -1),\n'
     '                                filled(f, dense({1, 1}), 1.0e-20F));',
     '    auto denominator = sum(f, scores, -1);')
edit(fragment,
     "  // DeepSeek's positive-sum normalization retains tiny nonzero scores.\n"
     '  // sqrt(nonzero F32 softplus) exceeds the F32 normal floor; zero stays zero.\n'
     '  total = bound(f, total, model.sqrt_softplus\n'
     '                    ? std::numeric_limits<float>::min() : 6.103515625e-5F, false);',
     '  // Sqrt-softplus uses the exact divide-by-sum formula, including 0/0.\n'
     '  // The separate sigmoid model recipes retain their own normalization floor.\n'
     '  if (!model.sqrt_softplus) total = bound(f, total, 6.103515625e-5F, false);')
edit(fragment,
     'struct RouteReference final {',
     '// Independent host oracle: retain the declared F32 softplus and sqrt\n'
     '// boundaries before normalization; double exp/sqrt are not native helpers.\n'
     'inline float sqrt_softplus_reference(float value) {\n'
     '  const double wide = value;\n'
     '  const float exponential = float(std::exp(-std::abs(wide)));\n'
     '  const float logarithm = float(std::log1p(double(exponential)));\n'
     '  const float softplus = float(std::max(wide, 0.0) + double(logarithm));\n'
     '  return float(std::sqrt(double(softplus)));\n'
     '}\n'
     'struct RouteReference final {')
edit(fragment,
     'const double score = model.sqrt_softplus ? std::sqrt(std::log1p(std::exp(logit)))',
     'const double score = model.sqrt_softplus ? sqrt_softplus_reference(float(logit))')
edit(fragment, 'double denominator = hash_ids.empty() ? 0 : 1.0e-20;',
     'double denominator = 0;')
edit(fragment, 'mode == 1 ? -80.0F + float(e % 7) / 8.0F',
     'mode == 1 ? -100.0F + float(e % 7) / 8.0F')
edit(fragment, '      std::array<double, 6> scores;\n      double denominator = 1.0e-20;',
     '      std::array<float, 6> scores;\n      double denominator = 0;')
edit(fragment,
     '        const double value = x[row * model.experts + expert];\n'
     '        scores[slot] = std::sqrt(std::max(value, 0.0) +\n'
     '                                   std::log1p(std::exp(-std::abs(value))));',
     '        scores[slot] = sqrt_softplus_reference(x[row * model.experts + expert]);')
edit(fragment,
     'if (mode == 1 || mode == 2) f.unordered_ids = Fragment::UnorderedIds{1, 6, experts};',
     'if (mode == 1 || mode == 2 || mode == 6)\n'
     '    f.unordered_ids = Fragment::UnorderedIds{1, 6, experts};')
edit(fragment,
     '                         : mode == 5 ? 1.0F + float(index) / 65536.0F\n',
     '                         : mode == 5 ? 1.0F + float(index) / 65536.0F\n'
     '                         : mode == 6 ? -100.0F\n')
edit(fragment,
     '        const double wide = value;\n'
     '        const float sp = mode == 3 ? 0.0F\n'
     '            : float(std::max(wide, 0.0) + std::log1p(std::exp(-std::abs(wide))));\n'
     '        scores[e] = std::sqrt(double(sp));',
     '        scores[e] = mode == 3 ? 0.0F : sqrt_softplus_reference(value);')
edit(fragment,
     '        weights[row * 6 + slot] = denominator > 0\n'
     '            ? float(scores[selected[slot]] / denominator * model.scaling) : 0.0F;',
     '        weights[row * 6 + slot] = float(scores[selected[slot]] / denominator * model.scaling);')

edit(FILES[9],
     '  for (std::size_t index = 0; index < actual.size(); ++index)\n'
     '    EXPECT_NEAR(actual[index], expected[index],\n'
     '                absolute + relative * std::abs(expected[index]))\n'
     '        << index;',
     '  for (std::size_t index = 0; index < actual.size(); ++index) {\n'
     '    if (std::isnan(expected[index])) {\n'
     '      EXPECT_TRUE(std::isnan(actual[index])) << index;\n'
     '    } else if (std::isinf(expected[index])) {\n'
     '      EXPECT_EQ(actual[index], expected[index]) << index;\n'
     '    } else {\n'
     '      ASSERT_TRUE(std::isfinite(actual[index])) << index;\n'
     '      EXPECT_NEAR(actual[index], expected[index],\n'
     '                  absolute + relative * std::abs(expected[index]))\n'
     '          << index;\n'
     '    }\n'
     '  }')
for rel in FILES[10:]:
    edit(rel, 'for (int mode = 0; mode < 6; ++mode)',
         'for (int mode = 0; mode < 7; ++mode)')

new_tree, tree_rows = tree_identity()
edit(FILES[7], entry['vendored']['tree_sha256'], new_tree)
notice = next(f for f in entry['license']['files']
              if f['path'] == 'third_party/sglang_activation/NOTICE')
edit(FILES[7], notice['sha256'], sha(normalized((ROOT / FILES[4]).read_bytes())))
save('vendor-tree.json', dict(algorithm='case-sensitive relative path sort; CRLF/CR -> LF; path|sha256 LF',
                              before=old_tree, after=new_tree,
                              files=[dict(path=p, sha256=h) for p, h in tree_rows]))

diffs = []
after = []
for rel in FILES:
    source = ROOT / rel
    target = STAGE / 'source' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    after.append(identity(source))
    original = (STAGE / 'before' / rel).read_text(encoding='utf-8').splitlines(keepends=True)
    current = source.read_text(encoding='utf-8').splitlines(keepends=True)
    diffs.extend(difflib.unified_diff(original, current, fromfile='before/' + rel, tofile=rel))
(STAGE / 'change.diff').write_text(''.join(diffs), encoding='utf-8')
save('source-freeze.json', dict(files=[dict(path=a['path'], before=b, after=a)
                                      for b, a in zip(before, after)],
                                validation='source-only; no build/GPU/global lock audit executed'))
print(json.dumps(dict(files=len(FILES), tree_before=old_tree, tree_after=new_tree,
                      source_freeze=identity(STAGE / 'source-freeze.json')), indent=2))
