from pathlib import Path
import ast
import hashlib
import json
import math
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
freeze = json.loads((STAGE / 'source-freeze.json').read_text())
for row in freeze['files']:
    for kind, path in [('before', STAGE / 'before' / row['path']),
                       ('after', ROOT / row['path'])]:
        data = path.read_bytes()
        assert len(data) == row[kind]['bytes']
        assert hashlib.sha256(data).hexdigest() == row[kind]['sha256']
    assert (STAGE / 'source' / row['path']).read_bytes() == (ROOT / row['path']).read_bytes()

header = (ROOT / 'include/hyle/compute/model_ops.h').read_text()
assert '0x445334524f555409ULL' in header and '0x4453344841534802ULL' in header
gate = (ROOT / 'third_party/sglang_activation/moe_gate.cuh').read_text()
hashed = (ROOT / 'third_party/sglang_activation/hash_topk.cuh').read_text()
assert gate.count('const auto norm = renormalize ? routed_sum : 1.0f;') == 2
assert 'routed_sum > 0' not in gate
assert 'kRenormalizeSumEpsilon' not in hashed and 'routed_weight / routed_sum' in hashed
assert 'expf(' in gate and 'expf(' in hashed and '__expf' not in gate + hashed
assert 'token_id < 0' in hashed and 'expert_id < 0' in hashed
fragment = (ROOT / 'tests/compute_models/d5_moe_execution_fragments.h').read_text()
assert '1.0e-20' not in fragment
assert 'if (!model.sqrt_softplus) total = bound(f, total, 6.103515625e-5F, false);' in fragment
assert 'mode == 6 ? -100.0F' in fragment
assert 'mode == 1 ? -100.0F' in fragment
assert 'double denominator = 0;' in fragment
comparison = (ROOT / 'tests/compute_models/d5_qwen35_gguf_fragment_support.h').read_text()
assert 'EXPECT_TRUE(std::isnan(actual[index]))' in comparison
assert 'ASSERT_TRUE(std::isfinite(actual[index]))' in comparison

original_lock = json.loads((STAGE / 'before/cmake/HyleDependencyLock.json').read_text())
current_lock = json.loads((ROOT / 'cmake/HyleDependencyLock.json').read_text())
old = next(d for d in original_lock['dependencies'] if d['name'] == 'sglang_activation')
new = next(d for d in current_lock['dependencies'] if d['name'] == 'sglang_activation')
expected = json.loads(json.dumps(original_lock))
expected_row = next(d for d in expected['dependencies'] if d['name'] == 'sglang_activation')
expected_row['vendored']['tree_sha256'] = new['vendored']['tree_sha256']
next(f for f in expected_row['license']['files'] if f['path'].endswith('/NOTICE'))['sha256'] = \
    next(f for f in new['license']['files'] if f['path'].endswith('/NOTICE'))['sha256']
assert expected == current_lock
ast.parse((STAGE / 'implement.py').read_text())

archive = ROOT / 'docs/evidence/research/deepseek-v4-ga-2026-10-19.zip'
official = []
with zipfile.ZipFile(archive) as z:
    for name in ['flash-0731/inference-model.py', 'pro-0813/current/inference/model.py',
                 'flash-0731/preview-inference-model.py', 'pro-0813/preview/inference/model.py']:
        data = z.read(name)
        source = data.decode()
        section = source[source.index('class Gate('):source.index('\nclass ', source.index('class Gate(') + 1)]
        assert 'weights /= weights.sum(dim=-1, keepdim=True)' in section
        assert '1e-20' not in section and 'clamp' not in section
        official.append(dict(archive_entry=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                             normalization='weights /= weights.sum(dim=-1, keepdim=True)'))

ninja = (ROOT / '.scratch/b-cuda-d5/build.ninja').read_text()
block = re.search(r'build src\\compute_provider_cuda\\CMakeFiles\\hyle_compute_provider_cuda.dir\\sglang_router_kernel.cu.obj:.*?(?=\n\n)', ninja, re.S).group()
flags = next(line.strip() for line in block.splitlines() if 'FLAGS =' in line)
assert 'fast_math' not in flags and 'ftz' not in flags
(STAGE / 'native-recipe-fragment.txt').write_text(block + '\n')

result = dict(status='source assertions passed; no compilation or GPU validation',
              official=official, native_flags=flags,
              fp32_note='expf/log1pf/sqrtf source retained. No fast-math or explicit FTZ in retained real recipe. This is not a compiled-PTX proof.',
              lock='only selected vendor tree and NOTICE identity changed; no global lock audit executed',
              portability='CPU/Apple/Vulkan typed primitive recipes updated; these custom routing descriptors remain CUDA-only',
              zero_sum='NaN numeric outputs expected with valid IDs and successful Completion; invalid IDs keep existing checked-error behavior',
              other_models='Case.sqrt_softplus true only DeepSeek Pro/Flash variants; independent sigmoid recipe normalization floor retained')
(STAGE / 'source-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status=result['status'], official_sources=len(official), changed_files=len(freeze['files'])), indent=2))
