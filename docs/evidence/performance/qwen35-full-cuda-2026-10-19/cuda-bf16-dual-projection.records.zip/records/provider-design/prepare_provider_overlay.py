"""Create only a scratch four-node BF16 dual-projection candidate overlay."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
RELATIVE = Path("src/graph_provider_ggml_cuda/ggml_cuda_region.cc")
source = ROOT / RELATIVE
before = source.read_text(encoding="utf-8")

helper = r'''
// Private implementation candidate, not a new public operation. The native
// matcher must still admit the actual device, edges, precision and read/write
// ranges before eliding any store. Descriptors alone do not prove a kernel hit.
template <class CanElide>
Result<bool> matches_bfloat_dual_projection(
    void *context, const Graph &graph, std::span<const NodeId> nodes,
    CanElide can_elide) noexcept {
  if (nodes.size() != 4) return false;
  NodeId silu, multiply;
  std::array<NodeId, 2> projections{};
  std::size_t count = 0;
  for (const auto node : nodes) {
    const auto operation = graph.operation(node);
    if (!operation) return false;
    const auto traits = compute::operation_traits(*operation);
    HYLE_ASSIGN_OR_RETURN(auto resources, graph.node_resource_count(node));
    HYLE_ASSIGN_OR_RETURN(auto outputs, graph.node_output_count(node));
    if (resources != 0 || outputs != 1 || traits.effect != compute::EffectKind::kPure ||
        traits.resource_count != 0) return false;
    if (const auto *matmul = operation->get_if<compute::MatMul>()) {
      if (count == projections.size() ||
          matmul->accumulation_type != compute::DataType::kFloat32) return false;
      projections[count++] = node;
    } else if (const auto *unary = operation->get_if<compute::Unary>()) {
      if (silu.valid() || unary->kind != compute::UnaryKind::kSilu) return false;
      silu = node;
    } else if (const auto *binary = operation->get_if<compute::Binary>()) {
      if (multiply.valid() || binary->kind != compute::BinaryKind::kMultiply) return false;
      multiply = node;
    } else return false;
  }
  if (count != 2 || !silu.valid() || !multiply.valid()) return false;
  HYLE_ASSIGN_OR_RETURN(auto unary_inputs, graph.node_input_count(silu));
  HYLE_ASSIGN_OR_RETURN(auto multiply_inputs, graph.node_input_count(multiply));
  if (unary_inputs != 1 || multiply_inputs != 2) return false;
  HYLE_ASSIGN_OR_RETURN(auto projected_gate, graph.node_input(silu, 0));
  HYLE_ASSIGN_OR_RETURN(auto activation, graph.result(silu));
  HYLE_ASSIGN_OR_RETURN(auto left, graph.node_input(multiply, 0));
  HYLE_ASSIGN_OR_RETURN(auto right, graph.node_input(multiply, 1));
  if (left == right || (left != activation && right != activation)) return false;
  const auto projected_up = left == activation ? right : left;
  if (projected_gate.kind() != ValueKind::kNodeOutput ||
      projected_up.kind() != ValueKind::kNodeOutput) return false;
  HYLE_ASSIGN_OR_RETURN(auto gate, graph.producer(projected_gate));
  HYLE_ASSIGN_OR_RETURN(auto up, graph.producer(projected_up));
  if (gate == up ||
      !((gate == projections[0] && up == projections[1]) ||
        (gate == projections[1] && up == projections[0]))) return false;
  HYLE_ASSIGN_OR_RETURN(auto output, graph.result(multiply));
  HYLE_ASSIGN_OR_RETURN(auto description, graph.value_description(output));
  if (!description.is_plain() || !description.is_dense() || description.rank() != 2 ||
      description.data_type() != compute::DataType::kBFloat16 ||
      description.dimensions()[0] != 1 || description.dimensions()[1] <= 0 ||
      description.dimensions()[1] > std::numeric_limits<int>::max()) return false;
  for (const auto value : {projected_gate, projected_up, activation}) {
    HYLE_ASSIGN_OR_RETURN(auto actual, graph.value_description(value));
    if (actual != description) return false;
  }
  if (!can_elide(gate, projected_gate) || !can_elide(up, projected_up) ||
      !can_elide(silu, activation)) return false;
  ValueId common_input;
  for (const auto projection : projections) {
    HYLE_ASSIGN_OR_RETURN(auto arity, graph.node_input_count(projection));
    if (arity != 2) return false;
    HYLE_ASSIGN_OR_RETURN(auto input, graph.node_input(projection, 0));
    HYLE_ASSIGN_OR_RETURN(auto weight, graph.node_input(projection, 1));
    if (common_input.valid() && input != common_input) return false;
    common_input = input;
    HYLE_ASSIGN_OR_RETURN(auto x, graph.value_description(input));
    HYLE_ASSIGN_OR_RETURN(auto w, graph.value_description(weight));
    if (!x.is_plain() || !x.is_dense() || x.rank() != 2 ||
        x.data_type() != compute::DataType::kBFloat16 || x.dimensions()[0] != 1 ||
        x.dimensions()[1] <= 0 || x.dimensions()[1] % 2 != 0 ||
        x.dimensions()[1] > std::numeric_limits<int>::max() ||
        !w.is_plain() || w.rank() != 2 ||
        w.data_type() != compute::DataType::kBFloat16 ||
        w.dimensions()[0] != x.dimensions()[1] ||
        w.dimensions()[1] != description.dimensions()[1]) return false;
    // The reused MMVF forms row*stride_row in int before widening it.
    // Check the product by division, without overflowing descriptor arithmetic.
    if (description.dimensions()[1] >
        std::numeric_limits<int>::max() / x.dimensions()[1]) return false;
    // Only the metadata transpose of contiguous [N,K] weight rows. Ordinary
    // [K,N], padding and other strides need native CONT and are outside this
    // no-copy implementation even though ordinary MatMul may support them.
    HYLE_ASSIGN_OR_RETURN(auto physical, w.transposed());
    if (!physical.is_dense()) return false;
  }
  for (const auto node : nodes) {
    HYLE_ASSIGN_OR_RETURN(auto supported, supported_node(context, graph, node));
    if (!supported) return false;
  }
  return true;
}
'''

proposal = r'''
  // A distinct no-copy implementation may cover two otherwise preferred BLAS
  // leaves. Their ordinary ranks and all nonmatching regions are unchanged.
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    if (!eligible[i]) continue;
    HYLE_ASSIGN_OR_RETURN(auto multiply, graph.node_id(i));
    const auto operation = graph.operation(multiply);
    const auto *binary = operation ? operation->get_if<compute::Binary>() : nullptr;
    if (!binary || binary->kind != compute::BinaryKind::kMultiply) continue;
    for (std::size_t port = 0; port < 2; ++port) {
      HYLE_ASSIGN_OR_RETURN(auto activation, graph.node_input(multiply, port));
      HYLE_ASSIGN_OR_RETURN(auto projected_up, graph.node_input(multiply, 1 - port));
      if (activation.kind() != ValueKind::kNodeOutput ||
          projected_up.kind() != ValueKind::kNodeOutput) continue;
      HYLE_ASSIGN_OR_RETURN(auto silu, graph.producer(activation));
      HYLE_ASSIGN_OR_RETURN(auto up, graph.producer(projected_up));
      const auto unary_op = graph.operation(silu);
      const auto *unary = unary_op ? unary_op->get_if<compute::Unary>() : nullptr;
      if (!unary || unary->kind != compute::UnaryKind::kSilu) continue;
      HYLE_ASSIGN_OR_RETURN(auto projected_gate, graph.node_input(silu, 0));
      if (projected_gate.kind() != ValueKind::kNodeOutput) continue;
      HYLE_ASSIGN_OR_RETURN(auto gate, graph.producer(projected_gate));
      const std::array nodes{gate, silu, up, multiply};
      if (std::ranges::any_of(nodes, [&](NodeId node) noexcept {
            return !eligible[node.ordinal()];
          })) continue;
      HYLE_ASSIGN_OR_RETURN(auto matches, matches_bfloat_dual_projection(
          context, graph, nodes, [&](NodeId producer, ValueId value) noexcept {
            const auto control = uses.control_readers[producer.ordinal()];
            return uses.uses[value.ordinal()] == 1 &&
                (control == FusionUses::kNone || std::ranges::any_of(nodes,
                    [&](NodeId node) noexcept { return control == node.ordinal(); }));
          }));
      if (!matches) continue;
      HYLE_ASSIGN_OR_RETURN(auto more, writer.try_add({
          .nodes = nodes,
          .cost = {.workspace = std::nullopt, .persistent_bytes = std::nullopt,
                   .copy_bytes = 0, .repack_bytes = 0,
                   .synchronization_count = 2, .dispatch_count = 1},
          .route = 3,
          .replay_class = compute::ProviderReplayClass::kManaged,
          .implementation = compute::ProviderImplementationId{4},
          .policy = kGgmlCudaDualProjectionPolicy,
          .preference = kGgmlCudaDualProjectionPreference}));
      if (!more) return Status::Ok();
      break;
    }
  }
'''

qualification = r'''
  if (request.route == 3) {
    HYLE_ASSIGN_OR_RETURN(auto matches, matches_bfloat_dual_projection(
        context, *request.graph, request.nodes,
        [&](NodeId, ValueId value) noexcept {
          // Common boundary discovery exposes every escaping intermediate,
          // including published metadata aliases. Contraction preserves the
          // original control edges. The one discovery-local use/control index
          // already proved this candidate's closure; do not rescan the Graph.
          return std::ranges::find(request.outputs, value) == request.outputs.end();
        }));
    // All three intermediates are private. The single escaping value is the
    // original Multiply, never a rewritten GLU or a placeholder output.
    if (!matches || request.outputs.size() != 1)
      return Status::Unimplemented("ggml CUDA BF16 dual projection boundary is not admitted");
    const auto output = request.outputs.front();
    const auto producer = request.graph->producer(output);
    if (!producer || std::ranges::find(request.nodes, *producer) == request.nodes.end())
      return Status::Unimplemented("ggml CUDA BF16 dual projection output is foreign");
    const auto operation = request.graph->operation(*producer);
    const auto *binary = operation ? operation->get_if<compute::Binary>() : nullptr;
    return binary && binary->kind == compute::BinaryKind::kMultiply ? Status::Ok()
        : Status::Unimplemented("ggml CUDA BF16 dual projection output is not Multiply");
  }
'''


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Expected unique source seam: " + old[:100])
    return text.replace(old, new, 1)


candidate = replace_once(before,
    "inline constexpr std::uint32_t kGgmlCudaSiluMultiplyPreference = 200;",
    "inline constexpr std::uint32_t kGgmlCudaSiluMultiplyPreference = 200;\n"
    "inline constexpr compute::RoutePolicyId kGgmlCudaDualProjectionPolicy{\n"
    "    0x48594c4547474355ULL, 3, 1};\n"
    "inline constexpr std::uint32_t kGgmlCudaDualProjectionPreference = 200;")
candidate = replace_once(candidate, "// Match an already implemented native numerical chain, following its actual",
    helper + "\n// Match an already implemented native numerical chain, following its actual")
candidate = replace_once(candidate, "  HYLE_RETURN_IF_ERROR(uses.initialize(graph));\n  // Follow the multiply's actual operands, independent of insertion adjacency.",
    "  HYLE_RETURN_IF_ERROR(uses.initialize(graph));\n" + proposal +
    "\n  // Follow the multiply's actual operands, independent of insertion adjacency.")
candidate = replace_once(candidate,
    "Status qualify(void *context, const RegionCompileRequest &request) noexcept {\n  if (!request.graph || (request.route != 1 && request.route != 2)",
    "Status qualify(void *context, const RegionCompileRequest &request) noexcept {\n"
    "  if (!request.graph || (request.route != 1 && request.route != 2 && request.route != 3)")
candidate = replace_once(candidate,
    '    return Status::Unimplemented("ggml CUDA region boundary is not admitted");\n  if (request.route == 2)',
    '    return Status::Unimplemented("ggml CUDA region boundary is not admitted");\n' + qualification + '\n  if (request.route == 2)')
old = '''    const auto constants = constant_expressions::prepare(context, request, values, recipe);
    if (constants.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return constants;
    const auto packing = ggml_shared::pack_constants(context, request, values, recipe,
        &native::widen_bfloat_constant, &native::pack_matrix_constant);
    if (packing.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
      return packing;'''
candidate = replace_once(candidate, old, '''    if (request.route != 3) {
      const auto constants = constant_expressions::prepare(context, request, values, recipe);
      if (constants.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
        return constants;
      const auto packing = ggml_shared::pack_constants(context, request, values, recipe,
          &native::widen_bfloat_constant, &native::pack_matrix_constant);
      if (packing.kind != compute::ProviderPrepareOutcomeKind::kPrepared)
        return packing;
    }
    // Route3 imports the original exact BF16 x/weight boundaries. Its dense
    // transposed RHS needs no cold pack/CONT and no duplicate weight bank.''')

target = STAGE / "overlay" / RELATIVE
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(candidate, encoding="utf-8", newline="\n")
(STAGE / "provider.before.cc").write_text(before, encoding="utf-8", newline="\n")
(STAGE / "provider-change.diff").write_text("".join(difflib.unified_diff(
    before.splitlines(True), candidate.splitlines(True),
    fromfile="a/" + RELATIVE.as_posix(), tofile="b/" + RELATIVE.as_posix())), encoding="utf-8")
facts = {
    "scope": "Scratch-only provider candidate; native implementation is separately owned by parent. Not applied, compiled, or GPU tested.",
    "base": {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()},
    "overlay": {"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()},
    "route": 3, "implementation": 4, "policy": ["0x48594c4547474355", 3, 1], "preference": 200,
    "ordinary_leaf_or_region_ranks_changed": False,
    "native_input_contract": {"x": "plain dense BF16[1,K], K positive even/int32 and N*K<=INT_MAX (old row*stride_row int product)", "weights": "two plain BF16 logical[K,N] with transposed().is_dense(), so physical[N,K] contiguous. They may be ordinary ready inputs or immutable bindings; no payload-based identity or cold packing.", "intermediates": "G/U/A plain dense BF16[1,N], three private single-use values and no external control readers", "output": "original Mul Y plain dense BF16[1,N], N positive/int32; all actual pointer/architecture/shouldMMVF eligibility belongs to native matcher", "recipe": "Standard MatMul, ordinary Unary SiLU, MatMul, Binary Multiply; Graph canonicalizes original topological node order. Original MatMul accumulation parameters and stable SiLU marker are unchanged; final Mul op_params are not a dot precision source.", "native_orders": ["gateMM,SiLU,upMM,Mul", "gateMM,upMM,SiLU,Mul", "upMM,gateMM,SiLU,Mul"], "native_node_count_limit": "Only the direct four-native-node BF16 MUL_MAT form is in scope. Current rank2/singlevector/evenK lowering admits its direct BF16 vector branch. RawF32 MatMul plus BF16 CPY/six-node forms are NOT fused this round. Both original MM descriptors must be BF16/F32acc, SiLU.src0==gate_mm and final Mul's other input==up_mm. No CPY/CONT stripping. Descriptor admission still does not prove the actual-range matcher hits.", "required_private_native_entry": "ggml_cuda_op_bf16_dual_matvec_silu_mul(ctx, gate_mm, up_mm, silu, dst)", "rounding": "G=BF16_RNE(dotF32(Wg,x)); U=BF16_RNE(dotF32(Wu,x)); A=BF16_RNE(strict_stableSiLU(widenG)); Y=BF16_RNE(widenA*widenU)"},
    "limits": ["Candidate selection is not proof that the native actual-range matcher fuses; a physical kernel observation is required before claiming a hit or dispatch reduction.", "Multiple internal control readers conservatively decline through FusionUses::kMany; no attempt to widen control semantics.", "Nonmatching shapes/layouts/types retain existing candidates. A legal selected region may still use its original safe native chain when a real pointer guard rejects fusion; accepted execution errors never trigger another provider.", "No original weight is retired/replaced; no quantization, packed weight bank, new common struct/op/API, consumer rewrite, or product manifest change."]}
(STAGE / "provider-proposal.json").write_text(json.dumps(facts, indent=2) + "\n", encoding="utf-8")
def identity(path):
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

freeze = {
    "scope": "Scratch provider proposal/test-plan only. No product edit, C++ build, GPU or test execution. The earlier review.json remains unchanged.",
    "files": [identity(path) for path in (Path(__file__).resolve(),
        STAGE / "provider.before.cc", STAGE / "provider-change.diff", target,
        STAGE / "provider-proposal.json", STAGE / "tests-plan.json")],
    "product_base": identity(source),
    "cold_discovery": "One existing global FusionUses initialization in propose. The new fixed-four-node matcher does no whole-Graph/output walk. Qualification uses common request.outputs escape proof, exact final Mul output and original contraction/control validation like route2.",
    "compile_overlay_include_requirement": "Keep the original recipe; add original src/graph_provider_ggml_cuda include directory for constant_expressions.h because the overlay contains only this cc. Existing src/compute_provider_ggml_cuda include remains needed for program.h and relative shared/core includes."
}
(STAGE / "provider-freeze.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
print(json.dumps(facts["overlay"]))
