"""Offline source/physical-count design receipt; no build or GPU work."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
BASE = STAGE.parent
ROOT = BASE.parent.parent
spec = importlib.util.spec_from_file_location("physical", BASE / "cuda-stable-silu/profile-analysis-stable.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": digest.hexdigest()}


def trace(label, stem):
    database = Path(str(stem) + ".sqlite")
    csv = Path(str(stem) + "_cuda_gpu_kern_sum.csv")
    data = a.load(database, csv)
    phases = a.phases(data)
    assert phases["valid"]
    assert data["receipt"]["csv_sqlite_per_symbol_counts_equal"]
    endpoints = [p["token_D2H_end_ns"] for p in phases["phases"]]
    groups, role_counts = collections.Counter(), collections.Counter()
    for step in range(7, 32):
        kernels = [k for k in data["kernels"] if endpoints[step - 1] < k["start"] <= endpoints[step]]
        projection = [k for k in kernels if ("gemvx" if label == "Hyle" else "mul_mat_vec_f<") in k["name"]]
        cursor = 0
        for layer in range(24):
            linear = layer % 4 != 3
            roles = ["linear_qkv", "linear_scalar_0", "linear_scalar_1", "linear_z", "linear_out"] if linear else ["attention_q", "attention_k", "attention_v", "attention_out"]
            roles += ["ffn_gate", "ffn_up", "ffn_down"] if label == "Hyle" else ["ffn_gate_up", "ffn_down"]
            expected = ([1536, 4, 4, 512, 512, 1536, 1536, 512] if linear else [1024, 128, 128, 512, 1536, 1536, 512]) if label == "Hyle" else ([6144, 16, 16, 2048, 2048, 6144, 2048] if linear else [4096, 512, 512, 2048, 6144, 2048])
            for role, grid in zip(roles, expected):
                kernel = projection[cursor]
                cursor += 1
                assert kernel["gridX"] == grid, (label, step, layer, role)
                fused = label == "peer" and "(bool)1, (bool)0>" in kernel["name"]
                if label == "peer":
                    assert fused == (role in ("ffn_gate_up", "ffn_down", "attention_out"))
                groups[(fused, grid)] += 1
                role_counts[role] += 1
        assert cursor == len(projection) - 1
        assert projection[-1]["gridX"] == (62080 if label == "Hyle" else 248320)
        role_counts["head"] += 1
        groups[(False, projection[-1]["gridX"])] += 1
    assert all(count % 25 == 0 for count in role_counts.values())
    return {"inputs": [identity(database), identity(csv)], "warm_steps": "decode7..31 inclusive, 25 token-endpoint bins", "all_25_model_order_grid_and_peer_fusion_checks_passed": True,
            "projection_count_each_step": sum(role_counts.values()) // 25,
            "roles_per_step": {role: count // 25 for role, count in role_counts.items()},
            "symbol_grid_groups_per_step": [{"fusion_template": fused, "grid_x": grid, "count": count // 25} for (fused, grid), count in groups.items()]}


sources = ["tools/qwen35_text/main.cc", "src/compute_provider_cublas/cublas_provider.cc", "src/compute_provider_ggml_cuda/tensor_program.cc", "src/compute_provider_ggml_cuda/program.h", "src/graph_provider_ggml_cuda/ggml_cuda_region.cc", "src/graph_provider_ggml_cuda/constant_expressions.h", "src/graph/constant_artifact.cc", "src/graph/plan_state.h", "src/graph_batch/batch.cc", "src/graph/region_access.cc", ".scratch/architecture-refactor-2026-10-18/cuda-projection-fusion/native-source/src/ggml-cuda/mmvf.cu", ".scratch/architecture-refactor-2026-10-18/cuda-stable-silu/native-source/src/ggml-cuda/unary.cu", ".scratch/architecture-refactor-2026-10-18/cuda-gdn-l2-fusion/native-source/src/ggml-cuda/ggml-cuda.cu", ".scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/models/qwen35.cpp", ".scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/src/llama-graph.cpp", ".scratch/architecture-refactor-2026-10-18/llama-matched-consumer/converted-model-audit.json"]
report = {
    "scope": "Read-only product/native/trace design review. This helper writes only its new review.json. No product edits, build, GPU, new profiling, or mutation of v14 retained evidence.",
    "source_snapshot_note": "Source SHAs describe current files read by this design receipt, not a claim that every current host source is identical to the earlier profiled image.",
    "sources": [identity(ROOT / path) for path in sources],
    "physical_counts": {"Hyle": trace("Hyle", BASE / "cuda-gdn-l2-fusion/profile/qwen-gdn-l2-trace"), "peer": trace("peer", BASE / "cuda-gdn-l2-fusion/peer-profile/peer-trace")},
    "role_mapping_limit": "The trace has physical symbols/grid/order, no logical-node NVTX mapping. Roles are a source-order inference cross-checked against the complete model projection schedule, all launch widths and peer fusion flags in all25 warm steps. The two width16 scalar projections are intentionally not assigned a/b names. 54 peer fusion launches split24 grid6144 dual gate/up+GLU,24 grid2048 down+residual,6 grid2048 attention_out+residual;18 linear_out remain plain. Only the24 duals reduce projection count187->163.",
    "current_ffn": {"seam": "main.cc:191-203; retained default-T1.route.tsv cublasLt MatMul leaves; tensor_program.cc:839-869 and ggml_cuda_region.cc:294-325", "shape": "Decode BF16 x[1,2048]; checkpoint gate/up[6144,2048], metadata transpose RHS; F32 accumulation. Each FFN already has two BF16-output cuBLAS kernels plus one strict typed SiLU/Mul kernel; no BF16/F32 casts between them.", "contract": ["G=BF16_RNE(dot_F32(Wgate,x))", "U=BF16_RNE(dot_F32(Wup,x))", "A=BF16_RNE(stable_SiLU_F32(widen(G)))", "Y=BF16_RNE(widen(A)*widen(U))"]},
    "generic_selection": "Follow the final Multiply's actual operand edges to marked ordinary SiLU(gate MatMul) and other up MatMul with identical activation. Require matching BF16 types/layout, F32 accumulation, dense rank2 and initially single vector/evenK/no IDs/bias/batch. Respect actual immutable roots/offsets/resources, published/extra data/control readers and external memory overlaps. Use provider-local candidate admission and existing Graph contractibility; no model name/op whitelist. Current MatMul leaves are cublasLt, so a native matcher alone cannot cross their selected-provider islands.",
    "packed_lt": {"carrier": "Cold row-concatenate gate/up checkpoint weights into[12288,2048], logical RHS[2048,12288]. One mature cuBLASLt BF16/F32acc/BF16 MatMul to[1,12288]; split halves and retain the existing strict BF16 staged-RNE SiLU/Mul. Three physical kernels become two, saving24 projection/total launches over24FFNs, not48.", "seams": ["cublas_provider.cc:117-174 rank2 row/column layouts and matching BF16;245-315 CUBLAS_COMPUTE_32F, COMPUTE_TYPE split-K mask and actual heuristic;360-395 original QueueSequence/capture submission", "constant_expressions.h:127-149,193-259 and program.h:evaluate_constant_recipe supply multi-root cold recipe, exact opaque identity, all source qualification and real retirement; source-ready aliases must remain independent logical origins", "v14 ggml-cuda.cu:1948 BF16 destination dispatches typedMMVF; a native recipe rewrite is not reuse of the separately selected modern cublasLt provider. Reuse/factor its real private prepared helper rather than silently changing the GEMM carrier"], "numerical_limit": "Doubling output width may change cuBLASLt algorithm, workspace and reduction order despite identical K/operands/F32acc. Do not claim bit identity to two independent Lt calls. Compare each BF16 projection half independently before staged activation and full output acceptance. Keep the existing compute-type reduction restriction.", "layout_limit": "For T>1, row-major[T,2M] gate/up subviews have2M row stride and are not dense[T,M]. Existing strict unary fusion requires contiguous mappings. Initially limit T1 or explicitly support the real strides without a hot copy.", "persistent_bytes_per_phase": 1207959552, "mib_per_pair": 48, "gib_per_24_pairs": 1.125, "ownership_block": "Current main.cc:236 weight Tensor.ready bank, main.cc:324/440 independent T128/T1 graph plans and plan_state.h:852-854 original leases keep original weights. Successful artifact preparation retires temporary native preparation, not caller roots. This adds1.125GiB per independently packed phase absent ownership sharing; the family-local artifact cache does not automatically share across those separately built graphs. Published/shared users, old plans and live slots forbid force-retiring original allocations. Not an immediate default fix under no-big-dup constraint.", "no_dup_prerequisite": "A generic immutable shared packed bank must become the actual common allocation behind logical gate/up views, or replacement ownership must prove all original users/plans/slots retired. This is an ownership/loading change, not a free effect of kernel fusion."},
    "dual_mmvf": {"carrier": "Existing dual-weight MMVF reads both separate weight pointers and reuses activation loads with independent F32 dot reductions. A new private BF16 stable epilogue can insert G/U RNE+widen, strict stable SiLU, A RNE+widen and final Y RNE. No persistent weight duplicate; three physical kernels could become one, saving24 projection and48 total launches.", "seams": ["mmvf.cu:7-354 dual accumulation/reduction;357-394 old GLU consumes unrounded F32 dots;412 fusion switch accepts Y/Dst=float;632-641 and685-701 typedBF16 entry explicitly forbids fusion", "v14 ggml-cuda.cu:1877 old float fusion admission requires F32 activation/destination;4503 expects MUL_MAT+MUL_MAT+GLU. New four-node ordinary-SiLU candidate/matcher and typed host entry must agree, retaining both MatMul precision descriptors instead of reading final Multiply op_params", "stable unary.cu:45-53 is compiled without fast math;:295-318 explicitly rounds unary toBF16 before Mul. MMVF TU uses fast math: putting expf/stable formula there is not proof of the original strict SiLU. Private shared template instantiated for the new epilogue in the strict TU is possible, but dot FMA/FTZ/reduction semantics still require compiled oracle validation"], "peer_difference": "Peer BF16-weight MMVF has float activation and float destination; qwen35.cpp:474 and llama-graph.cpp:1851 build F32 swiglu_split. Its unrounded GLU maths is not Hyle's staged BF16 oracle. New MMVF reduction can differ from current cuBLAS even if every BF16 boundary is retained.", "ABI_limit": "Avoid widening common.cuh MM fusion structs used by MMVF/MMVQ/MMF just to carry this private epilogue; use private entry/template arguments and preserve existing default F32 behavior."},
    "realistic_performance": {"weight_bytes_read_per_pair": 50331648, "approx_activation_bytes_removed_by_full_fusion_per_pair": 49152, "activation_over_weight_ratio": 0.0009765625, "limit": "Both approaches still read both gate/up matrices. Launch reduction is an opportunity, not a win claim; bandwidth, cuBLAS shape selection, register/shared pressure and strict activation can dominate. Earlier isolated typedMMVF-vs-Lt tests showed no demonstrated benefit and are not a reason to change the default. No repeated isolated benchmark or end-to-end speedup claimed. Different Nsight acquisitions/overhead and peer mathematics prevent causal attribution from duration differences."},
    "cheapest_hot_prepare": {"seams": ["batch.cc:755,775,780,558,300,727 repeatedly call full RegionAccess visit", "region_access.cc:162-185 scans all plan.steps; native selected refs/frame_slots already belong to BatchResources", "Invocation.reset executable.cc:8708 keeps provider slots; move:8530 transfers the same InvocationState; original idle/outcome/resource gate and dynamic layout/lease validations remain mandatory"], "direction": "Cache successful immutable capability/selected-step discovery per original Invocation payload, including an empty initialized result; retain current dynamic inspect/layout, queue admission, reset, pending-source and upload checks. Pending fresh-path mutation/partial failure must revoke cached initialization or update transactionally. Do not cache borrowed bound TensorView spans/provider mutable plans, and never dereference slot refs in payload destruction.", "timing_limit": "Measure discovery visits separately. cold_batch also includes actual metadata upload and wait plus consumer binding/replay preparation, so it is neither all pureCPU nor all removable."}
}
output = STAGE / "review.json"
output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({"output": str(output), "bytes": output.stat().st_size,
                  "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}, ensure_ascii=False))
