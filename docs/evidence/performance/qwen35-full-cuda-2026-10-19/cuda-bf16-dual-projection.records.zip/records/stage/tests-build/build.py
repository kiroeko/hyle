"""One strict test TU plus current CUDA test relink; no GPU execution."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
DUAL = STAGE.parent
ARCH = DUAL.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location("dual_test_cached_build", ARCH / "cuda-projection-fusion/build.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c

BASE = ARCH / "cuda-rms-candidate-frontier/checks/platform-fs-relink-20261019T081124/cuda-link-plan.json"
CURRENT = DUAL / "checks/relink-20261019T084930/qwen-link-plan.json"
CURRENT_PLAN = CURRENT.parent / "plan.json"
RECIPE = ARCH / "cuda-reshape-reuse/stable-test-identity.json"
SOURCE = ROOT / "tests/graph_route_cuda/stable_silu_test.cc"
NEW = DUAL / "checks/20261019T084721"


def inputs(command):
    return [x for x in command if not x.startswith("/") and Path(x).is_absolute()
            and Path(x).suffix.lower() in (".obj", ".lib")]


def check(plan):
    for row in plan["frozen"] + plan["cached_inputs"]:
        if not b.same(row):
            raise ValueError("Input drift: " + row["path"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    out = STAGE / dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
    out.mkdir(parents=True, exist_ok=False)
    before = c.read(DUAL / "tests-source-freeze.json")
    if b.identity(SOURCE)["sha256"] != before["overlay"]["sha256"]:
        raise ValueError("Applied test is not the final frozen overlay")
    base = c.read(BASE)
    current = c.read(CURRENT)
    if len(base["inputs"]) != 131 or len(current["inputs"]) != 124:
        raise ValueError("Unexpected retained closure size")
    base_rows = {c.key(row["path"]): row for row in base["inputs"]}
    current_rows = {c.key(row["path"]): row for row in current["inputs"]}
    owners = (
        ("native main", ARCH / "cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236/ggml-cuda.obj", NEW / "ggml-cuda.obj"),
        ("native MMVF", ARCH / "cuda-projection-fusion/checks/20261019T054525-686f560d/mmvf.obj", NEW / "mmvf.obj"),
        ("native unary", ARCH / "cuda-stable-silu/unary.obj", NEW / "unary.obj"),
        ("GGML CUDA provider", ARCH / "cuda-gdn-l2-fusion/checks/20261019T073103-c4e59236/provider.obj", NEW / "provider.obj"),
        ("GGML CUDA region", ARCH / "cuda-rms-candidate-frontier/checks/20261019T080921/region.obj", NEW / "region.obj"),
        ("Graph batch", ARCH / "immutable-constant-alias/checks/20261019T063301-1d108b74/9-graph_batch-batch.obj", ARCH / "cuda-hot-prepare-selection/checks/20261019T082235/graph-batch.obj"),
        ("Compute copy", ARCH / "native-ragged-graph/validation/windows/src--compute--batch_transfer.obj", ARCH / "cuda-hot-prepare-selection/checks/cpu-identity-20261019T082918/batch-transfer.obj"),
        ("Mem system resource", ARCH / "native-ragged-graph/validation/windows/src--mem--resource.obj", ARCH / "cuda-hot-prepare-selection/checks/cpu-identity-20261019T082918/mem-resource.obj"),
    )
    replacements = {}
    owner_changes = []
    for owner, old, new in owners:
        old_key, new_key = c.key(old), c.key(new)
        if old_key not in base_rows or sum(c.key(x) == old_key for x in base["command"]) != 1:
            raise ValueError("Base does not contain one explicit owner: " + owner)
        if new_key not in current_rows or sum(c.key(x) == new_key for x in current["command"]) != 1:
            raise ValueError("Current Qwen does not contain one explicit owner: " + owner)
        if not b.same(base_rows[old_key]) or not b.same(current_rows[new_key]):
            raise ValueError("Recorded owner identity drift: " + owner)
        replacements[old_key] = str(new)
        owner_changes.append({"owner": owner, "before": base_rows[old_key], "after": current_rows[new_key]})
    recipe = c.read(RECIPE)
    if any(c.key(row["path"]) == c.key(recipe["object"]["path"]) for row in base["inputs"]):
        raise ValueError("Unexpected existing stable test owner: use replacement instead of append")
    compile_command = b.host_command(recipe["command"], SOURCE, "stable-test", out)
    command = [replacements.get(c.key(x), x) for x in base["command"]
               if not x.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    command.insert(1, str(out / "stable-test.obj"))
    image = out / "cuda-tests.exe"
    command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                "/IMPLIB:" + str(image.with_suffix(".lib"))]
    selected = inputs(command)
    if len(selected) != 132 or len({c.key(x) for x in selected}) != 132:
        raise ValueError("Expected132 unique explicit test inputs")
    if sum(c.key(x) == c.key(out / "stable-test.obj") for x in selected) != 1:
        raise ValueError("Fresh stable test object duplicated")
    cached = []
    for path in selected:
        if c.key(path) == c.key(out / "stable-test.obj"):
            continue
        row = current_rows.get(c.key(path), base_rows.get(c.key(path)))
        if row is None or not b.same(row):
            raise ValueError("Missing or changed cached input: " + path)
        cached.append(row)
    frozen = [b.identity(x) for x in (Path(__file__), SOURCE, RECIPE, BASE, CURRENT, CURRENT_PLAN,
              DUAL / "tests-source-freeze.json", DUAL / "tests-plan.json", STAGE / "applied-source.json")]
    old_deps = None
    for i, arg in enumerate(recipe["command"]):
        if arg.lower() == "/sourcedependencies":
            old_deps = Path(recipe["command"][i + 1])
    if old_deps is None or not old_deps.is_file():
        raise ValueError("Exact old test sourceDependencies unavailable")
    frozen.append(b.identity(old_deps))
    for value in c.read(old_deps).get("Data", {}).get("Includes", []):
        path = Path(value).resolve()
        if path.is_relative_to(ROOT):
            frozen.append(b.identity(path))
    plan = {
        "compile": [{"tag": "stable-test", "command": compile_command,
                     "source": b.identity(SOURCE), "object": str(out / "stable-test.obj")}],
        "links": {"cuda": {"command": command, "image": str(image), "inputs": selected}},
        "frozen": list({x["path"]: x for x in frozen}.values()), "cached_inputs": cached,
        "owner_replacements": owner_changes,
        "test_object": "Base131 has no stable_silu_test object; append exactly one fresh test object after eight existing owner replacements.",
        "native_TUs": 0, "host_TUs": 1, "SDK_build": False, "CMake_run": False, "GPU_run": False,
    }
    target = out / "plan.json"
    c.save(target, plan)
    check(plan)
    print("PLAN", target, flush=True)
    if not args.build:
        return
    (out / "tmp").mkdir()
    env, _ = b.environment(command, [row["path"] for row in cached], out)
    c.execute("stable-test-compile", compile_command, env, out)
    check(plan)
    c.save(out / "stable-test-identity.json", {"command": compile_command,
           "source": plan["compile"][0]["source"], "object": b.identity(out / "stable-test.obj")})
    c.execute("cuda-tests-link", command, env, out)
    check(plan)
    c.save(out / "cuda-link-plan.json", {"command": command, "inputs": [b.identity(x) for x in selected]})
    c.save(out / "cuda-image.json", b.identity(image))
    c.save(out / "summary.json", {"passed": True, "host_TUs": 1, "native_TUs": 0,
           "SDK_build": False, "GPU_run": False, "link_inputs": len(selected),
           "owner_replacements": len(owner_changes), "fresh_test_object_count": 1})
    print("BUILD_COMPLETE", target, flush=True)


if __name__ == "__main__":
    main()
