"""Offline warm-family inventory of retained pre-dual Hyle1028/peer558 traces.

Writes only residual-review.json. No model, build, profiler or device execution.
Duration shares use each trace's own kernel-duration sum, never cross-run deltas.
"""
from pathlib import Path
import collections
import importlib.util
import statistics
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
spec = importlib.util.spec_from_file_location('retained_residual_physical',
    ARCH / 'cuda-stable-silu/profile-analysis-stable.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def family(name):
    if 'internal::gemvx' in name or 'mul_mat_vec_f<' in name:
        return 'projection'
    if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name or 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name:
        return 'BF16_F32_cast'
    if 'cpy_scalar_contiguous<int, float>' in name:
        return 'int32_F32_cast'
    if 'cpy_' in name or 'convert_' in name:
        return 'other_copy_kernel'
    if 'hyle_bf16_l2_core' in name:
        return 'GDN_L2_core'
    if 'gated_delta_net' in name:
        return 'GDN_recurrence'
    if 'rms_norm' in name:
        return 'RMSNorm'
    if 'ssm_conv' in name:
        return 'SSM_convolution'
    if 'flashinfer' in name or 'flash_attn' in name:
        return 'attention_and_merge'
    if 'k_bin_bcast<&op_repeat' in name:
        return 'repeat'
    if 'k_bin_bcast<&op_' in name:
        return 'BF16_binary' if ', __nv_bfloat16' in name else 'F32_binary'
    if 'unary_gated_op_kernel' in name:
        return 'gated_activation'
    if 'unary_op_kernel<&op_cos' in name or 'unary_op_kernel<&op_sin' in name or 'rope_multi' in name:
        return 'rotary_or_trigonometric'
    if 'unary_op_kernel' in name or 'act_kernel<' in name or 'softplus_kernel' in name:
        return 'scalar_activation'
    if 'concat_' in name:
        return 'concat_layout'
    if 'single_update<' in name or 'k_set_rows<' in name:
        return 'cache_update'
    if 'k_get_rows' in name or 'GatherOutput<' in name:
        return 'gather'
    if 'scale_f32' in name:
        return 'scale'
    if 'collectives' in name or 'argmax_f32' in name or 'pad_f32' in name:
        return 'token_selection_and_padding'
    raise ValueError('Unclassified retained kernel: ' + name)


def compact_stats(values):
    values = list(values)
    return {'min': min(values), 'median': statistics.median(values), 'max': max(values)}


def count_if(kernels, text):
    count = sum(text in k['name'] for k in kernels)
    assert count % 25 == 0
    return count // 25


def review(stem, expected):
    data = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'))
    phases = a.phases(data)
    assert phases['valid'] and data['receipt']['csv_sqlite_per_symbol_counts_equal']
    assert not data['receipt']['graph_api_failures']
    endpoints = [p['token_D2H_end_ns'] for p in phases['phases']]
    bins = [[k for k in data['kernels'] if endpoints[i - 1] < k['start'] <= endpoints[i]]
            for i in range(7, 32)]
    assert all(len(kernels) == expected for kernels in bins)
    kernels = [k for rows in bins for k in rows]
    total_ns = sum(k['end'] - k['start'] for k in kernels)
    names = {family(k['name']) for k in kernels}
    groups = []
    for key in names:
        selected = [k for k in kernels if family(k['name']) == key]
        counts = [sum(family(k['name']) == key for k in rows) for rows in bins]
        assert len(set(counts)) == 1
        duration_ns = sum(k['end'] - k['start'] for k in selected)
        groups.append({'family': key, 'kernels_per_step': counts[0],
            'duration_share_percent_of_own_kernel_sum': round(100 * duration_ns / total_ns, 4),
            'mean_profiled_kernel_duration_us_per_step': round(duration_ns / 25000, 4)})
    groups.sort(key=lambda r: -r['duration_share_percent_of_own_kernel_sum'])
    launches = [[r for r in data['launches'] if endpoints[i - 1] < r['start'] <= endpoints[i]] for i in range(7, 32)]
    return {'sqlite': data['receipt']['sqlite'], 'official_csv': data['receipt']['official_csv'],
        'csv_sqlite_per_symbol_counts_equal': True, 'graph_api_failures': [],
        'trace_warnings': [r['text'] for r in data['receipt']['warnings']],
        'warm_steps': 'decode7..31 inclusive, 25 bins ending at32 distinct4B token D2H endpoints',
        'physical_kernels_per_step': expected, 'unique_warm_physical_symbols': len({k['name'] for k in kernels}),
        'every_reported_family_count_is_identical_in_all25_warm_bins': True,
        'own_kernel_duration_sum_us_per_step': compact_stats(sum(k['end'] - k['start'] for k in rows) / 1000 for rows in bins),
        'families': groups,
        'GraphLaunch_API_count_per_step': compact_stats(len(rows) for rows in launches),
        'GraphLaunch_host_API_duration_sum_us_per_step': compact_stats(sum(r['end'] - r['start'] for r in rows) / 1000 for rows in launches),
        'subcounts_per_step': {
            'BF16_to_F32': count_if(kernels, 'cpy_scalar_contiguous<__nv_bfloat16, float>'),
            'F32_to_BF16': count_if(kernels, 'cpy_scalar_contiguous<float, __nv_bfloat16>'),
            'int32_to_F32': count_if(kernels, 'cpy_scalar_contiguous<int, float>'),
            'transpose_copy_F32': count_if(kernels, 'cpy_scalar_transpose<float>'),
            'F32_multiply': count_if(kernels, 'k_bin_bcast<&op_mul, float'),
            'F32_add': count_if(kernels, 'k_bin_bcast<&op_add, float'),
            'F32_subtract': count_if(kernels, 'k_bin_bcast<&op_sub, float'),
            'BF16_add': count_if(kernels, 'k_bin_bcast<&op_add, __nv_bfloat16'),
            'BF16_multiply': count_if(kernels, 'k_bin_bcast<&op_mul, __nv_bfloat16'),
            'repeat_F32': count_if(kernels, 'k_bin_bcast<&op_repeat, float'),
            'stable_BF16_SiLU_Mul': count_if(kernels, 'unary_gated_op_kernel<&op_hyle_stable_silu, __nv_bfloat16'),
            'stable_F32_SiLU_Mul': count_if(kernels, 'unary_gated_op_kernel<&op_hyle_stable_silu, float'),
            'peer_fused_projection_template': sum('mul_mat_vec_f<' in k['name'] and
                '(int)256, (bool)1, (bool)0>' in k['name'] for k in kernels) // 25 if expected == 558 else 0}}


def main():
    hyle = review(ARCH / 'cuda-rms-candidate-frontier/profile/qwen-rms-frontier-trace', 1028)
    peer = review(ARCH / 'cuda-gdn-l2-fusion/peer-profile/peer-trace', 558)
    result = {'schema': 'hyle.dual_projection.residual_review.v1',
        'scope': 'Existing pre-dual RMS-frontier1028 and fresh-peer558 traces only; not a profile of the new dual-projection image.',
        'script': a.identity(Path(__file__)), 'analysis_helper': a.identity(ARCH / 'cuda-stable-silu/profile-analysis-stable.py'),
        'hyle': hyle, 'peer': peer,
        'next_batch_observations': [
            'Within Hyle,187 projection kernels dominate own summed warm kernel duration; extra pointwise/conversion launch count is substantial but has a small fraction of that same kernel sum.',
            'Hyle still has223 BF16/F32 casts,12 integer-to-F32 casts,48 repeat kernels and18 transpose-copy kernels per warm step. Their individual logical roles cannot be proven from physical symbols alone.',
            'Hyle48 BF16 add kernels are consistent with two residual adds per24layers. Prior source-order/grid checks infer peer24down+6attention-output fused residuals, leaving18linear-output residuals. No logical-node NVTX proves exact add-to-projection mapping.',
            'F32 binary138 (multiply96/add30/subtract12), BF16 binary54 (add48/multiply6), scalar activations60 and gated activations42 provide generic chain-fusion candidates. Preserve public BF16 rounding, views, extra readers and dynamic input identities.',
            'Hyle36 L2 carriers,79 RMS kernels,18 convolution kernels,18 GDN recurrence kernels and12 attention/merge kernels are already present; raw kernel-count differences against peer reflect different mathematics and lowering.',
            'GraphLaunch is7 per Hyle step and1 per peer step. These are host API calls, not GPU kernels; their CPU intervals do not measure all hot prepare/bind work and do not establish a removable control cost.'],
        'limits': [
            'All duration shares normalize each acquisition independently by its own summed kernel durations; no cross-run time subtraction or end-to-end speedup estimate is made.',
            'Separate profiler acquisitions have frequency/system/instrumentation effects; Hyle/peer precision, activation, layout, attention and sampling contracts differ.',
            'Summed kernel durations are not wall time or GPU interval union when kernels overlap; host/API gaps, copies, memsets and wait are outside these shares.',
            'Physical symbols lack logical-node NVTX. Counts identify kernel families, not specific model roles or exact fusion legality.',
            'Only retained warm decode bins are analyzed; prefill includes cold preparation and is outside this report.',
            'The new dual-projection implementation needs its own root-run profile before any hit/count/performance claim.'],
        'product_edits': False, 'builds': 0, 'GPU_runs': 0, 'quality_acceptance': False, 'throughput_claim': False}
    a.save(STAGE / 'residual-review.json', result)
    print('OFFLINE_RESIDUAL_REVIEW', STAGE / 'residual-review.json')


if __name__ == '__main__':
    main()
