"""Remove one duplicate resource owner from the first link attempt; compile nothing."""
from pathlib import Path
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('dual_relink_build',STAGE/'build_current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);c=b.c

def main():
    prior=STAGE/'checks/20261019T084721';plan=c.read(prior/'plan.json');b.check(plan)
    out=STAGE/'checks'/('relink-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'));out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    original_resource=b.ARCH/'native-ragged-graph/validation/windows/src--mem--resource.obj'
    compiled=[b.b.identity(item['object']) for item in plan['compile']]
    links={}
    for name,link in plan['links'].items():
        image=out/(name+'.exe')
        if sum(c.key(x)==c.key(original_resource) for x in link['command'])!=1:raise ValueError('Resource owner not unique')
        command=[x for x in link['command'] if c.key(x)!=c.key(original_resource) and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        if len(b.inputs(command))!=124:raise ValueError('Expected124unique source owners')
        links[name]={'command':command,'image':str(image),'inputs':b.inputs(command)}
    plan=dict(plan,compile=[],links=links,frozen=plan['frozen']+[b.b.identity(Path(__file__))],
        cached_inputs=plan['cached_inputs']+compiled,prior_build=b.b.identity(prior/'plan.json'),
        correction='Existing Qwen resource owner was already current; drop its duplicate rather than add a125th input',compile_commands=0)
    target=out/'plan.json';c.save(target,plan);b.check(plan);print('PLAN',target,flush=True)
    env,_=b.b.environment(links['qwen']['command'],[r['path'] for r in plan['cached_inputs']],out)
    for name,link in links.items():
        c.execute(name+'-link',link['command'],env,out);b.check(plan)
        c.save(out/(name+'-link-plan.json'),{'command':link['command'],'inputs':[b.b.identity(x) for x in b.inputs(link['command'])]})
        c.save(out/(name+'-image.json'),b.b.identity(link['image']))
    c.save(out/'summary.json',{'passed':True,'native_TUs':0,'host_TUs':0,'SDK_build':False,'reused_new_native_TUs':3,'reused_new_host_TUs':2,'GPU_run':False})
    print('BUILD_COMPLETE',target,flush=True)

if __name__=='__main__':main()
