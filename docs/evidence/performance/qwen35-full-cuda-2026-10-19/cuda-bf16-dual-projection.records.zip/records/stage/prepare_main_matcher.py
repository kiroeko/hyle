"""Append only the real four-node BF16 dual projection matcher to current v14."""
from pathlib import Path
import difflib
import hashlib
import json
STAGE=Path(__file__).resolve().parent
SOURCE=STAGE.parent/'cuda-gdn-l2-fusion/native-source/src/ggml-cuda/ggml-cuda.cu'
EXPECTED='876f1f00b285fb9187d23a50b7f3c11d7ff884065897c8ad93ec476e9af4f0c7'

HELPER='''// The three intermediates are private BF16 values. Follow the actual final
// Multiply inputs; native scheduling may put either projection first.
struct ggml_cuda_bf16_dual_projection_match {
    const ggml_tensor * gate = nullptr;
    const ggml_tensor * up = nullptr;
    const ggml_tensor * silu = nullptr;
    ggml_tensor * dst = nullptr;
};

static bool ggml_cuda_match_bf16_dual_projection(const ggml_cgraph * graph, int begin,
        int device, ggml_cuda_bf16_dual_projection_match & match) {
    match = {};
    if (begin < 0 || begin >= graph->n_nodes || graph->n_nodes - begin < 4) {
        return false;
    }
    const ggml_tensor * silu = nullptr;
    int projections = 0;
    for (int j = 0; j < 3; ++j) {
        const ggml_tensor * value = graph->nodes[begin + j];
        if (value->op == GGML_OP_MUL_MAT) {
            ++projections;
        } else if (value->op == GGML_OP_UNARY && !silu && ggml_hyle_stable_silu(value)) {
            silu = value;
        } else {
            return false;
        }
    }
    ggml_tensor * dst = graph->nodes[begin + 3];
    if (projections != 2 || !silu || dst->op != GGML_OP_MUL ||
            (dst->src[0] == silu) == (dst->src[1] == silu)) {
        return false;
    }
    const ggml_tensor * gate = silu->src[0];
    const ggml_tensor * up = dst->src[dst->src[0] == silu ? 1 : 0];
    bool gate_inside = false, up_inside = false;
    for (int j = 0; j < 3; ++j) {
        gate_inside |= gate == graph->nodes[begin + j];
        up_inside |= up == graph->nodes[begin + j];
    }
    // Do not erase copies, CONT or views to manufacture logical identity.
    if (!gate_inside || !up_inside || gate == up ||
            !ggml_cuda_private_fusion_closed(graph, begin, 4) ||
            !ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate, up, silu, dst, device)) {
        return false;
    }
    match = {gate, up, silu, dst};
    return true;
}

'''

DISPATCH='''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    if (node->op == GGML_OP_MUL_MAT && node->type == GGML_TYPE_BF16) {
        ggml_cuda_bf16_dual_projection_match match;
        if (ggml_cuda_match_bf16_dual_projection(cgraph, i, cuda_ctx->device, match)) {
            ggml_cuda_op_bf16_dual_matvec_silu_mul(*cuda_ctx, match.gate, match.up, match.silu, match.dst);
            return 3;
        }
    }
#endif

'''

def main():
    before=SOURCE.read_bytes()
    if hashlib.sha256(before).hexdigest()!=EXPECTED:raise ValueError('Current native main drift')
    source=before.decode();source=source.replace('ggml_cuda_bf16_l2_closed','ggml_cuda_private_fusion_closed')
    anchor='static bool ggml_cuda_match_bf16_l2_core('
    if source.count(anchor)!=1:raise ValueError('Helper anchor differs')
    source=source.replace(anchor,HELPER+anchor,1)
    anchor='    // Keep the native F32 program as the fallback. This complete cast chain\n'
    if source.count(anchor)!=1:raise ValueError('Dispatch anchor differs')
    source=source.replace(anchor,DISPATCH+anchor,1)
    target=STAGE/'native-source/src/ggml-cuda/ggml-cuda.cu';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.encode())
    (STAGE/'ggml-cuda.before.cu').write_bytes(before)
    (STAGE/'main-matcher.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),source.splitlines(True),fromfile='a/src/ggml-cuda/ggml-cuda.cu',tofile='b/src/ggml-cuda/ggml-cuda.cu')),encoding='utf-8')
    (STAGE/'main-matcher.json').write_text(json.dumps({'before_sha256':EXPECTED,'after_sha256':hashlib.sha256(source.encode()).hexdigest(),
        'scope':'Scratch only; direct4nativeBF16 nodes; shared private closure guard, real edges/ranges/device; no copy/view stripping',
        'not_built':True},indent=2)+'\n',encoding='utf-8')
    print(target)

if __name__=='__main__':main()
