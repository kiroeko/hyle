"""One official CUDA trace, then offline physical-count analysis."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    build = load('dual_profile_build', STAGE / 'build_current.py')
    b, c = build.b, build.c
    plan_path = Path(sys.argv[1]).resolve()
    proof = Path(sys.argv[2]).resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if not proof.is_file():
        raise ValueError('Completed numerical diagnostics are required')
    image = Path(plan['links']['qwen']['image'])
    if b.identity(image) != c.read(plan_path.parent / 'qwen-image.json'):
        raise ValueError('Current image drift')
    out = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else STAGE / 'profile'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    env, _ = b.environment(plan['links']['qwen']['command'],
        [row['path'] for row in plan['cached_inputs']], out)
    original = c.read(STAGE.parent / 'cuda-reshape-reuse/profile-qwen.command.json')['command']
    index = original.index('--inputs') - 1
    stem = out / 'qwen-dual-projection-trace'
    command = [('--output=' + str(stem)) if item.startswith('--output=') else item
        for item in original[:index]] + [str(image)] + original[index + 1:]
    c.save(out / 'inputs.json', {'image': b.identity(image), 'command': command,
        'numerical_diagnostics': b.identity(proof), 'profiler_runs': 1,
        'quality_acceptance': False, 'throughput_claim': False})
    c.execute('profile', command, env, out)
    c.execute('export', [original[0], 'export', '--type=sqlite', '--output=' + str(stem) + '.sqlite',
        str(stem) + '.nsys-rep'], env, out)
    c.execute('stats', [original[0], 'stats', '--report=cuda_gpu_kern_sum,cuda_api_sum',
        '--format=csv', '--output=' + str(stem), str(stem) + '.sqlite'], env, out)
    a = load('dual_physical_count_helpers', STAGE.parent / 'cuda-stable-silu/profile-analysis-stable.py')
    current = a.load(Path(str(stem) + '.sqlite'), Path(str(stem) + '_cuda_gpu_kern_sum.csv'))
    before_stem = STAGE.parent / 'cuda-rms-candidate-frontier/profile/qwen-rms-frontier-trace'
    before = a.load(Path(str(before_stem) + '.sqlite'), Path(str(before_stem) + '_cuda_gpu_kern_sum.csv'))
    phases, previous = a.phases(current), a.phases(before)
    checks = {'valid_phase_binning': phases['valid'],
        'official_csv_sqlite_equal': current['receipt']['csv_sqlite_per_symbol_counts_equal'],
        'no_graph_api_errors': not current['receipt']['graph_api_failures']}
    if not all(checks.values()):
        raise ValueError('Physical trace could not establish valid counts')
    counts = []
    for index, phase in enumerate(phases['phases']):
        low = phases['phases'][index - 1]['token_D2H_end_ns'] if index else 0
        high = phase['token_D2H_end_ns']
        hits = [k for k in current['kernels'] if low < k['start'] <= high
            and 'hyle_bf16_dual_matvec_silu_epilogue' in k['name']]
        counts.append({'phase': phase['phase'], 'dual_projection_kernels': len(hits)})
    result = {'checks': checks, 'receipt': current['receipt'], 'phases': phases,
        'previous_phases': previous, 'comparison': a.compare(current, before, phases, previous),
        'actual_dual_projection_counts': counts, 'throughput_claim': False,
        'quality_acceptance': False,
        'limits': ['Previous trace establishes counts, not matched duration differences.',
            'Current capture of native fusion is observed independently of cold provider selection.',
            'No total memory peak is inferred from kernel counts or reported workspace.']}
    c.save(out / 'analysis.json', result)
    print(json.dumps({'checks': checks, 'warm_medians': {k: v['median'] for k, v in phases['warm_decode7_31'].items() if k != 'categories'},
        'dual_counts_by_phase': counts}, indent=2), flush=True)


if __name__ == '__main__':
    main()
