from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
UPSTREAM=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MAIN='src/ggml-cuda/ggml-cuda.cu'
def sha(data):return hashlib.sha256(data).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
def apply(data,edits):
 for edit in edits:
  old,new=edit['before'].encode(),edit['after'].encode()
  if data.count(old)!=1:raise ValueError('Nonunique edit context '+edit['before'][:80])
  data=data.replace(old,new,1)
 return data

def main():
 helper=load('root_main_matcher',STAGE/'prepare_main_matcher.py')
 before=(STAGE/'ggml-cuda.before.cu').read_bytes()
 after=(STAGE/'native-source'/MAIN).read_bytes()
 if sha(before)!='876f1f00b285fb9187d23a50b7f3c11d7ff884065897c8ad93ec476e9af4f0c7':raise ValueError('v14 main drift')
 edits=[
  {'before':'static bool ggml_cuda_bf16_l2_closed(', 'after':'static bool ggml_cuda_private_fusion_closed('},
  {'before':'if (!ggml_cuda_bf16_l2_closed(graph, begin, next - begin) ||','after':'if (!ggml_cuda_private_fusion_closed(graph, begin, next - begin) ||'},
  {'before':'static bool ggml_cuda_match_bf16_l2_core(','after':helper.HELPER+'static bool ggml_cuda_match_bf16_l2_core('},
  {'before':'    // Keep the native F32 program as the fallback. This complete cast chain\n','after':helper.DISPATCH+'    // Keep the native F32 program as the fallback. This complete cast chain\n'}]
 if apply(before,edits)!=after:raise ValueError('Exact main delta does not match root candidate')
 save(STAGE/'main-delta.json',{'path':MAIN,'canonical_before_sha256':sha(before),'canonical_after_sha256':sha(after),'edits':edits})
 manifest=read(STAGE/'patches.native-draft.json')
 entry=next(f for f in manifest['files'] if f['path']==MAIN)
 original=(UPSTREAM/MAIN).read_bytes().replace(b'\r\n',b'\n')
 if sha(original)!=entry['before_sha256']:raise ValueError('Original native main identity differs')
 previous=apply(original,entry['edits'])
 if sha(previous)!=entry['after_sha256']:raise ValueError('Prior CUDA-only result differs')
 entry['edits'].extend(edits)
 entry['after_sha256']=sha(apply(original,entry['edits']))
 if len({f['path'] for f in manifest['files']})!=len(manifest['files']):raise ValueError('Duplicate file key')
 if any(f['path']=='src/ggml-cuda.cu' for f in manifest['files']):raise ValueError('Flattened main key')
 save(STAGE/'patches.combined-draft.json',manifest)
 runtime=ROOT/'src/compute_ggml_runtime'
 load('mixed',runtime/'prepare_mixed_cpu_manifest.py').derive(UPSTREAM,ROOT/'third_party/ggml_runtime/patches.json',ROOT/'third_party/ggml_cpu_runtime/patches.json',STAGE/'mixed-main-draft.json')
 load('cuda',runtime/'prepare_cuda_iq1_manifest.py').derive(UPSTREAM,STAGE/'mixed-main-draft.json',STAGE/'patches.combined-draft.json',ROOT/'third_party/ggml_cuda_runtime/iq1-patches.json',STAGE/'combined-main-draft.json')
 rows=read(STAGE/'combined-main-draft.json')['files']
 expected={MAIN,'src/ggml-cuda/mmvf.cu','src/ggml-cuda/mmvf.cuh','src/ggml-cuda/unary.cu'}
 canonical={}
 for row in rows:
  data=(UPSTREAM/row['path']).read_bytes().replace(b'\r\n',b'\n')
  if sha(data)!=row['before_sha256']:raise ValueError('Mixed original differs '+row['path'])
  data=apply(data,row['edits'])
  if sha(data)!=row['after_sha256']:raise ValueError('Mixed output differs '+row['path'])
  if row['path'] in expected:
   if data!=(STAGE/'native-source'/row['path']).read_bytes():raise ValueError('Canonical overlay differs '+row['path'])
   canonical[row['path']]=sha(data)
 if set(canonical)!=expected:raise ValueError('Missing canonical source')
 if (ROOT/'third_party/ggml_cuda_runtime/patches.json').read_bytes()!=(STAGE/'patches.before.json').read_bytes():raise ValueError('Product manifest was changed concurrently')
 print(json.dumps({'full_manifest_files_replayed':len(rows),'canonical_sources':canonical,'CUDA_only_main_after_sha256':entry['after_sha256'],'no_product_mutation':True},indent=2))
if __name__=='__main__':main()
