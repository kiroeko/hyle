"""Materialize only the scratch test overlay; never edits product or builds."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
RELATIVE = Path("tests/graph_route_cuda/stable_silu_test.cc")


def snapshot(path):
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    original = ROOT / RELATIVE
    before = original.read_bytes()
    text = before.decode().replace("\r\n", "\n")
    text = text.replace("#include <array>\n", "#include <algorithm>\n#include <array>\n", 1)
    text = text.replace("#include <type_traits>\n", "#include <random>\n#include <string>\n#include <type_traits>\n", 1)
    text += "\n" + (STAGE / "dual_projection_tests.inc").read_text(encoding="utf-8")
    overlay = STAGE / "overlay" / RELATIVE
    overlay.parent.mkdir(parents=True, exist_ok=True)
    overlay.write_bytes(text.encode())
    before_path = STAGE / "stable-silu-tests.before.cc"
    before_path.write_bytes(before)
    difference = "".join(difflib.unified_diff(
        before.decode().replace("\r\n", "\n").splitlines(keepends=True),
        text.splitlines(keepends=True), fromfile="a/" + RELATIVE.as_posix(),
        tofile="b/" + RELATIVE.as_posix()))
    diff = STAGE / "tests-change.diff"
    diff.write_text(difference, encoding="utf-8", newline="\n")
    plan = {
        "product_edited": False, "CMake_edited": False, "new_TUs": 0,
        "target": "existing graph_route_cuda test target; only existing stable_silu_test.cc TU changes",
        "tests": [
            "GgmlCudaDualProjection.ExactDotsPreserveGateUpAndSiluRoundingAcrossSlots",
            "GgmlCudaDualProjection.EscapedValuesAndUnsupportedDomainsKeepOriginalChain",
            "GgmlCudaDualProjection.LongDotsMeetIndependentReductionBudget",
        ],
        "positive": "BF16 x[1,128], physical weights[33,128] via public transpose Views; both public topologies; impl4/policy3 and exact four math NodeIds. Two slots, two rounds, new input/weight/output addresses with old allocations held, commands+RequireCapture; real GraphOutput busy gate while other slot replays.",
        "exact_oracle": "FP64 dyadic products/sums, every prefix checked exactly F32. BF16 G/U RNE then independent isolated old GPU ordinary SiLU and Mul. Separate GPU F32 SiLU/Cast/Mul variants deleting G, U or A rounding must each differ in final BF16 output. No CPU exp used by tests.",
        "dyadic_bound": "K128 non-special operands have denominator at most2^7 and2^9; product numerator and any partial-sum absolute bound fit24bits. Special G halfway dots and -80/-90/-100 tail columns are exact F32 too.",
        "fallbacks": "One small loop: G/U/A all published; extra G reader; different x ValueIds bound to same actual buffer; K127; ordinary dense[K,N] RHS. No impl4 and both original default cuBLASLt projection leaves; published/extra outputs exact against staged oracle. No global ban on generic regions/impl3.",
        "random": "K2048,N33; two deterministic seeds, FP64 sum and absolute-product sum; declared gamma(K+64), BF16 ULP and SiLU derivative/float-function budget propagated to final output. Maximum absolute/nonzero-reference-relative/BF16-ULP/budget-fraction recorded. Does not observe hidden fused G/U and does not claim random bit equality with cuBLASLt.",
        "not_claimed": ["selected region is not physical kernel-hit evidence", "random error budget is not an exact intermediate rounding proof", "no whole-model bit-equality or performance conclusion", "no overlapping-buffer native guard coverage beyond existing tests"],
        "read_only_review": "Independent API/layout/owner lifetime/route review found no blocker; actual CUDA heuristic/capture and GPU numeric results remain unrun.",
        "build_executed": False, "GPU_executed": False,
    }
    (STAGE / "tests-plan.json").write_text(json.dumps(plan, indent=2) + "\n", encoding="utf-8")
    freeze = {"product_before": snapshot(original), "before_copy": snapshot(before_path),
              "overlay": snapshot(overlay), "diff": snapshot(diff),
              "fragment": snapshot(STAGE / "dual_projection_tests.inc"),
              "materializer": snapshot(Path(__file__).resolve()),
              "plan": snapshot(STAGE / "tests-plan.json"),
              "provider_overlay": snapshot(ROOT / ".scratch/architecture-refactor-2026-10-18/cuda-ffn-next-design/overlay/src/graph_provider_ggml_cuda/ggml_cuda_region.cc"),
              "products_modified": [], "build_executed": False, "GPU_executed": False}
    receipt = STAGE / "tests-source-freeze.json"
    receipt.write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"overlay": freeze["overlay"], "receipt": snapshot(receipt)}))


if __name__ == "__main__":
    main()
