"""CPU-only distribution/hidden diagnosis against the new independent Torch tape."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np

PHASES = ["prefill"] + [f"decode{i}" for i in range(1, 32)]


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def vector(row, suffix):
    if identity(row["path"]) != row:
        raise ValueError("Vector drift: " + row["path"])
    path = Path(row["path"])
    if suffix == "f32":
        value = np.fromfile(path, dtype="<f4")
        expected = 248320
    else:
        value = (np.fromfile(path, dtype="<u2").astype(np.uint32) << 16).view(np.float32)
        expected = 2048
    if value.size != expected or not np.isfinite(value).all():
        raise ValueError("Vector extent/nonfinite values: " + str(path))
    return value.astype(np.float64)


def hidden_metric(actual, expected):
    error = actual - expected
    a, e = np.linalg.norm(actual), np.linalg.norm(expected)
    return {"relative_l2": float(np.linalg.norm(error) / e) if e else (0.0 if not a else None),
            "max_abs": float(np.abs(error).max()),
            "cosine": float(actual @ expected / a / e) if a and e else None}


def log_probs(logits):
    centered = logits - logits.max()
    return centered - np.log(np.exp(centered).sum())


def logits_metric(actual, expected, target):
    la, le = log_probs(actual), log_probs(expected)
    top_a, top_e = np.argsort(-actual, kind="stable")[:10], np.argsort(-expected, kind="stable")[:10]
    result = {**hidden_metric(actual, expected),
        "kl_expected_to_actual": float(np.sum(np.exp(le) * (le - la))),
        "kl_actual_to_expected": float(np.sum(np.exp(la) * (la - le))),
        "top1_actual": int(top_a[0]), "top1_expected": int(top_e[0]),
        "reference_top1_margin": float(expected[top_e[0]] - expected[top_e[1]]),
        "top5_overlap": len(set(top_a[:5]) & set(top_e[:5])),
        "top10_overlap": len(set(top_a) & set(top_e)), "target_id": target,
        "target_nll_actual": None, "target_nll_expected": None, "target_nll_delta": None}
    if target is not None:
        result.update(target_nll_actual=float(-la[target]), target_nll_expected=float(-le[target]),
                      target_nll_delta=float(le[target] - la[target]))
    return result


def summarize(rows, field):
    keys = ("relative_l2", "max_abs", "cosine") if field == "hidden" else (
        "relative_l2", "max_abs", "cosine", "kl_expected_to_actual", "kl_actual_to_expected",
        "top5_overlap", "top10_overlap", "target_nll_actual", "target_nll_expected", "target_nll_delta")
    result = {}
    for key in keys:
        values = [row[field][key] for row in rows if row[field][key] is not None]
        if values:
            result[key] = {"count": len(values), "mean": float(np.mean(values)), "min": float(np.min(values)),
                           "p95": float(np.percentile(values, 95)), "max": float(np.max(values))}
    if field == "logits":
        result["top1_agreements"] = sum(row[field]["top1_actual"] == row[field]["top1_expected"] for row in rows)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--numerics", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError("Refusing to overwrite numeric diagnosis")
    reference, numerical = read(args.reference / "summary.json"), read(args.numerics)
    if reference["status"] != "completed_diagnosis_not_acceptance" or reference["candidate_values_used"] or not reference["caches_independent"]:
        raise ValueError("Independent reference is incomplete or not independent")
    fixed, targets = reference["fixed"], reference["targets"]
    if numerical.get("schema") != "hyle.qwen.dual_numerics.v1" or not numerical.get("diagnostic_complete"):
        raise ValueError("Need completed two-arm Hyle numerical report")
    if identity(numerical["inputs"]["prompt_ids"]["path"]) != numerical["inputs"]["prompt_ids"]:
        raise ValueError("Hyle prompt tape drift")
    if list(map(int, Path(numerical["inputs"]["prompt_ids"]["path"]).read_text().split())) != fixed["prompt_ids"]:
        raise ValueError("Hyle prompt differs from independent reference")
    arms = {}
    for arm in ("baseline", "current"):
        data = numerical["arms"][arm]
        if (data["source_id"] != reference["source_id"] or data["decode_input_ids"] != fixed["decode_input_ids"] or
                not data["fixed_decode"] or data["visible_tokens"] != 159 or data["text_tensors"] != 320):
            raise ValueError("Hyle model/fixed-input journey differs: " + arm)
        paths = {Path(row["path"]).as_posix(): row["actual"] for row in data["vectors"]}
        expected = {phase + "/" + name for phase in PHASES for name in ("hidden.bf16", "logits.f32")}
        if set(paths) != expected:
            raise ValueError("Expected64 Hyle observations: " + arm)
        arms[arm] = paths
    results = {}
    for variant in ("eager-reference", "f32-rope-reference"):
        steps = read(args.reference / variant / "steps.json")
        input_sequence = [fixed["prompt_ids"]] + [[token] for token in fixed["decode_input_ids"]]
        if ([row["name"] for row in steps] != PHASES or [row["target_id"] for row in steps] != targets or
                [row["input_ids"] for row in steps] != input_sequence):
            raise ValueError("Reference phase/target sequence differs")
        groups = {arm: [] for arm in arms}
        for i, phase in enumerate(PHASES):
            ref_hidden, ref_logits = vector(steps[i]["hidden"], "bf16"), vector(steps[i]["logits"], "f32")
            for arm, paths in arms.items():
                groups[arm].append({"phase": phase, "visible_tokens": 128 + i,
                    "hidden": hidden_metric(vector(paths[phase + "/hidden.bf16"], "bf16"), ref_hidden),
                    "logits": logits_metric(vector(paths[phase + "/logits.f32"], "f32"), ref_logits, targets[i])})
        results[variant] = {arm: {"summary": {"hidden": summarize(rows, "hidden"), "logits": summarize(rows, "logits")},
                                         "per_phase": rows} for arm, rows in groups.items()}
    output = {"schema": "hyle.qwen.independent128.comparison.v1", "status": "diagnosis_not_quality_acceptance",
        "reference_summary": identity(args.reference / "summary.json"), "numerical_summary": identity(args.numerics),
        "images": numerical["images"], "fixed_inputs_equal": True, "phases": 32, "vectors_verified_per_hyle_arm": 64,
        "target_policy": reference["target_policy"], "target_nll_observations_per_comparison": sum(t is not None for t in targets),
        "comparisons": results, "quality_accepted": None, "acceptance_thresholds": None,
        "limits": ["Independent Torch reference consumes only canonical weights and fixed input IDs, never Hyle hidden/logits/state.",
                   "Both Hyle arms and both Torch variants feed back their own cache/recurrent state.",
                   "The128prompt/31tape is benchmark-only and not coherent corpus evaluation; target NLL is diagnostic.",
                   "Last phase has no NLL target when the fixed input provides none; no target is invented from candidate argmax.",
                   "Top1/32-ID agreement alone does not accept model quality; KL/relative-L2/NLL/top-k here also have no predefined quality acceptance budget.",
                   "F32-RoPE is a retained reference-only numerical variant, not a product change.",
                   "No performance or memory conclusion follows from this diagnostic reference run."]}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print("OFFLINE_DIAGNOSIS", args.out, flush=True)


if __name__ == "__main__":
    main()
