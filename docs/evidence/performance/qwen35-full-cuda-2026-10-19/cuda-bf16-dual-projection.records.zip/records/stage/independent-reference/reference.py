"""Prepare or explicitly run the existing independent Torch reference on 128+31."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import sys
import time
import traceback
import types

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                  HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false")
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
ARCH = STAGE.parents[1]
OLD = ARCH / "qwen-fixed-decode"
ORIGINAL = ROOT / ".scratch/inference-execution-refactor-2026-10-18/qwen35-text/reference/reference.json"
FIXED = ARCH / "qwen-gpu-comparison/128-prefill/fixed-inputs.json"
MANIFEST = FIXED.parent / "inputs/weights.tsv"
INVENTORY = ROOT / "docs/implementation/tasks/compute/qwen35-2b-local-input.json"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def identity(path):
    path = Path(path)
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": hasher.hexdigest()}


def prepare(args):
    fixed, inventory, receipt = read(args.fixed), read(INVENTORY), read(ORIGINAL)
    lines = args.manifest.read_text().splitlines()
    if lines[0] != "HYLE_QWEN35_TEXT_V1" or lines[2] != inventory["artifact_identity_sha256"] or lines[2] != receipt["source_id"] or len(lines[3:]) != 320:
        raise ValueError("Weight artifact manifest differs")
    if len(fixed["prompt_ids"]) != 128 or len(fixed["decode_input_ids"]) != 31:
        raise ValueError("Expected128prompt+31fixeddecode")
    targets = fixed.get("target_ids", [])
    if targets and len(targets) != 32:
        raise ValueError("Provided targets must contain32 IDs")
    target_policy = "provided fixed target_ids" if targets else "next fixed decode input; final phase has no target"
    targets = targets or fixed["decode_input_ids"] + [None]
    if any(not 0 <= token < 248320 for token in fixed["prompt_ids"] + fixed["decode_input_ids"] + [t for t in targets if t is not None]):
        raise ValueError("Token outside original vocabulary")
    shard = Path(lines[1]).resolve()
    model_row, = [row for row in inventory["files"] if row["path"] == shard.name]
    if shard.stat().st_size != model_row["size_bytes"]:
        raise ValueError("Shard size differs; artifact SHA is not shard SHA")
    old_environment = read(OLD / "reference-environment.json")
    paths = [Path(__file__), args.fixed, args.manifest, INVENTORY, ORIGINAL,
             OLD / "reference.py", OLD / "reference-environment.json",
             ROOT / "tools/qwen35_text/reference.py", Path(receipt["model_source"]), shard.parent / "config.json",
             args.manifest.parent / "prompt.ids", args.fixed.parent / "decode.ids"]
    frozen = [identity(path) for path in paths]
    if identity(receipt["model_source"])["sha256"] != receipt["model_source_sha256"] or identity(ROOT / "tools/qwen35_text/reference.py")["sha256"] != receipt["reference_sha256"]:
        raise ValueError("Independent model/formula source drift")
    if list(map(int, (args.manifest.parent / "prompt.ids").read_text().split())) != fixed["prompt_ids"] or list(map(int, (args.fixed.parent / "decode.ids").read_text().split())) != fixed["decode_input_ids"]:
        raise ValueError("Fixed JSON differs from Hyle tapes")
    args.out.mkdir(parents=True, exist_ok=False)
    plan = {"schema": "hyle.qwen.independent128.v1", "status": "prepared_not_run",
            "frozen": frozen, "fixed": fixed, "targets": targets, "target_policy": target_policy,
            "source_id": lines[2], "model": {"path": str(shard), "bytes": model_row["size_bytes"], "sha256": model_row["sha256"]},
            "python": identity(sys.executable), "packages": {name: importlib.metadata.version(name) for name in ("torch", "transformers", "safetensors", "numpy")},
            "model_source": identity(receipt["model_source"]),
            "expected_runtime": {"torch": receipt["torch"], "gpu": receipt["gpu"], "cuda": old_environment["cuda"]},
            "variants": ["eager-reference", "f32-rope-reference"], "phases": 32,
            "model_reused_without_copy": True, "model_payload_read_during_prepare": False,
            "old150_payload_guard": "Not repeated: old prompt/tape differ; old reference remains untouched.",
            "numerical_contract": "Installed official transformers eager model plus unchanged prior recurrent-state correction; no Hyle values enter Torch. Same TF32/reduced-reduction flags and existing diagnostic F32-RoPE variant.",
            "limits": ["This fixed tape is marked benchmark_only/not_a_quality_prompt, not a corpus quality test.",
                       "When target_ids are empty only31 fixed-next-input NLL observations exist; last phase NLL is absent.",
                       "Each variant starts an independent empty cache and feeds back only its own state.",
                       "Hyle cap256 and Torch dynamic cache differ in storage; both process the same159 visible IDs.",
                       "RoPE F32 is reference-only diagnosis, not a consumer/model modification or acceptance threshold."]}
    save(args.out / "plan.json", plan)
    print("PREPARED_NO_GPU", args.out / "plan.json", flush=True)


def run(path):
    path = path.resolve()
    plan, out = read(path), path.parent
    if plan["status"] != "prepared_not_run" or (out / "started.json").exists():
        raise ValueError("Refusing overwrite or implicit reference retry")
    for row in plan["frozen"] + [plan["python"]]:
        if identity(row["path"]) != row:
            raise ValueError("Frozen input drift: " + row["path"])
    save(out / "started.json", {"pid": os.getpid(), "started": time.time(), "plan": identity(path)})
    try:
        if identity(plan["model"]["path"]) != plan["model"]:
            raise ValueError("Actual shard SHA differs from per-file inventory")
        import torch
        from safetensors import safe_open
        from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
        from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig
        if torch.__version__ != plan["expected_runtime"]["torch"] or torch.cuda.get_device_name() != plan["expected_runtime"]["gpu"]:
            raise ValueError("Torch/GPU runtime differs from retained reference")
        if identity(impl.__file__) != plan["model_source"] or any(importlib.metadata.version(name) != version for name, version in plan["packages"].items()):
            raise ValueError("Imported model or package versions differ from prepared cache")
        spec = importlib.util.spec_from_file_location("retained_recurrent_reference", ROOT / "tools/qwen35_text/reference.py")
        original = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(original)
        torch.set_num_threads(2); torch.set_num_interop_threads(1)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
        torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
        shard = Path(plan["model"]["path"])
        config = Qwen3_5TextConfig(**read(shard.parent / "config.json")["text_config"])
        config._attn_implementation = "eager"
        with torch.device("meta"):
            model = impl.Qwen3_5ForCausalLM(config)
        model.model.rotary_emb = impl.Qwen3_5TextRotaryEmbedding(config, device="cpu")
        parameters = {}
        with safe_open(shard, framework="pt", device="cpu") as checkpoint:
            for name in checkpoint.keys():
                if name.startswith("model.language_model."):
                    parameters[name.replace("model.language_model.", "model.", 1)] = checkpoint.get_tensor(name)
        if len(parameters) != 320:
            raise ValueError("Expected320original text tensors")
        parameters["lm_head.weight"] = parameters["model.embed_tokens.weight"]
        model.load_state_dict(parameters, strict=True, assign=True)
        model.lm_head.weight = model.model.embed_tokens.weight
        del parameters
        model.eval().to("cuda")
        for layer in model.model.layers:
            if hasattr(layer, "linear_attn"):
                layer.linear_attn.forward = types.MethodType(original.fixed_recurrent_forward, layer.linear_attn)
        hidden = []
        model.model.norm.register_forward_hook(lambda module, inputs, output: hidden.append(output[:, -1:].detach()))
        fixed = plan["fixed"]
        steps = [("prefill", fixed["prompt_ids"])] + [(f"decode{i+1}", [token]) for i, token in enumerate(fixed["decode_input_ids"])]
        def raw(tensor):
            return tensor.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes()
        def journey(mode):
            directory = out / mode
            directory.mkdir(exist_ok=False)
            cache, rows = None, []
            for index, (name, ids) in enumerate(steps):
                with torch.inference_mode():
                    result = model(input_ids=torch.tensor([ids], device="cuda", dtype=torch.long),
                        past_key_values=cache, use_cache=True, logits_to_keep=1)
                cache = result.past_key_values
                logits, last = result.logits[0, -1].float(), hidden.pop()
                phase = directory / name; phase.mkdir()
                (phase / "logits.f32").write_bytes(raw(logits))
                (phase / "hidden.bf16").write_bytes(raw(last))
                target = plan["targets"][index]
                logprobs = torch.log_softmax(logits.double(), dim=-1)
                rows.append({"name": name, "input_ids": ids, "next_id": int(logits.argmax()),
                    "target_id": target, "target_nll": None if target is None else float(-logprobs[target]),
                    "logits": identity(phase / "logits.f32"), "hidden": identity(phase / "hidden.bf16")})
            if len(rows) != 32 or hidden:
                raise ValueError("Reference phase/hook count differs")
            save(directory / "steps.json", rows)
            return rows
        eager = journey("eager-reference")
        old_rotary, old_apply = impl.Qwen3_5TextRotaryEmbedding.forward, impl.apply_rotary_pos_emb
        rotations = []
        def angles(self, x, position_ids):
            return old_rotary(self, x.float(), position_ids)
        def rotate(q, k, cos, sin, unsqueeze_dim=1):
            if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16 or cos.dtype != torch.float32 or sin.dtype != torch.float32 or cos.shape[-1] != 64:
                raise ValueError("Retained RoPE variant dtype/extent differs")
            cos, sin = cos.unsqueeze(unsqueeze_dim), sin.unsqueeze(unsqueeze_dim)
            def one(tensor):
                prefix = tensor[..., :64].float()
                rotated = (prefix * cos + impl.rotate_half(prefix) * sin).to(tensor.dtype)
                return torch.cat((rotated, tensor[..., 64:]), dim=-1)
            rotations.append({"q_shape": list(q.shape), "k_shape": list(k.shape)})
            return one(q), one(k)
        impl.Qwen3_5TextRotaryEmbedding.forward, impl.apply_rotary_pos_emb = angles, rotate
        try:
            variant = journey("f32-rope-reference")
        finally:
            impl.Qwen3_5TextRotaryEmbedding.forward, impl.apply_rotary_pos_emb = old_rotary, old_apply
        if len(rotations) != 192:
            raise ValueError("Expected6fullattention layers times32phases")
        save(out / "summary.json", {"schema": "hyle.qwen.independent128.v1", "status": "completed_diagnosis_not_acceptance",
            "plan": identity(path), "variants": {"eager-reference": len(eager), "f32-rope-reference": len(variant)},
            "torch": torch.__version__, "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(),
            "model_source": identity(impl.__file__), "rotations": len(rotations), "source_id": plan["source_id"],
            "fixed": fixed, "targets": plan["targets"], "target_policy": plan["target_policy"],
            "all_inputs_fixed": True, "caches_independent": True, "candidate_values_used": False,
            "old150_payload_guard_performed": False, "quality_evaluation": False, "performance_measurement": False})
        print("REFERENCE_COMPLETE", out / "summary.json", flush=True)
    except Exception as error:
        save(out / "failure.json", {"error": str(error), "pid": os.getpid(), "finished": time.time()})
        (out / "failure.txt").write_text(traceback.format_exc(), encoding="utf-8")
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    pre = sub.add_parser("prepare")
    pre.add_argument("--fixed", type=Path, default=FIXED)
    pre.add_argument("--manifest", type=Path, default=MANIFEST)
    pre.add_argument("--out", type=Path, required=True)
    actual = sub.add_parser("run")
    actual.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args()
    prepare(args) if args.mode == "prepare" else run(args.plan)


if __name__ == "__main__":
    main()
