"""Execute the frozen independent reference and its offline analysis once."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reference_execution_helpers', STAGE.parent / 'build_current.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
prepared = json.loads((STAGE / 'preparation.json').read_text())
out = STAGE / 'execution'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
env = os.environ.copy()
env.update(OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2', OMP_NUM_THREADS='2',
    TEMP=str(out / 'tmp'), TMP=str(out / 'tmp'))
for name, key in (('reference', 'run_GPU_NOT_EXECUTED'), ('analyze', 'analyze_CPU_after_reference')):
    helper.c.execute(name, prepared['commands'][key], env, out)
print('REFERENCE_AND_ANALYSIS_COMPLETE', flush=True)
