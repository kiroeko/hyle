from pathlib import Path
import importlib.util,hashlib,json,sys
sys.dont_write_bytecode=True
stage=Path('.scratch/architecture-refactor-2026-10-18/cuda-bf16-dual-projection')
upstream=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
runtime=Path('src/compute_ggml_runtime')
load('mixed',runtime/'prepare_mixed_cpu_manifest.py').derive(upstream,Path('third_party/ggml_runtime/patches.json'),Path('third_party/ggml_cpu_runtime/patches.json'),stage/'mixed-cpu-manifest.json')
load('cuda',runtime/'prepare_cuda_iq1_manifest.py').derive(upstream,stage/'mixed-cpu-manifest.json',stage/'patches.native-draft.json',Path('third_party/ggml_cuda_runtime/iq1-patches.json'),stage/'combined-native-draft.json')
rows=json.loads((stage/'combined-native-draft.json').read_text())['files']
sha=lambda data:hashlib.sha256(data).hexdigest()
changed={'src/ggml-cuda/'+name for name in ('mmvf.cu','mmvf.cuh','unary.cu')}
seen=[]
for row in rows:
 data=(upstream/row['path']).read_bytes().replace(b'\r\n',b'\n')
 assert sha(data)==row['before_sha256']
 for edit in row['edits']:
  before=edit['before'].encode();after=edit['after'].encode();assert data.count(before)==1
  data=data.replace(before,after,1)
 assert sha(data)==row['after_sha256'],row['path']
 if row['path'] in changed:
  assert data==(stage/'native-source'/row['path']).read_bytes(),row['path']
  seen.append(row['path'])
assert set(seen)==changed
assert Path('third_party/ggml_cuda_runtime/patches.json').read_bytes()==(stage/'patches.before.json').read_bytes()
print(json.dumps({'full_mixed_iq1_manifest_files_replayed':len(rows),'canonical_sources_match':seen,'default_template_reverse_proof':'exact old template body','product_manifest_untouched':True}))
