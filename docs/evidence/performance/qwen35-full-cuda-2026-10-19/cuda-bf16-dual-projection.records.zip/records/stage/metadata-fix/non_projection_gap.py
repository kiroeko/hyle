"""Align current and retained-peer physical kernel families, without GPU work."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_family_analysis', STAGE.parent / 'residual_review.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
current = r.review(STAGE / 'profile/qwen-dual-projection-trace', 980)
peer = r.review(r.ARCH / 'cuda-gdn-l2-fusion/peer-profile/peer-trace', 558)


def groups(trace):
    result = {}
    for row in trace['families']:
        key = 'normalization' if row['family'] in ('GDN_L2_core', 'RMSNorm') else row['family']
        result[key] = result.get(key, 0) + row['kernels_per_step']
    return result


h, p = groups(current), groups(peer)
rows = [{'family': key, 'hyle': h.get(key, 0), 'llama': p.get(key, 0),
    'delta': h.get(key, 0) - p.get(key, 0)} for key in h.keys() | p.keys() if key != 'projection']
rows.sort(key=lambda row: (-row['delta'], row['family']))
assert sum(row['hyle'] for row in rows) == 817
assert sum(row['llama'] for row in rows) == 395
assert sum(row['delta'] for row in rows) == 422
result = {'schema': 'hyle.qwen.non_projection_gap.v1', 'hyle': current, 'peer': peer,
    'non_projection_families': rows, 'totals': {'hyle': 817, 'llama': 395, 'delta': 422},
    'new_GPU_work': False, 'gap_time_attribution': False,
    'limits': ['Counts describe actual physical symbols in25warm bins, not a promise of identical intermediate math.',
        'RMSNorm and the Hyle L2 core share one normalization count here; their arithmetic contracts remain distinct.',
        'Peer projection epilogues can absorb work counted as non-projection elsewhere; categories are not logical operation counts.',
        'Both traces share fixed inputs and weights; their durations were collected at different times and are not subtracted.',
        'A count delta is a candidate for source-level alignment, not proof the entire delta is redundant or removable.']}
(STAGE / 'non-projection-gap.json').write_text(json.dumps(result, indent=2) + '\n')
for row in rows:
    print('{family}: {hyle} vs {llama}, delta {delta:+}'.format(**row))
