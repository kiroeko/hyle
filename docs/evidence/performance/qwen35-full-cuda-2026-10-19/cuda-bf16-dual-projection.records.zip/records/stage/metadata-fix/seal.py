"""Seal the metadata-aware private matcher without rebuilding the SDK."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
FIX = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dual_original_seal', FIX.parent / 'seal_native.py')
seal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(seal)
seal.STAGE = FIX
seal.VERSION = seal.VERSION.replace('-v15', '-v16')
seal.main()
