"""Reuse the fixed nine-process rotation with a new output/peer link directory."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
FIX = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dual_retained_rotation', FIX.parent / 'compare_three_dual.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
runner.PREPARED = FIX / 'performance-prepared'
runner.main()
