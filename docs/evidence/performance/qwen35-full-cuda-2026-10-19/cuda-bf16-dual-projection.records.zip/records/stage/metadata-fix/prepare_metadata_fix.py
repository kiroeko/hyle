from pathlib import Path
import difflib,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent;ROOT=STAGE.parents[3]
MAIN='src/ggml-cuda/ggml-cuda.cu'
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
before=(STAGE/'ggml-cuda.before.cu').read_text(encoding='utf-8')
assert sha(before.encode())=='0f1fcab495fd0063c367fd8ce8ffa8c92b5c5fbb0722bb5db7c685327216467c'
start=before.index('// The three intermediates are private BF16 values.')
end=before.index('static bool ggml_cuda_match_bf16_l2_core(',start)
old=before[start:end]
new=r'''// The three intermediates are private BF16 values. A weight transpose is
// already a bound readonly input view, not another mathematical producer.
struct ggml_cuda_bf16_dual_projection_match {
    const ggml_tensor * gate = nullptr;
    const ggml_tensor * up = nullptr;
    const ggml_tensor * silu = nullptr;
    ggml_tensor * dst = nullptr;
    int count = 0;
};

// Keep the existing math closure unchanged. Only the one explicitly admitted
// external weight view may have an ancestor outside the four math nodes.
static bool ggml_cuda_bf16_dual_projection_closed(const ggml_cgraph * graph,
        int begin, int count, const ggml_tensor * weight_view) {
    for (int j = 0; j < count; ++j) {
        const ggml_tensor * value = graph->nodes[begin + j];
        if ((value->flags & GGML_TENSOR_FLAG_COMPUTE) == 0) {
            return false;
        }
        if (j == count - 1) {
            continue;
        }
        if (value->flags & GGML_TENSOR_FLAG_OUTPUT) {
            return false;
        }
        int uses = 0;
        for (int k = j; k < count; ++k) {
            for (int s = 0; s < GGML_MAX_SRC; ++s) {
                uses += graph->nodes[begin + k]->src[s] == value;
            }
        }
        if (uses != ggml_node_get_use_count(graph, begin + j) ||
                (value == weight_view && uses != 1)) {
            return false;
        }
        if (value == weight_view) {
            continue;
        }
        for (const ggml_tensor * root = value->view_src; root; root = root->view_src) {
            bool internal = false;
            for (int k = 0; k < j; ++k) {
                internal |= root == graph->nodes[begin + k] && root != weight_view;
            }
            if (!internal) {
                return false;
            }
        }
    }
    return true;
}

static bool ggml_cuda_match_bf16_dual_projection(const ggml_cgraph * graph, int begin,
        int device, ggml_cuda_bf16_dual_projection_match & match) {
    match = {};
    if (begin < 0 || begin >= graph->n_nodes || graph->n_nodes - begin < 4) {
        return false;
    }
    const ggml_tensor * silu = nullptr;
    const ggml_tensor * weight_view = nullptr;
    const ggml_tensor * math[4] = {};
    int projections = 0, n_math = 0, count = 0;
    // Four real math nodes and at most one exact transpose of the other
    // projection's external weight. Never skip CONT, Cast, CPY or other views.
    while (count < 5 && begin + count < graph->n_nodes && n_math < 4) {
        ggml_tensor * value = graph->nodes[begin + count++];
        if (value->op == GGML_OP_TRANSPOSE) {
            if (weight_view || n_math == 0 || !value->src[0] ||
                    value->view_src != value->src[0] || value->view_offs != 0 ||
                    value->type != value->src[0]->type || value->type != GGML_TYPE_BF16) {
                return false;
            }
            const auto * source = value->src[0];
            if (value->ne[0] != source->ne[1] || value->ne[1] != source->ne[0] ||
                    value->nb[0] != source->nb[1] || value->nb[1] != source->nb[0] ||
                    value->ne[2] != source->ne[2] || value->ne[3] != source->ne[3] ||
                    value->nb[2] != source->nb[2] || value->nb[3] != source->nb[3]) {
                return false;
            }
            for (int s = 1; s < GGML_MAX_SRC; ++s) {
                if (value->src[s]) {
                    return false;
                }
            }
            weight_view = value;
            continue;
        }
        if (n_math < 3) {
            if (value->op == GGML_OP_MUL_MAT) {
                ++projections;
            } else if (value->op == GGML_OP_UNARY && !silu && ggml_hyle_stable_silu(value)) {
                silu = value;
            } else {
                return false;
            }
        } else if (value->op != GGML_OP_MUL) {
            return false;
        }
        math[n_math++] = value;
    }
    if (n_math != 4 || projections != 2 || !silu) {
        return false;
    }
    auto * dst = const_cast<ggml_tensor *>(math[3]);
    if ((dst->src[0] == silu) == (dst->src[1] == silu)) {
        return false;
    }
    const ggml_tensor * gate = silu->src[0];
    const ggml_tensor * up = dst->src[dst->src[0] == silu ? 1 : 0];
    bool gate_inside = false, up_inside = false;
    for (int j = 0; j < 3; ++j) {
        gate_inside |= gate == math[j];
        up_inside |= up == math[j];
    }
    if (!gate_inside || !up_inside || gate == up) {
        return false;
    }
    if (weight_view) {
        // Retain the actual MM input tensor and its external physical origin;
        // this is not peeling metadata from either projected mathematical value.
        const ggml_tensor * reader = gate->src[0] == weight_view ? gate
            : up->src[0] == weight_view ? up : nullptr;
        if (!reader) {
            return false;
        }
        for (int j = 0; j < 4; ++j) {
            if (weight_view->src[0] == math[j]) {
                return false;
            }
        }
        bool after_view = false, reader_after_view = false;
        for (int j = 0; j < count; ++j) {
            const auto * value = graph->nodes[begin + j];
            reader_after_view |= after_view && value == reader;
            after_view |= value == weight_view;
        }
        if (!reader_after_view) {
            return false;
        }
    }
    if (!ggml_cuda_bf16_dual_projection_closed(graph, begin, count, weight_view) ||
            !ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate, up, silu, dst, device)) {
        return false;
    }
    match = {gate, up, silu, dst, count};
    return true;
}

'''
old_return='''ggml_cuda_op_bf16_dual_matvec_silu_mul(*cuda_ctx, match.gate, match.up, match.silu, match.dst);
            return 3;'''
new_return='''ggml_cuda_op_bf16_dual_matvec_silu_mul(*cuda_ctx, match.gate, match.up, match.silu, match.dst);
            return match.count - 1;'''
edits=[{'before':old,'after':new},{'before':old_return,'after':new_return}]
after=before
for edit in edits:
 assert after.count(edit['before'])==1;after=after.replace(edit['before'],edit['after'],1)
# The v14 L2 guard and its call are byte-for-byte untouched.
closed_begin=before.index('static bool ggml_cuda_private_fusion_closed(')
assert before[closed_begin:start] in after
assert 'ggml_cuda_private_fusion_closed(graph, begin, next - begin)' in after
out=STAGE/'native-source'/MAIN;out.write_text(after,encoding='utf-8',newline='\n')
(STAGE/'main-change.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+MAIN,tofile='b/'+MAIN)),encoding='utf-8',newline='\n')
save(STAGE/'main-delta.json',{'path':MAIN,'canonical_before_sha256':sha(before.encode()),'canonical_after_sha256':sha(after.encode()),'edits':edits})
manifest=json.loads((STAGE/'patches.before.json').read_text())
entry=next(row for row in manifest['files']if row['path']==MAIN)
upstream=Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
data=(upstream/MAIN).read_bytes().replace(b'\r\n',b'\n')
assert sha(data)==entry['before_sha256']
for edit in entry['edits']:
 old_b,new_b=edit['before'].encode(),edit['after'].encode();assert data.count(old_b)==1;data=data.replace(old_b,new_b,1)
assert sha(data)==entry['after_sha256']
for edit in edits:
 old_b,new_b=edit['before'].encode(),edit['after'].encode();assert data.count(old_b)==1;data=data.replace(old_b,new_b,1)
entry['edits'].extend(edits);entry['after_sha256']=sha(data)
save(STAGE/'patches.metadata-draft.json',manifest)
runtime=ROOT/'src/compute_ggml_runtime'
load('mixed',runtime/'prepare_mixed_cpu_manifest.py').derive(upstream,ROOT/'third_party/ggml_runtime/patches.json',ROOT/'third_party/ggml_cpu_runtime/patches.json',STAGE/'mixed-draft.json')
load('cuda',runtime/'prepare_cuda_iq1_manifest.py').derive(upstream,STAGE/'mixed-draft.json',STAGE/'patches.metadata-draft.json',ROOT/'third_party/ggml_cuda_runtime/iq1-patches.json',STAGE/'combined-draft.json')
rows=json.loads((STAGE/'combined-draft.json').read_text())['files']
for row in rows:
 data=(upstream/row['path']).read_bytes().replace(b'\r\n',b'\n');assert sha(data)==row['before_sha256']
 for edit in row['edits']:
  old_b,new_b=edit['before'].encode(),edit['after'].encode();assert data.count(old_b)==1;data=data.replace(old_b,new_b,1)
 assert sha(data)==row['after_sha256']
 if row['path']==MAIN:assert data==out.read_bytes()
print(json.dumps({'source_bytes':len(after.encode()),'canonical_after_sha256':sha(after.encode()),'manifest_files_replayed':len(rows),'CUDA_only_after_sha256':entry['after_sha256']}))
