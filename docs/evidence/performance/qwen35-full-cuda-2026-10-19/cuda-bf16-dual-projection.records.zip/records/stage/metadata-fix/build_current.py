"""Compile only the corrected native matcher and provider version owner."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
DUAL = STAGE.parent
ARCH = DUAL.parent
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('metadata_original_build', DUAL / 'build_current.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
b, c = original.b, original.c
BASE = DUAL / 'checks/relink-20261019T084930'
TEST = DUAL / 'tests-build/20261019T085621'
NATIVE = DUAL / 'checks/20261019T084721'


def check(plan):
    original.check(plan)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    prior = c.read(BASE / 'plan.json')
    tests = c.read(TEST / 'cuda-link-plan.json')
    mutable = {c.key(ROOT / p) for p in ('third_party/ggml_cuda_runtime/patches.json',
        'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json')}
    frozen = []
    for row in prior['frozen']:
        if c.key(row['path']) not in mutable and not b.same(row):
            raise ValueError('Unrelated source drift: ' + row['path'])
        frozen.append(b.identity(row['path']))
    frozen += [b.identity(p) for p in (Path(__file__), STAGE / 'seal.py',
        STAGE / 'native-source-freeze.json', STAGE / 'provider-version.h',
        ROOT / 'tests/graph_route_cuda/stable_silu_test.cc')]
    freeze = c.read(STAGE / 'native-source-freeze.json')
    for path, expected in freeze['sources'].items():
        actual = b.identity(STAGE / 'native-source' / path)
        if actual['sha256'] != expected:
            raise ValueError('Corrected native source differs')
        frozen.append(actual)
    compile_rows, replacements = [], {}
    for tag in ('ggml-cuda', 'provider'):
        recipe_path = NATIVE / (tag + '-identity.json')
        recipe = c.read(recipe_path)
        if not b.same(recipe['object']):
            raise ValueError('Prior object drift')
        if tag == 'ggml-cuda':
            source = STAGE / 'native-source/src/ggml-cuda/ggml-cuda.cu'
            command = b.native_command(original.strip_ccbin(recipe['command']), source, tag, out)
            command[1:1] = ['-I' + str(STAGE / 'native-source/src'),
                '-I' + str(STAGE / 'native-source/src/ggml-cuda')]
        else:
            source = ROOT / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
            template = ['/FI' + str(STAGE / 'provider-version.h')
                if x.lower().startswith('/fi') else x for x in recipe['command']]
            command = b.host_command(template, source, tag, out)
        compile_rows.append({'tag': tag, 'command': command,
            'source': b.identity(source), 'object': str(out / (tag + '.obj'))})
        replacements[c.key(recipe['object']['path'])] = str(out / (tag + '.obj'))
        frozen.extend([b.identity(recipe_path), b.identity(source)])
    cached = {c.key(r['path']): r for r in prior['cached_inputs'] + tests['inputs']}
    for row in cached.values():
        if not b.same(row):
            raise ValueError('Retained object drift: ' + row['path'])
    links = {'baseline': prior['links']['baseline']}
    for tag, source in (('qwen', prior['links']['qwen']), ('cuda', tests)):
        for owner in replacements:
            if sum(c.key(x) == owner for x in source['command']) != 1:
                raise ValueError('Replacement owner is not unique: ' + tag)
        command = [replacements.get(c.key(x), x) for x in source['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
            '/IMPLIB:' + str(image.with_suffix('.lib'))]
        selected = original.inputs(command)
        expected = 124 if tag == 'qwen' else 132
        if len(selected) != expected or len({c.key(x) for x in selected}) != expected:
            raise ValueError('Input owners changed unexpectedly')
        links[tag] = {'command': command, 'image': str(image), 'inputs': selected}
    plan = {'compile': compile_rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list({r['path']: r for r in frozen}.values()),
        'native_TUs': 1, 'host_TUs': 1, 'SDK_build': False, 'CMake_run': False,
        'native_source_id': freeze['source_id'], 'baseline_image_reused': True,
        'prior_candidate': b.identity(BASE / 'qwen-image.json')}
    target = out / 'plan.json'
    c.save(target, plan)
    check(plan)
    print('PLAN', target, flush=True)
    if not args.build:
        return
    (out / 'tmp').mkdir()
    env, _ = b.environment(links['qwen']['command'], [r['path'] for r in cached.values()], out)
    for row in compile_rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': b.identity(row['object'])})
    for tag in ('qwen', 'cuda'):
        link = links[tag]
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'],
            'inputs': [b.identity(x) for x in link['inputs']]})
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    for name in ('baseline-image.json', 'baseline-link.result.json', 'baseline-link-plan.json'):
        (out / name).write_bytes((BASE / name).read_bytes())
    c.save(out / 'summary.json', {'passed': True, 'native_TUs': 1, 'host_TUs': 1,
        'SDK_build': False, 'GPU_run': False, 'baseline_image_reused': True})
    print('BUILD_COMPLETE', target, flush=True)


if __name__ == '__main__':
    main()
