"""Run new math/slot controls, then retained affected CUDA regressions."""
from pathlib import Path
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('dual_test_build', STAGE / 'tests-build/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c = b.c


def main():
    path = Path(sys.argv[1]).resolve()
    plan = c.read(path)
    b.check(plan)
    out = path.parent / 'run-cuda'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = Path(plan['links']['cuda']['image'])
    if b.b.identity(image) != c.read(path.parent / 'cuda-image.json'):
        raise ValueError('Test image drift')
    env, _ = b.b.environment(plan['links']['cuda']['command'],
        [row['path'] for row in plan['cached_inputs']], out)
    new = c.read(STAGE / 'tests-plan.json')['tests']
    retained = c.read(STAGE.parent / 'cuda-rms-candidate-frontier/checks/20261019T080921/plan.json')['directed_tests']
    stable = [
        'CudaStableSilu.DirectOrdinarySiluKeepsStableTailsAndNonfiniteContract',
        'CudaStableSilu.NoncontiguousSiluMulRegionCrossesCublasAndRebindsBothSlots',
        'CudaStableSilu.PublishedExtraReaderAndSelfMultiplyKeepRoundedIntermediate',
        'CudaStableSilu.DefaultRank2ProjectionKeepsBlasLeafPreference',
        'CudaStableSilu.Rank4RoundTripsKeepPublishedRoundingAndBothSlots']
    results = []
    for label, cases in (('dual', new), ('retained', retained + stable)):
        xml = out / (label + '.xml')
        c.execute(label, [str(image), '--gtest_color=no', '--gtest_filter=' + ':'.join(cases),
            '--gtest_output=xml:' + str(xml)], env, out)
        doc = ET.parse(xml).getroot()
        actual = [row.attrib['classname'] + '.' + row.attrib['name'] for row in doc.findall('.//testcase')]
        if set(actual) != set(cases) or len(actual) != len(cases) or doc.findall('.//failure') or doc.findall('.//skipped'):
            raise ValueError('Missing, failed or skipped CUDA regression: ' + label)
        results.extend(actual)
        c.save(out / 'summary.json', {'cases': results, 'failures': 0, 'skipped': 0,
            'image': b.b.identity(image), 'terminal': label == 'retained'})
        print('PASS', label, len(actual), flush=True)


if __name__ == '__main__':
    main()
