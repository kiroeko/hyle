"""Offline decomposition of the retained nine-process full/warm decode window."""
from pathlib import Path
import hashlib
import json
import re
import statistics

STAGE = Path(__file__).resolve().parent
SOURCE = STAGE.parent / 'cuda-hot-prepare-selection/comparison'


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    runs = json.loads((SOURCE / 'runs.json').read_text())
    rows, inputs = [], [identity(SOURCE / 'runs.json')]
    for run in runs:
        if run['engine'] == 'baseline':
            continue
        tag, engine = run['tag'], run['engine']
        if engine == 'hyle':
            path = SOURCE / (tag + '.stderr.log')
            text = path.read_text()
            phases = re.findall(r'^decode(\d+) tokens=1 .*?step_seconds=([0-9.e+-]+)', text, re.M)
            if [int(i) for i, _ in phases] != list(range(1, 32)):
                raise ValueError('Hyle phase set differs')
            seconds = [float(value) for _, value in phases]
            captures = [tuple(map(int, pair)) for pair in re.findall(
                r'capture_recorded=(\d+) capture_reused=(\d+)', text)]
            if captures != [(7, 0)] * 3 + [(0, 7)] * 29:
                raise ValueError('Hyle capture journey differs')
        else:
            path = SOURCE / (tag + '-peer-result.json')
            result = json.loads(path.read_text())
            if [p['phase'] for p in result['phases']] != list(range(32)):
                raise ValueError('Peer phase set differs')
            seconds = [p['step_seconds'] for p in result['phases'][1:]]
            captures = None
        inputs.append(identity(path))
        rows.append({'engine': engine, 'tag': tag, 'captures': captures,
            'first2_seconds': sum(seconds[:2]), 'decode3_6_seconds': sum(seconds[2:6]),
            'first6_seconds': sum(seconds[:6]), 'warm7_31_seconds': sum(seconds[6:]),
            'full31_seconds': sum(seconds), 'all_step_seconds': seconds})
    keys = ('first2_seconds', 'decode3_6_seconds', 'first6_seconds',
            'warm7_31_seconds', 'full31_seconds')
    groups = {engine: {key: {'samples': [r[key] for r in rows if r['engine'] == engine],
        'median': statistics.median(r[key] for r in rows if r['engine'] == engine)}
        for key in keys} for engine in ('hyle', 'peer')}
    excess = {key: groups['hyle'][key]['median'] - groups['peer'][key]['median'] for key in keys}
    result = {'source': inputs, 'runs': rows, 'groups': groups,
        'difference_of_window_medians_seconds': excess,
        'new_GPU_runs': 0, 'causal_attribution': False,
        'limits': [
            'These are the preceding hot-selection images, not the new dual-projection images.',
            'The first two Hyle decode invocations record their own seven ranges; later invocations reuse them.',
            'The measured windows include actual GPU execution, upload, prepare, submit, wait and the completed host token.',
            'Differences of separately selected medians are not an additive decomposition of a single paired run.',
            'Capture occurrence identifies a candidate cost; it does not isolate capture cost or prove it caused the time gap.',
            'Three processes per arm do not establish statistical significance.'
        ]}
    (STAGE / 'full-decode-decomposition.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'medians_seconds': {engine: {key: values['median'] for key, values in group.items()}
        for engine, group in groups.items()}, 'difference_seconds': excess}, indent=2))


if __name__ == '__main__':
    main()
