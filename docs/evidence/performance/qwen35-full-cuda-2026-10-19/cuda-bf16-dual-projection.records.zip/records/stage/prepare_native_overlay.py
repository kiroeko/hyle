from pathlib import Path
import hashlib,json,difflib
stage=Path('.scratch/architecture-refactor-2026-10-18/cuda-bf16-dual-projection')
def read(name):return (stage/'before/src/ggml-cuda'/name).read_text(encoding='utf-8')
mm=read('mmvf.cu'); unary=read('unary.cu'); header=read('mmvf.cuh')
start=mm.index('template <typename T, typename type_acc, int ncols_dst, int block_size,')
end=mm.index('template <typename T, typename type_acc, typename Y = float, typename Dst = float>')
old_templates=mm[start:end]; templates=old_templates
old='typename Y = float, typename Dst = float>'
assert templates.count(old)==3
templates=templates.replace(old,'typename Y = float, typename Dst = float, typename Epilogue = void>')
old_epilogue='''    if constexpr (has_fusion) {
        if (use_bias) {
            value += x_bias[tid*stride_col_dst + row];
        }

        if (use_gate) {
            float gate_value = sumf_gate[tid];
            if (use_gate_bias) {
                gate_value += gate_bias[tid*stride_col_dst + row];
            }
            switch (glu_op) {
                case GGML_GLU_OP_SWIGLU:
                    value *= ggml_cuda_op_silu_single(gate_value);
                    break;
                case GGML_GLU_OP_GEGLU:
                    value *= ggml_cuda_op_gelu_single(gate_value);
                    break;
                case GGML_GLU_OP_SWIGLU_OAI: {
                    value = ggml_cuda_op_swiglu_oai_single(gate_value, value);
                    break;
                }
                case GGML_GLU_OP_SWIGLU_CLAMP:
                    value = ggml_cuda_op_swiglu_clamp_single(gate_value, value, glu_limit);
                    break;
                default:
                    break;
            }
        }
    }
'''
assert templates.count(old_epilogue)==1
new_epilogue='''    if constexpr (!std::is_void_v<Epilogue>) {
        static_assert(has_fusion && ncols_dst == 1 && !is_multi_token_id);
        static_assert(std::is_same_v<T, nv_bfloat16> && std::is_same_v<type_acc, float> &&
                      std::is_same_v<Y, nv_bfloat16> && std::is_same_v<Dst, nv_bfloat16>);
        value = Epilogue::apply(value, sumf_gate[tid]);
    } else {
'''+old_epilogue+'''    }
'''
templates=templates.replace(old_epilogue,new_epilogue)
# Keep the original default dispatch body literal. The private epilogue always
# selects the real dual-weight kernel and never instantiates its unfused branch.
switch_start=templates.index('    const bool has_fusion = fusion.gate != nullptr || fusion.x_bias != nullptr || fusion.gate_bias != nullptr;')
switch_end=templates.index('\ntemplate <typename T, typename type_acc, int ncols_dst, bool is_multi_token_id')
old_switch=templates[switch_start:switch_end]
assert old_switch.endswith('\n}\n')
new_switch='''    if constexpr (!std::is_void_v<Epilogue>) {
        static_assert(ncols_dst == 1 && !is_multi_token_id);
        static_assert(std::is_same_v<T, nv_bfloat16> && std::is_same_v<type_acc, float> &&
                      std::is_same_v<Y, nv_bfloat16> && std::is_same_v<Dst, nv_bfloat16>);
        GGML_ASSERT(fusion.gate && !ids && !fusion.x_bias && !fusion.gate_bias &&
                    !fusion.x_scale && !fusion.gate_scale);
        ggml_cuda_kernel_launch(mul_mat_vec_f<T, type_acc, ncols_dst, block_size, true, is_multi_token_id, Y, Dst, Epilogue>, launch_params,
            x, y, ids, fusion, dst, ncols, nchannels_y, stride_row, stride_col_y, stride_col_dst,
            channel_ratio, stride_channel_x, stride_channel_y, stride_channel_dst,
            sample_ratio, stride_sample_x, stride_sample_y, stride_sample_dst, ids_stride);
    } else {
'''+old_switch[:-3]+'''    }
}
'''
templates=templates[:switch_start]+new_switch+templates[switch_end:]
# Only forward the new tag through the existing block-size selector.
for block in (32,64,96,128,160,192,224,256):
 old=f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id>'
 assert templates.count(old)==1
 templates=templates.replace(old,f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id, Y, Dst, Epilogue>')
# Reverse only the new tag/epilogue dispatch to prove that the extracted
# default carrier's complete literal body is the previous locked template.
roundtrip=templates.replace(new_epilogue,old_epilogue).replace(new_switch,old_switch)
for block in (32,64,96,128,160,192,224,256):
 roundtrip=roundtrip.replace(f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id, Y, Dst, Epilogue>',f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id>')
roundtrip=roundtrip.replace('typename Y = float, typename Dst = float, typename Epilogue = void>','typename Y = float, typename Dst = float>')
assert roundtrip==old_templates
new_mm=mm[:start]+mm[end:]
private_declarations='''// Private BF16 ordinary-SiLU carrier. Both original MUL_MAT nodes already
// have BF16 public outputs and independently declare F32 accumulation. The
// existing graph matcher still owns reader/control/output closure proof.
bool ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(
    const ggml_tensor * gate_mm, const ggml_tensor * up_mm,
    const ggml_tensor * silu, const ggml_tensor * dst, int device);
void ggml_cuda_op_bf16_dual_matvec_silu_mul(
    ggml_backend_cuda_context & ctx, const ggml_tensor * gate_mm,
    const ggml_tensor * up_mm, const ggml_tensor * silu, ggml_tensor * dst);
'''
new_header='#pragma once\n'+header.replace('#include "common.cuh"','#include "common.cuh"\n#include "unary.cuh"\n#include "convert.cuh"\n\n#include <type_traits>',1)+'\n'+private_declarations+'\n// Shared original MMVF carrier. A non-void epilogue is instantiated only by\n// the precise unary unit; upstream/default arithmetic remains in mmvf.cu.\n'+templates
assert unary.startswith('#include "unary.cuh"\n#include "convert.cuh"\n')
new_unary=unary.replace('#include "convert.cuh"\n','#include "convert.cuh"\n#include "mmvf.cuh"\n\n#include <cstdint>\n#include <limits>\n',1)
new_code=r'''
/* BF16 dual projection + ordinary stable SiLU + explicit public rounding */

// These are four independent public BF16 boundaries, not the old GLU math.
// This instantiation belongs to the existing no-fast-math unary object.
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
struct hyle_bf16_dual_matvec_silu_epilogue {
    static __device__ __forceinline__ float apply(float up_sum, float gate_sum) {
        const float up = __bfloat162float(__float2bfloat16_rn(up_sum));
        const float gate = __bfloat162float(__float2bfloat16_rn(gate_sum));
        const float activation = op_hyle_stable_silu(gate);
        const float rounded_activation = __bfloat162float(__float2bfloat16_rn(activation));
        // The shared carrier's final BF16 RNE store supplies the Y boundary.
        return rounded_activation * up;
    }
};

static bool hyle_bf16_dual_matvec_overlaps(const ggml_tensor * read, const ggml_tensor * dst) {
    const auto read_begin = reinterpret_cast<std::uintptr_t>(read->data);
    const auto dst_begin = reinterpret_cast<std::uintptr_t>(dst->data);
    const auto read_bytes = ggml_nbytes(read), dst_bytes = ggml_nbytes(dst);
    const auto limit = std::numeric_limits<std::uintptr_t>::max();
    if (read_bytes > limit - read_begin || dst_bytes > limit - dst_begin) {
        return true;
    }
    return read_begin < dst_begin + dst_bytes && dst_begin < read_begin + read_bytes;
}
#endif

bool ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(
        const ggml_tensor * gate_mm, const ggml_tensor * up_mm,
        const ggml_tensor * silu, const ggml_tensor * dst, int device) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(gate_mm, up_mm, silu, dst, device);
    return false;
#else
    if (!gate_mm || !up_mm || !silu || !dst || gate_mm == up_mm ||
            gate_mm->op != GGML_OP_MUL_MAT || up_mm->op != GGML_OP_MUL_MAT ||
            ggml_get_op_params_i32(gate_mm, 0) != GGML_PREC_F32 ||
            ggml_get_op_params_i32(up_mm, 0) != GGML_PREC_F32 ||
            silu->op != GGML_OP_UNARY || !ggml_hyle_stable_silu(silu) ||
            silu->src[0] != gate_mm || dst->op != GGML_OP_MUL ||
            !((dst->src[0] == silu && dst->src[1] == up_mm) ||
              (dst->src[1] == silu && dst->src[0] == up_mm))) {
        return false;
    }
    const ggml_tensor * gate_weight = gate_mm->src[0];
    const ggml_tensor * up_weight = up_mm->src[0];
    const ggml_tensor * x = gate_mm->src[1];
    if (!gate_weight || !up_weight || !x || up_mm->src[1] != x ||
            device < 0 || device >= ggml_cuda_info().device_count) {
        return false;
    }
    const int cc = ggml_cuda_info().devices[device].cc;
    if (!GGML_CUDA_CC_IS_NVIDIA(cc) || !fast_bf16_hardware_available(cc)) {
        return false;
    }
    for (const auto * tensor : {gate_weight, up_weight, x, gate_mm, up_mm, silu, dst}) {
        if (tensor->type != GGML_TYPE_BF16 || !ggml_is_contiguous(tensor) ||
                tensor->ne[2] != 1 || tensor->ne[3] != 1) {
            return false;
        }
    }
    const auto k = gate_weight->ne[0], n = gate_weight->ne[1];
    // The original carrier uses int row*stride_row and int channel strides.
    // Bound the product too, not only each independent dimension.
    if (k <= 0 || k % 2 || n <= 0 || k > std::numeric_limits<int>::max() ||
            n > std::numeric_limits<int>::max() / k ||
            !ggml_are_same_shape(gate_weight, up_weight) ||
            x->ne[0] != k || x->ne[1] != 1 || x->nb[1] % sizeof(nv_bfloat162) ||
            gate_mm->ne[0] != n || gate_mm->ne[1] != 1 ||
            !ggml_are_same_shape(gate_mm, up_mm) ||
            !ggml_are_same_shape(gate_mm, silu) || !ggml_are_same_shape(gate_mm, dst)) {
        return false;
    }
    for (const auto * read : {gate_weight, up_weight, x}) {
        if (!read->data || !dst->data ||
                reinterpret_cast<std::uintptr_t>(read->data) % alignof(nv_bfloat162) ||
                hyle_bf16_dual_matvec_overlaps(read, dst)) {
            return false;
        }
    }
    if (reinterpret_cast<std::uintptr_t>(dst->data) % alignof(nv_bfloat16)) {
        return false;
    }
    return ggml_cuda_should_use_mmvf(gate_weight->type, cc,
               gate_weight->ne, gate_weight->nb, 1) &&
           ggml_cuda_should_use_mmvf(up_weight->type, cc,
               up_weight->ne, up_weight->nb, 1);
#endif
}

void ggml_cuda_op_bf16_dual_matvec_silu_mul(
        ggml_backend_cuda_context & ctx, const ggml_tensor * gate_mm,
        const ggml_tensor * up_mm, const ggml_tensor * silu, ggml_tensor * dst) {
    GGML_ASSERT(ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate_mm, up_mm, silu, dst, ctx.device));
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const ggml_tensor * gate_weight = gate_mm->src[0];
    const ggml_tensor * up_weight = up_mm->src[0];
    const ggml_tensor * x = up_mm->src[1];
    const auto element_bytes = sizeof(nv_bfloat16);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = gate_weight->data;
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, 1, false,
        nv_bfloat16, nv_bfloat16, hyle_bf16_dual_matvec_silu_epilogue>(
            static_cast<const nv_bfloat16 *>(up_weight->data),
            static_cast<const nv_bfloat16 *>(x->data), nullptr, fusion,
            static_cast<nv_bfloat16 *>(dst->data), up_weight->ne[0], up_weight->ne[1],
            up_weight->nb[1] / element_bytes, x->nb[1] / element_bytes, dst->nb[1] / element_bytes,
            1, 1, 1, up_weight->nb[2] / element_bytes, x->nb[2] / element_bytes, dst->nb[2] / element_bytes,
            1, 1, up_weight->nb[3] / element_bytes, x->nb[3] / element_bytes, dst->nb[3] / element_bytes,
            1, 0, ctx.stream());
#else
    GGML_UNUSED_VARS(ctx, gate_mm, up_mm, silu, dst);
#endif
}
'''
new_unary += new_code
newfiles={'mmvf.cu':new_mm,'mmvf.cuh':new_header,'unary.cu':new_unary}
all_diff=[]; deltas=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for name,after in newfiles.items():
 before=read(name)
 assert after.endswith('\n')
 (stage/'native-source/src/ggml-cuda'/name).write_text(after,encoding='utf-8',newline='\n')
 all_diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/src/ggml-cuda/'+name,tofile='b/src/ggml-cuda/'+name))
 # Exact existing-source edits, no create-file feature needed.
 if name=='mmvf.cu':edits=[{'before':old_templates,'after':''}]
 elif name=='mmvf.cuh':edits=[{'before':before,'after':after}]
 else:edits=[{'before':'#include "convert.cuh"\n','after':'#include "convert.cuh"\n#include "mmvf.cuh"\n\n#include <cstdint>\n#include <limits>\n'},{'before':unary[-300:],'after':unary[-300:]+new_code}]
 current=before
 for e in edits:
  assert current.count(e['before'])==1
  current=current.replace(e['before'],e['after'],1)
 assert current==after
 deltas.append({'path':'src/ggml-cuda/'+name,'before_sha256':sha(before.encode()),'after_sha256':sha(after.encode()),'edits':edits})
(stage/'native-change.diff').write_text(''.join(all_diff),encoding='utf-8',newline='\n')
(stage/'native-delta.json').write_text(json.dumps({'upstream_revision':'456172ec733a135778adcd32d00e576a58232e45','scope':'Append these edits to current product entries; standalone before hashes name current patched source, not upstream.','files':deltas},indent=2)+'\n',encoding='utf-8',newline='\n')
manifest=json.loads((stage/'patches.before.json').read_text())
for delta in deltas:
 entry=next((f for f in manifest['files'] if f['path']==delta['path']),None)
 if entry:
  assert entry['after_sha256']==delta['before_sha256']
  entry['edits'].extend(delta['edits']);entry['after_sha256']=delta['after_sha256']
 else:manifest['files'].append(delta)
(stage/'patches.native-draft.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
for name,after in newfiles.items():print(name,len(after.encode()),sha(after.encode()))
