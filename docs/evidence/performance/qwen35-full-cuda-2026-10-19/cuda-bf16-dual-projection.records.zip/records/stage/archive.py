"""Prepare exact evidence/reclaim inventories, or archive; never delete anything."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import zipfile

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
DEST = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bf16-dual-projection.zip"
ALLOWED = {".py", ".ps1", ".json", ".xml", ".log", ".csv", ".sqlite", ".nsys-rep",
           ".bf16", ".f32", ".h", ".cc", ".c", ".cu", ".cuh", ".inc", ".diff",
           ".patch", ".cmake", ".ids", ".tsv", ".txt", ".md", ".d"}
DERIVED = {".exe", ".map", ".lib", ".exp"}
GENERATED = {"archive-plan.json", "archive-source-freeze.json", "model-references.json",
             "reclaim-targets.json", "archive-verification.json", "reclaim-receipt.json"}
PRODUCTS = (
    "third_party/ggml_cuda_runtime/patches.json", "third_party/ggml_cuda_runtime/NOTICE.md",
    "cmake/HyleDependencyLock.json", "src/compute_provider_ggml_cuda/program.h",
    "src/compute_provider_ggml_cuda/numerical_contract.h", "src/compute_provider_ggml_cuda/tensor_program.h",
    "src/compute_provider_ggml_cuda/tensor_program.cc", "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
    "src/graph_provider_ggml_cuda/ggml_cuda_region.cc", "src/graph_provider_ggml_cuda/constant_expressions.h",
    "src/graph_batch/batch.cc", "src/compute/batch_transfer.cc", "src/mem/resource.cc",
    "include/hyle/mem/resource.h", "tests/graph_route_cuda/stable_silu_test.cc",
    "tests/graph_route_cuda/CMakeLists.txt", "tests/graph_batch/typed_capability_graph_test.cc",
    "tests/compute_backend_cpu/copy_program_test.cc", "tools/qwen35_text/main.cc",
    "tools/qwen35_text/CMakeLists.txt", "tools/qwen35_text/README.md", "tools/qwen35_text/reference.py",
    "src/compute_ggml_runtime/explicit_rope.h",
    "docs/architecture/compute-design.md", "docs/developer/current-work.md",
    "docs/implementation/model-operators.md", "docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md",
    "docs/implementation/tasks/compute/qwen35-2b-local-input.json", "test.ps1")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(stream):
    result = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        result.update(chunk)
    return result.hexdigest()


def identity(path):
    with path.open("rb") as stream:
        return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": digest(stream)}


def eligible(path, base):
    relative = path.relative_to(base)
    return (path.is_file() and path.suffix.lower() in ALLOWED and
            not any(part.lower() in ("tmp", "__pycache__", ".git") for part in relative.parts) and
            path.name not in GENERATED)


def inventory(plan):
    payload = {}
    roots = (("stage", STAGE), ("provider-design", ARCH / "cuda-ffn-next-design"))
    for prefix, base in roots:
        if base.is_dir():
            for path in base.rglob("*"):
                if eligible(path, base):
                    payload[prefix + "/" + path.relative_to(base).as_posix()] = path
    hot = ARCH / "cuda-hot-prepare-selection"
    for path in hot.rglob("*"):
        relative = path.relative_to(hot)
        wanted = (path.name in ("preparation-review.json", "analyze_preparation.py") or
                  str(relative).startswith(("checks/cpu-", "checks\\cpu-")) or
                  path.name.startswith("typed-capability-test"))
        if wanted and eligible(path, hot):
            payload["cpu-analysis/" + relative.as_posix()] = path
    for name in PRODUCTS:
        path = ROOT / name
        if not path.is_file():
            raise ValueError("Required product source missing: " + str(path))
        payload["source/" + name] = path
    for row in plan.get("frozen", []):
        path = Path(row["path"]).resolve()
        if path.is_relative_to(ROOT) and not path.is_relative_to(ROOT / ".scratch"):
            if path.is_file() and path.suffix.lower() in ALLOWED:
                payload["source/" + path.relative_to(ROOT).as_posix()] = path
    fixtures = ARCH / "qwen-gpu-comparison/128-prefill"
    for name in ("inputs/prompt.ids", "inputs/weights.tsv", "fixed-inputs.json", "decode.ids"):
        path = fixtures / name
        if not path.is_file():
            raise ValueError("Fixed fixture missing: " + str(path))
        payload["fixtures/" + name] = path
    for name in ("converted-file-identity.json",):
        path = ARCH / "llama-matched-consumer" / name
        if path.is_file():
            payload["model-identities/" + name] = path
    for name, path in payload.items():
        if path.suffix.lower() in DERIVED or path.suffix.lower() in (".obj", ".pdb", ".gguf", ".safetensors", ".bin"):
            raise ValueError("Forbidden binary payload: " + name)
        if path.stat().st_size >= 1024 ** 3 and path.suffix.lower() not in (".sqlite", ".nsys-rep"):
            raise ValueError("Oversized non-profile artifact, not read: " + str(path))
    return payload


def declared_link_outputs():
    declared = set()
    def visit(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in ("command", "argv") and isinstance(child, list):
                    for argument in child:
                        if not isinstance(argument, str):
                            continue
                        if argument.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:")):
                            path = Path(argument.split(":", 1)[1]).resolve()
                            if path.is_relative_to(STAGE) and path.suffix.lower() in DERIVED:
                                declared.add(path)
                                if path.suffix.lower() == ".lib":
                                    declared.add(path.with_suffix(".exp"))
                else:
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    for path in STAGE.rglob("*.json"):
        if not any(part.lower() == "tmp" for part in path.relative_to(STAGE).parts) and path.name not in GENERATED:
            try:
                visit(read(path))
            except (json.JSONDecodeError, UnicodeError):
                # A failed attempt may leave raw/truncated JSON. Preserve its
                # payload without treating it as a declared link command.
                pass
    return declared


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "archive"))
    parser.add_argument("plan", type=Path)
    args = parser.parse_args()
    path = args.plan.resolve()
    if not path.is_relative_to(STAGE) or path.name != "plan.json" or path.parent.parent.name != "checks":
        raise ValueError("Use the current dual-stage Qwen build plan")
    plan = read(path)
    if len(plan["links"]["qwen"]["inputs"]) != 124:
        raise ValueError("Expected current124-input Qwen closure")
    if not read(path.parent / "summary.json").get("passed"):
        raise ValueError("Current build has no successful summary")
    if read(path.parent / "qwen-link.result.json").get("exit") != 0:
        raise ValueError("Current Qwen link did not exit0")
    if args.mode == "prepare":
        payload = inventory(plan)
        declared = declared_link_outputs()
        targets, unknown = [], []
        for item in sorted(STAGE.rglob("*")):
            if item.is_file() and item.suffix.lower() in DERIVED:
                if not item.resolve().is_relative_to(STAGE):
                    raise ValueError("Derived target escaped stage: " + str(item))
                (targets if item.resolve() in declared else unknown).append(identity(item))
        save(STAGE / "reclaim-targets.json", targets)
        save(STAGE / "archive-source-freeze.json", [identity(ROOT / name) for name in PRODUCTS])
        manifest = read(ROOT / "docs/implementation/tasks/compute/qwen35-2b-local-input.json")
        lines = (ARCH / "qwen-gpu-comparison/128-prefill/inputs/weights.tsv").read_text().splitlines()
        save(STAGE / "model-references.json", {
            "policy": "Reuse original model/SDK paths and recorded identities; no model or SDK payload is read, copied or freshly hashed by this archive script.",
            "hyle_shard_path": lines[1], "artifact_identity_sha256": lines[2],
            "original_files": manifest.get("files", []),
            "peer_identity_receipt": str(ARCH / "llama-matched-consumer/converted-file-identity.json"),
            "fixed_fixtures": "prompt128 + fixed31 decode, capacity256; small manifest and tapes included"})
        rows = [{"name": name, **identity(source)} for name, source in sorted(payload.items())]
        save(STAGE / "archive-plan.json", {
            "schema": 1, "build_plan": identity(path), "destination": str(DEST), "payload": rows,
            "reclaim_targets": identity(STAGE / "reclaim-targets.json"), "unclassified_derived_files": unknown,
            "deletion": "No deletion is implemented. Parent owns exact root test.ps1 and final cleanup.",
            "timing": "Run prepare after final evidence/docs/test.ps1 updates; rerun prepare if any changes before archive.",
            "excluded": ["exe", "map", "lib", "exp", "obj", "pdb", "tmp", "model/SDK payloads"],
            "failures": "All eligible stage logs/receipts/old numeric directories retained, including pre-GPU numeric identity failure and failed compile/link attempts."})
        print("PREPARED", len(rows), "payload files;", len(targets), "exact derived targets;", len(unknown), "unclassified", flush=True)
        return
    prepared = read(STAGE / "archive-plan.json")
    if prepared["build_plan"] != identity(path):
        raise ValueError("Build plan drift; rerun prepare")
    payload = inventory(plan)
    if set(payload) != {row["name"] for row in prepared["payload"]}:
        raise ValueError("Evidence inventory changed; rerun prepare after all processes finish")
    for row in prepared["payload"]:
        if identity(Path(row["path"])) != {key: row[key] for key in ("path", "bytes", "sha256")}:
            raise ValueError("Evidence/source changed; rerun prepare: " + row["path"])
    if DEST.exists():
        raise ValueError("Refusing to overwrite archive")
    for name in ("archive-plan.json", "archive-source-freeze.json", "model-references.json", "reclaim-targets.json"):
        payload["stage/" + name] = STAGE / name
    DEST.parent.mkdir(parents=True, exist_ok=True)
    manifest = []
    with zipfile.ZipFile(DEST, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, source in sorted(payload.items()):
            row = identity(source)
            archive.write(source, name)
            manifest.append({"name": name, "bytes": row["bytes"], "sha256": row["sha256"]})
        archive.writestr("manifest.json", json.dumps(manifest, indent=2))
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive CRC mismatch")
        for row in manifest:
            with archive.open(row["name"]) as stream:
                if digest(stream) != row["sha256"] or archive.getinfo(row["name"]).file_size != row["bytes"]:
                    raise ValueError("Archive payload SHA mismatch: " + row["name"])
    proof = {**identity(DEST), "entries": len(manifest), "CRC_and_payload_SHA_verified": True,
             "reclaim_manifest": identity(STAGE / "reclaim-targets.json"), "files_deleted": 0}
    save(STAGE / "archive-verification.json", proof)
    print(json.dumps(proof), flush=True)


if __name__ == "__main__":
    main()
