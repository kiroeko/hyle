// A captured public-Graph step, rotating >64MiB of immutable weights to avoid
// turning the model's DRAM workload into a single hot-L2 matrix benchmark.
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/cublas.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/graph/cuda.h"
#include <cuda_runtime_api.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace mem = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
void cuda_check(cudaError_t error) {
  if (error != cudaSuccess) throw std::runtime_error(cudaGetErrorString(error));
}
double median(std::vector<double> values) {
  std::sort(values.begin(), values.end());
  return (values[(values.size() - 1) / 2] + values[values.size() / 2]) / 2;
}
int main(int argc, char **argv) try {
  if (argc != 5) throw std::runtime_error("arm K N measured_steps");
  const std::string arm = argv[1];
  if (arm != "ggml" && arm != "cublas") throw std::runtime_error("unknown arm");
  const auto k = std::stoll(argv[2]), n = std::stoll(argv[3]);
  const auto steps = std::stoi(argv[4]);
  if (k <= 0 || n <= 0 || steps < 32) throw std::runtime_error("invalid geometry");
  auto context = take(c::Context::create(take(c::cuda::device(0)),
      arm == "ggml" ? c::ggml_cuda::provider() : c::cublas::provider()));
  auto memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  const auto stream = take(c::cuda::stream(queue));
  const auto desc = [](std::int64_t rows, std::int64_t columns) {
    const std::array shape{rows, columns};
    return take(c::TensorDesc::dense(c::DataType::kBFloat16, shape));
  };
  const auto x_desc = desc(1, k), w_desc = take(desc(n, k).transposed());
  const auto y_desc = desc(1, n);
  const auto weight_bytes = take(w_desc.required_bytes());
  const auto banks = std::max<std::size_t>(1, (64U << 20) / weight_bytes + 1);
  if (banks > 16) throw std::runtime_error("use a real model projection size");
  auto x = take(mem::Buffer::create(memory.ref(), take(x_desc.required_bytes()), 256));
  std::vector<std::uint16_t> host(static_cast<std::size_t>(k * n));
  std::uint32_t random = 0x1827abcd;
  for (auto &value : host) {
    random ^= random << 13; random ^= random >> 17; random ^= random << 5;
    value = static_cast<std::uint16_t>((random & 0x807fU) | (0x3dU << 8));
  }
  check(x.view().write(std::as_bytes(std::span(host).first(static_cast<std::size_t>(k)))));
  std::vector<mem::Buffer> weights, outputs;
  for (std::size_t bank = 0; bank < banks; ++bank) {
    weights.push_back(take(mem::Buffer::create(memory.ref(), weight_bytes, 256)));
    check(weights.back().view().write(std::as_bytes(std::span(host))));
    outputs.push_back(take(mem::Buffer::create(memory.ref(), take(y_desc.required_bytes()), 256)));
  }
  host.clear(); host.shrink_to_fit();
  auto builder = take(g::GraphBuilder::create());
  const auto a = take(builder.input(x_desc)), b = take(builder.input(w_desc));
  const auto y = take(builder.add(c::MatMul{}, a, b));
  check(builder.publish(y));
  const auto graph = take(std::move(builder).finish());
  auto compiled = take(g::cuda::compile(graph, context, memory.ref()));
  std::vector<g::Invocation> runs;
  for (std::size_t bank = 0; bank < banks; ++bank) {
    runs.push_back(take(compiled.executable.create_invocation()));
    auto &run = runs.back();
    check(run.bind(a, take(c::ConstTensorView::create(x_desc, x.view()))));
    check(run.bind(b, take(c::ConstTensorView::create(w_desc, weights[bank].view()))));
    check(run.bind(y, take(c::TensorView::create(y_desc, outputs[bank].view()))));
    check(g::cuda::prepare_replay(run, queue, {.mode = g::ReplayMode::kRequireCapture}));
    if (run.replay_route() != g::ReplayRoute::kCaptured)
      throw std::runtime_error("both arms must actually capture");
  }
  cudaEvent_t start{}, end{};
  cuda_check(cudaEventCreate(&start)); cuda_check(cudaEventCreate(&end));
  std::vector<double> wall, timeline;
  const auto warmup = std::max<std::size_t>(12, 3 * banks);
  for (std::size_t step = 0; step < warmup + static_cast<std::size_t>(steps); ++step) {
    auto &run = runs[step % banks];
    const auto before = std::chrono::steady_clock::now();
    cuda_check(cudaEventRecord(start, stream));
    auto done = take(run.submit(queue));
    cuda_check(cudaEventRecord(end, stream));
    check(done.wait());
    cuda_check(cudaEventSynchronize(end));
    const auto after = std::chrono::steady_clock::now();
    float milliseconds = 0;
    cuda_check(cudaEventElapsedTime(&milliseconds, start, end));
    if (step >= warmup) {
      wall.push_back(std::chrono::duration<double, std::micro>(after - before).count());
      timeline.push_back(milliseconds * 1000.0);
    }
  }
  cuda_check(cudaEventDestroy(end)); cuda_check(cudaEventDestroy(start));
  std::cout << "{\"arm\":\"" << arm << "\",\"K\":" << k << ",\"N\":" << n
      << ",\"banks\":" << banks << ",\"weight_bytes\":" << weight_bytes
      << ",\"steps\":" << steps << ",\"captured\":true,\"wall_us_median\":" << median(wall)
      << ",\"stream_us_median\":" << median(timeline) << "}\n";
  // Stream timing includes launch admission gaps; it is not kernel-only time.
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
