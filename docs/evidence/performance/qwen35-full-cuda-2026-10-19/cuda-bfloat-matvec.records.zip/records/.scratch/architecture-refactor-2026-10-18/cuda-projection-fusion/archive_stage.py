"""Archive a final summary, verify it, then write (never run) root test.ps1.

summary.json supplies source_files and proofs:{new_tests,legacy_cuda,Qwen,bench}.
Failed attempts remain evidence; only the four final proofs qualify cleanup.
"""
from pathlib import Path
import hashlib
import json
import os
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ARCHIVE = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-bfloat-matvec.zip'
IMAGES = {'.exe', '.map', '.lib', '.exp'}
EXCLUDED = {'sdk', '_deps', 'objects', 'obj', 'tmp', 'cache', '.cache', '__pycache__'}
EXCLUDED_SUFFIXES = IMAGES | {'.obj', '.o', '.tmp', '.pyc', '.pdb', '.ilk'}


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def digest(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
        value.update(block)
    return value.hexdigest()


def identity(path):
    with path.open('rb') as stream:
        return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(stream)}


def local(value, base):
    path = (base / value).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        raise ValueError(f'Missing/outside repository: {path}')
    return path


def frozen_read(path, records):
    data = path.read_bytes()
    records[path] = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return json.loads(data.decode('utf-8-sig'))


def files(directory):
    for folder, dirs, names in os.walk(directory):
        dirs[:] = sorted(name for name in dirs if name.lower() not in EXCLUDED)
        for name in sorted(names):
            path = Path(folder) / name
            if path.suffix.lower() not in EXCLUDED_SUFFIXES and name != 'archive-verification.json':
                yield local(str(path), ROOT)


def main():
    if ARCHIVE.exists():
        raise ValueError('Archive already exists; this is a one-shot operation')
    validated = {}
    summary = frozen_read(STAGE / 'summary.json', validated)
    proofs = {name: local(summary['proofs'][name], STAGE) for name in ('new_tests', 'legacy_cuda', 'Qwen', 'bench')}
    if len(set(proofs.values())) != 4:
        raise ValueError('The four final proofs must be distinct')
    new, legacy, qwen, bench = (frozen_read(path, validated) for path in proofs.values())
    for proof, count in ((new, 2), (legacy, 5)):
        if len(proof['cases']) != count or len(set(proof['cases'])) != count or proof['failures'] != 0 or proof['skipped'] != 0:
            raise ValueError(f'Final test proof needs {count} passed, unskipped cases')
    captures = qwen['capture_counts']
    if qwen['equal_vectors'] != 64 or qwen['equal_token_ids'] != 32 or qwen['capture_counts_equal'] is not True or len(captures) != 32 or any(len(row) != 2 or any(int(n) < 0 for n in row) for row in captures):
        raise ValueError('Qwen vector/token/capture proof is incomplete')
    if len(bench['results']) != 3 or len({row['shape'] for row in bench['results']}) != 3 or bench['remaining_shapes'] != 0 or any(len(row['runs']) != 6 for row in bench['results']):
        raise ValueError('Bench proof needs three completed shapes and six runs each')
    sources = [local(name, ROOT) for name in summary['source_files']]
    if not sources or len(set(sources)) != len(sources):
        raise ValueError('Source list is empty or duplicated')
    for path in sources:
        if path.suffix.lower() in EXCLUDED_SUFFIXES or '\0' in path.read_text(encoding='utf-8-sig'):
            raise ValueError(f'Not a text source: {path}')
    frozen = [identity(path) for path in sources]
    freeze = STAGE / 'archive-source-freeze.json'
    if freeze.exists() and json.loads(freeze.read_text()) != frozen:
        raise ValueError('Frozen source identity drifted')
    save(freeze, frozen)
    targets = [identity(path.resolve()) for path in sorted(STAGE.rglob('*')) if path.is_file() and path.suffix.lower() in IMAGES and path.resolve().is_relative_to(STAGE) and not EXCLUDED.intersection(part.lower() for part in path.relative_to(STAGE).parts)]
    if len(targets) < 12:
        raise ValueError('Expected at least twelve exact new-stage image targets')
    save(STAGE / 'reclaim-targets.json', targets)
    script = r'''param([switch]$ReclaimBfloatMatvec)
$ErrorActionPreference = 'Stop'
if (-not $ReclaimBfloatMatvec) { throw 'Use -ReclaimBfloatMatvec for reviewed exact targets.' }
$taskRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/architecture-refactor-2026-10-18/cuda-projection-fusion'))
$receipt = Join-Path $taskRoot 'reclaim-receipt.json'
if (Test-Path -LiteralPath $receipt) { throw 'Reclaim already recorded.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'archive-verification.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $proof.path -Algorithm SHA256).Hash -ne $proof.sha256) { throw 'Archive changed.' }
if ((Get-FileHash -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Algorithm SHA256).Hash -ne $proof.reclaim_manifest.sha256) { throw 'Reclaim plan changed.' }
$targets = @(Get-Content -LiteralPath (Join-Path $taskRoot 'reclaim-targets.json') -Raw | ConvertFrom-Json)
foreach ($entry in $targets) {
  $resolved = (Resolve-Path -LiteralPath $entry.path).Path
  if (-not $resolved.StartsWith($taskRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task: $resolved" }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or $item.Extension -notin @('.exe','.map','.lib','.exp') -or $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Target changed: $resolved" }
}
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path }
@{targets=$targets;archive=$proof;recursive=$false;objects_retained=$true;raw_vectors_retained=$true} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receipt -Encoding utf8
'''
    (STAGE / 'reclaim-script.ps1').write_text(script, encoding='utf-8-sig')
    payload = {}
    for directory in {STAGE, *(path.parent for path in proofs.values())}:
        if directory != STAGE and directory in STAGE.parents:
            raise ValueError('A proof directory would include unrelated stages')
        for path in files(directory):
            payload[path.relative_to(ROOT).as_posix()] = path
    payload.update({'source-current/' + path.relative_to(ROOT).as_posix(): path for path in sources})
    records = {name: identity(path) for name, path in sorted(payload.items())}
    expected = {path.relative_to(ROOT).as_posix(): row for path, row in validated.items()}
    expected.update({'source-current/' + path.relative_to(ROOT).as_posix(): row for path, row in zip(sources, frozen)})
    if any(records[name] != row for name, row in expected.items()):
        raise ValueError('Validated proof/source changed before archiving')
    raw = {path for path in payload.values() if path.suffix.lower() in {'.bf16', '.f32'}}
    if len(raw) != 64 or len(qwen['vectors']) != 64 or len({row['path'] for row in qwen['vectors']}) != 64:
        raise ValueError('Expected the complete 64 raw Qwen vectors')
    for row in qwen['vectors']:
        matches = [path for path in raw if path.as_posix().endswith('/' + row['path'].replace('\\', '/'))]
        if len(matches) != 1 or any(identity(matches[0])[key] != row[key] for key in ('bytes', 'sha256')):
            raise ValueError(f'Raw vector differs from proof: {row["path"]}')
    failed = []
    for name, path in payload.items():
        if path.name.endswith('.result.json') and 'compile' in path.name:
            result = json.loads(path.read_text(encoding='utf-8-sig'))
            if result.get('terminal') is True and isinstance(result.get('exit'), int) and result['exit'] != 0:
                failed.append(name)
    if not failed:
        raise ValueError('The original failed native compilation evidence is missing')
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(payload.items()):
            archive.write(path, name)
        archive.writestr('_manifest.json', json.dumps(records, indent=2))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(records) + 1 or set(archive.namelist()) != set(records) | {'_manifest.json'}:
            raise ValueError('ZIP CRC/directory verification failed')
        for name, row in records.items():
            with archive.open(name) as stream:
                if archive.getinfo(name).file_size != row['bytes'] or digest(stream) != row['sha256']:
                    raise ValueError(f'ZIP payload verification failed: {name}')
    if [identity(path) for path in sources] != frozen or any(identity(path) != row for path, row in validated.items()):
        raise ValueError('Source or validated proof changed while archiving')
    proof = dict(identity(ARCHIVE), payload_files=len(records), CRC_and_SHA256_verified=True,
                 failed_compilation_results=failed, raw_vectors=64, reclaim_manifest=identity(STAGE / 'reclaim-targets.json'))
    save(STAGE / 'archive-verification.json', proof)
    (ROOT / 'test.ps1').write_text(script, encoding='utf-8-sig')
    print(json.dumps({'archive': proof, 'reclaim_files': len(targets), 'reclaim_bytes': sum(row['bytes'] for row in targets)}, indent=2))


if __name__ == '__main__':
    main()
