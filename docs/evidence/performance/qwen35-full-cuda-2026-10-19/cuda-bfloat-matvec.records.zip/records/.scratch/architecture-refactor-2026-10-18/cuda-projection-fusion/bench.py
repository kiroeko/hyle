"""One cached host compile/link, or one explicit captured matvec bench run.

Default/--dry-run only records a plan. --build compiles matvec_bench.cc and
replaces the successful Qwen closure's consumer object. --run requires one
arm/geometry/prefix; the caller serializes the six paired runs. No SDK rebuild.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import json
import re
import sys
import uuid

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("projection_build", STAGE / "build.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
c, ARCH, ROOT = b.c, b.ARCH, b.ROOT
BASE = STAGE / "checks/20261019T054525-686f560d/qwen-link-plan.json"
RECIPE = ARCH / "cold-constant-retirement/cuda-checks/20261019T051553-817e50eb/consumer-identity.json"
OLD_CONSUMER = RECIPE.parent / "consumer.obj"
SOURCE = STAGE / "matvec_bench.cc"


def make_plan(base):
    base = Path(base).resolve()
    original = c.read(base)
    proof = c.read(base.parent / "build-summary.json")
    if proof.get("terminal") is not True or proof.get("exit") != 0:
        raise ValueError("The selected Qwen increment must have finished successfully")
    if len(original["inputs"]) != 122:
        raise ValueError("Expected the successful122-input native matvec Qwen closure")
    if original["command"].count(str(OLD_CONSUMER)) != 1:
        raise ValueError("Expected one explicit Qwen consumer object to replace")
    for row in original["inputs"]:
        if not b.same(row):
            raise ValueError("Retained input missing/changed: " + row["path"])
    session = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    out = STAGE / "bench-checks" / session
    out.mkdir(parents=True, exist_ok=False)
    recipe = c.read(RECIPE)
    command = b.host_command(recipe["command"], SOURCE, "bench", out)
    linked = [str(out / "bench.obj") if arg == str(OLD_CONSUMER) else arg
              for arg in original["command"]
              if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
    image = out / "matvec-bench.exe"
    linked += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
               "/IMPLIB:" + str(image.with_suffix(".lib"))]
    inputs = [arg for arg in linked if not arg.startswith("/") and Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib")]
    if len(inputs) != len(original["inputs"]) or str(OLD_CONSUMER) in inputs:
        raise ValueError("The benchmark must replace only the consumer object")
    env, runtime = b.environment(linked, inputs, out)
    sdk = c.sdk_libraries(linked, env)
    if any(row["resolved"] is None for row in sdk):
        raise ValueError("A named Windows SDK library is missing")
    headers = [b.identity(path) for path in sorted(b.host_dependencies(recipe["command"]), key=str)]
    plan = {"schema": "hyle.projection_matvec.bench_plan.v1", "source": b.identity(SOURCE),
        "recipe": b.identity(RECIPE), "compile": command, "object": str(out / "bench.obj"),
        "base_link_plan": b.identity(base), "base_build_proof": b.identity(base.parent / "build-summary.json"),
        "cached_inputs": original["inputs"], "headers": headers,
        "link": linked, "inputs": inputs, "image": str(image),
        "absolute_input_count": len(inputs), "runtime_path_directories": runtime,
        "named_sdk_libraries": sdk, "compile_TUs": 1, "SDK_build": False,
        "object_dependency_copy": False, "GPU_run": False,
        "paired_run_order": ["cublas", "ggml", "ggml", "cublas", "cublas", "ggml"],
        "run_scope": "One explicit arm/geometry/prefix per --run; root owns serial pairing and the GPU window."}
    path = out / "plan.json"
    c.save(path, plan)
    print("PLAN", str(path), "host_TUs1 link_inputs", len(inputs), flush=True)
    return path


def load_plan(path):
    path = Path(path).resolve()
    if not path.is_relative_to(STAGE / "bench-checks") or path.name != "plan.json":
        raise ValueError("Expected this stage's bench-checks/<session>/plan.json")
    return path, c.read(path)


def verify(plan):
    for row in [plan["source"], plan["recipe"], plan["base_link_plan"], plan["base_build_proof"]] + plan["headers"] + plan["cached_inputs"]:
        if not b.same(row):
            raise ValueError("Frozen benchmark source/recipe/header/input drift: " + row["path"])


def build(path):
    path, plan = load_plan(path)
    out = path.parent
    if (out / "bench-compile.command.json").exists():
        raise ValueError("Preserve the attempt; create a new plan to retry")
    verify(plan)
    (out / "tmp").mkdir()
    env, _ = b.environment(plan["link"], plan["inputs"], out)
    c.execute("bench-compile", plan["compile"], env, out)
    verify(plan)
    c.save(out / "bench-identity.json", {"source": plan["source"], "object": b.identity(plan["object"]),
        "recipe": plan["recipe"], "command": plan["compile"]})
    link_path = out / "bench-link-plan.json"
    c.save(link_path, {"command": plan["link"], "inputs": [b.identity(x) for x in plan["inputs"]],
        "base": plan["base_link_plan"], "build_plan": b.identity(path), "SDK_build": False,
        "object_dependency_copy": False})
    c.execute("bench-link", plan["link"], env, out)
    c.save(out / "bench-image.json", {"image": b.identity(plan["image"]), "link_plan": b.identity(link_path)})
    c.save(out / "build-summary.json", {"terminal": True, "exit": 0, "compile_TUs": 1,
        "image": b.identity(plan["image"]), "GPU_run": False})
    c.save(STAGE / "last-bench-build.json", {"plan": b.identity(path)})
    print("BUILT", str(out / "bench-image.json"), flush=True)


def run(path, args):
    path, plan = load_plan(path)
    out = path.parent
    if not args.arm or args.K is None or args.N is None or not args.prefix:
        raise ValueError("--run requires --arm ggml|cublas --K --N --prefix")
    if args.K <= 0 or args.N <= 0 or args.steps < 32:
        raise ValueError("Positive K/N and at least32 measured steps required")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", args.prefix):
        raise ValueError("Use a plain unique filename prefix")
    if c.read(out / "build-summary.json").get("exit") != 0:
        raise ValueError("Benchmark compile/link has not succeeded")
    image = c.read(out / "bench-image.json")
    if not b.same(image["image"]) or not b.same(image["link_plan"]):
        raise ValueError("Benchmark image/link identity drift")
    runs = out / "runs"
    runs.mkdir(exist_ok=True)
    if any(runs.glob(args.prefix + ".*")) or (runs / (args.prefix + "-inputs.json")).exists():
        raise ValueError("Run prefix already exists; no implicit retry or overwrite")
    env, _ = b.environment(plan["link"], plan["inputs"], out)
    command = [image["image"]["path"], args.arm, str(args.K), str(args.N), str(args.steps)]
    c.save(runs / (args.prefix + "-inputs.json"), {"image": image["image"],
        "source": plan["source"], "command": command, "profiler": False,
        "memory_monitor": False, "scope": "Isolated captured public Graph MatMul, not full-model throughput."})
    c.execute(args.prefix, command, env, runs)
    lines = (runs / (args.prefix + ".stdout.log")).read_text(encoding="utf-8-sig").splitlines()
    metrics = json.loads(next(line for line in reversed(lines) if line.startswith("{")))
    if any(metrics.get(key) != value for key, value in (
        ("arm", args.arm), ("K", args.K), ("N", args.N), ("steps", args.steps), ("captured", True))):
        raise ValueError("Benchmark output does not match the exact request")
    if metrics["banks"] * metrics["weight_bytes"] <= 64 * 1024 * 1024:
        raise ValueError("Weight bank ring does not exceed64MiB")
    c.save(runs / (args.prefix + "-metrics.json"), {"metrics": metrics, "image": image["image"],
        "source": plan["source"], "kernel_only_timing": False,
        "scope": "Wall includes event APIs/submit/wait; stream interval includes launch/admission gaps."})
    print(json.dumps(metrics), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--build", action="store_true")
    mode.add_argument("--run", action="store_true")
    parser.add_argument("--plan")
    parser.add_argument("--base-link", default=str(BASE))
    parser.add_argument("--arm", choices=("ggml", "cublas"))
    parser.add_argument("--K", type=int)
    parser.add_argument("--N", type=int)
    parser.add_argument("--steps", type=int, default=128)
    parser.add_argument("--prefix")
    args = parser.parse_args()
    if args.run:
        path = args.plan or c.read(STAGE / "last-bench-build.json")["plan"]["path"]
        run(path, args)
    elif args.build:
        build(args.plan or make_plan(args.base_link))
    elif args.plan:
        parser.error("--plan is for --build or --run")
    else:
        make_plan(args.base_link)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError, StopIteration) as error:
        print("ERROR:", error, file=sys.stderr, flush=True)
        raise SystemExit(1)
