"""Run three serialized AB/BA/AB pairs per real decode projection geometry."""
from pathlib import Path
import argparse
import json
import statistics
import subprocess
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
ORDER = ("cublas", "ggml", "ggml", "cublas", "cublas", "ggml")
SHAPES = (("gate", 2048, 6144), ("down", 6144, 2048), ("head", 2048, 248320))


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({"order": ORDER, "shapes": SHAPES, "steps": 128,
                          "run": False, "profiler": False}))
        return
    # Two already executed first-pair gate runs are reused only with their
    # successful command/exit, exact arguments and image identity verified.
    build = read(STAGE / "last-bench-build.json")
    bench_dir = Path(build["plan"]["path"]).parent
    image = read(bench_dir / "bench-image.json")["image"]
    results = []
    for label, k, n in SHAPES:
        rows = []
        for index, arm in enumerate(ORDER, 1):
            prefix = f"{label}-{index:02d}-{arm}"
            path = bench_dir / "runs" / (prefix + "-metrics.json")
            if path.exists():
                if label != "gate" or index > 2:
                    raise ValueError("No implicit result replay: " + prefix)
                terminal = read(path.with_name(prefix + ".result.json"))
                if terminal["exit"] != 0 or not terminal["terminal"]:
                    raise ValueError("Previously executed run was not successful")
            else:
                subprocess.run([sys.executable, str(STAGE / "bench.py"), "--run",
                    "--arm", arm, "--K", str(k), "--N", str(n), "--steps", "128",
                    "--prefix", prefix], cwd=ROOT, check=True)
            row = read(path)
            if row["image"] != image or any(row["metrics"][name] != value for name, value in
                    (("K", k), ("N", n), ("arm", arm), ("steps", 128))):
                raise ValueError("Pair does not use the same benchmark/geometry")
            rows.append(row["metrics"])
        groups = {arm: {name: statistics.median(row[name] for row in rows if row["arm"] == arm)
                        for name in ("wall_us_median", "stream_us_median")}
                  for arm in ("cublas", "ggml")}
        ratios = {name: groups["ggml"][name] / groups["cublas"][name]
                  for name in groups["ggml"]}
        result = {"shape": label, "K": k, "N": n, "runs": rows, "groups": groups,
                  "ggml_over_cublas": ratios, "statistical_significance": False}
        results.append(result)
        (STAGE / "bench-pairs-results.json").write_text(json.dumps({"results": results,
            "remaining_shapes": len(SHAPES) - len(results), "image": image,
            "kernel_only_timing": False, "model_throughput_claim": False}, indent=2) + "\n")
        print("SHAPE", label, json.dumps({"groups": groups, "ratio": ratios}), flush=True)


if __name__ == "__main__":
    main()
