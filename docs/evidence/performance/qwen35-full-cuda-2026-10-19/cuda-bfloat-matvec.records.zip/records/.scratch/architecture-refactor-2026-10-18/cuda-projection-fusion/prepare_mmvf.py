"""Compose only the typed BF16 MMVF source/manifest entry; never compile."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-cuda/mmvf.cu')
raw = UPSTREAM.read_bytes()
original = raw.decode().replace('\r\n', '\n')
source, edits = original, []

def edit(before, after, count=1):
    global source
    if source.count(before) != count:
        raise ValueError(f'Expected {count} exact MMVF contexts: {before[:100]!r}')
    # Manifest edits are sequential, one matched occurrence apiece.
    for _ in range(count):
        source = source.replace(before, after, 1)
        edits.append({'before': before, 'after': after})

edit('template <typename T, typename type_acc, int ncols_dst, int block_size, bool has_fusion = false, bool is_multi_token_id = false>',
     'template <typename T, typename type_acc, int ncols_dst, int block_size, bool has_fusion = false, bool is_multi_token_id = false, typename Y = float, typename Dst = float>')
edit('const T * x_ptr, const float * y_ptr, const int32_t * ids_ptr, const ggml_cuda_mm_fusion_args_device fusion, float * dst_ptr,',
     'const T * x_ptr, const Y * y_ptr, const int32_t * ids_ptr, const ggml_cuda_mm_fusion_args_device fusion, Dst * dst_ptr,')
edit('    const float   * GGML_CUDA_RESTRICT y   = y_ptr;',
     '    const Y       * GGML_CUDA_RESTRICT y   = y_ptr;')
edit('    float         * GGML_CUDA_RESTRICT dst = dst_ptr;',
     '    Dst           * GGML_CUDA_RESTRICT dst = dst_ptr;')
edit('    const float2 * y2 = (const float2 *) y;', '''    // Pair indices and all y strides remain measured in Y elements.
    // The existing float path keeps its original float2 load exactly.
    const auto load_pair = [y](int64_t index) {
        if constexpr (std::is_same_v<Y, float>) {
            return ((const float2 *) y)[index];
        } else {
            static_assert(std::is_same_v<Y, nv_bfloat16>);
            const nv_bfloat162 pair = ((const nv_bfloat162 *) y)[index];
            return make_float2(ggml_cuda_cast<float>(pair.x), ggml_cuda_cast<float>(pair.y));
        }
    };''')
edit('const float2 tmpy = y2[j*stride_col_y2 + col2];',
     'const float2 tmpy = load_pair(j*stride_col_y2 + col2);', 5)
edit('    dst[tid*stride_col_dst + row] = value;', '''    if constexpr (std::is_same_v<Dst, nv_bfloat16>) {
        dst[tid*stride_col_dst + row] = __float2bfloat16_rn(value);
    } else {
        dst[tid*stride_col_dst + row] = value;
    }''')
edit('template<typename T, typename type_acc, int ncols_dst, int block_size, bool is_multi_token_id = false>',
     'template<typename T, typename type_acc, int ncols_dst, int block_size, bool is_multi_token_id = false, typename Y = float, typename Dst = float>')
edit('template <typename T, typename type_acc, int ncols_dst, bool is_multi_token_id = false>',
     'template <typename T, typename type_acc, int ncols_dst, bool is_multi_token_id = false, typename Y = float, typename Dst = float>')
edit('template <typename T, typename type_acc>\nstatic void mul_mat_vec_f_cuda_switch_ncols_dst(',
     'template <typename T, typename type_acc, typename Y = float, typename Dst = float>\nstatic void mul_mat_vec_f_cuda_switch_ncols_dst(')
edit('template<typename T>\nstatic void mul_mat_vec_f_cuda(',
     'template<typename T, typename Y = float, typename Dst = float>\nstatic void mul_mat_vec_f_cuda(')
edit('const T * x, const float * y, const int32_t * ids, const ggml_cuda_mm_fusion_args_device fusion, float * dst,',
     'const T * x, const Y * y, const int32_t * ids, const ggml_cuda_mm_fusion_args_device fusion, Dst * dst,', 4)
edit('if constexpr (ncols_dst == 1) {',
     'if constexpr (ncols_dst == 1 && std::is_same_v<Y, float> && std::is_same_v<Dst, float>) {')
edit('mul_mat_vec_f<T, type_acc, ncols_dst, block_size, true, is_multi_token_id>',
     'mul_mat_vec_f<T, type_acc, ncols_dst, block_size, true, is_multi_token_id, Y, Dst>')
edit('mul_mat_vec_f<T, type_acc, ncols_dst, block_size, false, is_multi_token_id>',
     'mul_mat_vec_f<T, type_acc, ncols_dst, block_size, false, is_multi_token_id, Y, Dst>')
start = source.index('    if constexpr(std::is_same_v<T, half>) {', source.index('static void mul_mat_vec_f_cuda('))
end = source.index('\n}\n\nvoid ggml_cuda_mul_mat_vec_f(', start)
old_dispatch = source[start:end]
typed_dispatch = '''    if constexpr (std::is_same_v<Y, nv_bfloat16> || std::is_same_v<Dst, nv_bfloat16>) {
        static_assert(std::is_same_v<T, nv_bfloat16> && std::is_same_v<Y, nv_bfloat16> && std::is_same_v<Dst, nv_bfloat16>);
        GGML_ASSERT(!ids && ncols_dst == 1 && prec == GGML_PREC_F32);
        GGML_ASSERT(!fusion.gate && !fusion.x_bias && !fusion.gate_bias && !fusion.x_scale && !fusion.gate_scale);
        // Only instantiate the admitted single-column carrier. No ID/GLU or
        // multi-column BF16 variants are exposed by this private extension.
        launch_mul_mat_vec_f_cuda<T, float, 1>(
            x, y, ids, fusion, dst, ncols, nrows, stride_row, stride_col_y, stride_col_dst,
            nchannels_x, nchannels_y, nchannels_dst, stride_channel_x, stride_channel_y,
            stride_channel_dst, nsamples_x, nsamples_dst, stride_sample_x, stride_sample_y, stride_sample_dst,
            nsamples_dst, ids_stride, stream);
    } else {
''' + ''.join('    ' + line + '\n' for line in old_dispatch.splitlines()).rstrip('\n') + '\n    }'
edit(old_dispatch, typed_dispatch)
edit('''    GGML_ASSERT(        src1->type == GGML_TYPE_F32);
    GGML_ASSERT(!ids ||  ids->type == GGML_TYPE_I32);
    GGML_ASSERT(         dst->type == GGML_TYPE_F32);''', '''    const bool bf16_io = src1->type == GGML_TYPE_BF16 && dst->type == GGML_TYPE_BF16;
    GGML_ASSERT(bf16_io || src1->type == GGML_TYPE_F32);
    GGML_ASSERT(!ids || ids->type == GGML_TYPE_I32);
    GGML_ASSERT(bf16_io || dst->type == GGML_TYPE_F32);''')
edit('''    const enum ggml_prec prec = fast_fp16_available(cc) ? ggml_prec(dst->op_params[0]) : GGML_PREC_F32;

    const float   * src1_d''', '''    const enum ggml_prec prec = fast_fp16_available(cc) ? ggml_prec(dst->op_params[0]) : GGML_PREC_F32;

    if (bf16_io) {
        GGML_ASSERT(src0->type == GGML_TYPE_BF16 && !ids && !fusion);
        GGML_ASSERT(ne1 == 1 && ne11 == 1 && ggml_prec(dst->op_params[0]) == GGML_PREC_F32);
        GGML_ASSERT(ggml_is_contiguous(src0) && ggml_is_contiguous(src1) && ggml_is_contiguous(dst));
        GGML_ASSERT(ggml_cuda_should_use_mmvf(src0->type, cc, src0->ne, src0->nb, 1));
        const nv_bfloat16 * src0_d = (const nv_bfloat16 *) src0->data;
        const nv_bfloat16 * src1_d = (const nv_bfloat16 *) src1->data;
        nv_bfloat16 * dst_d = (nv_bfloat16 *) dst->data;
        const ggml_cuda_mm_fusion_args_device empty{};
        mul_mat_vec_f_cuda(src0_d, src1_d, nullptr, empty, dst_d, ne00, ne01, 1,
            nb01 / ts_src0, nb11 / ts_src1, nb1 / ts_dst,
            ne02, ne12, ne2, nb02 / ts_src0, nb12 / ts_src1, nb2 / ts_dst,
            ne03, ne3, nb03 / ts_src0, nb13 / ts_src1, nb3 / ts_dst,
            0, GGML_PREC_F32, ctx.stream());
        return;
    }

    const float   * src1_d''')
# Production composition requires each edit to have exactly one match. Group
# repeated typed signatures/load sites with enough original surrounding lines.
old_lines, new_lines = original.splitlines(True), source.splitlines(True)
for context in (3, 5, 8, 12, 20):
    unique, verified = [], original
    for group in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_grouped_opcodes(context):
        before_text = ''.join(old_lines[group[0][1]:group[-1][2]])
        after_text = ''.join(new_lines[group[0][3]:group[-1][4]])
        if verified.count(before_text) != 1:
            break
        verified = verified.replace(before_text, after_text, 1)
        unique.append({'before': before_text, 'after': after_text})
    else:
        if verified == source:
            edits = unique
            break
else:
    raise ValueError('Could not construct unique exact MMVF edit contexts')
entry = {'path': 'src/ggml-cuda/mmvf.cu',
         'before_sha256': hashlib.sha256(original.encode()).hexdigest(),
         'after_sha256': hashlib.sha256(source.encode()).hexdigest(), 'edits': edits}
manifest_path = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
if any(row['path'] == entry['path'] for row in manifest['files']):
    raise ValueError('MMVF manifest entry already exists; do not replay composition')
before = STAGE / 'before-mmvf'
before.mkdir(exist_ok=False)
(before / 'patches.json').write_bytes(manifest_bytes)
(before / 'NOTICE.md').write_bytes((manifest_path.parent / 'NOTICE.md').read_bytes())
(before / 'mmvf.cu').write_bytes(raw)
candidate = STAGE / 'native-source/src/ggml-cuda/mmvf.cu'
candidate.parent.mkdir(parents=True, exist_ok=True)
candidate.write_bytes(source.encode())
(STAGE / 'mmvf-change.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile='upstream/mmvf.cu', tofile='candidate/mmvf.cu')), encoding='utf-8')
(STAGE / 'mmvf-manifest-entry.json').write_text(json.dumps(entry, indent=2) + '\n', encoding='utf-8')
manifest['files'].append(entry)
if manifest_path.read_bytes() != manifest_bytes:
    raise ValueError('Concurrent manifest mutation; preserve the new entry and reapply to latest manifest')
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'candidate': str(candidate), 'bytes': len(source.encode()), 'entry': {k:v for k,v in entry.items() if k != 'edits'}, 'edits':len(edits)}, indent=2))
