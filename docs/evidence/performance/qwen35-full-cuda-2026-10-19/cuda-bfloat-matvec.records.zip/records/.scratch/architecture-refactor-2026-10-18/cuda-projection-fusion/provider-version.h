#pragma once
#define HYLE_GGML_CUDA_PROVIDER_VERSION "hyle-ggml-cuda-resource-iq1-f32-causal-bf16-fusion-bf16-input-acc-stable-silu-bf16-matvec-v11+7caf606377daf938"
