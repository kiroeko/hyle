from pathlib import Path
import hashlib,json,zipfile,zlib
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
DEST=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-coarse-capture-reclaim.zip'
def identity(path):
 data=path.read_bytes()
 return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
receipt=json.loads((OUT/'cleanup-receipt.json').read_text(encoding='utf-8-sig'))
plan=json.loads((OUT/'cleanup-plan.json').read_text(encoding='utf-8-sig'))
assert receipt['complete'] and receipt['files']==12 and receipt['bytes']==402821651
assert receipt['deleted']==plan['targets']
assert len(receipt['retained_objects'])==53 and len(receipt['retained_raw_vectors'])==16
assert len(receipt['archives_verified'])==2
script=ROOT/'test.ps1'
assert identity(script)['sha256']==receipt['script_sha256']
assert script.read_bytes()==(OUT/'test.ps1').read_bytes()
inputs={'cleanup-receipt.json':OUT/'cleanup-receipt.json','cleanup-plan.json':OUT/'cleanup-plan.json',
        'test.ps1':script,'archive.py':Path(__file__)}
rows=[]
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,source in inputs.items():
  data=source.read_bytes();archive.writestr(name,data)
  rows.append(dict(name=name,**identity(source),crc32=f'{zlib.crc32(data)&0xffffffff:08x}'))
 manifest=dict(schema='hyle.cuda.coarse-capture.cleanup.archive.v1',executed=True,
   deleted_files=12,reclaimed_bytes=402821651,retained_objects=53,retained_raw_vectors=16,
   verified_archives=receipt['archives_verified'],entries=rows,
   note='The plan is the original pre-execution plan. cleanup-receipt.json records the completed execution. Main evidence archive unchanged; no additional deletions or tests.')
 archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
 assert archive.testzip() is None
 for row in rows:
  data=archive.read(row['name'])
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 archive_count=len(archive.infolist())
result=dict(archive=identity(DEST),entries=archive_count,crc_verified=True,
 every_payload_sha256_verified=True,deleted_files=12,reclaimed_bytes=402821651,
 main_archive_modified=False,no_new_deletions=True)
(OUT/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
