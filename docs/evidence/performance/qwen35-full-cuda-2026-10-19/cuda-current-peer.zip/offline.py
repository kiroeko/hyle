from pathlib import Path
import hashlib
import json
import statistics

HERE = Path(__file__).resolve().parent
ARCH = HERE.parent


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(name, value): (HERE / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


summary = read(HERE / 'summary.json')
rows = []
for run in summary['runs']:
    warm = run['phases'][7:]
    mean = lambda values: statistics.mean(values) * 1000
    if run['engine'] == 'hyle':
        split = dict(pre_submit=mean([p['step_seconds']-p['submit_to_token_seconds'] for p in warm]),
            submit_call=mean([p['submit_seconds'] for p in warm]),
            after_submit_through_token=mean([p['submit_to_token_seconds']-p['submit_seconds'] for p in warm]))
    else:
        split = {field:mean([p[field + '_seconds'] for p in warm]) for field in [
            'input_prepare', 'decode_return', 'synchronize', 'token_access', 'sample_fastpath']}
    rows.append(dict(tag=run['tag'], engine=run['engine'], pid=run['pid'], exit=run['exit'],
        phases='decode7..31 inclusive', count=25,
        warm_mean_step_ms=mean([p['step_seconds'] for p in warm]),
        warm_mean_wall_split_ms=split,
        warm7_31_tokens_per_second=run['warm7_31_tokens_per_second'],
        full31_tokens_per_second=run['full31_tokens_per_second'],
        prefill_tokens_per_second=run['prefill_tokens_per_second'],
        stdout=ident(HERE / run['stdout']), stderr=ident(HERE / run['stderr'])))
h, p = summary['medians']['hyle'], summary['medians']['peer']
report = dict(scope='Offline analysis of exactly the six completed unprofiled current-window runs; no new GPU/build.',
    pair_order=summary['pair_order'], per_run=rows, medians=summary['medians'],
    warm_time_gap_ms=1000/h['warm7_31_tokens_per_second']-1000/p['warm7_31_tokens_per_second'],
    hyle_warm_throughput_below_peer_fraction=1-h['warm7_31_tokens_per_second']/p['warm7_31_tokens_per_second'],
    full31_time_gap_ms=1000/h['full31_tokens_per_second']-1000/p['full31_tokens_per_second'],
    equality=dict(prompt_tokens=128, fixed_decode_inputs=31, context_capacity=256,
        all_32_predicted_ids_equal=True, all_three_runs_of_each_engine_equal=True,
        predicted_ids=summary['runs'][0]['predicted_ids']),
    parameters=dict(hyle_replay='prefer-capture', hyle_progress='direct', profiler=False, external_memory_monitor=False,
        peer_context_capacity=256, peer_batch_ubatch_capacity=128, peer_kv_dtype='BF16',
        hyle_dtype='existing BF16 boundaries', weights='Existing same-source BF16 safetensors/GGUF, no copies.'),
    boundaries=dict(hyle='Before position/token upload through Completion.wait and4B token readback;binds/layout/replay included;shape compile before step.',
        peer='Before batch preparation through llama_decode, synchronize, GPU greedy token access and public sampler fastpath. Lifecycle memory snapshots outside individual steps.',
        warning='Wall subintervals are additive chronology;decode_return/submit can overlap GPU. Synchronize/post-submit intervals are not pure GPU kernel time.'),
    old_reference=dict(peer_full31=104.052475, peer_warm7_31=105.824003,
        source='qwen-gpu-comparison/128-prefill/summary.json; historical50ms monitor,not this current window.'),
    conclusion='Current same-window gap is measured,not attributed. Historical105.8vs77.5 overstates this window difference. No quality acceptance or causal kernel claim.')
pairs = []
for i in range(0, 6, 2):
    hrow = next(r for r in rows[i:i+2] if r['engine'] == 'hyle')
    prow = next(r for r in rows[i:i+2] if r['engine'] == 'peer')
    hs, ps = hrow['warm_mean_wall_split_ms'], prow['warm_mean_wall_split_ms']
    before_delta = hs['pre_submit'] + hs['submit_call'] - ps['input_prepare'] - ps['decode_return']
    total_delta = hrow['warm_mean_step_ms'] - prow['warm_mean_step_ms']
    pairs.append(dict(pair=i//2+1, total_mean_step_difference_ms=total_delta,
        before_enqueue_API_return_wall_difference_ms=before_delta,
        after_enqueue_API_return_wall_difference_ms=total_delta-before_delta,
        before_return_fraction_of_wall_difference=before_delta/total_delta))
report['paired_wall_differences'] = pairs
report['current_gap_interpretation'] = [
    'Hyle preparation0.499..0.726ms is material relative to this current1.49ms median gap;the previous historical105.8 comparison cannot rule it out.',
    'Before enqueue API return wall difference is0.454..0.693ms,27..43% of each paired total difference. The code boundaries differ and GPU may overlap calls;this is not exclusive CPU attribution or fully removable time.',
    'The absolute step being dominated by wait does not establish that the remaining engine gap is GPU kernels. Current matched profiling is separate and pending.'
]
save('baseline-cost-report.json', report)
prior = read(ARCH / 'cuda-capture-reuse/validation/binding-reuse/final-selected-owners.json')
selected = set(read(HERE / 'hyle-link-plan.json')['command'])
sources = []
for owner in prior['current_local_owners']:
    if owner['object']['path'] not in selected: continue
    actual = ident(owner['source']['path'])
    assert actual == owner['source']
    sources.append(dict(source=actual, object=owner['object'], receipt=owner['receipt']))
inputs = {}
for name in ['hyle', 'peer']:
    plan = read(HERE / (name + '-link-plan.json'))
    for expected in plan['inputs']:
        actual = inputs.setdefault(expected['path'], ident(expected['path']))
        assert actual == expected
save('source-closure.json', dict(link_inputs=list(inputs.values()), link_input_drift=0,
    selected_current_hyle_sources=sources, selected_source_drift=0,
    retained_closure=ident(ARCH / 'cuda-capture-reuse/validation/binding-reuse/final-selected-owners.json'),
    hyle_plan=ident(HERE / 'hyle-link-plan.json'), peer_plan=ident(HERE / 'peer-link-plan.json'),
    native_and_SDK_compiles=0, host_compiles=0, no_objects_or_models_copied=True,
    images={name:read(HERE / (name + '-image.json')) for name in ['hyle', 'peer']}))
print(json.dumps(dict(medians=summary['medians'],warm_gap_ms=report['warm_time_gap_ms'],
    hyle_warm_below_peer=report['hyle_warm_throughput_below_peer_fraction'],current_sources=len(sources)),indent=2))
