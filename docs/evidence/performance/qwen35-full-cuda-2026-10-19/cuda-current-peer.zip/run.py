from pathlib import Path
import importlib.util
import json
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ARCH = HERE.parent
spec = importlib.util.spec_from_file_location('retained_capture_helpers', ARCH / 'cuda-capture-reuse/build.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
b = driver.previous
b.OUT = HERE
HYLE_PLAN = ARCH / 'cuda-capture-reuse/validation/binding-reuse/qwen-link-plan.json'
PEER_PLAN = ARCH / 'qwen-decode-native-route/peer-link-plan.json'


def runtime():
    paths = []
    for recipe in [HYLE_PLAN, PEER_PLAN]:
        paths += [str(Path(v).parent) for v in b.read(recipe)['command']
                  if Path(v).is_absolute() and v.lower().endswith('.lib')]
    b.ENV['PATH'] = os.pathsep.join(dict.fromkeys(paths)) + os.pathsep + b.ENV['PATH']


def link():
    for name, recipe in [('hyle', HYLE_PLAN), ('peer', PEER_PLAN)]:
        args = [v for v in b.read(recipe)['command']
                if not v.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        inputs = [b.ident(v) for v in args if Path(v).is_absolute() and Path(v).suffix.lower() in ['.obj', '.lib']]
        output = HERE / name
        assert not output.with_suffix('.exe').exists()
        args += ['/OUT:' + str(output.with_suffix('.exe')), '/MAP:' + str(output.with_suffix('.map')),
                 '/IMPLIB:' + str(output.with_suffix('.lib'))]
        b.save(name + '-link-plan.json', dict(command=args, original=b.ident(recipe),
            inputs=inputs, change='Only OUT/MAP/IMPLIB. No compilation or object/model copy.'))
        b.execute(name + '-link', args)
        b.save(name + '-image.json', dict(image=b.ident(output.with_suffix('.exe')),
            map=b.ident(output.with_suffix('.map')), input_count=len(inputs)))


def run():
    runtime()
    fixture = ARCH / 'qwen-gpu-comparison/128-prefill'
    model = ARCH / 'llama-matched-consumer/Qwen3.5-2B-text-BF16.gguf'
    assert model.is_file() and model.stat().st_size == 3775709152
    fixed = b.read(fixture / 'fixed-inputs.json')
    assert len(fixed['prompt_ids']) == 128 and len(fixed['decode_input_ids']) == 31
    hyle = [str(HERE / 'hyle.exe'), '--inputs', str(fixture / 'inputs'),
            '--decode-ids', str(fixture / 'decode.ids'), '--steps', '32', '--capacity', '256',
            '--progress', 'direct', '--replay', 'prefer-capture']
    requests = []
    for index, engine in enumerate(['hyle', 'peer', 'peer', 'hyle', 'hyle', 'peer'], 1):
        tag = f'{index:02d}-{engine}'
        output = HERE / (tag + '-peer-result.json')
        args = hyle if engine == 'hyle' else [str(HERE / 'peer.exe'), str(model),
            str(fixture / 'fixed-inputs.json'), str(output)]
        requests.append(dict(tag=tag, engine=engine, argv=args, peer_result=str(output) if engine == 'peer' else None))
    plan = dict(pair_order=['H/L', 'L/H', 'H/L'], H='current Hyle PreferCapture', L='retained matched llama',
        profiler=False, memory_monitor=False, prompt=b.ident(fixture / 'inputs/prompt.ids'),
        fixed_inputs=b.ident(fixture / 'fixed-inputs.json'), tape=b.ident(fixture / 'decode.ids'),
        model=dict(path=str(model), bytes=model.stat().st_size, sha_reference='Original matched model receipt; not copied or rehashed.'),
        images={name:b.read(HERE / (name + '-image.json')) for name in ['hyle', 'peer']}, requests=requests)
    b.save('run-plan.json', plan)
    results = []
    for request in requests:
        # No subprocess timeout: retain the actual live handle until terminal.
        b.execute(request['tag'] + '-run', request['argv'])
        command = next(r for r in b.read(HERE / 'commands.json') if r['tag'] == request['tag'] + '-run')
        if request['engine'] == 'hyle':
            text = (HERE / command['stderr']).read_text()
            phases = [dict(phase=phase, tokens=int(tokens), visible=int(visible),
                submit_to_token_seconds=float(seconds), submit_seconds=float(submit), step_seconds=float(step), next_token=int(token))
                for phase, tokens, visible, seconds, submit, step, token in re.findall(
                    r'^(prefill|decode\d+) tokens=(\d+) visible=(\d+) seconds=(\S+) submit_seconds=(\S+) step_seconds=(\S+) progress=direct next=(\d+)', text, re.M)]
            captures = [dict(recorded=int(a), reused=int(c)) for a,c in re.findall(
                r'capture_recorded=(\d+) capture_reused=(\d+)', text)]
            assert [(r['recorded'],r['reused']) for r in captures] == [(7,0)]*3+[(0,7)]*29
            output = json.loads((HERE / command['stdout']).read_text())
            ids = output['generated_ids']
        else:
            output = b.read(request['peer_result'])
            phases = output['phases']
            ids = output['predicted_ids']
            captures = None
            assert output['context_capacity'] == 256
        assert len(phases) == len(ids) == 32
        assert output['decode_input_ids'] == fixed['decode_input_ids']
        if results: assert ids == results[0]['predicted_ids']
        result = dict(engine=request['engine'], tag=request['tag'], pid=command['pid'], exit=command['exit'],
            command_index=b.read(HERE / 'commands.json').index(command)+1,
            stdout=command['stdout'], stderr=command['stderr'], peer_result=request['peer_result'],
            phases=phases, capture_counts=captures, predicted_ids=ids,
            prefill_tokens_per_second=128/phases[0]['step_seconds'],
            full31_tokens_per_second=31/sum(p['step_seconds'] for p in phases[1:]),
            warm7_31_tokens_per_second=25/sum(p['step_seconds'] for p in phases[7:]))
        results.append(result)
        b.save('results.json', dict(runs=results, remaining=6-len(results)))
    medians = {engine:{metric:statistics.median(r[metric] for r in results if r['engine']==engine)
        for metric in ['prefill_tokens_per_second','full31_tokens_per_second','warm7_31_tokens_per_second']}
        for engine in ['hyle','peer']}
    b.save('summary.json', dict(status='six_unprofiled_processes_terminal_zero', pair_order=plan['pair_order'],
        medians=medians, runs=results, same32_predicted_ids=True, profiler=False, memory_monitor=False,
        timer='Full step from input preparation through token on host. Hyle includes binds/prepare_replay. Shape compile outside step.',
        limitations=['Same-source BF16 weights, but Hyle/peer activation and numerical boundaries are not bit-equivalent.',
            'No independent quality acceptance; this pairset measures whole engine step,not kernel-level cause.',
            'Background competition was observed previously; no process was stopped and no current attribution inferred.'],
        gpu_released=True, live=False, source_or_sdk_compilations=0))
    print(json.dumps(medians,indent=2),flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'link': link()
    elif sys.argv[1] == 'run': run()
    else: raise ValueError(sys.argv[1])
