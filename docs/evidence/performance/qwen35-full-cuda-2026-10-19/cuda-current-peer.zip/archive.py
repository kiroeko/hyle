from pathlib import Path
import hashlib
import json
import zipfile
import zlib
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-current-peer.zip'
replace_draft = '--replace-before-final-doc-draft' in sys.argv
if DEST.exists():
    assert replace_draft and hashlib.sha256(DEST.read_bytes()).hexdigest() == 'b3ef7e73a6fcf7dd2babf7bbf7ec925906086c95b831012659208f77ef5bb766', 'Only the retained unpublished draft may be replaced'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
assert read(OUT / 'summary.json')['status'] == 'six_unprofiled_processes_terminal_zero'
assert read(OUT / 'profile/summary.json')['status'] == 'two_profiles_and_official_exports_terminal_zero'
assert 'exited zero' in read(OUT / 'ncu/summary.json')['status']
entries = []
excluded = {'.obj', '.exe', '.dll', '.lib', '.exp', '.map', '.pdb', '.ilk', '.pyc', '.zip'}
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or path.suffix.lower() in excluded or '__pycache__' in path.parts:
        continue
    relative = path.relative_to(OUT)
    if relative.parts[0] == 'reclaim' or path.name in {'archive-receipt.json', 'archive-inventory.json'}:
        continue
    entries.append((relative.as_posix(), path, path.read_bytes()))
doc = ROOT / 'docs/architecture/compute-design.md'
entries.append(('context/compute-design.md', doc, doc.read_bytes()))
manifest = dict(schema='hyle.cuda.current-peer.archive.v1',
    scope='Six current-window unprofiled runs,two current Nsight traces and one LM-head Ncu kernel per engine;failed first Ncu launch retained. No new compiler/math/product change.',
    context='context/compute-design.md is the current full existing architecture document,not a claim that all of its content changed in this slice.',
    limitations=read(OUT / 'ncu/summary.json')['limitations'],
    design='next-cold-pack-owner-handoff.json and fusion-review.json are proposed next work/read-only facts,not implemented capability.',
    files=[dict(path=name,source=str(path),bytes=len(data),sha256=sha(data),crc32=f'{zlib.crc32(data)&0xffffffff:08x}')
           for name,path,data in entries])
with zipfile.ZipFile(DEST, 'w' if replace_draft else 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name,path,data in entries: archive.writestr(name,data)
    archive.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert len(archive.infolist()) == len(entries)+1
    for record in manifest['files']:
        data = archive.read(record['path'])
        assert sha(data) == record['sha256'] and len(data) == record['bytes']
for name,path,data in entries:
    assert path.read_bytes() == data, 'Archive input drifted: '+str(path)
payload = DEST.read_bytes()
receipt = dict(archive=dict(path=str(DEST),bytes=len(payload),sha256=sha(payload)),
    entries=len(entries)+1,payload_files=len(entries),payload_bytes=sum(len(data) for name,path,data in entries),
    crc_verified=True,every_payload_sha256_verified=True,source_drift=0,
    crc32=f'{zlib.crc32(payload)&0xffffffff:08x}',
    baseline_processes=6,nsight_processes=2,ncu_completed_processes=2,ncu_first_failure_retained=True,
    images_objects_SDK_models_included=False,quality_acceptance=False)
(OUT/'archive-inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
