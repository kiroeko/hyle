from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ARCH = BASE.parent
ROOT = ARCH.parents[1]
CASE = ARCH / 'qwen-gpu-comparison/128-prefill'
NSYS = Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=h.hexdigest())


def environment():
    plans = [read(BASE / (engine + '-link-plan.json'))['command'] for engine in ['hyle', 'peer']]
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': plans[0][0].replace('link.exe', 'cl.exe')})
    env['VSLANG'] = '1033'
    paths = [str(Path(arg).parent) for args in plans for arg in args
             if Path(arg).is_absolute() and arg.lower().endswith('.lib')]
    env['PATH'] = os.pathsep.join(dict.fromkeys(paths)) + os.pathsep + env['PATH']
    assert not env.get('GGML_CUDA_DISABLE_GRAPHS')
    return env


def execute(tag, argv):
    assert not (OUT / (tag + '.command.json')).exists(), 'No implicit retry: ' + tag
    row = dict(argv=list(map(str, argv)), cwd=str(ROOT), started=time.time(), exit=None)
    save(tag + '.command.json', row)
    with (OUT / (tag + '.stdout.log')).open('wb') as so, (OUT / (tag + '.stderr.log')).open('wb') as se:
        process = subprocess.Popen(row['argv'], cwd=ROOT, env=environment(), stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = process.pid
        save('live.json', dict(tag=tag, **row))
        print('START', tag, 'PID', process.pid, flush=True)
        row['exit'] = process.wait()
    row.update(terminal=True, finished=time.time())
    save(tag + '.result.json', row)
    save('live.json', dict(tag=tag, **row))
    print('END', tag, 'exit', row['exit'], 'seconds', round(row['finished'] - row['started'], 3), flush=True)
    if row['exit']:
        print((OUT / (tag + '.stdout.log')).read_text(errors='replace')[-5000:], flush=True)
        print((OUT / (tag + '.stderr.log')).read_text(errors='replace')[-5000:], flush=True)
    return row['exit']


def profile(engine):
    assert engine in ['hyle', 'peer']
    assert read(BASE / 'summary.json')['status'] == 'six_unprofiled_processes_terminal_zero'
    actual = ident(BASE / (engine + '.exe'))
    assert actual == read(BASE / (engine + '-image.json'))['image']
    fixed = read(CASE / 'fixed-inputs.json')
    assert len(fixed['prompt_ids']) == 128 and len(fixed['decode_input_ids']) == 31
    plan = read(BASE / 'run-plan.json')
    request = next(item for item in plan['requests'] if item['engine'] == engine)
    target = request['argv'][:]
    if engine == 'peer':
        target[-1] = str(OUT / 'peer-result.json')
    argv = [NSYS, 'profile', '--trace=cuda', '--sample=none', '--cpuctxsw=none',
            '--cuda-graph-trace=node:host-only', '--discard-environment=true',
            '--output=' + str(OUT / (engine + '-trace')), *target]
    save(engine + '-inputs.json', dict(image=actual, image_receipt=ident(BASE / (engine + '-image.json')),
        link_plan=ident(BASE / (engine + '-link-plan.json')), original_run_plan=ident(BASE / 'run-plan.json'),
        unprofiled_summary=ident(BASE / 'summary.json'), profiler=ident(NSYS),
        inputs=[ident(CASE / relative) for relative in ['fixed-inputs.json', 'inputs/prompt.ids', 'inputs/weights.tsv', 'decode.ids']],
        model_reference=plan['model'], no_compilation_or_link=True, no_model_or_sdk_copy=True))
    return execute(engine + '-profile', argv)


def export(engine):
    assert engine in ['hyle', 'peer']
    assert read(OUT / (engine + '-profile.result.json'))['exit'] == 0
    return execute(engine + '-stats', [NSYS, 'stats', '--report', 'cuda_api_sum,cuda_gpu_kern_sum',
        '--format', 'csv', '--output', OUT / (engine + '-trace'), OUT / (engine + '-trace.nsys-rep')])


if __name__ == '__main__':
    assert sys.argv[1] in ['profile', 'export'] and sys.argv[2] in ['hyle', 'peer']
    raise SystemExit(profile(sys.argv[2]) if sys.argv[1] == 'profile' else export(sys.argv[2]))
