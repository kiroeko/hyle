"""Extend the retained node-trace analyzer; no inference or instrumentation changes."""
from pathlib import Path
import bisect
import collections
import csv
import hashlib
import json
import re
import sqlite3
import statistics

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ARCH = BASE.parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=h.hexdigest())


def stats(values):
    values = list(values)
    return dict(min=min(values), median=statistics.median(values),
                mean=statistics.mean(values), max=max(values)) if values else None


def merged(intervals):
    result = []
    for a, b in sorted(intervals):
        if result and a <= result[-1][1]:
            result[-1][1] = max(b, result[-1][1])
        else:
            result.append([a, b])
    return result


def union_ns(intervals):
    return sum(b - a for a, b in merged(intervals))


def group(name):
    # Same primary grouping as cuda-bfloat-elementwise-trace/analyze.py.
    if 'internal::gemvx' in name:
        return 'cuBLAS_gemvx'
    if 'mul_mat_vec_f<' in name:
        return 'ggml_mmvf'
    if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name:
        return 'scalar_BF16_to_F32'
    if 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name:
        return 'scalar_F32_to_BF16'
    if 'k_bin_bcast<&op_add, __nv_bfloat16' in name:
        return 'BF16_native_add'
    if 'k_bin_bcast<&op_mul, __nv_bfloat16' in name:
        return 'BF16_native_multiply'
    if 'unary_op_kernel<&op_sigmoid, __nv_bfloat16>' in name:
        return 'BF16_native_sigmoid'
    if 'rms_norm' in name:
        return 'RMSNorm'
    if 'gated_delta_net' in name:
        return 'GatedDeltaNet'
    if 'flashinfer' in name:
        return 'FlashInfer_attention_or_merge'
    if 'flash_attn' in name:
        return 'ggml_attention'
    if 'hyle::compute::cuda_native::collectives' in name:
        return 'Hyle_collectives'
    if 'gemm' in name.lower():
        return 'GEMM_named'
    if 'cpy_' in name or 'convert_' in name:
        return 'other_copy_or_convert_kernel'
    return 'other'


def count_family(name):
    if 'internal::gemvx' in name or 'mul_mat_vec_f<' in name:
        return 'projection'
    if 'cpy_scalar_contiguous<__nv_bfloat16, float>' in name or 'cpy_scalar_contiguous<float, __nv_bfloat16>' in name:
        return 'BF16_F32_cast'
    if 'k_bin_bcast<&op_repeat' in name:
        return 'repeat'
    if 'k_bin_bcast<&op_' in name:
        if ', __nv_bfloat16' in name:
            return 'BF16_binary'
        return 'F32_binary'
    if 'unary_op_kernel<' in name:
        return 'pointwise_unary'
    if 'reduce_rows' in name:
        return 'reduce_rows'
    if 'rms_norm' in name:
        return 'RMSNorm'
    if 'act_kernel<' in name or 'softplus_kernel' in name or 'unary_gated_op_kernel<' in name:
        return 'activation_or_gated_activation'
    if 'ssm_conv' in name:
        return 'SSM_convolution'
    if 'gated_delta_net' in name:
        return 'GatedDeltaNet'
    if 'flashinfer' in name or 'flash_attn' in name:
        return 'attention_and_merge'
    if 'concat_' in name:
        return 'concat'
    if 'single_update<' in name or 'k_set_rows<' in name:
        return 'cache_update'
    if 'cpy_' in name or 'convert_' in name:
        return 'other_copy_or_convert'
    if 'k_get_rows' in name or 'GatherOutput<' in name:
        return 'gather'
    if 'rope_multi' in name:
        return 'rotary'
    if 'scale_f32' in name:
        return 'scale'
    if 'collectives' in name or 'argmax_f32' in name or 'pad_f32' in name:
        return 'token_selection_and_padding'
    return 'unclassified'


def activity_summary(activities):
    intervals = [(x['start'], x['end']) for x in activities]
    if not intervals:
        return dict(count=0, union_active_ns=0, duration_sum_ns=0)
    first = min(a for a, b in intervals)
    last = max(b for a, b in intervals)
    combined = merged(intervals)
    gaps = [(combined[i][0] - combined[i-1][1], combined[i-1][1], combined[i][0])
            for i in range(1, len(combined))]
    return dict(count=len(activities), first_ns=first, last_ns=last, span_ns=last-first,
                union_active_ns=union_ns(intervals),
                duration_sum_ns=sum(b-a for a, b in intervals),
                intra_span_without_target_activity_ns=last-first-union_ns(intervals),
                longest_gaps=[dict(duration_ns=d, start_ns=a, end_ns=b)
                              for d, a, b in sorted(gaps, reverse=True)[:12]])


def api_group(name):
    if 'GraphLaunch' in name:
        return 'graph_launch'
    if any(part in name for part in ['Malloc', 'Free', 'MemAlloc', 'MemFree', 'MemCreate', 'MemMap', 'MemUnmap']):
        return 'allocation_or_free'
    if 'Memcpy' in name:
        return 'copy'
    if 'Memset' in name:
        return 'memset'
    if 'Synchronize' in name:
        return 'host_synchronize'
    if 'Query' in name:
        return 'query'
    if 'WaitEvent' in name or 'EventRecord' in name:
        return 'event_dependency'
    if any(part in name for part in ['GraphInstantiate', 'GraphExecUpdate', 'Capture', 'GraphDestroy']):
        return 'capture_lifecycle'
    return 'other'


def bin_engine(engine):
    db = OUT / (engine + '-trace.sqlite')
    con = sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True)
    con.row_factory = sqlite3.Row
    diagnostics = [dict(row) for row in con.execute('select timestamp,severity,text from DIAGNOSTIC_EVENT')]
    for filename, content in con.execute(
            'select a.filename,s.value from ANALYSIS_FILE a join StringIds s on s.id=a.contentId'):
        if '/streams/' in filename:
            suffix = 'stderr' if 'stderr_' in filename else 'stdout'
            (OUT / (engine + '-target-' + suffix + '.log')).write_text(content, encoding='utf-8')
    save(engine + '-diagnostics.json', diagnostics)
    kernels = [dict(row) for row in con.execute(
        'select k.start,k.end,k.streamId,k.correlationId,k.graphId,k.graphNodeId,'
        'k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,s.value as name '
        'from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on s.id=k.demangledName order by k.start')]
    copies = [dict(row) for row in con.execute(
        'select start,end,streamId,correlationId,graphNodeId,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start')]
    memsets = [dict(row) for row in con.execute(
        'select start,end,streamId,correlationId,graphNodeId,bytes from CUPTI_ACTIVITY_KIND_MEMSET order by start')]
    apis = [dict(row) for row in con.execute(
        'select a.start,a.end,a.correlationId,a.globalTid,a.returnValue,s.value as name '
        'from CUPTI_ACTIVITY_KIND_RUNTIME a join StringIds s on s.id=a.nameId order by a.start')]
    if con.execute("select count(*) from sqlite_master where name='CUPTI_ACTIVITY_KIND_DRIVER'").fetchone()[0]:
        apis += [dict(row) for row in con.execute(
            'select a.start,a.end,a.correlationId,a.globalTid,a.returnValue,s.value as name '
            'from CUPTI_ACTIVITY_KIND_DRIVER a join StringIds s on s.id=a.nameId order by a.start')]
        apis.sort(key=lambda row: row['start'])
    api_by_correlation = {row['correlationId']: row for row in apis}
    for k in kernels:
        k['kind'] = 'kernel'
        k['group'] = group(k['name'])
    for m in copies:
        m['kind'] = 'memcpy'
    for m in memsets:
        m['kind'] = 'memset'
    activities = sorted(kernels + copies + memsets, key=lambda row: row['start'])
    tokens = [m for m in copies if m['copyKind'] == 2 and m['bytes'] == 4]
    assert len(tokens) == 32, (engine, len(tokens))
    ends = [m['end'] for m in tokens]
    d2h = [m for m in copies if m['copyKind'] == 2]
    if engine == 'hyle':
        assert len(d2h) == 32
    else:
        assert collections.Counter(m['bytes'] for m in d2h) == {4: 32, 993280: 32}
    phases = []
    previous = -1
    for index, end in enumerate(ends):
        kk = [k for k in kernels if previous < k['start'] <= end]
        mm = [m for m in copies + memsets if previous < m['start'] <= end]
        aa = [a for a in apis if previous < a['start'] <= end]
        all_activity = kk + mm
        launches = [a for a in aa if 'GraphLaunch' in a['name']]
        launch_starts = [a['start'] for a in launches]
        ranges = []
        for ordinal, launch in enumerate(launches):
            selected = [a for a in all_activity if a['correlationId'] == launch['correlationId']]
            graphs = sorted({k['graphId'] for k in selected if k['kind'] == 'kernel' and k['graphId'] is not None})
            ranges.append(dict(ordinal=ordinal, correlation_id=launch['correlationId'], graph_ids=graphs,
                api_start_ns=launch['start'], api_end_ns=launch['end'],
                activity=activity_summary(selected),
                kernel_groups=dict(collections.Counter(k['group'] for k in selected if k['kind'] == 'kernel'))))
        gaps = []
        for gap_index in range(len(launches) + 1):
            selected = []
            for a in all_activity:
                if a.get('graphNodeId'):
                    continue
                host = api_by_correlation.get(a['correlationId'])
                if host and bisect.bisect_right(launch_starts, host['start']) == gap_index:
                    selected.append(a)
            gaps.append(dict(position=('before_first' if gap_index == 0 else
                            'after_last' if gap_index == len(launches) else
                            'between_%d_and_%d' % (gap_index-1, gap_index)),
                activity=activity_summary(selected),
                kernels=[dict(name=k['name'], group=k['group'], start_ns=k['start'], end_ns=k['end'],
                              stream=k['streamId']) for k in selected if k['kind'] == 'kernel']))
        groups = {}
        for name in sorted({k['group'] for k in kk}):
            selected = [k for k in kk if k['group'] == name]
            groups[name] = activity_summary(selected)
        api_groups = {}
        for name in sorted({api_group(a['name']) for a in aa}):
            selected = [a for a in aa if api_group(a['name']) == name]
            api_groups[name] = dict(count=len(selected), duration_sum_ns=sum(a['end']-a['start'] for a in selected),
                                   union_ns=union_ns([(a['start'], a['end']) for a in selected]))
        envelope = activity_summary(all_activity)
        first_launch = launches[0]['start'] if launches else None
        gpu_graph_start = min((r['activity'].get('first_ns', 2**63) for r in ranges), default=None)
        before_graph = [a for a in all_activity if gpu_graph_start and a['end'] <= gpu_graph_start]
        after_graph = [(max(gpu_graph_start,a['start']),min(end,a['end'])) for a in all_activity
                       if gpu_graph_start and a['end']>gpu_graph_start and a['start']<end]
        before_graph_span = gpu_graph_start-envelope['first_ns'] if gpu_graph_start else None
        before_graph_union = union_ns([(a['start'],a['end']) for a in before_graph])
        copy_counts = collections.Counter((m.get('copyKind'), m['bytes']) for m in mm if m['kind'] == 'memcpy')
        phase = dict(phase='prefill' if index == 0 else 'decode' + str(index), token_end_ns=end,
            previous_token_end_ns=None if index == 0 else previous,
            readback_to_readback_ns=None if index == 0 else end-previous,
            kernel_count=len(kk), graph_node_kernel_count=sum(bool(k['graphNodeId']) for k in kk),
            graph_launch_count=len(launches), envelope=envelope,
            gap_before_first_device_activity_ns=None if index == 0 else envelope['first_ns']-previous,
            gap_to_first_graph_launch_api_ns=None if index == 0 or first_launch is None else first_launch-previous,
            gap_to_first_graph_device_activity_ns=None if index == 0 or gpu_graph_start is None else gpu_graph_start-previous,
            gpu_before_first_graph=activity_summary(before_graph), kernel_groups=groups, api_groups=api_groups,
            prefix_span_to_first_graph_ns=before_graph_span,
            prefix_without_target_activity_ns=None if before_graph_span is None else before_graph_span-before_graph_union,
            graph_start_to_token_span_ns=None if gpu_graph_start is None else end-gpu_graph_start,
            graph_start_to_token_without_target_activity_ns=None if gpu_graph_start is None else end-gpu_graph_start-union_ns(after_graph),
            native_between_range_span_ns=sum(g['activity'].get('span_ns',0) for g in gaps if g['position'].startswith('between')),
            internal_range_without_target_activity_ns=sum(r['activity'].get('intra_span_without_target_activity_ns',0) for r in ranges),
            mechanism_counts=dict(collections.Counter(count_family(k['name']) for k in kk)),
            runtime_api_returns=collections.Counter(str(a['returnValue']) for a in aa),
            copy_counts=[dict(copy_kind=k, bytes=n, count=count) for (k,n),count in sorted(copy_counts.items())],
            memcpy_duration_sum_ns=sum(m['end']-m['start'] for m in mm if m['kind']=='memcpy'),
            memset_duration_sum_ns=sum(m['end']-m['start'] for m in mm if m['kind']=='memset'),
            ranges=ranges, native_gaps=gaps)
        phases.append(phase)
        previous = end
    stable = phases[7:]
    metric_paths = {
        'readback_to_readback_ns': lambda p: p['readback_to_readback_ns'],
        'device_activity_span_ns': lambda p: p['envelope']['span_ns'],
        'union_kernel_copy_memset_active_ns': lambda p: p['envelope']['union_active_ns'],
        'intra_span_without_target_activity_ns': lambda p: p['envelope']['intra_span_without_target_activity_ns'],
        'gap_before_first_device_activity_ns': lambda p: p['gap_before_first_device_activity_ns'],
        'gap_to_first_graph_launch_api_ns': lambda p: p['gap_to_first_graph_launch_api_ns'],
        'gap_to_first_graph_device_activity_ns': lambda p: p['gap_to_first_graph_device_activity_ns'],
        'gpu_activity_before_first_graph_union_ns': lambda p: p['gpu_before_first_graph']['union_active_ns'],
        'memcpy_duration_sum_ns': lambda p: p['memcpy_duration_sum_ns'],
        'memset_duration_sum_ns': lambda p: p['memset_duration_sum_ns'],
        'prefix_span_to_first_graph_ns': lambda p: p['prefix_span_to_first_graph_ns'],
        'prefix_without_target_activity_ns': lambda p: p['prefix_without_target_activity_ns'],
        'graph_start_to_token_span_ns': lambda p: p['graph_start_to_token_span_ns'],
        'graph_start_to_token_without_target_activity_ns': lambda p: p['graph_start_to_token_without_target_activity_ns'],
        'native_between_range_span_ns': lambda p: p['native_between_range_span_ns'],
        'internal_range_without_target_activity_ns': lambda p: p['internal_range_without_target_activity_ns'],
    }
    numeric = {name: stats(fn(p) for p in stable) for name, fn in metric_paths.items()}
    names = sorted({name for p in stable for name in p['kernel_groups']})
    group_stats = {name: dict(count=stats(p['kernel_groups'].get(name, {}).get('count', 0) for p in stable),
        duration_sum_ns=stats(p['kernel_groups'].get(name, {}).get('duration_sum_ns', 0) for p in stable),
        union_ns=stats(p['kernel_groups'].get(name, {}).get('union_active_ns', 0) for p in stable)) for name in names}
    api_names = sorted({name for p in stable for name in p['api_groups']})
    api_stats = {name: dict(count=stats(p['api_groups'].get(name, {}).get('count', 0) for p in stable),
        duration_sum_ns=stats(p['api_groups'].get(name, {}).get('duration_sum_ns', 0) for p in stable)) for name in api_names}
    names = sorted({k['name'] for k in kernels if ends[6] < k['start'] <= ends[-1]})
    timings = {}
    for name in names:
        selected = [k for k in kernels if ends[6] < k['start'] <= ends[-1] and k['name'] == name]
        timings[name] = dict(name=name, group=group(name), count=len(selected), count_per_warm_step=len(selected)/25,
            duration_sum_ns=sum(k['end']-k['start'] for k in selected),
            duration_mean_per_warm_step_ns=sum(k['end']-k['start'] for k in selected)/25,
            instances_ns=stats(k['end']-k['start'] for k in selected))
    top = sorted(timings.values(), key=lambda item: -item['duration_sum_ns'])
    csvrows = list(csv.DictReader((OUT / (engine + '-trace_cuda_gpu_kern_sum.csv')).open()))
    assert sum(int(row['Instances']) for row in csvrows) == len(kernels)
    save(engine + '-phases.json', dict(method='32 final4B token D2H endpoints; bins use activity start. '
         'Peer engine also reads993280B sampled logits after token: this falls in the next4B bin; '
         'warm steady-state cost remains included, and this is not exact application step timing.', phases=phases))
    detailed = []
    kernel_names = sorted({k['name'] for k in kernels if ends[6] < k['start'] <= ends[9]})
    name_indexes = {name: i for i, name in enumerate(kernel_names)}
    for i in range(7, 10):
        start, end = ends[i-1], ends[i]
        detailed.append(dict(phase='decode'+str(i), origin_ns=start, endpoint_ns=end,
            kernel_columns=['start_rel_ns','end_rel_ns','stream','correlationId','graphId','graphNodeId','name_index'],
            kernels=[[k['start']-start,k['end']-start,k['streamId'],k['correlationId'],k['graphId'],k['graphNodeId'],name_indexes[k['name']]]
                     for k in kernels if start < k['start'] <= end],
            copies=[dict(m, start_rel_ns=m['start']-start, end_rel_ns=m['end']-start)
                    for m in copies if start < m['start'] <= end],
            memsets=[dict(m, start_rel_ns=m['start']-start, end_rel_ns=m['end']-start)
                     for m in memsets if start < m['start'] <= end],
            graph_launches=[a for a in apis if start<a['start']<=end and 'GraphLaunch' in a['name']]))
    save(engine + '-warm7-9-timeline.json', dict(kernel_names=kernel_names, phases=detailed))
    save(engine + '-warm-kernel-groups.json', dict(groups=group_stats, exact_kernel_names_by_duration=top))
    actual = read(OUT / ('hyle-target-stdout.log' if engine == 'hyle' else 'peer-result.json'))
    fixed = read(ARCH / 'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
    ids = actual['generated_ids'] if engine == 'hyle' else actual['predicted_ids']
    baseline = next(row for row in read(BASE / 'summary.json')['runs'] if row['engine'] == engine)
    assert actual['decode_input_ids'] == fixed['decode_input_ids']
    assert len(ids) == 32 and ids == baseline['predicted_ids']
    if engine == 'hyle':
        text = (OUT / 'hyle-target-stderr.log').read_text()
        capture_counts = [(int(a),int(b)) for a,b in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', text)]
        assert capture_counts == [(7,0)]*3 + [(0,7)]*29
        step_metrics = [dict(phase=phase, submit_to_token_seconds=float(sec), submit_seconds=float(sub),
                             step_seconds=float(step), prepare_seconds=float(step)-float(sec))
                        for phase,sec,sub,step in re.findall(
                            r'^(prefill|decode\d+) tokens=\d+ visible=\d+ seconds=(\S+) submit_seconds=(\S+) step_seconds=(\S+)', text, re.M)]
    else:
        capture_counts = None
        step_metrics = actual['phases']
    metrics = {key: stats(row[key] for row in step_metrics[7:]) for key in step_metrics[7]
               if key.endswith('_seconds')}
    return dict(sqlite=ident(db), diagnostics=ident(OUT / (engine+'-diagnostics.json')),
        kernel_count=len(kernels), stable_structure=sorted({(p['kernel_count'],p['graph_node_kernel_count'],p['graph_launch_count']) for p in stable}),
        stable_decode7_31=numeric, stable_kernel_groups=group_stats, stable_api_groups=api_stats,
        first_three_warm_phases=phases[7:10], capture_counts=capture_counts,
        profile_app_timer_seconds=metrics, same32_predicted_ids_as_same_engine_unprofiled=True,
        mechanism_counts=[dict(phase=p['phase'],counts=p['mechanism_counts']) for p in stable],
        predicted_ids=ids, phase_details=ident(OUT / (engine+'-phases.json')),
        timeline=ident(OUT / (engine+'-warm7-9-timeline.json')),
        groups=ident(OUT / (engine+'-warm-kernel-groups.json')))


engines = {engine: bin_engine(engine) for engine in ['hyle', 'peer']}
assert engines['hyle']['predicted_ids'] == engines['peer']['predicted_ids']
families=sorted({family for e in engines.values() for p in e['mechanism_counts'] for family in p['counts']})
differences=[]
for family in families:
    counts={engine:stats(p['counts'].get(family,0) for p in e['mechanism_counts']) for engine,e in engines.items()}
    differences.append(dict(family=family,counts=counts,difference=counts['hyle']['median']-counts['peer']['median']))
assert sum(row['counts']['hyle']['median'] for row in differences)==1794
assert sum(row['counts']['peer']['median'] for row in differences)==558
assert sum(row['difference'] for row in differences)==1236
save('kernel-count-difference.json',dict(scope='All25 observed warmdecode7..31 bins have identical counts; exclusive physical kernel-name families, not logical-operation equivalence.',
    rows=differences,hyle=1794,peer=558,difference=1236,
    source_interpretation=[
        'tools/qwen35_text/main.cc Recipe::l2 emits square/reduction/epsilon/rsqrt/multiply with literal BF16 boundaries; peer uses original native norm graph.',
        'Recipe::ffn emits gate projection, SiLU, up projection and multiply separately; peer native FFN/vector graph can fuse gated work.',
        'Actual Hyle SSM convolution kernel has template false with separate SiLU; peer has template true.',
        'Hyle rotary is multiple public primitives; peer has12 rope_multi kernels.',
        'A required BF16 per-node RNE boundary does not require a separate kernel: a proven fused implementation can preserve rounding in registers.'
    ],limits=['Kernel-name family counts do not by themselves establish the time saved by fusion or acceptance of altered numerical boundaries.']))
summary = dict(schema='hyle.cuda.current-peer.profile.v1', status='two_profiles_and_official_exports_terminal_zero',
    scope='Current retained7-range Hybrid Hyle and unchanged matched llama; one software node trace per engine. '
          'Same128prompt+31fixedprefix/ctx256/allCUDA. No compilation, relink, SDK or model copy.',
    engines=engines, unprofiled_comparison=ident(BASE / 'summary.json'),
    source_mechanism=[
        'src/graph/submission.cc enqueues retained common captured ranges and original uncaptured steps on one QueueSequence.',
        'The consumer uses batch::prepare then ordinary Invocation::prepare_replay; no per-step batch::prepare_replay is called.',
        'src/compute_batch/batch_execution.cc therefore calls the actual selected BatchProvider run for current attention gaps.',
        'Kernel graphId/graphNodeId and correlationId join actual runtime GraphLaunch; node:host-only observes captured direct-encoder nodes.'
    ],
    limits=[
        'Profile times are software-instrumented observations, not replacement fair throughput or an additive decomposition of the1.49ms unprofiled difference.',
        'Installed driver13.4 is collected with13.3 CUPTI and legacy software node trace; actual diagnostics retained.',
        'GPU kernel duration sums double-count overlapping intervals; union active and observed gaps are reported separately.',
        'No observed target activity does not establish whole GPU idle or distinguish external WDDM scheduling, clock changes and profiler overhead.',
        'The4B D2H bins are not exact step-start boundaries. Peer retained sampled-logits copy after token is included in the following bin.',
        'Names support physical kernel grouping, not exact logical-operation equivalence or quality/precision acceptance.',
        'Same32 predictions preserve this test-prefix guard only; no new rawvector/fullmodel quality claim.'
    ], gpu_released=True, no_more_gpu_work=True)
save('summary.json', summary)
save('cleanup-plan.json', dict(root=str(OUT.resolve()), files=[], retain=['both nsys-rep and SQLite exports',
    'official CSV, all commands, logs and JSON', 'parent retained images are owned by parent cuda-current-peer cleanup'],
    no_images_created=True, delete_executed=False))
print(json.dumps({e:dict(structure=engines[e]['stable_structure'], times=engines[e]['stable_decode7_31'],
                       groups=engines[e]['stable_kernel_groups']) for e in engines},indent=2))
