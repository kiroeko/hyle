from pathlib import Path
import csv
import io
import json

OUT = Path(__file__).resolve().parent
DATA = OUT / 'with-runtime'
rows = {}
for engine in ('hyle', 'peer'):
    lines = (DATA / (engine + '.stdout.log')).read_text(encoding='utf-8-sig').splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith('"ID",'))
    records = list(csv.DictReader(io.StringIO('\n'.join(lines[start:]))))
    selected = [r for r in records if r.get('ID', '').isdigit()]
    assert len(selected) == 1
    record = selected[0]
    number = lambda key: float(record[key].replace(',', ''))
    duration = number('gpu__time_duration.sum')
    byte_count = number('dram__bytes.sum')
    rows[engine] = dict(
        kernel=record['Kernel Name'], grid=record['Grid Size'], block=record['Block Size'],
        duration_ns=duration, dram_bytes=byte_count,
        dram_GB_per_second=byte_count / duration,
        dram_percent_peak=number('gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed'),
        sm_percent_peak=number('sm__throughput.avg.pct_of_peak_sustained_elapsed'),
        replay_passes=number('profiler__replayer_passes'),
    )
assert rows['hyle']['grid'] == '(62080, 1, 1)'
assert rows['peer']['grid'] == '(248320, 1, 1)'
report = dict(
    status='One LM-head kernel collected per engine; both profiler processes exited zero.',
    scope='Same logical W[248320,2048], BF16 weights. Hyle input/output BF16; peer F32.',
    kernels=rows,
    limitations=[
        'One sampled kernel per engine, seven profiling replay passes each; not a whole-model throughput comparison.',
        'GPU clocks and caches deliberately uncontrolled. Tool warnings are retained; these are observations, not stable throughput guarantees.',
        'First launch failed before model startup because the runtime DLL environment was omitted; preserved separately. The completed attempt uses the exact successful Nsight Systems runtime environment.',
        'Completed peer application JSON was overwritten by runner command metadata due to a filename collision. Runner is corrected for future use; no rerun solely to regenerate that auxiliary output. Peer counter results and exit status remain preserved. Baseline and Nsight Systems each independently preserve peer predictions.',
    ],
)
(OUT / 'summary.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
