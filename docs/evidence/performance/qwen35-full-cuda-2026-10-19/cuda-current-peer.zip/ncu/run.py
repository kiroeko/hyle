from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
SCRIPT = Path(__file__).resolve()
STAGE = SCRIPT.parent.parent
OUT = SCRIPT.parent / (sys.argv[1] if len(sys.argv) > 1 else '.')
OUT.mkdir(parents=True, exist_ok=True)
ROOT = STAGE.parents[2]
NCU = Path(r'C:\Program Files\NVIDIA Corporation\Nsight Compute 2026.2.1\target\windows-desktop-win7-x64\ncu.exe')
METRICS = [
    'gpu__time_duration.sum',
    'dram__bytes.sum',
    'gpu__dram_throughput.avg.pct_of_peak_sustained_elapsed',
    'sm__throughput.avg.pct_of_peak_sustained_elapsed',
]


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


if (OUT / 'results.json').exists():
    raise SystemExit('Existing results: do not replay or overwrite the experiment.')
plan = json.loads((STAGE / 'run-plan.json').read_text(encoding='utf-8-sig'))
for engine in ('hyle', 'peer'):
    expected = plan['images'][engine]['image']
    assert identity(expected['path']) == expected, engine
assert NCU.is_file()
spec = importlib.util.spec_from_file_location('current_profile_environment', STAGE / 'profile/run.py')
profile = importlib.util.module_from_spec(spec)
spec.loader.exec_module(profile)
env = profile.environment()
save(OUT / 'experiment.json', dict(
    tool=identity(NCU), metrics=METRICS,
    scope='One decode7 LM-head kernel per engine, W[248320,2048] BF16. '
          'Hyle activations/output BF16; peer F32. Not a whole-model throughput comparison.',
    selection='Current Nsight Systems SQLite chronological family count before decode7 final '
              'projection: gemvx 1309, mul_mat_vec_f 1141; includes prefill and decode1..6.',
    cache_control='none', clock_control='none', graph_profiling='node',
    environment='Exact runtime DLL environment from the successful current Nsight Systems runner.',
    runner=identity(SCRIPT),
))
results = []
for engine, pattern, skip in [('hyle', 'internal::gemvx::kernel', 1309),
                              ('peer', 'mul_mat_vec_f', 1141)]:
    target = list(next(r for r in plan['requests'] if r['engine'] == engine)['argv'])
    if engine == 'peer':
        target[-1] = str(OUT / 'peer-consumer-result.json')
    argv = [str(NCU), '--graph-profiling', 'node', '--filter-mode', 'global',
            '--kernel-name-base', 'demangled', '--kernel-name', 'regex:' + pattern,
            '--launch-skip', str(skip), '--launch-count', '1',
            '--cache-control', 'none', '--clock-control', 'none',
            '--metrics', ','.join(METRICS), '--export', str(OUT / (engine + '-head')),
            '--csv', '--page', 'raw'] + target
    item = dict(engine=engine, argv=argv, cwd=str(ROOT), started=time.time(), exit=None)
    save(OUT / (engine + '-command.json'), item)
    with (OUT / (engine + '.stdout.log')).open('w', encoding='utf-8') as stdout, \
         (OUT / (engine + '.stderr.log')).open('w', encoding='utf-8') as stderr:
        proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        item['pid'] = proc.pid
        save(OUT / 'live.json', item)
        print(json.dumps(dict(engine=engine, pid=proc.pid, state='running')), flush=True)
        item['exit'] = proc.wait()
    item['finished'] = time.time()
    save(OUT / (engine + '-result.json'), item)
    results.append(item)
    save(OUT / 'live.json', item)
    print(json.dumps(dict(engine=engine, pid=proc.pid, exit=item['exit'],
                          elapsed=item['finished'] - item['started'])), flush=True)
    if item['exit'] != 0:
        break
save(OUT / 'results.json', results)
