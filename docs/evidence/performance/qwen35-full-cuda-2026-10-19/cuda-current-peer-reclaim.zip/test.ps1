param([switch]$ReclaimCudaCurrentPeer)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$directory = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-current-peer'
$stage = Join-Path $directory 'reclaim'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
$archive = Join-Path $workspace 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-current-peer.zip'
function Get-Sha256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}
function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    if ([string]$entry.sha256 -cnotmatch '^[0-9a-f]{64}$') { throw "Invalid SHA identity: $path" }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    if (-not [string]::Equals((Resolve-Path -LiteralPath $path).ProviderPath, $path, [StringComparison]::OrdinalIgnoreCase)) { throw "Resolved path changed: $path" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne [long]$entry.bytes -or (Get-Sha256 $path) -ne $entry.sha256) { throw "Identity changed: $path" }
}
if ($plan.workspace -ne $workspace -or $plan.allowed_directory -ne $directory) { throw 'Unexpected plan root' }
if (@($plan.targets).Count -ne 6 -or $plan.files -ne 6 -or $plan.bytes -ne 208092023 -or ($plan.targets | Measure-Object bytes -Sum).Sum -ne $plan.bytes) { throw 'Expected exact six completed images totaling208092023 bytes' }
if (@($plan.retained_objects).Count -ne 91 -or @($plan.retained_raw_files).Count -ne 6) { throw 'Expected91 retained objects and6 raw profiler files' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_files)) {
    if (-not $seen.Add([string]$entry.path)) { throw "Duplicate retained path: $($entry.path)" }
    Assert-Identity $entry
}
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    $stem = [IO.Path]::GetFileNameWithoutExtension($path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ([IO.Path]::GetDirectoryName($path) -ne $directory -or @('hyle', 'peer') -notcontains $stem -or @('.exe', '.map', '.lib', '.exp') -notcontains $extension) { throw "Not a completed current-peer image: $path" }
    if (-not $seen.Add($path)) { throw "Duplicate or retained target: $path" }
    Assert-Identity $entry
}
if ($plan.archive.path -ne $archive -or $plan.archive_receipt -ne (Join-Path $directory 'archive-receipt.json')) { throw 'Unexpected archive or receipt' }
$archiveReceipt = Get-Content -Raw -LiteralPath $plan.archive_receipt | ConvertFrom-Json
if (-not $archiveReceipt.crc_verified -or -not $archiveReceipt.every_payload_sha256_verified -or $archiveReceipt.source_drift -ne 0) { throw 'Archive must pass CRC/everySHA/source identity checks' }
if ($archiveReceipt.archive.path -ne $archive -or $archiveReceipt.archive.sha256 -ne $plan.archive.sha256 -or $archiveReceipt.archive.bytes -ne $plan.archive.bytes) { throw 'Archive identity differs from plan' }
Assert-Identity $plan.archive
$preview = [pscustomobject]@{preview=$true; files=6; bytes=$plan.bytes; archives_verified=1; retained_objects=91; retained_raw_files=6; script_sha256=(Get-Sha256 $PSCommandPath)}
if (-not $ReclaimCudaCurrentPeer) {
    $preview | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stage 'preview.json') -Encoding utf8
    $preview
    return
}
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup receipt already exists;do not replay deletion' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Assert-Identity $entry
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Target still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{deleted=$deleted.ToArray(); files=$deleted.Count; bytes=($deleted | Measure-Object bytes -Sum).Sum; archive_verified=$plan.archive; retained_objects=$plan.retained_objects; retained_raw_files=$plan.retained_raw_files; complete=($deleted.Count -eq 6); script_sha256=(Get-Sha256 $PSCommandPath)} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_files)) { Assert-Identity $entry }
[pscustomobject]@{deleted_files=6;reclaimed_bytes=$plan.bytes;archives_verified=1;retained_objects=91;retained_raw_files=6}
