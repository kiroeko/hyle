"""Apply an exact reviewed native correction and refresh its locked identity."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('rope_delta_seal', STAGE / 'seal.py')
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)
s = owner.s


def main():
    delta_path = Path(sys.argv[1]).resolve()
    delta = s.read(delta_path)
    manifest_path = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
    manifest = s.read(manifest_path)
    freeze = s.read(STAGE / 'native-source-freeze.json')
    expected = dict(freeze['sources'])
    for change in delta['files']:
        canonical = STAGE / 'native-source' / change['path']
        if s.sha(canonical.read_bytes()) != change['before_sha256']:
            raise ValueError('Correction does not describe current source')
        row = next(row for row in manifest['files'] if row['path'] == change['path'])
        row['edits'].extend(change['edits'])
        row['after_sha256'] = s.sha(owner.replay(row))
        expected[change['path']] = change['after_sha256']
    snapshot = STAGE / ('before-correction-' + freeze['source_id'])
    snapshot.mkdir(exist_ok=False)
    (snapshot / 'patches.json').write_bytes(manifest_path.read_bytes())
    (snapshot / 'native-source-freeze.json').write_bytes((STAGE / 'native-source-freeze.json').read_bytes())
    proposed = snapshot / 'proposed.json'
    s.save(proposed, manifest)
    runtime = ROOT / 'src/compute_ggml_runtime'
    s.load('rope_corrected_iq1', runtime / 'prepare_cuda_iq1_manifest.py').derive(
        s.UPSTREAM, STAGE / 'mixed-cpu-manifest.json', proposed,
        ROOT / 'third_party/ggml_cuda_runtime/iq1-patches.json', STAGE / 'combined-manifest.json')
    outputs = {}
    for row in s.read(STAGE / 'combined-manifest.json')['files']:
        data = owner.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Corrected replay differs')
        if row['path'] in expected:
            if s.sha(data) != expected[row['path']]:
                raise ValueError('Corrected source differs from reviewed hash')
            outputs[row['path']] = data
    if len(outputs) != len(expected):
        raise ValueError('Native output set changed')
    manifest_path.write_bytes(proposed.read_bytes())
    for relative, data in outputs.items():
        (STAGE / 'native-source' / relative).write_bytes(data)
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    tree = s.tree(ROOT / 'third_party/ggml_cuda_runtime')
    entries['ggml_cuda_runtime_patches']['vendored']['tree_sha256'] = tree
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes()) + tree
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    freeze.update(sources=expected, source_id=source_id, vendor_tree_sha256=tree)
    s.save(STAGE / 'native-source-freeze.json', freeze)
    print('CORRECTED', source_id, flush=True)


if __name__ == '__main__':
    main()
