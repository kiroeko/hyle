from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
BASE = ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-bf16-dual-projection/metadata-fix/native-source'
UPSTREAM = STAGE / 'upstream'

def digest(data):
    return hashlib.sha256(data).hexdigest()

records = []
replacement_records = []
def write(relative, before, after, before_path):
    path = STAGE / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(after, encoding='utf-8', newline='\n')
    records.append({'path': relative, 'before_path': str(before_path.relative_to(ROOT)),
                    'before_sha256': digest(before.encode()), 'after_sha256': digest(after.encode()),
                    'after_bytes': len(after.encode())})
    before_lines, after_lines = before.splitlines(True), after.splitlines(True)
    context = 3
    while True:
        groups = list(difflib.SequenceMatcher(None, before_lines, after_lines,
                                             autojunk=False).get_grouped_opcodes(context))
        edits = []
        for group in groups:
            old = ''.join(before_lines[group[0][1]:group[-1][2]])
            new = ''.join(after_lines[group[0][3]:group[-1][4]])
            edits.append({'before': old, 'after': new})
        replayed = before
        for edit in edits:
            if not edit['before'] or replayed.count(edit['before']) != 1:
                break
            replayed = replayed.replace(edit['before'], edit['after'], 1)
        else:
            if replayed == after:
                break
        context *= 2
        assert context < max(len(before_lines), len(after_lines)) * 2
    replacement_records.append({'path': relative, 'edits': edits,
                                'before_sha256': digest(before.encode()),
                                'after_sha256': digest(after.encode())})
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                      fromfile='a/' + relative, tofile='b/' + relative))

contract_path = ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h'
# Read only a frozen pre-seal input. The current product header already
# contains this addition after application and cannot seed a replay.
contract_snapshot = STAGE.parent / 'before-seal/numerical_contract.h'
if not contract_snapshot.is_file():
    contract_snapshot = STAGE / 'numerical_contract.before.h'
contract = contract_snapshot.read_text(encoding='utf-8')
assert digest(contract.encode()) == 'c0ba96d143fc36c1244d72e14121ac72d461e2c52cd3156b83dd4c51726a873c'
contract_addition = '''// Private CUDA RoPE carrier for the existing explicit-frequency contract.
// src0=[D,H,S,B], src1=I32[S,1|B], src2=F32[pairs,1|S].
// Rotary dimensions are 2*pairs; no duplicate narrow integer metadata.
// Layout uses upstream NORMAL(interleaved) or NEOX(first/second half).
// All remaining op_params bytes are zero, not upstream YaRN parameters.
inline constexpr std::uint32_t kExplicitRopeContractParam = 0;
inline constexpr std::int32_t kExplicitRopeContract = 0x48595250;
inline constexpr std::uint32_t kExplicitRopeLayoutParam = 2;

'''
anchor = '} // namespace hyle::compute::ggml_cuda::internal'
assert contract.count(anchor) == 1
changes = write('hyle/numerical_contract.h', contract,
                contract.replace(anchor, contract_addition + anchor), contract_path)

rope_path = UPSTREAM / 'src/ggml-cuda/rope.cuh'
rope = rope_path.read_text(encoding='utf-8')
assert digest(rope.encode()) == '182542526249adc83170a534a427730aeeae54d4c863af7d7a6698a762ccdaa7'
rope_after = '#pragma once\n' + rope.replace('#include "common.cuh"', '#include "common.cuh"\n#include "numerical_contract.h"', 1)
rope_after += '''
// Kept separate from inverse-factor/YaRN RoPE, including all old fusers.
inline bool ggml_cuda_is_hyle_explicit_rope(const ggml_tensor * node) {
    return node && node->op == GGML_OP_ROPE &&
        ggml_get_op_params_i32(node, hyle::compute::ggml_cuda::internal::kExplicitRopeContractParam) ==
            hyle::compute::ggml_cuda::internal::kExplicitRopeContract;
}

bool ggml_cuda_supports_hyle_explicit_rope(const ggml_tensor * dst, int device, bool require_bound);
void ggml_cuda_op_hyle_explicit_rope(ggml_backend_cuda_context & ctx, ggml_tensor * dst);
'''
changes += write('src/ggml-cuda/rope.cuh', rope, rope_after, rope_path)

unary_path = BASE / 'src/ggml-cuda/unary.cu'
unary = unary_path.read_text(encoding='utf-8')
assert digest(unary.encode()) == '0d373afb04d81a12f7e76a1c281535724f6907493398fbef0ce7d59f3546c9e8'
unary_after = unary.replace('#include "mmvf.cuh"', '#include "mmvf.cuh"\n#include "rope.cuh"', 1)
unary_after += r'''

/* explicit-frequency RoPE, preserving the existing decomposed graph */

#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
// The old binary nodes are separate fast-math kernels. Preserve their exact
// RN/FTZ operations in this precise TU; intrinsics without FTZ would change
// subnormal behavior, and a C++ expression could accidentally contract to FMA.
static __device__ __forceinline__ float hyle_rope_mul(float a, float b) {
    float result;
    asm("mul.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

static __device__ __forceinline__ float hyle_rope_add(float a, float b) {
    float result;
    asm("add.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

static __device__ __forceinline__ float hyle_rope_sub(float a, float b) {
    float result;
    asm("sub.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

template <typename T>
static __global__ void hyle_explicit_rope(
        const T * data, const int32_t * positions, const float * frequencies, T * dst,
        int64_t width, int64_t heads, int64_t sequence, int64_t batch,
        int64_t dimensions, int64_t position_batches, int64_t frequency_sequences,
        bool interleaved, int64_t rotated_work, int64_t tail_elements, int64_t work) {
    ggml_cuda_pdl_lc();
    // One warp owns a phase. Trigonometry is evaluated once and reused by
    // every head (and by every B when positions are shared), without scratch.
    // All lanes reach the full-mask shuffles, including when heads < 32.
    const int lane = threadIdx.x;
    const int64_t pairs = dimensions / 2;
    ggml_cuda_pdl_sync();
    for (int64_t unit = blockIdx.x; unit < work; unit += gridDim.x) {
        if (unit < rotated_work) {
            const int64_t pair = unit % pairs;
            const int64_t row = unit / pairs;
            const int64_t s = row % sequence;
            const int64_t position_batch = row / sequence;
            float cosine = 0.0f, sine = 0.0f;
            if (lane == 0) {
                // Match cast(I32->F32), then frequency * position, in that
                // order. Do not keep the position as an exact integer longer.
                const float p = __int2float_rn(positions[s + sequence * position_batch]);
                const float f = frequencies[pair + pairs * (frequency_sequences == 1 ? 0 : s)];
                const float phase = hyle_rope_mul(f, p);
                // Separate strict full-range functions, as in old Unary.
                cosine = op_cos(phase);
                sine = op_sin(phase);
            }
            cosine = __shfl_sync(0xffffffffu, cosine, 0);
            sine = __shfl_sync(0xffffffffu, sine, 0);
            const int64_t row_heads = heads * (position_batches == 1 ? batch : 1);
            const int64_t first_component = interleaved ? 2 * pair : pair;
            const int64_t second_component = interleaved ? first_component + 1 : pair + pairs;
            for (int64_t h = lane; h < row_heads; h += 32) {
                const int64_t b = position_batches == 1 ? h / heads : position_batch;
                const int64_t head = h % heads;
                const int64_t base = width * (head + heads * (s + sequence * b));
                // Both loads precede both stores: exact dense allocator reuse
                // is safe, while partial aliases are rejected before launch.
                const float first = ggml_cuda_cast<float>(data[base + first_component]);
                const float second = ggml_cuda_cast<float>(data[base + second_component]);
                const float first_cosine = hyle_rope_mul(first, cosine);
                const float second_sine = hyle_rope_mul(second, sine);
                const float first_sine = hyle_rope_mul(first, sine);
                const float second_cosine = hyle_rope_mul(second, cosine);
                const float rotated_first = hyle_rope_sub(first_cosine, second_sine);
                const float rotated_second = hyle_rope_add(first_sine, second_cosine);
                dst[base + first_component] = ggml_cuda_cast<T>(rotated_first);
                dst[base + second_component] = ggml_cuda_cast<T>(rotated_second);
            }
        } else {
            const int64_t tail = width - dimensions;
            const int64_t linear = (unit - rotated_work) * 32 + lane;
            if (linear < tail_elements) {
                const int64_t offset = (linear / tail) * width + dimensions + linear % tail;
                if constexpr (std::is_same_v<T, float>) {
                    // Old F32 CONT/CONCAT tail is a copy, including NaN bits.
                    dst[offset] = data[offset];
                } else {
                    // The old graph widens the complete data tensor and then
                    // narrows the completed output. Keep that NaN/RNE boundary.
                    const float widened = ggml_cuda_cast<float>(data[offset]);
                    float converted;
                    // Opaque identity prevents folding the two conversions
                    // to a raw typed copy, which would retain signaling NaNs.
                    asm("mov.b32 %0, %1;" : "=f"(converted) : "f"(widened));
                    dst[offset] = ggml_cuda_cast<T>(converted);
                }
            }
        }
    }
}

static bool hyle_rope_dense_bytes(const ggml_tensor * tensor, size_t & bytes) {
    if (!tensor) {
        return false;
    }
    const size_t type_bytes = ggml_type_size(tensor->type);
    if (type_bytes == 0 || ggml_blck_size(tensor->type) != 1) {
        return false;
    }
    size_t extent = type_bytes;
    for (int d = 0; d < GGML_MAX_DIMS; ++d) {
        if (tensor->ne[d] <= 0 || tensor->nb[d] != extent ||
                uint64_t(tensor->ne[d]) > std::numeric_limits<size_t>::max() / extent) {
            return false;
        }
        extent *= size_t(tensor->ne[d]);
    }
    // All device index products below are signed int64_t, including tails.
    if (extent / type_bytes > uint64_t(std::numeric_limits<int64_t>::max())) {
        return false;
    }
    bytes = extent;
    return true;
}

static bool hyle_rope_range(const ggml_tensor * tensor, size_t bytes,
        uintptr_t & begin, uintptr_t & end) {
    begin = reinterpret_cast<uintptr_t>(tensor->data);
    if (!begin || begin % ggml_type_size(tensor->type) ||
            bytes > std::numeric_limits<uintptr_t>::max() - begin) {
        return false;
    }
    end = begin + bytes;
    return true;
}
#endif

bool ggml_cuda_supports_hyle_explicit_rope(const ggml_tensor * dst, int device, bool require_bound) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(dst, device, require_bound);
    return false;
#else
    using namespace hyle::compute::ggml_cuda::internal;
    if (!ggml_cuda_is_hyle_explicit_rope(dst) || !dst->src[0] || !dst->src[1] || !dst->src[2] ||
            device < 0 || device >= ggml_cuda_info().device_count ||
            !GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[device].cc)) {
        return false;
    }
    const auto * data = dst->src[0];
    const auto * positions = dst->src[1];
    const auto * frequencies = dst->src[2];
    if ((data->type != GGML_TYPE_F32 && data->type != GGML_TYPE_F16 && data->type != GGML_TYPE_BF16) ||
            dst->type != data->type || positions->type != GGML_TYPE_I32 || frequencies->type != GGML_TYPE_F32 ||
            !ggml_are_same_layout(data, dst)) {
        return false;
    }
    for (int s = 3; s < GGML_MAX_SRC; ++s) {
        if (dst->src[s]) {
            return false;
        }
    }
    // No YaRN factors, offsets or other upstream parameters share this ABI.
    for (size_t p = 3 * sizeof(int32_t); p < sizeof(dst->op_params); ++p) {
        if (reinterpret_cast<const uint8_t *>(dst->op_params)[p] != 0) {
            return false;
        }
    }
    const int64_t pairs = frequencies->ne[0];
    const int layout = ggml_get_op_params_i32(dst, kExplicitRopeLayoutParam);
    if (ggml_get_op_params_i32(dst, 1) != 0 || pairs <= 0 || pairs > data->ne[0] / 2 ||
            (layout != GGML_ROPE_TYPE_NORMAL && layout != GGML_ROPE_TYPE_NEOX) ||
            positions->ne[0] != data->ne[2] ||
            (positions->ne[1] != 1 && positions->ne[1] != data->ne[3]) ||
            positions->ne[2] != 1 || positions->ne[3] != 1 ||
            (frequencies->ne[1] != 1 && frequencies->ne[1] != data->ne[2]) ||
            frequencies->ne[2] != 1 || frequencies->ne[3] != 1) {
        return false;
    }
    const ggml_tensor * tensors[] = {data, positions, frequencies, dst};
    size_t sizes[4] = {};
    uintptr_t begin[4] = {}, end[4] = {};
    for (int i = 0; i < 4; ++i) {
        if (!hyle_rope_dense_bytes(tensors[i], sizes[i]) ||
                (require_bound && !hyle_rope_range(tensors[i], sizes[i], begin[i], end[i]))) {
            return false;
        }
    }
    if (require_bound) {
        for (int i = 0; i < 3; ++i) {
            const bool overlaps = begin[i] < end[3] && begin[3] < end[i];
            // GGML's allocator may reuse a private, sole-reader input. Keep
            // exactly that mapping, never a partial x alias or pos/freq alias.
            if (overlaps && !(i == 0 && begin[0] == begin[3])) {
                return false;
            }
        }
    }
    return true;
#endif
}

void ggml_cuda_op_hyle_explicit_rope(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (!ggml_cuda_supports_hyle_explicit_rope(dst, ctx.device, true)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
            "invalid explicit-frequency RoPE tensor contract");
    }
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    using namespace hyle::compute::ggml_cuda::internal;
    const auto * data = dst->src[0];
    const auto * positions = dst->src[1];
    const auto * frequencies = dst->src[2];
    const int64_t dimensions = 2 * frequencies->ne[0];
    const bool interleaved = ggml_get_op_params_i32(dst, kExplicitRopeLayoutParam) == GGML_ROPE_TYPE_NORMAL;
    const int64_t rotated_work = (dimensions / 2) * data->ne[2] * positions->ne[1];
    const int64_t tail_elements = (data->ne[0] - dimensions) * data->ne[1] * data->ne[2] * data->ne[3];
    const int64_t tail_work = tail_elements / 32 + (tail_elements % 32 != 0);
    if (rotated_work > std::numeric_limits<int64_t>::max() - tail_work) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
            "explicit-frequency RoPE work extent overflow");
    }
    const int64_t work = rotated_work + tail_work;
    const unsigned int blocks = unsigned(std::min<int64_t>(work, 65535));
    const auto launch = [&](auto * typed_dst) {
        using T = std::remove_pointer_t<decltype(typed_dst)>;
        const ggml_cuda_kernel_launch_params launch_params(dim3(blocks), 32, 0, ctx.stream());
        ggml_cuda_kernel_launch(hyle_explicit_rope<T>, launch_params,
            static_cast<const T *>(data->data), static_cast<const int32_t *>(positions->data),
            static_cast<const float *>(frequencies->data), typed_dst,
            data->ne[0], data->ne[1], data->ne[2], data->ne[3], dimensions,
            positions->ne[1], frequencies->ne[1], interleaved, rotated_work, tail_elements, work);
    };
    switch (dst->type) {
        case GGML_TYPE_F32: launch(static_cast<float *>(dst->data)); break;
        case GGML_TYPE_F16: launch(static_cast<half *>(dst->data)); break;
        case GGML_TYPE_BF16: launch(static_cast<nv_bfloat16 *>(dst->data)); break;
        default: hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
                     "unsupported explicit-frequency RoPE output type");
    }
#else
    GGML_UNUSED_VARS(ctx, dst);
#endif
}
'''
changes += write('src/ggml-cuda/unary.cu', unary, unary_after, unary_path)

main_path = BASE / 'src/ggml-cuda/ggml-cuda.cu'
main = main_path.read_text(encoding='utf-8')
assert digest(main.encode()) == '3236cc09eb2cbbb334ddddb57724dc98f0dd95521589fb3f5afa0d01736716e4'
main_after = main
anchor = 'static void * ggml_backend_cuda_buffer_get_base(ggml_backend_buffer_t buffer) {'
assert main_after.count(anchor) == 1
main_after = main_after.replace(anchor, r'''// No CUDA pointer query on the hot path: resource admission already binds
// actual device buffers. Check their native owner and exact bounded range.
static bool ggml_cuda_hyle_explicit_rope_bound(const ggml_tensor * dst, int device) {
    if (!ggml_cuda_supports_hyle_explicit_rope(dst, device, true)) {
        return false;
    }
    const ggml_tensor * tensors[] = {dst->src[0], dst->src[1], dst->src[2], dst};
    for (const auto * tensor : tensors) {
        if (!tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) {
            return false;
        }
        const auto * context = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (context->device != device || !context->dev_ptr) {
            return false;
        }
        const uintptr_t base = reinterpret_cast<uintptr_t>(context->dev_ptr);
        const uintptr_t begin = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        if (begin < base || begin - base > capacity || ggml_nbytes(tensor) > capacity - (begin - base)) {
            return false;
        }
    }
    return true;
}

''' + anchor, 1)
anchor = '''        case GGML_OP_ROPE:
            ggml_cuda_op_rope(ctx, dst);
            break;'''
assert main_after.count(anchor) == 1
main_after = main_after.replace(anchor, '''        case GGML_OP_ROPE:
            if (ggml_cuda_is_hyle_explicit_rope(dst)) {
                if (!ggml_cuda_hyle_explicit_rope_bound(dst, ctx.device)) {
                    hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
                        "invalid explicit-frequency RoPE device binding");
                }
                ggml_cuda_op_hyle_explicit_rope(ctx, dst);
            } else {
                ggml_cuda_op_rope(ctx, dst);
            }
            break;''', 1)
anchor = '''        if (ggml_hyle_stable_silu(cgraph->nodes[node_idx + j]) &&'''
assert main_after.count(anchor) == 1
main_after = main_after.replace(anchor, '''        // Explicit frequencies use strict trigonometry and different src1/2
        // semantics; none of the inverse-factor RoPE fusers may consume it.
        if (ggml_cuda_is_hyle_explicit_rope(cgraph->nodes[node_idx + j])) {
            return false;
        }
''' + anchor, 1)
anchor = '''        case GGML_OP_ROPE:
        case GGML_OP_ROPE_BACK: {
            return op->src[0]->nb[0] == ggml_type_size(op->src[0]->type) && ggml_is_contiguous_2(op->src[0]);
        }'''
assert main_after.count(anchor) == 1
main_after = main_after.replace(anchor, '''        case GGML_OP_ROPE:
            if (ggml_cuda_is_hyle_explicit_rope(op)) {
                return ggml_cuda_supports_hyle_explicit_rope(op, dev_ctx->device, false);
            }
            [[fallthrough]];
        case GGML_OP_ROPE_BACK: {
            return op->src[0]->nb[0] == ggml_type_size(op->src[0]->type) && ggml_is_contiguous_2(op->src[0]);
        }''', 1)
changes += write('src/ggml-cuda/ggml-cuda.cu', main, main_after, main_path)

(STAGE / 'changes.diff').write_text(changes, encoding='utf-8', newline='\n')
(STAGE / 'replacements.json').write_text(json.dumps({'files': replacement_records}, indent=2) + '\n',
                                       encoding='utf-8', newline='\n')
(STAGE / 'source-freeze.json').write_text(json.dumps({
    'state': 'Scratch native overlay only, not compiled or run; not product manifest or lock.',
    'files': records,
    'numerical_contract': 'Existing explicit_rope.h: typed->F32; I32 RN->F32; independent RN/FTZ binary kernels; strict separate sin/cos; four products, sub/add; typed RNE output; widened/narrowed typed tail.',
    'marker': {'op': 'GGML_OP_ROPE', 'params': [0x48595250, 0, 'NORMAL(interleaved)|NEOX(half)'], 'dimensions': '2*src2.ne[0], after pairs>0 and pairs<=src0.ne[0]/2 validation', 'remaining_param_bytes': 0},
    'work': 'One warp per position_batch, sequence and pair; one strict sine/cosine reused for heads and shared-position B; tail warp work shares the same launch; no temporary allocations.',
    'alias': 'Exact internal src0/dst mapping allowed for existing GGML allocator reuse; partial src0 overlap and all dst/positions/frequencies overlap rejected; no public alias capability change.',
    'limits': 'NVIDIA CUDA only; scalar BF16 convert uses the existing software-capable conversion path, no BF16 MMA requirement. No runtime GPU evidence; source review and intended checks only.'
}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'files': len(records), 'stage': str(STAGE), 'freeze_sha256': digest((STAGE / 'source-freeze.json').read_bytes())}))
