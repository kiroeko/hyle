from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
OVERLAY = STAGE.parent
files = []
for relative in ('hyle/numerical_contract.h', 'src/ggml-cuda/unary.cu'):
    before = (STAGE / 'before' / relative).read_text(encoding='utf-8')
    after = (OVERLAY / 'source' / relative).read_text(encoding='utf-8')
    before_lines, after_lines = before.splitlines(True), after.splitlines(True)
    context = 3
    while True:
        edits = []
        for group in difflib.SequenceMatcher(None, before_lines, after_lines,
                                            autojunk=False).get_grouped_opcodes(context):
            edits.append({'before': ''.join(before_lines[group[0][1]:group[-1][2]]),
                          'after': ''.join(after_lines[group[0][3]:group[-1][4]])})
        replayed = before
        for edit in edits:
            if not edit['before'] or replayed.count(edit['before']) != 1:
                break
            replayed = replayed.replace(edit['before'], edit['after'], 1)
        else:
            if replayed == after:
                break
        context *= 2
        assert context < len(before_lines) * 2
    sha = lambda value: hashlib.sha256(value.encode()).hexdigest()
    files.append({'path': relative, 'before_sha256': sha(before), 'after_sha256': sha(after), 'edits': edits})
output = {'state': 'Unique amendment against the applied initial v17 native overlay; no compilation or GPU run.',
          'reason': 'Derive dimensions from actual F32 frequency pair shape without narrowing public size_t dimensions into duplicate int32 metadata.',
          'contract': 'op_params=[marker,0,layout,0...]; pairs=src2.ne0>0 and pairs<=src0.ne0/2 checked before dimensions=2*pairs.',
          'files': files}
path = STAGE / 'replacements.json'
path.write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'files': [(f['path'], f['before_sha256'], f['after_sha256'], len(f['edits'])) for f in files]}))
