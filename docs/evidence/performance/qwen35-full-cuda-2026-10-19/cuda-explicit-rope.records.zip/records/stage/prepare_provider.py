"""Prepare the CUDA-only native explicit-frequency RoPE lowering overlay."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
SOURCE = ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    snapshot = STAGE / 'before/src/compute_provider_ggml_cuda/tensor_program.cc'
    before = (snapshot if snapshot.is_file() else SOURCE).read_bytes()
    text = before.decode('utf-8').replace('\r\n', '\n')
    old_include = '#include "explicit_rope.h"\n'
    old_lowering = '''    result = ggml_runtime::explicit_rope(
        context, values[node.inputs[0]], values[node.inputs[1]],
        values[node.inputs[2]], rope->rotary_dimensions,
        rope->layout == RopeLayout::kInterleaved);'''
    new_lowering = '''    // One native operation retains the original explicit-frequency F32
    // arithmetic and final output rounding. The private marker prevents the
    // standard inverse-factor RoPE kernels and fusions from interpreting it.
    auto *data = values[node.inputs[0]];
    result = ggml_dup_tensor(context, data);
    result->op = GGML_OP_ROPE;
    result->src[0] = data;
    result->src[1] = values[node.inputs[1]];
    result->src[2] = values[node.inputs[2]];
    std::fill_n(result->op_params,
                GGML_MAX_OP_PARAMS / sizeof(result->op_params[0]), 0);
    result->op_params[kExplicitRopeContractParam] = kExplicitRopeContract;
    result->op_params[kExplicitRopeLayoutParam] =
        rope->layout == RopeLayout::kInterleaved ? GGML_ROPE_TYPE_NORMAL
                                                : GGML_ROPE_TYPE_NEOX;'''
    if text.count(old_include) != 1 or text.count(old_lowering) != 1:
        raise ValueError('Unexpected CUDA RoPE source; refusing a broad rewrite')
    after = text.replace(old_include, '', 1).replace(old_lowering, new_lowering, 1)
    target = STAGE / 'provider-overlay/src/compute_provider_ggml_cuda/tensor_program.cc'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after, encoding='utf-8', newline='\n')
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(before)
    diff = ''.join(difflib.unified_diff(text.splitlines(True), after.splitlines(True),
        fromfile='a/src/compute_provider_ggml_cuda/tensor_program.cc',
        tofile='b/src/compute_provider_ggml_cuda/tensor_program.cc'))
    (STAGE / 'provider-change.diff').write_text(diff, encoding='utf-8')
    record = {'status': 'overlay_only_not_built', 'source': str(SOURCE),
        'before_sha256': digest(before), 'overlay': str(target),
        'after_sha256': digest(target.read_bytes()),
        'scope': 'CUDA lowering only; shared explicit_rope.h and other backends unchanged',
        'semantics': 'I32 RN cast; F32 multiply/sin/cos/products/add-sub; original final dtype',
        'public_API_changed': False}
    (STAGE / 'provider-source-freeze.json').write_text(json.dumps(record, indent=2)+'\n',
        encoding='utf-8')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
