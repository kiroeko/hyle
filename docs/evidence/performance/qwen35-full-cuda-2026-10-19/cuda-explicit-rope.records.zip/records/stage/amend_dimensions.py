"""Remove redundant narrow metadata before the first v17 compilation."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('rope_own_seal', STAGE / 'seal.py')
owner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owner)
s = owner.s


def main():
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    snapshot = STAGE / 'initial-v17'
    snapshot.mkdir(exist_ok=False)
    for path in (vendor / 'patches.json', ROOT / 'cmake/HyleDependencyLock.json',
                 STAGE / 'native-source-freeze.json', STAGE / 'provider-version.h'):
        (snapshot / path.name).write_bytes(path.read_bytes())
    changes = s.read(STAGE / 'native-overlay/dimension-amendment/replacements.json')
    manifest = s.read(vendor / 'patches.json')
    for change in changes['files']:
        if change['path'].startswith('hyle/'):
            path = ROOT / 'src/compute_provider_ggml_cuda/numerical_contract.h'
            data = path.read_bytes()
            if s.sha(data) != change['before_sha256']:
                raise ValueError('Contract changed before amendment')
            for edit in change['edits']:
                old, new = edit['before'].encode(), edit['after'].encode()
                if data.count(old) != 1:
                    raise ValueError('Contract amendment context is not unique')
                data = data.replace(old, new, 1)
            if s.sha(data) != change['after_sha256']:
                raise ValueError('Contract amendment hash differs')
            path.write_bytes(data)
            continue
        row = next(row for row in manifest['files'] if row['path'] == change['path'])
        row['edits'].extend(change['edits'])
        row['after_sha256'] = s.sha(owner.replay(row))
    proposed = STAGE / 'patches.final-draft.json'
    s.save(proposed, manifest)
    runtime = ROOT / 'src/compute_ggml_runtime'
    mixed, combined = STAGE / 'mixed-cpu-manifest.json', STAGE / 'combined-manifest.json'
    s.load('rope_amended_iq1', runtime / 'prepare_cuda_iq1_manifest.py').derive(
        s.UPSTREAM, mixed, proposed, vendor / 'iq1-patches.json', combined)
    expected = {row['path']: row for row in s.read(STAGE / 'native-overlay/source-freeze.json')['files']}
    sources = {}
    for row in s.read(combined)['files']:
        data = owner.replay(row)
        if s.sha(data) != row['after_sha256']:
            raise ValueError('Combined amendment source hash differs')
        if row['path'] in expected:
            if s.sha(data) != expected[row['path']]['after_sha256']:
                raise ValueError('Reviewed amendment differs')
            (STAGE / 'native-source' / row['path']).write_bytes(data)
            sources[row['path']] = s.sha(data)
    if len(sources) != 3:
        raise ValueError('Expected three native files')
    provider = s.read(STAGE / 'provider-source-freeze.json')
    path = ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'
    if s.sha(path.read_bytes()) != provider['after_sha256']:
        raise ValueError('Provider source changed before amendment')
    old = '    result->op_params[kExplicitRopeDimensionsParam] =\n        static_cast<std::int32_t>(rope->rotary_dimensions);\n'
    text = path.read_text(encoding='utf-8')
    if text.count(old) != 1:
        raise ValueError('Provider dimension metadata differs')
    text = text.replace(old, '', 1)
    path.write_text(text, encoding='utf-8', newline='\n')
    Path(provider['overlay']).write_bytes(path.read_bytes())
    provider['after_sha256'] = s.sha(path.read_bytes())
    provider['dimensions'] = 'Derived without narrowing from the already-validated frequency shape; reserved param1 stays zero'
    s.save(STAGE / 'provider-source-freeze.json', provider)
    (vendor / 'patches.json').write_bytes(proposed.read_bytes())
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = s.read(lock_path)
    entries = {row['name']: row for row in lock['dependencies']}
    entries['ggml_cuda_runtime_patches']['vendored']['tree_sha256'] = s.tree(vendor)
    s.save(lock_path, lock)
    identity = entries['ggml_runtime_patches']['vendored']['tree_sha256']
    identity += entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']
    identity += s.sha((runtime / 'prepare_mixed_cpu_manifest.py').read_bytes())
    identity += s.sha((runtime / 'prepare_cuda_iq1_manifest.py').read_bytes())
    identity += s.tree(vendor)
    source_id = s.sha(identity.encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + source_id + '"\n', encoding='utf-8')
    freeze = s.read(STAGE / 'native-source-freeze.json')
    freeze.update(source_id=source_id, sources=sources, vendor_tree_sha256=s.tree(vendor))
    s.save(STAGE / 'native-source-freeze.json', freeze)
    print('AMENDED', source_id, 'dimensions from exact frequency shape')


if __name__ == '__main__':
    main()
