"""Run the two RoPE cases and the retained 28-case CUDA regression closure."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rope_test_build', STAGE / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
b, c = build.b, build.c
plan_path = Path(sys.argv[1]).resolve()
plan = c.read(plan_path)
build.check(plan)
out = plan_path.parent / 'run-cuda'
out.mkdir(exist_ok=False)
(out / 'tmp').mkdir()
old = build.ARCH / 'cuda-bf16-dual-projection/tests-build/20261019T085621/run-cuda'
filters = ['GgmlCudaExplicitRope.*']
for name in ('dual', 'retained'):
    command = c.read(old / (name + '.command.json'))['command']
    filters.append(next(x.split('=', 1)[1] for x in command if x.startswith('--gtest_filter=')))
env, _ = b.environment(plan['links']['cuda']['command'], [r['path'] for r in plan['cached_inputs']], out)
c.execute('cuda', [plan['links']['cuda']['image'], '--gtest_color=no', '--gtest_filter=' + ':'.join(filters),
    '--gtest_output=xml:' + str(out / 'cuda.xml')], env, out)
root = ET.parse(out / 'cuda.xml').getroot()
summary = {key: int(root.attrib.get(key, '0')) for key in ('tests', 'failures', 'disabled', 'errors')}
summary['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in root.findall('testsuite'))
summary['passed'] = summary['tests'] == 30 and not any(summary[k] for k in ('failures', 'disabled', 'errors', 'skipped'))
c.save(out / 'summary.json', summary)
if not summary['passed']:
    raise ValueError('Expected all 30 cases, zero fail/skip')
print('CUDA_CASES', summary, flush=True)
