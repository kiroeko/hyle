# ggml CUDA integration patches

Upstream: https://github.com/ggml-org/ggml at
`456172ec733a135778adcd32d00e576a58232e45` (MIT; see LICENSE).

The owning CMake applies the exact context-matched edits in `patches.json` to
a build-local copy of authenticated upstream source. Shared source caches and
upstream checkouts remain unchanged. The manifest pins both original and
result hashes; this directory does not contain a second runtime distribution.

Edits preserve native CUDA Runtime, Driver and cuBLAS errors at the private
C++ adapter boundary. Resource owners roll back partial construction; cleanup
does not throw. Capture begin/end/encoding failures release the global capture
counter and discard incomplete graphs. Virtual-memory mapping failures release
their allocation handle and partial mapping. Non-owning buffer wrappers never
free external tensor payload. Backend streams, pools, algorithms, fusion and
capture selection remain upstream-owned. The precision and mathematical
changes are documented below.

The private bridge implementation is in `src/compute_provider_ggml_cuda` and
is compiled into the upstream translation unit. It is not an installed API.
Numerical behavior, Direct/Graph execution and failure recovery still require
tests of the operations and lifetimes being used.

The narrow IQ1_XS/XXS/XXXS CUDA programs in `iq1-patches.json` and the three
MMQ template instances originate from Unsloth llama.cpp
`46cbf0e95786fe8f5b7c0e86d57aaf8f8eceea7f` (MIT, same LICENSE).
Original CUDA tables, conversion, dot products, MMVQ/MMQ math and dispatch
blocks remain unchanged. The newer core's three block-size traits and the
template include path are ABI/build adaptations. `iq1-origins.json` retains
the original block and template SHA-256 identities. They share the existing
physical types/codecs with the original CPU port, not a second ggml runtime.
Only the CUDA route compiles these programs; CPU-only/Metal/Vulkan pins and
math remain unchanged. This source port is not runtime or performance proof.

The F32 MMF tiles in this pin execute TF32 multiplication. The original regular
MUL_MAT, MUL_MAT_ID and corresponding capture-suitability selection are guarded
so a requested native F32 operand contract on F32 weights reaches the original
F32 cuBLAS/sorting program instead. An explicit F32 source request also uses
DEFAULT_MATH within the F32 cuBLAS call: COMPUTE_32F alone does not disable the
handle's TF32 mode. The private handle's previous mode is restored on return
and exception unwind. Default precision and GEMM kernels remain upstream.
These are precision-selection changes, not a new GEMM implementation.

The original CUDA DIAG_MASK_INF kernel subtracted FLT_MAX. This does not
exclude a future score containing positive infinity, and can leave a very
large finite score visible. The exact patch replaces every excluded element
with negative infinity and preserves each permitted value. The original
launch geometry and attention scale, additive-bias, softmax and PV programs
remain unchanged; no mask-content scan or host fallback is added.

The existing float elementwise templates also accept homogeneous BF16 inputs
and outputs for Add/Sub/Mul/Div, their bit-preserving Repeat broadcasts, and
Abs/Neg/Exp/Log/Sqrt/Tanh/Sigmoid. Values widen to F32 on load and round to BF16
on each operation's store; the original float arithmetic and launch geometry
remain unchanged. Consecutive BF16 Add/Mul nodes do not use the native multi-op
fusion, which would otherwise remove intermediate BF16 rounding. Original
F32/F16 dispatch and fusion behavior, and composite Rsqrt, remain unchanged.

Caller-owned CUDA capture records the same factored native encoder without
private graph warmup, instantiation or launch. The exact lowered graph uses
the original graph-enabled metadata and capture-compatibility checks. Creating
or refreshing that original metadata entry performs no model mathematics or
native graph instantiation. It preserves the original Mean CUB threshold in
Commands and outer capture alike; environment/architecture-disabled native
graphs remain ineligible rather than taking a different reduction algorithm.
Original lazy handles, streams and caching pools stay owned by that backend.
Only this outer recording permits their allocation in a local Relaxed scope;
pool OOM does not synchronize/flush, and its 256-entry retaining limit counts
both cached and checked-out buffers before allocating. Original Commands and
private native capture keep their previous allocator and selection behavior.
The original preparation Completion holds the process-wide cuBLAS destruction
exclusion through outer End/abort, then observes any failed auxiliary prefix.
No model mathematics executes during recording. A captured graph must be
destroyed before reusing its invocation's pool through a new preparation;
the owning Graph slot already enforces that order.

The original MMVF template additionally accepts a narrow homogeneous BF16
weight/activation/output carrier: one output column, no IDs or fusion,
requested F32 accumulation, dense native layouts and the existing MMVF
shape/device predicate. Activation pairs widen exactly on load; the original
F32 accumulation and warp/shared reduction are reused, followed by an explicit
BF16 round-to-nearest-even store. No whole-tensor input conversion or weight
copy is introduced. Existing float activation/output instantiations retain
their arithmetic and launch selection. This extension does not add a GLU or
ordinary SiLU epilogue, change public descriptors, or establish performance
or model-quality results. Default projection routing is qualified separately.

The original RMSNorm template also carries a checked BF16 widen/RMSNorm/
optional F32-scale/narrow chain. It reads BF16 directly, keeps the original
F32 partial sums, block reduction, epsilon and reciprocal square root, and
stores with explicit BF16 round-to-nearest-even. A scale inside the original
F32 chain is applied before that final rounding. A separate BF16 norm output
followed by a scale retains its intermediate rounding and is not folded into
the weighted variant. Original F32 RMSNorm, multiply and add paths retain
their existing arithmetic and launch choice.

Matching keeps published intermediate values, extra readers and views, and
checks output overlap with every actual input, including OP_NONE leaves.
The BF16 input may share exactly the output's dense shape, strides and byte
range: each row's original block reduction synchronizes its reads before
stores, and each epilogue thread reads and writes only its own columns.
Partial, strided and broadcast overlaps remain ineligible; the F32 scale
must always be disjoint. CPY self references are counted explicitly. The extension
uses the original backend graph, allocator and encoder; it neither changes
public descriptors nor establishes throughput, workspace or quality results.

The composed BF16 square/SUM_ROWS/epsilon/Rsqrt/multiply pattern has a separate
NVIDIA CUDA carrier. It retains the original eight partial sums, launch-dependent
reduction tree and thread-zero result, and every BF16 round-to-nearest-even
boundary. Explicit RN sqrt without FTZ keeps the precise unary object's sqrt
edge separate from the original fast-math division. Runtime epsilon and the
original repeated numerator remain actual inputs. The repeat and following
public cast are not removed. Matching retains published values and extra readers,
counts CPY self references, and accepts only identical dense reshape origins;
output may alias its dense BF16 input exactly, but cannot overlap epsilon or
numerator. Original per-operation math remains the fallback.

The dense single-vector BF16 dual-projection implementation shares the original
MMVF carrier through its private header and instantiates its new epilogue in the
existing precise unary translation unit. Both F32 dot accumulations round to
BF16 independently; ordinary stable SiLU rounds again before the final multiply
and BF16 store. The floating dot reduction is an implementation variant, not a
bitwise promise against cuBLASLt. Four actual closed BF16 nodes, declared F32
accumulation, device/layout/alignment and disjoint output/read ranges are checked.
The implementation reads both original weights without packing or copying them.
Default MMVF, quantized GLU and other native paths retain their old epilogues.
The matcher also admits the other projection's actual readonly weight transpose
between the four math nodes, retaining its exact shape, strides, origin and sole
reader. It consumes the real native span without bypassing casts, copies, CONT
or mathematical values; the existing private intermediate checks remain intact.
