#pragma once

#include <cstdint>

namespace hyle::compute::ggml_cuda::internal {

// Private native UNARY metadata; zero retains upstream Unary/GLU behavior.
inline constexpr std::uint32_t kUnaryContractParam = 1;
inline constexpr std::int32_t kStableSiluContract = 0x48595349;

} // namespace hyle::compute::ggml_cuda::internal
