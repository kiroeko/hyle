"""Archive source and actual evidence; leave SDKs, weights and binary caches out."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
DEST = ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-explicit-rope.zip'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if DEST.exists():
        raise ValueError('Archive already exists')
    products = ('src/compute_provider_ggml_cuda/tensor_program.cc',
        'src/compute_provider_ggml_cuda/numerical_contract.h',
        'src/compute_ggml_runtime/explicit_rope.h', 'tests/graph_route_cuda/stable_silu_test.cc',
        'third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/NOTICE.md',
        'cmake/HyleDependencyLock.json', 'docs/architecture/compute-design.md',
        'docs/developer/current-work.md', 'docs/implementation/model-operators.md',
        'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md', 'test.ps1')
    files = [('product/' + relative, ROOT / relative) for relative in products]
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if not path.is_file() or 'tmp' in path.relative_to(STAGE).parts:
            continue
        if path.suffix.lower() in ('.exe', '.obj', '.pdb', '.lib', '.exp', '.dll', '.pyc'):
            continue
        files.append(('stage/' + path.relative_to(STAGE).as_posix(), path))
    records = []
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in files:
            data = path.read_bytes()
            records.append({'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)})
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC failure')
        for row in records:
            if sha(archive.read(row['entry'])) != row['sha256']:
                raise ValueError('Archive payload hash differs')
    receipt = {'path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': sha(DEST.read_bytes()),
        'payloads': len(records), 'CRC_and_payload_SHA_verified': True,
        'SDKs_models_objects_executables_excluded': True}
    (STAGE / 'archive-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    DEST.with_name('cuda-explicit-rope-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
