from pathlib import Path
import hashlib,json
root=Path.cwd();stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
freeze=json.loads((stage/'source-freeze.json').read_text())
changed=[]
for row in freeze['files']:
 current=(root/row['path']).read_bytes()
 if hashlib.sha256(current).hexdigest()!=row['sha256']:changed.append(row['path'])
assert changed==['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'],changed
for name in ['source-freeze.json','source.diff','integration-review.json','native-source-identities.json']:
 src=stage/name;dest=stage/('initial-'+name)
 if dest.exists():assert dest.read_bytes()==src.read_bytes(),str(dest)
 else:dest.write_bytes(src.read_bytes())
name='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
dest=stage/'initial-candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((stage/'candidate'/name).read_bytes())
initial=(stage/'candidate'/name).read_text();final=(root/name).read_text()
assert initial.count('      invocation.failed = true;')-final.count('      invocation.failed = true;')==1
assert initial.count('    invocation.failed = true;')-final.count('    invocation.failed = true;')==2
assert initial.replace('    if (!bound.ok()) {\n      invocation.failed = true;\n      return bound;\n    }', '    if (!bound.ok())\n      return bound;',1).replace('    invocation.failed = true;\n    return failure();','    return failure();',1)==final
(stage/'cold-rejection-fix.json').write_text(json.dumps(dict(owner='root',change='Remove exactly two failed=true writes from cold finish_bind failure/exception; no GPU work accepted. A rejected cold binding remains retryable.',initial_freeze_sha256=hashlib.sha256((stage/'initial-source-freeze.json').read_bytes()).hexdigest(),initial_provider_sha256=hashlib.sha256((stage/'initial-candidate'/name).read_bytes()).hexdigest(),final_provider_sha256=hashlib.sha256((root/name).read_bytes()).hexdigest(),validation='No new compile/GPU by this agent; validator separately recompiles this host owner.'),indent=2)+'\n')
