from pathlib import Path
import hashlib,json,difflib
root=Path.cwd();stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only/test-maintenance'
paths=[r['path'] for r in json.loads((stage/'before-identities.json').read_text())];rows=[];diff=[]
for name in paths:
 data=(root/name).read_bytes();old=(stage/'before'/name).read_bytes();out=stage/'candidate'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),before_sha256=hashlib.sha256(old).hexdigest()))
 diff.extend(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+name,tofile='candidate/'+name))
(stage/'source.diff').write_text(''.join(diff),encoding='utf-8')
receipt=dict(files=rows,actual_path_correction='The old hard RequireCapture false assertion is in graph_provider_ggml_cuda/tensor_test_support.h, not the Compute same-named header. Parent approved the real owner and region_test.cc to preserve existing build dependencies.',changes=['Existing Graph tensor fixture follows the selected actual compiled capture capability and retains Unimplemented expectation for actual false domains.','One new F32 [1,50000] single-row Mean test compiles/prepares a fresh ordinary Graph before any model math, checks destination sentinel bits unchanged, then compares original Direct Commands and captured replay output bits and the existing F32 2e-6 independent FP64 budget.'],source_shape='Real original ggml Mean via Reduce over axis1, keep_dimensions=true; nonuniform decimal/sinusoidal float inputs, FP64 sum uses actual uploaded float values.',fresh_owner='tests/graph_provider_ggml_cuda/region_test.cc',suggested_filter='GgmlCudaGraph.ColdMeanCaptureKeepsOriginalCubSelectionAndDoesNotExecute:GgmlCudaGraph.TensorRegionPreservesRoundingPublishedIntermediatesAndOldResults',validation='Not compiled or run by this agent; root/validator owns one fresh test TU and serialized GPU run. No CMake/product/SDK changes.')
(stage/'source-freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(receipt=str(stage/'source-freeze.json'),bytes=(stage/'source-freeze.json').stat().st_size,sha256=hashlib.sha256((stage/'source-freeze.json').read_bytes()).hexdigest(),files=rows),indent=2))
