from pathlib import Path
stage=Path('.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only')
p=stage/'freeze.py';s=p.read_text(encoding='utf-8-sig');s=s.replace('Actual native graph checker refines proposal capture upper bound; CUB build stays false.','Original native graph-enabled metadata and checker refine the capture upper bound and preserve the same enabled Mean CUB threshold.');p.write_text(s,encoding='utf-8')
