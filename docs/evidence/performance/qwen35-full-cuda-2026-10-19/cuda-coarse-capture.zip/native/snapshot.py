from pathlib import Path
import hashlib,json
root=Path.cwd(); out=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
paths=['src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_provider_ggml_cuda/program.h','src/compute_provider_ggml_cuda/native_bridge.h','src/compute_provider_ggml_cuda/native_bridge_impl.h','src/graph_provider_ggml_cuda/ggml_cuda_region.cc','third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md','cmake/HyleDependencyLock.json','src/compute_backend_cuda/native_context.h','src/compute_backend_cuda/cuda_backend.cc']
rows=[]
for name in paths:
 data=(root/name).read_bytes(); dest=out/'before'/name
 if dest.exists(): assert dest.read_bytes()==data, name
 else: dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data)
 rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(out/'before-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
