from pathlib import Path
import hashlib,json
root=Path.cwd();stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only/test-maintenance';stage.mkdir(parents=True,exist_ok=True)
paths=['tests/graph_provider_ggml_cuda/tensor_test_support.h','tests/graph_provider_ggml_cuda/region_test.cc'];rows=[]
for name in paths:
 data=(root/name).read_bytes();out=stage/'before'/name
 assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(stage/'before-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
