from pathlib import Path
import hashlib,json
stage=Path('.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only')
freeze=stage/'source-freeze.json'; data=json.loads(freeze.read_text());data['cold_rejection_revision']=json.loads((stage/'cold-rejection-fix.json').read_text());data['native_source_unchanged_from_initial_freeze']=json.loads((stage/'initial-native-source-identities.json').read_text())==json.loads((stage/'native-source-identities.json').read_text());freeze.write_text(json.dumps(data,indent=2)+'\n')
review=stage/'integration-review.json'; data=json.loads(review.read_text());data['native_freeze_sha256']=hashlib.sha256(freeze.read_bytes()).hexdigest();data['followup_cold_retry_fix']={'discovered_by':'Independent backend_assembly_design review after the first native freeze.','changed_by':'root','actual_change':'Removed exactly two invocation.failed=true writes and redundant if braces on cold finish_bind rejection/exception. No command accepted; repeat cold binding remains permitted.','status':'Final source frozen; separate validator recompiles the sole changed host TU. No new runtime success is claimed by this review.'};review.write_text(json.dumps(data,indent=2)+'\n')
for path in [freeze,review,stage/'cold-rejection-fix.json']:
 print(json.dumps(dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())))
