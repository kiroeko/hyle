from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
root=Path.cwd(); stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
normalize=lambda data:data.replace(b'\r\n',b'\n')
sha=lambda data:hashlib.sha256(data).hexdigest()
lockpath=root/'cmake/HyleDependencyLock.json'; text=lockpath.read_text();lock=json.loads(text)
entry=next(x for x in lock['dependencies'] if x['name']=='ggml_cuda_runtime_patches')
vendor=root/entry['vendored']['path']; manifest=''
for path in sorted(vendor.rglob('*'), key=lambda p:p.relative_to(vendor).as_posix()):
 if path.is_file():
  assert not path.is_symlink()
  manifest+=path.relative_to(vendor).as_posix()+'|'+sha(normalize(path.read_bytes()))+'\n'
oldtree=entry['vendored']['tree_sha256'];newtree=sha(manifest.encode())
oldnotice=next(x['sha256'] for x in entry['license']['files'] if x['path'].endswith('/NOTICE.md'))
newnotice=sha(normalize((vendor/'NOTICE.md').read_bytes()))
# Replace only this owning dependency's fields; unrelated lock bytes are kept.
start=text.index('"name": "ggml_cuda_runtime_patches"');end=text.index('\n    },',start)
block=text[start:end];assert block.count(oldtree)==1 and block.count(oldnotice)==1
block=block.replace(oldtree,newtree).replace(oldnotice,newnotice)
block=block.replace('hyle-ggml-cuda-resource-iq1-f32-causal-bf16-v6','hyle-ggml-cuda-resource-iq1-f32-causal-bf16-record-v7')
lockpath.write_text(text[:start]+block+text[end:],encoding='utf-8',newline='\n')
# Complete canonical math/type/runtime composition, never the runtime-only tree.
path=root/'.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/build.py'
spec=importlib.util.spec_from_file_location('canonical_native_source',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
contents,derived_manifest,source_id=mod.generate(False)
rows=[]
for name in ['src/ggml-cuda/ggml-cuda.cu','src/ggml-cuda/binbcast.cu','src/ggml-cuda/unary.cu']:
 data=contents[name];dest=stage/'native-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 rows.append(dict(path=str(dest),bytes=len(data),sha256=sha(data)))
common=contents['src/ggml-cuda/common.cuh'];reference=root/'.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/common.cuh'
assert common==reference.read_bytes(),'native shared ABI header drift'
for case in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
 assert contents['src/ggml-cuda/ggml-cuda.cu'].count(('case GGML_TYPE_'+case+':').encode())==1
prior=root/'.scratch/architecture-refactor-2026-10-18/cuda-bfloat-elementwise/native-source/src/ggml-cuda'
for name in ['binbcast.cu','unary.cu']:assert contents['src/ggml-cuda/'+name]==(prior/name).read_bytes()
(stage/'derived-manifest.json').write_text(json.dumps(derived_manifest,indent=2)+'\n')
(stage/'native-source-identities.json').write_text(json.dumps(dict(source_id=source_id,canonical_generator=str(path),native_files=rows,common_header=dict(path=str(reference),bytes=len(common),sha256=sha(common),unchanged=True),bf16_binary_unary_unchanged=True,all_three_iq1_cases_preserved=True,vendor_tree_sha256=newtree,notice_sha256=newnotice),indent=2)+'\n')
print(json.dumps(dict(source_id=source_id,native_files=rows,tree=newtree),indent=2))
