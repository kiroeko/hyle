from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
root=Path.cwd(); stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
path=root/'third_party/ggml_cuda_runtime/patches.json'
manifest=json.loads(path.read_text())
entry=next(x for x in manifest['files'] if x['path']=='src/ggml-cuda/ggml-cuda.cu')
raw=(Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')/entry['path']).read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(raw).hexdigest()==entry['before_sha256']
source=raw.decode()
for edit in entry['edits']:
 assert source.count(edit['before'])==1
 source=source.replace(edit['before'],edit['after'],1)
assert hashlib.sha256(source.encode()).hexdigest()==entry['after_sha256']
changes=[]
def replace(before,after):
 global source
 assert source.count(before)==1, before[:100]
 source=source.replace(before,after,1); changes.append(dict(before=before,after=after))
replace('struct ggml_cuda_pool_leg : public ggml_cuda_pool {', '''// Only the caller-owned outer recording uses this scope. Ordinary private
// graph warmup/capture and Commands keep their original pool behavior.
static thread_local unsigned ggml_hyle_recording_depth = 0;
struct ggml_hyle_recording_scope {
    ggml_hyle_recording_scope() { ++ggml_hyle_recording_depth; }
    ggml_hyle_recording_scope(const ggml_hyle_recording_scope &) = delete;
    ~ggml_hyle_recording_scope() { --ggml_hyle_recording_depth; }
};

struct ggml_cuda_pool_leg : public ggml_cuda_pool {''')
replace('    size_t pool_size = 0;\n\n    explicit ggml_cuda_pool_leg', '    size_t pool_size = 0;\n    size_t live_buffers = 0; // Cached plus checked-out allocations, not bytes.\n\n    explicit ggml_cuda_pool_leg')
replace('        GGML_ASSERT(pool_size == 0);\n    }\n\n    void clear_pool()', '        GGML_ASSERT(pool_size == 0 && live_buffers == 0);\n    }\n\n    void clear_pool()')
replace('                pool_size -= b.size;\n                b.ptr  = nullptr;', '                pool_size -= b.size;\n                --live_buffers;\n                b.ptr  = nullptr;')
replace('        void * ptr;\n        size_t look_ahead_size', '''        // Every temporary referenced by an outer captured graph must return
        // to this original fixed cache, rather than be cudaFree'd on return.
        // At idle, the previous encoder has returned all checked-out buffers.
        if (ggml_hyle_recording_depth != 0 && live_buffers >= MAX_BUFFERS)
            hyle::compute::ggml_cuda::bridge::fail(cudaErrorMemoryAllocation,
                "recorded native pool exceeds retaining capacity");
        void * ptr;
        size_t look_ahead_size''')
replace('            const size_t cached_bytes = pool_size;\n            GGML_LOG_DEBUG', '            if (ggml_hyle_recording_depth != 0)\n                hyle::compute::ggml_cuda::bridge::fail(err, "recorded native pool allocation");\n            const size_t cached_bytes = pool_size;\n            GGML_LOG_DEBUG')
replace('        pool_size += look_ahead_size;\n#ifdef DEBUG_CUDA_MALLOC', '        pool_size += look_ahead_size;\n        ++live_buffers;\n#ifdef DEBUG_CUDA_MALLOC')
replace('        pool_size -= size;\n    }\n};\n\n// pool with virtual memory', '        pool_size -= size;\n        --live_buffers;\n    }\n};\n\n// pool with virtual memory')
start=source.index('static void ggml_cuda_graph_evaluate_and_capture(')
end=source.index('\n#ifdef USE_CUDA_GRAPH\nstatic bool ggml_cuda_graph_set_enabled',start)
old=source[start:end]
setup_start=old.index('    // flag used to determine')
setup_end=old.index('    while (!graph_evaluated_or_captured)')
body_start=old.index('            [[maybe_unused]] int prev_i')
body_end=old.index('\n        }\n\n#ifdef USE_CUDA_GRAPH',body_start)
setup=old[setup_start:setup_end]
body='\n'.join(line[8:] if line.startswith('        ') else line for line in old[body_start:body_end].split('\n'))
encoder='static void ggml_cuda_graph_encode(ggml_backend_cuda_context * cuda_ctx, ggml_cgraph * cgraph) {\n'+setup+body+'\n}\n\n'
wrapper=old[:setup_start]+old[setup_end:body_start]+'            ggml_cuda_graph_encode(cuda_ctx, cgraph);'+old[body_end:]
replace(old,encoder+wrapper)
entry['edits'].extend(changes)
entry['after_sha256']=hashlib.sha256(source.encode()).hexdigest()
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
out=stage/'runtime-only'/entry['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_text(source,encoding='utf-8',newline='\n')
(stage/'native-patch-receipt.json').write_text(json.dumps(dict(new_edits=len(changes),runtime_only_sha256=entry['after_sha256'],math='Original encoder body extracted verbatim except indentation; original Commands wrapper calls same encoder.'),indent=2)+'\n')
