from pathlib import Path
import json,hashlib
root=Path.cwd();stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
paths=['src/compute_provider_ggml_cuda/native_bridge_impl.h','third_party/ggml_cuda_runtime/NOTICE.md','cmake/HyleDependencyLock.json']
for name in paths:
 src=root/name;dst=stage/'pre-cub-candidate'/name
 assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
for name in ['source-freeze.json','source.diff','integration-review.json','native-source-identities.json']:
 dst=stage/('pre-cub-'+name);assert not dst.exists();dst.write_bytes((stage/name).read_bytes())
