from pathlib import Path
import difflib,hashlib,json,re,subprocess
root=Path.cwd(); stage=root/'.scratch/architecture-refactor-2026-10-18/ggml-cuda-record-only'
paths=[row['path'] for row in json.loads((stage/'before-identities.json').read_text())]
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[];differences=[]
for name in paths:
 data=(root/name).read_bytes();dest=stage/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 old=(stage/'before'/name).read_bytes()
 rows.append(dict(path=name,bytes=len(data),sha256=sha(data),before_sha256=sha(old),changed=data!=old))
 differences.extend(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+name,tofile='candidate/'+name))
(stage/'source.diff').write_text(''.join(differences),encoding='utf-8',newline='\n')
prior=(root/'.scratch/architecture-refactor-2026-10-18/cuda-bfloat-elementwise/native-source/src/ggml-cuda/ggml-cuda.cu').read_text()
current=(stage/'native-source/src/ggml-cuda/ggml-cuda.cu').read_text()
oldbody=prior[prior.index('            [[maybe_unused]] int prev_i',prior.index('static void ggml_cuda_graph_evaluate_and_capture')):prior.index('\n        }\n\n#ifdef USE_CUDA_GRAPH',prior.index('static void ggml_cuda_graph_evaluate_and_capture'))]
newbody=current[current.index('    [[maybe_unused]] int prev_i',current.index('static void ggml_cuda_graph_encode')):current.index('\n}\n\nstatic void ggml_cuda_graph_evaluate_and_capture',current.index('static void ggml_cuda_graph_encode'))]
assert re.sub(r'\s+','',oldbody)==re.sub(r'\s+','',newbody)
command=['cmake','-P',str(stage/'audit.cmake')]
run=subprocess.run(command,cwd=root,capture_output=True,text=True)
(stage/'audit.stdout.log').write_text(run.stdout);(stage/'audit.stderr.log').write_text(run.stderr)
assert run.returncode==0
receipt=dict(files=rows,native=json.loads((stage/'native-source-identities.json').read_text()),audit=dict(command=command,exit_code=run.returncode,selected_dependency='ggml_cuda_runtime_patches',initial_python_tree_sort_mismatch_corrected='WindowsPath case-fold sorting differed from CMake ASCII list SORT; final exact CMake audit passes.'),encoder_math_body_identical_ignoring_whitespace=True,validation='Source-only implementation; no native/host compilation or GPU execution by this agent.',invariants=['Original native graph-enabled metadata and checker refine the capture upper bound and preserve the same enabled Mean CUB threshold.','Cold bind only installs original roots/views/gallocr addresses; no payload math.','No native private-cache warmup/instantiate/launch in outer record.','Legacy pool live count includes checked-out and cached buffers; record OOM never sync/flush.','Graph invalidates captured ranges before reusing the same native pool.','One original Invocation probe per selected step; iterative same-type chain retains full-outer cuBLAS guard through End/abort.','Only native failed record probes drain auxiliary streams, after real outer capture None.'],fresh_owners=['native src/ggml-cuda/ggml-cuda.cu (original full canonical recipe)','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc','src/compute_backend_cuda/cuda_backend.cc'],unchanged_native_math_objects=['cuda-bfloat-elementwise-build/binbcast.obj','cuda-bfloat-elementwise-build/unary.obj','cuda-bfloat-elementwise-build/tensor-current.obj'],unverified=['Actual cold cuBLAS lazy-resource capture for all supported kernels.','Runtime numeric parity/capture success/two-slot replay/failure injection.'])
(stage/'source-freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(freeze=str(stage/'source-freeze.json'),bytes=(stage/'source-freeze.json').stat().st_size,sha256=sha((stage/'source-freeze.json').read_bytes()),files=[dict(path=r['path'],sha256=r['sha256']) for r in rows]),indent=2))
