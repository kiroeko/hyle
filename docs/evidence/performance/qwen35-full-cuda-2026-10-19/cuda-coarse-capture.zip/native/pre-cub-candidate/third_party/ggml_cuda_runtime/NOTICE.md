# ggml CUDA integration patches

Upstream: https://github.com/ggml-org/ggml at
`456172ec733a135778adcd32d00e576a58232e45` (MIT; see LICENSE).

The owning CMake applies the exact context-matched edits in `patches.json` to
a build-local copy of authenticated upstream source. Shared source caches and
upstream checkouts remain unchanged. The manifest pins both original and
result hashes; this directory does not contain a second runtime distribution.

Edits preserve native CUDA Runtime, Driver and cuBLAS errors at the private
C++ adapter boundary. Resource owners roll back partial construction; cleanup
does not throw. Capture begin/end/encoding failures release the global capture
counter and discard incomplete graphs. Virtual-memory mapping failures release
their allocation handle and partial mapping. Non-owning buffer wrappers never
free external tensor payload. Backend streams, pools, algorithms, fusion and
capture selection remain upstream-owned. The precision and mathematical
changes are documented below.

The private bridge implementation is in `src/compute_provider_ggml_cuda` and
is compiled into the upstream translation unit. It is not an installed API.
Numerical behavior, Direct/Graph execution and failure recovery still require
tests of the operations and lifetimes being used.

The narrow IQ1_XS/XXS/XXXS CUDA programs in `iq1-patches.json` and the three
MMQ template instances originate from Unsloth llama.cpp
`46cbf0e95786fe8f5b7c0e86d57aaf8f8eceea7f` (MIT, same LICENSE).
Original CUDA tables, conversion, dot products, MMVQ/MMQ math and dispatch
blocks remain unchanged. The newer core's three block-size traits and the
template include path are ABI/build adaptations. `iq1-origins.json` retains
the original block and template SHA-256 identities. They share the existing
physical types/codecs with the original CPU port, not a second ggml runtime.
Only the CUDA route compiles these programs; CPU-only/Metal/Vulkan pins and
math remain unchanged. This source port is not runtime or performance proof.

The F32 MMF tiles in this pin execute TF32 multiplication. The original regular
MUL_MAT, MUL_MAT_ID and corresponding capture-suitability selection are guarded
so a requested native F32 operand contract on F32 weights reaches the original
F32 cuBLAS/sorting program instead. An explicit F32 source request also uses
DEFAULT_MATH within the F32 cuBLAS call: COMPUTE_32F alone does not disable the
handle's TF32 mode. The private handle's previous mode is restored on return
and exception unwind. Default precision and GEMM kernels remain upstream.
These are precision-selection changes, not a new GEMM implementation.

The original CUDA DIAG_MASK_INF kernel subtracted FLT_MAX. This does not
exclude a future score containing positive infinity, and can leave a very
large finite score visible. The exact patch replaces every excluded element
with negative infinity and preserves each permitted value. The original
launch geometry and attention scale, additive-bias, softmax and PV programs
remain unchanged; no mask-content scan or host fallback is added.

The existing float elementwise templates also accept homogeneous BF16 inputs
and outputs for Add/Sub/Mul/Div, their bit-preserving Repeat broadcasts, and
Abs/Neg/Exp/Log/Sqrt/Tanh/Sigmoid. Values widen to F32 on load and round to BF16
on each operation's store; the original float arithmetic and launch geometry
remain unchanged. Consecutive BF16 Add/Mul nodes do not use the native multi-op
fusion, which would otherwise remove intermediate BF16 rounding. Original
F32/F16 dispatch and fusion behavior, and composite Rsqrt, remain unchanged.

Caller-owned CUDA capture records the same factored native encoder without
private graph warmup, instantiation or launch. The exact lowered graph uses
the original capture-compatibility check; builds enabling CUB remain excluded
because the original Mean dispatch also depends on private graph-cache state.
Original lazy handles, streams and caching pools stay owned by that backend.
Only this outer recording permits their allocation in a local Relaxed scope;
pool OOM does not synchronize/flush, and its 256-entry retaining limit counts
both cached and checked-out buffers before allocating. Original Commands and
private native capture keep their previous allocator and selection behavior.
The original preparation Completion holds the process-wide cuBLAS destruction
exclusion through outer End/abort, then observes any failed auxiliary prefix.
No model mathematics executes during recording. A captured graph must be
destroyed before reusing its invocation's pool through a new preparation;
the owning Graph slot already enforces that order.
