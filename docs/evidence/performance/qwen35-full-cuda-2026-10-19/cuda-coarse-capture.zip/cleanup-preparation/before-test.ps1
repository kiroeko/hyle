param([switch]$ReclaimCudaDecodeInvestigation)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\')
$stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-decode-investigation-reclaim'
$plan = Get-Content -Raw -LiteralPath (Join-Path $stage 'cleanup-plan.json') | ConvertFrom-Json
$archiveDirectory = Join-Path $workspace 'docs/evidence/performance/qwen35-full-cuda-2026-10-19'
$headerPath = Join-Path $workspace 'tests/cuda_vector_matmul_test.h'
$headerSha = '1d1ed7539ae2824b1d3901fb10fe762c0db53375b9646c5bbd64a435126aee3e'
$allowed = @{}
$allowed[(Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/qwen-decode-native-route')] = @('hyle', 'peer')
$allowed[(Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-native-matvec')] = @('candidate', 'matvec-tests')
$allowed[(Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-bfloat-elementwise-build')] = @('candidate')
$allowed[(Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/cuda-bfloat-elementwise-tests')] = @('bfloat-tests')
$expectedArchives = @('qwen-decode-native-route.zip', 'cuda-native-matvec-rejected.zip', 'cuda-bfloat-elementwise.zip', 'cuda-bfloat-elementwise-trace.zip') | ForEach-Object { Join-Path $archiveDirectory $_ }

function Get-IdentitySha256([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose(); $stream.Dispose() }
}

function Assert-Identity($entry) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if (-not $path.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
    if ([string]$entry.sha256 -cnotmatch '^[0-9a-f]{64}$') { throw "Invalid SHA256 identity: $path" }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer) { throw "Expected exact file: $path" }
    $resolved = (Resolve-Path -LiteralPath $path).ProviderPath
    if (-not [string]::Equals($resolved, $path, [StringComparison]::OrdinalIgnoreCase)) { throw "Resolved path changed: $path" }
    $cursor = $item
    while ($null -ne $cursor) {
        if ($cursor.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse path: $path" }
        if ($cursor -is [IO.FileInfo]) { $cursor = $cursor.Directory } else { $cursor = $cursor.Parent }
    }
    if ($item.Length -ne [long]$entry.bytes -or (Get-IdentitySha256 $path) -ne $entry.sha256) { throw "Identity changed: $path" }
}

if ($plan.workspace -ne $workspace) { throw 'Plan workspace does not match this task' }
if (@($plan.targets).Count -ne 23 -or $plan.files -ne 23 -or @($plan.retained_objects).Count -ne 10 -or @($plan.retained_raw_traces).Count -ne 8) { throw 'Expected exactly23 targets,10 retained objects and8 raw traces' }
if ($plan.bytes -ne 808658511 -or ($plan.targets | Measure-Object -Property bytes -Sum).Sum -ne $plan.bytes) { throw 'Plan byte total changed' }
if (@($plan.allowed_image_directories).Count -ne 4) { throw 'Expected four exact image directories' }
foreach ($directory in $plan.allowed_image_directories) {
    if (-not $allowed.ContainsKey([string]$directory)) { throw "Unexpected image directory: $directory" }
}
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_traces)) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if (@('.obj', '.sqlite', '.nsys-rep') -notcontains $extension) { throw "Unexpected retained payload: $path" }
    if (-not $seen.Add($path)) { throw "Duplicate retained path: $path" }
    Assert-Identity $entry
}
$headerCount = 0
foreach ($entry in $plan.targets) {
    $path = [IO.Path]::GetFullPath([string]$entry.path)
    if ([string]::Equals($path, $headerPath, [StringComparison]::OrdinalIgnoreCase)) {
        if ($entry.bytes -ne 3711 -or $entry.sha256 -ne $headerSha -or $plan.header.identity.path -ne $headerPath -or $plan.header.frozen_snapshot.sha256 -ne $headerSha) { throw 'Rejected unused header does not match frozen snapshot' }
        Assert-Identity $plan.header.frozen_snapshot
        $headerCount++
    } else {
        $parent = [IO.Path]::GetDirectoryName($path)
        $stem = [IO.Path]::GetFileNameWithoutExtension($path)
        $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
        if (-not $allowed.ContainsKey($parent) -or $allowed[$parent] -notcontains $stem -or @('.exe', '.map', '.lib', '.exp') -notcontains $extension) { throw "Not an exact completed-stage image: $path" }
    }
    if (-not $seen.Add($path)) { throw "Duplicate or retained target: $path" }
    Assert-Identity $entry
}
if ($headerCount -ne 1) { throw 'Expected exactly one rejected unused source header' }
if (@($plan.archives).Count -ne 4 -or @($plan.expected_archive_paths).Count -ne 4 -or @($plan.archive_receipts).Count -ne 4) { throw 'Four final archive identities and receipts are required' }
$archiveIdentities = @{}
foreach ($entry in $plan.archives) {
    if ($expectedArchives -notcontains $entry.path -or $plan.expected_archive_paths -notcontains $entry.path -or $archiveIdentities.ContainsKey([string]$entry.path)) { throw "Unexpected or duplicate archive: $($entry.path)" }
    Assert-Identity $entry
    $archiveIdentities[[string]$entry.path] = $entry
}
foreach ($entry in $plan.archive_receipts) {
    Assert-Identity $entry
    $receipt = Get-Content -Raw -LiteralPath $entry.path | ConvertFrom-Json
    $verified = $receipt.zip_crc_and_all_entry_sha_verified -or $receipt.crc_and_all_payload_sha_verified -or ($receipt.crc_verified -and $receipt.every_payload_sha256_verified)
    if (-not $verified) { throw "Archive receipt has not verified CRC/payload SHA: $($entry.path)" }
    $identity = if ($null -ne $receipt.archive) { $receipt.archive } else { $receipt }
    $planned = $archiveIdentities[[string]$identity.path]
    if ($null -eq $planned -or $identity.bytes -ne $planned.bytes -or $identity.sha256 -ne $planned.sha256) { throw "Archive receipt disagrees with plan: $($entry.path)" }
}
if (-not $ReclaimCudaDecodeInvestigation) {
    [pscustomobject]@{ preview = $true; files = 23; image_files = 22; unused_headers = 1; bytes = $plan.bytes; archives_verified = 4; archive_ready = $plan.archive_ready; retained_objects = 10; retained_raw_traces = 8 }
    return
}
if (-not $plan.archive_ready) { throw 'Final archive identity not frozen; no files were deleted' }
$receiptPath = Join-Path $stage 'cleanup-receipt.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup already has a receipt; do not replay deletions' }
$deleted = [Collections.Generic.List[object]]::new()
foreach ($entry in $plan.targets) {
    Assert-Identity $entry
    Remove-Item -LiteralPath ([string]$entry.path)
    if (Test-Path -LiteralPath ([string]$entry.path)) { throw "Still exists: $($entry.path)" }
    $deleted.Add($entry)
    [pscustomobject]@{
        deleted = $deleted.ToArray(); files = $deleted.Count; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum
        archives_verified = $plan.archives; retained_objects = $plan.retained_objects; retained_raw_traces = $plan.retained_raw_traces
        complete = ($deleted.Count -eq $plan.targets.Count); script_sha256 = (Get-IdentitySha256 $PSCommandPath)
    } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
}
foreach ($entry in @($plan.retained_objects) + @($plan.retained_raw_traces)) { Assert-Identity $entry }
[pscustomobject]@{ deleted_files = $deleted.Count; reclaimed_bytes = $plan.bytes; archives_verified = 4; retained_objects = 10; retained_raw_traces = 8 }
