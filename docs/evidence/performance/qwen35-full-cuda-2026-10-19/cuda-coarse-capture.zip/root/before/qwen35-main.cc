// Independent text consumer. All candidate tensor mathematics uses public
// Compute/Graph operations; no native API, provider choice or oracle feedback.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/cuda.h"
#include "hyle/graph/progress.h"
#include "hyle/mem/buffer.h"
#include "hyle/sched/blocking.h"
#include "hyle/sched/scheduler.h"

namespace qwen35 {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace mem = hyle::mem;
using V = g::ValueId;
using Type = c::DataType;
constexpr std::int64_t hidden = 2048, intermediate = 6144, vocabulary = 248320;
constexpr char source_id[] = "4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155";
using Clock = std::chrono::steady_clock;
constexpr bool is_end_of_generation(std::int32_t token) noexcept {
  return token == 248044 || token == 248046; // Original endoftext and tokenizer im_end.
}
constexpr std::array<const char *, 9> layer0_probe_names{
    "01-gdn-output", "02-out-proj-input", "03-out-proj-output",
    "04-down-proj-input", "05-layer-output", "06-post-attn-residual",
    "07-post-attn-norm", "08-gate-proj-output", "09-up-proj-output"};

void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
c::TensorDesc dense(Type type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, std::span(shape.begin(), shape.size())));
}
struct Tensor final {
  c::TensorDesc description;
  mem::Buffer buffer;
  Tensor() = default;
  Tensor(mem::MemoryResourceRef resource, c::TensorDesc desc)
      : description(desc), buffer(take(mem::Buffer::create(resource,
            take(desc.required_bytes()), 256))) {}
  c::TensorView view() { return take(c::TensorView::create(description, buffer.view())); }
  c::ConstTensorView read() { return view().as_const(); }
  void zero() { check(buffer.view().fill(std::byte{})); }
  template<class T> void write(std::span<const T> values) {
    check(buffer.view().write(std::as_bytes(values)));
  }
  void dump(const std::filesystem::path &path) {
    std::vector<std::byte> bytes(buffer.size());
    check(buffer.view().read(bytes));
    std::ofstream output(path, std::ios::binary);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!output) throw std::runtime_error("cannot write trace: " + path.string());
  }
};
struct State final {
  std::array<Tensor, 2> history, recurrent;
  Tensor key, value;
};
struct Recipe final {
  g::GraphBuilder builder = take(g::GraphBuilder::create());
  std::vector<c::TensorDesc> descriptions;
  std::vector<g::ConstantBinding> constants;
  std::map<std::string, V> weights;
  std::map<std::string, Tensor> &bank;
  std::vector<Tensor> literals;
  mem::MemoryResourceRef resource;
  Recipe(std::map<std::string, Tensor> &selected, mem::MemoryResourceRef r) : bank(selected), resource(r) {}
  V remember(V value, c::TensorDesc description) {
    if (descriptions.size() <= value.ordinal()) descriptions.resize(value.ordinal() + 1);
    descriptions[value.ordinal()] = description;
    return value;
  }
  V input(c::TensorDesc description) { return remember(take(builder.input(description)), description); }
  V constant(Tensor &tensor) {
    const auto value = remember(take(builder.constant(tensor.description)), tensor.description);
    constants.push_back({value, tensor.read(), g::ConstantPolicy::kBorrow});
    return value;
  }
  V weight(const std::string &name) {
    auto found = weights.find(name);
    if (found != weights.end()) return found->second;
    const auto value = constant(bank.at("model.language_model." + name));
    weights.emplace(name, value);
    return value;
  }
  V scalar(float value, Type type = Type::kFloat32) {
    literals.emplace_back(resource, dense(type, {1}));
    if (type == Type::kFloat32) literals.back().write<float>(std::span(&value, 1));
    else {
      auto bits = std::bit_cast<std::uint32_t>(value);
      bits += 0x7fffU + ((bits >> 16) & 1U);
      const auto bf16 = static_cast<std::uint16_t>(bits >> 16);
      literals.back().write<std::uint16_t>(std::span(&bf16, 1));
    }
    return constant(literals.back());
  }
  std::vector<V> op(c::Operation operation, std::initializer_list<V> arguments,
                    g::NodeId *node_id = nullptr) {
    std::vector<c::TensorDesc> in;
    for (auto value : arguments) in.push_back(descriptions.at(value.ordinal()));
    std::vector<c::TensorDesc> out(c::operation_traits(operation).outputs);
    auto inferred = c::infer_output_descriptions(operation, in, out);
    if (!inferred.ok()) throw std::runtime_error(std::string(c::operation_name(operation.kind())) + ": " + std::string(inferred.message()));
    const auto node = take(builder.add_node(operation, std::span(arguments.begin(), arguments.size())));
    if (node_id) *node_id = node;
    std::vector<V> result;
    for (std::size_t i = 0; i < out.size(); ++i)
      result.push_back(remember(take(builder.result(node, i)), out[i]));
    return result;
  }
  template<class O> V one(O operation, std::initializer_list<V> arguments,
                          g::NodeId *node_id = nullptr) {
    return op(c::Operation(operation), arguments, node_id).at(0);
  }
  V cast(V x, Type type) {
    return descriptions[x.ordinal()].data_type() == type ? x : one(c::Cast{type}, {x});
  }
  V unary(c::UnaryKind kind, V x) { return one(c::Unary{kind}, {x}); }
  V binary(c::BinaryKind kind, V x, V y) { return one(c::Binary{kind}, {x, y}); }
  V reshape(V x, std::initializer_list<std::int64_t> shape) {
    const auto view = take(c::View::reshape(
        take(c::TensorShape::create(std::span(shape.begin(), shape.size())))));
    const auto inferred = c::infer_single_output(c::Operation(view),
        std::array{descriptions[x.ordinal()]});
    // Graph construction is cold. Materialize only when logical flattening
    // crosses stride chunks; the ordinary View remains a zero-copy contract.
    if (!inferred && inferred.error().IsUnimplemented()) x = copy(x);
    return one(view, {x});
  }
  V copy(V x) { return one(c::Copy{}, {x}); }
  V slice(V x, int axis, std::int64_t first, std::int64_t count) {
    return one(take(c::View::slice(axis, first, count)), {x});
  }
  V linear(V x, const std::string &name) {
    constexpr std::array<std::int32_t, 2> axes{1, 0};
    auto w = one(take(c::View::permute(axes)), {weight(name)});
    return one(c::MatMul{}, {x, w});
  }
  V norm(V x, const std::string &name) {
    const auto type = descriptions[x.ordinal()].data_type();
    auto scale = binary(c::BinaryKind::kAdd, cast(weight(name), Type::kFloat32), scalar(1));
    return cast(one(c::RmsNorm{.epsilon = 1.e-6F}, {cast(x, Type::kFloat32), scale}), type);
  }
  // Literal BF16 boundaries from the independent local reference, including
  // BF16 square/sum/epsilon/rsqrt. GDN applies its own 1/sqrt(128) exactly once.
  V l2(V x) {
    const auto square = binary(c::BinaryKind::kMultiply, x, x);
    const std::array<std::int32_t, 1> axes{-1};
    auto sum = one(c::Reduce{.kind = c::ReductionKind::kSum,
        .axes = take(c::Axes::from(axes)), .keep_dimensions = true,
        .accumulation_type = Type::kFloat32}, {square});
    sum = binary(c::BinaryKind::kAdd, sum, scalar(1.e-6F, Type::kBFloat16));
    return binary(c::BinaryKind::kMultiply, x, unary(c::UnaryKind::kRsqrt, sum));
  }
  V ffn(V x, const std::string &prefix, std::span<V> probes = {}) {
    auto normalized = norm(x, prefix + "post_attention_layernorm.weight");
    auto projected_gate = linear(normalized, prefix + "mlp.gate_proj.weight");
    auto gate = unary(c::UnaryKind::kSilu, projected_gate);
    auto up = linear(normalized, prefix + "mlp.up_proj.weight");
    auto product = binary(c::BinaryKind::kMultiply, gate, up);
    if (!probes.empty()) {
      probes[3] = product; probes[5] = x; probes[6] = normalized;
      probes[7] = projected_gate; probes[8] = up;
    }
    auto result = linear(product, prefix + "mlp.down_proj.weight");
    return binary(c::BinaryKind::kAdd, x, result);
  }
  void publish(V value) { check(builder.publish(value)); }
};

struct Ports final {
  V history, recurrent, next_history, next_recurrent, key, value, next_key, next_value;
};
struct Phase final {
  std::vector<Tensor> literals; // Cold constant backing outlives compiled artifacts.
  c::BatchSchema attention_schema;
  c::BatchLayoutVersion attention_layout;
  g::CompiledGraph compiled;
  std::array<g::Invocation, 2> slots;
  Tensor tokens, positions, logits, next_id, final_hidden;
  V token_port, position_port, metadata_port, logits_port, id_port, hidden_port;
  std::array<g::NodeId, 6> attention_nodes;
  std::array<V, 9> probe_ports;
  std::array<Tensor, 9> probe_outputs;
  std::array<bool, 9> probe_caller{};
  std::array<Ports, 24> layers;
};

class Model final {
public:
  c::Context context = take(g::cuda::create_context());
  c::cuda::MemoryResource memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  c::cuda::MemoryResource planning_memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  c::Queue queue = take(context.create_queue());
  // These original runtimes outlive every phase/slot and its native retirement.
  std::unique_ptr<hyle::sched::Scheduler> scheduler;
  std::unique_ptr<hyle::sched::BlockingPool> workers;
  std::map<std::string, Tensor> weights;
  std::array<State, 24> state;
  std::map<std::size_t, std::unique_ptr<Phase>> phases;
  std::map<std::size_t, std::unique_ptr<Phase>> probe_phases;
  std::size_t capacity, length = 0, parity = 0;
  bool failed = false;
  std::filesystem::path layer0_probe, trace_routes;
  explicit Model(const std::filesystem::path &manifest, std::size_t selected_capacity,
                 std::filesystem::path probe = {}, bool progress = false)
      : capacity(selected_capacity), layer0_probe(std::move(probe)) {
    if (capacity == 0 || capacity > 262144) throw std::runtime_error("capacity outside model context limit");
    if (progress) {
      auto status = hyle::Status::Ok();
      scheduler = std::make_unique<hyle::sched::Scheduler>(1, mem::system_allocator(), 64, &status);
      check(status);
      workers = std::make_unique<hyle::sched::BlockingPool>(mem::system_allocator(), 1,
                                                          std::chrono::seconds(10), &status);
      check(status);
    }
    const auto weight_load_start = Clock::now();
    std::ifstream input(manifest);
    std::string signature, shard, identity;
    std::getline(input, signature); std::getline(input, shard); std::getline(input, identity);
    if (signature != "HYLE_QWEN35_TEXT_V1" || identity != source_id)
      throw std::runtime_error("unidentified local weight manifest");
    std::ifstream payload(shard, std::ios::binary);
    if (!payload) throw std::runtime_error("cannot open original checkpoint");
    std::string line;
    std::size_t bytes = 0;
    while (std::getline(input, line)) {
      std::istringstream fields(line);
      std::string name, type; std::size_t rank = 0, offset = 0, count = 0;
      fields >> name >> type >> rank;
      if (rank == 0 || rank > c::kMaxTensorRank || (type != "BF16" && type != "F32"))
        throw std::runtime_error("invalid manifest tensor");
      std::vector<std::int64_t> dimensions(rank);
      for (auto &dimension : dimensions) fields >> dimension;
      fields >> offset >> count;
      auto desc = take(c::TensorDesc::dense(type == "BF16" ? Type::kBFloat16 : Type::kFloat32, dimensions));
      if (!fields || take(desc.required_bytes()) != count) throw std::runtime_error("manifest tensor extent differs");
      Tensor tensor(memory.ref(), desc);
      std::vector<std::byte> host(count);
      payload.seekg(static_cast<std::streamoff>(offset));
      payload.read(reinterpret_cast<char*>(host.data()), static_cast<std::streamsize>(host.size()));
      if (!payload) throw std::runtime_error("short checkpoint tensor: " + name);
      check(tensor.buffer.view().write(host));
      if (!weights.emplace(name, std::move(tensor)).second) throw std::runtime_error("duplicate weight");
      bytes += count;
    }
    if (weights.size() != 320 || bytes != 3763655360ULL) throw std::runtime_error("text weight inventory differs");
    const auto weight_load_seconds = std::chrono::duration<double>(Clock::now() - weight_load_start).count();
    std::cerr << "resident text weights: " << weights.size() << " tensors, " << bytes << " bytes\n";
    std::cerr << "weights_load_seconds=" << weight_load_seconds << '\n';
    for (std::size_t i = 0; i < state.size(); ++i) {
      auto &layer = state[i];
      if (i % 4 == 3) {
        layer.key = Tensor(memory.ref(), dense(Type::kBFloat16, {static_cast<std::int64_t>(capacity), 512}));
        layer.value = Tensor(memory.ref(), layer.key.description);
        layer.key.zero(); layer.value.zero();
      } else {
        for (std::size_t slot = 0; slot < 2; ++slot) {
          layer.history[slot] = Tensor(memory.ref(), dense(Type::kBFloat16, {1, 3, 6144}));
          layer.recurrent[slot] = Tensor(memory.ref(), dense(Type::kFloat32, {1, 16, 128, 128}));
          layer.history[slot].zero(); layer.recurrent[slot].zero();
        }
      }
    }
  }

  ~Model() {
    // Success and exception teardown join actual slots before releasing either
    // the runtimes or the borrowed model/state buffers. Scheduler idleness alone
    // does not establish native retirement or completion-observer return.
    for (auto *cache : {&phases, &probe_phases})
      for (auto &[tokens, phase] : *cache) {
        (void)tokens;
        for (auto &run : phase->slots) run.drain().IgnoreError();
      }
    if (workers) workers->shutdown();
    if (scheduler) scheduler->drain();
  }

  Phase &prepare(std::size_t tokens, bool diagnostic = false) {
    auto &cache = diagnostic ? probe_phases : phases;
    auto found = cache.find(tokens);
    if (found != cache.end()) return *found->second;
    const auto start = Clock::now();
    const auto t = static_cast<std::int64_t>(tokens), cap = static_cast<std::int64_t>(capacity);
    auto result = std::make_unique<Phase>();
    auto &phase = *result;
    Recipe r(weights, memory.ref());
    phase.tokens = Tensor(memory.ref(), dense(Type::kInt32, {t}));
    phase.positions = Tensor(memory.ref(), phase.tokens.description);
    const auto cache_storage = take(c::CacheStorage::plain(Type::kBFloat16));
    phase.attention_schema = take(c::BatchSchema::create({
        .storage = c::BatchStorage::kRagged, .query_type = Type::kBFloat16,
        .output_type = Type::kBFloat16, .key_storage = cache_storage, .value_storage = cache_storage,
        .max_requests = 1, .max_query_rows = static_cast<std::uint32_t>(tokens),
        .max_kv_rows = static_cast<std::uint32_t>(capacity), .max_pages = 0, .max_page_refs = 0,
        .query_heads = 8, .kv_heads = 2, .qk_head_dim = 256, .value_head_dim = 256, .page_size = 1}));
    phase.token_port = r.input(phase.tokens.description);
    phase.position_port = r.input(phase.positions.description);
    phase.metadata_port = r.input(take(phase.attention_schema.metadata_description()));
    auto x = r.one(c::Gather{.bounds = c::IndexBoundsPolicy::kUnchecked},
        {r.weight("embed_tokens.weight"), phase.token_port});
    std::array<float, 32> frequency{};
    for (std::size_t i = 0; i < frequency.size(); ++i) frequency[i] = 1.F / std::pow(10000000.F, float(i) / 32.F);
    r.literals.emplace_back(memory.ref(), dense(Type::kFloat32, {32}));
    r.literals.back().write<float>(frequency);
    const auto frequencies = r.constant(r.literals.back());
    for (std::size_t i = 0; i < state.size(); ++i) {
      const auto prefix = "layers." + std::to_string(i) + ".";
      auto normalized = r.norm(x, prefix + "input_layernorm.weight");
      auto &ports = phase.layers[i];
      V mixed;
      if (i % 4 != 3) {
        ports.history = r.input(state[i].history[0].description);
        ports.recurrent = r.input(state[i].recurrent[0].description);
        auto qkv = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_qkv.weight"), {1, t, 6144});
        auto samples = r.one(c::Concat{.axis = 1}, {ports.history, qkv});
        // Published state uses caller-owned ping-pong storage.
        ports.next_history = r.copy(r.slice(samples, 1, t, 3));
        auto convolution = r.one(c::model_ops::causal_conv1d(), {r.cast(samples, Type::kFloat32),
            r.cast(r.reshape(r.weight(prefix + "linear_attn.conv1d.weight"), {6144, 4}), Type::kFloat32)});
        auto activated = r.unary(c::UnaryKind::kSilu, r.cast(convolution, Type::kBFloat16));
        auto q = r.reshape(r.slice(activated, 2, 0, 2048), {1, t, 16, 128});
        auto k = r.reshape(r.slice(activated, 2, 2048, 2048), {1, t, 16, 128});
        auto v = r.reshape(r.slice(activated, 2, 4096, 2048), {1, t, 16, 128});
        auto a = r.reshape(r.cast(r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32), {1, t, 16, 1});
        auto b = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"), {1, t, 16, 1});
        auto dt = r.reshape(r.cast(r.weight(prefix + "linear_attn.dt_bias"), Type::kFloat32), {1, 1, 16, 1});
        auto decay = r.reshape(r.unary(c::UnaryKind::kNeg,
            r.unary(c::UnaryKind::kExp, r.weight(prefix + "linear_attn.A_log"))), {1, 1, 16, 1});
        auto g = r.binary(c::BinaryKind::kMultiply, decay,
            r.unary(c::UnaryKind::kSoftplus, r.binary(c::BinaryKind::kAdd, a, dt)));
        auto beta = r.cast(r.unary(c::UnaryKind::kSigmoid, b), Type::kFloat32);
        auto recurrent = r.op(c::Operation(c::GatedDeltaNet{}),
            {r.cast(r.l2(q), Type::kFloat32), r.cast(r.l2(k), Type::kFloat32),
             r.cast(v, Type::kFloat32), g, beta, ports.recurrent});
        ports.next_recurrent = recurrent[1];
        auto y = r.cast(recurrent[0], Type::kBFloat16);
        if (i == 0) phase.probe_ports[0] = y;
        y = r.cast(r.one(c::RmsNorm{.epsilon = 1.e-6F}, {r.cast(y, Type::kFloat32)}), Type::kBFloat16);
        // The original checkpoint keeps this scale F32. Torch promotes the
        // rounded BF16 normalized value before multiplying it by that scale.
        y = r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32), r.weight(prefix + "linear_attn.norm.weight"));
        auto z = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_z.weight"), {1, t, 16, 128});
        y = r.cast(r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32),
            r.unary(c::UnaryKind::kSilu, r.cast(z, Type::kFloat32))), Type::kBFloat16);
        auto projection_input = r.reshape(y, {t, hidden});
        if (i == 0) phase.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.
        mixed = r.linear(projection_input, prefix + "linear_attn.out_proj.weight");
        if (i == 0) phase.probe_ports[2] = mixed;
        r.publish(ports.next_history); r.publish(ports.next_recurrent);
      } else {
        ports.key = r.input(state[i].key.description);
        ports.value = r.input(state[i].value.description);
        auto projected = r.reshape(r.linear(normalized, prefix + "self_attn.q_proj.weight"), {1, t, 8, 512});
        auto q = r.norm(r.slice(projected, 3, 0, 256), prefix + "self_attn.q_norm.weight");
        auto gate = r.reshape(r.slice(projected, 3, 256, 256), {t, hidden});
        auto k = r.norm(r.reshape(r.linear(normalized, prefix + "self_attn.k_proj.weight"), {1, t, 2, 256}), prefix + "self_attn.k_norm.weight");
        auto v = r.linear(normalized, prefix + "self_attn.v_proj.weight");
        const c::RoPE rope{.rotary_dimensions = 64, .sequence_axis = 1, .layout = c::RopeLayout::kHalfSplit};
        q = r.one(rope, {q, phase.position_port, frequencies});
        k = r.one(rope, {k, phase.position_port, frequencies});
        ports.next_key = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.key, phase.position_port, r.reshape(k, {t, 512})});
        ports.next_value = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.value, phase.position_port, v});
        auto attention = r.one(c::Operation::custom(c::RaggedAttention{
            .capacity = phase.attention_schema.capacity(), .scale = 0.0625F, .causal = true}),
            {r.reshape(q, {t, 8, 256}), r.reshape(ports.next_key, {cap, 2, 256}),
             r.reshape(ports.next_value, {cap, 2, 256}), phase.metadata_port}, &phase.attention_nodes[i / 4]);
        auto gated = r.binary(c::BinaryKind::kMultiply, r.reshape(attention, {t, hidden}), r.unary(c::UnaryKind::kSigmoid, gate));
        mixed = r.linear(gated, prefix + "self_attn.o_proj.weight");
        r.publish(ports.next_key); r.publish(ports.next_value);
      }
      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix,
                i == 0 ? std::span<V>(phase.probe_ports) : std::span<V>{});
      if (i == 0) phase.probe_ports[4] = x;
    }
    if (diagnostic) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
      r.publish(phase.probe_ports[i]);
      auto description = r.descriptions.at(phase.probe_ports[i].ordinal());
      if (description.data_type() != Type::kBFloat16) throw std::runtime_error("layer0 diagnostic boundary is not BF16");
    }
    // This published result is bound to the caller's fixed final_hidden buffer.
    auto last = r.copy(r.slice(r.norm(x, "norm.weight"), 0, t - 1, 1));
    phase.hidden_port = last;
    phase.logits_port = r.cast(r.linear(last, "embed_tokens.weight"), Type::kFloat32);
    phase.id_port = r.op(c::Operation(c::TopK{.count = 1}), {phase.logits_port})[1];
    for (auto value : {phase.hidden_port, phase.logits_port, phase.id_port}) r.publish(value);
    phase.logits = Tensor(memory.ref(), r.descriptions[phase.logits_port.ordinal()]);
    phase.next_id = Tensor(memory.ref(), r.descriptions[phase.id_port.ordinal()]);
    phase.final_hidden = Tensor(memory.ref(), r.descriptions[phase.hidden_port.ordinal()]);
    auto graph = take(std::move(r.builder).finish());
    phase.literals = std::move(r.literals);
    std::cerr << "compile full text phase T=" << tokens << " nodes=" << graph.node_count() << '\n';
    phase.compiled = take(g::cuda::compile(graph, context, memory.ref(), {.constants = r.constants}));
    if (diagnostic) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
      for (std::size_t output = 0; output < phase.compiled.executable.output_count(); ++output) {
        if (take(phase.compiled.executable.output_id(output)) != phase.probe_ports[i]) continue;
        phase.probe_caller[i] = take(phase.compiled.executable.output_ownership(output)) == g::OutputOwnership::kCaller;
        if (phase.probe_caller[i]) phase.probe_outputs[i] = Tensor(memory.ref(), r.descriptions.at(phase.probe_ports[i].ordinal()));
      }
    }
    const auto &route_directory = layer0_probe.empty() ? trace_routes : layer0_probe;
    if (!route_directory.empty()) {
      std::filesystem::create_directories(route_directory);
      const auto label = diagnostic ? "published" : "default";
      std::ofstream route(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".route.tsv"));
      route << "step\tkind\tprovider\timplementation\tnodes\n";
      for (std::size_t step = 0; step < phase.compiled.report.step_count(); ++step) {
        const auto detail = take(phase.compiled.report.step(step));
        route << step << '\t' << static_cast<unsigned>(detail.kind) << '\t' << detail.provider.name
              << '\t' << detail.implementation.value() << '\t';
        for (std::size_t n = 0; n < detail.node_count; ++n) {
          const auto node = take(phase.compiled.report.step_node(step, n));
          route << (n ? "," : "") << node.ordinal() << ':' << c::operation_name(take(graph.operation(node)));
        }
        route << '\n';
      }
      std::ofstream boundaries(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".boundaries.tsv"));
      boundaries << "point\tvalue\tproducer\tshape\n";
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        const auto value = phase.probe_ports[i];
        boundaries << layer0_probe_names[i] << '\t' << value.ordinal() << '\t' << take(graph.producer(value)).ordinal() << '\t';
        for (auto dimension : r.descriptions.at(value.ordinal()).dimensions()) boundaries << dimension << ',';
        boundaries << '\n';
      }
      if (!route || !boundaries) throw std::runtime_error("cannot write layer0 route diagnostics");
    }
    if (layer0_probe.empty() || diagnostic) for (std::size_t slot = 0; slot < 2; ++slot) {
      phase.slots[slot] = take(phase.compiled.executable.create_invocation());
      if (scheduler) check(g::prepare_progress(phase.slots[slot], *scheduler, *workers));
    }
    std::cerr << "compiled T=" << tokens << " steps=" << phase.compiled.report.step_count()
              << " workspace/slot=" << phase.compiled.executable.workspace_bytes()
              << " cold_seconds=" << std::chrono::duration<double>(Clock::now() - start).count() << '\n';
    auto *address = result.get(); cache.emplace(tokens, std::move(result)); return *address;
  }

  std::int32_t evaluate(std::span<const std::int32_t> ids, const std::string &name,
                        const std::filesystem::path &trace = {}, bool trace_states = true) {
    if (failed) throw std::runtime_error("request state was invalidated by a previous failure");
    if (ids.empty() || ids.size() > capacity - length) throw std::runtime_error("nonempty block exceeds remaining context capacity");
    for (auto id : ids) if (id < 0 || id >= vocabulary) throw std::runtime_error("token ID outside vocabulary");
    if (!layer0_probe.empty()) prepare(ids.size()); // Compile-only route comparison; never execute the default graph here.
    auto &phase = prepare(ids.size(), !layer0_probe.empty());
    const auto step_start = Clock::now();
    std::vector<std::int32_t> positions(ids.size());
    for (std::size_t row = 0; row < ids.size(); ++row) {
      positions[row] = static_cast<std::int32_t>(length + row);
    }
    phase.tokens.write<std::int32_t>(ids); phase.positions.write<std::int32_t>(positions);
    const auto cold_start = Clock::now();
    Clock::time_point start;
    double submit_seconds = 0;
    try {
      const std::array<std::int32_t, 2> query_indptr{0, static_cast<std::int32_t>(ids.size())};
      const std::array<std::int32_t, 2> kv_indptr{0, static_cast<std::int32_t>(length + ids.size())};
      phase.attention_layout = take(phase.attention_schema.version({query_indptr, kv_indptr, {}, {}}));
      std::array<g::batch::NodeLayout, 6> layouts;
      for (std::size_t i = 0; i < layouts.size(); ++i) layouts[i] = {phase.attention_nodes[i], phase.attention_layout};
      const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};
      auto &run = phase.slots[parity];
      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));
      check(run.bind(phase.token_port, phase.tokens.read()));
      check(run.bind(phase.position_port, phase.positions.read()));
      check(run.bind(phase.logits_port, phase.logits.view()));
      check(run.bind(phase.id_port, phase.next_id.view()));
      check(run.bind(phase.hidden_port, phase.final_hidden.view()));
      if (!layer0_probe.empty()) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i)
        if (phase.probe_caller[i]) check(run.bind(phase.probe_ports[i], phase.probe_outputs[i].view()));
      for (std::size_t i = 0; i < state.size(); ++i) {
        auto &p = phase.layers[i]; auto &s = state[i];
        if (i % 4 == 3) {
          check(run.bind(p.key, s.key.read())); check(run.bind(p.value, s.value.read()));
          check(run.bind(p.next_key, s.key.view())); check(run.bind(p.next_value, s.value.view()));
        } else {
          check(run.bind(p.history, s.history[parity].read()));
          check(run.bind(p.recurrent, s.recurrent[parity].read()));
          check(run.bind(p.next_history, s.history[1 - parity].view()));
          check(run.bind(p.next_recurrent, s.recurrent[1 - parity].view()));
        }
      }
      check(run.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));
      std::cerr << "prepared T=" << ids.size() << " visible=" << length + ids.size()
                << " cold_batch_seconds=" << std::chrono::duration<double>(Clock::now() - cold_start).count() << '\n';
      start = Clock::now();
      auto done = take(run.submit(queues));
      submit_seconds = std::chrono::duration<double>(Clock::now() - start).count();
      check(done.wait());
    } catch (...) { failed = true; throw; }
    length += ids.size(); parity = 1 - parity;
    std::int32_t next = 0;
    check(phase.next_id.buffer.view().read(std::as_writable_bytes(std::span(&next, 1))));
    const auto finished = Clock::now();
    std::cerr << name << " tokens=" << ids.size() << " visible=" << length
              << " seconds=" << std::chrono::duration<double>(finished - start).count()
              << " submit_seconds=" << submit_seconds
              << " step_seconds=" << std::chrono::duration<double>(finished - step_start).count()
              << " progress=" << (scheduler ? "scheduler" : "direct")
              << " next=" << next << '\n';
    if (!trace.empty()) {
      std::filesystem::create_directories(trace / name);
      phase.logits.dump(trace / name / "logits.f32"); phase.final_hidden.dump(trace / name / "hidden.bf16");
      if (trace_states) for (std::size_t layer = 0; layer < state.size(); ++layer) {
        auto &s = state[layer]; const auto prefix = "layer" + std::to_string(layer);
        if (layer % 4 == 3) {
          s.key.dump(trace / name / (prefix + ".key.bf16")); s.value.dump(trace / name / (prefix + ".value.bf16"));
        } else {
          s.history[parity].dump(trace / name / (prefix + ".conv.bf16"));
          s.recurrent[parity].dump(trace / name / (prefix + ".gdn.f32"));
        }
      }
    }
    if (!layer0_probe.empty()) {
      std::filesystem::create_directories(layer0_probe / name);
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        auto output = take(phase.slots[1 - parity].output(phase.probe_ports[i]));
        std::vector<std::byte> bytes(take(output.description().required_bytes()));
        check(output.storage().read(bytes));
        std::ofstream stream(layer0_probe / name / (std::string(layer0_probe_names[i]) + ".bf16"), std::ios::binary);
        stream.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!stream) throw std::runtime_error("cannot write layer0 probe output");
      }
    }
    return next;
  }
};

std::vector<std::int32_t> read_ids(const std::filesystem::path &path) {
  std::ifstream stream(path); if (!stream) throw std::runtime_error("cannot open token IDs");
  std::vector<std::int32_t> ids; std::int64_t value = 0;
  while (stream >> value) {
    if (value < 0 || value >= vocabulary) throw std::runtime_error("input token outside vocabulary");
    ids.push_back(static_cast<std::int32_t>(value));
  }
  if (!stream.eof()) throw std::runtime_error("malformed input IDs");
  return ids;
}
} // namespace qwen35

int main(int argc, char **argv) {
  const auto startup = qwen35::Clock::now();
  try {
    std::filesystem::path input, continuation, trace, layer0_probe, decode_ids;
    std::size_t steps = 4, capacity = 128;
    bool progress = false, trace_states = true, explicit_steps = false;
    for (int i = 1; i < argc; ++i) {
      const std::string option = argv[i];
      if (i + 1 >= argc) throw std::runtime_error("option needs a value");
      const std::string value = argv[++i];
      if (option == "--inputs") input = value;
      else if (option == "--continuation") continuation = value;
      else if (option == "--trace") trace = value;
      else if (option == "--trace-level") {
        if (value != "full" && value != "decisions")
          throw std::runtime_error("--trace-level requires full or decisions");
        trace_states = value == "full";
      }
      else if (option == "--decode-ids") decode_ids = value;
      else if (option == "--layer0-probe") layer0_probe = value;
      else if (option == "--steps") { steps = std::stoull(value); explicit_steps = true; }
      else if (option == "--capacity") capacity = std::stoull(value);
      else if (option == "--progress") {
        if (value != "direct" && value != "scheduler")
          throw std::runtime_error("--progress requires direct or scheduler");
        progress = value == "scheduler";
      }
      else throw std::runtime_error("unknown option: " + option);
    }
    const auto forced = decode_ids.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(decode_ids);
    if (!decode_ids.empty()) {
      if (forced.empty()) throw std::runtime_error("--decode-ids requires a nonempty token tape");
      if (explicit_steps && steps != forced.size() + 1)
        throw std::runtime_error("--steps must equal decode input count plus one");
      steps = forced.size() + 1;
    }
    if (input.empty() || steps == 0 || steps > 128)
      throw std::runtime_error("usage: hyle_qwen35_text --inputs DIR [--continuation IDS] [--steps 4 | --decode-ids IDS] [--capacity 128] [--progress direct|scheduler] [--trace DIR] [--trace-level full|decisions] [--layer0-probe DIR]");
    const auto prompt = qwen35::read_ids(input / "prompt.ids");
    const auto extra = continuation.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(continuation);
    if (prompt.size() + extra.size() + steps - 1 > capacity) throw std::runtime_error("capacity is smaller than requested complete journey");
    const auto model_start = qwen35::Clock::now();
    qwen35::Model model(input / "weights.tsv", capacity, layer0_probe, progress);
    const auto constructed = qwen35::Clock::now();
    if (!trace.empty()) model.trace_routes = trace / "routes";
    model.prepare(prompt.size());
    if (!extra.empty()) model.prepare(extra.size());
    if (steps > 1) model.prepare(1);
    const auto ready = qwen35::Clock::now();
    std::cerr << "initialized model_seconds=" << std::chrono::duration<double>(constructed - model_start).count()
              << " shape_prepare_seconds=" << std::chrono::duration<double>(ready - constructed).count()
              << " startup_to_ready_seconds=" << std::chrono::duration<double>(ready - startup).count() << '\n';
    auto next = model.evaluate(prompt, "prefill", trace, trace_states);
    std::cerr << "first_token_elapsed_seconds=" << std::chrono::duration<double>(qwen35::Clock::now() - startup).count() << '\n';
    if (!extra.empty()) next = model.evaluate(extra, "continuation", trace, trace_states);
    std::vector<std::int32_t> generated{next};
    std::vector<std::int32_t> consumed;
    for (std::size_t step = 1; step < steps && (!forced.empty() || !qwen35::is_end_of_generation(next)); ++step) {
      const auto previous = forced.empty() ? next : forced[step - 1];
      next = model.evaluate(std::span(&previous, 1), "decode" + std::to_string(step), trace, trace_states);
      consumed.push_back(previous);
      generated.push_back(next);
    }
    std::cout << "{\"source_id\":\"" << qwen35::source_id << "\",\"text_tensors\":320,\"visible_tokens\":"
              << model.length << ",\"generated_ids\":[";
    for (std::size_t i = 0; i < generated.size(); ++i) std::cout << (i ? "," : "") << generated[i];
    std::cout << "],\"fixed_decode\":" << (forced.empty() ? "false" : "true") << ",\"decode_input_ids\":[";
    for (std::size_t i = 0; i < consumed.size(); ++i) std::cout << (i ? "," : "") << consumed[i];
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Qwen3.5 text consumer: " << error.what() << '\n'; return 1;
  }
}
