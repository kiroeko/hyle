# Qwen3.5-2B 推理架构实验消费者

这是用于验证新执行架构的独立测试产物，尚未完成，不是已交付的推理引擎。
只运行本地官方权重的 24 层 CUDA 纯文本计算，关闭 MTP 和视觉；不提供服务、安装规则或 Provider 绕过。

`prepare.py` 校验原输入清单的 13 个文件并输出原始权重偏移及固定 token IDs；Python 只负责输入准备和 tokenizer。
`main.cc` 使用公共 Compute/Graph 构建一个完整模型语义图。首次 prefill、带状态的多 token continuation、decode
分别使用相应 token 数的冷准备入口。conv/GDN 状态真实反馈，KV 使用固定容量并只更新新增行；失败会使当前请求失效。
六个 BF16 GQA attention 使用 typed `RaggedAttention`：Q/K/V 以 metadata-only reshape 表达为 THD，
每个 phase 持有真实 `BatchSchema`，六个节点共享同一 owned layout 与 metadata 输入。`q_indptr={0,T}`、
`kv_indptr={0,L}` 和 bottom-right causal 语义明确当前可见范围；本机固定旅程为 T/L=23/23、4/27、1/28。
每次冷准备在原 `graph::Invocation` slot 上调用 `graph::batch::prepare`，随后绑定普通输入与输出，
再调用原 `prepare_replay` / `submit`；保留两个原始 slot、完整 24 层和全部 KV/conv/GDN 状态。
`reference.py` 是独立 Torch oracle，显式保留 continuation 的 conv/GDN 初始状态，候选不会读取它的状态或结果。

`--progress direct|scheduler` 选择原 Invocation 的直接提交或可选进度驱动，默认 `direct`。
构建本消费者的已安装 SDK 须包含 CUDA `compute;graph;graph_progress` 产品；
链接进度服务即可获得其公开的 Sched 依赖。CMake 只查包和链接，不构建原生依赖。
`scheduler` 在冷创建的原槽上调用 `prepare_progress`，由原 Scheduler/BlockingPool 按实际片段的阻塞属性推进；
两种模式均在 Completion 成功后反馈状态、读取 token。同一 Model 的 tokens、KV 和状态共享，`evaluate` 须顺序调用，
两个槽不授权并发覆盖这些输入。成功或异常退出均先 drain 原槽，再结束池和 Scheduler，最后释放模型数据。

`--decode-ids FILE` 用固定的单token输入序列继续计算，步数为序列长度加一，允许跨过预测EOS。
若同时传 `--steps`，两者必须一致。这是逐步条件分布诊断；输出 `generated_ids` 记录各步argmax，
`fixed_decode` 与 `decode_input_ids` 说明实际消费的输入，不将预测token或参考状态偷偷写回候选。
`--trace DIR --trace-level decisions` 只导出logits和最后hidden；默认 `full` 仍导出完整状态。
这样长旅程可以保留决策数据，避免为每个decode反复导出整套KV、conv和GDN数组。

RTX 4070 此前已完成两种模式的 prefill23 → continuation4 → decode1，两模式 150 个输出与状态 trace 逐字节一致。
随后利用通用 strided reshape 去掉 Q/K/V 等可直接消费切片的 Copy；跨 head 间隙的 flatten、固定状态和最终
hidden 输出仍显式 Copy。当前 direct 每个 phase 为完整 1878 节点、1204 个报告步骤（含 metadata View），
Copy 节点从 85 降为 25；150 个 trace 与修改前仍逐字节相同，next token 为 20 → 248046 → 198。
当前布局改动未重跑 scheduler。`--trace DIR` 同时把实际路由写入 `DIR/routes`，不新增图输出。
`submit_seconds` 只记录调用返回时间；`seconds` 包含提交、完成等待与读取 next token。
`step_seconds` 还包含输入/位置上传、batch布局准备、绑定及重放准备，始于shape入口查找/创建之后，
止于读取token之后；首次模型加载、shape编译和trace导出不在其中。对照每步decode成本须包含这些准备费用，
不能直接用`seconds`与其他引擎的完整decode时间比较。带trace的单次旅程用于接线与寿命核对，不作吞吐结论。
加载报告区分原权重读取/分配/同步上传、Model构造、shape入口冷准备，以及从输入解析到ready的总时间；
首次生成前预先冷准备本次prefill/续算与decode入口，不预跑数学或推进状态。`first_token_elapsed_seconds`
还包含prefill并止于首token读回。正常生成在原endoftext或tokenizer的im_end停止；固定输入诊断仍可继续。
ggml CUDA 借用原 Queue stream 后，完整三阶段 trace 仍相同。同配置关闭 trace、旧新各3次短请求，
首 decode 中位执行时间为33.59→20.27ms；正常EOS在第二decode结束，属于本次短请求实测，未证明持续warm decode。
独立 Torch 参考的 logits 相对 L2 差异约 2.151%、1.957%、2.459%，数值接受和公平 llama.cpp 对照仍未完成。

[RoPE 单因素诊断](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-rope-ablation.zip)
先逐字节复现独立参考的全部150份三阶段结果，再仅将该参考的 RoPE 中间改为 F32，最终 Q/K 仍为 BF16。
Hyle 未变；与这一参考的三阶段 logits 相对 L2 为1.940%、1.490%、2.127%，表明本样本存在部分因果贡献。
三阶段 top1 一致只覆盖这次固定输入，其他指标并非全部改善；这不是产品数学修复、精度接受或性能验收。

后续[固定输入32阶段](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/qwen-fixed-decode.zip)
使用既有science提示与31个预先确定的decode输入，两种推进模式真实反馈各自状态，64份决策向量逐字节一致，
可见长度达到52；原三阶段6份决策向量也与旧trace相同。独立Torch先复现原150份结果，再运行同一固定序列。
当前eager参考top1相同31/32，唯一差异步的最高两token同为20.25并列；只提高参考RoPE中间精度后，
其选择与Hyle一致。Hyle与eager的logits相对L2均值1.166%、KL均值6.462e-4，top5集合全部一致。
目标来自既有参考生成，属于数值和状态旅程诊断；独立质量语料、持续吞吐及公平llama.cpp对照仍待完成。

显式 `--layer0-probe DIR` 用于诊断：另行发布 layer0 的五个 BF16 边界及四个 FFN 切片，
并导出默认图和诊断图的实际路由；默认运行的图与 trace 不新增这些输出。
首个明显传播位于 post-attention RMSNorm 的 token21/channel619。原 native 归约 mean 比已保存 Torch variance
低 2 个 F32 ULP，后续两乘跨过 BF16 中点；实际 F32→BF16 全部符合 RNE。原 kernel 控制与诊断重放的
47,104 个 F32/BF16 元素均与原 Hyle 逐 bit 相同，未改数学去匹配 Torch。归约顺序解释此点，不证明全部层误差同源；
插桩的 FFMA 变化、离线推演与实际观察的界限保留在[审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
本地原输入与参考仍位于 `.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，没有复制权重或 SDK。
