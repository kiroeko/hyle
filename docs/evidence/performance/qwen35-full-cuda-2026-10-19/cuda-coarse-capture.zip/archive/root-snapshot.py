from pathlib import Path
import hashlib,json,difflib
root=Path.cwd();stage=root/'.scratch/architecture-refactor-2026-10-18/cuda-coarse-capture'
paths={'src/compute_provider_torch_cuda/artifact_provider.cc':'torch-artifact-provider.cc','tools/qwen35_text/main.cc':'qwen35-main.cc','tools/qwen35_text/README.md':'qwen35-README.md'}
rows=[];diff=[]
for name,oldname in paths.items():
 old=(stage/'before'/oldname).read_bytes();data=(root/name).read_bytes();dest=stage/'candidate'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),before_path=str(stage/'before'/oldname),before_sha256=hashlib.sha256(old).hexdigest()))
 diff.extend(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),data.decode('utf-8-sig').splitlines(True),fromfile='before/'+name,tofile='candidate/'+name))
(stage/'root-source-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
(stage/'root-source.diff').write_text(''.join(diff),encoding='utf-8')
print(json.dumps(rows,indent=2))
