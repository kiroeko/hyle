"""Archive the bounded cold-binding/capture change; never delete or run math."""
from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent
NATIVE = ARCH / "ggml-cuda-record-only"
TESTS = ARCH / "cuda-coarse-capture-tests"
TARGET = ROOT / "docs/evidence/performance/qwen35-full-cuda-2026-10-19/cuda-coarse-capture.zip"
ALLOWED = {".json", ".diff", ".cc", ".h", ".cu", ".cuh", ".py", ".log", ".xml", ".txt", ".tsv", ".csv", ".cmake", ".md", ".ids"}
GENERATED = {"archive-inventory.json", "archive-receipt.json"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))


def check_identity(row):
    path = Path(row["path"])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert (actual["bytes"], actual["sha256"]) == (row["bytes"], row["sha256"]), str(path)


def verify_sources():
    manifests = [OUT / "generic-hooks/source-freeze.json", NATIVE / "source-freeze.json",
                 NATIVE / "test-maintenance/source-freeze.json", TESTS / "test-source-freeze.json"]
    rows = []
    for manifest in manifests:
        data = read(manifest)
        for row in data.get("files", data.get("sources", [])):
            check_identity(row)
            rows.append(row)
    for row in read(OUT / "root-source-identities.json"):
        check_identity(row)
        rows.append(row)
    return dict(checked_manifest_files=[identity(p) for p in manifests],
                source_rows=len(rows), canonical_source_drift=0)


def verify_results():
    summary = read(TESTS / "summary.json")
    assert summary["distinct_passing_cases"] == 10
    assert summary["live_processes_from_this_stage"] == 0
    passed = set()
    for run in summary["actual_runs"]:
        check_identity(run["xml"])
        cases = list(ET.parse(run["xml"]["path"]).getroot().iter("testcase"))
        actual = {case.attrib["classname"] + "." + case.attrib["name"]:
                  not case.findall("failure") and not case.findall("skipped")
                  for case in cases}
        assert actual == {case["name"]: case["passed"] for case in run["cases"]}
        passed.update(name for name, ok in actual.items() if ok)
    assert sorted(passed) == summary["passing_case_names"]
    probe = read(TESTS / "qwen-probe-summary.json")
    assert len(probe["arms"]) == 2
    for arm in probe["arms"]:
        assert arm["exit"] == 0 and len(arm["prepared"]) == len(arm["steps"]) == 4
    parity = read(TESTS / "qwen-pair-parity.json")
    assert parity["vector_count"] == 8 and parity["all_byte_identical"]
    return dict(distinct_passing_cases=sorted(passed), qwen_functional_pairs=1,
                qwen_identical_vectors=8, performance_or_quality_acceptance=False,
                failed_attempts_retained=summary["failed_attempts_preserved"],
                limits=summary["limits"] + probe["limits"])


def verify_vectors():
    refs = read(TESTS / "decision-vector-archive-references.json")
    check_identity(refs["archive"])
    assert len(refs["vectors"]) == 8 and refs["new_payloads_to_archive"] == 0
    with zipfile.ZipFile(refs["archive"]["path"]) as prior:
        for row in refs["vectors"]:
            data = prior.read(row["archived_entry"])
            assert (len(data), sha(data)) == (row["bytes"], row["sha256"])
            assert f"{prior.getinfo(row['archived_entry']).CRC:08x}" == row["archived_crc32"]
            assert Path(row["commands_path"]).read_bytes() == data
            assert Path(row["prefer_path"]).read_bytes() == data
    return dict(archive=refs["archive"], referenced_original_payloads=8,
                current_arm_vectors_verified=16, new_vector_payloads=0,
                exact_reference_manifest=identity(TESTS / "decision-vector-archive-references.json"),
                raw_scratch_vectors_retained=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    sources, results, vectors = verify_sources(), verify_results(), verify_vectors()
    payloads, excluded = {}, []

    def add(name, path):
        assert name not in payloads
        payloads[name] = (path, path.read_bytes())

    folders = [("generic", OUT / "generic-hooks"), ("native", NATIVE), ("validation", TESTS),
               ("root/before", OUT / "before"), ("root/candidate", OUT / "candidate")]
    for prefix, folder in folders:
        for path in sorted(folder.rglob("*"), key=lambda p: p.as_posix()):
            if not path.is_file():
                continue
            name = prefix + "/" + path.relative_to(folder).as_posix()
            if (path.name in GENERATED or path.suffix.lower() not in ALLOWED
                    or path.name.endswith("-deps.json") or "__pycache__" in path.parts):
                excluded.append(dict(path=name, bytes=path.stat().st_size))
                continue
            add(name, path)
    for name in ["archive.py", "root-snapshot.py", "root-source-identities.json", "root-source.diff"]:
        add("archive/" + name, OUT / name)
    reclaim = ARCH / "cuda-coarse-capture-reclaim"
    for name in ["before-test.ps1", "before-script-identity.json", "cleanup-plan.json", "test.ps1"]:
        add("cleanup-preparation/" + name, reclaim / name)
    for name in ["docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md",
                 "docs/developer/current-work.md"]:
        add("documentation/" + name, ROOT / name)
    prompt = Path(read(TESTS / "qwen-commands-run-plan.json")["prompt"]["path"])
    add("inputs/prompt.ids", prompt)
    entries = [dict(path=name, bytes=len(data), sha256=sha(data))
               for name, (_, data) in sorted(payloads.items())]
    inventory = dict(schema="hyle.cuda.coarse.capture.archive.v1", output=str(TARGET),
                     payload_files=len(entries), payload_bytes=sum(r["bytes"] for r in entries),
                     entries=entries, excluded=excluded, sources=sources, results=results,
                     decision_vectors=vectors,
                     exclusions="No objects, images, maps, SDK/model data, huge raw include dependency JSON, old ZIP copies or repeated raw decision vectors. Filtered actual Hyle dependencies and original source/command identities are retained.",
                     deletion_performed=False)
    manifest = encoded(inventory)
    (OUT / "archive-inventory.json").write_bytes(manifest)
    if not args.write:
        print(json.dumps(dict(payload_files=len(entries), payload_bytes=inventory["payload_bytes"],
                              distinct_passing_cases=10, referenced_vectors=8, copied_vectors=0)))
        return
    with zipfile.ZipFile(TARGET, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (_, data) in sorted(payloads.items()):
            archive.writestr(name, data)
        archive.writestr("archive-manifest.json", manifest)
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(entries) + 1
        assert archive.read("archive-manifest.json") == manifest
        for row in entries:
            data = archive.read(row["path"])
            assert (len(data), sha(data)) == (row["bytes"], row["sha256"])
    for path, data in payloads.values():
        assert path.read_bytes() == data, str(path)
    receipt = dict(archive=identity(TARGET), entries=len(entries) + 1,
                   payload_files=len(entries), payload_bytes=inventory["payload_bytes"],
                   manifest_sha256=sha(manifest), crc_verified=True,
                   every_payload_sha256_verified=True, source_drift=0,
                   distinct_passing_cases=10, qwen_functional_pairs=1,
                   referenced_original_vectors=8, copied_vectors=0,
                   retained_raw_vectors=16, deleted_files=0,
                   cleanup_candidates=identity(TESTS / "cleanup-windows.json"))
    (OUT / "archive-receipt.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
