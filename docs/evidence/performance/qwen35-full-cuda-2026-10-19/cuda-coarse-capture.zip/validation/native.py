from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import build as b
ROOT=b.ROOT;ARCH=b.ARCH
name='ggml-cuda-record-cub' if '--cub-fix' in sys.argv else 'ggml-cuda-record'
freeze=b.read(ARCH/'ggml-cuda-record-only/source-freeze.json')
source=Path(freeze['native']['native_files'][0]['path'])
assert b.ident(source)=={k:freeze['native']['native_files'][0][k] for k in ['path','bytes','sha256']}
recipe=b.read(ARCH/'cuda-bfloat-elementwise-build/ggml-cuda-identity.json')
args=[];skip=False
for v in recipe['command']:
 if skip:skip=False;continue
 if v in ['-MT','-MF','-c','-o']:skip=True;continue
 if v.startswith('-Xcompiler=-Fd'):continue
 args.append(v)
args+=['-MT',str(HERE/(name+'.obj')),'-MF',str(HERE/(name+'.d')),
 '-c',str(source),'-o',str(HERE/(name+'.obj')),
 '-Xcompiler=-Fd'+str(HERE/(name+'.pdb'))+',-FS']
b.save('native-compile-plan.json',dict(command=args,original=b.ident(ARCH/'cuda-bfloat-elementwise-build/ggml-cuda-identity.json'),
 source=b.ident(source),freeze=b.ident(ARCH/'ggml-cuda-record-only/source-freeze.json'),
 changes='Only final main CU source and output/dependency paths; original flags/include order/sm89 retained.'))
initial=b.ident(source)
dst=HERE/'candidate/native/ggml-cuda.cu';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source.read_bytes())
b.execute(name+'-main-compile',args)
assert b.ident(source)==initial
headers=[ROOT/'src/compute_provider_ggml_cuda/native_bridge.h',ROOT/'src/compute_provider_ggml_cuda/native_bridge_impl.h',
 ROOT/'.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/common.cuh']
b.save(name+'-identity.json',dict(source=initial,object=b.ident(HERE/(name+'.obj')),
 command=args,dependency_file=b.ident(HERE/(name+'.d')),matching_headers=[b.ident(p) for p in headers],
 reuses='Original all other native math objects, prior BF16 binbcast/unary/tensor-current, IQ1 and reference3libs.'))
