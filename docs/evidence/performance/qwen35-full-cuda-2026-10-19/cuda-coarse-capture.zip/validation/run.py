from pathlib import Path
import sys,os,json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import build as b
base=b.read(b.ARCH/'cuda-bfloat-elementwise-build/candidate-link-plan.json')['command']
libs=[str(Path(x).parent) for x in base if Path(x).is_absolute() and x.lower().endswith('.lib')]
libs+= [str(Path(x).parent) for x in b.read(b.ARCH/'cold-placement-facts/link-plan.json')['command']
 if Path(x).is_absolute() and x.lower().endswith('.lib')]
b.ENV['PATH']=os.pathsep.join(dict.fromkeys(libs))+os.pathsep+b.ENV['PATH']
kind=sys.argv[1];plan=b.read(HERE/(kind+'-run-plan.json'))
b.execute(kind+'-focused-tests-run',plan['command'],timeout=plan['timeout_seconds'])
plan['not_run']=False;b.save(kind+'-run-plan.json',plan)
