from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import build as b
ROOT=b.ROOT;ARCH=b.ARCH
read=b.read;save=b.save;ident=b.ident
HISTORY=[ARCH/x/'commands.json' for x in [
 'native-ready-pages/windows','native-ragged-graph/validation/windows',
 'retire-native-runtime/paging-risks','native-runtime-retirement/metadata-oom-review',
 'cpu-context-assembly','cold-placement-facts','ggml-cuda-caller-workspace',
 'ggml-cuda-caller-workspace-tests','cuda-bfloat-elementwise-build',
 'native-ready-pages/schema']]
HISTORY += [p for directory in ['native-ragged-graph/validation/windows',
    'qwen-fixed-decode','ggml-cuda-caller-workspace']
    for p in (ARCH/directory).glob('*compile*.result.json')]
CPU_BASE=ARCH/'cold-placement-facts/link-plan.json'
CUDA_BASE=ARCH/'cuda-bfloat-elementwise-build/candidate-link-plan.json'
impact=read(ARCH/'cuda-coarse-capture/generic-hooks/owner-impact.json')
WANTED=set(impact['provider_contract_or_callback_exact_cpp_owners']+
 impact['graph_plan_state_include_owners']+impact['direct_changed_tus'])
WANTED.discard('tests/graph/region_provider_test.cc')
HOLD={'src/graph/executable.cc','src/graph/submission.cc',
 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc'}

def relative(value):
 try:return Path(value).resolve().relative_to(ROOT).as_posix()
 except ValueError:return None

def plan():
 rows=[]
 for history in HISTORY:
  if not history.exists():continue
  value=read(history)
  for row in value if isinstance(value,list) else [value]:
   cmd=row.get('command',row.get('argv',[]))
   if row.get('exit')!=0 or not cmd or Path(cmd[0]).name.lower()!='cl.exe':continue
   src=[v for v in cmd if str(v).lower().endswith('.cc') and Path(v).is_file()]
   obj=[v[3:] for v in cmd if str(v).lower().startswith('/fo')]
   if len(src)==len(obj)==1:
    rows.append(dict(source=relative(src[0]),command=cmd,object=str(Path(obj[0]).resolve()),
                     origin=str(history),tag=row.get('tag')))
 bases={name:read(path)['command'] for name,path in [('cuda',CUDA_BASE),('cpu',CPU_BASE)]}
 selected={str(Path(v).resolve()) for cmd in bases.values() for v in cmd
           if Path(v).is_absolute() and Path(v).suffix.lower()=='.obj'}
 selected_sources={r['source'] for r in rows if r['object'] in selected}
 missing=[];owners=[]
 for source in sorted(WANTED):
  candidates=[r for r in rows if r['source']==source]
  actual=[r for r in candidates if r['object'] in selected]
  if not actual:
   missing.append(dict(source=source,reason='not found as explicit selected object in saved recipe index',
                       recipes=len(candidates)))
   continue
  chosen=actual[-1]
  owners.append(dict(source=source,name=source[4:-3].replace('/','--'),
       template=chosen['command'],origin=chosen['origin'],
       old_objects=sorted({r['object'] for r in actual}),
       current=ident(ROOT/source),hold=source in HOLD))
 save('host-plan.json',dict(cuda_base=str(CUDA_BASE),cpu_base=str(CPU_BASE),owners=owners,
    not_explicit=missing,recipe_history=[str(x) for x in HISTORY],
    note='Only selected explicit objects intersect current17 owner-impact. No SDK/native math build.'))
 print('selected host owners',len(owners),'not explicit',len(missing))
 for row in missing:print('NOT EXPLICIT',row)
 for row in owners:print('HOLD' if row['hold'] else 'COMPILE',row['source'])

def compile_selected(final=False):
 data=read(HERE/'host-plan.json')
 for row in data['owners']:
  if row['hold'] and not final:continue
  if row['source']=='src/compute_provider_torch_cuda/artifact_provider.cc':
   receipt=read(HERE/'torch-artifact-identity.json')
   assert ident(ROOT/row['source'])==receipt['source'];continue
  receipt=HERE/(row['name']+'-identity.json')
  if receipt.exists():
   previous=read(receipt)
   assert previous['source']==ident(ROOT/row['source'])
   assert previous['object']==ident(previous['object']['path'])
   print('REUSE',row['name'],flush=True);continue
  assert ident(ROOT/row['source'])==row['current'],'plan source drift'
  b.compile_one(row['source'],row['name'],row['template'])
 print('Host batch done; held native/Graph follow source freeze. No link/run.',flush=True)

def chain_test():
 args=list(b.DRAFT['test_command'])
 args.insert(1,'/DHYLE_COMPUTE_GGML_CUDA=1')
 b.compile_one('tests/compute_provider_torch_cuda/attention_test.cc','torch-chain-test',args)

if __name__=='__main__':
 {'plan':plan,'compile-hosts':compile_selected,'compile-final':lambda:compile_selected(True),
  'compile-chain-test':chain_test}[sys.argv[1]]()
