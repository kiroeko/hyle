from pathlib import Path
import sys,os,json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import build as b
mode=sys.argv[1]
base=b.read(b.ARCH/'cuda-bfloat-elementwise-build/candidate-link-plan.json')['command']
libs=[str(Path(x).parent) for x in base if Path(x).is_absolute() and x.lower().endswith('.lib')]
b.ENV['PATH']=os.pathsep.join(dict.fromkeys(libs))+os.pathsep+b.ENV['PATH']
inputs=b.ARCH/'qwen-fixed-decode/science-inputs'
assert len((inputs/'prompt.ids').read_text().split())==21
ids=b.read(b.ARCH/'qwen-fixed-decode/fixed-inputs.json')['decode_input_ids'][:3]
tape=HERE/'decode-3.ids'
if not tape.exists():tape.write_text(' '.join(map(str,ids))+'\n')
assert list(map(int,tape.read_text().split()))==ids
name='qwen-'+mode
trace=HERE/('trace-'+mode)
args=[str(HERE/'qwen-capture.exe'),'--inputs',str(inputs),'--decode-ids',str(tape),
 '--steps','4','--capacity','256','--progress','direct','--replay',mode,
 '--trace-level','decisions','--trace',str(trace)]
b.save(name+'-run-plan.json',dict(command=args,model_manifest=b.ident(inputs/'weights.tsv'),
 prompt=b.ident(inputs/'prompt.ids'),decode_ids=ids,tape=b.ident(tape),image=b.ident(HERE/'qwen-capture.exe'),
 note='Only one process per arm, same 21-token prompt+3 fixed decode inputs, original two slots, no profiler. No performance headline or precision acceptance.'))
b.execute(name+'-probe-run',args,timeout=120)
files=sorted(p for p in trace.rglob('*') if p.is_file() and p.suffix in ['.f32','.bf16'])
assert len(files)==8,len(files)
b.save(name+'-decisions.json',dict(files=[dict(relative=str(p.relative_to(trace)),**b.ident(p))for p in files]))
