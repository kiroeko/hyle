from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
ARCH = OUT.parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


DRAFT = read(OUT / 'build-plan-draft.json')
original = read(ARCH / 'native-runtime-retirement/metadata-oom-review/commands.json')
torch = next(row for row in original if any(str(v).endswith('artifact_provider.cc')
                                           for v in row['command']))['command']
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
ENV = windows_compiler_environment({'CMAKE_CXX_COMPILER': torch[0]})
ENV['VSLANG'] = '1033'


def execute(tag, argv, timeout=None):
    rows = read(OUT / 'commands.json') if (OUT / 'commands.json').exists() else []
    assert not any(row['tag'] == tag for row in rows), 'No implicit compiler retry'
    stem = f'{len(rows)+1:03d}-{tag}'
    row = dict(tag=tag, command=list(map(str, argv)), cwd=str(ROOT), started=time.time(),
               stdout=stem+'.stdout.log', stderr=stem+'.stderr.log', exit=None)
    rows.append(row)
    save('commands.json', rows)
    with (OUT / row['stdout']).open('wb') as so, (OUT / row['stderr']).open('wb') as se:
        process = subprocess.Popen(row['command'], cwd=ROOT, env=ENV, stdout=so, stderr=se,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        row['pid'] = process.pid
        save('live.json', row)
        save('commands.json', rows)
        print('START', stem, 'PID', process.pid, flush=True)
        try:
            row['exit'] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            row['exit'] = process.wait()
            row['timed_out_after_seconds'] = timeout
    row.update(terminal=True, finished=time.time())
    save('commands.json', rows)
    save('live.json', row)
    print('END', stem, row['exit'], round(row['finished']-row['started'], 3), flush=True)
    if row['exit']:
        print((OUT / row['stdout']).read_text(errors='replace')[-9000:], flush=True)
        print((OUT / row['stderr']).read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(row['exit'])


def compile_one(source, name, template):
    source = ROOT / source
    initial = ident(source)
    destination = OUT / 'candidate' / source.relative_to(ROOT)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(source.read_bytes())
    args = []
    skip = False
    for value in template:
        if skip:
            skip = False
            continue
        if value.lower() == '/sourcedependencies':
            skip = True
            continue
        if value.lower().startswith(('/fo', '/fd')) or value.lower().endswith('.cc'):
            continue
        args.append(value)
    assert '/W4' in args and '/WX' in args
    args += ['/sourceDependencies', str(OUT / (name+'-deps.json')), str(source),
             '/Fo'+str(OUT / (name+'.obj'))]
    execute(name+'-compile', args)
    assert ident(source) == initial, 'Source changed during actual compilation'
    includes = read(OUT / (name+'-deps.json'))['Data']['Includes']
    local = [ident(path) for path in includes if any(Path(path).resolve().is_relative_to(ROOT / part)
             for part in ['include', 'src', 'tests'])]
    save(name+'-identity.json', dict(source=initial, object=ident(OUT / (name+'.obj')),
        command=args, current_hyle_dependency_identities=local,
        note='Only actual Hyle source dependencies of this TU, no broad old-closure re-audit.'))


if __name__ == '__main__':
    assert not sys.argv[1:]
    compile_one('src/compute_provider_torch_cuda/artifact_provider.cc', 'torch-artifact', torch)
    compile_one('tests/compute_provider_torch_cuda/attention_test.cc', 'torch-test', DRAFT['test_command'])
    save('compile-summary.json', dict(status='two_current_TUs_strict_compiled_not_linked_or_run',
        owners=[read(OUT / (name+'-identity.json')) for name in ['torch-artifact', 'torch-test']],
        root_before_source=ident(ARCH / 'cuda-coarse-capture/before/torch-artifact-provider.cc'),
        pending='Wait current17 remaining provider-table/common owner freeze for matched link.',
        linked=False, gpu_execution=False, sdk_or_native_math_compilation=False))
    print('Two host TUs compiled. No link or GPU execution.', flush=True)
