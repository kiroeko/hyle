from pathlib import Path
import sys,os,json
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import build as b
ROOT=b.ROOT;ARCH=b.ARCH
CUDA_BASE=ARCH/'cuda-bfloat-elementwise-build/candidate-link-plan.json'
CPU_BASE=ARCH/'cold-placement-facts/link-plan.json'
GPU_TESTS=['TorchCudaSoftplus.ColdCaptureRetainsTypedTailsTwoSlotsAndReboundAddresses',
 'TorchCudaSoftplus.OneCapturedRangeCrossesGgmlAndTorchWithIndependentSlots']

def make(kind, proof_only=False, suffix=''):
 base=CPU_BASE if kind=='cpu' else CUDA_BASE
 args=b.read(base)['command'];replace={};selected=[]
 for row in b.read(HERE/'current-host-owners.json')['owners']:
  assert b.ident(row['object']['path'])==row['object']
  used=[p for p in row['old_objects'] if p in args]
  for p in used:replace[p]=row['object']['path']
  if used:selected.append(row)
 if kind=='cpu':
  proof=ARCH/'legacy-native-retirement/contracts/windows/resources-compile-receipt.json'
  old=b.read(proof)
  assert Path(old['source']['path']).resolve()==ROOT/'src/graph/resources.cc'
  oldobj=str(ARCH/'legacy-native-retirement/contracts/windows/resources-fce1fdc7ad0f.obj')
  assert oldobj in args
  new=next(r for r in b.read(HERE/'current-host-owners.json')['owners'] if r['source']=='src/graph/resources.cc')
  replace[oldobj]=new['object']['path'];selected.append(new)
  # This historical CPU control carrier also explicitly listed an obsolete
  # row-node owner. Reuse the current same source owner already selected by
  # the completed CUDA closure; no row operation is added to the five tests.
  oldrow=str(ARCH/'native-ready-pages/windows/graph_batch--row_cache_node.obj')
  newrow=str(ARCH/'row-cache-region-projection/src--graph_batch--row_cache_node.obj')
  assert oldrow in args
  replace[oldrow]=newrow
  oldtest=str(ARCH/'cold-placement-facts/region-test.obj');assert args.count(oldtest)==1
  replace[oldtest]=str(HERE/'region-control-test.obj')
  output='cpu-controls'
 else:
  replace[str(ARCH/'cuda-admitted-ggml-stream-implementation/cuda_backend.obj')]=str(HERE/'cuda-backend-final.obj')
  replace[str(ARCH/'cuda-bfloat-elementwise-build/ggml-cuda.obj')]=str(HERE/(
      'ggml-cuda-record-cub.obj' if '--cub-fix' in sys.argv else 'ggml-cuda-record.obj'))
  consumer=str(ARCH/'qwen-gpu-comparison/hyle-consumer.obj');assert args.count(consumer)==1
  replace[consumer]=str(HERE/('qwen-consumer.obj' if kind=='qwen' else
      'torch-batched-chain-test.obj' if '--batch-fixture' in sys.argv else 'torch-matmul-chain-test.obj'))
  output='qwen-capture' if kind=='qwen' else 'softplus-capture-tests'
 args=[replace.get(v,v) for v in args if not v.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 if kind=='gpu':args += [str(ROOT/'.scratch/build-compute-v2-dev/lib'/n) for n in ['gtest_main.lib','gtest.lib']]
 if '--adjacent' in sys.argv:
  args[1:1]=[b.read(HERE/'reused-graph-test-identity.json')['object']['path'],str(HERE/'sglang-checked-test.obj')]
 if '--mean' in sys.argv:args[1:1]=[str(HERE/'ggml-mean-test.obj')]
 args+=['/OUT:'+str(HERE/(output+'.exe')),'/MAP:'+str(HERE/(output+'.map')),'/IMPLIB:'+str(HERE/(output+'.lib'))]
 assert len([v for v in args if v.lower().endswith('.obj')])==len(set(v for v in args if v.lower().endswith('.obj')))
 assert all(Path(v).is_file() for v in args if Path(v).is_absolute() and Path(v).suffix.lower() in ['.lib','.obj'])
 if suffix:
  prior=HERE/'initial-linked-before-cold-retry';prior.mkdir(exist_ok=True)
  for name in [output+'-link-plan.json',output+'-image.json',output+'-map-owners.json']:
   if (HERE/name).exists():(prior/name).write_bytes((HERE/name).read_bytes())
 b.save(output+'-link-plan.json',dict(command=args,original=b.ident(base),replacements=replace,selected_current_host_owners=selected))
 if proof_only:
  assert b.read(HERE/(output+'-link-plan.json'))['command']==args
  assert (HERE/(output+'.exe')).exists()
 else:b.execute(output+'-link'+suffix,args)
 lines=(HERE/(output+'.map')).read_text(errors='replace').splitlines()
 mentions=[]
 for row in selected:
  name=Path(row['object']['path']).name
  found=[v for v in lines if v.split() and v.split()[-1].lower()==name.lower()]
  if found:mentions.append(dict(source=row['source'],object=row['object'],count=len(found),sample=found[:2]))
  else:mentions.append(dict(source=row['source'],object=row['object'],count=0,
      note='Explicit current object in actual link argv; no retained public symbol in /OPT:REF map for this consumer.'))
 b.save(output+'-map-owners.json',dict(map=b.ident(HERE/(output+'.map')),selected=mentions,
  note='All current selected Provider17/InvocationState owners are explicit; original SDK/native objects remain retained.'))
 b.save(output+'-image.json',dict(image=b.ident(HERE/(output+'.exe')),map=b.ident(HERE/(output+'.map'))))
 if kind=='gpu':
  b.save('gpu-run-plan.json',dict(command=[str(HERE/(output+'.exe')),'--gtest_color=no','--gtest_filter='+':'.join(GPU_TESTS),
   '--gtest_output=xml:'+str(HERE/'softplus-tests.xml')],tests=GPU_TESTS,not_run=True,timeout_seconds=90))
 if kind=='cpu':
  filters=b.read(ARCH/'cuda-coarse-capture/generic-hooks/cpu-control-plan.json')['filters']
  b.save('cpu-run-plan.json',dict(command=[str(HERE/(output+'.exe')),'--gtest_color=no','--gtest_filter='+':'.join(filters),
   '--gtest_output=xml:'+str(HERE/'cpu-controls.xml')],tests=filters,not_run=True,timeout_seconds=90))

if __name__=='__main__':make(sys.argv[1], '--proof-only' in sys.argv[2:],
    '-cold-retry' if '--cold-retry' in sys.argv[2:] else
    '-mean' if '--mean' in sys.argv[2:] else
    '-adjacent' if '--adjacent' in sys.argv[2:] else
    '-cub-fix' if '--cub-fix' in sys.argv[2:] else
    '-batch-fixture' if '--batch-fixture' in sys.argv[2:] else
    '-row-owner' if '--row-owner' in sys.argv[2:] else '')
