from pathlib import Path
import sys,json,hashlib,re,zipfile,zlib,difflib,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import build as b
ROOT=b.ROOT;ARCH=b.ARCH

def save(name,value):b.save(name,value)

def vectors():
 a=b.read(HERE/'qwen-commands-decisions.json')['files'];bb=b.read(HERE/'qwen-prefer-capture-decisions.json')['files']
 byname={r['relative']:r for r in bb}
 prior=ROOT/'docs/evidence/performance/qwen35-full-cuda-2026-10-19/ggml-cuda-caller-workspace.zip'
 receipt=b.read(ARCH/'ggml-cuda-caller-workspace/archive-receipt.json')
 assert b.ident(prior)['sha256']==receipt['sha256']
 rows=[]
 with zipfile.ZipFile(prior) as z:
  manifest=json.loads(z.read('manifest.json'))
  for row in a:
   other=byname[row['relative']]
   assert row['bytes']==other['bytes'] and row['sha256']==other['sha256']
   ref=next(r for r in manifest['entries'] if r['sha256']==row['sha256'] and r['bytes']==row['bytes'])
   data=z.read(ref['stored_as']);info=z.getinfo(ref['stored_as'])
   assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
   assert zlib.crc32(data)&0xffffffff==info.CRC
   rows.append(dict(relative=row['relative'],bytes=row['bytes'],sha256=row['sha256'],
        archived_entry=ref['stored_as'],archived_crc32=f'{info.CRC:08x}',
        commands_path=row['path'],prefer_path=other['path'],verified_actual_archived_payload=True))
 save('decision-vector-archive-references.json',dict(archive=b.ident(prior),original_receipt=b.ident(ARCH/'ggml-cuda-caller-workspace/archive-receipt.json'),
      vectors=rows,all8_bit_identical_to_prior_and_between_modes=True,new_payloads_to_archive=0,
      note='Read and SHA+CRC verified exactly these eight original ZIP payloads; no model/SDK/all-trace copy. Current both-arm raw vectors remain scratch.'))

def probe():
 rows=[]
 for mode in ['commands','prefer-capture']:
  row=next(x for x in b.read(HERE/'commands.json') if x['tag']=='qwen-'+mode+'-probe-run')
  text=(HERE/row['stderr']).read_text()
  prep=[];steps=[]
  for line in text.splitlines():
   if line.startswith('prepared T='):
    prep.append(dict((k,float(v) if k=='cold_batch_seconds' else v) for k,v in re.findall(r'(\w+)=([^ ]+)',line)))
   if line.startswith(('prefill tokens=','decode1 tokens=','decode2 tokens=','decode3 tokens=')):
    d=dict(re.findall(r'(\w+)=([^ ]+)',line));d['phase']=line.split()[0]
    for k in ['seconds','submit_seconds','step_seconds']:d[k]=float(d[k])
    steps.append(d)
  assert row['exit']==0 and len(prep)==len(steps)==4
  rows.append(dict(mode=mode,pid=row['pid'],exit=row['exit'],process_seconds=row['finished']-row['started'],
    prepared=prep,steps=steps,stdout=json.loads((HERE/row['stdout']).read_text()),
    native_graph_warmup_messages=text.count('CUDA graph warmup complete')))
 save('qwen-probe-summary.json',dict(arms=rows,decision_vectors_equal=8,
   limits=['One bounded sequential pair, no performance acceptance or throughput headline.',
    'Complete step_seconds includes cold preparation; all PreferCapture steps are hybrid.',
    'Qwen still resets and rebinds every episode, therefore these captures are recreated; no amortized reuse claim.',
    'Commands third decode includes original native graph warmup messages; single-pair times cannot isolate scheduler/device costs.',
    'No Torch-reference/model precision acceptance is inferred from same-product decision parity.']))

def freeze():
 owners=b.read(HERE/'current-host-owners.json')['owners'];fresh=[]
 for row in owners:fresh.append(b.read(row['receipt']))
 extras=['cuda-backend-final','torch-batched-chain-test','region-control-test','sglang-checked-test','ggml-mean-test','qwen-consumer']
 fresh += [b.read(HERE/(name+'-identity.json')) for name in extras]
 deps={};drift=[]
 for row in fresh:
  src=row['source'];assert b.ident(src['path'])==src
  for d in row.get('current_hyle_dependency_identities',[]):
   actual=b.ident(d['path'])
   if actual!=d:drift.append(dict(compiled_source=src['path'],compiled=d,current=actual))
   deps[d['path']]=d
 native=b.read(HERE/'ggml-cuda-record-cub-identity.json')
 assert b.ident(native['source']['path'])==native['source']
 for d in native['matching_headers']:
  assert b.ident(d['path'])==d;deps[d['path']]=d
 assert not drift,drift
 save('filtered-current-dependencies.json',dict(fresh_host_TUs=len(fresh),files=sorted(deps.values(),key=lambda r:r['path']),
   actual_hyle_dependency_count=len(deps),source_and_actual_dependency_drift=drift,
   scope='Only actual compiler-recorded Hyle dependencies of final fresh objects plus actual main native bridge/common headers. No broad SDK/old-closure re-audit.'))
 rels=['tests/compute_provider_torch_cuda/attention_test.cc','tests/compute_provider_torch_cuda/CMakeLists.txt']
 rows=[];diff=[]
 for rel in rels:
  p=ROOT/rel;q=HERE/'candidate'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());rows.append(b.ident(p))
  diff+=difflib.unified_diff((HERE/'before'/rel).read_text().splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='before/'+rel,tofile='candidate/'+rel)
 save('test-source-freeze.json',dict(sources=rows,first_compilation='initial-2tu',
   prior_fixture_sources=['037-add-chain-attention_test.cc','052-matmul-rank2-attention_test.cc']))
 (HERE/'test-source.diff').write_text(''.join(diff),newline='\n')
 final=[dict(source=r['source'],object=r['object']) for r in fresh]
 final.append(dict(source=native['source'],object=native['object'],matching_headers=native['matching_headers']))
 save('final-selected-owners.json',dict(fresh_owners=final,reused_graph_test=b.read(HERE/'reused-graph-test-identity.json'),
   reuse_reason='Unchanged source/object; contains neither current Provider callback tables nor InvocationState private layout. Same actual public class ABI.',
   generic_final_freeze=b.ident(ARCH/'cuda-coarse-capture/generic-hooks/source-freeze.json'),
   native_final_freeze=b.ident(ARCH/'ggml-cuda-record-only/source-freeze.json'),
   original_base=b.ident(ARCH/'cuda-bfloat-elementwise-build/candidate-link-plan.json'),
   native_rebuilt='Only original main CUDA TU; 038 initial and 058 final CUB-header refresh. BF16 binbcast/unary, tensor carrier, IQ1, FlashInfer and reference math libraries reused.'))
 test_runs=[];unique=set()
 for command_tag,xml in [('gpu-focused-tests-run','softplus-tests.xml'),('cross-cub-focused-tests-run','cross-cub-tests.xml'),
  ('cpu-focused-tests-run','cpu-controls.xml'),('adjacent-focused-tests-run','adjacent-tests.xml'),('mean-focused-tests-run','mean-tests.xml')]:
  row=next(r for r in b.read(HERE/'commands.json') if r['tag']==command_tag)
  doc=ET.parse(HERE/xml).getroot();cases=[]
  for case in doc.iter('testcase'):
   passed=case.find('failure') is None and case.find('error') is None
   name=case.attrib['classname']+'.'+case.attrib['name'];cases.append(dict(name=name,passed=passed))
   if passed:unique.add(name)
  test_runs.append(dict(command_tag=command_tag,pid=row['pid'],exit=row['exit'],xml=b.ident(HERE/xml),cases=cases))
 assert len(unique)==10,len(unique)
 failures=[dict(tag=r['tag'],exit=r['exit'],stdout=r['stdout'],stderr=r['stderr'])for r in b.read(HERE/'commands.json') if r['exit']]
 summary=dict(status='bounded_validation_complete_frozen',distinct_passing_cases=10,passing_case_names=sorted(unique),actual_runs=test_runs,
   failed_attempts_preserved=failures,failure_reasons=[
    '052: pure Torch typed capture passed; cross ordinary two-dimensional float MatMul declined its established provider domain. Test moved to true batch=1 rank3, same arithmetic/element counts.',
    '055: valid three-step cross-provider graph exposed blanket auto-CUB capture rejection. Native qualification fixed using actual original enabled state/checker; final060 passed.',
    '056: historical CPU carrier had stale row_cache_node owner calling removed configure_operation; reused already-current source owner,057 link passed.'],
   qwen_probe=b.ident(HERE/'qwen-probe-summary.json'),qwen_vector_references=b.ident(HERE/'decision-vector-archive-references.json'),
   final_owners=b.ident(HERE/'final-selected-owners.json'),filtered_dependency_check=b.ident(HERE/'filtered-current-dependencies.json'),
   live_processes_from_this_stage=0,gpu_released=True,no_more_build_or_gpu_planned=True,
   no_new_sdk_math_or_model_copy=True,only_native_main_TU_recompiled=True,
   limits=['No Qwen quality/precision acceptance or throughput result.',
    'No full provider suite/platform matrix.',
    'Two unique new Softplus cases passed in separate final rounds; not a single final2/2 run.',
    'Old two-dimensional MatMul capability was not changed.',
    'Final Mean ran only the new case; the additional helper-maintenance oldcase was compile-covered, not separately run.'])
 save('summary.json',summary)
 images=[]
 for stem in ['cpu-controls','softplus-capture-tests','qwen-capture']:
  for ext in ['.exe','.map','.lib','.exp']:
   p=HERE/(stem+ext)
   if p.exists():images.append(b.ident(p))
 retained=[b.ident(p)for p in sorted(HERE.glob('*.obj'))]
 raw=[b.ident(p)for folder in ['trace-commands','trace-prefer-capture']for p in sorted((HERE/folder).rglob('*'))if p.is_file() and p.suffix in ['.f32','.bf16']]
 save('cleanup-windows.json',dict(root=str(ROOT),directory=str(HERE),files=images,bytes=sum(r['bytes']for r in images),
   retain=retained,retained_raw_vectors=raw,delete_executed=False,
   restriction='Exact completed-stage .exe/.map/.lib/.exp only; keep every object, source, raw vector, log, original SDK/model/cache.'))
 print('FROZEN',len(unique),'unique tests;',len(images),'images;',sum(r['bytes']for r in images),'bytes;',len(retained),'local objs retained')

vectors();probe();freeze()
