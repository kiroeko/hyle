from pathlib import Path
import sys,json,shutil
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
import build as b
ROOT=b.ROOT;ARCH=b.ARCH

def stale(row):
 result=[]
 if b.ident(row['source']['path'])!=row['source']:result.append(row['source']['path'])
 for item in row.get('current_hyle_dependency_identities',[]):
  if b.ident(item['path'])!=item:result.append(item['path'])
 return result

def hosts():
 data=b.read(HERE/'host-plan.json');final=[];changes=[]
 for row in data['owners']:
  name='torch-artifact' if row['source']=='src/compute_provider_torch_cuda/artifact_provider.cc' else row['name']
  receipt=HERE/(name+'-identity.json');new=HERE/(name+'-final-identity.json')
  if new.exists():
   got=b.read(new);assert not stale(got);final.append(dict(source=row['source'],old_objects=row['old_objects'],receipt=str(new),object=got['object']));continue
  reasons=stale(b.read(receipt)) if receipt.exists() else ['not yet compiled']
  if reasons:
   saved=HERE/'candidate'/row['source']
   if saved.exists():
    prior=HERE/'superseded-before-final'/row['source'];prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes(saved.read_bytes())
   b.compile_one(row['source'],name+'-final',row['template'])
   receipt=new
   changes.append(dict(source=row['source'],reasons=reasons))
  final.append(dict(source=row['source'],old_objects=row['old_objects'],receipt=str(receipt),object=b.read(receipt)['object']))
  b.save('current-host-owners.json',dict(owners=final,actual_refreshes=changes))
 print('Current17 final owner receipt list written, no link or GPU.',flush=True)

def backend():
 old=b.read(ARCH/'cuda-admitted-ggml-stream-implementation/cuda_backend-identity.json')
 b.compile_one('src/compute_backend_cuda/cuda_backend.cc','cuda-backend-final',old['command'])

def mock():
 cp=b.read(ARCH/'cuda-coarse-capture/generic-hooks/cpu-control-plan.json')
 row=cp['compile_recipe'];cmd=b.read(row['path'])[row['json_index']]['command']
 b.compile_one(row['source'],'region-control-test',cmd)

def chain():
 cmd=list(b.DRAFT['test_command']);cmd.insert(1,'/DHYLE_COMPUTE_GGML_CUDA=1')
 b.compile_one('tests/compute_provider_torch_cuda/attention_test.cc',
   'torch-batched-chain-test' if '--batch-fixture' in sys.argv else 'torch-matmul-chain-test',cmd)

def qwen():
 cmd=b.read(ARCH/'qwen-gpu-comparison/compile-hyle.result.json')['argv']
 b.compile_one('tools/qwen35_text/main.cc','qwen-consumer',cmd)

def retry_provider():
 source='src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'
 row=next(x for x in b.read(HERE/'host-plan.json')['owners'] if x['source']==source)
 name='ggml-cuda-provider-cold-retry'
 b.compile_one(source,name,row['template'])
 data=b.read(HERE/'current-host-owners.json')
 for row in data['owners']:
  if row['source']==source:
   row['receipt']=str(HERE/(name+'-identity.json'))
   row['object']=b.read(row['receipt'])['object']
 b.save('current-host-owners.json',data)

def checked():
 old=b.read(ARCH/'ggml-cuda-caller-workspace-consumer-validation/graph_route_cuda--graph-test-identity.json')
 assert b.ident(old['source']['path'])==old['source']
 assert b.ident(old['object']['path'])==old['object']
 b.save('reused-graph-test-identity.json',old)
 b.compile_one('tests/graph_route_cuda/sglang_primitives_test.cc','sglang-checked-test',old['command'])

def mean():
 old=b.read(ARCH/'cuda-bfloat-elementwise-tests/region-test-identity.json')
 b.compile_one('tests/graph_provider_ggml_cuda/region_test.cc','ggml-mean-test',old['command'])

if __name__=='__main__':{'hosts':hosts,'backend':backend,'mock':mock,'chain':chain,'qwen':qwen,
 'retry-provider':retry_provider,'checked':checked,'mean':mean}[sys.argv[1]]()
