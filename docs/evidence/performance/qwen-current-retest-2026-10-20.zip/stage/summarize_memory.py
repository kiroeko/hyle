"""Summarize the two separate observed-memory runs without altering timing data."""
import hashlib
import json
from pathlib import Path
import shutil
S = Path(__file__).resolve().parent
out = S / "memory-probe"
out.mkdir(exist_ok=True)
arms = {}
for arm in ("current", "llama"):
    path = S / ("memory-" + arm) / "samples.json"
    data = json.loads(path.read_text())
    assert data["exit"] == 0 and not data["timed_out"] and not data["thread_error"]
    assert not data["enters_accepted_throughput_statistics"]
    valid_gpu = [row for row in data["samples"] if row["gpu_dedicated_available"]]
    assert valid_gpu
    arms[arm] = dict(samples=len(data["samples"]),
        successful_gpu_samples=data["successful_gpu_samples"],
        actual_sample_gap_ms=data["actual_sample_gap_ms"],
        max_observed_bytes=data["max_observed_bytes"],
        os_lifetime_high_water_observed_bytes=data["os_lifetime_high_water_observed_bytes"],
        dedicated_first_last_available_bytes=[valid_gpu[0]["gpu_dedicated_bytes"], valid_gpu[-1]["gpu_dedicated_bytes"]],
        source=dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
helper = S.parent / "qwen-gpu-comparison/memory-probe/memory_probe.py"
assert hashlib.sha256(helper.read_bytes()).hexdigest() == "e4897f9eea8029c179a085c73dada38135a3c750d2fb02a629498316dd294bc4"
shutil.copyfile(helper, out / "retained_api_helper.py")
report = dict(passed=True, platform="Windows WDDM, PSAPI and persistent per-PID PDH Dedicated/Shared counters",
    sampled_model_processes=2, requested_interval_ms=40,
    enters_accepted_throughput_statistics=False, arms=arms,
    limits=["GPU numbers are maxima observed by Windows attribution counters, not instantaneous true peaks, CUDA allocator totals, reserved bytes or card-wide usage.",
        "OS working-set/commit high water is separately labeled; private commit is not physical resident CPU memory. Do not sum these columns with GPU usage.",
        "PDH refresh can lag the requested interval; null PID instances remain unavailable rather than zero.",
        "Whole fixed128+31 process sampled once per implementation; exact load/prefill/decode phase boundaries are not independently synchronized.",
        "No timings from sampled runs enter the accepted unprofiled nine-process window."])
(out / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({arm: {key: round(value / 2**30, 4) for key, value in data["max_observed_bytes"].items()}
                  for arm, data in arms.items()}, ensure_ascii=False))
