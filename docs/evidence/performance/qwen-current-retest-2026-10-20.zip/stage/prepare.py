"""Read retained link/dependency records and prepare one-main, zero-CUDA increment."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('qwen_retest_cache', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
OLD = A / 'view-projection-reuse/checks/20261019T191627'
CURRENT = A / 'fp8-shared-prologue/checks/host1'


def logical_source(row):
    text = row['source_path'].replace('\\', '/')
    if '/src/ggml-cuda/' in text:
        return 'ggml-cuda/' + text.rsplit('/src/ggml-cuda/', 1)[1]
    path = Path(row['source_path'])
    return str(path.relative_to(ROOT)).replace('\\', '/') if path.is_relative_to(ROOT) else text


def main():
    paths = {'qwen': OLD / 'qwen-link-plan.json',
             'bf16': A / 'bf16-grouped-bank/checks/native1/tests-link-plan.json',
             'current': CURRENT / 'tests-link-plan.json'}
    plans = {name: c.read(path) for name, path in paths.items()}
    metadata = h.metadata(plans)
    before = plans['qwen']
    current = plans['current']
    def owner(item):
        return metadata.get(c.key(item['path']))
    removed = []
    for item in current['inputs']:
        row = owner(item)
        if Path(item['path']).name in ('gtest.lib', 'gtest_main.lib') or (
                row and Path(row['source_path']).is_relative_to(ROOT / 'tests')):
            removed.append(item)
    assert len(removed) == 8
    main_item = next(item for item in before['inputs'] if Path(item['path']).name == '29-qwen35_text-main.obj')
    main_recipe = owner(main_item)
    assert b.identity(ROOT / 'tools/qwen35_text/main.cc') == main_recipe['source']
    removed_keys = {c.key(item['path']) for item in removed}
    retained = [item for item in current['inputs'] if c.key(item['path']) not in removed_keys]
    assert len(retained) + 1 == 135
    missing = [item['path'] for item in [*retained, main_item] if not Path(item['path']).is_file()]
    assert not missing, missing
    old_by_source = {logical_source(owner(item)): item for item in before['inputs'] if owner(item)}
    replacements, additions = [], []
    for item in retained:
        row = owner(item)
        if not row:
            continue
        logical = logical_source(row)
        previous = old_by_source.get(logical)
        record = {'source': logical, 'object': item, 'receipt': row['recipe']}
        if previous and c.key(previous['path']) != c.key(item['path']):
            replacements.append({**record, 'old_object': previous})
        elif previous is None:
            additions.append(record)
    main_dependencies = c.read(next(main_recipe['command'][i+1] for i, arg in enumerate(main_recipe['command'])
                                    if arg.lower() == '/sourcedependencies'))['Data']['Includes']
    recorded = {c.key(item['path']): item for item in main_recipe['dependencies']}
    changed_main_headers = []
    for path in main_dependencies:
        member = Path(path)
        if member.is_relative_to(ROOT / 'include') or member.is_relative_to(ROOT / 'src'):
            prior = recorded.get(c.key(path))
            if prior and b.identity(member)['sha256'] != prior['sha256']:
                changed_main_headers.append(str(member))
    assert {Path(path).name for path in changed_main_headers} == {'model_ops.h', 'low_precision.h'}
    old_image = c.read(OLD / 'qwen-image.json')
    peer_image = c.read(A / 'cuda-explicit-rope/performance-prepared/peer-image.json')
    assert old_image['sha256'] == 'fc3638f3eec256eb25a5aa4ac3893484b72360655d53f9a5181e787e5a2100b5'
    assert peer_image['sha256'] == 'fb169f0282f2a834a61b3e887edaba92d8699814558b0c5f1a13aaf07e0de969'
    for item in (old_image, peer_image):
        assert b.same(item), item['path']
    reference = A / 'batch-graph-capture/correctness-final/trace'
    vectors = [path for path in reference.rglob('*') if path.suffix in ('.bf16', '.f32')]
    assert len(vectors) == 64
    # Read Ninja's retained dependency database; -t deps never builds a target.
    unresolved = []
    changed = set()
    for path in (A / 'cuda-version-route/source-freeze.json', A / 'fp8-shared-prologue/native-source-freeze.json'):
        for row in c.read(path)['files']:
            changed.add(c.key(ROOT / (row.get('source') or row['path'])))
    changed |= {c.key(ROOT / path) for path in ('src/compute_provider_ggml_cuda/program.h',
        'src/graph_route_cuda/mapped_native_region.h', 'src/graph/executable.cc',
        'include/hyle/compute/model_ops.h', 'include/hyle/compute/low_precision.h')}
    for item in retained:
        if Path(item['path']).suffix.lower() != '.obj' or owner(item):
            continue
        path = Path(item['path'])
        relative = str(path.relative_to(ROOT / '.scratch/b-cuda-d5'))
        run = subprocess.run(['ninja', '-C', str(ROOT / '.scratch/b-cuda-d5'), '-t', 'deps', relative],
                             text=True, capture_output=True, check=True)
        dependencies = [line.strip() for line in run.stdout.splitlines()[1:] if line.startswith('    ')]
        assert dependencies and '(VALID)' in run.stdout.splitlines()[0]
        hits = [path for path in dependencies if c.key(path) in changed]
        assert not hits, hits
        unresolved.append({'object': item, 'actual_dependency_source': 'Ninja -t deps',
            'dependency_count': len(dependencies), 'changed_file_hits': hits,
            'product_dependencies': [path for path in dependencies if Path(path).is_relative_to(ROOT / 'src')
                                     or Path(path).is_relative_to(ROOT / 'include')],
            'limitation': 'No full original per-object source/header hash receipt; the exact accepted object is retained unchanged and current changed-source/header set is absent from its actual dependencies.'})
    command = [arg for arg in current['command'] if c.key(arg) not in removed_keys
               and not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    source_files = [row['source'] for row in c.read(CURRENT / 'plan.json')['compile']
                    if Path(row['source']['path']).is_relative_to(ROOT / 'src')]
    source_files += [main_recipe['source'], b.identity(ROOT / 'include/hyle/compute/model_ops.h'),
                     b.identity(ROOT / 'include/hyle/compute/low_precision.h')]
    result = {'status': 'prepared_not_built', 'base_current_link_plan': str(paths['current']),
        'old_qwen_link_plan': str(paths['qwen']), 'bf16_link_plan': str(paths['bf16']),
        'base_command_without_output_or_tests': command, 'retained_inputs': retained,
        'main_recipe': {'command': main_recipe['command'], 'source': main_recipe['source'],
                        'old_object': main_item, 'receipt': main_recipe['recipe']},
        'fresh_host_TUs': 1, 'fresh_CUDA_TUs': 0, 'SDK_build': False,
        'reason_main_refresh': changed_main_headers, 'main_source_unchanged_and_uninstrumented': True,
        'replacements_since_last_qwen': replacements, 'additions_since_last_qwen': additions,
        'removed_old_product': [item for item in before['inputs'] if owner(item) and
            logical_source(owner(item)) == 'src/compute_route_cuda/best_of.cc'],
        'removed_test_only_inputs_from_current_closure': removed,
        'retained_old_image': old_image, 'retained_llama_image': peer_image,
        'source_fingerprints': source_files, 'unresolved_original_native_receipt_boundary': unresolved,
        'reference_vectors': 64, 'planned_link_inputs': 135,
        'limits': ['Uses the accepted current product link closure, not a rebuilt SDK.',
            'Only actual sourceDependencies/-MF membership decides header ownership; aggregate receipt union is not a rebuild request.',
            'Original link libraries may contain unused old members; selected current explicit objects override the actual product owners, as in the accepted tests closure.',
            'Same-source BF16 weights and unchanged Hyle precision; Hyle/reference intermediate precision and load/prepare sub-boundaries remain different.',
            'Prepare and Ninja dependency inspection execute no compiler, linker or model.']}
    c.save(S / 'retest-plan.json', result)
    print('QWEN_RETEST_PREPARED', {'fresh_host': 1, 'fresh_CUDA': 0, 'inputs': 135,
          'replacements': len(replacements), 'additions': len(additions), 'old_native_receipts_bounded': len(unresolved)})


if __name__ == '__main__':
    main()
