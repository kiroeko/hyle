"""Use the retained fixed128+31, exact64-observation runner on the new same-main image."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qwen_retest_correctness', S.parent / 'view-projection-reuse/run_model.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
r.STAGE = S
r.ARCH = S.parent
r.ROOT = S.parent.parents[1]
if __name__ == '__main__':
    r.main()
