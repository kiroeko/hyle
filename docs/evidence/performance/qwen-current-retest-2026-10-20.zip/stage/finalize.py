"""Publish the actual same-main model regression and rotated measurement window."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location("qwen_retest_publication", S / "build.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
build = S / "checks/main1"
plan = c.read(build / "plan.json")
assert c.read(build / "summary.json")["passed"]
for row in plan["frozen"]:
    assert b.same(row), row["path"]
for row in c.read(build / "qwen-link-plan.json")["inputs"]:
    assert b.same(row), row["path"]
image = c.read(build / "qwen-image.json")
assert b.same(image)
numerical = c.read(S / "correctness/summary.json")
assert numerical["passed"] and numerical["observation"]["equal_vectors"] == 64
rotation = c.read(S / "performance-rotation/summary.json")
assert rotation["terminal_zero"] == 9 and rotation["same_baseline_predictions_all9"]
assert not rotation["profiler"] and not rotation["external_memory_monitor"]
first = c.read(S / "performance-rotation/01-baseline.result.json")
last = c.read(S / "performance-rotation/09-baseline.result.json")
zone = dt.timezone(dt.timedelta(hours=8))
window = {key: dt.datetime.fromtimestamp(value, zone).isoformat()
          for key, value in (("start", first["started"]), ("end", last["finished"]))}
inventory = c.read(S / "retest-plan.json")
table = {arm: {name: values["median"] for name, values in group.items()
               if isinstance(values, dict) and "median" in values}
         for arm, group in rotation["groups"].items()}
products = ["tools/qwen35_text/main.cc", "include/hyle/compute/model_ops.h",
    "include/hyle/compute/low_precision.h", "docs/developer/current-work.md",
    "docs/implementation/model-operators.md", "docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md"]
c.execute("diff-check", ["git", "diff", "--check", "--", *products], dict(os.environ), S)
report = dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(), window_beijing=window,
    scope="Qwen3.5-2B full CUDA, original BF16 consumer; fixed128-token prefill and31 fixed decode inputs, no MTP or multimodal",
    result="Current product closure executes all64 retained hidden/logits observations byte-identically, then completes nine fresh unprofiled rotated old/current/llama processes",
    current_image=image,
    actual_build=dict(fresh_CXX_owners=1, fresh_CUDA_owners=0, SDK_builds=0,
        links=1, inputs=135, main_source_unchanged_and_uninstrumented=True,
        cached_owner_replacements=len(inventory["replacements_since_last_qwen"]),
        cached_owner_additions=len(inventory["additions_since_last_qwen"]),
        removed="Retired best-of CUDA wrapper object and all test-only inputs",
        original_native_receipt_limit=inventory["unresolved_original_native_receipt_boundary"]),
    correctness=numerical, performance=rotation, median_table=table,
    interpretation=dict(
        warm_vs_last_accepted_percent=100*(rotation["current_over_baseline"]["warm7_31_tokens_per_second"]-1),
        full_vs_last_accepted_percent=100*(rotation["current_over_baseline"]["full31_tokens_per_second"]-1),
        warm_below_llama_percent=100*(1-rotation["current_over_llama"]["warm7_31_tokens_per_second"]),
        full_below_llama_percent=100*(1-rotation["current_over_llama"]["full31_tokens_per_second"]),
        observed="Warm current process medians do not overlap old process medians in this window; full31 and prefill ranges overlap. Three processes do not establish long-run significance.",
        attribution="This retests accumulated accepted product changes, not an isolated optimization. FP8 sharing and grouped MoE are not executed by this BF16 dense model.",
        precision_and_load="Same-source weights/input; Hyle BF16 intermediate math and reference F32 decode differ. Weight/model loading and shape/context preparation are different sub-boundaries; compare reported TTFT and whole-step metrics with that limitation."),
    next_investigation=dict(source_review="hot-prepare-review.json",
        lead="Region input lease lookup scans every episode binding for each native input port; count current B/R/P before changing the algorithm.",
        performance_claim=False),
    memory="No external memory monitor in the throughput rotation; any separate memory observation is independently labeled below.",
    not_claimed=["No independent language-model quality acceptance from matching retained observations or greedy IDs.",
        "No new whole-model physical kernel trace in this retest.",
        "No total GPU/CPU instantaneous peak, long-run state validation or other models/platforms/mixed modes from this run.",
        "No per-function cause for the prefill/shape-preparation differences or guaranteed remaining speedup."],
    evidence=dict(stage=str(S), source_and_command_archive="qwen-current-retest-2026-10-20.zip",
        source_snapshots="One unchanged consumer main refreshed against current public descriptors; exact cached owner mapping/commands and input hashes retained. Earlier product-source batches remain in their existing archives.",
        reproduce=["python .scratch/architecture-refactor-2026-10-18/qwen-current-retest/build.py --build",
            "python .scratch/architecture-refactor-2026-10-18/qwen-current-retest/run_model.py .scratch/architecture-refactor-2026-10-18/qwen-current-retest/checks/main1/plan.json",
            "python .scratch/architecture-refactor-2026-10-18/qwen-current-retest/compare.py --build-plan .scratch/architecture-refactor-2026-10-18/qwen-current-retest/checks/main1/plan.json",
            "python .scratch/architecture-refactor-2026-10-18/qwen-current-retest/compare.py --run"],
        reproduction_limit="Scripts deliberately refuse overwriting completed output directories; choose a fresh destination or reconstruct the retained exact commands. SDKs, model weights and all cached object bytes are not duplicated in the evidence archive."),
    goal="Active; full architecture, model/operator/quantization and cross-platform lifecycle requirements remain")
memory = S / "memory-probe/summary.json"
if memory.is_file():
    report["separate_memory_observation"] = c.read(memory)
c.save(S / "summary.json", report)
public = ROOT / "docs/evidence/performance/qwen-current-retest-2026-10-20.json"
archive = public.with_suffix(".zip")
assert not archive.exists()
files = {}
ignored = {".exe", ".obj", ".lib", ".exp", ".pdb", ".map", ".pyc", ".bf16", ".f32"}
for path in S.rglob("*"):
    relative = path.relative_to(S)
    if (not path.is_file() or path.suffix.lower() in ignored or
        any(part in {"tmp", "lease-probe"} for part in relative.parts) or
        path.name in {"metadata-inventory.json", "archive-manifest.json", "publication.json"}):
        continue
    files["stage/" + relative.as_posix()] = path
for name in products:
    files["product/" + name] = ROOT / name
manifest = [dict(name=name, bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name, path in sorted(files.items())]
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr("manifest.json", json.dumps(dict(payloads=manifest,
        excluded="SDK/model/cache binaries, maps, duplicate observation vectors,20MB rebuildable metadata scan and in-progress separate lease probe"), ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        payload = z.read(row["name"])
        assert len(payload) == row["bytes"] and hashlib.sha256(payload).hexdigest() == row["sha256"]
receipt = dict(archive=b.identity(archive), payload_count=len(manifest), CRC_checked=True, all_payload_SHA256_checked=True)
c.save(S / "archive-manifest.json", dict(payloads=manifest, receipt=receipt))
report["evidence"].update(receipt)
c.save(public, report)
c.save(S / "publication.json", dict(report=b.identity(public), **receipt))
print("QWEN_CURRENT_RETEST_PUBLISHED", receipt["archive"]["bytes"], "bytes", len(manifest), "payloads", flush=True)
