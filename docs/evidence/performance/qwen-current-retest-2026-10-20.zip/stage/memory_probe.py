"""Bounded external Windows memory observation; default probes counters only, never starts a model.

--run current|llama starts exactly one retained command, outside throughput statistics.
PSAPI and a persistent PDH query are initialized before process creation. No CUDA/NVML
library, nvidia-smi process, SDK or third-party Python package is used.
"""
from pathlib import Path
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
import os
import statistics
import subprocess
import sys
import time
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parent.parents[1]
HELPER = S.parent / 'qwen-gpu-comparison/memory-probe/memory_probe.py'
HELPER_SHA = 'e4897f9eea8029c179a085c73dada38135a3c750d2fb02a629498316dd294bc4'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def counter_inventory(probe, key):
    """Read current wildcard availability, without opening a GPU context or another process."""
    size, count = wintypes.DWORD(), wintypes.DWORD()
    status = probe._pdh.PdhGetFormattedCounterArrayW(probe._counters[key], 0x400,
        ctypes.byref(size), ctypes.byref(count), None)
    if (int(status) & 0xffffffff) != 0x800007d2:
        return {'status': f'0x{int(status) & 0xffffffff:08x}', 'instances': None}
    buffer = ctypes.create_string_buffer(size.value + 4096)
    size = wintypes.DWORD(len(buffer))
    status = probe._pdh.PdhGetFormattedCounterArrayW(probe._counters[key], 0x400,
        ctypes.byref(size), ctypes.byref(count), buffer)
    return {'status': f'0x{int(status) & 0xffffffff:08x}',
            'instances': count.value if status == 0 else None}


def probe_only(module, interval):
    with module.MemoryProbe(interval_s=interval) as probe:
        probe.attach(os.getpid())
        for _ in range(3):
            probe.sample()
            time.sleep(interval)
        counters = {key: counter_inventory(probe, key) for key in probe._counters}
        probe.stop()
        result = probe.result()
    report = {'mode': 'read_only_counter_probe_no_model', 'model_processes_started': 0,
        'helper_sha256': HELPER_SHA, 'requested_interval_ms': interval * 1000,
        'psapi_successful_samples': sum(row['psapi_available'] for row in result['samples']),
        'pdh_setup_error': result['gpu_setup_error'], 'wildcard_counters': counters,
        'own_CPU_only_process_missing_GPU_is_null': all(row['gpu_total_bytes'] is None for row in result['samples']),
        'sample_duration_ms': [row['sample_duration_ns'] / 1e6 for row in result['samples']],
        'limits': ['A populated wildcard counter is usable on this Windows system; no new model or CUDA context was started.',
            'This CPU-only probe does not prove a future CUDA PID instance will appear or update at40ms.',
            'Missing PID instances remain unavailable/null, never measured zero.']}
    save(S / 'memory-counter-probe.json', report)
    print(json.dumps(report, ensure_ascii=False))


def observe(module, arm, interval, timeout):
    runner = load('qwen_external_memory_runtime', S / 'compare.py')
    plan = runner.c.read(S / 'performance-prepared/plan.json')
    assert runner.c.read(S / 'performance-rotation/summary.json')['status'] == 'nine_fresh_unprofiled_processes_terminal_zero'
    out = S / ('memory-' + arm)
    out.mkdir(exist_ok=False)
    request = next(row for row in plan['requests'] if row['arm'] == arm)
    command = [arg.replace('{output}', str(out)) for arg in request['command']]
    assert '--trace' not in command
    runner.r.require_same(plan['images'][arm])
    build = runner.c.read(plan['build_plan']['path'])
    peer = runner.c.read(runner.r.PEER_PLAN)
    env, runtime = runner.runtime_environment(build, peer, out)
    save(out / 'inputs.json', {'arm': arm, 'command': command, 'image': plan['images'][arm],
        'helper_sha256': HELPER_SHA, 'requested_interval_ms': interval * 1000,
        'max_process_seconds': timeout, 'runtime': runtime,
        'memory_observation_only': True, 'enters_accepted_throughput_statistics': False})
    with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        with module.MemoryProbe(interval_s=interval) as memory:
            started_ns = time.perf_counter_ns()
            process = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr, env=env)
            timed_out = False
            try:
                memory.start(process.pid)
                try:
                    code = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    process.terminate()
                    try:
                        code = process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        code = process.wait(timeout=5)
            finally:
                if process.poll() is None:
                    process.kill()
                    process.wait(timeout=5)
                memory.stop()
            data = memory.result()
            finished_ns = time.perf_counter_ns()
    peaks = data.pop('peaks')
    samples = data['samples']
    gaps = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(samples, samples[1:])]
    data.update(arm=arm, command=command, exit=code, timed_out=timed_out,
        process_start_monotonic_ns=started_ns, process_wait_return_monotonic_ns=finished_ns,
        memory_observation_only=True, enters_accepted_throughput_statistics=False,
        max_observed_bytes={'cpu_working_set': peaks['sampled_max_working_set_bytes'],
            'cpu_private_commit': peaks['sampled_max_private_commit_bytes'],
            'gpu_dedicated': peaks['sampled_peak_gpu_dedicated_bytes'],
            'gpu_shared': peaks['sampled_peak_gpu_shared_bytes'],
            'gpu_dedicated_plus_shared': peaks['sampled_peak_gpu_total_bytes']},
        os_lifetime_high_water_observed_bytes={'working_set': peaks['observed_os_peak_working_set_bytes'],
            'commit_charge': peaks['observed_os_peak_commit_bytes']},
        actual_sample_gap_ms={'min': min(gaps), 'median': statistics.median(gaps), 'max': max(gaps)} if gaps else None,
        successful_gpu_samples={key: sum(row['gpu_' + key + '_available'] for row in samples)
                                for key in ('dedicated', 'shared')})
    data['limits'] += ['PDH refresh cadence/driver attribution can lag the requested sampling interval.',
        'Max observed GPU usage is not an instantaneous true peak, CUDA allocation/reservation total or card-wide VRAM.',
        'This extra sampled run is separate from, and cannot replace or enter, the accepted nine-process throughput statistics.']
    save(out / 'samples.json', data)
    print(json.dumps({'arm': arm, 'exit': code, 'timed_out': timed_out,
        'sample_count': len(samples), 'max_observed_bytes': data['max_observed_bytes'],
        'os_lifetime_high_water_observed_bytes': data['os_lifetime_high_water_observed_bytes'],
        'gpu_setup_error': data['gpu_setup_error'], 'thread_error': data['thread_error'],
        'result': str(out / 'samples.json')}, ensure_ascii=False))
    if code != 0 or timed_out or data['thread_error']:
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--probe', action='store_true', help='Read local counters only; also the default.')
    parser.add_argument('--run', choices=('current', 'llama'))
    parser.add_argument('--interval-ms', type=int, default=40)
    parser.add_argument('--max-seconds', type=int, default=120)
    args = parser.parse_args()
    if os.name != 'nt' or not 20 <= args.interval_ms <= 50 or not 1 <= args.max_seconds <= 300:
        parser.error('Windows required; interval20..50ms, timeout1..300s.')
    if args.probe and args.run:
        parser.error('Choose counter probe or one model observation.')
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA
    module = load('qwen_retained_windows_memory_api', HELPER)
    if args.run:
        observe(module, args.run, args.interval_ms / 1000, args.max_seconds)
    else:
        probe_only(module, args.interval_ms / 1000)
