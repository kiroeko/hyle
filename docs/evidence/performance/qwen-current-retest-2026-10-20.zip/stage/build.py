"""Prepare by default; --build compiles the unchanged Qwen main once and links current cached owners."""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('qwen_retest_prepare', S / 'prepare.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
b, c = p.b, p.c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    if not args.build:
        p.main()
        return
    receipt = c.read(S / 'retest-plan.json')
    out = S / 'checks/main1'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    for item in receipt['source_fingerprints']:
        assert b.same(item), item['path']
    assert all(b.same(item) for item in receipt['retained_inputs'])
    source = Path(receipt['main_recipe']['source']['path'])
    assert b.same(receipt['main_recipe']['source'])
    command = b.host_command(receipt['main_recipe']['command'], source, 'qwen-main', out)
    image = out / 'qwen.exe'
    link_command = receipt['base_command_without_output_or_tests'].copy()
    link_command.insert(1, str(out / 'qwen-main.obj'))
    link_command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                     '/IMPLIB:' + str(image.with_suffix('.lib'))]
    link_inputs = [arg for arg in link_command if Path(arg).is_absolute()
                   and Path(arg).suffix.lower() in ('.obj', '.lib')]
    assert len(link_inputs) == len(set(map(c.key, link_inputs))) == 135
    plan = {'compile': [{'tag': 'qwen-main', 'command': command, 'source': b.identity(source)}],
        'links': {'qwen': {'command': link_command, 'inputs': link_inputs, 'image': str(image)}},
        'frozen': receipt['source_fingerprints'] + [b.identity(S / 'retest-plan.json'), b.identity(Path(__file__))],
        'host_TUs': 1, 'native_TUs': 0, 'SDK_rebuild': False, 'main_instrumented': False}
    c.save(out / 'plan.json', plan)
    snapshot = out / 'compiled-source/tools/qwen35_text/main.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    env, runtime = b.environment(link_command, [item['path'] for item in receipt['retained_inputs']], out)
    c.save(out / 'runtime-environment.json', {'runtime': runtime, 'unrelated_CPU_closure_union': False})
    c.execute('qwen-main-compile', command, env, out)
    dep = c.read(out / 'qwen-main-deps.json')['Data']
    main_object = b.identity(out / 'qwen-main.obj')
    c.save(out / 'qwen-main-identity.json', {'command': command, 'source': b.identity(source),
        'object': main_object, 'dependencies': [b.identity(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]})
    for item in plan['frozen']:
        assert b.same(item), item['path']
    c.execute('qwen-link', link_command, env, out)
    lookup = {c.key(item['path']): item for item in [*receipt['retained_inputs'], main_object]}
    c.save(out / 'qwen-link-plan.json', {'command': link_command,
        'inputs': [lookup[c.key(path)] for path in link_inputs]})
    c.save(out / 'qwen-image.json', b.identity(image))
    c.save(out / 'summary.json', {'passed': True, 'host_TUs': 1, 'native_TUs': 0,
        'SDK_rebuild': False, 'main_source_unchanged': True, 'main_instrumented': False})
    print('QWEN_RETEST_BUILT', out / 'plan.json', flush=True)


if __name__ == '__main__':
    main()
