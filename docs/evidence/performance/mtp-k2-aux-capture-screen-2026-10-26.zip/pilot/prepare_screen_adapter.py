"""Write/parse a retained-protocol adapter. Never execute that adapter here."""
from pathlib import Path
import ast
import hashlib
import json

W=Path(__file__).resolve().parent
R=W.parents[1]
original=R/'.scratch/mtp-m2-typed-mmf-20261026/consumer/screen.py'
text=original.read_text()
def replace(a,b):
    global text
    assert text.count(a)==1,a
    text=text.replace(a,b)
replace('import importlib.util\n','import importlib.util\nimport difflib\nimport inspect\nimport re\n')
replace('helpers = m.helpers()','''helpers = m.helpers()
# Keep the original PSAPI/PDH/reader/marker path; only narrow its watchdog.
execute_source = inspect.getsource(helpers.execute)
assert execute_source.count('process.wait(timeout=900)') == 1
execute_source = execute_source.replace('process.wait(timeout=900)', 'process.wait(timeout=120)')
execute_globals = dict(helpers.execute.__globals__)
exec(compile(execute_source, inspect.getsourcefile(helpers.execute), 'exec'), execute_globals)
helpers.execute = execute_globals['execute']''')
replace("control, candidate = read(C / 'ready-current.json'), read(W / 'attempt1/ready.json')", "control, candidate = read(C / 'ready-current.json'), read(W / 'ready.json')")
replace("original = read(C / 'full-window/two-turn-timing/02-hyle_mtp/command.json')['command']", "source_command = R / '.scratch/mtp-performance-convergence-20261025/k2-exploration/run1/command.json'\noriginal = read(source_command)['command']\nassert original[original.index('--mtp-max-drafts') + 1] == '2'\nassert images['control']['sha256'] == '2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'\nassert images['candidate']['sha256'] == 'bed123d596a154ab815e394a499f5ee80a83255c65b1f580a53aa5f332d5e4fb'")
replace("    candidate_ready=pin(W / 'attempt1/ready.json'), runtime=pin(C / 'runtime-current.json'),", "    candidate_ready=pin(W / 'ready.json'), runtime={\n        'control':pin(C / 'runtime-current.json'), 'candidate':pin(W / 'runtime.json')},")
replace("    independent_review=pin(W / 'independent-review-architecture.json'),\n    original_command=pin(C / 'full-window/two-turn-timing/02-hyle_mtp/command.json'),", "    behavior=pin(W / 'final-summary.json'),\n    original_command=pin(source_command),\n    non_time_reference=pin(W / 'behavior/control/report.json'),\n    timeout_seconds=120, retained_execute=pin(Path(inspect.getsourcefile(helpers.execute))),")
replace("    SDK_builds=0, HTTP=0, reference='First actual current control, no old report.',", "    SDK_builds=0, HTTP=0, reference='Original2a94 behavior report is a strict non-time oracle only; all timing/memory samples are new, no pooling.',")
replace("scope='Bounded current2a94 vs private31e189 exact-M2 typed-MMF Hyle K1 two-turn screen; first pair '", "scope='Bounded current2a94 vs privatebed123 auxiliary capture Hyle K2 two-turn screen; every process '")
replace("results, memories, baseline = [], {}, None", '''results, memories = [], {}
baseline = normalize(read(W / 'behavior/control/report.json'))
allowed_warmup = {
    'ggml_backend_cuda_graph_compute: CUDA graph warmup complete',
    'ggml_backend_cuda_graph_compute: CUDA graph warmup reset',
}
expected_pilot = read(W / 'final-summary.json')['actual_capture']
def stderr_facts(path, arm):
    kept, pilot, counts = [], [], {line:0 for line in sorted(allowed_warmup)}
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    for index, line in enumerate(lines):
        if line in allowed_warmup:
            counts[line] += 1
            continue
        if line.startswith('K2_AUX_CAPTURE_PILOT '):
            assert arm == 'candidate' and index == len(lines) - 1, 'Pilot must be one final candidate-only POD line'
            pod = json.loads(line.split(' ', 1)[1])
            assert set(pod) == set(expected_pilot)
            assert all(type(v) is int and v >= 0 for v in pod.values())
            pilot.append(pod)
            continue
        line = re.sub(r'([A-Za-z0-9_]*(?:seconds|tokens_per_second|clock_unix[A-Za-z0-9_]*|unix_ns|unix_ms)\\s*[=:]\\s*)[-+0-9.eE]+', r'\\1<TIME>', line)
        kept.append(line)
    assert len(pilot) == (1 if arm == 'candidate' else 0)
    return kept, {'exact_allowed_warmup_counts':counts, 'final_pilot_POD':pilot,
                  'pilot_equal_original_behavior':not pilot or pilot[0] == expected_pilot}
stderr_reference, _ = stderr_facts(W / 'behavior/control/stderr.log', 'control')''')
replace("env['PATH'] = str(Path(command[0]).parent) + ';' + read(C / 'runtime-current.json')['PATH']", "runtime_path = C / 'runtime-current.json' if arm == 'control' else W / 'runtime.json'\n            env['PATH'] = str(Path(command[0]).parent) + ';' + read(runtime_path)['PATH']")
replace('''            if baseline is None:
                assert arm == 'control' and mode == 'timing'
                baseline = normalized
                save(O / 'current-control-nontime.json', baseline)
''', '')
replace("            assert not delta, (arm, mode, 'Non-time work or metadata changed; retained exact differences.')", '''            assert not delta, (arm, mode, 'Non-time work or metadata changed; retained exact differences.')
            stderr_actual, stderr_metadata = stderr_facts(folder / 'stderr.log', arm)
            stderr_delta = list(difflib.unified_diff(stderr_reference, stderr_actual,
                fromfile='behavior-control', tofile=folder.name, lineterm=''))
            save(folder / 'stderr-allowed-facts.json', stderr_metadata)
            save(folder / 'stderr-unexpected-differences.json', stderr_delta)
            assert not stderr_delta, 'Unexpected non-time stderr difference; stop without replacement samples'
            assert stderr_metadata['pilot_equal_original_behavior'], 'Capture POD facts changed; stop with original counts retained' ''')
replace("                                source_work_equal=True, metrics=metrics))", "                                source_work_equal=True, stderr_work_equal=True, stderr_facts=stderr_metadata, metrics=metrics))")
replace("            'Private exact dense BF16 M2 K2048 N6144 MMF provider candidate; all other operations original Lt. No canonical merge or peer window.',", "            'Private K2 auxiliary capture Model TU; exact warmup complete/reset counts and final POD retained, all other non-time stderr exact. No canonical merge or peer window.',")
target=W/'screen.py'
assert not target.exists()
ast.parse(text)
target.write_text(text,encoding='utf-8')
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt={'status':'ADAPTER_SOURCE_AST_READY_NOT_EXECUTED','script':pin(target),'retained_source':pin(original),
 'run_command':['python',str(target)],'processes':8,'timing_order':['control','candidate','candidate','control','control','candidate'],
 'memory_order':['control','candidate'],'timeout_each_seconds':120,'new_GPU_runs':0,
 'strict_stdout_oracle':pin(W/'behavior/control/report.json'),
 'stderr_gate':'Named clocks only normalized; exact two allowed warmup texts counted, one final candidate POD required, all other lines exact. POD counts also must match original behavior or stop.'}
(W/'screen-adapter.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
