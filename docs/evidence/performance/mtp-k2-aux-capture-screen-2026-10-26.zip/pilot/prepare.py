"""One private K2 auxiliary replay-policy pilot; no canonical edits."""
from pathlib import Path
import difflib,hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=R/'engine/models/qwen35/main.cc';before=p.read_bytes()
assert hashlib.sha256(before).hexdigest()=='1892e2d13dc7b77cf58043d3099eb59377ea722f540155d64b2de3a4be7ef33c'
text=before.decode('utf-8')
old='  std::size_t draft_program_graph_calls = 0, prefix_decision_graph_calls = 0;\n'
new=old+'  // Private K2 pilot POD facts: eligible, recorded, reused, Commands fallback, noneligible.\n  std::array<std::size_t, 5> pilot_aux_capture{};\n'
assert text.count(old)==1;text=text.replace(old,new)
old='''      check(run.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));
      guard.completion = submit_retained(run, queues, program.retirement); check(guard.completion.wait()); guard.completion = {};'''
new='''      // Private finite K2 experiment only, not a production replay policy.
      const bool pilot_capture = max_drafts() == 2 && ids.size() <= 3 &&
          !default_sampler.enabled && replay_policy != ReplayPolicy::kCommands;
      check(run.prepare_replay(queues, {.mode = pilot_capture ? g::ReplayMode::kPreferCapture
          : g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}));
      if (pilot_capture) {
        const auto report = take(run.replay_report());
        ++pilot_aux_capture[0];
        pilot_aux_capture[1] += report.recorded_capture_range_count;
        pilot_aux_capture[2] += report.reused_capture_range_count;
        pilot_aux_capture[3] += run.replay_route() == g::ReplayRoute::kCommands;
      } else ++pilot_aux_capture[4];
      guard.completion = submit_retained(run, queues, program.retirement); check(guard.completion.wait()); guard.completion = {};'''
assert text.count(old)==1;text=text.replace(old,new)
old='''  const auto graph_calls = cache::add(cache::add(cache::add(actual_prefill_calls, actual_decode_calls), restored.graph_calls),'''
new='''  // One final POD-only diagnostic line after the natural request journey.
  if (model.pilot_aux_capture[0] || model.pilot_aux_capture[4])
    std::cerr << "K2_AUX_CAPTURE_PILOT {\\"eligible_prepares\\":" << model.pilot_aux_capture[0]
        << ",\\"recorded_ranges\\":" << model.pilot_aux_capture[1]
        << ",\\"reused_ranges\\":" << model.pilot_aux_capture[2]
        << ",\\"commands_fallbacks\\":" << model.pilot_aux_capture[3]
        << ",\\"noneligible_commands\\":" << model.pilot_aux_capture[4] << "}\\n";
''' + old
assert text.count(old)==1;text=text.replace(old,new)
after=W/'source/engine/models/qwen35/main.cc';after.parent.mkdir(parents=True,exist_ok=True);after.write_bytes(text.encode())
bp=W/'before/engine/models/qwen35/main.cc';bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before)
patch=''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/engine/models/qwen35/main.cc',tofile='b/engine/models/qwen35/main.cc'))
(W/'source.patch').write_text(patch,encoding='utf-8')
save(W/'source-pins.json',dict(before=pin(bp),canonical=pin(p),after=pin(after),patch=pin(W/'source.patch')))
save(W/'plan.json',dict(scope='Private exact K2 auxiliary replay pilot; only Model TU changed; no production strategy/API.',
 eligibility='max_drafts==2, rows<=3, greedy default sampler, replay policy not Commands',
 unchanged='All original waits, RetainedResources/StepState, repair math, accepted-prefix/head/ledger transaction, original cache and state budgets.',
 diagnostics='Five Model-local POD counters; original replay_report after successful prepare; one final stderr line after natural journey. No per-call IO or new allocation.',
 comparison='Control2a94 then private candidate once each, original K2 two-turn command,120s per process. Compare every non-time stdout fact before classifying any expected replay-metadata difference. New final diagnostic line only in candidate stderr.',
 source=pin(W/'source-pins.json'),builds=dict(Model_TUs=1,other_TUs=0,SDK=0),GPU_processes=2,profiler=False,TPS_claim=False))
print(json.dumps(pin(after)))
