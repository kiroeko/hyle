from pathlib import Path
import datetime
import hashlib
import importlib.util
import difflib
import inspect
import re
import json
import math
import os
import statistics
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = Path(__file__).resolve().parent
B = R / '.scratch/mtp-performance-convergence-20261025/baseline'
C = R / '.scratch/inference-current-closure-20261026'
O = W / 'screen'
spec = importlib.util.spec_from_file_location('retained_screen', B / 'window.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.WORKLOAD = 'two-turn'
helpers = m.helpers()
# Keep the original PSAPI/PDH/reader/marker path; only narrow its watchdog.
execute_source = inspect.getsource(helpers.execute)
assert execute_source.count('process.wait(timeout=900)') == 1
execute_source = execute_source.replace('process.wait(timeout=900)', 'process.wait(timeout=120)')
execute_globals = dict(helpers.execute.__globals__)
exec(compile(execute_source, inspect.getsourcefile(helpers.execute), 'exec'), execute_globals)
helpers.execute = execute_globals['execute']


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p)
    return dict(path=str(p.resolve()), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def normalize(value):
    # Original retained screen's clock exclusions, unchanged. No cache,
    # capture, state, work or other metadata exclusions are introduced.
    if isinstance(value, list):
        return [normalize(x) for x in value]
    if isinstance(value, dict):
        return {k: normalize(x) for k, x in value.items()
                if not any(t in k for t in
                           ['seconds', 'tokens_per_second', 'clock_unix',
                            'unix_ns', 'unix_ms'])}
    return value


def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, control=a, candidate=b)]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append(dict(path=path + '.' + key,
                                   control=a.get(key), candidate=b.get(key)))
            else:
                result.extend(differences(a[key], b[key], path + '.' + key))
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [dict(path=path, control_length=len(a), candidate_length=len(b))]
        return [row for i, (x, y) in enumerate(zip(a, b))
                for row in differences(x, y, f'{path}[{i}]')]
    return [] if a == b else [dict(path=path, control=a, candidate=b)]


def report(p):
    return json.loads(next(x for x in reversed(p.read_text(encoding='utf8').splitlines())
                           if x.startswith('{')))


def stats(values):
    return dict(count=len(values), median=statistics.median(values),
                min=min(values), max=max(values), samples=values)


control, candidate = read(C / 'ready-current.json'), read(W / 'ready.json')
images = dict(control=control['image'], candidate=candidate['image'])
for image in images.values():
    assert pin(image['path'])['sha256'] == image['sha256']
source_command = R / '.scratch/mtp-performance-convergence-20261025/k2-exploration/run1/command.json'
original = read(source_command)['command']
assert original[original.index('--mtp-max-drafts') + 1] == '2'
assert images['control']['sha256'] == '2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
assert images['candidate']['sha256'] == 'bed123d596a154ab815e394a499f5ee80a83255c65b1f580a53aa5f332d5e4fb'
inputs = Path(original[original.index('--inputs') + 1])
schedule = Path(original[original.index('--schedule') + 1])
assert not O.exists(), 'Keep previous runs; never overwrite or pool a screen.'
O.mkdir()
order = ['control', 'candidate', 'candidate', 'control', 'control', 'candidate']
save(O / 'plan.json', dict(
    created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    timing_order=order, memory_order=['control', 'candidate'], images=images,
    candidate_ready=pin(W / 'ready.json'), runtime={
        'control':pin(C / 'runtime-current.json'), 'candidate':pin(W / 'runtime.json')},
    source_review=pin(W / 'source-pins.json'),
    behavior=pin(W / 'final-summary.json'),
    original_command=pin(source_command),
    non_time_reference=pin(W / 'behavior/control/report.json'),
    timeout_seconds=120, retained_execute=pin(Path(inspect.getsourcefile(helpers.execute))),
    schedule=pin(schedule),
    inputs=[pin(inputs / n) for n in ['weights.tsv', 'prompt.ids', 'input.json']],
    retained_screen=pin(R / '.scratch/mtp-native-seed-candidate-20261025/screen.py'),
    retained_memory_and_marker_helper=pin(B / 'window.py'),
    memory_interval_seconds=0.01, profiler=False, warmup=False,
    SDK_builds=0, HTTP=0, reference='Original2a94 behavior report is a strict non-time oracle only; all timing/memory samples are new, no pooling.',
    scope='Bounded current2a94 vs privatebed123 auxiliary capture Hyle K2 two-turn screen; every process '
          'is the behavior gate. 3 serial interleaved pairs and1 independent '
          'memory process per arm. Original protocol, no old samples pooled.'))
results, memories = [], {}
baseline = normalize(read(W / 'behavior/control/report.json'))
allowed_warmup = {
    'ggml_backend_cuda_graph_compute: CUDA graph warmup complete',
    'ggml_backend_cuda_graph_compute: CUDA graph warmup reset',
}
expected_pilot = read(W / 'final-summary.json')['actual_capture']
def stderr_facts(path, arm):
    kept, pilot, counts = [], [], {line:0 for line in sorted(allowed_warmup)}
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    for index, line in enumerate(lines):
        if line in allowed_warmup:
            counts[line] += 1
            continue
        if line.startswith('K2_AUX_CAPTURE_PILOT '):
            assert arm == 'candidate' and index == len(lines) - 1, 'Pilot must be one final candidate-only POD line'
            pod = json.loads(line.split(' ', 1)[1])
            assert set(pod) == set(expected_pilot)
            assert all(type(v) is int and v >= 0 for v in pod.values())
            pilot.append(pod)
            continue
        line = re.sub(r'([A-Za-z0-9_]*(?:seconds|tokens_per_second|clock_unix[A-Za-z0-9_]*|unix_ns|unix_ms)\s*[=:]\s*)[-+0-9.eE]+', r'\1<TIME>', line)
        kept.append(line)
    assert len(pilot) == (1 if arm == 'candidate' else 0)
    return kept, {'exact_allowed_warmup_counts':counts, 'final_pilot_POD':pilot,
                  'pilot_equal_original_behavior':not pilot or pilot[0] == expected_pilot}
stderr_reference, _ = stderr_facts(W / 'behavior/control/stderr.log', 'control')
helpers.gpu_snapshot(O, 'before')
try:
    for mode, sequence in [('timing', order), ('memory', ['control', 'candidate'])]:
        for index, arm in enumerate(sequence, 1):
            folder = O / (mode + f'-{index:02}-' + arm)
            command = original.copy()
            command[0] = images[arm]['path']
            env = os.environ.copy()
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            runtime_path = C / 'runtime-current.json' if arm == 'control' else W / 'runtime.json'
            env['PATH'] = str(Path(command[0]).parent) + ';' + read(runtime_path)['PATH']
            print('BEGIN', mode, index, arm,
                  datetime.datetime.now(datetime.timezone.utc).isoformat(), flush=True)
            record = helpers.execute(folder, arm, command, env, mode == 'memory')
            raw = report(folder / 'stdout.log')
            normalized = normalize(raw)
            delta = differences(baseline, normalized)
            save(folder / 'nontime-differences.json', delta)
            assert not delta, (arm, mode, 'Non-time work or metadata changed; retained exact differences.')
            stderr_actual, stderr_metadata = stderr_facts(folder / 'stderr.log', arm)
            stderr_delta = list(difflib.unified_diff(stderr_reference, stderr_actual,
                fromfile='behavior-control', tofile=folder.name, lineterm=''))
            save(folder / 'stderr-allowed-facts.json', stderr_metadata)
            save(folder / 'stderr-unexpected-differences.json', stderr_delta)
            assert not stderr_delta, 'Unexpected non-time stderr difference; stop without replacement samples'
            assert stderr_metadata['pilot_equal_original_behavior'], 'Capture POD facts changed; stop with original counts retained' 
            p, d, s = raw['prefill_seconds'], raw['decode_seconds'], raw['session_seconds']
            assert math.isclose(p + d, s, rel_tol=1e-5, abs_tol=2e-6)
            assert raw['prefill_target_rows'] == 309 and raw['generated_tokens'] == 128
            metrics = dict(prefill_seconds=p, decode_seconds=d, session_seconds=s,
                           prefill_tokens_per_second=309 / p,
                           decode_output_tokens_per_second=126 / d,
                           combined_output_tokens_per_second=128 / s)
            results.append(dict(arm=arm, mode=mode, index=index, exit=record['exit'],
                                folder=folder.relative_to(R).as_posix(),
                                source_work_equal=True, stderr_work_equal=True, stderr_facts=stderr_metadata, metrics=metrics))
            save(O / 'runs.json', results)
            if mode == 'memory':
                memory = read(folder / 'memory-summary.json')
                assert memory['setup_error'] is None and memory['thread_error'] is None
                memories[arm] = dict(
                    path=pin(folder / 'memory-summary.json'),
                    sampled_peaks=memory['sampled_peaks'], sample_count=memory['sample_count'],
                    ready_baseline=memory['ready_baseline'],
                    null_sample_counts={key: sum(row.get(key) is None for row in
                        read(folder / 'memory.json')['samples']) for key in
                        ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
                         'gpu_shared_bytes', 'gpu_total_bytes']},
                    unavailable_reasons=memory['unavailable_reasons'],
                    actual_sample_gaps_ms=memory['actual_sample_gaps_ms'],
                    sample_cost_ms=memory['sample_cost_ms'], phase_windows=memory['phase_windows'])
            print('END', mode, index, arm, flush=True)
finally:
    helpers.gpu_snapshot(O, 'after')

metrics = {arm: {key: stats([x['metrics'][key] for x in results
                            if x['arm'] == arm and x['mode'] == 'timing'])
                  for key in results[0]['metrics']} for arm in images}
comparison = {key: dict(
    candidate_relative_percent=(metrics['candidate'][key]['median'] /
                                metrics['control'][key]['median'] - 1) * 100,
    ranges_overlap=not (metrics['candidate'][key]['min'] > metrics['control'][key]['max'] or
                       metrics['control'][key]['min'] > metrics['candidate'][key]['max']))
    for key in metrics['control']}
summary = dict(
    status='BOUNDED_SCREEN_COMPLETE_ALL_WORK_EQUAL', timing_processes=6,
    independent_memory_processes=2, all_exit0=all(x['exit'] == 0 for x in results),
    source_work_equal=True, metrics=metrics, comparisons=comparison, memory=memories,
    work={key: raw[key] for key in ['generated_tokens', 'actual_graph_calls',
        'prefill_target_rows', 'verified_target_rows', 'actual_target_rows',
        'actual_draft_rows', 'consumed_drafts']},
    historical_samples_pooled=False, latest_llama_comparison=False, profiler=False,
    limits=['3 observations per arm: descriptive medians/ranges only, no fixed clocks.',
            'Original P+D=session endpoints. Decode126 outputs; combined128; prefill309 rows.',
            'Independent1 memory process per arm; PSAPI/PDH maxima are sampled lower bounds.',
            'Private K2 auxiliary capture Model TU; exact warmup complete/reset counts and final POD retained, all other non-time stderr exact. No canonical merge or peer window.',
            'No fault injection or independent hidden tensor readback in this screen.'])
save(O / 'summary.json', summary)
print(json.dumps(dict(metrics=metrics, comparisons=comparison,
                     memory={a: v['sampled_peaks'] for a, v in memories.items()}), indent=2), flush=True)
print('SCREEN_TERMINAL_GPU_RELEASED', flush=True)
