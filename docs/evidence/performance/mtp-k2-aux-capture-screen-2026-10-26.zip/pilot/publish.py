"""Offline publication of the closed, already executed K2 pilot. No model run."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
P = R / 'docs/evidence/performance/mtp-k2-aux-capture-screen-2026-10-26.json'
Z = P.with_suffix('.zip')

def load(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def write(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

decision = load(W / 'screen-decision.json')
behavior = load(W / 'final-summary.json')
screen = load(W / 'screen/summary.json')
assert screen['all_exit0'] and screen['timing_processes'] == 6
assert len(decision['runs']) == 8
files = {}

def add(path, name):
    assert path.is_file(), path
    assert path.suffix.lower() not in {'.obj', '.exe', '.dll', '.lib', '.exp', '.bin'}
    assert name not in files
    files[name] = path

for name in ['plan.json', 'prepare.py', 'source.patch', 'source-pins.json',
             'build.py', 'build-plan.json', 'ready.json', 'runtime.json',
             'link-inputs.json', 'object-map.json', 'run.py', 'final-summary.json',
             'screen.py', 'prepare_screen_adapter.py', 'screen-adapter.json',
             'screen-decision.json', 'publish.py']:
    add(W / name, 'pilot/' + name)
for directory in ['behavior', 'screen', 'compile', 'link/process']:
    for f in sorted((W / directory).rglob('*')):
        if f.is_file() and f.suffix.lower() in {'.json', '.log', '.diff'}:
            add(f, 'pilot/' + f.relative_to(W).as_posix())
control = R / '.scratch/inference-current-closure-20261026'
for name in ['ready-current.json', 'runtime-current.json',
             'link-inputs-current.json', 'object-map-current.json']:
    add(control / name, 'control/' + name)
for name in ['review.json', 'review.py']:
    add(R / '.scratch/mtp-k2-source-review-20261026' / name, 'source-reason/' + name)
retained = {
    'original-k2-command.json': '.scratch/mtp-performance-convergence-20261025/k2-exploration/run1/command.json',
    'baseline-window.py': '.scratch/mtp-performance-convergence-20261025/baseline/window.py',
    'window.py': '.scratch/qwen-mtp-window-20261022/window.py',
    'multiturn_run.py': '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
    'observer.py': '.scratch/shared-execution-20261021/observer.py',
}
for name, relative in retained.items():
    add(R / relative, 'retained/' + name)
manifest = [dict(member=name, **pin(path)) for name, path in sorted(files.items())]
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(Z, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
    archive.writestr('archive/manifest.json', manifest_bytes)
with zipfile.ZipFile(Z) as archive:
    assert archive.testzip() is None
    members = archive.infolist()
archive = dict(**pin(Z), members=len(members),
               logical_bytes=sum(f.file_size for f in members), CRC='PASS')
report = dict(
    status='BEHAVIOR_AND_REPLAY_MECHANISM_PASS_SCREEN_OVERLAP_CLOSED_NOT_MERGED',
    date='2026-10-26',
    decision='Close this private K2 auxiliary capture candidate: decode and combined ranges overlap. No extra samples or product route.',
    scope='Original two-turn K2 work, control2a94 versus privatebed123. No peer comparison, full32 window, new MTP feature or product change.',
    control_image=behavior['control_image'], candidate_image=behavior['candidate_image'],
    source=dict(before_main=load(W / 'source-pins.json')['before'],
                candidate_main=load(W / 'source-pins.json')['after'],
                patch=pin(W / 'source.patch'), pins=pin(W / 'source-pins.json'),
                frozen_boundary='Both images use main1892 baseline and identical cached dependencies. Later canonical CPU-options forwarding is outside both images.'),
    eligibility=behavior['eligibility'],
    unchanged_contract=behavior['unchanged_contract'],
    build=behavior['build'],
    pre_screen_behavior=dict(processes=behavior['model_processes'],
                             complete_stdout_non_time_differences=0,
                             stderr_classification=behavior['comparison']['stderr_expected_only']),
    screen_protocol=dict(timing_processes=6, memory_processes=2,
                         timing_order=['B','C','C','B','B','C'],
                         memory_order=['B','C'], watchdog_seconds=120,
                         all_exit0=True, stdout_non_time_differences=0,
                         unexpected_stderr_differences=0,
                         profiler=False, old_samples_pooled=False),
    screen_processes=decision['runs'],
    replay=behavior['actual_capture'],
    replay_scope='Same143 eligible/78record/65reuse/0fallback/0noneligible in each candidate. Existing ReplayReport counts are not CUDA API capture measurements. Exact warmup logs94complete/15reset for each control and0/0 for each candidate; all other237 timing-normalized stderr lines match.',
    metrics=screen['metrics'], comparisons=screen['comparisons'],
    memory=decision['memory'], work=screen['work'],
    limits=decision['limits'] + [
        'One behavior pair preceded the six timing and two independent memory processes; its wall times are not pooled into timing statistics.',
        'Fixed POD counters execute inside original endpoints. This is not a wholly uninstrumented pilot; its final POD print is after the original endpoints.',
        'ready.json and screen-adapter.json retain pre-run checkpoint status. Actual execution facts are the later behavior and screen receipts.',
        'Observed prefill decrease and tiny single-process sampled VRAM difference do not establish stable causal effects.'
    ],
    HTTP=0, SDK_builds=0, new_core_or_provider_TUs=0,
    source_build_reference='../research/inference-current-source-build-2026-10-26.json',
    archive=archive)
write(P, report)
write(W / 'publication.json', dict(report=pin(P), archive=archive))
print(json.dumps(dict(report=pin(P), archive=archive)))
