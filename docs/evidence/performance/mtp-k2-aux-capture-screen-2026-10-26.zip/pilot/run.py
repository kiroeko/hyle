"""Exactly the authorized control/candidate K2 two-turn behavior pair."""
from pathlib import Path
import difflib,hashlib,importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];B=R/'.scratch/inference-current-closure-20261026'
spec=importlib.util.spec_from_file_location('k2_pair_execute',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
def report(p):return json.loads(next(s for s in reversed(p.read_text(encoding='utf-8-sig').splitlines()) if s.strip().startswith('{')))
def norm(x):
 if isinstance(x,list):return [norm(y) for y in x]
 if isinstance(x,dict):return {k:norm(v) for k,v in x.items() if not any(t in k for t in ['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
 return x
def diff(a,b,p='$'):
 if type(a)!=type(b):return [dict(path=p,control=a,candidate=b)]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:out.append(dict(path=p+'.'+k,control=a.get(k),candidate=b.get(k)))
   else:out.extend(diff(a[k],b[k],p+'.'+k))
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [dict(path=p,control_length=len(a),candidate_length=len(b))]
  return [row for i,(x,y) in enumerate(zip(a,b)) for row in diff(x,y,p+f'[{i}]')]
 return [] if a==b else [dict(path=p,control=a,candidate=b)]
def stderr_lines(p):
 lines=[];facts=[]
 for line in p.read_text(encoding='utf-8-sig').splitlines():
  if line.startswith('K2_AUX_CAPTURE_PILOT '):facts.append(json.loads(line.split(' ',1)[1]));continue
  # Only the same named timing/clock fields omitted by the stdout comparison.
  line=re.sub(r'([A-Za-z0-9_]*(?:seconds|tokens_per_second|clock_unix[A-Za-z0-9_]*|unix_ns|unix_ms)\s*[=:]\s*)[-+0-9.eE]+',r'\1<TIME>',line)
  lines.append(line)
 return lines,facts
base=read(B/'ready-current.json');candidate=read(W/'ready.json')
assert pin(base['image']['path'])==base['image'] and pin(candidate['image']['path'])==candidate['image']
source_command=R/'.scratch/mtp-performance-convergence-20261025/k2-exploration/run1/command.json'
original=read(source_command)['command']
assert original[original.index('--mtp-max-drafts')+1]=='2'
assert original[original.index('--sampling')+1]=='greedy'
summaries=[]
for name,ready,runtime_path in [('control',base,B/'runtime-current.json'),('candidate',candidate,W/'runtime.json')]:
 folder=W/'behavior'/name;runtime=read(runtime_path)
 env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 env['PATH']=str(Path(ready['image']['path']).parent)+os.pathsep+runtime['PATH']
 command=[ready['image']['path'],*original[1:]]
 save(W/'behavior'/f'{name}-plan.json',dict(image=ready['image'],source_command=pin(source_command),runtime=pin(runtime_path),command=command,
   allowed_model_processes=1,timeout_seconds=120,profiler=False,throughput_claim=False))
 try:done=h.execute(command,env,folder,timeout=120)
 except Exception:
  save(W/'behavior/summary.json',dict(status='PROCESS_FAILED_STOPPED_NO_FURTHER_RUN',arm=name,process=read(folder/'process.json'),prior=summaries,GPU_released=True))
  raise
 result=report(folder/'stdout.log');save(folder/'report.json',result)
 summaries.append(dict(arm=name,process=done,image=ready['image'],report=pin(folder/'report.json')))
 save(W/'behavior/runs.json',summaries)
 print('MODEL_TERMINAL',name,done['pid'],done['exit'],flush=True)
a=read(W/'behavior/control/report.json');b=read(W/'behavior/candidate/report.json')
delta=diff(norm(a),norm(b));save(W/'behavior/all-non-time-differences.json',delta)
left,_=stderr_lines(W/'behavior/control/stderr.log');right,facts=stderr_lines(W/'behavior/candidate/stderr.log')
stderr_diff='\n'.join(difflib.unified_diff(left,right,fromfile='control_timing_only_normalized',tofile='candidate_timing_only_normalized'))
(W/'behavior/stderr-timing-only.diff').write_text(stderr_diff,encoding='utf-8')
assert len(facts)==1,'Expected exactly one final private diagnostic line'
save(W/'behavior/capture-facts.json',facts[0])
# No non-time field is discarded or preclassified here. Root/reviewer can
# examine replay/storage metadata differences without hiding state changes.
summary=dict(status='PAIR_EXIT0_FULL_DIFFERENCES_RETAINED',runs=summaries,non_time_differences=len(delta),differences=delta,
 capture_facts=facts[0],stderr_timing_only_equal_except_final_pilot_line=not stderr_diff,
 metrics=[dict(arm=n,generated_tokens=x['generated_tokens'],actual_graph_calls=x['actual_graph_calls'],prefill_graph_calls=x['prefill_graph_calls'],decode_graph_calls=x['decode_graph_calls'],
    draft_program_graph_calls=x['draft_program_graph_calls'],verified_target_rows=x['verified_target_rows'],actual_draft_rows=x['actual_draft_rows'],draft_rounds=x['draft_rounds'],consumed_drafts=x['consumed_drafts']) for n,x in [('control',a),('candidate',b)]],
 limits='One pair is a behavior/capture pilot, not comparative TPS evidence. Frozen2a94/current privatec1 Model source; subsequent CPU-option canonical glue is outside both binaries. All non-time differences above remain visible.',
 GPU_released=True)
save(W/'behavior/summary.json',summary)
print(json.dumps(summary,indent=2))
