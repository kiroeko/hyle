"""Finite offline K2 call-account review; no build/model/native execution."""
from pathlib import Path
import collections,hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 p=Path(p).resolve();b=p.read_bytes()
 return dict(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
source=R/'engine/models/qwen35/main.cc'
old=R/'.scratch/mtp-performance-convergence-20261025/k2-exploration'
raw=old/'run1/normalized-result.json';d=json.loads(raw.read_text())
rounds=d['rounds'];ledger=[r for r in d['sessions'][0]['ledger'] if r['generation']]
assert len(ledger)==len(rounds)==48
proposals=sum(r['proposals'] for r in rounds)
aux=sum(r['auxiliary_graph_calls'] for r in rounds)
lag=sum(r['before_lag'] for r in ledger)
retained=sum(1 if r['accepted']==1 else r['accepted']-1 for r in ledger)
proposal_rows=proposals+lag;repair_rows=retained+lag
assert proposals==95 and aux==143 and proposal_rows+repair_rows==261
assert d['actual_graph_calls']==2+len(rounds)+proposals+len(rounds)==193
memo=dict(status='SOURCE_AND_RETAINED_RAW_CALL_ACCOUNT_CLOSED_NO_NEW_RUN',
 sources=[pin(source),pin(R/'engine/models/qwen35/mtp_graph.h'),pin(R/'engine/models/qwen35/session_state.h'),pin(R/'engine/inference/mtp_acceptance.h')],
 retained_evidence=[pin(raw),pin(old/'exploration-summary.json')],
 actual_old_K2=dict(verifier_rounds=len(rounds),verifier_widths=dict(collections.Counter(str(r['verified_rows']) for r in rounds)),
 proposal_calls=proposals,repair_calls=len(rounds),auxiliary_calls=aux,prefill_calls=2,total_Graph_calls=193,
 proposal_rows=proposal_rows,repair_rows=repair_rows,decode_draft_rows=proposal_rows+repair_rows,prefill_draft_rows=310,total_draft_rows=571,
 note='Exact old c343 greedy K2 retained result. This is not a current K2 timing, peer comparison or new experiment.'),
 actual_path=[
  dict(anchor='main.cc:1483,5298-5302,5421-5448',fact='max_drafts>1 (or probability stopping) selects recursive mode. propose_recursive completes actual proposal IDs, then one kVerify call consumes the whole exact [pending,proposal...] width; distinct real widths are bucketed without padding.'),
  dict(anchor='main.cc:2114-2180,2190-2192',fact='K1 Round/CatchupRound builds NextN full_head and target T2 in the same graph, with the real draft append preceding target append. This joint K1 graph is absent from the generic recursive route.'),
  dict(anchor='main.cc:4199-4230,2647-2790',fact='Each recursive proposal depends on the preceding proposal ID/approximate hidden and private draft pages. execute_draft submits and retires one already-cold program per autoregressive proposal. This is sequential draft generation, not sequential target verification.'),
  dict(anchor='main.cc:4235-4265,4068-4075,4110-4142',fact='After target selection, one batched head=false program repairs actual retained draft KV using true target hidden rows. Approximate proposal KV is never installed into the complete published Head. Repair finishes before ledger checks/head swaps; existing COW/old-reader/retirement semantics remain authoritative.')],
 existing_multirow_capability=[
  dict(anchor='main.cc:2030-2047,2210-2266',fact='Verify already has exact T families, GDN.snapshot_count=T and independent history/recurrent output per target prefix. K2 therefore truly uses one T3 target, not three T1 calls.'),
  dict(anchor='main.cc:3973-4028,4048-4068,4110-4122; session_state.h:84-90',fact='Accepted target KV is reframed to the selected prefix; immutable GDN/history/carry outputs select accepted row. Partial acceptance discards mutable tail authority, never rewinds it. Existing finite N+T*R state and2N+T*R hidden budgeting already accounts those prefixes.'),
  dict(anchor='mtp_acceptance.h:56-79,82-109',fact='Public accepted-prefix selection is already arbitrary finite width, preserving output quota/EOS and final pending token. No common verifier API/operator/GDN snapshot extension is needed merely to admit K2 target batching.')],
 minimal_performance_direction=dict(
  first='Investigate reuse of existing capture policy for the original finite DraftPrograms, rather than another target-width rewrite.',
  source_seam='main.cc:2744 fixes every execute_draft prepare_replay to kCommands; main.cc:3319-3322 instead cold-selects Commands/PreferCapture from ReplayPolicy and planned uses for target Phase.',
  affected_modules=['Model::DraftProgram/prepare_draft_program/prepare_recursive_round_programs/execute_draft in existing qwen35 main adapter'],
  unchanged_modules=['engine/inference/mtp_acceptance.h','GatedDeltaNet snapshot operator','Graph/Compute executor and public resource/retirement APIs'],
  constraint='Would retain exact row/head finite programs, real page/hidden binding changes, hard invalidation, same RetainedResources/StepState retirement and normal Commands fallback. Source only: native capture qualification and actual savings have not been checked or measured here.',
  expected_kind='Could reduce eager per-command host dispatch; does not reduce mathematical work or weight bytes by itself. Current call count alone does not prove that dispatch is the performance bottleneck.'),
 why_not_trivial_wider_batch=[
  'Target width is alreadyK+1. Increasing it again cannot remove the95 autoregressive proposal calls without changing how later proposal inputs are produced.',
  'Repair already batches its actually retained rows in one call. Removing it or publishing approximate KV would violate the true-target hidden/full-Head contract.',
  'Moving bounded teacher-forced repair math into Verify is source-expressible with existing projections and prefix reframe, but still must materialize actual candidate KV and select the correct frontier/lag. It removes a host invocation only, not the required projection/weight reads, and can compute extra rejected-prefix rows; it is a larger separate design, not a verified free win.',
  'Batching the same draft depth across independent requests could share weight reads forR>1 using existing request-major geometry. The investigated old case isR1, so that does not explain or fix this193-call observation.',
  'No new manager, parallel speculative token policy, lazy incomplete Head, unbudgeted candidate storage, state deletion or fixed-address overwrite is justified by this call account.'
 ],
 changes=dict(product=0,builds=0,model_runs=0,GPU=0,HTTP=0))
(W/'review.json').write_text(json.dumps(memo,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(review=pin(W/'review.json'),old_call_breakdown=memo['actual_old_K2']),indent=2))
