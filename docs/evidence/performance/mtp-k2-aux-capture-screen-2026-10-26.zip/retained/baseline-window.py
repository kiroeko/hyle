from pathlib import Path
import importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2];V=R/'.scratch/qwen-mtp-window-20261022';F=R/'.scratch/qwen-mtp-final-window-20261024'
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
base=module('retained_window',V/'window.py');h=module('retained_consistency',R/'.scratch/qwen-mtp-quality-20261022/current-window/performance.py');turns=module('retained_turns_parser',F/'turns.py')
original_plan=base.plan;single_parse=base.parse_result;original_analyze=base.analyze;original_helpers=base.load_helpers
WORKLOAD='single'
def setup():
 ready=base.read(D/'ready.json');assert not ready['instrumented'];assert ready['canonical_main']['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
 peer=base.read(F/'peer-link1/ready.json');assert peer['image']['sha256']=='433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
 base.save(D/'peer-ready.json',peer)
 config=base.read(F/'current-window2/arms.json')
 for arm,row in config['arms'].items():row['ready']=str(D/('ready.json'if arm.startswith('hyle')else'peer-ready.json'))
 base.save(D/'arms.json',config)
 base.save(D/'binding.json',dict(clean_image=ready,peer=peer,role_mapping=base.read(D.parent/'current-cuda/input-adaptation.json'),protocol=base.identity(V/'window.py'),turns_parser=base.identity(F/'turns.py'),original_configuration=base.identity(F/'current-window2/arms.json'),scope='Only current image/V2 input bindings and natural output schema adapter. Original process order,12timing+4independent memory, clocks, observer, quotas, endpoints and no warmup/profile remain. No old samples pooled; no architecture causal-speed claim.'))
 print('SETUP_ONLY clean current + same peer/input protocol',flush=True)

def plan(config,mode,output):
 p=original_plan(config,mode,output)
 for row in p['commands']:
  cmd=row['command']
  if row['arm'].startswith('hyle'):
   at=cmd.index('--inputs');cmd[at+1]=str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original')
   cmd+=['--backend','cuda','--sampling','greedy']
   if row['arm'].endswith('_mtp'):cmd+=['--mtp-max-drafts','1']
  if WORKLOAD=='two-turn':
   at=cmd.index('--steps');assert cmd[at+1]=='64';del cmd[at:at+2]
   cmd+=['--schedule',str(F/'natural-inputs/performance64.txt')]
 p.update(workload=WORKLOAD,binding=base.identity(D/'binding.json'),canonical_main=base.identity(R/'engine/models/qwen35/main.cc'),historical_samples_pooled=False,causal_architecture_benefit_claim=False,current_image_uninstrumented=True)
 if WORKLOAD=='two-turn':p.update(user_ids=[int(x)for x in(V/'inputs/prompt.ids').read_text().split()],quota=64,turn_count=2,new_user_tokens=308,prefill_target_input_rows=309)
 return p

def normalize(folder,arm):
 if arm.startswith('peer'):return
 raw=json.loads(next(line for line in reversed((folder/'stdout.log').read_text().splitlines())if line.startswith('{')))
 assert len(raw['sessions'])==1
 detail=raw['sessions'][0]['result'];n=dict(raw)
 for key,val in detail.items():
  if key not in n:n[key]=val
 # Exact counter spelling adaptation; plain declares no draft roles or programs.
 if'consumed_drafts'in n:n['accepted_drafts']=n['consumed_drafts']
 if not n['mtp']:
  assert n['mtp_tensors']==0 and n['draft_program_graph_calls']==0
  n.setdefault('actual_draft_rows',0);n.setdefault('draft_rows',0);n.setdefault('prefill_draft_rows',0)
 base.save(folder/'consumer-result.json',n)
 base.save(folder/'result-schema-adapter.json',dict(source='Original producer stdout last JSON retained unchanged',source_sha256=base.identity(folder/'stdout.log')['sha256'],operations=['top-level timing/work remain authoritative','missing generated IDs/turns copied from original sole sessions[0].result','consumed_drafts exposed under retained accepted_drafts spelling','ordinary absent draft row counters0 verified no MTP tensors/programs'],timing_values_changed=False))

def parse(folder,arm,configuration):
 normalize(folder,arm)
 result=turns.parse_result(folder,arm,configuration)if WORKLOAD=='two-turn'else single_parse(folder,arm,configuration)
 if arm.startswith('hyle'):
  raw=base.read(folder/'consumer-result.json');assert raw['score_policy']=='bf16_inputs_f32_output'
  assert raw['live_committed_versions']==0 and raw['original_host_weight_bytes']==0
  assert raw['original_device_weight_bytes']==(3885311680 if arm.endswith('_mtp')else 3763655360)
 return result

def helpers():
 runner=original_helpers();old=runner.marker;turn=0
 def marker(line):
  nonlocal turn
  if line.startswith('measure_memory ')and'name=ready_before_first'in line:turn=0
  found=re.search(r'\bmemory_phase=generation_default_(prefill|decode)_(begin|end)\b',line)
  if found:
   if found.groups()==('prefill','begin'):turn+=1
   return(f'round{turn}_'if WORKLOAD=='two-turn'else'window_')+found[1]+'_'+found[2]
  return old(line)
 runner.marker=marker;return runner

def analyze(output):
 value=original_analyze(output);runs=base.read(output/'runs.json');consistency=h.within_arm_work(runs);expect=3 if value['mode']=='timing'else 1
 stable=len(runs)==4*expect and all(v['processes']==expect and v['stable']for v in consistency.values())
 value.update(status='complete_stable_within_arm_work'if stable else'complete_with_within_arm_variability',within_arm_work=consistency,within_arm_fixed_work_valid=stable,workload=WORKLOAD,baseline_date='2026-10-25',historical_samples_pooled=False,architecture_causal_benefit_claim=False,baseline_binding=base.identity(D/'binding.json'),image_instrumented=False)
 value['limits']+=['Current clean canonical CLI and scoped refreshed BF16 CUDA/Graph closure; other quant modes not blanket current-certified.','Producer default cerr/unitbuf remains; continuous natural wall includes prior step post-endpoint reporting. No private clocks or GPU profiler.', 'V2 input describes exact original335 physical ranges; ordinary selects original320 only. Current per-session result spelling normalized without changing endpoints.']
 base.save(output/'summary.json',value);assert stable,'Within-arm IDs/work/decision variability preserved; do not silently remove samples.'
 return value
base.plan,base.parse_result,base.load_helpers,base.analyze=plan,parse,helpers,analyze
if __name__=='__main__':
 action=sys.argv[1]
 if action=='setup':setup()
 else:
  WORKLOAD,mode=sys.argv[2:];assert WORKLOAD in('single','two-turn')and mode in('timing','memory');output=D/(WORKLOAD+'-'+mode)
  if action=='plan':base.save(D/(WORKLOAD+'-'+mode+'-plan.json'),plan(D/'arms.json',mode,output));print('PLAN',WORKLOAD,mode,flush=True)
  elif action=='run':
   os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');result=base.run(D/'arms.json',mode,output);print('COMPLETE',WORKLOAD,mode,result['processes'],result['within_arm_fixed_work_valid'],flush=True)
  elif action=='analyze':print(analyze(output)['status'],flush=True)
