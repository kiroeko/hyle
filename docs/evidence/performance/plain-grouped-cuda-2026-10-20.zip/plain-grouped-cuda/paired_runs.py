"""One bounded interleaved comparison after both exact precision witnesses pass."""
import argparse
import json
from pathlib import Path
import statistics
import subprocess
import sys
stage = Path(__file__).resolve().parent
build = stage / "checks/native1"
p = argparse.ArgumentParser(); p.add_argument("--prefix", default="paired-pinned")
p.add_argument("--cpu", type=int, default=2)
p.add_argument("--warmup", type=int, default=512)
p.add_argument("--iterations", type=int, default=512)
args = p.parse_args()
order = ["control", "new", "new", "control", "control", "new"]
rows = []
for index, arm in enumerate(order):
    name = args.prefix + "-" + str(index) + "-" + arm
    command = [sys.executable, "-B", str(stage / "run_bench.py"), "--build", str(build),
        "--arm", arm, "--name", name, "--warmup", str(args.warmup), "--iterations", str(args.iterations),
        "--cpu", str(args.cpu)]
    result = subprocess.run(command, capture_output=True, text=True)
    print(result.stdout, end="", flush=True)
    if result.returncode:
        print(result.stderr, end="", flush=True)
        raise SystemExit(result.returncode)
    record = json.loads((stage / "runs" / name / "summary.json").read_text())
    record.update(arm=arm, run=name)
    rows.append(record)
arms = {arm: [row["submit_and_wait_ns_median"] / 1000 for row in rows if row["arm"] == arm]
        for arm in ("control", "new")}
medians = {arm: statistics.median(values) for arm, values in arms.items()}
summary = dict(passed=True, order=order, per_process_median_us=arms,
    median_of_process_medians_us=medians, latency_ratio_new_over_control=medians["new"] / medians["control"],
    input=dict(T=1, S=4, E=8, N=512, K=2048, shared_A=True),
    counts=dict(processes_per_arm=3, warmup_per_process=args.warmup,
        measured_samples_per_process=args.iterations), caller_cpu=args.cpu,
    arithmetic="Both exact unit and subnormal product witnesses passed in every process; original wrong-precision image excluded",
    boundary="Already prepared commands: Invocation::submit through Completion::wait, not kernel duration or whole-model tokens/s",
    limitations=["One synthetic ordinary grouped operation and fixed bound inputs/IDs",
                 "No power/frequency lock; process order interleaved to expose drift",
                 "No selected whole-model throughput, cold load or total memory peak result"],
    runs=rows)
(stage / (args.prefix + "-results.json")).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(passed=True, medians_us=medians, ratio=summary["latency_ratio_new_over_control"])), flush=True)
