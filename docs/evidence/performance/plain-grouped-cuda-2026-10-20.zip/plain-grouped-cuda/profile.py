"""Trace one actual command invocation per same-math arm, without counters."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "plain_grouped_profile_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
build = stage / "checks/native1"
nsys = Path("C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe")
for arm in ("control", "new"):
    out = stage / "profile" / arm
    out.mkdir(parents=True, exist_ok=False); (out / "tmp").mkdir()
    image, link = c.read(build / (arm + "-image.json")), c.read(build / (arm + "-link-plan.json"))
    assert b.same(image)
    for item in link["inputs"]:
        assert b.same(item), item["path"]
    env, runtime = b.environment(link["command"], [r["path"] for r in link["inputs"]], out)
    c.save(out / "runtime.json", dict(image=image, profiler=b.identity(nsys),
        runtime_library_directories=runtime, counter_sampling=False))
    prefix = out / "trace"
    c.execute("profile", [str(nsys), "profile", "--trace=cuda", "--sample=none",
        "--cpuctxsw=none", "--cuda-graph-trace=node", "--output=" + str(prefix), image["path"],
        "--tokens", "1", "--iterations", "1", "--warmup", "0", "--cpu", "2"], env, out)
    c.execute("export", [str(nsys), "export", "--type=sqlite", "--output=" + str(prefix.with_suffix(".sqlite")),
        str(prefix.with_suffix(".nsys-rep"))], env, out)
print("PLAIN_GROUPED_PROFILE_COMPLETE", flush=True)
