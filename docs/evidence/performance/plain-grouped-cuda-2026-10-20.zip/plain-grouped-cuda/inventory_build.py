"""Inventory actual cached owners; never infer reuse from directory names."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "plain_grouped_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
base_path = stage.parent / "ct-packed-linear/checks/mapped-prepared/link-plan.json"
base = c.read(base_path)
metadata = h.metadata({"current": base})
requested = ["ggml-cuda.cu", "mmvf.cu", "unary.cu"]
owners = {}
provider_owner = None
test_owners = []
for item in base["inputs"]:
    row = metadata.get(c.key(item["path"]))
    if not row:
        continue
    for name in requested:
        if Path(row["source_path"]).name == name:
            owners[name] = dict(row, old_object=item)
    if row["source_path"].replace("\\", "/").endswith("src/compute_provider_ggml_cuda/ggml_cuda_provider.cc"):
        provider_owner = dict(row, old_object=item)
    if "tests" in Path(row["source_path"]).parts:
        test_owners.append(dict(row, old_object=item))
result = dict(base=str(base_path), inputs=len(base["inputs"]),
    metadata_records=len(metadata), native_owners=owners, provider_owner=provider_owner,
    current_test_owners=test_owners,
    missing=[name for name in requested if name not in owners])
c.save(stage / "build-inventory.json", result)
print("PLAIN_GROUPED_INVENTORY", len(owners), "native owners", "missing", result["missing"])
