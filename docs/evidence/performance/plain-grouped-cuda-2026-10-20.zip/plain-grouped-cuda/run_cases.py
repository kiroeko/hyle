"""Run only the affected existing public grouped consumer in one real image."""
import argparse
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "plain_grouped_test_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
p = argparse.ArgumentParser()
p.add_argument("--build", type=Path, required=True)
p.add_argument("--name", required=True)
args = p.parse_args()
assert Path(args.name).name == args.name
out = stage / "runs" / args.name
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
build = args.build.resolve()
image, link = c.read(build / "tests-image.json"), c.read(build / "tests-link-plan.json")
assert b.same(image)
for item in link["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(link["command"], [row["path"] for row in link["inputs"]], out)
c.save(out / "runtime.json", dict(image=image, link=b.identity(build / "tests-link-plan.json"),
    runtime_library_directories=runtime))
try:
    c.execute("tests", [image["path"], "--gtest_filter=CudaGroupedShared.*",
        "--gtest_output=xml:" + str(out / "results.xml")], env, out)
finally:
    cases = ET.parse(out / "results.xml").findall(".//testcase") if (out / "results.xml").is_file() else []
    passed = len(cases) == 6 and all(case.find(tag) is None for case in cases
        for tag in ("failure", "error", "skipped"))
    c.save(out / "summary.json", dict(passed=passed, cases=len(cases), expected=6,
        skipped=sum(case.find("skipped") is not None for case in cases),
        names=[case.attrib["classname"] + "." + case.attrib["name"] for case in cases], image=image))
assert passed
print("PLAIN_GROUPED_ACTUAL_TESTS", len(cases), "passed", flush=True)
