"""Exact existing-manifest edits only; no compilation, GPU, or SDK mutation."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('nv_helpers',
    STAGE.parent / 'gguf-nvfp4/cpu-cuda/prepare_native.py')
n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(n)
NAMES = ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/mmvf.cuh', 'src/ggml-cuda/mmvf.cu']


def main():
    assert not (STAGE / 'native-source-freeze.json').exists() or '--refresh' in sys.argv
    manifest = n.read(STAGE / 'product-before/third_party/ggml_cuda_runtime/patches.json')
    rows = {r['path']: r for r in manifest['files']}
    source = {name: n.replay(rows[name]).decode() for name in NAMES}
    changes = {name: [] for name in NAMES}

    def edit(name, old, new):
        assert source[name].count(old) == 1, (name, old[:100])
        source[name] = source[name].replace(old, new, 1)
        changes[name].append(dict(before=old, after=new))

    main_name, header, host = NAMES
    old = '        dst_slice.data   = dst_data_cur;\n\n        ggml_cuda_mul_mat(ctx, &src0_slice, &src1_slice, &dst_slice);'
    new = '''        dst_slice.data   = dst_data_cur;
        // Sorting must preserve both parent precision requests.
        dst_slice.op = GGML_OP_MUL_MAT;
        GGML_ASSERT(ggml_prec_set_acc(&dst_slice, (ggml_prec) ggml_get_op_params_i32(dst, 0)));
        GGML_ASSERT(ggml_prec_set_src(&dst_slice, (ggml_prec) ggml_get_op_params_i32(dst, 3), 1));

        ggml_cuda_mul_mat(ctx, &src0_slice, &src1_slice, &dst_slice);'''
    edit(main_name, old, new)
    # Independent same-math control: only restore the original fallback's lost
    # precision fields, without enabling the new GPU-ID vector dispatch.
    control_cuda = source[main_name].encode()

    helper = '''// One predicate for indexed dispatch and capture qualification. Preserve the
// original AMD domain; NVIDIA's new exact-F32 carrier uses the existing MMVF
// shape/device preference and only its actual pair-load/indexing layouts.
static bool ggml_cuda_mul_mat_id_use_mmvf(const ggml_tensor * dst, const int cc) {
    if (GGML_CUDA_CC_IS_AMD(cc)) {
        return true;
    }
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const ggml_tensor * w = dst->src[0];
    const ggml_tensor * a = dst->src[1];
    const ggml_tensor * ids = dst->src[2];
    const int device = ggml_cuda_get_device();
    const auto & limits = ggml_cuda_launch_limits[device];
    const int slot_limit = ggml_cuda_mmvq_grid_y[device];
    if (!GGML_CUDA_CC_IS_NVIDIA(cc) || w->type != GGML_TYPE_F32 ||
            a->type != GGML_TYPE_F32 || dst->type != GGML_TYPE_F32 ||
            dst->op_params[0] != GGML_PREC_F32 || !ids || ids->type != GGML_TYPE_I32 ||
            w->ne[3] != 1 || a->ne[3] != 1 || dst->ne[3] != 1 || ids->ne[2] != 1 || ids->ne[3] != 1 ||
            a->ne[0] != w->ne[0] || dst->ne[0] != w->ne[1] ||
            (a->ne[1] != 1 && a->ne[1] != dst->ne[1]) ||
            a->ne[2] != dst->ne[2] || ids->ne[0] != dst->ne[1] || ids->ne[1] != dst->ne[2] ||
            ids->nb[0] != sizeof(int32_t) || ids->nb[1] % sizeof(int32_t) != 0 ||
            ids->nb[1] / sizeof(int32_t) > INT_MAX ||
            limits[0] <= 0 || limits[1] <= 0 || slot_limit <= 0 ||
            w->ne[1] > limits[0] || dst->ne[1] > slot_limit || a->ne[2] > limits[1] ||
            !ggml_cuda_should_use_mmvf(w->type, cc, w->ne, w->nb, a->ne[2])) {
        return false;
    }
    // Forwarded kernel strides and their in-expert offsets are signed I32.
    // Also prove pair alignment from view metadata before payload binding.
    const auto layout = [](const ggml_tensor * value, bool pairs) {
        if (value->nb[0] != sizeof(float)) return false;
        size_t span = sizeof(float);
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            if (value->ne[axis] <= 0 || value->nb[axis] % sizeof(float) != 0 ||
                    value->nb[axis] / sizeof(float) > INT_MAX) return false;
            const size_t count = size_t(value->ne[axis] - 1);
            if (count && value->nb[axis] > (SIZE_MAX - span) / count) return false;
            span += count * value->nb[axis];
        }
        if (span / sizeof(float) > INT_MAX) return false;
        const size_t alignment = pairs ? 2 * sizeof(float) : sizeof(float);
        size_t offset = 0;
        for (const ggml_tensor * view = value; view->view_src; view = view->view_src) {
            if (view->view_offs > SIZE_MAX - offset) return false;
            offset += view->view_offs;
        }
        return offset % alignment == 0 && (!value->data || uintptr_t(value->data) % alignment == 0);
    };
    return layout(w, true) && layout(a, true) && layout(dst, false) && layout(ids, false) &&
        a->nb[2] % (2 * sizeof(float)) == 0 &&
        (a->ne[1] == 1 || a->nb[1] % (2 * sizeof(float)) == 0);
#else
    GGML_UNUSED(dst);
    return false;
#endif
}

'''
    anchor = '// returns true when ggml_cuda_mul_mat_id takes the fallback path that requires stream synchronization\n'
    edit(main_name, anchor, helper + anchor)
    edit(main_name, '} else if (GGML_CUDA_CC_IS_AMD(cc)) {\n            return false;\n        }',
         '} else if (ggml_cuda_mul_mat_id_use_mmvf(dst, cc)) {\n            return false;\n        }')
    edit(main_name, '                if (GGML_CUDA_CC_IS_AMD(cc)) {\n                    ggml_cuda_mul_mat_vec_f(ctx, src0, src1, ids, dst, ggml_prec(dst->op_params[0]));',
         '                if (ggml_cuda_mul_mat_id_use_mmvf(dst, cc)) {\n                    ggml_cuda_mul_mat_vec_f(ctx, src0, src1, ids, dst, ggml_prec(dst->op_params[0]));')

    arithmetic = '''// The new NVIDIA F32-ID specialization preserves subnormal operands and
// reduction partials even though this existing TU uses -use_fast_math.
template<bool strict_f32_ids>
static __device__ __forceinline__ void ggml_cuda_mmvf_mad(float & acc, float x, float y) {
    if constexpr (strict_f32_ids) {
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        asm volatile("fma.rn.f32 %0, %1, %2, %0;" : "+f"(acc) : "f"(x), "f"(y));
#else
        static_assert(!strict_f32_ids, "strict F32-ID MMVF is NVIDIA-only");
#endif
    } else {
        ggml_cuda_mad(acc, x, y);
    }
}
template<bool strict_f32_ids, int width>
static __device__ __forceinline__ float ggml_cuda_mmvf_sum(float value) {
    if constexpr (strict_f32_ids) {
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
#pragma unroll
        for (int offset = width / 2; offset > 0; offset >>= 1) {
            const float other = __shfl_xor_sync(0xffffffff, value, offset, width);
            asm volatile("add.rn.f32 %0, %0, %1;" : "+f"(value) : "f"(other));
        }
#else
        static_assert(!strict_f32_ids, "strict F32-ID MMVF is NVIDIA-only");
#endif
        return value;
    } else {
        return warp_reduce_sum<width>(value);
    }
}

'''
    anchor = '// Shared original MMVF carrier. A non-void epilogue is instantiated only by\n'
    edit(header, anchor, arithmetic + anchor)
    # Default template arguments keep every existing call and math branch.
    for prefix in [
        'template <typename T, typename type_acc, int ncols_dst, int block_size, bool has_fusion = false, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void>',
        'template<typename T, typename type_acc, int ncols_dst, int block_size, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void>',
        'template <typename T, typename type_acc, int ncols_dst, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void>']:
        edit(header, prefix, prefix[:-1] + ', bool strict_f32_ids = false>')
    edit(header, '    const T       * GGML_CUDA_RESTRICT x   = x_ptr;',
         '''    static_assert(!strict_f32_ids || (std::is_same_v<T, float> && std::is_same_v<Y, float> &&
        std::is_same_v<Dst, float> && std::is_same_v<type_acc, float> && !has_fusion));
    const T       * GGML_CUDA_RESTRICT x   = x_ptr;''')
    old = '                ggml_cuda_mad(sumf[j], tmpx.x, tmpy.x);\n                ggml_cuda_mad(sumf[j], tmpx.y, tmpy.y);'
    # The same text also exists in HIP BF16. Replace only the F32 branch.
    begin = source[header].index('    if constexpr (std::is_same_v<T, float>) {')
    end = source[header].index('    } else if constexpr (std::is_same_v<T, half>) {', begin)
    block = source[header][begin:end]
    assert block.count(old) == 1
    edit(header, block, block.replace(old,
        '                ggml_cuda_mmvf_mad<strict_f32_ids>(sumf[j], tmpx.x, tmpy.x);\n                ggml_cuda_mmvf_mad<strict_f32_ids>(sumf[j], tmpx.y, tmpy.y);'))
    for old in ['sumf[j] = warp_reduce_sum<warp_size>(sumf[j]);',
                'sumf_gate[j] = warp_reduce_sum<warp_size>(sumf_gate[j]);']:
        # Both the first and shared second warp stage keep the same tree.
        begin = source[header].index('    ggml_cuda_pdl_lc();')
        end = source[header].index('    if (tid >= ncols_dst)', begin)
        block = source[header][begin:end]
        assert block.count(old) == 2
        edit(header, block, block.replace(old, old.replace('warp_reduce_sum<warp_size>', 'ggml_cuda_mmvf_sum<strict_f32_ids, warp_size>')))
    edit(header, 'if constexpr (ncols_dst == 1 && std::is_same_v<Y, float> && std::is_same_v<Dst, float>) {',
         'if constexpr (ncols_dst == 1 && std::is_same_v<Y, float> && std::is_same_v<Dst, float> && !strict_f32_ids) {')
    # Only the no-fusion kernel receives strict=true. Existing fusion remains
    # byte-identical and cannot instantiate the strict no-fusion assertion.
    edit(header, 'mul_mat_vec_f<T, type_acc, ncols_dst, block_size, false, is_multi_token_id, Y, Dst>, launch_params',
         'mul_mat_vec_f<T, type_acc, ncols_dst, block_size, false, is_multi_token_id, Y, Dst, Epilogue, strict_f32_ids>, launch_params')
    for block_size in range(32, 257, 32):
        old = f'mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block_size}, is_multi_token_id, Y, Dst, Epilogue>'
        edit(header, old, old[:-1] + ', strict_f32_ids>')

    strict_host = '''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        if constexpr (std::is_same_v<T, float> && std::is_same_v<Y, float> && std::is_same_v<Dst, float>) {
            const int cc = ggml_cuda_info().devices[ggml_cuda_get_device()].cc;
            if (ids && prec == GGML_PREC_F32 && GGML_CUDA_CC_IS_NVIDIA(cc) &&
                    !fusion.gate && !fusion.x_bias && !fusion.gate_bias && !fusion.x_scale && !fusion.gate_scale) {
                if (ncols_dst > 1) {
                    launch_mul_mat_vec_f_cuda<T, float, 1, true, float, float, void, true>(
                        x, y, ids, fusion, dst, ncols, nrows, stride_row, stride_col_y, stride_col_dst,
                        nchannels_x, nchannels_y, nchannels_dst, stride_channel_x, stride_channel_y,
                        stride_channel_dst, nsamples_x, nsamples_dst, stride_sample_x, stride_sample_y,
                        stride_sample_dst, ncols_dst, ids_stride, stream);
                } else {
                    launch_mul_mat_vec_f_cuda<T, float, 1, false, float, float, void, true>(
                        x, y, ids, fusion, dst, ncols, nrows, stride_row, stride_col_y, stride_col_dst,
                        nchannels_x, nchannels_y, nchannels_dst, stride_channel_x, stride_channel_y,
                        stride_channel_dst, nsamples_x, nsamples_dst, stride_sample_x, stride_sample_y,
                        stride_sample_dst, ncols_dst, ids_stride, stream);
                }
                return;
            }
        }
#endif
'''
    anchor = '    } else {\n        if constexpr(std::is_same_v<T, half>) {'
    edit(host, anchor, '    } else {\n' + strict_host + '        if constexpr(std::is_same_v<T, half>) {')
    # Build-local source, patches and complete combined replay are authenticated
    # before the three product files are touched.
    for name in NAMES:
        rows[name]['edits'].extend(changes[name])
        rows[name]['after_sha256'] = n.sha(source[name].encode())
    draft = STAGE / 'patches-draft.json'
    n.save(draft, manifest)
    n.load('prepare_cuda_iq1_manifest').derive(n.UPSTREAM, STAGE / 'mixed-cpu-manifest.json',
        draft, n.VENDOR / 'iq1-patches.json', STAGE / 'combined-manifest.json')
    combined = n.read(STAGE / 'combined-manifest.json')
    before_combined = n.read(STAGE / 'before-combined-manifest.json')
    old = {r['path']: n.replay(r) for r in before_combined['files']}
    full = {r['path']: n.replay(r) for r in combined['files']}
    assert {name for name in full if full[name] != old[name]} == set(NAMES)
    for name in NAMES:
        out = STAGE / 'native-source' / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(full[name])
        b = STAGE / 'before' / name
        b.parent.mkdir(parents=True, exist_ok=True)
        b.write_bytes(old[name])
    # The unchanged strict unary source is a real mmvf.cuh owner. Put only its
    # source beside the changed header, not a duplicate SDK/header tree.
    unary = 'src/ggml-cuda/unary.cu'
    p = STAGE / 'native-source' / unary
    p.write_bytes(full[unary])
    # The control gets all current CPU/IQ1 edits plus only precision restore.
    row = next(r for r in before_combined['files'] if r['path'] == main_name)
    delta = changes[main_name][0]
    control = old[main_name].replace(delta['before'].encode(), delta['after'].encode(), 1)
    assert control != old[main_name]
    for folder, data in [('fallback-control', control), ('cuda-fallback-control', control_cuda)]:
        p = STAGE / folder / main_name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    n.save(STAGE / 'replacements.json', {'files': [dict(path=k, edits=v) for k, v in changes.items()]})
    (STAGE / 'native-changes.diff').write_text(''.join(''.join(difflib.unified_diff(
        old[name].decode().splitlines(True), full[name].decode().splitlines(True),
        'before/' + name, 'after/' + name)) for name in NAMES), encoding='utf-8', newline='\n')
    (n.VENDOR / 'patches.json').write_bytes(draft.read_bytes())
    notice = n.VENDOR / 'NOTICE.md'
    notice.write_text((STAGE / 'product-before/third_party/ggml_cuda_runtime/NOTICE.md').read_text(encoding='utf-8').rstrip() + '''

NVIDIA indexed plain-F32 small-token matrices additionally use the original
MMVF GPU-ID carrier when its existing device/shape preference and actual pair
layout/index bounds are satisfied. One predicate is shared by dispatch and
capture eligibility. The original TF32 MMF guard and larger-token host-sorted
fallback remain. That fallback now preserves both parent accumulation and
activation-source precision in each internal expert MatMul instead of resetting
them to DEFAULT. Every repeated slot remains an independent output.

Only the new NVIDIA F32-ID, non-fused specialization explicitly emits RN F32
FMA and reduction adds without FTZ, preserving subnormal operands/partials under
the existing fast-math TU flags. It reuses the original float2 loads, ID/slot
mapping, warp/shared reduction tree and launch geometry. Default-false template
instantiations, existing fusion, BF16/F16 and other backends retain their old
arithmetic. No activation expansion, ID host readback, new executor or public
operation is added in the admitted vector path. This is source/precision
selection, not a measured performance or complete prefill improvement claim.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = n.read(lock_path)
    entries = {r['name']: r for r in lock['dependencies']}
    tree = n.tree(n.VENDOR)
    row = entries['ggml_cuda_runtime_patches']
    row['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v29'
    row['vendored']['tree_sha256'] = tree
    for item in row['license']['files']:
        if item['root'] == 'hyle' and item['path'] == 'third_party/ggml_cuda_runtime/NOTICE.md':
            item['sha256'] = n.sha(notice.read_bytes())
    n.save(lock_path, lock)
    sid = n.sha((entries['ggml_runtime_patches']['vendored']['tree_sha256'] +
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        n.sha((ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        n.sha((ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) + tree).encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + sid + '"\n', encoding='utf-8')
    old_closure = n.read(STAGE.parent / 'gguf-nvfp4/cpu-cuda/native-header-closure.json')
    header_root = STAGE.parent / 'gguf-nvfp4/cpu-cuda/native-source'
    headers = []
    for item in old_closure['headers']:
        name = item['path']
        data = full.get(name, n.original(name))
        before = old.get(name, n.original(name))
        prior = header_root / name
        actual = STAGE / 'native-source' / name if name in NAMES else prior
        if not actual.exists() or actual.read_bytes() != data:
            actual = STAGE / 'native-source' / name
            actual.parent.mkdir(parents=True, exist_ok=True)
            actual.write_bytes(data)
        assert actual.read_bytes() == data, name
        headers.append(dict(path=name, bytes=len(data), sha256=n.sha(data), source=str(actual),
            changed=data != before, canonical_before_sha256=n.sha(before),
            previous_receipt_sha256=item['sha256'], previous_source_matches_canonical=prior.exists() and prior.read_bytes() == before))
    n.save(STAGE / 'native-header-closure.json', dict(headers=headers, previous_header_root=str(header_root)))
    n.save(STAGE / 'native-source-freeze.json', dict(version=row['version'], source_id=sid,
        files=[dict(path=name, before=n.identity(STAGE / 'before' / name), after=n.identity(STAGE / 'native-source' / name),
            cuda_only_before=n.identity(STAGE / 'cuda-before' / name)) for name in NAMES],
        sources={name: n.sha(full[name]) for name in NAMES + [unary]},
        fallback_control=n.identity(STAGE / 'fallback-control' / main_name),
        original_cuda_only_main_sha256=n.sha((STAGE / 'cuda-before' / main_name).read_bytes()),
        header_root=str(header_root), header_closure=n.identity(STAGE / 'native-header-closure.json'),
        native_TUs_requiring_refresh=['ggml-cuda.cu', 'mmvf.cu', 'unary.cu'],
        header_owners_reason='Only these three canonical source files include mmvf.cuh; unary copied unchanged beside new header.',
        math_status='Source-only explicit no-ftz PTX; actual compiled instructions/witnesses are not yet validated',
        product_files=[n.identity(ROOT / p) for p in ['third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json']],
        compile_run=False, GPU_run=False, SDK_modified=False))
    n.save(STAGE / 'cuda-lock-proposal.json', dict(dependency=row['name'], version=row['version'], source_id=sid,
        vendored_tree_sha256=tree, notice_sha256=n.sha(notice.read_bytes()), central_lock_modified=True))
    print(json.dumps(n.read(STAGE / 'cuda-lock-proposal.json'), indent=2))


if __name__ == '__main__':
    main()
