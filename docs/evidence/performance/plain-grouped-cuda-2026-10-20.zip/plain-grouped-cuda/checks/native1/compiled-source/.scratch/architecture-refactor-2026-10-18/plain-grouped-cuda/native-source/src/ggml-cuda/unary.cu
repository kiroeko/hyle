#include "unary.cuh"
#include "convert.cuh"
#include "mmvf.cuh"
#include "rope.cuh"

#include <cstdint>
#include <limits>
#include "numerical_contract.h"

#include <type_traits>

static __device__ __forceinline__ float op_abs(float x) {
    return fabsf(x);
}

static __device__ __forceinline__ float op_sgn(float x) {
    return (x > 0.f ? 1.f : ((x < 0.f ? -1.f : 0.f)));
}

static __device__ __forceinline__ float op_neg(float x) {
    return -x;
}

static __device__ __forceinline__ float op_step(float x) {
    return x > 0.0f;
}

static __device__ __forceinline__ float op_gelu(float x) {
    return ggml_cuda_op_gelu_single(x);
}

static __device__ __forceinline__ float op_gelu_erf(float x) {
    const float SQRT_2_INV = 0.70710678118654752440084436210484f;

    return 0.5f*x*(1.0f + erff(x*SQRT_2_INV));
}

static __device__ __forceinline__ float op_gelu_quick(float x) {
    const float GELU_QUICK_COEF = -1.702f;

    return x * (1.0f / (1.0f + expf(GELU_QUICK_COEF * x)));
}

static __device__ __forceinline__ float op_silu(float x) {
    return ggml_cuda_op_silu_single(x);
}

// Match HYLE ordinary Unary, not the separately defined GLU formula.
// This unit is compiled by ggml-cuda-precise-unary without fast math.
static __device__ __forceinline__ float op_hyle_stable_silu(float x) {
    if (isinf(x) && x < 0) {
        return 0.0f;
    }
    const float e = expf(-fabsf(x));
    const float sigmoid = x >= 0 ? 1.0f / (1.0f + e) : e / (1.0f + e);
    return x * sigmoid;
}

static bool ggml_hyle_stable_silu(const ggml_tensor * node) {
    return ggml_get_unary_op(node) == GGML_UNARY_OP_SILU &&
        ggml_get_op_params_i32(node, hyle::compute::ggml_cuda::internal::kUnaryContractParam) ==
            hyle::compute::ggml_cuda::internal::kStableSiluContract;
}


// Exact metadata carrier only. Published/readers and real buffer ownership are
// graph/encode facts checked by the native private matcher, not by sizing.
bool ggml_cuda_supports_cast_stable_silu(const ggml_tensor * cast, const ggml_tensor * silu) {
    if (!cast || !silu || cast->op != GGML_OP_CPY || cast->type != GGML_TYPE_BF16 ||
        cast->src[1] != cast || cast->view_src || silu->view_src ||
        silu->op != GGML_OP_UNARY || silu->type != GGML_TYPE_BF16 ||
        silu->src[0] != cast || !ggml_hyle_stable_silu(silu)) return false;
    const ggml_tensor * const x = cast->src[0];
    if (!x || x == cast || x == silu || x->type != GGML_TYPE_F32) return false;
    for (int port = 2; port < GGML_MAX_SRC; ++port) {
        if (cast->src[port]) return false;
    }
    for (int port = 1; port < GGML_MAX_SRC; ++port) {
        if (silu->src[port]) return false;
    }
    const ggml_tensor * const tensors[] = {x, cast, silu};
    for (const auto * tensor : tensors) {
        uint64_t count = 1;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            // The original dense unary carrier uses a signed int count.
            if (tensor->ne[axis] <= 0 || uint64_t(tensor->ne[axis]) > uint64_t(INT32_MAX) / count ||
                tensor->nb[axis] > uint64_t(INT64_MAX) ||
                tensor->nb[axis] % ggml_type_size(tensor->type)) return false;
            count *= uint64_t(tensor->ne[axis]);
        }
        if (!ggml_is_contiguous(tensor) || !ggml_are_same_shape(tensor, cast)) return false;
    }
    return true;
}

static __global__ void hyle_cast_stable_silu(const float * __restrict__ x,
        nv_bfloat16 * __restrict__ dst, int64_t count) {
    ggml_cuda_pdl_lc();
    const int64_t index = int64_t(blockIdx.x) * blockDim.x + threadIdx.x;
    if (index >= count) return;
    ggml_cuda_pdl_sync();
    // Both public BF16 boundaries remain. In particular do not apply SiLU to
    // the original float value and narrow only its final result.
    const nv_bfloat16 rounded = __float2bfloat16_rn(x[index]);
    const float value = __bfloat162float(rounded);
    dst[index] = __float2bfloat16_rn(op_hyle_stable_silu(value));
}

void ggml_cuda_op_cast_stable_silu(ggml_backend_cuda_context & ctx,
        const ggml_tensor * cast, ggml_tensor * silu) {
    if (!ggml_cuda_supports_cast_stable_silu(cast, silu)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid Cast/stable SiLU metadata");
    }
    const int64_t count = ggml_nelements(silu);
    const unsigned blocks = unsigned((count + CUDA_SILU_BLOCK_SIZE - 1) / CUDA_SILU_BLOCK_SIZE);
    // The main encoder has checked actual owners, capacities, device, bounds,
    // alignment, disjointness and the cold device launch limits before entry.
    ggml_cuda_kernel_launch(hyle_cast_stable_silu,
        ggml_cuda_kernel_launch_params(blocks, CUDA_SILU_BLOCK_SIZE, 0, ctx.stream()),
        static_cast<const float *>(cast->src[0]->data), static_cast<nv_bfloat16 *>(silu->data), count);
}

static __device__ __forceinline__ float op_tanh(float x) {
    return tanhf(x);
}

static __device__ __forceinline__ float op_relu(float x) {
    return fmaxf(x, 0);
}

static __device__ __forceinline__ float op_sigmoid(float x) {
    return 1.0f / (1.0f + expf(-x));
}

static __device__ __forceinline__ float op_hardsigmoid(float x) {
    return fminf(1.0f, fmaxf(0.0f, (x + 3.0f) / 6.0f));
}

static __device__ __forceinline__ float op_hardswish(float x) {
    return x * fminf(1.0f, fmaxf(0.0f, (x + 3.0f) / 6.0f));
}

static __device__ __forceinline__ float op_exp(float x) {
    return expf(x);
}

static __device__ __forceinline__ float op_sqr(float x) {
    return x * x;
}

static __device__ __forceinline__ float op_relu_sqr(float x) {
    const float r = fmaxf(x, 0.0f);
    return r * r;
}

static __device__ __forceinline__ float op_sqrt(float x) {
    return sqrtf(x);
}

static __device__ __forceinline__ float op_sin(float x) {
    return sinf(x);
}

static __device__ __forceinline__ float op_cos(float x) {
    return cosf(x);
}

static __device__ __forceinline__ float op_log(float x) {
    return logf(x);
}

static __device__ __forceinline__ float op_expm1(float x) {
    return expm1f(x);
}

static __device__ __forceinline__ float op_softplus(float x) {
    return (x > 20.0f) ? x : logf(1.0f + expf(x));
}

static __device__ __forceinline__ float op_elu(float x) {
    return (x > 0.f) ? x : expm1f(x);
}

static __device__ __forceinline__ float op_floor(float x) {
    return floorf(x);
}

static __device__ __forceinline__ float op_ceil(float x) {
    return ceilf(x);
}

static __device__ __forceinline__ float op_round(float x) {
    return round(x);
}

static __device__ __forceinline__ float op_trunc(float x) {
    return trunc(x);
}

template <float (*op)(float), typename T>
static __global__ void unary_op_kernel(const T * x, T * dst, const int k) {
    ggml_cuda_pdl_lc();
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    ggml_cuda_pdl_sync();
    dst[i] = (T)op((float)x[i]);
}

template <float (*op)(float), typename T>
static void unary_cuda(const T * x, T * dst, const int k, cudaStream_t stream) {
    const int num_blocks = (k + CUDA_NEG_BLOCK_SIZE - 1) / CUDA_NEG_BLOCK_SIZE;
    const ggml_cuda_kernel_launch_params launch_params = ggml_cuda_kernel_launch_params((dim3)num_blocks, CUDA_NEG_BLOCK_SIZE, 0, stream);
    ggml_cuda_kernel_launch(unary_op_kernel<op, T>, launch_params, x, dst, k);
}

template <float (*op)(float)>
void ggml_cuda_op_unary(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const void * src0_d = src0->data;
    void * dst_d = dst->data;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous(src0));

    if constexpr (op == op_abs || op == op_neg || op == op_exp || op == op_log ||
                  op == op_sqrt || op == op_tanh || op == op_sigmoid || op == op_hyle_stable_silu) {
        if (src0->type == GGML_TYPE_BF16 && dst->type == GGML_TYPE_BF16) {
            unary_cuda<op>((const nv_bfloat16 *)src0_d, (nv_bfloat16 *)dst_d, ggml_nelements(src0), stream);
            return;
        }
    }

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);

    if (src0->type == GGML_TYPE_F16) {
        unary_cuda<op>((const half *)src0_d, (half *)dst_d, ggml_nelements(src0), stream);
    } else {
        unary_cuda<op>((const float *)src0_d, (float *)dst_d, ggml_nelements(src0), stream);
    }
}

void ggml_cuda_op_abs(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_abs>(ctx, dst);
}

void ggml_cuda_op_sgn(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_sgn>(ctx, dst);
}

void ggml_cuda_op_neg(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_neg>(ctx, dst);
}

void ggml_cuda_op_step(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_step>(ctx, dst);
}

void ggml_cuda_op_gelu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_gelu>(ctx, dst);
}

void ggml_cuda_op_gelu_erf(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_gelu_erf>(ctx, dst);
}

void ggml_cuda_op_gelu_quick(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_gelu_quick>(ctx, dst);
}

void ggml_cuda_op_silu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (ggml_hyle_stable_silu(dst)) {
        GGML_ASSERT(dst->type == GGML_TYPE_F32 || dst->type == GGML_TYPE_BF16);
        ggml_cuda_op_unary<op_hyle_stable_silu>(ctx, dst);
        return;
    }
    ggml_cuda_op_unary<op_silu>(ctx, dst);
}

void ggml_cuda_op_tanh(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_tanh>(ctx, dst);
}

void ggml_cuda_op_relu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_relu>(ctx, dst);
}

void ggml_cuda_op_sigmoid(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_sigmoid>(ctx, dst);
}

void ggml_cuda_op_hardsigmoid(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_hardsigmoid>(ctx, dst);
}

void ggml_cuda_op_hardswish(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_hardswish>(ctx, dst);
}

void ggml_cuda_op_exp(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_exp>(ctx, dst);
}

void ggml_cuda_op_sqr(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_sqr>(ctx, dst);
}

void ggml_cuda_op_sqrt(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_sqrt>(ctx, dst);
}

void ggml_cuda_op_sin(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_sin>(ctx, dst);
}

void ggml_cuda_op_cos(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_cos>(ctx, dst);
}

void ggml_cuda_op_log(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_log>(ctx, dst);
}

void ggml_cuda_op_elu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_elu>(ctx, dst);
}

void ggml_cuda_op_floor(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_floor>(ctx, dst);
}

void ggml_cuda_op_ceil(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_ceil>(ctx, dst);
}

void ggml_cuda_op_round(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_round>(ctx, dst);
}

void ggml_cuda_op_trunc(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_trunc>(ctx, dst);
}

void ggml_cuda_op_expm1(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_expm1>(ctx, dst);
}

void ggml_cuda_op_softplus(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary<op_softplus>(ctx, dst);
}
/* gated ops */

template <float (*op)(float), typename T, bool round_unary = false>
static __global__ void unary_gated_op_kernel(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1) {
    ggml_cuda_pdl_lc();
    const int64_t i = int64_t(blockDim.x)*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    // perform base op and multiply with gate (either offset in same tensor or a separate one)
    const int64_t j0 = (i / n) * o0 + (i % n);
    const int64_t j1 = o0 == o1 ? j0 : (i / n) * o1 + (i % n);

    ggml_cuda_pdl_sync();
    if constexpr (round_unary) {
        float value = op((float)x[j0]);
        if constexpr (std::is_same<T, nv_bfloat16>::value) {
            value = __bfloat162float(__float2bfloat16_rn(value));
        } else {
            value = (float)(T)value;
        }
        dst[i] = (T)(value * (float)g[j1]);
    } else {
        dst[i] = (T)(op((float)x[j0]) * (float)g[j1]);
    }
}

template <float (*op)(float), typename T, bool round_unary = false>
static void unary_gated_cuda(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, cudaStream_t stream) {
    const int64_t num_blocks = (k + CUDA_GLU_BLOCK_SIZE - 1) / CUDA_GLU_BLOCK_SIZE;
    const ggml_cuda_kernel_launch_params launch_params = ggml_cuda_kernel_launch_params((dim3)num_blocks, CUDA_GLU_BLOCK_SIZE, 0, stream);
    ggml_cuda_kernel_launch(unary_gated_op_kernel<op, T, round_unary>, launch_params, x, g, dst, k, n, o0, o1);
}

template <float (*op)(float)>
void ggml_cuda_op_unary_gated(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const ggml_tensor * src1 = dst->src[1];
    void * src0_d = src0->data;
    void * src1_d = src1 ? src1->data : src0->data;
    const int64_t src0_o = src0->nb[1];
    const int64_t src1_o = src1 ? src1->nb[1] : src0->nb[1];
    void * dst_d = dst->data;
    const int64_t nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous_1(src0));
    GGML_ASSERT(src0->nb[0] == ggml_element_size(src0));
    GGML_ASSERT(ggml_is_contiguous(dst));

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);
    GGML_ASSERT(dst->ne[0] == nc);
    GGML_ASSERT(ggml_nrows(dst) == ggml_nrows(src0));

    if (src1) {
        GGML_ASSERT(ggml_is_contiguous_1(src1));
        GGML_ASSERT(src1->nb[0] == ggml_element_size(src1));
        GGML_ASSERT(src1->ne[0] == nc);
        GGML_ASSERT(src0->type == src1->type);
    }

    const int32_t swapped = ((const int32_t *) dst->op_params)[1];

    if (src0->type == GGML_TYPE_F16) {
        half * src0_p = (half *) src0_d;
        half * src1_p = (half *) src1_d;

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        unary_gated_cuda<op>(src0_p, src1_p, (half *)dst_d, ggml_nelements(dst), nc, src0_o / sizeof(half), src1_o / sizeof(half), stream);
    } else {
        float * src0_p = (float *) src0_d;
        float * src1_p = (float *) src1_d;

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        unary_gated_cuda<op>(src0_p, src1_p, (float *)dst_d, ggml_nelements(dst), nc, src0_o / sizeof(float), src1_o / sizeof(float), stream);
    }
}

void ggml_cuda_op_reglu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary_gated<op_relu>(ctx, dst);
}

void ggml_cuda_op_geglu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary_gated<op_gelu>(ctx, dst);
}

void ggml_cuda_op_swiglu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary_gated<op_silu>(ctx, dst);
}

void ggml_cuda_op_geglu_erf(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary_gated<op_gelu_erf>(ctx, dst);
}

void ggml_cuda_op_geglu_quick(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    ggml_cuda_op_unary_gated<op_gelu_quick>(ctx, dst);
}

// swiglu_oai

template <typename T>
static __global__ void swiglu_oai_kernel(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, float alpha, float limit) {
    const int64_t i = int64_t(blockDim.x)*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    // perform base op and multiply with gate (either offset in same tensor or a separate one)
    const int64_t j0 = (i / n) * o0 + (i % n);
    const int64_t j1 = o0 == o1 ? j0 : (i / n) * o1 + (i % n);

    float xi = x[j0];
    float gi = g[j1];

    dst[i] = ggml_cuda_op_swiglu_oai_single(xi, gi, alpha, limit);
}

template <typename T>
static void swiglu_oai_cuda(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, const float alpha, const float limit, cudaStream_t stream) {
    const int64_t num_blocks = (k + CUDA_GLU_BLOCK_SIZE - 1) / CUDA_GLU_BLOCK_SIZE;
    swiglu_oai_kernel<<<num_blocks, CUDA_GLU_BLOCK_SIZE, 0, stream>>>(x, g, dst, k, n, o0, o1, alpha, limit);
}

void ggml_cuda_op_swiglu_oai(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const ggml_tensor * src1 = dst->src[1];
    void * src0_d = src0->data;
    void * src1_d = src1 ? src1->data : src0->data;
    const int64_t src0_o = src0->nb[1];
    const int64_t src1_o = src1 ? src1->nb[1] : src0->nb[1];
    void * dst_d = dst->data;
    const int64_t nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous_1(src0));
    GGML_ASSERT(src0->nb[0] == ggml_element_size(src0));
    GGML_ASSERT(ggml_is_contiguous(dst));

    GGML_ASSERT(src0->type == GGML_TYPE_F32);
    GGML_ASSERT( dst->type == GGML_TYPE_F32);
    GGML_ASSERT(src0->type == dst->type);
    GGML_ASSERT(dst->ne[0] == nc);
    GGML_ASSERT(ggml_nrows(dst) == ggml_nrows(src0));

    if (src1) {
        GGML_ASSERT(ggml_is_contiguous_1(src1));
        GGML_ASSERT(src1->nb[0] == ggml_element_size(src1));
        GGML_ASSERT(src1->ne[0] == nc);
        GGML_ASSERT(src0->type == src1->type);
    }

    //const int32_t swapped = ((const int32_t *) dst->op_params)[1];
    const int32_t swapped = ggml_get_op_params_i32(dst, 1);
    const float alpha = ggml_get_op_params_f32(dst, 2);
    const float limit = ggml_get_op_params_f32(dst, 3);

    float * src0_p = (float *) src0_d;
    float * src1_p = (float *) src1_d;

    if (!src1) {
        src0_p += swapped ? nc : 0;
        src1_p += swapped ? 0 : nc;
    }

    swiglu_oai_cuda(src0_p, src1_p, (float *)dst_d, ggml_nelements(dst), nc, src0_o / sizeof(float), src1_o / sizeof(float), alpha, limit, stream);
}

// swiglu_clamp

template <typename T>
static __global__ void swiglu_clamp_kernel(const T * gate, const T * up, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, float limit) {
    const int64_t i = int64_t(blockDim.x)*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    const int64_t j0 = (i / n) * o0 + (i % n);
    const int64_t j1 = o0 == o1 ? j0 : (i / n) * o1 + (i % n);

    dst[i] = (T) ggml_cuda_op_swiglu_clamp_single((float) gate[j0], (float) up[j1], limit);
}

template <typename T>
static void swiglu_clamp_cuda(const T * gate, const T * up, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, const float limit, cudaStream_t stream) {
    const int64_t num_blocks = (k + CUDA_GLU_BLOCK_SIZE - 1) / CUDA_GLU_BLOCK_SIZE;
    swiglu_clamp_kernel<<<num_blocks, CUDA_GLU_BLOCK_SIZE, 0, stream>>>(gate, up, dst, k, n, o0, o1, limit);
}

void ggml_cuda_op_swiglu_clamp(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const ggml_tensor * src1 = dst->src[1];
    void * src0_d = src0->data;
    void * src1_d = src1 ? src1->data : src0->data;
    const int64_t src0_o = src0->nb[1];
    const int64_t src1_o = src1 ? src1->nb[1] : src0->nb[1];
    void * dst_d = dst->data;
    const int64_t nc = src1 ? src0->ne[0] : src0->ne[0] / 2;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous_1(src0));
    GGML_ASSERT(src0->nb[0] == ggml_element_size(src0));
    GGML_ASSERT(ggml_is_contiguous(dst));

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);
    GGML_ASSERT(dst->ne[0] == nc);
    GGML_ASSERT(ggml_nrows(dst) == ggml_nrows(src0));

    if (src1) {
        GGML_ASSERT(ggml_is_contiguous_1(src1));
        GGML_ASSERT(src1->nb[0] == ggml_element_size(src1));
        GGML_ASSERT(src1->ne[0] == nc);
        GGML_ASSERT(src0->type == src1->type);
    }

    const int32_t swapped = ggml_get_op_params_i32(dst, 1);
    const float limit = ggml_get_op_params_f32(dst, 3);

    if (src0->type == GGML_TYPE_F16) {
        half * src0_p = (half *) src0_d;
        half * src1_p = (half *) src1_d;

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        swiglu_clamp_cuda(src0_p, src1_p, (half *) dst_d, ggml_nelements(dst), nc, src0_o / sizeof(half), src1_o / sizeof(half), limit, stream);
    } else {
        float * src0_p = (float *) src0_d;
        float * src1_p = (float *) src1_d;

        if (!src1) {
            src0_p += swapped ? nc : 0;
            src1_p += swapped ? 0 : nc;
        }

        swiglu_clamp_cuda(src0_p, src1_p, (float *) dst_d, ggml_nelements(dst), nc, src0_o / sizeof(float), src1_o / sizeof(float), limit, stream);
    }
}

/* CUDA kernel + launcher for xIELU */

template <typename T>
static __global__ void xielu_kernel(const T * x, T * dst, const int k, float alpha_n, float alpha_p, float beta, float eps) {
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    const float xi = ggml_cuda_cast<float>(x[i]);

    const float gate_pos = (xi > 0.0f);
    const float y_pos = alpha_p * xi * xi + beta * xi;
    const float min_v_eps = fminf(xi, eps);
    const float y_neg = (expm1f(min_v_eps) - xi) * alpha_n + beta * xi;
    const float out = gate_pos * y_pos + (1.0f - gate_pos) * y_neg;

    dst[i] = ggml_cuda_cast<T>(out);
}

template <typename T>
static void xielu_cuda(const T * x, T * dst, const int k, float alpha_n, float alpha_p, float beta, float eps, cudaStream_t stream) {
    const int num_blocks = (k + CUDA_XIELU_BLOCK_SIZE) / CUDA_XIELU_BLOCK_SIZE;
    xielu_kernel<<<num_blocks, CUDA_XIELU_BLOCK_SIZE, 0, stream>>>(x, dst, k, alpha_n, alpha_p, beta, eps);
}

void ggml_cuda_op_xielu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const void * src0_d = src0->data;
    void * dst_d = dst->data;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous(src0));

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);

    const float alpha_n = ggml_get_op_params_f32(dst, 1);
    const float alpha_p = ggml_get_op_params_f32(dst, 2);
    const float beta    = ggml_get_op_params_f32(dst, 3);
    const float eps     = ggml_get_op_params_f32(dst, 4);

    if (src0->type == GGML_TYPE_F16) {
        xielu_cuda((const half *)src0_d, (half *)dst_d, ggml_nelements(src0), alpha_n, alpha_p, beta, eps, stream);
    } else {
        xielu_cuda((const float *)src0_d, (float *)dst_d, ggml_nelements(src0), alpha_n, alpha_p, beta, eps, stream);
    }
}



/* silu_back */

static __device__ __forceinline__ float op_silu_back(float grad, float x) {
    const float s = 1.0f / (1.0f + expf(-x));
    return grad * s * (1.0f + x * (1.0f - s));
}

template <class T>
static __global__ void silu_back_kernel(const T * grad, const T * xf, T * dst, const int k) {
    const int i = blockDim.x*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    dst[i] = (T)op_silu_back((float)grad[i], (float)xf[i]);
}

template <class T>
static void silu_back_cuda(const T * grad, const T * x, T * dst, const int k, cudaStream_t stream) {
    const int num_blocks = (k + CUDA_SILU_BACK_BLOCK_SIZE - 1) / CUDA_SILU_BLOCK_SIZE;
    silu_back_kernel<<<num_blocks, CUDA_SILU_BACK_BLOCK_SIZE, 0, stream>>>(grad, x, dst, k);
}

void ggml_cuda_op_silu_back(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0]; // input from forward pass
    const ggml_tensor * src1 = dst->src[1]; // grads of forward pass output

    const float * src0_d = (const float *) src0->data;
    const float * src1_d = (const float *) src1->data;
    float       * dst_d  = (float       *) dst->data;

    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous(src0));

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);

    if (src0->type == GGML_TYPE_F16) {
        silu_back_cuda((const half *)src0_d, (const half *)src1_d, (half *)dst_d, ggml_nelements(src0), stream);
    } else {
        silu_back_cuda((const float*)src0_d, (const float*)src1_d, (float *)dst_d, ggml_nelements(src0), stream);
    }
}

/* leaky relu */

static __device__ __forceinline__ float op_leaky_relu(float x, const float negative_slope) {
    return fmaxf(x, 0) + fminf(x, 0.0f) * negative_slope;
}

template <class T>
static __global__ void leaky_relu_kernel(const T * x, T * dst, const int k, const float negative_slope) {
    const int i  = blockDim.x*blockIdx.x + threadIdx.x;

    if (i >= k) {
        return;
    }

    dst[i] = (T)op_leaky_relu((float)x[i], negative_slope);
}

template <class T>
static void leaky_relu_cuda(const T * x, T * dst, const int k, const float negative_slope, cudaStream_t stream) {
    const int num_blocks = (k + CUDA_RELU_BLOCK_SIZE - 1) / CUDA_RELU_BLOCK_SIZE;
    leaky_relu_kernel<<<num_blocks, CUDA_RELU_BLOCK_SIZE, 0, stream>>>(x, dst, k, negative_slope);
}

void ggml_cuda_op_leaky_relu(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    const ggml_tensor * src0 = dst->src[0];
    const void * src0_d = src0->data;
    void * dst_d = dst->data;
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous(src0));

    GGML_ASSERT(src0->type == GGML_TYPE_F32 || src0->type == GGML_TYPE_F16);
    GGML_ASSERT( dst->type == GGML_TYPE_F32 ||  dst->type == GGML_TYPE_F16);
    GGML_ASSERT(src0->type == dst->type);

    float negative_slope;
    memcpy(&negative_slope, dst->op_params, sizeof(float));

    if (src0->type == GGML_TYPE_F16) {
        leaky_relu_cuda((const half *)src0_d, (half *)dst_d, ggml_nelements(src0), negative_slope, stream);
    } else {
        leaky_relu_cuda((const float *)src0_d, (float *)dst_d, ggml_nelements(src0), negative_slope, stream);
    }
}

/* fused unary + mul */

template <float (*op)(float), bool round_unary = false>
static void ggml_cuda_op_unary_mul_impl(ggml_backend_cuda_context & ctx, ggml_tensor * unary_node, ggml_tensor * mul_node) {
    // unary_node: UNARY op applied to unary_node->src[0]
    // mul_node:   MUL(a, b) where one of a/b is unary_node
    // Output goes to mul_node->data

    const ggml_tensor * unary_src = unary_node->src[0];  // input to the unary op
    const ggml_tensor * other_src = (mul_node->src[0] == unary_node) ? mul_node->src[1] : mul_node->src[0];

    GGML_ASSERT(ggml_is_contiguous_1(unary_src));
    GGML_ASSERT(unary_src->nb[0] == ggml_element_size(unary_src));
    GGML_ASSERT(ggml_is_contiguous_1(other_src));
    GGML_ASSERT(other_src->nb[0] == ggml_element_size(other_src));
    GGML_ASSERT(ggml_are_same_shape(unary_src, other_src));

    GGML_ASSERT(unary_src->type == GGML_TYPE_F32 || unary_src->type == GGML_TYPE_F16 ||
                (round_unary && unary_src->type == GGML_TYPE_BF16));
    GGML_ASSERT(unary_src->type == other_src->type);
    GGML_ASSERT(unary_src->type == mul_node->type);

    cudaStream_t stream = ctx.stream();

    const int64_t k  = ggml_nelements(mul_node);
    const int64_t nc = unary_src->ne[0];
    const int64_t unary_stride = unary_src->nb[1];
    const int64_t other_stride = other_src->nb[1];

    if constexpr (round_unary) {
        if (unary_src->type == GGML_TYPE_BF16) {
            unary_gated_cuda<op, nv_bfloat16, true>((const nv_bfloat16 *) unary_src->data,
                (const nv_bfloat16 *) other_src->data, (nv_bfloat16 *) mul_node->data, k, nc,
                unary_stride / sizeof(nv_bfloat16), other_stride / sizeof(nv_bfloat16), stream);
            return;
        }
    }
    if (unary_src->type == GGML_TYPE_F16) {
        unary_gated_cuda<op, half, round_unary>((const half *) unary_src->data, (const half *) other_src->data,
                             (half *) mul_node->data, k, nc,
                             unary_stride / sizeof(half), other_stride / sizeof(half), stream);
    } else {
        unary_gated_cuda<op, float, round_unary>((const float *) unary_src->data, (const float *) other_src->data,
                             (float *) mul_node->data, k, nc,
                             unary_stride / sizeof(float), other_stride / sizeof(float), stream);
    }
}

void ggml_cuda_op_unary_mul(ggml_backend_cuda_context & ctx, ggml_tensor * unary_node, ggml_tensor * mul_node) {
    if (ggml_hyle_stable_silu(unary_node)) {
        GGML_ASSERT(unary_node->type == GGML_TYPE_F32 || unary_node->type == GGML_TYPE_BF16);
        ggml_cuda_op_unary_mul_impl<op_hyle_stable_silu, true>(ctx, unary_node, mul_node);
        return;
    }
    switch (ggml_get_unary_op(unary_node)) {
        case GGML_UNARY_OP_SILU:
            ggml_cuda_op_unary_mul_impl<op_silu>(ctx, unary_node, mul_node);
            break;
        case GGML_UNARY_OP_SIGMOID:
            ggml_cuda_op_unary_mul_impl<op_sigmoid>(ctx, unary_node, mul_node);
            break;
        case GGML_UNARY_OP_SOFTPLUS:
            ggml_cuda_op_unary_mul_impl<op_softplus>(ctx, unary_node, mul_node);
            break;
        default:
            GGML_ABORT("Unsupported unary op for fused unary+mul");
    }
}

/* fused relu + sqr */

void ggml_cuda_op_relu_sqr(ggml_backend_cuda_context & ctx, ggml_tensor * relu_node, ggml_tensor * sqr_node) {
    const ggml_tensor * src = relu_node->src[0];
    cudaStream_t stream = ctx.stream();

    GGML_ASSERT(ggml_is_contiguous(src));
    GGML_ASSERT(src->type == GGML_TYPE_F32 || src->type == GGML_TYPE_F16);
    GGML_ASSERT(src->type == sqr_node->type);

    const int k = ggml_nelements(src);
    if (src->type == GGML_TYPE_F16) {
        unary_cuda<op_relu_sqr>((const half *)src->data, (half *)sqr_node->data, k, stream);
    } else {
        unary_cuda<op_relu_sqr>((const float *)src->data, (float *)sqr_node->data, k, stream);
    }
}

/* BF16 dual projection + ordinary stable SiLU + explicit public rounding */

// These are four independent public BF16 boundaries, not the old GLU math.
// This instantiation belongs to the existing no-fast-math unary object.
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
struct hyle_bf16_dual_matvec_silu_epilogue {
    static __device__ __forceinline__ float apply(float up_sum, float gate_sum) {
        const float up = __bfloat162float(__float2bfloat16_rn(up_sum));
        const float gate = __bfloat162float(__float2bfloat16_rn(gate_sum));
        const float activation = op_hyle_stable_silu(gate);
        const float rounded_activation = __bfloat162float(__float2bfloat16_rn(activation));
        // The shared carrier's final BF16 RNE store supplies the Y boundary.
        return rounded_activation * up;
    }
};

static bool hyle_bf16_dual_matvec_overlaps(const ggml_tensor * read, const ggml_tensor * dst) {
    const auto read_begin = reinterpret_cast<std::uintptr_t>(read->data);
    const auto dst_begin = reinterpret_cast<std::uintptr_t>(dst->data);
    const auto read_bytes = ggml_nbytes(read), dst_bytes = ggml_nbytes(dst);
    const auto limit = std::numeric_limits<std::uintptr_t>::max();
    if (read_bytes > limit - read_begin || dst_bytes > limit - dst_begin) {
        return true;
    }
    return read_begin < dst_begin + dst_bytes && dst_begin < read_begin + read_bytes;
}
#endif

bool ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(
        const ggml_tensor * gate_mm, const ggml_tensor * up_mm,
        const ggml_tensor * silu, const ggml_tensor * dst, int device) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(gate_mm, up_mm, silu, dst, device);
    return false;
#else
    if (!gate_mm || !up_mm || !silu || !dst || gate_mm == up_mm ||
            gate_mm->op != GGML_OP_MUL_MAT || up_mm->op != GGML_OP_MUL_MAT ||
            ggml_get_op_params_i32(gate_mm, 0) != GGML_PREC_F32 ||
            ggml_get_op_params_i32(up_mm, 0) != GGML_PREC_F32 ||
            silu->op != GGML_OP_UNARY || !ggml_hyle_stable_silu(silu) ||
            silu->src[0] != gate_mm || dst->op != GGML_OP_MUL ||
            !((dst->src[0] == silu && dst->src[1] == up_mm) ||
              (dst->src[1] == silu && dst->src[0] == up_mm))) {
        return false;
    }
    const ggml_tensor * gate_weight = gate_mm->src[0];
    const ggml_tensor * up_weight = up_mm->src[0];
    const ggml_tensor * x = gate_mm->src[1];
    if (!gate_weight || !up_weight || !x || up_mm->src[1] != x ||
            device < 0 || device >= ggml_cuda_info().device_count) {
        return false;
    }
    const int cc = ggml_cuda_info().devices[device].cc;
    if (!GGML_CUDA_CC_IS_NVIDIA(cc) || !fast_bf16_hardware_available(cc)) {
        return false;
    }
    for (const auto * tensor : {gate_weight, up_weight, x, gate_mm, up_mm, silu, dst}) {
        if (tensor->type != GGML_TYPE_BF16 || !ggml_is_contiguous(tensor) ||
                tensor->ne[2] != 1 || tensor->ne[3] != 1) {
            return false;
        }
    }
    const auto k = gate_weight->ne[0], n = gate_weight->ne[1];
    // The original carrier uses int row*stride_row and int channel strides.
    // Bound the product too, not only each independent dimension.
    if (k <= 0 || k % 2 || n <= 0 || k > std::numeric_limits<int>::max() ||
            n > std::numeric_limits<int>::max() / k ||
            !ggml_are_same_shape(gate_weight, up_weight) ||
            x->ne[0] != k || x->ne[1] != 1 || x->nb[1] % sizeof(nv_bfloat162) ||
            gate_mm->ne[0] != n || gate_mm->ne[1] != 1 ||
            !ggml_are_same_shape(gate_mm, up_mm) ||
            !ggml_are_same_shape(gate_mm, silu) || !ggml_are_same_shape(gate_mm, dst)) {
        return false;
    }
    for (const auto * read : {gate_weight, up_weight, x}) {
        if (!read->data || !dst->data ||
                reinterpret_cast<std::uintptr_t>(read->data) % alignof(nv_bfloat162) ||
                hyle_bf16_dual_matvec_overlaps(read, dst)) {
            return false;
        }
    }
    if (reinterpret_cast<std::uintptr_t>(dst->data) % alignof(nv_bfloat16)) {
        return false;
    }
    return ggml_cuda_should_use_mmvf(gate_weight->type, cc,
               gate_weight->ne, gate_weight->nb, 1) &&
           ggml_cuda_should_use_mmvf(up_weight->type, cc,
               up_weight->ne, up_weight->nb, 1);
#endif
}

void ggml_cuda_op_bf16_dual_matvec_silu_mul(
        ggml_backend_cuda_context & ctx, const ggml_tensor * gate_mm,
        const ggml_tensor * up_mm, const ggml_tensor * silu, ggml_tensor * dst) {
    GGML_ASSERT(ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate_mm, up_mm, silu, dst, ctx.device));
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const ggml_tensor * gate_weight = gate_mm->src[0];
    const ggml_tensor * up_weight = up_mm->src[0];
    const ggml_tensor * x = up_mm->src[1];
    const auto element_bytes = sizeof(nv_bfloat16);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = gate_weight->data;
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, 1, false,
        nv_bfloat16, nv_bfloat16, hyle_bf16_dual_matvec_silu_epilogue>(
            static_cast<const nv_bfloat16 *>(up_weight->data),
            static_cast<const nv_bfloat16 *>(x->data), nullptr, fusion,
            static_cast<nv_bfloat16 *>(dst->data), up_weight->ne[0], up_weight->ne[1],
            up_weight->nb[1] / element_bytes, x->nb[1] / element_bytes, dst->nb[1] / element_bytes,
            1, 1, 1, up_weight->nb[2] / element_bytes, x->nb[2] / element_bytes, dst->nb[2] / element_bytes,
            1, 1, up_weight->nb[3] / element_bytes, x->nb[3] / element_bytes, dst->nb[3] / element_bytes,
            1, 0, ctx.stream());
#else
    GGML_UNUSED_VARS(ctx, gate_mm, up_mm, silu, dst);
#endif
}


/* explicit-frequency RoPE, preserving the existing decomposed graph */

#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
// The old binary nodes are separate fast-math kernels. Preserve their exact
// RN/FTZ operations in this precise TU; intrinsics without FTZ would change
// subnormal behavior, and a C++ expression could accidentally contract to FMA.
static __device__ __forceinline__ float hyle_rope_mul(float a, float b) {
    float result;
    asm("mul.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

static __device__ __forceinline__ float hyle_rope_add(float a, float b) {
    float result;
    asm("add.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

static __device__ __forceinline__ float hyle_rope_sub(float a, float b) {
    float result;
    asm("sub.rn.ftz.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    return result;
}

template <typename T>
static __global__ void hyle_explicit_rope(
        const T * data, const int32_t * positions, const float * frequencies, T * dst,
        int64_t width, int64_t heads, int64_t sequence, int64_t batch,
        int64_t dimensions, int64_t position_batches, int64_t frequency_sequences,
        bool interleaved, int64_t rotated_work, int64_t tail_elements, int64_t work) {
    ggml_cuda_pdl_lc();
    // One warp owns a phase. Trigonometry is evaluated once and reused by
    // every head (and by every B when positions are shared), without scratch.
    // All lanes reach the full-mask shuffles, including when heads < 32.
    const int lane = threadIdx.x;
    const int64_t pairs = dimensions / 2;
    ggml_cuda_pdl_sync();
    for (int64_t unit = blockIdx.x; unit < work; unit += gridDim.x) {
        if (unit < rotated_work) {
            const int64_t pair = unit % pairs;
            const int64_t row = unit / pairs;
            const int64_t s = row % sequence;
            const int64_t position_batch = row / sequence;
            float cosine = 0.0f, sine = 0.0f;
            if (lane == 0) {
                // Match cast(I32->F32), then frequency * position, in that
                // order. Do not keep the position as an exact integer longer.
                const float p = __int2float_rn(positions[s + sequence * position_batch]);
                const float f = frequencies[pair + pairs * (frequency_sequences == 1 ? 0 : s)];
                const float phase = hyle_rope_mul(f, p);
                // Separate strict full-range functions, as in old Unary.
                cosine = op_cos(phase);
                sine = op_sin(phase);
            }
            cosine = __shfl_sync(0xffffffffu, cosine, 0);
            sine = __shfl_sync(0xffffffffu, sine, 0);
            const int64_t row_heads = heads * (position_batches == 1 ? batch : 1);
            const int64_t first_component = interleaved ? 2 * pair : pair;
            const int64_t second_component = interleaved ? first_component + 1 : pair + pairs;
            for (int64_t h = lane; h < row_heads; h += 32) {
                const int64_t b = position_batches == 1 ? h / heads : position_batch;
                const int64_t head = h % heads;
                const int64_t base = width * (head + heads * (s + sequence * b));
                // Both loads precede both stores: exact dense allocator reuse
                // is safe, while partial aliases are rejected before launch.
                const float first = ggml_cuda_cast<float>(data[base + first_component]);
                const float second = ggml_cuda_cast<float>(data[base + second_component]);
                const float first_cosine = hyle_rope_mul(first, cosine);
                const float second_sine = hyle_rope_mul(second, sine);
                const float first_sine = hyle_rope_mul(first, sine);
                const float second_cosine = hyle_rope_mul(second, cosine);
                const float rotated_first = hyle_rope_sub(first_cosine, second_sine);
                const float rotated_second = hyle_rope_add(first_sine, second_cosine);
                dst[base + first_component] = ggml_cuda_cast<T>(rotated_first);
                dst[base + second_component] = ggml_cuda_cast<T>(rotated_second);
            }
        } else {
            const int64_t tail = width - dimensions;
            const int64_t linear = (unit - rotated_work) * 32 + lane;
            if (linear < tail_elements) {
                const int64_t offset = (linear / tail) * width + dimensions + linear % tail;
                if constexpr (std::is_same_v<T, float>) {
                    // Old F32 CONT/CONCAT tail is a copy, including NaN bits.
                    dst[offset] = data[offset];
                } else {
                    // The old graph widens the complete data tensor and then
                    // narrows the completed output. Keep that NaN/RNE boundary.
                    const float widened = ggml_cuda_cast<float>(data[offset]);
                    float converted;
                    // Opaque identity prevents folding the two conversions
                    // to a raw typed copy, which would retain signaling NaNs.
                    asm("mov.b32 %0, %1;" : "=f"(converted) : "f"(widened));
                    dst[offset] = ggml_cuda_cast<T>(converted);
                }
            }
        }
    }
}

static bool hyle_rope_dense_bytes(const ggml_tensor * tensor, size_t & bytes) {
    if (!tensor) {
        return false;
    }
    const size_t type_bytes = ggml_type_size(tensor->type);
    if (type_bytes == 0 || ggml_blck_size(tensor->type) != 1) {
        return false;
    }
    size_t extent = type_bytes;
    for (int d = 0; d < GGML_MAX_DIMS; ++d) {
        if (tensor->ne[d] <= 0 || tensor->nb[d] != extent ||
                uint64_t(tensor->ne[d]) > std::numeric_limits<size_t>::max() / extent) {
            return false;
        }
        extent *= size_t(tensor->ne[d]);
    }
    // All device index products below are signed int64_t, including tails.
    if (extent / type_bytes > uint64_t(std::numeric_limits<int64_t>::max())) {
        return false;
    }
    bytes = extent;
    return true;
}

static bool hyle_rope_range(const ggml_tensor * tensor, size_t bytes,
        uintptr_t & begin, uintptr_t & end) {
    begin = reinterpret_cast<uintptr_t>(tensor->data);
    if (!begin || begin % ggml_type_size(tensor->type) ||
            bytes > std::numeric_limits<uintptr_t>::max() - begin) {
        return false;
    }
    end = begin + bytes;
    return true;
}
#endif

bool ggml_cuda_supports_hyle_explicit_rope(const ggml_tensor * dst, int device, bool require_bound) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(dst, device, require_bound);
    return false;
#else
    using namespace hyle::compute::ggml_cuda::internal;
    if (!ggml_cuda_is_hyle_explicit_rope(dst) || !dst->src[0] || !dst->src[1] || !dst->src[2] ||
            device < 0 || device >= ggml_cuda_info().device_count ||
            !GGML_CUDA_CC_IS_NVIDIA(ggml_cuda_info().devices[device].cc)) {
        return false;
    }
    const auto * data = dst->src[0];
    const auto * positions = dst->src[1];
    const auto * frequencies = dst->src[2];
    if ((data->type != GGML_TYPE_F32 && data->type != GGML_TYPE_F16 && data->type != GGML_TYPE_BF16) ||
            dst->type != data->type || positions->type != GGML_TYPE_I32 || frequencies->type != GGML_TYPE_F32 ||
            !ggml_are_same_layout(data, dst)) {
        return false;
    }
    for (int s = 3; s < GGML_MAX_SRC; ++s) {
        if (dst->src[s]) {
            return false;
        }
    }
    // No YaRN factors, offsets or other upstream parameters share this ABI.
    for (size_t p = 3 * sizeof(int32_t); p < sizeof(dst->op_params); ++p) {
        if (reinterpret_cast<const uint8_t *>(dst->op_params)[p] != 0) {
            return false;
        }
    }
    const int64_t pairs = frequencies->ne[0];
    const int layout = ggml_get_op_params_i32(dst, kExplicitRopeLayoutParam);
    if (ggml_get_op_params_i32(dst, 1) != 0 || pairs <= 0 || pairs > data->ne[0] / 2 ||
            (layout != GGML_ROPE_TYPE_NORMAL && layout != GGML_ROPE_TYPE_NEOX) ||
            positions->ne[0] != data->ne[2] ||
            (positions->ne[1] != 1 && positions->ne[1] != data->ne[3]) ||
            positions->ne[2] != 1 || positions->ne[3] != 1 ||
            (frequencies->ne[1] != 1 && frequencies->ne[1] != data->ne[2]) ||
            frequencies->ne[2] != 1 || frequencies->ne[3] != 1) {
        return false;
    }
    const ggml_tensor * tensors[] = {data, positions, frequencies, dst};
    size_t sizes[4] = {};
    uintptr_t begin[4] = {}, end[4] = {};
    for (int i = 0; i < 4; ++i) {
        if (!hyle_rope_dense_bytes(tensors[i], sizes[i]) ||
                (require_bound && !hyle_rope_range(tensors[i], sizes[i], begin[i], end[i]))) {
            return false;
        }
    }
    if (require_bound) {
        for (int i = 0; i < 3; ++i) {
            const bool overlaps = begin[i] < end[3] && begin[3] < end[i];
            // GGML's allocator may reuse a private, sole-reader input. Keep
            // exactly that mapping, never a partial x alias or pos/freq alias.
            if (overlaps && !(i == 0 && begin[0] == begin[3])) {
                return false;
            }
        }
    }
    return true;
#endif
}

void ggml_cuda_op_hyle_explicit_rope(ggml_backend_cuda_context & ctx, ggml_tensor * dst) {
    if (!ggml_cuda_supports_hyle_explicit_rope(dst, ctx.device, true)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
            "invalid explicit-frequency RoPE tensor contract");
    }
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    using namespace hyle::compute::ggml_cuda::internal;
    const auto * data = dst->src[0];
    const auto * positions = dst->src[1];
    const auto * frequencies = dst->src[2];
    const int64_t dimensions = 2 * frequencies->ne[0];
    const bool interleaved = ggml_get_op_params_i32(dst, kExplicitRopeLayoutParam) == GGML_ROPE_TYPE_NORMAL;
    const int64_t rotated_work = (dimensions / 2) * data->ne[2] * positions->ne[1];
    const int64_t tail_elements = (data->ne[0] - dimensions) * data->ne[1] * data->ne[2] * data->ne[3];
    const int64_t tail_work = tail_elements / 32 + (tail_elements % 32 != 0);
    if (rotated_work > std::numeric_limits<int64_t>::max() - tail_work) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
            "explicit-frequency RoPE work extent overflow");
    }
    const int64_t work = rotated_work + tail_work;
    const unsigned int blocks = unsigned(std::min<int64_t>(work, 65535));
    const auto launch = [&](auto * typed_dst) {
        using T = std::remove_pointer_t<decltype(typed_dst)>;
        const ggml_cuda_kernel_launch_params launch_params(dim3(blocks), 32, 0, ctx.stream());
        ggml_cuda_kernel_launch(hyle_explicit_rope<T>, launch_params,
            static_cast<const T *>(data->data), static_cast<const int32_t *>(positions->data),
            static_cast<const float *>(frequencies->data), typed_dst,
            data->ne[0], data->ne[1], data->ne[2], data->ne[3], dimensions,
            positions->ne[1], frequencies->ne[1], interleaved, rotated_work, tail_elements, work);
    };
    switch (dst->type) {
        case GGML_TYPE_F32: launch(static_cast<float *>(dst->data)); break;
        case GGML_TYPE_F16: launch(static_cast<half *>(dst->data)); break;
        case GGML_TYPE_BF16: launch(static_cast<nv_bfloat16 *>(dst->data)); break;
        default: hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue,
                     "unsupported explicit-frequency RoPE output type");
    }
#else
    GGML_UNUSED_VARS(ctx, dst);
#endif
}
