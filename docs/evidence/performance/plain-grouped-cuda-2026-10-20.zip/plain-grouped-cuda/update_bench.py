"""Add optional measured CPU affinity; reuse every product/native object."""
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "plain_grouped_affinity_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = stage / "checks/native1"
old = c.read(stage / "checks/before/bench-identity.json")
assert b.identity(stage / "bench-unpinned.cc")["sha256"] == old["source"]["sha256"]
source = stage / "bench.cc"
command = b.host_command(old["command"], source, "bench-pinned", out)
base = c.read(out / "control-link-plan.json")
env, _ = b.environment(base["command"], [r["path"] for r in base["inputs"]], out)
before = b.identity(source)
c.execute("bench-pinned-compile", command, env, out)
assert b.same(before)
obj = b.identity(out / "bench-pinned.obj")
dep = c.read(out / "bench-pinned-deps.json")["Data"]
c.save(out / "bench-pinned-identity.json", dict(command=command, source=before, object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([dep["Source"], *dep["Includes"]])]))
preserve = out / "before-affinity"
preserve.mkdir(exist_ok=False)
for arm in ("control", "new"):
    for suffix in ("image.json", "link-plan.json"):
        shutil.copyfile(out / (arm + "-" + suffix), preserve / (arm + "-" + suffix))
    link = c.read(out / (arm + "-link-plan.json"))
    assert sum(c.key(r["path"]) == c.key(old["object"]["path"]) for r in link["inputs"]) == 1
    lookup = {c.key(r["path"]):r for r in link["inputs"]}
    lookup[c.key(obj["path"])] = obj
    args = [obj["path"] if c.key(arg) == c.key(old["object"]["path"]) else arg for arg in link["command"]]
    c.execute(arm + "-pinned-link", args, env, out)
    inputs = [arg for arg in args if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
    c.save(out / (arm + "-link-plan.json"), dict(command=args, inputs=[lookup[c.key(p)] for p in inputs]))
    c.save(out / (arm + "-image.json"), b.identity(out / (arm + ".exe")))
plan = c.read(out / "plan.json")
plan["frozen"].append(before)
snapshot = out / "compiled-source/bench-pinned.cc"
shutil.copyfile(source, snapshot)
plan["compile"].append(dict(tag="bench-pinned", kind="host", source=before,
    command=command, object=obj["path"]))
c.save(out / "plan.json", plan)
print("PLAIN_GROUPED_PINNED_BENCH_BUILT", flush=True)
