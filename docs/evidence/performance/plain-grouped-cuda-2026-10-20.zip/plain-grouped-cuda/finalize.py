"""Archive the actual numerical failure, native fix and bounded matched result."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
stage = Path(__file__).resolve().parent
root = stage.parents[2]
build = stage / "checks/native1"

def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+"\n", encoding="utf-8")
def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def matches(item):
    path=Path(item["path"])
    return path.is_file() and identity(path)==item

tests=read(stage/"runs/first-actual/summary.json")
pair=read(stage/"paired-pinned-results.json")
initial_pair=read(stage/"paired-results.json")
trace=read(stage/"profile-analysis.json")
sass=read(stage/"sass-math-check.json")
freeze=read(stage/"native-source-freeze.json")
assert tests["passed"] and tests["cases"]==6 and tests["skipped"]==0
assert pair["passed"] and trace["passed"] and sass["passed"]
assert len(sass["strict_instantiations"])==16
for row in freeze["files"]:
    assert matches(row["before"]) and matches(row["after"])
for item in freeze["product_files"]: assert matches(item), item
assert matches(freeze["fallback_control"])
for item in read(build/"plan.json")["frozen"]: assert matches(item), item
for arm in ("control","new","tests"):
    assert matches(read(build/(arm+"-image.json")))
    for item in read(build/(arm+"-link-plan.json"))["inputs"]: assert matches(item),item
for row in pair["runs"]:
    assert row["caller_cpu"]==2 and row["passed"] and matches(row["image"])
    assert row["unit_precision_witness"] and row["subnormal_product_witness"]
for arm in ("control","new"):
    assert read(stage/"runs"/(arm+"-larger-T9")/"summary.json")["passed"]
assert read(stage/"runs/before-witness/bench.result.json")["exit"]==1
old_bench=read(stage/"checks/before/bench-identity.json")
assert identity(stage/"bench-unpinned.cc")["sha256"]==old_bench["source"]["sha256"]
docs=read(stage/"docs-result.json")
# Document source keys are relative to the product checkout.
for item in docs["files"]:
    actual=identity(root/item["path"])
    assert actual["sha256"]==item["sha256"]
products=["third_party/ggml_cuda_runtime/patches.json","third_party/ggml_cuda_runtime/NOTICE.md",
    "cmake/HyleDependencyLock.json","tests/graph_route_cuda/grouped_shared_activation_test.cc",
    "docs/user/compute.md","docs/implementation/model-operators.md","docs/developer/current-work.md"]
diff=subprocess.run(["git","diff","--check","--",*products],cwd=root,capture_output=True,text=True)
save(stage/"diff-check.json",dict(command=diff.args,exit=diff.returncode,stdout=diff.stdout,stderr=diff.stderr))
assert diff.returncode==0
save(stage/"root-final-check.json",dict(passed=True,recorded_utc=datetime.now(timezone.utc).isoformat(),
    native_freeze=identity(stage/"native-source-freeze.json"),
    independent_review=identity(stage/"native-independent-review.json"),
    tests=tests, final_images={arm:read(build/(arm+"-image.json")) for arm in ("control","new","tests")},
    product_files=[identity(root/p) for p in products], full_goal_status="active",
    scope="This ordinary CUDA grouped native batch only; no updated full-Qwen benchmark"))

destination=root/"docs/evidence/performance/plain-grouped-cuda-2026-10-20.zip"
assert not destination.exists()
suffixes={".json",".cc",".cu",".h",".cuh",".py",".md",".diff",".txt",".xml",".log",".d",".nsys-rep",".sqlite"}
selected={}
for path in stage.rglob("*"):
    if path.is_file() and path.suffix.lower() in suffixes and "tmp" not in path.relative_to(stage).parts:
        if path.name=="mmvf.sass.txt": continue # 47MB mostly unrelated default kernels; keep exact strict entries.
        selected["plain-grouped-cuda/"+path.relative_to(stage).as_posix()]=path
for row in read(stage/"native-header-closure.json")["headers"]:
    source=Path(row["source"])
    assert identity(source)["sha256"]==row["sha256"]
    selected["native-headers/"+row["path"]]=source
for rel in products+[
    "tests/compute_models/grouped_shared_activation_fixture.h", "tests/compute_models/gguf_nvfp4_fixture.h",
    "src/compute_provider_ggml_cuda/tensor_program.cc", "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
    "src/compute_provider_ggml_cuda/index_guard.cu", "include/hyle/compute/model_ops.h",
    "include/hyle/platform/thread.h"]:
    source=root/rel
    if source.is_file(): selected["product/"+rel]=source
manifest={name:dict(bytes=path.stat().st_size,sha256=identity(path)["sha256"]) for name,path in sorted(selected.items())}
with zipfile.ZipFile(destination,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(selected.items()): z.write(path,name)
    z.writestr("manifest.json",json.dumps(manifest,indent=2)+"\n")
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    for name,item in manifest.items():
        payload=z.read(name)
        assert len(payload)==item["bytes"] and hashlib.sha256(payload).hexdigest()==item["sha256"]
archive=dict(**identity(destination),payload_files=len(manifest),CRC_and_payload_hashes_verified=True,
    SDK_executable_object_or_library_payloads=False,actual_profiler_traces_included=True)
report=dict(passed=True,recorded_utc=datetime.now(timezone.utc).isoformat(),
    scope="Plain NVIDIA CUDA grouped small-token execution and precision propagation; not completion of the full architecture goal",
    changes=["Existing GPU-ID MMVF carrier selected by common dispatch/capture qualification; no new public operator, Provider or executor",
        "Preserve shared or independent activation, repeated experts, checked safe IDs, guarded publication and original Completion failure/recovery",
        "New NVIDIA F32-ID no-fusion specialization uses explicit no-FTZ FMA and same-tree additions, retaining old default-false math",
        "Restore actual parent accumulator and source-1 precision in fallback expert temporary; original memset had silently dropped both",
        "Actual layout/indexing/pair alignment and initialized device launch limits qualify the new domain; other domains retain original decomposition"],
    native=dict(version=freeze["version"],source_id=freeze["source_id"],
        source_freeze=identity(stage/"native-source-freeze.json"),private_header_owners=freeze["native_TUs_requiring_refresh"]),
    hardware=read(stage/"goal-turn.json")["GPU_inventory"],
    verification=dict(public_grouped_TESTs_passed=6,skipped=0,actual_final_image=tests["image"],
        SM89_strict_SASS_instantiations_without_FTZ=16,PTX_claim=False,
        refreshed_native_owner_compiles=4,refreshed_product_host_owners=1,refreshed_test_TUs=1,
        benchmark_TUs=2,shared_SDK_rebuilt=False),
    prior_failure=dict(expected_F32_bits="0x3f800008",actual_bits="0x3f800000",exit=1,
        cause="Fallback expert destination temporary lost parent accumulator/src1 precision markers",
        disposition="Preserved as numerical counterexample; excluded from all accepted speed comparisons"),
    comparison=dict(input=pair["input"],caller_cpu=2,boundary=pair["boundary"],counts=pair["counts"],
        shared_inputs_except_main=133,control="Precision-fixed original sorting fallback; same new MMVF/unary/provider/benchmark objects as candidate",
        per_process_median_us=pair["per_process_median_us"],
        median_of_process_medians_us=pair["median_of_process_medians_us"],
        latency_reduction_fraction=1-pair["latency_ratio_new_over_control"],
        unpinned_initial_series=initial_pair["per_process_median_us"],
        qualification="Fixed CPU and fuller warmup reduce scheduling ambiguity; magnitude is sensitive to host configuration, not a generic engine speedup"),
    physical_trace=dict(scope=trace["scope"],control_kernels=6,new_kernels=3,
        native_operation_stream_syncs_before=2,native_operation_stream_syncs_after=0,
        removed_full_ID_D2H_bytes=16,removed_mapping_H2D_bytes=32,
        retained_Completion_status_D2H_bytes=4,
        removed_native_sorting_storage_for_fixture_bytes=40992,
        removed_storage_formula=trace["removed_native_sorting_temporaries_formula"],
        caller_workspace_bytes_both=8192,
        interpretation="Sorting-storage count is source-derived before pool rounding; caller workspace is unchanged; no total memory peak claimed"),
    larger_T_control="T9 control and candidate exact unit/subnormal witnesses pass; native host sorting and synchronization still remain there",
    limitations=["One small synthetic grouped workload; no selected model throughput/quality, updated Qwen tokens/s or total memory peak",
        "GPU power/clocks not locked; retain both unpinned and pinned process measurements and their spread",
        "BF16 expert-bank cold F32 widening remains; ordinary non-ID MMVF default fast-math behavior is unchanged",
        "Larger-T/general exact-F32 indirect grouped matrix carrier remains required to remove its native sorting banks and host synchronization",
        "Windows RTX4070/SM89 executed; no new Linux/Apple run or exhaustive shape/dtype/device claim"],
    evidence_archive=archive,full_goal_status="active")
public=root/"docs/evidence/performance/plain-grouped-cuda-2026-10-20.json"
save(public,report)
save(stage/"publication.json",dict(archive=archive,report=identity(public)))
print(json.dumps(dict(passed=True,payload_files=len(manifest),archive_bytes=archive["bytes"],
    tests=6,control_us=151.6,new_us=58.6)))
