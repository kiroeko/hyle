"""Refresh only affected native TUs; share all other objects and the SDK cache."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
root = stage.parents[2]
spec = importlib.util.spec_from_file_location(
    "plain_grouped_native_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
p = argparse.ArgumentParser()
p.add_argument("--out", type=Path, required=True)
p.add_argument("--headers", type=Path, required=True)
p.add_argument("--control-main", type=Path, required=True)
p.add_argument("--main", type=Path, required=True)
p.add_argument("--build", action="store_true")
p.add_argument("--reuse", type=Path)
args = p.parse_args()
out, headers = args.out.resolve(), args.headers.resolve()
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
inventory = c.read(stage / "build-inventory.json")
base = c.read(inventory["base"])
before = c.read(stage / "checks/before/link-plan.json")
recipes = inventory["native_owners"]
native_freeze = c.read(stage / "native-source-freeze.json")
base_headers = Path(native_freeze["header_root"])
header_closure = c.read(stage / "native-header-closure.json")["headers"]

def strip_ccbin(command):
    result, skip = [], False
    for arg in command:
        if skip:
            skip = False
        elif arg in ("-ccbin", "--compiler-bindir"):
            skip = True
        elif not arg.startswith(("-ccbin=", "--compiler-bindir=")):
            result.append(arg)
    return result

rows = []
for tag, name, source in [
    ("main-control", "ggml-cuda.cu", args.control_main.resolve()),
    ("main-new", "ggml-cuda.cu", args.main.resolve()),
    ("mmvf", "mmvf.cu", headers / "src/ggml-cuda/mmvf.cu"),
    ("unary", "unary.cu", headers / "src/ggml-cuda/unary.cu")]:
    original = recipes[name]
    command = b.native_command(strip_ccbin(original["command"]), source, tag, out)
    command = [arg for arg in command if not (arg.startswith("-I") and
        (".scratch" in arg or "reference-windows" in arg))]
    command[1:1] = ["-I" + str(directory / name) for directory in (headers, base_headers)
                    for name in ("src/ggml-cuda", "src", "include")]
    command.insert(1, "-I" + str(root / "src/compute_provider_ggml_cuda"))
    rows.append(dict(tag=tag, kind="native", source=b.identity(source), command=command,
        object=str(out / (tag + ".obj")), old_object=original["old_object"]))
test_source = root / "tests/graph_route_cuda/grouped_shared_activation_test.cc"
test_recipe = c.read(stage.parent / "ct-packed-linear/build-inventory.json")["owners"][
    "tests/graph_route_cuda/grouped_shared_activation_test.cc"]
command = b.host_command(test_recipe["command"], test_source, "grouped-test", out)
command[1:1] = ["/external:I" + str(directory / name) for directory in (headers, base_headers)
                for name in ("include", "src")]
rows.append(dict(tag="grouped-test", kind="host", source=b.identity(test_source),
    command=command, object=str(out / "grouped-test.obj")))
frozen = [b.identity(path) for path in headers.rglob("*") if path.is_file()]
for item in header_closure:
    actual = b.identity(item["source"])
    assert actual["bytes"] == item["bytes"] and actual["sha256"] == item["sha256"]
    frozen.append(actual)
frozen += [row["source"] for row in rows]
frozen += [b.identity(root / name) for name in (
    "third_party/ggml_cuda_runtime/patches.json", "third_party/ggml_cuda_runtime/NOTICE.md",
    "cmake/HyleDependencyLock.json")]
frozen += [b.identity(stage / name) for name in ("native-source-freeze.json", "tests-source-freeze.json")]
for item in frozen:
    source = Path(item["path"])
    if source.is_relative_to(root):
        target = out / "compiled-source" / source.relative_to(root)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
plan = dict(compile=rows, frozen=frozen, headers=str(headers), baseline=inventory["base"],
    actual_shared_header_control="Both controls link the same refreshed MMVF/unary; only main dispatch differs, both retain explicit fallback precision", SDK_build=False)
c.save(out / "plan.json", plan)
print("PLAIN_GROUPED_PLAN", out, "native", 4, "host", 1, flush=True)
if not args.build:
    raise SystemExit(0)

def check():
    for item in frozen:
        assert b.same(item), item["path"]
check()
for item in base["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(base["command"], [row["path"] for row in base["inputs"]], out)
c.save(out / "runtime-environment.json", dict(runtime=runtime, PATH=env["PATH"]))

def compile_one(row):
    if args.reuse:
        receipt = args.reuse.resolve() / (row["tag"] + "-identity.json")
        if receipt.is_file():
            previous = c.read(receipt)
            old_out = Path(previous["object"]["path"]).parent
            normalize = lambda command, directory: [arg.replace(str(directory), "<OUT>") for arg in command]
            if (normalize(previous["command"], old_out) == normalize(row["command"], out)
                    and b.same(previous["source"]) and b.same(previous["object"])
                    and all(b.same(dep) for dep in previous["dependencies"])):
                c.save(out / (row["tag"] + "-identity.json"), previous)
                return row["tag"], previous
    c.execute(row["tag"] + "-compile", row["command"], env, out)
    check()
    if row["kind"] == "host":
        dep = c.read(out / (row["tag"] + "-deps.json"))["Data"]
        deps = [b.identity(path) for path in dict.fromkeys([dep["Source"], *dep["Includes"]])]
    else:
        paths = [row["source"]["path"]]
        for line in (out / (row["tag"] + ".d")).read_text().splitlines()[1:]:
            path = line.strip().removesuffix("\\").strip().replace("\\ ", " ")
            if path:
                assert Path(path).is_file(), path
                paths.append(path)
        deps = [b.identity(path) for path in dict.fromkeys(paths)]
    result = dict(command=row["command"], source=row["source"],
        object=b.identity(row["object"]), dependencies=deps)
    c.save(out / (row["tag"] + "-identity.json"), result)
    return row["tag"], result

finished, errors = {}, []
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    pending = [pool.submit(compile_one, row) for row in rows]
    for future in concurrent.futures.as_completed(pending):
        try:
            tag, result = future.result(); finished[tag] = result
        except BaseException as error:
            errors.append(repr(error))
c.save(out / "compile-summary.json", dict(passed=not errors, native_owners=4,
    host_test_owners=1, SDK_build=False, errors=errors))
if errors:
    raise SystemExit("Inspect retained actual compile errors: " + repr(errors))

original_tests = {c.key(row["old_object"]["path"]) for row in inventory["current_test_owners"]}
for arm, linkbase in (("control", before), ("new", before), ("tests", base)):
    replacements = {}
    for name, tag in (("ggml-cuda.cu", "main-control" if arm == "control" else "main-new"),
                      ("mmvf.cu", "mmvf"), ("unary.cu", "unary")):
        replacements[c.key(recipes[name]["old_object"]["path"])] = finished[tag]["object"]
    lookup = {c.key(item["path"]): item for item in linkbase["inputs"]}
    lookup.update({c.key(item["object"]["path"]): item["object"] for item in finished.values()})
    command = []
    for arg in linkbase["command"]:
        if arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:")):
            continue
        if arm == "tests" and c.key(arg) in original_tests:
            continue
        command.append(replacements[c.key(arg)]["path"] if c.key(arg) in replacements else arg)
    if arm == "tests":
        command.insert(1, finished["grouped-test"]["object"]["path"])
    image = out / (arm + ".exe")
    command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
                "/IMPLIB:" + str(image.with_suffix(".lib"))]
    inputs = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
    assert len(inputs) == len(set(map(c.key, inputs)))
    for path in inputs:
        assert b.same(lookup[c.key(path)]), path
    c.execute(arm + "-link", command, env, out)
    check()
    c.save(out / (arm + "-link-plan.json"), dict(command=command, inputs=[lookup[c.key(p)] for p in inputs]))
    c.save(out / (arm + "-image.json"), b.identity(image))
print("PLAIN_GROUPED_BUILT", out, flush=True)
