"""Refresh the actual provider version owner, retaining every compiled native object."""
import argparse
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
root = stage.parents[2]
spec = importlib.util.spec_from_file_location(
    "plain_grouped_provider_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
p = argparse.ArgumentParser(); p.add_argument("--build", type=Path, required=True)
out = p.parse_args().build.resolve()
inventory = c.read(stage / "build-inventory.json")
recipe = inventory["provider_owner"]
assert recipe
source = root / "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc"
version = stage / "provider-version.h"
command = b.host_command(recipe["command"], source, "ggml-provider", out)
command = ["/FI" + str(version) if arg.lower().startswith("/fi") and
    Path(arg[3:]).name == "provider-version.h" else arg for arg in command]
if not any(arg == "/FI" + str(version) for arg in command):
    command.insert(1, "/FI" + str(version))
base = c.read(out / "control-link-plan.json")
env, runtime = b.environment(base["command"], [r["path"] for r in base["inputs"]], out)
before = b.identity(source)
c.execute("ggml-provider-compile", command, env, out)
assert b.same(before)
obj = b.identity(out / "ggml-provider.obj")
dep = c.read(out / "ggml-provider-deps.json")["Data"]
receipt = dict(command=command, source=before, object=obj,
    dependencies=[b.identity(path) for path in dict.fromkeys([dep["Source"], *dep["Includes"]])])
c.save(out / "ggml-provider-identity.json", receipt)
old = out / "before-provider-version"
old.mkdir(exist_ok=False)
for arm in ("control", "new", "tests"):
    for suffix in ("image.json", "link-plan.json"):
        shutil.copyfile(out / (arm + "-" + suffix), old / (arm + "-" + suffix))
    link = c.read(out / (arm + "-link-plan.json"))
    original = recipe["old_object"]
    assert sum(c.key(r["path"]) == c.key(original["path"]) for r in link["inputs"]) == 1
    lookup = {c.key(r["path"]): r for r in link["inputs"]}
    lookup[c.key(obj["path"])] = obj
    args = [obj["path"] if c.key(arg) == c.key(original["path"]) else arg for arg in link["command"]]
    for item in link["inputs"]:
        assert b.same(item), item["path"]
    c.execute(arm + "-provider-link", args, env, out)
    inputs = [arg for arg in args if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
    c.save(out / (arm + "-link-plan.json"), dict(command=args, inputs=[lookup[c.key(p)] for p in inputs]))
    c.save(out / (arm + "-image.json"), b.identity(out / (arm + ".exe")))
plan = c.read(out / "plan.json")
plan["compile"].append(dict(tag="ggml-provider", kind="host", source=before, command=command,
    object=obj["path"], old_object=recipe["old_object"]))
for item in (before, b.identity(version)):
    plan["frozen"].append(item)
    snap = out / "compiled-source" / Path(item["path"]).relative_to(root)
    snap.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(item["path"], snap)
c.save(out / "plan.json", plan)
c.save(out / "provider-update.json", dict(passed=True, actual_identity_macro=version.read_text(),
    source=before, object=obj, fresh_host_owners=1, fresh_native_owners=0,
    preceding_image_receipts=str(old), SDK_build=False))
print("PLAIN_GROUPED_PROVIDER_UPDATED", out, flush=True)
