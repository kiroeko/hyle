"""Check the physical copies/syncs between existing ID check and publication."""
from collections import Counter
import json
from pathlib import Path
import sqlite3
stage = Path(__file__).resolve().parent
arms = {}
for arm, expected_kernels in (("control", 6), ("new", 3)):
    path = stage / "profile" / arm / "trace.sqlite"
    conn = sqlite3.connect(path); conn.row_factory = sqlite3.Row
    def rows(query): return [dict(row) for row in conn.execute(query)]
    kernels = rows("SELECT k.start,k.end,k.correlationId,k.streamId,s.value AS name "
        "FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName ORDER BY k.start")
    copies = rows("SELECT bytes,copyKind,start,end,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start")
    api = rows("SELECT r.start,r.end,r.correlationId,s.value AS name FROM CUPTI_ACTIVITY_KIND_RUNTIME r "
        "JOIN StringIds s ON s.id=r.nameId ORDER BY r.start")
    assert len(kernels) == expected_kernels
    assert "::check(" in kernels[0]["name"] and "::publish(" in kernels[-1]["name"]
    begin,end = kernels[0]["start"],kernels[-1]["end"]
    overlap = lambda row: row["start"] < end and row["end"] > begin
    operation_copies = [row for row in copies if overlap(row)]
    syncs = [row for row in api if "StreamSynchronize" in row["name"] and overlap(row)]
    if arm == "control":
        assert [(row["bytes"],row["copyKind"]) for row in operation_copies] == [(16,2),(32,1)]
        assert len(syncs) == 2
    else:
        assert not operation_copies and not syncs
        assert "mul_mat_vec_f<float, float" in kernels[1]["name"]
        assert "void, (bool)1>" in kernels[1]["name"]
    assert any(row["bytes"]==4 and row["copyKind"]==2 and row["start"]>=end for row in copies)
    arms[arm] = dict(kernels=kernels, kernel_count=len(kernels), all_process_copies=copies,
        operation_window_ns=dict(start=begin,end=end), operation_copies=operation_copies,
        operation_stream_synchronizations=syncs,
        all_process_stream_sync_counts=dict(Counter(row["name"] for row in api if "StreamSynchronize" in row["name"])),
        runtime=json.loads((path.parent/"runtime.json").read_text()))
summary = dict(passed=True, scope="One already-bound T1/S4/E8/N512/K2048 command invocation per same-math arm",
    control=arms["control"], new=arms["new"],
    removed_native_sorting_temporaries_formula="4*T*S*(K+N)+8*T*S bytes before pool rounding/vendor workspace",
    removed_native_sorting_temporaries_for_fixture_bytes=40992,
    retained="Original safe-ID check and guarded output; asynchronous4-byte Completion status D2H and explicit final output readback remain",
    limitations=["Profiler runs have zero warmup; kernel timings include cold preparation effects and are not the accepted speed benchmark",
                 "Startup input uploads have their own stream synchronizations; only the named operation window excludes those",
                 "No total process/device peak, all-shape, generic capture or whole-model throughput claim"])
(stage/"profile-analysis.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
print("PLAIN_GROUPED_TRACE control6/new3 kernels; native sync2->0; ID/map copies2->0")
