"""Record why this continuation proceeds; no new governance or admission rules."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

stage = Path(__file__).resolve().parent
root = stage.parents[2]
evidence = root / "docs/evidence/correctness/ct-packed-linear-2026-10-20.json"
report = json.loads(evidence.read_text())
gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,temperature.gpu,clocks.sm,clocks.mem,power.draw", "--format=csv,noheader"],
                     capture_output=True, text=True)
doc = dict(recorded_utc=datetime.now(timezone.utc).isoformat(), full_goal_status="active",
    previous_goal_turn="progress",
    previous_evidence=dict(path=str(evidence), sha256=hashlib.sha256(evidence.read_bytes()).hexdigest()),
    previous_reason="Shared actual Prepared helper removed55lines; CT4 plus Dense4 real CUDA regressions passed; docs/evidence published;487222471 rebuildable bytes reclaimed",
    current_work="Remove existing plain grouped CUDA ID host synchronization/sorting in the actual admitted small-T domain; preserve source/accumulator precision and error/lifetime contracts",
    actual_negative_evidence="runs/before-witness: public F32 unit activation1+2^-20 produced1.0; no throughput accepted from that failed original baseline",
    source_revision_correction="CUDA-only8eeb and mixedCPU+CUDA+IQ1 canonical6cde are different legitimate compositions; match the real composition and header closure before comparison",
    verification_scope="Only affected native owner TUs and the existing grouped public consumer; same command submit+wait benchmark, with a precision-fixed fallback control",
    GPU_inventory=dict(command=gpu.args, exit=gpu.returncode, stdout=gpu.stdout, stderr=gpu.stderr))
(stage / "goal-turn.json").write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
print("PLAIN_GROUPED_TURN previous=progress active=true GPU_inventory_exit=" + str(gpu.returncode))
