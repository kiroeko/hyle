"""Compile one public benchmark and link the exact current before closure."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
root = stage.parents[2]
spec = importlib.util.spec_from_file_location(
    "plain_grouped_build_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = stage / "checks/before"
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
inventory = c.read(stage / "build-inventory.json")
base = c.read(inventory["base"])
old = c.read(stage.parent / "ct-packed-linear/build-inventory.json")["owners"][
    "tests/graph_route_cuda/grouped_shared_activation_test.cc"]
source = stage / "bench.cc"
command = b.host_command(old["command"], source, "bench", out)
env, runtime = b.environment(base["command"], [row["path"] for row in base["inputs"]], out)
source_id = b.identity(source)
c.save(out / "runtime-environment.json", dict(runtime=runtime, PATH=env["PATH"]))
c.execute("bench-compile", command, env, out)
assert b.same(source_id)
dep = c.read(out / "bench-deps.json")["Data"]
obj = b.identity(out / "bench.obj")
c.save(out / "bench-identity.json", dict(command=command, source=source_id, object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([dep["Source"], *dep["Includes"]])]))
lookup = {c.key(row["path"]): row for row in base["inputs"]}
removed = {c.key(row["old_object"]["path"]) for row in inventory["current_test_owners"]}
for item in base["inputs"]:
    if Path(item["path"]).name.casefold() in ("gtest.lib", "gtest_main.lib"):
        removed.add(c.key(item["path"]))
    assert b.same(item), item["path"]
command = [arg for arg in base["command"] if c.key(arg) not in removed and
           not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
command.insert(1, obj["path"])
image = out / "grouped-bench.exe"
command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
            "/IMPLIB:" + str(image.with_suffix(".lib"))]
lookup[c.key(obj["path"])] = obj
inputs = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
c.execute("bench-link", command, env, out)
c.save(out / "link-plan.json", dict(command=command, inputs=[lookup[c.key(p)] for p in inputs]))
c.save(out / "image.json", b.identity(image))
c.save(out / "plan.json", dict(source=source_id, baseline=inventory["base"], SDK_build=False,
    fresh_native_owners=0, fresh_host_owners=1, removed_test_objects=sorted(removed)))
print("PLAIN_GROUPED_BEFORE_BUILT", image, flush=True)
