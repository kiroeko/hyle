"""Execute the same public command submit+Completion wait benchmark serially."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "plain_grouped_run_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
p = argparse.ArgumentParser()
p.add_argument("--build", type=Path, required=True)
p.add_argument("--arm", choices=("control", "new"))
p.add_argument("--name", required=True)
p.add_argument("--tokens", type=int, default=1)
p.add_argument("--iterations", type=int, default=64)
p.add_argument("--warmup", type=int, default=8)
p.add_argument("--cpu", type=int)
args = p.parse_args()
assert Path(args.name).name == args.name
out = stage / "runs" / args.name
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
build = args.build.resolve()
prefix = args.arm + "-" if args.arm else ""
image, link = c.read(build / (prefix + "image.json")), c.read(build / (prefix + "link-plan.json"))
assert b.same(image)
for item in link["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(link["command"], [row["path"] for row in link["inputs"]], out)
c.save(out / "runtime.json", dict(image=image, link=b.identity(build / (prefix + "link-plan.json")),
    runtime_library_directories=runtime))
command = [image["path"], "--tokens", str(args.tokens), "--iterations", str(args.iterations),
    "--warmup", str(args.warmup)]
if args.cpu is not None:
    command += ["--cpu", str(args.cpu)]
c.execute("bench", command, env, out)
lines = (out / "bench.stdout.log").read_text().splitlines()
records = [json.loads(row) for row in lines if row.startswith("{")]
assert len(records) == 1 and records[0]["passed"]
assert len(records[0]["samples_ns"]) == args.iterations
c.save(out / "summary.json", dict(**records[0], image=image))
print(json.dumps(dict(passed=True, tokens=args.tokens,
    median_us=records[0]["submit_and_wait_ns_median"] / 1000,
    caller_workspace=records[0]["reported_caller_workspace_bytes"])))
