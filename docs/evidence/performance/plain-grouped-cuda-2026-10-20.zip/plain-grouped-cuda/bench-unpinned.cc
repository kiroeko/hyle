#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/cuda.h"
#include "tests/compute_models/grouped_shared_activation_fixture.h"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
c::TensorDesc dense(c::DataType type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, {shape.begin(), shape.size()}));
}
template<class T> m::Buffer upload(m::MemoryResourceRef memory, const std::vector<T>& values) {
  const auto bytes = std::as_bytes(std::span(values));
  auto buffer = take(m::Buffer::create(memory, bytes.size(), 256));
  check(buffer.view().write(bytes));
  return buffer;
}
int main(int argc, char** argv) try {
  int tokens = 1, iterations = 64, warmup = 8;
  for (int i = 1; i < argc; i += 2) {
    if (i + 1 == argc) throw std::runtime_error("option needs a value");
    const std::string flag(argv[i]); const int value = std::stoi(argv[i + 1]);
    if (flag == "--tokens") tokens = value;
    else if (flag == "--iterations") iterations = value;
    else if (flag == "--warmup") warmup = value;
    else throw std::runtime_error("unknown option: " + flag);
  }
  if (tokens < 1 || tokens > 9 || iterations < 1 || warmup < 0)
    throw std::runtime_error("unsupported benchmark dimensions/counts");
  grouped_shared_test::Fixture data(tokens, 4, 2048, 512, 8);
  auto activation = data.activations(true, 0);
  auto ids = data.ids(false, 0); // Repeated IDs are real separate output slots.
  for (std::int64_t e = 0; e < data.experts; ++e) {
    const auto row0 = static_cast<std::size_t>(e * data.rows * data.columns);
    std::fill_n(data.weights.begin() + row0, 2 * data.columns, 0.0F);
    data.weights[row0] = 1.0F;
    data.weights[row0 + static_cast<std::size_t>(data.columns) + 1] = 0x1p120F;
  }
  for (int t = 0; t < tokens; ++t) {
    activation[static_cast<std::size_t>(t * data.columns)] = 0x1.00001p0F;
    activation[static_cast<std::size_t>(t * data.columns + 1)] = std::bit_cast<float>(std::uint32_t{0x00080000});
  }
  auto expected = data.expected(true, activation, ids);
  // These independent known results do not depend on the host's DAZ/FTZ mode.
  for (int t = 0; t < tokens; ++t) for (int s = 0; s < data.slots; ++s) {
    const auto row = static_cast<std::size_t>((t * data.slots + s) * data.rows);
    expected[row] = 0x1.00001p0F;
    expected[row + 1] = 0x1p-10F;
  }
  auto context = take(g::cuda::create_context());
  auto memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  const auto wd = dense(c::DataType::kFloat32, {data.experts, data.rows, data.columns});
  const auto ad = dense(c::DataType::kFloat32, {tokens, 1, data.columns});
  const auto id = dense(c::DataType::kInt32, {tokens, data.slots});
  const auto yd = dense(c::DataType::kFloat32, {tokens, data.slots, data.rows});
  auto wbuf = upload(memory.ref(), data.weights), abuf = upload(memory.ref(), activation);
  auto ibuf = upload(memory.ref(), ids);
  auto obuf = take(m::Buffer::create(memory.ref(), take(yd.required_bytes()), 256));
  auto builder = take(g::GraphBuilder::create());
  auto w = take(builder.input(wd)), a = take(builder.input(ad)), i = take(builder.input(id));
  auto y = take(builder.add(c::model_ops::grouped_matmul(), w, a, i));
  check(builder.publish(y));
  auto compiled = take(g::cuda::compile(take(std::move(builder).finish()), context, memory.ref()));
  auto slot = take(compiled.executable.create_invocation());
  auto queue = take(context.create_queue());
  check(slot.bind(w, take(c::ConstTensorView::create(wd, wbuf.view()))));
  check(slot.bind(a, take(c::ConstTensorView::create(ad, abuf.view()))));
  check(slot.bind(i, take(c::ConstTensorView::create(id, ibuf.view()))));
  check(slot.bind(y, take(c::TensorView::create(yd, obuf.view()))));
  check(g::cuda::prepare_replay(slot, queue,
      {.mode=g::ReplayMode::kCommands, .host_wait=g::HostWaitPolicy::kAllow}));
  const auto run = [&] { auto work = take(slot.submit(queue)); check(work.wait()); };
  for (int it = 0; it < warmup; ++it) run();
  std::vector<std::int64_t> times;
  for (int it = 0; it < iterations; ++it) {
    const auto start = std::chrono::steady_clock::now(); run();
    times.push_back(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now() - start).count());
  }
  std::vector<float> actual(expected.size());
  check(obuf.view().read(std::as_writable_bytes(std::span(actual))));
  for (std::size_t q = 0; q < actual.size(); ++q) {
    const auto row = q % static_cast<std::size_t>(data.rows);
    if (row < 2) {
      if (std::bit_cast<std::uint32_t>(actual[q]) != std::bit_cast<std::uint32_t>(expected[q]))
        throw std::runtime_error("precision witness mismatch row=" + std::to_string(row) +
            " actual_bits=" + std::to_string(std::bit_cast<std::uint32_t>(actual[q])) +
            " expected_bits=" + std::to_string(std::bit_cast<std::uint32_t>(expected[q])));
    } else {
      // Sparse dyadic inputs plus one explicit witness; no quality acceptance.
      const auto tolerance = 0.02F + 0.00002F * std::abs(expected[q]);
      if (!std::isfinite(actual[q]) || std::abs(actual[q] - expected[q]) > tolerance)
        throw std::runtime_error("logical matrix output differs");
    }
  }
  auto sorted = times; std::ranges::sort(sorted);
  const auto step = take(compiled.report.step(compiled.report.step_count() - 1));
  std::cout << "{\"passed\":true,\"tokens\":" << tokens << ",\"slots\":" << data.slots
      << ",\"K\":" << data.columns << ",\"N\":" << data.rows << ",\"E\":" << data.experts
      << ",\"warmup\":" << warmup << ",\"iterations\":" << iterations
      << ",\"command_mode\":true,\"submit_and_wait_ns_median\":" << sorted[sorted.size()/2]
      << ",\"reported_caller_workspace_bytes\":" << step.workspace.size
      << ",\"unit_precision_witness\":true,\"subnormal_product_witness\":true,\"samples_ns\":[";
  for (std::size_t q = 0; q < times.size(); ++q) std::cout << (q ? "," : "") << times[q];
  std::cout << "]}\n";
  return 0;
} catch (const std::exception& error) {
  std::cerr << "GROUPED_BENCH_FAILURE " << error.what() << '\n'; return 1;
}
