import hashlib
import json
from pathlib import Path

root = Path.cwd()
stage = root / '.scratch/architecture-refactor-2026-10-18/plain-grouped-cuda'
pristine = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
manifest = json.loads((stage / 'before-combined-manifest.json').read_text())
patched = {f['path']: f['after_sha256'] for f in manifest['files']}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected_native(path):
    value = path.as_posix()
    marker = '/native-source/'
    if marker not in value:
        return None
    relative = value.split(marker, 1)[1]
    if relative in patched:
        return patched[relative]
    candidate = pristine / relative
    return sha(candidate) if candidate.is_file() else None


def check_identity(relative):
    identity = json.loads((root / relative).read_text())
    results = []
    for record in [identity['source'], identity['object']] + identity.get('dependencies', []):
        path = Path(record['path'])
        actual = sha(path) if path.is_file() else None
        expected = expected_native(path)
        results.append({'path': str(path), 'recorded_sha256': record['sha256'],
                        'actual_sha256': actual,
                        'current_before_profile_sha256': expected,
                        'record_matches_actual': actual == record['sha256'],
                        'native_before_profile_matches': actual == expected if expected else None})
    return identity, results


main_path = '.scratch/architecture-refactor-2026-10-18/grouped-shared-activation/cpu-cuda/checks/20261019T205250/native-main-identity.json'
mmvf_path = '.scratch/architecture-refactor-2026-10-18/cuda-fusion-precision/checks/20261019T111328/mmvf-identity.json'
main, main_checks = check_identity(main_path)
mmvf, mmvf_checks = check_identity(mmvf_path)
main_recorded = {Path(r['path']).as_posix().lower(): r['sha256'] for r in main.get('dependencies', [])}

mmvf_headers = []
depfile = Path(mmvf['object']['path']).with_suffix('.d')
for raw in depfile.read_text().splitlines()[1:]:
    value = raw.strip().removesuffix('\\').strip().replace('\\ ', ' ')
    if not value:
        continue
    path = Path(value)
    actual = sha(path) if path.is_file() else None
    expected = expected_native(path)
    historical = main_recorded.get(path.as_posix().lower())
    mmvf_headers.append({'path': str(path), 'actual_sha256': actual,
                         'current_before_profile_sha256': expected,
                         'native_before_profile_matches': actual == expected if expected else None,
                         'shared_main_recorded_sha256': historical,
                         'shared_main_record_matches': actual == historical if historical else None})

report = {
    'scope': 'Before-baseline object reuse qualification only; no compilation or claim that changed candidate headers match cached objects',
    'main_identity': main_path,
    'main_checks': main_checks,
    'main_record_mismatches': [r for r in main_checks if not r['record_matches_actual']],
    'main_native_profile_mismatches': [r for r in main_checks if r['native_before_profile_matches'] is False],
    'mmvf_identity': mmvf_path,
    'mmvf_checks': mmvf_checks,
    'mmvf_dependency_file': str(depfile),
    'mmvf_header_checks': mmvf_headers,
    'mmvf_native_profile_mismatches': [r for r in mmvf_headers if r['native_before_profile_matches'] is False],
    'mmvf_shared_record_mismatches': [r for r in mmvf_headers if r['shared_main_record_matches'] is False],
    'compile_flags': {
        'main': main['command'],
        'mmvf': mmvf['command'],
        'qualification': 'Reuse the original compiler/toolchain and complete flags/macros, include resolution and ordered dependencies. Only source/output/dependency/PDB directories with byte-equivalent inputs may be normalized; do not ignore architecture, optimization, CRT, fast-math or source-level precision flags.'
    },
    'limits': 'Old MMVF identity has no recorded header SHA list. Its depfile identifies the headers; current native snapshots were compared with the exact before combined profile and shared main records where available. No original historical SHA was invented for remaining toolkit/standard-library headers. Reuse is for this same installed toolchain; a moved or changed toolkit requires qualification again.'
}
(stage / 'baseline-cache-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({k: len(report[k]) for k in [
    'main_checks', 'main_record_mismatches', 'main_native_profile_mismatches',
    'mmvf_header_checks', 'mmvf_native_profile_mismatches', 'mmvf_shared_record_mismatches']}))
