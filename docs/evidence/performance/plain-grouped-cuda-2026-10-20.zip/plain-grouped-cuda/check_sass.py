"""Inspect actually compiled SM89 code; the cache contains cubin, not PTX."""
import hashlib
import json
from pathlib import Path
import re
stage = Path(__file__).resolve().parent
path = stage / "checks/native1/mmvf.sass.txt"
raw = path.read_bytes(); text = raw.decode("utf-8-sig")
functions = list(re.finditer(r"Function\s*:\s*(\S+)", text))
selected, rows = [], []
for i, match in enumerate(functions):
    name = match.group(1)
    if "mul_mat_vec_fIff" not in name or "vLb1EE" not in name:
        continue
    body = text[match.start():functions[i+1].start() if i+1<len(functions) else len(text)]
    facts = dict(name=name, FFMA=bool(re.search(r"\bFFMA\b", body)),
        FADD=bool(re.search(r"\bFADD\b", body)), FTZ_modifier=".FTZ" in body)
    assert facts["FFMA"] and facts["FADD"] and not facts["FTZ_modifier"], facts
    selected.append(body); rows.append(facts)
assert len(rows) == 16, len(rows)
(stage / "strict-mmvf.sass.txt").write_text("\n".join(selected), encoding="utf-8")
result = dict(passed=True, architecture="sm89", strict_instantiations=rows,
    actual_object=json.loads((stage / "checks/native1/mmvf-identity.json").read_text())["object"],
    disassembly=dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
    extractor_command="cuobjdump.exe --dump-sass checks/native1/mmvf.obj",
    numeric_witnesses="Both public Direct/Graph regression and same-work control/new benchmark known-bit checks passed",
    limitation="SM89 actual SASS and bounded witnesses; not exhaustive float payload/device testing",
    no_PTX_claim="Original native recipe emits sm89 cubin only; --dump-ptx contained no entries, so no PTX result is claimed")
(stage / "sass-math-check.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print("STRICT_MMVF_SASS",len(rows),"entries no FTZ")
