from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import zipfile

root = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('compute', 'graph'))
args = parser.parse_args()
mode = args.mode
source = root / f'p1-{mode}-final'
manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
summary = json.loads((source / 'summary.json').read_text(encoding='utf-8'))
verify = json.loads((root / f'p1-{mode}-final-verify.json').read_text(encoding='utf-8'))
target = root / f'retained-p1-{mode}'
target.mkdir(exist_ok=False)
for name in ('contract-lock.json', 'controls.json', 'manifest.json', 'summary.json'):
    (target / name).write_text((source / name).read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
(target / 'verify.json').write_text(json.dumps(verify, indent=2) + '\n', encoding='utf-8', newline='\n')
table = []
directions = {}
for workload in summary['workloads']:
    estimates = [row['estimate'] for row in workload['strata']]
    values = [row['median_advantage_ratio'] for row in estimates]
    intervals = [row['confidence_interval'] for row in estimates]
    counts = Counter('WIN' if low > 1 else 'LOSS' if high < 1 else 'INCONCLUSIVE' for low, high in intervals)
    directions[workload['id']] = dict(counts)
    table.append(f"| {workload['id']} | {min(values):.6f}–{max(values):.6f} | "
                 f"{min(row[0] for row in intervals):.6f}–{max(row[1] for row in intervals):.6f} | "
                 f"{counts['WIN']} WIN / {counts['LOSS']} LOSS / {counts['INCONCLUSIVE']} INCONCLUSIVE | {workload['combined_noninferiority_gate']} |")
(target / 'direction.json').write_text(json.dumps(directions, indent=2) + '\n', encoding='utf-8', newline='\n')
kind = 'Direct' if mode == 'compute' else 'captured Graph'
readme = f'''# R4 CUDA {kind} 最终默认 FFN 验收

产品候选 `755fb7c76132908e15cc8e2c298c69c227af775a`；资格化 checkout
`f01e92379048b920b2545fa228921ef95038d5b3` 仅追加状态/文档/正确性证据，产品、benchmark、工具输入不变。
W1-WIN RTX4070/SM89、driver610.62、Toolkit13.3.73、MSVC19.50，engineering 身份。
合同 `{mode}-cuda-ffn-p1-v3`，caller CPU2、process mask0x14、AboveNormal；两颗独立 P 核，
SDK helpers 原生管理，运行前物理邻置 CUDA/CRT DLL。

两侧都使用完整 HYLE 资源/完成/失败合同、Marlin group128 W4A16、cuBLASLt，以及同一 pin 的
SGLang precise SwiGLU 数学实现。一侧使用自然默认 factory，另一侧使用独立精确 reference adapter。
该比较检查默认接入成本，**不证明 HYLE 算法胜过 SGLang**；采用成熟算法的依据是此前 v2 完整链比较。
M1/M16、双 placement、执行和分配双顺序保持原合同；原始样本数和资格详情保留在 manifest/summary。

qualification: **{manifest['qualification']}**。各 workload 的非劣结论与严格方向如下。
ratio>1 有利于发布路线；保留小幅输赢，不把5% practical PARITY解释为严格等速。

| Workload | 分层 median ratio 范围 | 各 CI 端点外界 | 各分层严格方向 | 5% NI |
|---|---|---|---|---|
''' + '\n'.join(table) + f'''

CI 外界不是新的聚合区间。性能只签测过的两个 resident FFN 原型与当前硬件/软件；不是模型吞吐，
不外推其它 GPU、驱动、Toolkit、dtype 或 shape。裸 native 成本在另一份 NATURAL_ROUTE 证据中报告。

raw-bundle.zip 保留所有原始输出、A/A、controls、manifest、验证结果及 recipe；sha256.json 记录归档。
原始 output `{source.as_posix()}`、build `C:/hv4{'d' if mode == 'compute' else 'g'}p3` 继续保留，
可读 JSON 只规范换行。不伪称脱离实际 artifact 路径取得永久 Formal 资格。
'''
(target / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
with zipfile.ZipFile(target / 'raw-bundle.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(source.rglob('*')):
        if p.is_file():
            archive.write(p, p.relative_to(source).as_posix())
    for p in (root / 'logs' / f'p1-{mode}-final-console.log', root / f'p1-{mode}-final-verify.json',
              root / 'run-final-p1.ps1', root / 'final-input-equivalence.json', Path(__file__)):
        archive.write(p, 'retention/' + p.name)
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.iterdir()) if p.is_file()}
(target / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'path': str(target), 'qualification': manifest['qualification'], 'directions': directions}))
