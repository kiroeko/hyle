from pathlib import Path
import sqlite3,collections,json,statistics,hashlib,re
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1];S.mkdir(exist_ok=True)
def I(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def J(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def merged(a):
 z=[]
 for x,y in sorted(a):
  if y<=x:continue
  if not z or x>z[-1][1]:z.append([x,y])
  else:z[-1][1]=max(z[-1][1],y)
 return z
def union(a):return sum(y-x for x,y in merged(a))
def intervals(a,lo,hi):return[(max(lo,v['start']),min(hi,v['end']))for v in a if v['start']<hi and v['end']>lo]
def dist(a):return dict(mean=statistics.mean(a),median=statistics.median(a),min=min(a),max=max(a))
def family(n):
 if 'internal::gemvx::kernel<'in n:return'projection_cublas'
 if 'mul_mat_vec_f<'in n:return'projection_FFN_dual'if'hyle_bf16_dual_matvec_silu_epilogue'in n else'projection_paired'if'void, (bool)0, (bool)1>'in n else'projection_other'
 if'gated_delta_net'in n:return'GDN_core'
 if'ssm_conv'in n:return'causal_conv'
 if'flashinfer::'in n or'flash_attn_ext_vec<'in n:return'dense_attention'
 if'hyle_bf16_l2_core'in n:return'GDN_L2'
 if'cpy_scalar_contiguous'in n:return'copy_cast_contiguous'
 if'rms_norm'in n:return'RMSNorm'
 if'concat'in n:return'concat'
 if'set_rows'in n or'single_update'in n:return'KV_update'
 if'rope'in n:return'RoPE'
 if'GatherOutput'in n or'get_rows'in n:return'gather'
 if any(x in n for x in ['ArgPair','ArgValue','ArgIndex','argmax_f32']):return'argmax'
 return'elementwise_other'
def activity_family(v):return family(v['name'])if v['kind']=='kernel'else v['kind']
def partition(projections,others,copies,lo,hi):
 events=collections.defaultdict(lambda:[0,0,0])
 for i,rows in enumerate([projections,others,copies]):
  for x,y in intervals(rows,lo,hi):events[x][i]+=1;events[y][i]-=1
 events[lo];events[hi];active=[0,0,0];last=lo;out=collections.defaultdict(int)
 for t,delta in sorted(events.items()):
  key='+'.join(label for label,n in zip(['projection','nonprojection','copy_or_memset'],active)if n)or'no_recorded_device_activity';out[key]+=t-last
  active=[a+b for a,b in zip(active,delta)];last=t
 assert sum(out.values())==hi-lo and all(v>=0 for v in out.values());return{k:v/1000 for k,v in out.items()}
roleplan=J(A/'decode-major-hotspots/trace-analysis.json')['hyle']['mapped_decode7'];weight_bytes=sum(x['logical_weight_bytes']for x in roleplan);assert weight_bytes==3762552832
results={}
for arm,path in [('latest_retained_596',A/'gdn-direct-state-output/profile/capture.sqlite'),('prior_major_hotspots_596',A/'paired-projection-route/profile/capture.sqlite')]:
 c=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;strings=dict(c.execute('select id,value from StringIds'));tables={x[0]for x in c.execute("select name from sqlite_master where type='table'")}
 kernels=[dict(x,name=strings[x['demangledName']],kind='kernel')for x in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start')];copies=[dict(x,name=str(x['bytes'])+'B_copyKind'+str(x['copyKind']),kind='copy')for x in c.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY order by start')];memsets=[dict(x,name=str(x['bytes'])+'B_memset',kind='memset')for x in c.execute('select * from CUPTI_ACTIVITY_KIND_MEMSET order by start')]if'CUPTI_ACTIVITY_KIND_MEMSET'in tables else[];runtime=[dict(x,name=re.sub(r'_v[0-9]+$','',strings[x['nameId']]))for x in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start')];c.close();tokens=sorted([x for x in copies if x['copyKind']==2 and x['bytes']==4],key=lambda x:x['end']);assert len(tokens)==32
 phases=[];gaps_sample=[];role_samples=collections.defaultdict(list);family_samples=collections.defaultdict(list)
 for i in range(7,32):
  lo,hi=tokens[i-1]['end'],tokens[i]['end'];ks=[x for x in kernels if lo<x['start']and x['end']<=hi];cs=[x for x in copies+memsets if lo<x['start']and x['end']<=hi];acts=sorted(ks+cs,key=lambda x:x['start']);assert len(ks)==596
  proj=[x for x in ks if family(x['name']).startswith('projection_')];other=[x for x in ks if not family(x['name']).startswith('projection_')];assert len(proj)==len(roleplan)==145
  graph=[x for x in acts if x['graphNodeId']is not None];glo,ghi=min(x['start']for x in graph),max(x['end']for x in graph);graphks=[x for x in ks if x['graphNodeId']is not None];assert len(graphks)==591
  m=merged((x['start'],x['end'])for x in acts);gaps=[(x[1],y[0])for x,y in zip(m,m[1:])if y[0]>x[1]];ingaps=[(max(x,glo),min(y,ghi))for x,y in gaps if max(x,glo)<min(y,ghi)];allspan=max(x['end']for x in acts)-acts[0]['start'];kernelspan=max(x['end']for x in ks)-ks[0]['start'];beforegraph=[x for x in acts if x['end']<=glo];startup_start=max(x['end']for x in beforegraph);rt=[x for x in runtime if x['start']<glo and x['end']>startup_start];launch=[x for x in runtime if x['name']=='cudaGraphLaunch'and lo<x['start']and x['end']<=hi];assert len(launch)==1,(arm,i,len(launch))
  projunion=union((x['start'],x['end'])for x in proj);otherunion=union((x['start'],x['end'])for x in other);kernunion=union((x['start'],x['end'])for x in ks);alunion=union((x['start'],x['end'])for x in acts);graphunion=union(intervals(acts,glo,ghi));parts=partition(proj,other,cs,lo,hi)
  roleus=collections.defaultdict(float)
  for x,p in zip(proj,roleplan):roleus[p['role']]+=(x['end']-x['start'])/1000
  for key,v in roleus.items():role_samples[key].append(v)
  for key in sorted({family(x['name'])for x in other}):family_samples[key].append(sum(x['end']-x['start']for x in other if family(x['name'])==key)/1000)
  adjacent=[];projection_overlaps=[]
  for ordinal,(p,q) in enumerate(zip(proj,proj[1:])):
   a,b=p['end'],q['start']
   if b<a:
    projection_overlaps.append(dict(overlap_us=(min(p['end'],q['end'])-q['start'])/1000,earlier_ordinal=ordinal,later_ordinal=ordinal+1,earlier_role=roleplan[ordinal]['role'],later_role=roleplan[ordinal+1]['role'],earlier_stream=p['streamId'],later_stream=q['streamId']));continue
   adjacent.append(dict(span_us=(b-a)/1000,nonprojection_union_us=union(intervals(other,a,b))/1000,copy_union_us=union(intervals(cs,a,b))/1000,no_device_us=(b-a-union(intervals(acts,a,b)))/1000))
  phase=dict(index=i,kernels=596,projection_kernels=145,nonprojection_kernels=451,graph_kernels=591,graph_copy_or_memset_count=len(graph)-591,D2D_payload_bytes=sum(x['bytes']for x in cs if x.get('copyKind')==8),wall_us=(hi-lo)/1000,kernel_sum_us=sum(x['end']-x['start']for x in ks)/1000,kernel_union_us=kernunion/1000,projection_union_us=projunion/1000,nonprojection_union_us=otherunion/1000,projection_nonprojection_overlap_us=(projunion+otherunion-kernunion)/1000,device_union_us=alunion/1000,kernel_span_us=kernelspan/1000,device_span_us=allspan/1000,no_recorded_device_activity_us=(hi-lo-alunion)/1000,graph_span_us=(ghi-glo)/1000,graph_device_union_us=graphunion/1000,graph_internal_no_device_us=(ghi-glo-graphunion)/1000,graph_internal_gap_count=len(ingaps),graph_internal_gaps_gt1us=sum(y-x>1000 for x,y in ingaps),graph_internal_max_gap_us=max([y-x for x,y in ingaps]or[0])/1000,graph_startup_gap_us=(glo-startup_start)/1000,graph_startup_overlap_GraphLaunch_us=union((max(startup_start,x['start']),min(glo,x['end']))for x in launch)/1000,prefix_until_first_graph_kernel_us=(glo-lo)/1000,post_graph_tail_us=(hi-ghi)/1000,exclusive_partition_us=parts,projection_interval_logical_GB_s=weight_bytes/projunion,whole_step_logical_GB_s=weight_bytes/(hi-lo),projection_interval_duty_fraction=projunion/(hi-lo),adjacent_projection_gap_span_us=sum(x['span_us']for x in adjacent),adjacent_projection_gap_no_device_us=sum(x['no_device_us']for x in adjacent),adjacent_projection_gap_nonprojection_union_us=sum(x['nonprojection_union_us']for x in adjacent),adjacent_projection_gap_max_us=max(x['span_us']for x in adjacent),adjacent_projection_top5=sorted(adjacent,key=lambda x:x['span_us'],reverse=True)[:5],nonprojection_family_sum_us=roleus if False else None)
  del phase['nonprojection_family_sum_us'];phase['adjacent_projection_overlap_count']=len(projection_overlaps);phase['adjacent_projection_overlap_pairwise_sum_us']=sum(x['overlap_us']for x in projection_overlaps);phase['adjacent_projection_overlap_first2_examples']=projection_overlaps[:2]if i==7 else[];phase['graph_gaps_at_least10us']=[dict(gap_us=(y-x)/1000,previous_family=activity_family(max([v for v in acts if v['end']<=x],key=lambda v:v['end'])),next_family=activity_family(min([v for v in acts if v['start']>=y],key=lambda v:v['start'])),start_after_graph_us=(x-glo)/1000)for x,y in ingaps if y-x>=10000];assert abs(sum(parts.values())-phase['wall_us'])<1e-6;assert abs(phase['whole_step_logical_GB_s']-phase['projection_interval_logical_GB_s']*phase['projection_interval_duty_fraction'])<1e-8;phases.append(phase)
  if i==7:
   for x,y in sorted(gaps,key=lambda x:x[1]-x[0],reverse=True)[:8]:
    previous=max([v for v in acts if v['end']<=x],key=lambda v:v['end']);following=min([v for v in acts if v['start']>=y],key=lambda v:v['start']);gaps_sample.append(dict(gap_us=(y-x)/1000,start_after_token_us=(x-lo)/1000,end_after_token_us=(y-lo)/1000,inside_graph_span=x>=glo and y<=ghi,previous=dict(kind=previous['kind'],name=previous['name'][:240],graph_node=previous['graphNodeId']),following=dict(kind=following['kind'],name=following['name'][:240],graph_node=following['graphNodeId']),runtime_overlap_name_counts=dict(collections.Counter(v['name']for v in runtime if v['start']<y and v['end']>x))))
 scalar_keys=[k for k,v in phases[0].items()if isinstance(v,(float,int))and k!='index'];pkeys=sorted({k for p in phases for k in p['exclusive_partition_us']});stats={k:dist([p[k]for p in phases])for k in scalar_keys};exclusive={k:dist([p['exclusive_partition_us'].get(k,0)for p in phases])for k in pkeys};aggregate=dict(wall_us=sum(p['wall_us']for p in phases),exclusive_partition_us={k:sum(p['exclusive_partition_us'].get(k,0)for p in phases)for k in pkeys});aggregate['exclusive_fraction_of_wall']={k:v/aggregate['wall_us']for k,v in aggregate['exclusive_partition_us'].items()}
 results[arm]=dict(trace=I(path),profile_diagnostics=I(path.parent/'diagnostics.json'),phases=phases,stats=stats,exclusive_partition_stats_us=exclusive,all25_exact_additive_partition=aggregate,nonprojection_families_sum_us={k:dist(v)for k,v in family_samples.items()},projection_roles_sum_us={k:dist(v)for k,v in role_samples.items()},decode7_largest_gaps=gaps_sample)
review=dict(date='2026-10-20',status='offline_only_existing_GPU_activity_timestamps',method=dict(warm_phases='decode7..31, previous4B tokenD2H end -> current4B tokenD2H end',activity_scope='Recorded kernels, copies and memsets from this process. Union is elapsed recordedactivity, not DRAM occupancy or SMutilization.',decomposition='Sweep line exactmutuallyexclusive projection/nonprojection/copy intersections; no subtraction of kernel_sum fromwall. First-to-lastgraphnode span is not a reconstructed DAGcriticalpath.',primary='latest_retained_596 gdn-directstate trace10:25; prior09:30 major-hotspots is independent crosscheck, not pairedspeedcomparison',source_mapping=I(A/'decode-major-hotspots/trace-analysis.json'),logical_projection_weight_bytes=weight_bytes),results=results,limits=['Legacy softwareinstrumented Nsight trace with unsupported-driver-version fallback; GraphLaunch call and its preceding/following noGPUinterval are profiler/driver/host mixed and not a recoverablewall estimate.','Small submicrosecond recordedinterval overlaps are counted by timestampunion, not asserted as actual SMconcurrency or independentlyvalidated timeraccuracy. Projection logicalbytes are tensor geometry, not measured DRAMtraffic. Historical head/dual NsightCompute~93-98% peak was anotherisolatedcountercollection; not wholetrace bandwidth counters.','The latestretained596 trace predates later finitefamily/stablebind/nativeCast/retirement source changes. It informs recurringGPUwork but cannot sign latestunprofiled perstep gaps or present throughput.','No newprofiler,GPU,compile,modelprocess,peercomparison or productchange.'],next_action='The typical capturedgraph interior has small GPUactivity gaps, but latesttrace7/25 phases have231-767us isolated interior gaps at differentnodeboundaries; thetrace has noCPUcontextswitch or GPUglobalownership attribution and doesnot identify a sourcefix for thoseoutliers. For a large claim first demand concrete sourceelimination or immutablemath fusion in the dominant projection/elementwise work; preserveBF16rounding. If checking hostlaunch residual, use existing fresh unprofiled consumerstageclock evidence and one namedhostinterval, not an inferred659ussoftwareGraphLaunch saving. Existingretirementquery reuse targets firstprepare, not warm596graphwork. Do not re-open alreadyremoved18MiB GDNstate stageout.')
(S/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
for arm,r in results.items():
 print(arm)
 print(json.dumps({k:v for k,v in r['stats'].items()if k in ['wall_us','kernel_union_us','projection_union_us','nonprojection_union_us','projection_nonprojection_overlap_us','device_union_us','graph_span_us','graph_device_union_us','graph_internal_no_device_us','graph_internal_max_gap_us','graph_startup_gap_us','graph_startup_overlap_GraphLaunch_us','prefix_until_first_graph_kernel_us','post_graph_tail_us','projection_interval_logical_GB_s','whole_step_logical_GB_s','projection_interval_duty_fraction','adjacent_projection_gap_span_us','adjacent_projection_gap_no_device_us','adjacent_projection_gap_nonprojection_union_us']},indent=2));print('partition',r['all25_exact_additive_partition']);print('nonprojection',r['nonprojection_families_sum_us'])
print(I(S/'review.json'))
