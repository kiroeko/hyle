from pathlib import Path

task = Path(__file__).resolve().parent
source = (task / 'run.py').read_text(encoding='utf-8')
source = source.replace('import zipfile\n', 'import zipfile\nfrom types import SimpleNamespace\n')
start = source.index("assert (build / '.hyle-owner')")
end = source.index("with zipfile.ZipFile(root / 'evidence/performance/")
source = source[:start] + '''identity_record=json.loads((task/'input-identity.json').read_text(encoding='utf-8'))
identity=identity_record['inputs']
assert all(sha(Path(p))==v['sha256'] for p,v in identity.items())
assert not (task/'resumed-result.json').exists(), 'Fixed bundle already resumed'
prior=json.loads((task/'result.json').read_text(encoding='utf-8'))
assert prior['processes_completed']==1 and prior['execution_failure']==''
write(task/'resume-identity.json',{'validator_sha256':sha(Path(__file__)),
                                'prior_identity_sha256':sha(task/'input-identity.json'),
                                'reused_processes':[0,1],'new_processes':[2,3],
                                'correction':'Accept the existing onednn-prefix tag only for untimed Graph prefix observations; all measured Direct observations must be onednn. Treat even an empty exception message as failure.'})
''' + source[end:]
start = source.index('    directory.mkdir(parents=True,exist_ok=False)')
end = source.index('    try:\n        assert process.returncode', start)
execute = source[start:end]
reuse = '''    if index < 2:
        fact=json.loads((directory/'process.json').read_text(encoding='utf-8'))
        process=SimpleNamespace(returncode=fact['exit_code'])
        timed_out=fact['timeout']
        stdout=(directory/'stdout.bin').read_bytes()
        stderr=(directory/'stderr.bin').read_bytes()
    else:
'''
source = source[:start] + reuse + ''.join('    '+line if line.strip() else line for line in execute.splitlines(keepends=True)) + source[end:]
source = source.replace("assert all(v['provider']=='onednn' for v in instances)",
    "assert all(v['provider']==('onednn-prefix' if v['workload']=='prefix-graph' else 'onednn') for v in instances), 'Unexpected provider identity'")
source = source.replace('failure=str(error)', 'failure=type(error).__name__+\": \"+str(error)')
source = source.replace("write(task/'result.json'", "write(task/'resumed-result.json'")
source = source.replace('if failure: raise SystemExit', 'if failure is not None: raise SystemExit')
(task / 'resume.py').write_text(source, encoding='utf-8', newline='\n')
print('Generated one validator-only correction; run 0 and run 1 will not repeat')
