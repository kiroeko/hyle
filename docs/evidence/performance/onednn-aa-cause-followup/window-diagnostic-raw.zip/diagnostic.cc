#define ANKERL_NANOBENCH_IMPLEMENT
#define main historical_normalization_entry
#include "bench/graph_provider_onednn/normalization_p1_bench.cc"
#undef main
#include <intrin.h>

namespace {

struct Stamp {
  LONGLONG qpc;
  ULONG64 cycles;
  unsigned long long tsc;
  unsigned long cpu;
  unsigned aux;
};
LONGLONG qpc_frequency = 0;
Stamp stamp() {
  Stamp s{};
  s.cpu = ::GetCurrentProcessorNumber();
  LARGE_INTEGER qpc{};
  if (!::QueryPerformanceCounter(&qpc)) fail("QPC observation");
  s.qpc = qpc.QuadPart;
  s.tsc = __rdtscp(&s.aux);
  if (!::QueryThreadCycleTime(::GetCurrentThread(), &s.cycles))
    fail("thread cycle observation");
  return s;
}
struct BatchSample { Stamp before, after; unsigned arm; };
struct Monitor {
  static constexpr std::size_t capacity = 65536;
  std::unique_ptr<BatchSample[]> values = std::make_unique<BatchSample[]>(capacity);
  std::size_t used = 0;
};
struct WindowOp {
  DirectRoute *route;
  Monitor *monitor;
  unsigned arm;
  void operator()() const {
    if (monitor->used == Monitor::capacity) fail("window observation budget");
    const auto before = stamp();
    for (unsigned i = 0; i != 256; ++i) route->run();
    const auto after = stamp();
    monitor->values[monitor->used++] = {before, after, arm};
  }
};
void clock_controls() {
  int info[4]{};
  __cpuid(info, static_cast<int>(0x80000000U));
  if (static_cast<unsigned>(info[0]) < 0x80000007U)
    fail("extended CPUID clock capability unavailable");
  __cpuid(info, static_cast<int>(0x80000001U));
  if (!(static_cast<unsigned>(info[3]) & (1U << 27))) fail("RDTSCP unsupported");
  __cpuid(info, static_cast<int>(0x80000007U));
  const unsigned invariant = (static_cast<unsigned>(info[3]) >> 8) & 1;
  LARGE_INTEGER frequency{};
  if (!::QueryPerformanceFrequency(&frequency)) fail("QPC frequency");
  qpc_frequency = frequency.QuadPart;
  std::printf("# HYLE_AA_WINDOW_CLOCK qpc_frequency=%lld rdtscp=1 invariant=%u\n",
              static_cast<long long>(qpc_frequency), invariant);
  for (bool sleep : {false, true}) {
    const auto before = stamp();
    if (sleep) ::Sleep(20);
    else {
      LARGE_INTEGER now{};
      do { _mm_pause(); ::QueryPerformanceCounter(&now); }
      while (now.QuadPart-before.qpc < qpc_frequency/200);
    }
    const auto after = stamp();
    std::printf("# HYLE_AA_WINDOW_CONTROL kind=%s qpc=%lld cycles=%llu tsc=%llu "
                "cpu0=%lu cpu1=%lu\n", sleep ? "sleep20ms" : "busy5ms",
                static_cast<long long>(after.qpc-before.qpc),
                static_cast<unsigned long long>(after.cycles-before.cycles),
                after.tsc-before.tsc, before.cpu, after.cpu);
  }
}
template<class Route> void prime_region(Problem &problem, const char *label) {
  auto first = std::make_unique<Route>(problem, true);
  auto second = std::make_unique<Route>(problem, true);
  for (unsigned i = 0; i != 64; ++i) { first->run(); second->run(); }
  first->verify(problem);
  second->verify(problem);
  first->observe(label, "prefix-first", true, problem);
  second->observe(label, "prefix-second", true, problem);
}
void allocation_prefix() {
  unsigned count = 0;
  for (bool rms : {true, false})
    for (const auto shape : {std::array<std::size_t, 2>{1, 2048}, {17, 2048},
                             {128, 2048}, {17, 257}}) {
      if (!rms && shape[1] == 257) continue;
      Problem problem(shape[0], shape[1], rms);
      prime_region<DirectRoute>(problem, "prefix-direct");
      prime_region<GraphRoute>(problem, "prefix-graph");
      count += 2;
    }
  if (count != 14) fail("prefix region count");
  std::printf("# HYLE_AA_WINDOW_PREFIX regions=%u repeats=64 timed=0\n", count);
}

void observe_comparison(const char *group, DirectRoute &first,
                        DirectRoute &second, const Problem &problem, Monitor &monitor) {
  first.verify(problem);
  second.verify(problem);
  first.observe(group, "baseline", true, problem);
  second.observe(group, "alternative", true, problem);
  nb::Bench bench;
  bench.title(group).relative(true).epochs(12)
      .minEpochTime(std::chrono::milliseconds(8));
  monitor.used = 0;
  const auto before = cold_times();
  const auto result = bench.compare("baseline", WindowOp{&first, &monitor, 0},
                                    "alternative", WindowOp{&second, &monitor, 1});
  const auto after = cold_times();
  if (result.rounds() != 12 || result.size() != 2)
    fail("unexpected diagnostic round count");
  for (std::size_t arm = 0; arm < result.size(); ++arm) {
    const auto &entry = result[arm];
    std::printf("# HYLE_AA_CAUSE_SUMMARY group=%s arm=%zu ratio=%.17g low=%.17g "
                "high=%.17g rounds=%zu\n", group, arm, entry.relative,
                entry.relativeLow, entry.relativeHigh, result.rounds());
    for (std::size_t round = 0; round < entry.result.size(); ++round)
      std::printf("# HYLE_AA_CAUSE_ROUND group=%s arm=%zu round=%zu "
                  "seconds_per_op=%.17g iterations=%.0f\n", group, arm,
                  round, entry.result.get(round, nb::Result::Measure::elapsed),
                  entry.result.get(round, nb::Result::Measure::iterations));
  }

  std::printf("# HYLE_AA_WINDOW_COUNT group=%s count=%zu batch=256\n", group, monitor.used);
  for (std::size_t i = 0; i != monitor.used; ++i) {
    const auto &s = monitor.values[i];
    std::printf("# HYLE_AA_WINDOW group=%s index=%zu arm=%u qpc0=%lld qpc1=%lld "
                "cycles=%llu tsc=%llu cpu0=%lu cpu1=%lu aux0=%u aux1=%u\n", group,
                i, s.arm, static_cast<long long>(s.before.qpc),
                static_cast<long long>(s.after.qpc),
                static_cast<unsigned long long>(s.after.cycles-s.before.cycles),
                s.after.tsc-s.before.tsc, s.before.cpu, s.after.cpu,
                s.before.aux, s.after.aux);
  }
  std::fprintf(stderr, "# HYLE_AA_CAUSE_INTERVAL group=%s wall_ns=%lld "
                       "thread_cpu_100ns=%llu cpu_before=%lu cpu_after=%lu\n",
               group, static_cast<long long>(std::chrono::duration_cast<
                          std::chrono::nanoseconds>(after.wall-before.wall).count()),
               static_cast<unsigned long long>(after.thread_cpu_100ns-before.thread_cpu_100ns),
               before.cpu, after.cpu);
  first.verify(problem);
  second.verify(problem);
}
} // namespace

int main(int argc, char **argv) {
  ::SetErrorMode(0x8003);
  if (argc != 2 || argv[1][0] < '0' || argv[1][0] > '3' || argv[1][1])
    fail("diagnostic requires fixed process index 0..3");
  const int index = argv[1][0] - '0';
  if (!::SetProcessAffinityMask(::GetCurrentProcess(), 0x4) ||
      !::SetThreadAffinityMask(::GetCurrentThread(), 0x4) ||
      !::SetPriorityClass(::GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS))
    fail("apply original single-P-core process policy");
  DWORD_PTR process_mask = 0, system_mask = 0;
  if (!::GetProcessAffinityMask(::GetCurrentProcess(), &process_mask, &system_mask)
      || process_mask != 0x4)
    fail("verify process affinity");
  std::fprintf(stderr, "# HYLE_AA_CAUSE_PROCESS index=%d pid=%lu mask=0x%llx "
                       "priority=%lu cpu=%lu provider=onednn\n", index,
               ::GetCurrentProcessId(), static_cast<unsigned long long>(process_mask),
               ::GetPriorityClass(::GetCurrentProcess()), ::GetCurrentProcessorNumber());
  clock_controls();
  if (index == 1 || index == 2) allocation_prefix();
  Problem problem(17, 257, false);
  std::unique_ptr<DirectRoute> a, b;
  if (index % 2 == 0) {
    a = std::make_unique<DirectRoute>(problem, true);
    b = std::make_unique<DirectRoute>(problem, true);
  } else {
    b = std::make_unique<DirectRoute>(problem, true);
    a = std::make_unique<DirectRoute>(problem, true);
  }
  a->run();
  b->run();
  a->observe("identity", "A", true, problem);
  b->observe("identity", "B", true, problem);
  observe_code("diagnostic-17x257");
  Monitor monitor;
  observe_comparison("pre-AA", *a, *a, problem, monitor);
  observe_comparison("pre-BB", *b, *b, problem, monitor);
  if (index % 2 == 0) {
    observe_comparison("AB", *a, *b, problem, monitor);
    observe_comparison("BA", *b, *a, problem, monitor);
  } else {
    observe_comparison("BA", *b, *a, problem, monitor);
    observe_comparison("AB", *a, *b, problem, monitor);
  }
  observe_comparison("post-AA", *a, *a, problem, monitor);
  observe_comparison("post-BB", *b, *b, problem, monitor);
  std::puts("# HYLE_AA_CAUSE_COMPLETE groups=6 rounds_per_group=12 correctness=PASS");
  return 0;
}
