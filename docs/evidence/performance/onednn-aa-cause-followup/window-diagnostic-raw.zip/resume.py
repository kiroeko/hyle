import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import struct
import subprocess
import zipfile
from types import SimpleNamespace

root = Path(r'C:\public\project-hyle\hyle')
task = root / '.scratch/validation/onednn-aa-cause-b'
build = Path(r'C:\hv\odaab')
sdk = Path(r'C:\hyle-scratch\active-cpu\aa\selected-graph\static-sdk-relocated')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def fields(text, prefix):
    return [dict(re.findall(r'(\w+)=([^\s]+)', line)) for line in text.splitlines() if line.startswith(prefix)]

identity_record=json.loads((task/'input-identity.json').read_text(encoding='utf-8'))
identity=identity_record['inputs']
assert all(sha(Path(p))==v['sha256'] for p,v in identity.items())
assert not (task/'resumed-result.json').exists(), 'Fixed bundle already resumed'
prior=json.loads((task/'result.json').read_text(encoding='utf-8'))
assert prior['processes_completed']==1 and prior['execution_failure']==''
write(task/'resume-identity.json',{'validator_sha256':sha(Path(__file__)),
                                'prior_identity_sha256':sha(task/'input-identity.json'),
                                'reused_processes':[0,1],'new_processes':[2,3],
                                'correction':'Accept the existing onednn-prefix tag only for untimed Graph prefix observations; all measured Direct observations must be onednn. Treat even an empty exception message as failure.'})
with zipfile.ZipFile(root / 'evidence/performance/onednn-normalization-aa-q2/failed-experiment-raw.zip') as archive:
    original = archive.read('preflight/selected-primary-peer-first-candidate-first/dnnl_dump_cpu_jit_lnorm_stat_and_data_kernel_t.28.bin')
exe = (build / 'onednn_window_diag.exe').read_bytes()
pe = struct.unpack_from('<I',exe,60)[0]
section_count = struct.unpack_from('<H',exe,pe+6)[0]
section_table = pe+24+struct.unpack_from('<H',exe,pe+20)[0]
def validate_jit(blob, base):
    assert len(blob)==3039 and blob[:89]==original[:89] and blob[97:]==original[97:]
    pointer = int.from_bytes(blob[89:97],'little')
    rva = pointer-base
    for i in range(section_count):
        pos=section_table+40*i
        _,va,size,offset=struct.unpack_from('<IIII',exe,pos+8)
        if va<=rva and rva+32<=va+size:
            assert not struct.unpack_from('<I',exe,pos+36)[0]&0x80000000
            mask=exe[offset+rva-va:offset+rva-va+32]
            assert mask==bytes.fromhex('ffffffff'+'00000000'*7)
            return {'pointer':hex(pointer),'mask_bytes':mask.hex(),'only_relocation_differs':True}
    raise AssertionError('No matching mask in read-only PE section')

def derive_group(group, rounds, windows, frequency):
    relevant=[r for r in rounds if r['group']==group]
    counts={int(r['iterations']) for r in relevant}
    assert len(relevant)==24 and len(counts)==1
    per_epoch=counts.pop()
    observed=[w for w in windows if w['group']==group]
    assert len(observed)>=24*per_epoch
    measured=observed[-24*per_epoch:]
    epochs=[]
    for i in range(24):
        chunk=measured[i*per_epoch:(i+1)*per_epoch]
        arms={int(w['arm']) for w in chunk}
        assert len(arms)==1
        arm=arms.pop()
        qpc=sum(int(w['qpc1'])-int(w['qpc0']) for w in chunk)
        cycles=sum(int(w['cycles']) for w in chunk)
        tsc=sum(int(w['tsc']) for w in chunk)
        epochs.append({'arm':arm,'batches':per_epoch,'qpc_sum':qpc,'cycles_sum':cycles,'tsc_sum':tsc,
                       'qpc_begin':int(chunk[0]['qpc0']),'qpc_end':int(chunk[-1]['qpc1']),
                       'wall_ns_per_call':qpc*1e9/frequency/(per_epoch*256),
                       'cycles_per_call':cycles/(per_epoch*256),'thread_cycles_over_tsc':cycles/tsc})
    ratios=[]
    for i in range(12):
        pair={e['arm']:e for e in epochs[2*i:2*i+2]}
        assert set(pair)=={0,1}
        ratios.append({'round':i,'wall_ratio':pair[0]['qpc_sum']/pair[1]['qpc_sum'],
                       'cycle_ratio':pair[0]['cycles_sum']/pair[1]['cycles_sum'],
                       'tsc_ratio':pair[0]['tsc_sum']/pair[1]['tsc_sum']})
    def median_ratio(key): return math.exp(statistics.median(math.log(r[key]) for r in ratios))
    return {'group':group,'calibration_batches':len(observed)-len(measured),'epochs':epochs,'paired':ratios,
            'wall_ratio':median_ratio('wall_ratio'),'cycle_ratio':median_ratio('cycle_ratio'),
            'tsc_ratio':median_ratio('tsc_ratio'),
            'active_fraction_range':[min(e['thread_cycles_over_tsc'] for e in epochs),
                                     max(e['thread_cycles_over_tsc'] for e in epochs)]}

ctypes.windll.kernel32.SetErrorMode(0x8003)
rows=[]
failure=None
for index in range(4):
    directory=build/'runs'/f'run-{index}'
    if index < 2:
        fact=json.loads((directory/'process.json').read_text(encoding='utf-8'))
        process=SimpleNamespace(returncode=fact['exit_code'])
        timed_out=fact['timeout']
        stdout=(directory/'stdout.bin').read_bytes()
        stderr=(directory/'stderr.bin').read_bytes()
    else:
        directory.mkdir(parents=True,exist_ok=False)
        env={k:v for k,v in os.environ.items() if not k.startswith(('HYLE_BENCH_','HYLE_PERF_'))}
        env['ONEDNN_JIT_DUMP']='1'
        command=[str(build/'onednn_window_diag.exe'),str(index)]
        process=subprocess.Popen(command,cwd=directory,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        timed_out=False
        try: stdout,stderr=process.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            timed_out=True
            process.kill()
            stdout,stderr=process.communicate()
        (directory/'stdout.bin').write_bytes(stdout)
        (directory/'stderr.bin').write_bytes(stderr)
        write(directory/'process.json',{'command':command,'pid':process.pid,'exit_code':process.returncode,
                                        'timeout':timed_out,'uac_or_power_changes':False})
    try:
        assert process.returncode==0 and not timed_out,'Execution failed'
        output,observations=stdout.decode('utf-8'),stderr.decode('utf-8')
        assert '# HYLE_AA_CAUSE_COMPLETE groups=6 rounds_per_group=12 correctness=PASS' in output
        prefix=index in (1,2)
        assert ('# HYLE_AA_WINDOW_PREFIX regions=14 repeats=64 timed=0' in output)==prefix
        clock=fields(output,'# HYLE_AA_WINDOW_CLOCK ')[0]
        controls=fields(output,'# HYLE_AA_WINDOW_CONTROL ')
        windows=fields(output,'# HYLE_AA_WINDOW ')
        rounds=fields(output,'# HYLE_AA_CAUSE_ROUND ')
        summaries=fields(output,'# HYLE_AA_CAUSE_SUMMARY ')
        instances=fields(observations,'# HYLE_NORMALIZATION_INSTANCE ')
        assert len(summaries)==12 and len(rounds)==144
        assert all(v['provider']==('onednn-prefix' if v['workload']=='prefix-graph' else 'onednn') for v in instances), 'Unexpected provider identity'
        assert all(w['cpu0']=='2' and w['cpu1']=='2' and w['aux0']==w['aux1'] for w in windows)
        base=int(fields(observations,'# HYLE_NORMALIZATION_PROCESS ')[0]['executable_base'],16)
        dumps=sorted(directory.glob('dnnl_dump_*lnorm*.bin'),key=lambda p:int(p.name.split('.')[-2]))
        assert len(dumps)==(30 if prefix else 2),f'Unexpected JIT count {len(dumps)}'
        jit={p.name:{'bytes':p.stat().st_size,'sha256':sha(p),**validate_jit(p.read_bytes(),base)} for p in dumps[-2:]}
        assert len({v['sha256'] for v in jit.values()})==1
        groups=[derive_group(g,rounds,windows,int(clock['qpc_frequency'])) for g in
                ('pre-AA','pre-BB','AB','BA','post-AA','post-BB')]
        row={'index':index,'prefix':prefix,'clock':clock,'controls':controls,'summaries':summaries,
             'groups':groups,'instances':instances,'jit':jit,
             'raw_window_count':len(windows),'batch':256}
        write(directory/'parsed.json',row)
        rows.append(row)
        print(json.dumps({'index':index,'prefix':prefix,'ratios':[
            {k:g[k] for k in ('group','wall_ratio','cycle_ratio','active_fraction_range')} for g in groups]}),flush=True)
    except Exception as error:
        failure=type(error).__name__+": "+str(error)
        break
changed=[name for name,fact in identity.items() if sha(Path(name))!=fact['sha256']]
write(task/'resumed-result.json',{'processes_completed':len(rows),'execution_failure':failure,
                         'immutable_input_changes':changed,'rows':rows,'cause_verdict':'NOT_YET_EVALUATED',
                         'old_q2_qualification':'FAIL','product_performance':'INCONCLUSIVE'})
assert not changed,changed
if failure is not None: raise SystemExit(f'Window diagnosis stopped: {failure}')
