from pathlib import Path

root = Path.cwd()
previous = root / '.scratch/validation/onednn-aa-cause'
task = root / '.scratch/validation/onednn-aa-cause-b'
task.mkdir(exist_ok=True)
source = (previous / 'diagnostic.cc').read_text(encoding='utf-8')
begin = source.index('struct BoundRoute {')
end = source.index('void observe_comparison(')
source = source[:begin] + r'''
struct Stamp {
  LONGLONG qpc;
  ULONG64 cycles;
  unsigned long long tsc;
  unsigned long cpu;
  unsigned aux;
};
LONGLONG qpc_frequency = 0;
Stamp stamp() {
  Stamp s{};
  s.cpu = ::GetCurrentProcessorNumber();
  LARGE_INTEGER qpc{};
  if (!::QueryPerformanceCounter(&qpc)) fail("QPC observation");
  s.qpc = qpc.QuadPart;
  s.tsc = __rdtscp(&s.aux);
  if (!::QueryThreadCycleTime(::GetCurrentThread(), &s.cycles))
    fail("thread cycle observation");
  return s;
}
struct BatchSample { Stamp before, after; unsigned arm; };
struct Monitor {
  static constexpr std::size_t capacity = 65536;
  std::unique_ptr<BatchSample[]> values = std::make_unique<BatchSample[]>(capacity);
  std::size_t used = 0;
};
struct WindowOp {
  DirectRoute *route;
  Monitor *monitor;
  unsigned arm;
  void operator()() const {
    if (monitor->used == Monitor::capacity) fail("window observation budget");
    const auto before = stamp();
    for (unsigned i = 0; i != 256; ++i) route->run();
    const auto after = stamp();
    monitor->values[monitor->used++] = {before, after, arm};
  }
};
void clock_controls() {
  int info[4]{};
  __cpuid(info, static_cast<int>(0x80000000U));
  if (static_cast<unsigned>(info[0]) < 0x80000007U)
    fail("extended CPUID clock capability unavailable");
  __cpuid(info, static_cast<int>(0x80000001U));
  if (!(static_cast<unsigned>(info[3]) & (1U << 27))) fail("RDTSCP unsupported");
  __cpuid(info, static_cast<int>(0x80000007U));
  const unsigned invariant = (static_cast<unsigned>(info[3]) >> 8) & 1;
  LARGE_INTEGER frequency{};
  if (!::QueryPerformanceFrequency(&frequency)) fail("QPC frequency");
  qpc_frequency = frequency.QuadPart;
  std::printf("# HYLE_AA_WINDOW_CLOCK qpc_frequency=%lld rdtscp=1 invariant=%u\n",
              static_cast<long long>(qpc_frequency), invariant);
  for (bool sleep : {false, true}) {
    const auto before = stamp();
    if (sleep) ::Sleep(20);
    else {
      LARGE_INTEGER now{};
      do { _mm_pause(); ::QueryPerformanceCounter(&now); }
      while (now.QuadPart-before.qpc < qpc_frequency/200);
    }
    const auto after = stamp();
    std::printf("# HYLE_AA_WINDOW_CONTROL kind=%s qpc=%lld cycles=%llu tsc=%llu "
                "cpu0=%lu cpu1=%lu\n", sleep ? "sleep20ms" : "busy5ms",
                static_cast<long long>(after.qpc-before.qpc),
                static_cast<unsigned long long>(after.cycles-before.cycles),
                after.tsc-before.tsc, before.cpu, after.cpu);
  }
}
template<class Route> void prime_region(Problem &problem, const char *label) {
  auto first = std::make_unique<Route>(problem, true);
  auto second = std::make_unique<Route>(problem, true);
  for (unsigned i = 0; i != 64; ++i) { first->run(); second->run(); }
  first->verify(problem);
  second->verify(problem);
  first->observe(label, "prefix-first", true, problem);
  second->observe(label, "prefix-second", true, problem);
}
void allocation_prefix() {
  unsigned count = 0;
  for (bool rms : {true, false})
    for (const auto shape : {std::array<std::size_t, 2>{1, 2048}, {17, 2048},
                             {128, 2048}, {17, 257}}) {
      if (!rms && shape[1] == 257) continue;
      Problem problem(shape[0], shape[1], rms);
      prime_region<DirectRoute>(problem, "prefix-direct");
      prime_region<GraphRoute>(problem, "prefix-graph");
      count += 2;
    }
  if (count != 14) fail("prefix region count");
  std::printf("# HYLE_AA_WINDOW_PREFIX regions=%u repeats=64 timed=0\n", count);
}

''' + source[end:]
source = source.replace('#undef main', '#undef main\n#include <intrin.h>')
source = source.replace('DirectRoute &second, const Problem &problem) {',
                        'DirectRoute &second, const Problem &problem, Monitor &monitor) {')
source = source.replace('  const auto before = cold_times();', '  monitor.used = 0;\n  const auto before = cold_times();')
source = source.replace('BoundRoute{&first}', 'WindowOp{&first, &monitor, 0}')
source = source.replace('BoundRoute{&second}', 'WindowOp{&second, &monitor, 1}')
source = source.replace('  std::fprintf(stderr, "# HYLE_AA_CAUSE_INTERVAL', r'''
  std::printf("# HYLE_AA_WINDOW_COUNT group=%s count=%zu batch=256\n", group, monitor.used);
  for (std::size_t i = 0; i != monitor.used; ++i) {
    const auto &s = monitor.values[i];
    std::printf("# HYLE_AA_WINDOW group=%s index=%zu arm=%u qpc0=%lld qpc1=%lld "
                "cycles=%llu tsc=%llu cpu0=%lu cpu1=%lu aux0=%u aux1=%u\n", group,
                i, s.arm, static_cast<long long>(s.before.qpc),
                static_cast<long long>(s.after.qpc),
                static_cast<unsigned long long>(s.after.cycles-s.before.cycles),
                s.after.tsc-s.before.tsc, s.before.cpu, s.after.cpu,
                s.before.aux, s.after.aux);
  }
  std::fprintf(stderr, "# HYLE_AA_CAUSE_INTERVAL''')
source = source.replace('  Problem problem(17, 257, false);',
                        '  clock_controls();\n  if (index == 1 || index == 2) allocation_prefix();\n  Problem problem(17, 257, false);')
source = source.replace('  observe_comparison("pre-AA", *a, *a, problem);',
                        '  Monitor monitor;\n  observe_comparison("pre-AA", *a, *a, problem, monitor);')
source = source.replace('*b, *b, problem);', '*b, *b, problem, monitor);')
source = source.replace('*a, *a, problem);', '*a, *a, problem, monitor);')
source = source.replace('*a, *b, problem);', '*a, *b, problem, monitor);')
source = source.replace('*b, *a, problem);', '*b, *a, problem, monitor);')
source = source.replace('if (index < 2)', 'if (index % 2 == 0)')
(task / 'diagnostic.cc').write_text(source, encoding='utf-8', newline='\n')
cmake = (previous / 'CMakeLists.txt').read_text(encoding='utf-8')
cmake = cmake.replace('onednn_instance_diag', 'onednn_window_diag')
(task / 'CMakeLists.txt').write_text(cmake, encoding='utf-8', newline='\n')
script = (previous / 'build.ps1').read_text(encoding='utf-8')
script = script.replace("'.scratch\\validation\\onednn-aa-cause'", "'.scratch\\validation\\onednn-aa-cause-b'")
script = script.replace("'C:\\hv\\odaa'", "'C:\\hv\\odaab'")
script = script.replace('oneDNN A/A cause /root', 'oneDNN A/A cause windows /root')
(task / 'build.ps1').write_text(script, encoding='utf-8', newline='\n')
print('Generated independent execution-window consumer')
