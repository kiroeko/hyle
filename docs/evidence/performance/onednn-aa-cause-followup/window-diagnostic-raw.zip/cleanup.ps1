$ErrorActionPreference = 'Stop'
$workspacePath = 'C:\public\project-hyle\hyle'
$records = @()
$items = @(
    @{ Build = 'C:\hv\odaa'; Task = 'onednn-aa-cause'; Owner = 'oneDNN A/A cause /root'; Exe = 'onednn_instance_diag.exe' },
    @{ Build = 'C:\hv\odaab'; Task = 'onednn-aa-cause-b'; Owner = 'oneDNN A/A cause windows /root'; Exe = 'onednn_window_diag.exe' }
)
foreach ($item in $items) {
    $resolvedBuild = (Resolve-Path -LiteralPath $item.Build).Path
    if ($resolvedBuild -ne $item.Build -or [IO.Path]::GetDirectoryName($resolvedBuild) -ne 'C:\hv') { throw 'Unexpected build path' }
    if ((Get-Content -LiteralPath (Join-Path $resolvedBuild '.hyle-owner') -Raw).Trim() -ne $item.Owner) { throw 'Unexpected build owner' }
    $taskPath = [IO.Path]::GetFullPath((Join-Path $workspacePath ('.scratch\validation\' + $item.Task)))
    $retainedPath = [IO.Path]::GetFullPath((Join-Path $taskPath 'retained-diagnostic'))
    if (-not $retainedPath.StartsWith($workspacePath + '\.scratch\validation\', [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetDirectoryName($retainedPath) -ne $taskPath) { throw 'Unexpected retained path' }
    if (Test-Path -LiteralPath $retainedPath) { throw 'Retained destination already exists' }
    $identity = Get-Content -LiteralPath (Join-Path $taskPath 'input-identity.json') -Raw | ConvertFrom-Json -AsHashtable
    $keep = @((Get-Item -LiteralPath (Join-Path $resolvedBuild $item.Exe))) + @(Get-ChildItem -LiteralPath $resolvedBuild -Filter '*.dll' -File)
    foreach ($file in $keep) {
        if ($file.DirectoryName -ne $resolvedBuild -or $file.LinkType) { throw 'Unexpected retained artifact source' }
        if ((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $identity.inputs[$file.FullName].sha256) { throw 'Artifact no longer matches immutable input' }
    }
    New-Item -Path $retainedPath -ItemType Directory | Out-Null
    $retained = @()
    foreach ($file in $keep) {
        $destination = Join-Path $retainedPath $file.Name
        $retained += [pscustomobject]@{ source = $file.FullName; destination = $destination; bytes = $file.Length; sha256 = $identity.inputs[$file.FullName].sha256 }
        Move-Item -LiteralPath $file.FullName -Destination $destination
    }
    Set-Content -LiteralPath (Join-Path $retainedPath '.hyle-owner') -Value ($item.Owner + '; immutable diagnostic EXE and adjacent DLLs retained for review')
    $removedBytes = (Get-ChildItem -LiteralPath $resolvedBuild -Recurse -File -Force | Measure-Object -Property Length -Sum).Sum
    Remove-Item -LiteralPath $resolvedBuild -Recurse -Force
    $records += [pscustomobject]@{ removed = $resolvedBuild; removed_bytes = $removedBytes; retained = $retained }
}
$receipt = Join-Path $workspacePath '.scratch\validation\onednn-aa-cause-b\cleanup.json'
$records | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt -Encoding utf8
$records | ForEach-Object { [pscustomobject]@{ removed = $_.removed; removed_bytes = $_.removed_bytes; retained_bytes = ($_.retained | Measure-Object -Property bytes -Sum).Sum } } | ConvertTo-Json
