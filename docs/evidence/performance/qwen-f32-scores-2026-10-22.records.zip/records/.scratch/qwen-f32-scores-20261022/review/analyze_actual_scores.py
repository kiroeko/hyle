"""Offline AC score-policy arithmetic and execution receipt analysis; no model run."""
from pathlib import Path
import csv, hashlib, io, json, math, re, struct
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
STAGE = ROOT / '.scratch/qwen-f32-scores-20261022'
CASES = ['ordinary-before', 'ordinary-after', 'mtp-single', 'mtp-warm-r2', 'mtp-pressure-r1']
V, K = 248320, 2048
raw_cache, identities, checks = {}, {}, []

def read(p):
    p = Path(p).resolve()
    if p not in raw_cache:
        data = p.read_bytes()
        raw_cache[p] = data
        identities[p] = dict(path=p.relative_to(ROOT).as_posix(), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return raw_cache[p]

def js(p): return json.loads(read(p).decode('utf-8-sig'))
def text(p): return read(p).decode('utf-8-sig')
def actual_receipts():
    freeze=js(STAGE/'source-freeze.json'); compiled=js(STAGE/'compile1/qwen/identity.json')
    compile_result=js(STAGE/'compile1/qwen/compile.result.json'); link_result=js(STAGE/'qwen-link1/link.result.json')
    link_plan=js(STAGE/'qwen-link1/link-plan.json'); ready=js(STAGE/'qwen-ready-attempt1.json')
    assert compile_result['terminal'] and compile_result['exit']==0 and link_result['terminal'] and link_result['exit']==0
    assert compiled['source']['sha256']==ready['source']['sha256']==freeze['files'][0]['current']['sha256']
    mtp=next(d for d in compiled['dependencies'] if d['path'].endswith('mtp_graph.h'))
    assert mtp['sha256']==freeze['files'][1]['current']['sha256']
    assert '/W4' in compile_result['command'] and '/WX' in compile_result['command'] and len(link_plan['inputs'])==195
    return dict(source=compiled['source'],mtp_header=mtp,object=compiled['object'],image=ready['image'],
        compile_result=identities[(STAGE/'compile1/qwen/compile.result.json').resolve()],
        link_result=identities[(STAGE/'qwen-link1/link.result.json').resolve()],
        source_freeze=identities[(STAGE/'source-freeze.json').resolve()],link_inputs=195,
        SDK_builds=link_plan['SDK_builds'],native_rebuilds=link_plan['native_rebuilds'],receipt_checks=True,
        note='Actual recorded compile/link/source/header identities checked; large exe, objects and complete shard are not rehashed by this host review.')
def check(condition, label):
    if not condition: raise AssertionError(label)
    checks.append(label)
def b16(data): return (np.frombuffer(data, '<u2').astype(np.uint32) << 16).view('<f4').astype(np.float64)
def fp32(data): return np.frombuffer(data, '<f4')
def bf16_rne(x):
    if x == 0: return x
    exponent = math.frexp(abs(x))[1] - 1
    unit = math.ldexp(1.0, max(exponent - 7, -133))
    return math.copysign(round(abs(x) / unit) * unit, x)
def ordered_f32(x):
    bits = struct.unpack('<I', struct.pack('<f', x))[0]
    return (~bits & 0xffffffff) if bits & 0x80000000 else (bits | 0x80000000)
def top2(row):
    candidates = np.argpartition(row, -2)[-2:]
    # Include every exact tie at the second score, then order by score and ID.
    cutoff = min(float(row[i]) for i in candidates)
    ids = np.flatnonzero(row >= cutoff)
    return sorted((int(i) for i in ids), key=lambda i: (-float(row[i]), i))[:2]

observations, execution, routes = {}, {}, {}
for case in CASES:
    base = STAGE/'cases1'/case
    obs = js(base/'parsed.json'); result = js(base/'run.result.json'); command = js(base/'run.command.json')
    stdout = json.loads(text(base/'run.stdout.log').splitlines()[-1]); plan = js(base/'plan.json')
    check(obs == stdout, case+': parsed equals actual stdout')
    check(result['terminal'] and result['exit'] == 0, case+': actual terminal success')
    check(command['command'] == result['command'] == plan['command'], case+': actual argv equals plan')
    check(result['command'][0] == plan['ready']['image']['path'], case+': image binds actual ready receipt')
    if case != 'ordinary-before':
        check(obs['score_dtype'] == 'F32' and obs['score_policy'] == 'bf16_inputs_f32_output', case+': declared F32 score policy')
    observations[case] = obs
    execution[case] = dict(result=identities[(base/'run.result.json').resolve()], command=result['command'],
        ready=plan['ready'], declared_score_policy=obs.get('score_policy', 'legacy BF16 projection then F32 cast'),
        diagnostic=obs['diagnostic'])
    rows = []
    for p in sorted((base/'trace/routes').glob('*.route.tsv')):
        hits = []
        for entry in csv.DictReader(io.StringIO(text(p)), delimiter='\t'):
            n = entry['nodes'].count(':bfloat-linear-f32')
            if n: hits.append(dict(step=int(entry['step']), provider=entry['provider'], nodes=entry['nodes'], count=n))
        count = sum(h['count'] for h in hits)
        role_match = re.search(r'role(\d+)-R(\d+)-T(\d+)', p.name)
        role = int(role_match[1]) if role_match else None
        expected = 0 if case == 'ordinary-before' else (2 if role in (3,4) else 1)
        check(count == expected, case+': route score count '+p.name)
        check(all(h['provider'] == 'ggml-cuda' for h in hits), case+': native score route '+p.name)
        rows.append(dict(path=p.relative_to(ROOT).as_posix(), role=role, count=count, selected=hits))
    routes[case] = rows

# Read only the safetensors header and the few selected embedding rows.
manifest = text(STAGE/'inputs/text/weights.tsv').splitlines()
mtp_manifest = text(STAGE/'inputs/mtp/weights.tsv').splitlines()
weight_line = next(l for l in manifest if l.startswith('model.language_model.embed_tokens.weight\t'))
check(weight_line in mtp_manifest, 'text and MTP use exactly the same BF16 embedding inventory row')
fields = weight_line.split('\t'); shard = Path(manifest[1]); offset, length = map(int, fields[-2:])
check(fields[1:5] == ['BF16','2',str(V),str(K)], 'original output-major BF16 tied weight geometry')
check(length == V*K*2 and manifest[1] == mtp_manifest[1], 'same physical original shard and row extent')
with shard.open('rb') as f:
    prefix = f.read(8); header_size = struct.unpack('<Q', prefix)[0]; header_bytes = f.read(header_size)
header = json.loads(header_bytes); entry = header['model.language_model.embed_tokens.weight']
check(entry['dtype'] == 'BF16' and entry['shape'] == [V,K], 'safetensors actual header BF16 [E,K]')
check(8+header_size+entry['data_offsets'][0] == offset, 'inventory offset equals actual safetensors payload offset')
weight_cache, weight_rows = {}, []
def weight_row(token):
    if token not in weight_cache:
        with shard.open('rb') as f:
            f.seek(offset+token*K*2); data=f.read(K*2)
        check(len(data)==K*2, 'selected original BF16 row extent '+str(token))
        weight_cache[token] = b16(data)
        check(bool(np.isfinite(weight_cache[token]).all()), 'selected weight finite '+str(token))
        weight_rows.append(dict(token=token, absolute_offset=offset+token*K*2, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return weight_cache[token]

phase_specs = []
for case in ('ordinary-before','ordinary-after'):
    for name, token in zip(['prefill','decode1','decode2','decode3'],observations[case]['generated_ids']):
        phase_specs.append((case, name, [token], 'ordinary'))
single = observations['mtp-single']
phase_specs.append(('mtp-single','prefill',[single['generated_ids'][0]],'prompt'))
for i, r in enumerate(single['rounds'],1):
    expected=[r['target_first']] + ([r['target_second']] if r['draft']>=0 else [])
    phase_specs.append(('mtp-single','mtp'+str(i),expected,'generation'))
for case in ('mtp-warm-r2','mtp-pressure-r1'):
    obs=observations[case]
    for i,s in enumerate(obs['sessions']):
        base=f"session{i}_{s['session_id']}"
        for record in s['ledger']:
            expected=[record['target_first']] + ([record['target_second']] if record['role'] in (3,4) else [])
            phase_specs.append((case,base+'/'+record['trace_name'],expected,'generation' if record['generation'] else 'prompt'))
        for restore in range(s['restore_count']):
            folder=STAGE/'cases1'/case/'trace'/base/'restores'/f'restore{restore}'
            episodes=sorted(folder.glob('episode*'),key=lambda p:int(p.name[7:]))
            check(len(episodes)==s['result']['restored_graph_calls'],case+': restore trace count '+s['session_id'])
            check(not s['result']['decision_changes'],case+': raw restore row IDs use unchanged recorded fresh predictions '+s['session_id'])
            for e in episodes:
                record=s['ledger'][int(e.name[7:])]
                phase_specs.append((case,e.relative_to(STAGE/'cases1'/case/'trace').as_posix(),[record['next_id']],'normal-recompute'))

phase_results, vector_summary, dot_checks = [], {}, []
u=2.0**-24; gamma=(K-1)*u/(1-(K-1)*u)
min_normal=float(np.finfo(np.float32).tiny); max_finite=float(np.finfo(np.float32).max)
for case,name,expected,kind in phase_specs:
    p=STAGE/'cases1'/case/'trace'/name
    hb,lb=read(p/'hidden.bf16'),read(p/'logits.f32')
    hidden=b16(hb).reshape(-1,K); logits=fp32(lb).reshape(-1,V)
    check(hidden.shape[0]==logits.shape[0]==len(expected),case+': exact raw output geometry '+name)
    check(bool(np.isfinite(hidden).all() and np.isfinite(logits).all()),case+': finite hidden and all vocabulary scores '+name)
    row_results=[]
    for r,want in enumerate(expected):
        row=logits[r]; actual=int(np.argmax(row)); chosen=top2(row)
        check(actual==want,case+': native ID equals own full-vocabulary argmax '+name+'/'+str(r))
        non_bf16=int(np.count_nonzero(row.view('<u4') & 0xffff))
        if case=='ordinary-before': check(non_bf16==0,'legacy scores are BF16 rounded '+name)
        else: check(non_bf16>0,'native F32 scores retain non-BF16 bits '+case+'/'+name+'/'+str(r))
        candidates=sorted(set(chosen+[198,271]))
        row_results.append(dict(row=r,expected_id=want,own_argmax=actual,
            top2=[dict(id=t,score=float(row[t])) for t in chosen], top2_margin=float(row[chosen[0]])-float(row[chosen[1]]),
            non_bf16_scores=non_bf16, scores_198_271={str(t):float(row[t]) for t in (198,271)}))
        for token in candidates:
            weights=weight_row(token); products=hidden[r]*weights
            ref=math.fsum(float(x) for x in products)
            value=float(row[token]); reference_f32=float(np.float32(ref)); error=abs(value-ref)
            nz=products[products!=0]
            # BF16 inputs have at most 8 significant bits: products need <=16,
            # so these finite products are exact F32 when within its exponent range.
            product_exact=bool(np.array_equal(products.astype(np.float32).astype(np.float64),products))
            min_quantum=math.ldexp(1.0,-max((float(x).as_integer_ratio()[1].bit_length()-1 for x in nz),default=0))
            sumabs=math.fsum(abs(float(x)) for x in products)
            safe=product_exact and min_quantum>=min_normal and sumabs<max_finite
            bound=gamma*sumabs
            check(safe,case+': finite standard F32 dot model preconditions '+name+'/'+str(r)+'/'+str(token))
            is_new=case!='ordinary-before'
            if is_new: check(error<=bound,case+': standard F32 forward-error comparison '+name+'/'+str(r)+'/'+str(token))
            old_round=bf16_rne(ref)
            dot_checks.append(dict(case=case,phase=name,row=r,token=token,actual=value,fp64_dot=ref,
                nearest_f32=reference_f32,abs_error=error,relative_error=error/abs(ref) if ref else None,
                ulp_distance_to_nearest_f32=abs(ordered_f32(value)-ordered_f32(reference_f32)),
                reference_bf16_rne=old_round,actual_equals_reference_bf16_rne=value==old_round,
                product_exact_in_f32=product_exact,minimum_exact_sum_quantum=min_quantum,sum_abs_products=sumabs,
                gamma_2047_bound=bound,new_score_within_standard_bound=(error<=bound) if is_new else None))
    phase_results.append(dict(case=case,phase=name,kind=kind,rows=len(expected),hidden=identities[(p/'hidden.bf16').resolve()],logits=identities[(p/'logits.f32').resolve()],decisions=row_results))
    vector_summary.setdefault(case,dict(files=0,rows=0,finite_hidden_elements=0,finite_logits_elements=0))
    count=vector_summary[case]; count['files']+=2; count['rows']+=len(expected);count['finite_hidden_elements']+=hidden.size;count['finite_logits_elements']+=logits.size

ordinary=[]
for name in ['prefill','decode1','decode2','decode3']:
    a=STAGE/'cases1/ordinary-before/trace'/name;b=STAGE/'cases1/ordinary-after/trace'/name
    check(read(a/'hidden.bf16')==read(b/'hidden.bf16'),'upstream hidden byte-identical '+name)
    x,y=fp32(read(a/'logits.f32')).astype(np.float64),fp32(read(b/'logits.f32')).astype(np.float64)
    rounded=np.array([bf16_rne(float(v)) for v in y],dtype=np.float64)
    ordinary.append(dict(phase=name,hidden_byte_equal=True,logits_byte_equal=read(a/'logits.f32')==read(b/'logits.f32'),
        differing_logits=int(np.count_nonzero(x!=y)),max_abs_score_change=float(np.max(np.abs(x-y))),
        rel_l2_score_change=float(np.linalg.norm(x-y)/np.linalg.norm(x)),
        old_equals_bf16_rne_of_new_count=int(np.count_nonzero(x==rounded)),vocabulary=V))
check(observations['ordinary-before']['decode_input_ids']==observations['ordinary-after']['decode_input_ids']==[198,248045,74455],'same teacher-forced upstream inputs')
check(observations['ordinary-before']['generated_ids']==observations['ordinary-after']['generated_ids'],'ordinary four IDs unchanged')

# Compare actual restored episode IDs in stderr with the exact restored trace order.
restore_lines=re.findall(r'^episode(\d+) tokens=\d+ visible=\d+ .* next=(\d+)\r?$',text(STAGE/'cases1/mtp-pressure-r1/run.stderr.log'),re.M)
restore_specs=[s for s in phase_specs if s[0]=='mtp-pressure-r1' and s[3]=='normal-recompute']
check(len(restore_lines)==len(restore_specs)==10,'ten actual restore output endpoints')
for (index,token),(_,phase,expected,_) in zip(restore_lines,restore_specs):
    check(phase.endswith('episode'+index) and expected==[int(token)],'restore stdout-ledger/raw/stderr ID '+phase)

work={}
for case in ('mtp-warm-r2','mtp-pressure-r1'):
    obs=observations[case]; batches=obs['batches']; all_records=[]; sessions=[]
    check(len(batches)+obs['restored_graph_calls']==obs['actual_graph_calls'],case+': real batches plus restores equals global calls')
    check(sum(b['requests'] for b in batches)==obs['graph_participations'],case+': batch participations counted separately')
    check(sum(not b['generation'] for b in batches)==obs['prefill_graph_calls'],case+': physical prompt batches')
    check(sum(b['generation'] for b in batches)==obs['decode_graph_calls'],case+': physical generation batches')
    for s in obs['sessions']:
        r=s['result']; records=s['ledger']; all_records.extend(records); emitted=[]; previous_length=0; previous_pending=None
        for record in records:
            check(record['before_length']==previous_length,case+': continuous committed length '+s['session_id']+'/'+str(record['index']))
            check(record['before_frontier']+record['before_lag']==record['before_length'],case+': before frontier and lag')
            check(record['after_frontier']+record['after_lag']==record['after_length'],case+': after frontier and lag')
            check(record['after_length']==record['before_length']+record['accepted'],case+': exact accepted boundary')
            if record['generation']:
                check(record['first_input']==previous_pending,case+': generation uses actual emitted pending')
                check(1<=record['accepted']<=min(2,record['quota']),case+': acceptance respects remaining quota')
                check(record['committed_input_ids'][0]==record['first_input'],case+': teacher-forced committed tape begins with pending')
                if record['accepted']==2:
                    check(record['draft']==record['target_first'] and record['committed_input_ids']==[record['first_input'],record['draft']],case+': accepted draft is actual input')
                    emitted.extend([record['draft'],record['target_second']])
                else: emitted.append(record['target_first'])
            else:
                check(record['accepted']==record['input_rows'] and record['after_lag']==0,case+': prompt accepts its real input and synchronizes draft')
                check(record['draft_rows']==record['input_rows']+record['before_lag'],case+': warm draft row accounting')
                if record['turn']>1: check(record['first_input']==previous_pending,case+': warm prompt flushes prior emitted pending once')
                emitted.append(record['target_first'])
            previous_pending=emitted[-1];previous_length=record['after_length']
        check(emitted==r['generated_ids'],case+': ledger reproduces emitted token history '+s['session_id'])
        check(previous_length==r['visible_tokens'] and previous_pending==r['emitted_pending']==r['generated_ids'][-1],case+': final state and policy pending')
        check(r['draft_frontier']+r['draft_lag']==r['visible_tokens'] and r['fresh_next_id']==records[-1]['next_id'],case+': fresh prediction and complete state boundary')
        check(len(records)+r['restored_graph_calls']==r['graph_participations'],case+': per-session actual graph participations')
        check(math.isclose(r['prefill_seconds']+r['decode_seconds']+r['between_turn_seconds'],r['session_seconds'],rel_tol=1e-12,abs_tol=1e-12),case+': per-session idle wall explicit')
        turn_outputs=[]
        for turn in r['turns']:
            ids=r['generated_ids'][turn['output_begin']:turn['output_end']]
            check(0<len(ids)<=turn['requested_steps'],case+': finite natural turn quota')
            check(len(ids)==turn['requested_steps'] or ids[-1]==248046,case+': early turn termination is EOS')
            turn_outputs.append(dict(turn=turn['turn'],outputs=len(ids),quota=turn['requested_steps'],last_id=ids[-1]))
        sessions.append(dict(id=s['session_id'],generated_ids=r['generated_ids'],turns=turn_outputs,visible=r['visible_tokens'],draft_frontier=r['draft_frontier'],draft_lag=r['draft_lag'],emitted_pending=r['emitted_pending'],fresh_next_id=r['fresh_next_id'],restored_graph_calls=r['restored_graph_calls'],normalized_lag_rows=r['normalized_lag_rows'],decision_changes=r['decision_changes']))
    target=sum((2 if x['role'] in (3,4) else 1) if x['generation'] else x['input_rows'] for x in all_records)
    drafted=sum(x['draft_rows'] for x in all_records)
    check(target+obs['restored_target_rows']==obs['actual_target_rows'],case+': all real target rows including restore')
    check(drafted+obs['restored_draft_rows']==obs['actual_draft_rows'],case+': all real draft rows including restore')
    check(sum(x['accepted'] for x in all_records)==obs['committed_target_rows'],case+': committed target rows separate from verified work')
    check(sum(len(s['result']['generated_ids']) for s in obs['sessions'])==obs['generated_tokens'],case+': global actual outputs')
    check(obs['peak_committed_versions']<=obs['max_sessions'] and obs['live_committed_versions']==0,case+': bounded committed budget and real terminal release')
    check(math.isclose(obs['prefill_seconds']+obs['decode_seconds'],obs['session_seconds'],rel_tol=1e-12,abs_tol=1e-12),case+': disjoint global prompt and generation wall')
    work[case]={k:obs[k] for k in ['active_sequences','max_sessions','shared_backing_bytes','peak_resident_requests','peak_committed_versions','live_committed_versions','actual_graph_calls','graph_participations','generated_tokens','actual_target_rows','actual_draft_rows','committed_target_rows','restore_count','restored_graph_calls','restored_target_rows','restored_draft_rows','normalized_lag_rows','recomputed_decision_changes','idle_evictions','prefill_seconds','decode_seconds','session_seconds']}
    work[case].update(sessions=sessions,batches=batches)
check(any(b['requests']==2 and b['role']==7 and b['tokens']==2 for b in observations['mtp-warm-r2']['batches']),'actual R2 lag1 warm target2/draft3 graph executed')
check(observations['mtp-pressure-r1']['max_sessions']==1 and observations['mtp-pressure-r1']['restored_graph_calls']==10 and observations['mtp-pressure-r1']['restore_count']==3,'actual N1 pressure and ten native recompute episodes')

new=[d for d in dot_checks if d['case']!='ordinary-before']; legacy=[d for d in dot_checks if d['case']=='ordinary-before']
report=dict(schema='qwen-f32-scores-actual-analysis-v1',status='offline_actual_raw_review_complete',
    scope='Five serial parent-run diagnostic processes; one execution each, not a performance window or full-model quality gate.',
    score_policy='bf16_inputs_f32_output', execution=execution,actual_routes=routes,
    ordinary_control=ordinary,ordinary_ids=observations['ordinary-after']['generated_ids'],
    vector_summary=vector_summary,raw_phases=phase_results,actual_mtp_work=work,
    independent_last_projection=dict(reference='math.fsum of original BF16 hidden * original BF16 tied embedding row, products represented exactly in FP64; full vocab inference is not independently recomputed.',
        shard=str(shard),shard_bytes=shard.stat().st_size,manifest_weight_line=weight_line,
        header_bytes_read=8+header_size,header_sha256=hashlib.sha256(prefix+header_bytes).hexdigest(),selected_weight_rows=weight_rows,
        selected_weight_bytes_read=len(weight_rows)*K*2,candidate_policy='Each own top two tokens plus tokens 198 and 271, exact row reads only.',
        standard_bound=dict(u=u,gamma_2047=gamma,formula='gamma_(2047) * sum(abs(hidden_i * weight_i))',
            meaning='Conditional conventional F32 dot forward-error comparison, not a quality tolerance or proof of every implementation instruction. BF16 products were checked exact in F32, sumabs prevents overflow and exact product quantum excludes nonzero subnormal intermediate sums; actual F32 errors compared with the derived bound.',
            all_new_comparisons_within_bound=all(d['new_score_within_standard_bound'] for d in new)),
        summary=dict(new_checks=len(new),legacy_checks=len(legacy),new_max_abs_error=max(d['abs_error'] for d in new),
            new_max_relative_error=max(d['relative_error'] or 0 for d in new),new_max_f32_ulp_distance=max(d['ulp_distance_to_nearest_f32'] for d in new),
            legacy_matches_direct_bf16_rne=sum(d['actual_equals_reference_bf16_rne'] for d in legacy),legacy_total=len(legacy)),comparisons=dot_checks),
    limitations=['New policy changes final score arithmetic intentionally; identical ordinary hidden and four IDs do not prove full model quality.',
        'Draft hidden/logits are not exported. Draft coverage is the declared shared operation, actual selected routes, and natural MTP decisions; no independent complete draft oracle is claimed.',
        'No B1/B2 quality-equivalence assertion, no newly measured throughput or physical allocation attribution, no new execution/build/GPU work by this analyzer.'],
    analyzer_history=['First offline analyzer attempt completed numeric work but its final stderr regex rejected CRLF. Regex corrected and analyzer rerun; no model/build/GPU was rerun, original payloads unchanged.'],
    check_count=len(checks),checks_passed=True,actual_source=actual_receipts(),analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_identities=list(identities.values()))
out=STAGE/'review/actual-score-analysis.json';out.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(dict(report=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),checks=len(checks),vectors=vector_summary,dot_summary=report['independent_last_projection']['summary'])))
