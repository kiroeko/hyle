"""Independent AC raw-log/sample arithmetic; no native/model imports or runs."""
from collections import defaultdict
from pathlib import Path
import hashlib
import json
import math
import re
import statistics

S = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
ARMS = ("before_MTP", "after_MTP", "peer_MTP")
MEM_KEYS = ("gpu_dedicated_bytes", "gpu_shared_bytes", "gpu_total_bytes", "working_set_bytes", "private_commit_bytes")
WORK_KEYS = ("actual_graph_calls", "target_compute_calls", "draft_compute_calls", "target_decode_calls", "draft_decode_calls",
             "actual_target_rows", "actual_draft_rows", "verified_target_rows", "committed_target_rows", "committed_target_decode_rows",
             "prefill_target_rows", "prefill_draft_rows", "draft_rows", "draft_decode_rows", "draft_rounds", "proposals",
             "agreements", "accepted_drafts", "visible_tokens", "draft_frontier", "draft_lag")


def unique(items):
    d = {}
    for k, v in items:
        if k in d:
            raise ValueError("duplicate JSON key: " + k)
        d[k] = v
    return d


def load(p):
    return json.loads(p.read_text(encoding="utf-8"), object_pairs_hook=unique)


def identity(p):
    b = p.read_bytes()
    return {"path": str(p.relative_to(S)), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}


def stats(xs):
    return {"count": len(xs), "median": statistics.median(xs) if xs else None,
            "min": min(xs) if xs else None, "max": max(xs) if xs else None}


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-10, abs_tol=2e-9), (a, b)


def raw_result(p):
    result = load(p / "result.json")
    assert result["exit"] == 0 and not result.get("reader_errors")
    if (p / "consumer-result.json").exists():
        raw = load(p / "consumer-result.json")
    else:
        raw = json.loads(next(x for x in reversed((p / "stdout.log").read_text(encoding="utf-8").splitlines())
                              if x.startswith("{")), object_pairs_hook=unique)
    return raw, result


def inspect(p):
    raw, terminal = raw_result(p)
    ids = raw.get("generated_ids", raw.get("predicted_ids"))
    assert len(ids) == 64 and not any(x in (248044, 248046) for x in ids)
    pref, dec, session = (raw[x] for x in ("prefill_seconds", "decode_seconds", "session_seconds"))
    close(pref + dec, session)
    stderr = (p / "stderr.log").read_text(encoding="utf-8")
    load_seconds = raw.get("weights_load_seconds")
    if load_seconds is None:
        load_seconds = float(re.search(r"^weights_load_seconds=([^\s]+)", stderr, re.M)[1])
    startup = raw["startup_to_endpoint_seconds"]
    ttft = raw.get("first_token_elapsed_seconds")
    if ttft is None:
        points = [x for x in raw["phase_points"] if x["name"] == "generation_prefill_end"]
        assert len(points) == 1
        ttft = points[0]["elapsed_seconds"]
        close(ttft, startup - dec)
    ready = raw["startup_to_ready_seconds"]
    assert 0 < load_seconds <= ready <= ttft <= startup
    for k in ("requested_context", "capacity", "context_capacity"):
        if k in raw:
            assert raw[k] == 1024
    for flag, value in (("--steps", "64"), ("--capacity", "1024"), ("--mtp", "on")):
        assert terminal["command"].count(flag) == 1 and terminal["command"][terminal["command"].index(flag) + 1] == value
    assert raw["generated_tokens"] == 64 and raw["generated_decode_tokens"] == 63
    if "committed_target_rows" in raw:
        assert raw["committed_target_rows"] == 217
    if "processed_tokens" in raw:
        assert raw["processed_tokens"] == 217
    rebuilt_ids = [ids[0]]
    accepted = verified = draft_rows = agreed = 0
    decision_rows = []
    for row in raw["rounds"]:
        assert row["pending"] == rebuilt_ids[-1]
        target = row.get("target_ids", [row.get("target_first"), row.get("target_second")])
        emitted = row.get("emitted", target[:2 if row["accepted_draft"] else 1])
        assert len(emitted) == row["committed_target_rows"]
        rebuilt_ids.extend(emitted)
        accepted += int(row["accepted_draft"])
        verified += row.get("verified_target_rows", 2 if target[1] is not None and target[1] >= 0 else 1)
        draft_rows += row["draft_rows"]
        agreed += int(row.get("agreed", target[0] == row["draft"]))
        decision_rows.append([row["pending"], row["draft"], target, emitted,
                              row["accepted_draft"], row["committed_target_rows"], row["draft_rows"]])
    assert rebuilt_ids == ids and accepted == raw["accepted_drafts"] and verified == raw["verified_target_rows"]
    assert raw["actual_target_rows"] == 154 + verified and raw["actual_draft_rows"] == 154 + draft_rows
    assert raw["visible_tokens"] == 217 and raw["visible_tokens"] - raw["draft_frontier"] == raw["draft_lag"]
    proposals = raw.get("proposals", raw.get("draft_rounds"))
    assert proposals == len(raw["rounds"])
    prepared = [dict(re.findall(r"(\w+)=([^\s]+)", x)) for x in stderr.splitlines() if x.startswith("prepared ")]
    captures = None
    if prepared:
        assert len(prepared) == raw["actual_graph_calls"]
        captures = {"recorded_ranges": sum(int(x["capture_recorded"]) for x in prepared[1:]),
                    "reused_ranges": sum(int(x["capture_reused"]) for x in prepared[1:]),
                    "inclusive_decode_cold_batch_seconds": sum(float(x["cold_batch_seconds"]) for x in prepared[1:])}
    metrics = {"prefill_tps": 154 / pref, "decode_tps": 63 / dec, "session_output_tps": 64 / session,
               "prefill_seconds": pref, "decode_seconds": dec, "session_seconds": session,
               "load_seconds": load_seconds, "ready_seconds": ready, "TTFT_seconds": ttft,
               "startup_to_endpoint_seconds": startup, "cold_output_tps": 64 / startup}
    return {"folder": str(p.relative_to(S)), "image": terminal["image"], "metrics": metrics,
            "actual_ids": ids, "work": {k: raw.get(k) for k in WORK_KEYS},
            "decision_fingerprint": hashlib.sha256(json.dumps(decision_rows, sort_keys=True).encode()).hexdigest(),
            "acceptance": {"accepted": accepted, "proposals": proposals, "fraction": accepted / proposals},
            "captures": captures, "score_policy": raw.get("score_policy"),
            "evidence": [identity(p / x) for x in ("result.json", "stderr.log", "stdout.log")
                         if (p / x).exists()]}, raw


timing = defaultdict(list)
raws = {}
for p in sorted((S / "performance/timing").glob("[0-9]*-*")):
    arm = p.name.split("-", 1)[1]
    record, raw = inspect(p)
    timing[arm].append(record)
    raws.setdefault(arm, raw)
assert set(timing) == set(ARMS) and all(len(timing[a]) == 3 for a in ARMS)
summary = {}
existing = load(S / "performance/timing/summary.json")
metric_aliases = {"prefill_tps": "prefill_tokens_per_second", "decode_tps": "full_decode_tokens_per_second",
                  "session_output_tps": "session_output_tokens_per_second", "load_seconds": "weights_load_seconds",
                  "ready_seconds": "startup_to_ready_seconds", "TTFT_seconds": "first_token_elapsed_seconds",
                  "cold_output_tps": "cold_output_tokens_per_second"}
for arm in ARMS:
    selected = timing[arm]
    assert all(x["actual_ids"] == selected[0]["actual_ids"] and x["work"] == selected[0]["work"]
               and x["decision_fingerprint"] == selected[0]["decision_fingerprint"] for x in selected)
    metrics = {k: stats([x["metrics"][k] for x in selected]) for k in selected[0]["metrics"]}
    for k, v in metrics.items():
        expected = existing["groups"][arm][metric_aliases.get(k, k)]
        for stat in ("median", "min", "max"):
            close(v[stat], expected[stat])
    summary[arm] = {"metrics": metrics, "stable64_IDs_and_work_all3": True,
                    "work": selected[0]["work"], "acceptance": selected[0]["acceptance"],
                    "capture_ledgers": [x["captures"] for x in selected]}


def differences(a, b):
    mismatches = [i for i, (x, y) in enumerate(zip(a, b)) if x != y]
    first = mismatches[0] if mismatches else None
    return {"equal": a == b, "mismatch_count": len(mismatches), "first_zero_based": first,
            "first_values": None if first is None else [a[first], b[first]]}


between = {a + "__" + b: differences(timing[a][0]["actual_ids"], timing[b][0]["actual_ids"])
           for i, a in enumerate(ARMS) for b in ARMS[i + 1:]}
assert between["before_MTP__after_MTP"]["equal"]
assert timing["before_MTP"][0]["decision_fingerprint"] == timing["after_MTP"][0]["decision_fingerprint"]
assert timing["before_MTP"][0]["work"] == timing["after_MTP"][0]["work"]
assert between["after_MTP__peer_MTP"]["first_zero_based"] == 18


memory = {}
for p in sorted((S / "performance/memory").glob("[0-9]*-*")):
    arm = p.name.split("-", 1)[1]
    observed, _ = inspect(p)
    assert observed["actual_ids"] == timing[arm][0]["actual_ids"] and observed["work"] == timing[arm][0]["work"]
    data, terminal = load(p / "memory.json"), load(p / "result.json")
    retained = load(p / "memory-summary.json")
    all_rows = data["samples"]
    rows = [x for x in all_rows if x["process_running"]]
    for x in all_rows:
        expected_total = x["gpu_dedicated_bytes"] + x["gpu_shared_bytes"] if x.get("gpu_dedicated_bytes") is not None and x.get("gpu_shared_bytes") is not None else None
        assert x.get("gpu_total_bytes") == expected_total
    peaks = {k: max((x[k] for x in rows if x.get(k) is not None), default=None) for k in MEM_KEYS}
    aliases = {"gpu_dedicated_bytes": "sampled_peak_gpu_dedicated_bytes", "gpu_shared_bytes": "sampled_peak_gpu_shared_bytes",
               "gpu_total_bytes": "sampled_peak_gpu_total_bytes", "working_set_bytes": "sampled_max_working_set_bytes",
               "private_commit_bytes": "sampled_max_private_commit_bytes"}
    assert all(peaks[k] == retained["sampled_peaks"][aliases[k]] for k in MEM_KEYS)
    gaps = stats([(b["timestamp_ns"] - a["timestamp_ns"]) / 1e6 for a, b in zip(rows, rows[1:])])
    for k in ("median", "min", "max"):
        close(gaps[k], retained["actual_sample_gaps_ms"][k])
    costs = stats([x["sample_duration_ns"] / 1e6 for x in rows])
    marker = {x["name"]: x["timestamp_ns"] for x in terminal["markers"]}
    assert len(marker) == len(terminal["markers"])
    ready_rows = [x for x in rows if marker["ready_before_first"] <= x["timestamp_ns"] <= marker["generation_prefill_begin"]]
    assert not ready_rows and retained["ready_baseline"]["unknown"]
    phases = {}
    for phase in ("generation_prefill", "generation_decode"):
        begin, end = marker[phase + "_begin"], marker[phase + "_end"]
        inside = [x for x in rows if begin <= x["timestamp_ns"] <= end]
        before = max((x for x in rows if x["timestamp_ns"] <= begin), key=lambda x: x["timestamp_ns"], default=None)
        after = min((x for x in rows if x["timestamp_ns"] >= end), key=lambda x: x["timestamp_ns"], default=None)
        delta = {k: after[k] - before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in MEM_KEYS}
        peak = {k: max((x[k] for x in inside if x.get(k) is not None), default=None) for k in MEM_KEYS}
        expected = retained["phase_windows"][phase]
        assert len(inside) == expected["sample_count"] and delta == expected["bracket_delta_bytes"]
        assert all(peak[k] == expected["values"][k]["max"] for k in MEM_KEYS)
        phases[phase] = {"sample_count": len(inside), "sampled_peaks_bytes": peak,
                         "bracket_delta_bytes": delta, "bracket_ages_ms": {
                             "before": (begin - before["timestamp_ns"]) / 1e6 if before else None,
                             "after": (after["timestamp_ns"] - end) / 1e6 if after else None},
                         "null_counts": {k: sum(x.get(k) is None for x in inside) for k in MEM_KEYS}}
    memory[arm] = {"folder": str(p.relative_to(S)), "sample_count": len(all_rows), "running_samples": len(rows),
                   "sampled_peaks_bytes": peaks, "actual_running_gaps_ms": gaps, "sample_cost_ms": costs,
                   "sampler_setup_ms": data["setup_duration_ns"] / 1e6,
                   "null_counts_all_samples": {k: sum(x.get(k) is None for x in all_rows) for k in MEM_KEYS},
                   "null_counts_running_samples": {k: sum(x.get(k) is None for x in rows) for k in MEM_KEYS},
                   "ready_baseline": None, "ready_unknown": True, "phases": phases,
                   "GPU_setup_error": data["gpu_setup_error"], "sampler_thread_error": data["thread_error"],
                   "actual_ids_and_work_match_own_timing_arm": True,
                   "evidence": [identity(p / x) for x in ("result.json", "memory.json", "memory-summary.json")]}
assert set(memory) == set(ARMS)


def contrast(a, b, metric):
    x, y = summary[a]["metrics"][metric], summary[b]["metrics"][metric]
    return {"median_percent": (x["median"] / y["median"] - 1) * 100,
            "ranges_overlap": max(x["min"], y["min"]) <= min(x["max"], y["max"])}


report = {
    "status": "PASS_OFFLINE_ENDPOINT_WORK_SAMPLE_ARITHMETIC; NO_QUALITY_OR_UNIVERSAL_SPEED_CLAIM",
    "scope": "Existing AC9 unmonitored timing +3 independent monitored processes, one P154/64 natural MTP workload, C1024/N1R1. No new native/model computation/build or product/old result edits.",
    "input": identity(S / "performance/timing/inputs.json"),
    "checker": identity(Path(__file__)),
    "fixed_work": {"within_each_arm_all3_actual64_ids_and_work_stable": True,
                   "all12_processes_exit0": True, "all_timing_P_plus_D_equals_session": True,
                   "formulas": {"P": "154/prefill_seconds", "D": "63/decode_seconds", "total": "64/session_seconds", "cold": "64/startup_to_endpoint_seconds"},
                   "statistics": "Each process ratio first, then median/min/max of3; no pooled denominators or phase TPS averages."},
    "public_table": {arm: {"prefill_tps": summary[arm]["metrics"]["prefill_tps"],
                           "decode_tps": summary[arm]["metrics"]["decode_tps"],
                           "total_output_tps": summary[arm]["metrics"]["session_output_tps"],
                           "independent_memory_sampled_peaks_bytes": memory[arm]["sampled_peaks_bytes"]} for arm in ARMS},
    "timing_summary": summary,
    "per_process_timing": {arm: [{k: x[k] for k in ("folder", "metrics", "captures", "decision_fingerprint")}
                                 for x in timing[arm]] for arm in ARMS},
    "natural_output_comparison": between,
    "current_vs_before_descriptive": {k: contrast("after_MTP", "before_MTP", k) for k in ("prefill_tps", "decode_tps", "session_output_tps")},
    "independent_memory": memory,
    "current_minus_before_sampled_peak_bytes": {k: memory["after_MTP"]["sampled_peaks_bytes"][k] - memory["before_MTP"]["sampled_peaks_bytes"][k] for k in MEM_KEYS},
    "conclusions": [
        "This window's Hyle BF16-score and F32-score policies happen to produce identical64 IDs, rounds/work counters and18record/50reuse. This finite result does not establish mathematical equivalence, general quality or the absence of score differences.",
        "The F32-score Hyle median P/D/session rates are slightly lower; all three before/current ranges overlap. No speed improvement is demonstrated. Cold load/ready/startup ranges also overlap and are not evidence of a reproducible startup win.",
        "Native F32 MTP first differs at zero-based output18 (19th): Hyle11/native271, then follows different tokens. It uses30/33 accepted proposals and220target/216draft rows versus Hyle29/34 and222/216. Its descriptive rates are not a same-token cross-engine implementation-speed or quality victory.",
        "Both Hyle arms actually report35Graph calls; native reports34target+34draft compute calls from its two-context chain. These are different work units, not a directly comparable Graph-call count. Missing native capture counters remain null.",
        "Current dedicated sampled peak exceeds before by109051904bytes (104MiB), with unchanged shared peak. This is one monitored process per arm and a sampled process-memory observation, not an exact allocation/reservation delta."
    ],
    "limits": [
        "Before Hyle scores are BF16 projection castF32; current Hyle scores use BF16 operands with F32 output. Native also has different intermediate arithmetic/state/prefill work. No cross-policy or cross-engine identical-math claim.",
        "Only3 fresh timing samples per arm on a normal desktop card; ranges and backgrounds matter, no significance or universal throughput claim. Historical W/V windows are not pooled.",
        "Consumer complete host endpoints determine TPS; parent process wall and stderr marker arrival do not replace them. Per-step/cold/capture buckets cannot be subtracted as a proven removable cost.",
        "Requested10ms memory sampling has measured roughly15ms median gaps plus marker-near samples. All ready baselines are unknown/null. Phase peaks use only actual samples; short phases and boundary-near deltas are approximate and can include subsequent work/teardown.",
        "GPU bytes are WDDM PDH process-memory counters, CPU WS/commit are PSAPI. Peaks are sampling lower bounds. Dedicated/shared independent peaks must not be summed; total is maximum same-sample addition. CPU WS/commit/GPU shared overlap and are not physical-allocation totals.",
        "All null values remain null. GPU unavailable counts include early/exit no-PID intervals and are separated from process-running null counts. Memory-process timing never enters the timing table.",
        "No new kernel trace, quality threshold, model-math run or broader workload was added. This review does not mark the broader goal complete."
    ],
    "model_runs": 0, "GPU_runs": 0, "builds": 0,
}
path = OUT / "actual-window-analysis.json"
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": identity(path), "table": {a: {"P": summary[a]["metrics"]["prefill_tps"]["median"], "D": summary[a]["metrics"]["decode_tps"]["median"], "total": summary[a]["metrics"]["session_output_tps"]["median"]} for a in ARMS}}))
