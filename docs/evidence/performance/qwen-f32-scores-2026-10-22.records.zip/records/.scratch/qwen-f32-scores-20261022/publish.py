"""Publish F32 score semantics, finite checks and the actual four-metric window."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
C=Path(__file__).resolve().parent;R=C.parents[1];A=R/'.scratch/qwen-mtp-batch-20261022'
O=R/'docs/evidence/performance';NAME='qwen-f32-scores-2026-10-22'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())
sources=['tools/qwen35_text/main.cc','tools/qwen35_text/mtp_graph.h','tools/qwen35_text/README.md','docs/developer/current-work.md'];frozen=[]
for name in sources:
 p=R/name;before=C/'before'/name;assert before.exists(),name
 snapshot=C/'current'/name;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(p.read_bytes())
 diff=C/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
 check=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
 assert check.returncode in(0,1)and not(check.stdout.strip()or check.stderr.strip()),(name,check.stdout,check.stderr)
 frozen.append(dict(source=identity(p),snapshot=identity(snapshot),before=identity(before),diff=identity(diff)))
save(C/'product-freeze.json',dict(files=frozen))
ready=read(C/'qwen-ready-attempt1.json');old=read(A/'qwen-ready-attempt1.json')
assert all(identity(ready[k]['path'])==ready[k]for k in('source','main','image','runtime_environment'))
assert identity(old['image']['path'])==old['image']
old_source=identity(A/'current/tools/qwen35_text/main.cc');assert(old_source['bytes'],old_source['sha256'])==(old['source']['bytes'],old['source']['sha256'])
link=read(ready['link_plan']['path']);compiled=read(link['compiled_record']['path'])
assert len(link['inputs'])==195 and link['inputs'][1:]==read(link['base']['path'])['inputs'][1:]
assert all(identity(d['path'])==d for d in compiled['dependencies'])
reports={p.name:read(p)for p in sorted((C/'review').glob('*.json'))}
score=reports['actual-score-analysis.json'];assert score['checks_passed']and score['check_count']==1025
assert score['status']=='offline_actual_raw_review_complete'
window_review=reports['actual-window-analysis.json'];assert window_review['status'].startswith('PASS')
timing=read(C/'performance/timing/summary.json');memory=read(C/'performance/memory/summary.json')
assert timing['processes']==9 and memory['processes']==3
assert timing['fixed_work_window_valid']and memory['fixed_work_window_valid']
assert timing['between_arm_first_process_outputs']['before_MTP__after_MTP']['equal']
assert timing['between_arm_first_process_outputs']['after_MTP__peer_MTP']['first_divergence']==18
assert memory['groups']['after_MTP']['sampled_peaks']['sampled_peak_gpu_dedicated_bytes']-memory['groups']['before_MTP']['sampled_peaks']['sampled_peak_gpu_dedicated_bytes']==109051904
runs=[]
for p in sorted((C/'cases1').glob('*/run.result.json')):
 t=read(p);assert t['terminal']and t['exit']==0
 runs.append(dict(category='diagnostic',command=t['command'],terminal=identity(p),performance_evidence=False))
assert len(runs)==5
for mode,count in(('timing',9),('memory',3)):
 files=sorted((C/'performance'/mode).glob('*/result.json'));assert len(files)==count
 for p in files:
  t=read(p);assert t['exit']==0 and not t['reader_errors']
  runs.append(dict(category=mode,command=t['command'],terminal=identity(p),performance_evidence=mode=='timing'))
assert len(runs)==17
summary=dict(status='Explicit BF16 operand/F32 terminal score policy implemented and checked; actual window shows no speed improvement and a higher sampled dedicated-memory peak; broader goal active',date='2026-10-22',
 product_freeze=identity(C/'product-freeze.json'),ready=ready,before_ready=old,before_frozen_source=old_source,
 build_scope=dict(host_compile_attempts=1,successful_host_compiles=1,successful_links=1,consumer_TUs=1,library_TUs=0,SDK_builds=0,NVCC_builds=0,full_configures=0,reused_link_inputs=194),
 actual_model_processes=17,diagnostic_processes=5,timing_processes=9,independent_memory_processes=3,actual_runs=runs,
 reports=reports,performance=dict(timing=timing,memory=memory),
 findings=[
  'A consumer-private Recipe::scores uses existing public BFloatLinearF32 for target and MTP draft terminal projections. Original dense[E,K] BF16 weight and BF16 hidden are inputs; F32 is the declared score output. Generic MatMul, intermediate linears and original execution/state/retirement mechanisms remain unchanged.',
  'No new public API, hidden result-dtype exception, provider-specific consumer branch, execution path or runtime compatibility mode was added. Fixed score_policy and score_dtype are reported; checkpoints remain isolated by Model and its compiled mathematical family.',
  'Actual retained195-input closure contains the declared operation and native BF16/BF16-to-F32 branch. No SDK, kernel or library rebuild occurred. Source-supported device/environment conditions are explicit; this does not promise every backend physically avoids conversions.',
  'Five actual diagnostic processes cover matched ordinary P15 plus three fixed decode inputs, single MTP, real R2 warm lag1 input and N1 pressure. Ordinary four hidden payloads are byte equal. All993280 original logits equal BF16-RNE(newF32), demonstrating changed final score rounding with identical observed upstream hidden.',
  'The98 raw files contain64 target rows; all finite and each own-row argmax matches actual ID. Independent selected original-weight FP64 dots comprise190 newF32 and11 oldBF16 scores; new maximum absolute error1.1197827e-4, relative4.72094e-6 and74F32ULP, all within the condition-checked gamma2047*sum(abs(products)) FP32 accumulation bound. This is finite terminal arithmetic evidence, not full model quality.',
  'Draft final hidden is not exported here: actual shared operation/route and natural draft/accept execution are covered, not an independent full draft score/model oracle. R2 warm uses5physical Graphs/9member participations; N1 three rebuilds use29=19+10Graph and64target/64draft recovery rows, normalize one lag row and finish with no live committed versions.',
  'Natural P154/64 C1024/N1R1 window uses three interleaved timing processes and one independent monitored process per arm. Hyle before/current have the same64 IDs,34draft rounds/29accepts,35Graph,222target/216draft rows and18record/50reuse; all repeated within-arm work is stable.',
  'Before/current/native median prefill2010.3126/1982.7833/1539.7398tok/s; complete decode122.7295/121.4171/141.2554; total64/session108.4876/107.2851/117.1214. Hyle before/current ranges overlap. No speed improvement or reproducible startup win is demonstrated.',
  'Sampled dedicated GPU peaks are4369498112/4478550016/4182888448B; current-before+109051904B(104MiB). This is a one-process-per-arm observed peak, not an exact allocation delta or attribution to a specific buffer/provider. CPU WS, private commit, shared GPU and same-sample GPU total are separately preserved.',
  'Native continuation differs at zero-index18 and uses220target/216draft rows,30accepted/33proposals. Its two-context compute counts and arithmetic differ; descriptive native rates are not identical-token implementation-speed or model-quality victory evidence.',
  'Current-work has the latest four-metric table, complete endpoints, sampling limits and the negative/neutral result. Prior W evidence is linked, not pooled. No extra repetitions were run merely to seek a favorable median.'],
 limitations=[
  'This explicitly changes terminal score rounding. It does not make upstream BF16 state F32, prove whole-model quality or eliminate all cross-batch numerical differences.',
  'Only the Qwen CLI TU compiled in this batch. Existing independent mtp_session/retirement probes were not recompiled/run; old results belong to their original score policies.',
  'Three timing samples and one independent memory process per arm on a desktop card do not establish universal throughput, significance or exact allocation savings/cost. Memory timings are excluded from TPS.',
  'Extra104MiB sampled peak remains a resource observation, not proof of a particular workspace allocation or a full weight conversion. Actual linked source has a preserving native BF16 path under stated conditions.',
  'cuBLASLt support for this existing contract is a concrete next candidate: per-port dtype/byte strides and stored-weight orientation must be correct, normal MatMul retained, natural proposal selection audited. It is not implemented by this batch; no new whitelist or consumer provider preference is proposed.',
  'Other backends/models/quantization, image projection, capture invalidation and full architecture completion remain open.'],
 previous_evidence=['docs/evidence/correctness/qwen-mtp-batch-numerics-2026-10-22.json','docs/evidence/correctness/qwen-mtp-batch-2026-10-22.json','docs/evidence/performance/qwen-mtp-divergence-2026-10-22.json'],
 next_actions=['Implement and measure an efficient cuBLASLt candidate for existing BFloatLinearF32 using proper per-port mixed dtype/layout and existing runtime/resource mechanisms; audit general selection facts without model/provider branches in consumers.',
  'Keep capture first-invalidation diagnosis and remaining backend/model/quant/image and architecture work active.'])
save(C/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in C.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(x in('tmp','__pycache__')for x in p.relative_to(C).parts)
 and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1','postconditions.json'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[];unique={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);key=(e['bytes'],e['sha256']);entry=unique.get(key)
  if entry is None:entry=p.relative_to(R).as_posix();unique[key]=entry;z.write(p,entry)
  else:e['identical_content_alias']=True
  e['entry']=entry;entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and len(z.namelist())==len(unique)
 for(size,sha),entry in unique.items():
  raw=z.read(entry);assert len(raw)==size and hashlib.sha256(raw).hexdigest()==sha
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,
 archive_verified=dict(CRC=True,all_unique_entry_SHA256=True,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique),content_deduplication='Source paths preserve SHA/size and canonical ZIP entries; identical content stored once.')))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(C/'published.json',published)
print(json.dumps(dict(**published,source_files=len(entries),unique_entries=len(unique),original_bytes=sum(e['bytes']for e in entries),unique_bytes=sum(k[0]for k in unique)),indent=2))
