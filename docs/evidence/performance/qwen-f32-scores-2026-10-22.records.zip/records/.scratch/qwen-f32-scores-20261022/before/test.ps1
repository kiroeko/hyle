# Exact verified leaves only. No recursion. Do not rerun after completion.
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-mtp-batch-numerics-20261022'
$planFile = Join-Path $taskRoot 'cleanup-plan.json'
$resultFile = Join-Path $taskRoot 'cleanup-result.json'
if (Test-Path -LiteralPath $resultFile) { throw 'Completed cleanup; do not rerun test.ps1.' }
$plan = Get-Content -LiteralPath $planFile -Raw | ConvertFrom-Json
$scope = [IO.Path]::GetFullPath($plan.scope).TrimEnd('\') + '\'
$batch = [IO.Path]::GetFullPath($plan.batch_scope).TrimEnd('\') + '\'
if ($scope -cne 'C:\public\project-hyle\hyle\.scratch\' -or $batch -cne ($taskRoot + '\')) { throw 'Unexpected cleanup scope' }
function Confirm-Identity($record) {
 $item = Get-Item -LiteralPath $record.path -Force -ErrorAction Stop
 if ($item.PSIsContainer -or $item.Length -ne $record.bytes) { throw ('File identity differs: ' + $record.path) }
 if ((Get-FileHash -LiteralPath $record.path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $record.sha256) { throw ('File hash differs: ' + $record.path) }
}
Confirm-Identity $plan.script
Confirm-Identity $plan.script_copy
Confirm-Identity $plan.published.manifest
foreach ($archive in $plan.published.archives) { Confirm-Identity $archive }
$protected = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($record in $plan.keep_images) { Confirm-Identity $record; [void]$protected.Add([IO.Path]::GetFullPath($record.path)) }
$allowOld = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($path in $plan.historical_image_allowlist) { [void]$allowOld.Add([IO.Path]::GetFullPath($path)) }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($target in $plan.targets) {
 $absolute = [IO.Path]::GetFullPath($target.path)
 if (-not $absolute.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase) -or
     (-not $absolute.StartsWith($batch,[StringComparison]::OrdinalIgnoreCase) -and -not $allowOld.Contains($absolute)) -or
     $protected.Contains($absolute) -or -not $seen.Add($absolute)) { throw ('Unsafe cleanup target: ' + $absolute) }
 Confirm-Identity $target
}
$scriptText = Get-Content -LiteralPath $plan.script_copy.path -Raw
$removed = [Collections.Generic.List[object]]::new()
foreach ($target in $plan.targets) { Remove-Item -LiteralPath $target.path -Force -ErrorAction Stop; $removed.Add($target) }
$result = [ordered]@{status='completed; do not rerun';recursive=$false;script=$plan.script;script_copy=$plan.script_copy;script_text=$scriptText;removed_files=$removed.Count;removed_logical_bytes=$plan.logical_bytes;kept_images=$plan.keep_images;verified_archives=$plan.published.archives;removed=$removed}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $resultFile -Encoding utf8
Copy-Item -LiteralPath $resultFile -Destination 'C:\public\project-hyle\hyle\docs\evidence\correctness\qwen-mtp-batch-numerics-2026-10-22.cleanup.json'
Write-Output ('Removed ' + $removed.Count + ' exact leaves / ' + $plan.logical_bytes + ' logical bytes. Completed; do not rerun.')
