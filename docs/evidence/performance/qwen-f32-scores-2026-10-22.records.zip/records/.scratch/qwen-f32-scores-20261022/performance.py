"""AC score-policy window; only the explicit run action starts model processes.

Import the immutable W/V runner, parser and memory observer. Keep all new
outputs in AC and report changed natural work descriptively, never as a
same-token regression or an implementation-speed/quality victory.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[1]
W = ROOT / ".scratch/qwen-mtp-divergence-20261022"
V = ROOT / ".scratch/qwen-mtp-window-20261022"
AA = ROOT / ".scratch/qwen-mtp-batch-20261022"
spec = importlib.util.spec_from_file_location("ac_retained_W_performance", W / "performance.py")
retained = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)
base = retained.base
ARMS = retained.ARMS
retained.S = S
retained.EXPECTED_READY = {
    "before_MTP": AA / "qwen-ready-attempt1.json",
    "after_MTP": S / "qwen-ready-attempt1.json",
    "peer_MTP": V / "peer-ready-attempt1.json",
}
original_plan, original_analyze = retained.plan, retained.analyze
POLICIES = {
    "before_MTP": "Hyle BF16 final score projection, then cast to F32",
    "after_MTP": "Hyle explicit F32 final score projection; BF16 weight/activation inputs",
    "peer_MTP": "Pinned native F32 scores; its other arithmetic/state path remains different",
}


def compare_work(runs):
    within = {}
    for arm in ARMS:
        selected = [r for r in runs if r["arm"] == arm]
        if not selected:
            within[arm] = {"processes": 0, "pending": True}
            continue
        first = selected[0]["observation"]
        all64 = all(len(r["observation"]["generated_ids"]) == 64 for r in selected)
        ids_equal = all(r["observation"]["generated_ids"] == first["generated_ids"] for r in selected)
        work_equal = all(r["observation"]["work"] == first["work"] for r in selected)
        within[arm] = {"processes": len(selected), "pending": False,
                       "all64_outputs": all64, "identical_actual_ids": ids_equal,
                       "identical_actual_work": work_equal,
                       "valid_fixed_work_repeats": all64 and ids_equal and work_equal,
                       "actual_lengths": [len(r["observation"]["generated_ids"]) for r in selected]}
    firsts = {arm: next((r["observation"] for r in runs if r["arm"] == arm), None) for arm in ARMS}
    between = {}
    for i, a in enumerate(ARMS):
        for b in ARMS[i + 1:]:
            left, right = firsts[a], firsts[b]
            if left is None or right is None:
                continue
            changes = {key: {a: left["work"].get(key), b: right["work"].get(key)}
                       for key in left["work"].keys() | right["work"].keys()
                       if left["work"].get(key) != right["work"].get(key)}
            between[a + "__" + b] = {
                "output_differences": base.differences(left["generated_ids"], right["generated_ids"]),
                "actual_work_differences": changes,
                "same_math_policy_assumed": False,
                "same_token_speed_or_quality_claim": False,
            }
    stable = all(v.get("valid_fixed_work_repeats", False) for v in within.values())
    return {"status": "stable_observed_within_arm_work" if stable else "pending_or_within_arm_variability",
            "within_arm": within, "between_arms": between,
            "note": "A changed natural continuation/work ledger across score policies is descriptive, not a failed bitwise regression. EOS-short or within-arm output/work variation is explicitly marked invalid for a fixed64 stable-work window; preserve raw runs and do not silently call it passed."}


def plan(config_path, mode, output):
    result = original_plan(config_path, mode, output)
    result.update(
        score_policies=POLICIES,
        same_math_policy_assumed=False,
        expected_within_arm_processes=3 if mode == "timing" else 1,
        within_arm_fixed_work_policy="All actual64 IDs and work counters must agree within each arm; otherwise flag variation, retain raw data and make no validated fixed-work summary claim.",
        contract="Original P154, up to64 natural greedy outputs, C1024/N1R1, prefixoff/replayauto. Before/current score policies intentionally differ; no cross-arm ID, acceptance or work equality is required or assumed. Report actual outputs/EOS/work, full endpoints and sampling limits. No same-token speed/quality victory claim.",
        script=base.identity(Path(__file__)),
        reused_W_script=base.identity(W / "performance.py"),
    )
    return result


def analyze(output):
    # W still collects Hyle record/reuse/cold ledgers; the patched comparison
    # is descriptive and its full original raw records remain untouched.
    result = original_analyze(output)
    result.pop("carrier_before_after_regression", None)
    runs = base.read(output / "runs.json")
    consistency = compare_work(runs)
    result["score_policy_observation"] = consistency
    result["score_policies"] = POLICIES
    result["fixed_work_window_valid"] = (
        len(runs) == (9 if result["mode"] == "timing" else 3)
        and all(x.get("valid_fixed_work_repeats", False)
                and x["processes"] == (3 if result["mode"] == "timing" else 1)
                for x in consistency["within_arm"].values())
    )
    result["status"] = "complete_stable_within_arm_work" if result["fixed_work_window_valid"] else "complete_with_work_or_output_variability_not_validated"
    result["same_math_policy_assumed"] = False
    result["same_token_cross_arm_speed_claim"] = False
    result["quality_threshold"] = None
    result["limits"] = [x for x in result["limits"] if not x.startswith("Original V peer MTP already differs")]
    result["limits"].extend([
        "Before Hyle uses BF16 score projection and current Hyle uses F32 scores; the native arm has its own arithmetic. Natural IDs, proposals, acceptance, verification work and EOS may differ. These are actual end-to-end policy outcomes, not identical-token implementation speed or model-quality evidence.",
        "Within each arm the actual64 output sequence and exported work must be consistent across its three timing processes; any variation remains explicit. A one-process memory observation does not establish repeatability.",
        "Do not combine this new window with W/V timings or infer gains from capture counts. Capture counters are range counts; cold_batch is an inclusive host bucket, not capture self-time.",
    ])
    base.save(output / "summary.json", result)
    return result


retained.plan = plan
retained.compare_before_after = compare_work
retained.analyze = analyze


def self_check():
    # Pure host policy checks. No retained helper is loaded and no image runs.
    def row(arm, changed=0, calls=35, length=64):
        return {"arm": arm, "observation": {"generated_ids": [changed] + list(range(1, length)),
                                              "work": {"actual_graph_calls": calls, "actual_target_rows": 222}}}
    rows = [row(arm, i, 35 + i) for i, arm in enumerate(ARMS)]
    assert all(x["valid_fixed_work_repeats"] for x in compare_work(rows)["within_arm"].values())
    assert compare_work(rows)["between_arms"]["before_MTP__after_MTP"]["output_differences"]
    assert not compare_work(rows + [row(ARMS[0], 9)])["within_arm"][ARMS[0]]["valid_fixed_work_repeats"]
    assert not compare_work(rows + [row(ARMS[0], calls=99)])["within_arm"][ARMS[0]]["valid_fixed_work_repeats"]
    assert not compare_work([row(ARMS[0], length=63)])["within_arm"][ARMS[0]]["valid_fixed_work_repeats"]
    assert retained.owned_output(S / "performance/timing").is_relative_to(S)
    try:
        retained.owned_output(W / "performance/forbidden")
    except ValueError:
        pass
    else:
        raise AssertionError("old stage output accepted")
    return {"status": "pure_host_policy_checks_pass", "checks": 7,
            "model_runs": 0, "GPU_runs": 0, "builds": 0,
            "script": base.identity(Path(__file__))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "run", "analyze", "self-check"))
    parser.add_argument("--config", type=Path, default=S / "arms.json")
    parser.add_argument("--mode", choices=("timing", "memory"), default="timing")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.action == "self-check":
        print(json.dumps(self_check()))
        return
    output = retained.owned_output(args.output or S / "performance" / args.mode)
    if args.action == "plan":
        result = plan(args.config, args.mode, output)
        base.save(S / (args.mode + "-plan.json"), result)
        print(json.dumps({"processes": len(result["commands"]), "plan": str(S / (args.mode + "-plan.json")), "model_runs": 0}))
    else:
        result = retained.run(args.config, args.mode, output) if args.action == "run" else analyze(output)
        print(json.dumps({"summary": str(output / "summary.json"), "processes": result["processes"],
                          "mode": result["mode"], "status": result["status"],
                          "fixed_work_window_valid": result["fixed_work_window_valid"]}))


if __name__ == "__main__":
    main()
