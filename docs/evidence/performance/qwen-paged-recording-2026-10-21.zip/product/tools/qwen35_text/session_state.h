#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <stdexcept>
#include <utility>
#include <vector>

#include "hyle/compute/paged_arena.h"

namespace qwen35::cache {
namespace c = hyle::compute;

inline std::size_t add(std::size_t a, std::size_t b) {
  if (b > (std::numeric_limits<std::size_t>::max)() - a)
    throw std::runtime_error("cache backing byte count overflows");
  return a + b;
}
inline std::size_t multiply(std::size_t a, std::size_t b) {
  if (a && b > (std::numeric_limits<std::size_t>::max)() / a)
    throw std::runtime_error("cache backing byte count overflows");
  return a * b;
}

// This consumer has six equal-geometry K/V layers. One physical page ID names
// twelve independent real arena blocks; this policy is not a Compute owner.
struct Plan final {
  static constexpr std::uint32_t page_rows = 16;
  std::size_t resident_sessions = 0, recurrent_payload_bytes = 0;
  std::uint32_t max_pages = 0, max_page_refs = 0, state_slots = 0;
  std::size_t bank_bytes = 0, backing_bytes = 0;
};
inline Plan plan(std::size_t context, std::size_t residents,
                 std::size_t max_query_rows, std::size_t recurrent_payload) {
  if (!context || !residents || !max_query_rows || max_query_rows > context)
    throw std::runtime_error("cache plan requires positive context, resident sessions and query rows");
  const auto refs = add(context, Plan::page_rows - 1) / Plan::page_rows;
  // Calls are serial. All untouched full pages are shared with the candidate;
  // its visible length never exceeds context. Only its retained old partial
  // tail needs one extra COW page beyond the N complete-context capacities.
  const auto pages = add(multiply(refs, residents), 1);
  if (pages > std::size_t((std::numeric_limits<std::int32_t>::max)()) ||
      residents >= (std::numeric_limits<std::uint32_t>::max)())
    throw std::runtime_error("cache page or state-slot count exceeds the supported index range");
  Plan result;
  result.resident_sessions = residents;
  result.recurrent_payload_bytes = recurrent_payload;
  result.max_pages = static_cast<std::uint32_t>(pages);
  result.max_page_refs = static_cast<std::uint32_t>(refs);
  result.state_slots = static_cast<std::uint32_t>(residents + 1);
  result.bank_bytes = add(multiply(multiply(pages, Plan::page_rows), 1024), 1);
  // Each real arena/pool includes its own final byte. There are 12 KV arena
  // backings and 36 independent conv/GDN pools, each charged exactly once.
  result.backing_bytes = add(multiply(result.bank_bytes, 12),
      add(multiply(recurrent_payload, result.state_slots), 36));
  return result;
}

struct PageInventory;
class PageRef final {
public:
  PageRef() noexcept = default;
  PageRef(const PageRef &) noexcept;
  PageRef &operator=(const PageRef &) noexcept;
  PageRef(PageRef &&other) noexcept
      : owner_(std::exchange(other.owner_, nullptr)), page_(other.page_) {}
  PageRef &operator=(PageRef &&other) noexcept {
    if (this != &other) { PageRef next(std::move(other)); swap(next); }
    return *this;
  }
  ~PageRef();
  std::uint32_t page() const noexcept { return page_; }
private:
  friend struct PageInventory;
  PageRef(PageInventory *owner, std::uint32_t page) noexcept : owner_(owner), page_(page) {}
  void swap(PageRef &other) noexcept { std::swap(owner_, other.owner_); std::swap(page_, other.page_); }
  PageInventory *owner_ = nullptr;
  std::uint32_t page_ = 0;
};
struct PageReservation final {
  // Writers die before the policy reference can make this ID eligible again.
  PageRef reference;
  std::array<c::PagedPageWriter, 6> keys, values;
};
struct PageInventory final {
  std::array<c::PagedArena, 6> keys, values;
  std::vector<std::uint32_t> owners, free_ids;
  void prepare(std::uint32_t pages) {
    owners.assign(pages, 0); free_ids.reserve(pages);
    for (auto page = pages; page != 0; --page) free_ids.push_back(page - 1);
  }
  hyle::Result<PageReservation> acquire() noexcept {
    auto attempts = free_ids.size();
    while (attempts--) {
      const auto page = free_ids.back(); free_ids.pop_back();
      PageReservation result;
      hyle::Status status;
      for (std::size_t i = 0; i < keys.size() && status.ok(); ++i) {
        auto key = keys[i].acquire(page);
        if (!key) { status = key.error(); break; }
        result.keys[i] = std::move(*key);
        auto value = values[i].acquire(page);
        if (!value) { status = value.error(); break; }
        result.values[i] = std::move(*value);
      }
      if (status.ok()) {
        owners[page] = 1; result.reference = PageRef(this, page); return result;
      }
      // Policy eligibility never proves native retirement. The real acquire
      // can defer an ID while old Graph readers still retain its blocks.
      if (status.IsUnavailable()) { free_ids.insert(free_ids.begin(), page); continue; }
      free_ids.push_back(page); return std::unexpected(std::move(status));
    }
    return std::unexpected(hyle::Status::ResourceExhausted("shared Qwen KV pages are retained; release a prefix/session or enlarge the cache"));
  }
  void retain(std::uint32_t page) noexcept { ++owners[page]; }
  void release(std::uint32_t page) noexcept {
    if (--owners[page] == 0) free_ids.push_back(page);
  }
};
inline PageRef::PageRef(const PageRef &other) noexcept : owner_(other.owner_), page_(other.page_) {
  if (owner_) owner_->retain(page_);
}
inline PageRef &PageRef::operator=(const PageRef &other) noexcept {
  if (this != &other) { PageRef next(other); swap(next); }
  return *this;
}
inline PageRef::~PageRef() { if (owner_) owner_->release(page_); }

struct Recurrent final { c::ReadLease history, recurrent; };
struct StatePools final { c::LeasePool history, recurrent; };
// Counts distinct immutable versions, not shared_ptr aliases or users. An
// explicitly retained prefix consumes the same finite capacity as an old head.
struct VersionCount final { std::uint32_t live = 0, capacity = 0; };
class VersionRef final {
public:
  VersionRef() noexcept = default;
  VersionRef(const VersionRef &) = delete;
  VersionRef &operator=(const VersionRef &) = delete;
  VersionRef(VersionRef &&other) noexcept : owner_(std::exchange(other.owner_, nullptr)) {}
  VersionRef &operator=(VersionRef &&other) noexcept {
    if (this != &other) { VersionRef next(std::move(other)); std::swap(owner_, next.owner_); }
    return *this;
  }
  ~VersionRef() { if (owner_) --owner_->live; }
  static hyle::Result<VersionRef> acquire(VersionCount &owner) noexcept {
    if (owner.live == owner.capacity)
      return std::unexpected(hyle::Status::ResourceExhausted("Qwen cache retains all snapshot versions; release a prefix/checkpoint or enlarge the cache"));
    ++owner.live; VersionRef result; result.owner_ = &owner; return result;
  }
private:
  VersionCount *owner_ = nullptr;
};
// Snapshot is immutable once published. Tokens/positions and every layer's
// state advance by replacing one shared pointer. Model outlives all snapshots.
struct Snapshot final {
  // Reverse destruction releases actual frames before policy references.
  VersionRef version;
  std::vector<PageRef> pages;
  std::array<c::PagedArenaRead, 6> keys, values;
  std::array<Recurrent, 24> state;
  const void *model = nullptr;
  std::size_t length = 0;
};
using SnapshotRef = std::shared_ptr<const Snapshot>;
} // namespace qwen35::cache
