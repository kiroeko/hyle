"""Six related host translation units; cached native libraries, no SDK/NVCC."""
from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/paged-append-20261021'
A = R / '.scratch/architecture-refactor-2026-10-18'
W = A / 'd4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
jobs = (
    ('src/graph/resources.cc', P / 'qwen-snapshot/unbind/checks/attempt2/graph--resources/identity.json'),
    ('src/graph_batch/batch.cc', P / 'symbolic-rows/checks/attempt1/graph_batch--batch/identity.json'),
    ('src/graph_batch/paged_append.cc', P / 'symbolic-rows/checks/attempt2/graph_batch--paged_append/identity.json'),
    ('src/graph_batch/native_batch_regions.cc', A / 'compact-mla-e4-reference/common/checks/attempt2/graph_batch--native_batch_regions-fc2356/identity.json'),
    ('src/graph_batch/native_pending_regions.cc', A / 'gguf-nvfp4/windows-host/checks/20261019T201048/o629dd934--graph_batch--native_pending_regions-identity.json'),
    ('tests/graph_batch/paged_append_cuda_consumer.cc', P / 'symbolic-rows/cuda-host1/identity.json'),
)

def one(job):
    path, recipe = job
    source = R / path
    tag = source.parent.name + '--' + source.stem
    out = S / 'checks/attempt1' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = b.identity(source)
    command = b.host_command(c.read(recipe)['command'], source, tag, out)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (tag + '-deps.json'))['Data']
    record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
    c.save(out / 'identity.json', record)
    return record

assert (S / 'implementation/source-freeze.json').is_file(), 'Wait for the implementation freeze'
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(one, jobs))
c.save(S / 'compiled.json', dict(records=records, CXX=len(records), NVCC=0, SDK_builds=0, GPU_runs=0))
print('Compiled six related host TUs; no SDK/NVCC.', flush=True)
