"""Root serial actual CUDA checks; original numerical oracles, no speed claim."""
from pathlib import Path
import argparse
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/paged-append-20261021'
F = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('cuda', 'model'))
args = parser.parse_args()
if args.mode == 'cuda':
    source = (P / 'run_cuda_check.py').read_text(encoding='utf-8')
    source = source.replace("P / 'cuda-ready-for-root.json'", "P / 'cuda-ready.json'")
    target = S / 'run_cuda_check.py'
    target.write_text(source, encoding='utf-8')
    exec(compile(source, str(target), 'exec'), {'__file__': str(target), '__name__': '__main__'})
    raise SystemExit(0)
spec = importlib.util.spec_from_file_location('original_checker', F / 'multi-session-isolation-2026-10-21/run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(F / 'multi-session-isolation-2026-10-21/inputs/plan.json')
single = S / 'single-run1'
case = plan['cases']['alice']
observed = h.run(single, S / 'qwen-ready.json', ['--schedule', case['schedule']['path']])
baseline = R / '.scratch/multi-session-20261021/attempt2/baseline/alice'
pairs = h.check_vectors(baseline / 'trace', single / 'trace', case['calls'])
assert len(pairs) == 18 and all(p['byte_equal'] for p in pairs)
assert observed['generated_ids'] == m.read(baseline / 'observation.json')['generated_ids']
m.save(single / 'summary.json', dict(passed=True, vector_count=18, pairs=pairs, throughput_evidence=False))
print('Single paged Qwen: original 18 decision vectors byte-identical.', flush=True)
out = S / 'multi-run1'
observed = h.run(out, S / 'qwen-ready.json', [
    '--session-schedules', plan['manifests']['4']['manifest']['path'],
    '--max-sessions', '2', '--active-sequences', '2', '--cache-bytes', '168886272'])
assert observed['processed_tokens'] == 239 and observed['generated_tokens'] == 36
assert observed['evicted_session_ids'] == ['bob', 'alice', 'carol', 'dave', 'alice', 'bob']
assert sum(s['restored_calls'] for s in observed['sessions']) == 18
assert sum(s['restored_tokens'] for s in observed['sessions']) == 185
proofs = {}
for session in observed['sessions']:
    sid = session['session_id']
    case = plan['cases'][sid]
    h.check_session(session, case)
    baseline = R / '.scratch/multi-session-20261021/attempt2/baseline' / sid
    assert session['generated_ids'] == m.read(baseline / 'observation.json')['generated_ids']
    pairs = h.check_vectors(baseline / 'trace', out / 'trace' / session['trace_subdirectory'], case['calls'])
    assert len(pairs) == 18 and all(p['byte_equal'] for p in pairs)
    proofs[sid] = pairs
m.save(out / 'summary.json', dict(passed=True, vector_count=72, sessions=proofs,
    throughput_evidence=False, original_restored_calls=18, original_restored_tokens=185))
print('Four-session paged Qwen: eviction/rebuild; original 72 vectors byte-identical.', flush=True)
