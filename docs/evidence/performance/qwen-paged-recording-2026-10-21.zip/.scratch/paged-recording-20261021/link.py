"""Replace every ProjectedReader owner in the retained CUDA link closures."""
from pathlib import Path
import importlib.util
import os
import sys
import argparse
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/paged-append-20261021'
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
records = c.read(S / 'compiled.json')['records']
for row in records:
    assert h.same(row['source']) and h.same(row['object'])
    assert all(h.same(x) for x in row['dependencies'])
parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('both', 'qwen', 'cuda'), default='both')
parser.add_argument('--suffix', default='1')
parser.add_argument('--provider', action='store_true')
args = parser.parse_args()
for mode, base_ready in [('qwen', P / 'qwen-snapshot/linked-ready.json'), ('cuda', P / 'symbolic-rows/cuda-ready.json')]:
    if args.mode not in ('both', mode):
        continue
    prior = c.read(base_ready)
    base = c.read(prior['link_plan']['path'])
    assert all(h.same(x) for x in base['inputs'])
    replacements = {}
    selected = records if mode == 'cuda' else records[:-1]
    for row in selected:
        source = Path(row['source']['path'])
        tag = source.parent.name + '--' + source.stem
        matches = [x for x in base['inputs'] if tag in Path(x['path']).stem or
            (source.name == 'paged_append_cuda_consumer.cc' and Path(x['path']).name == 'cuda-test.obj')]
        assert len(matches) == 1, (tag, matches)
        replacements[c.key(matches[0]['path'])] = row['object']
    if args.provider:
        provider = c.read(S / 'checks/provider/identity.json')
        assert h.same(provider['source']) and h.same(provider['object'])
        assert all(h.same(x) for x in provider['dependencies'])
        matches = [x for x in base['inputs'] if Path(x['path']).name == 'provider.obj' and 'host-provider' in x['path']]
        assert len(matches) == 1
        replacements[c.key(matches[0]['path'])] = provider['object']
    out = S / (mode + '-link' + args.suffix)
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / (mode + '.exe')
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(prior['link_plan']['path']),
        replaced_inputs=list(replacements.values()), CXX=0, NVCC=0, links=1, SDK_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):
        os.link(dll, out / dll.name)
    runtime = c.read(prior['runtime_environment']['path'])
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    runtime['scope'] = 'Current permission-only paged recording change; retained shared CUDA provider closure, not native backend execution'
    c.save(out / 'runtime-environment.json', runtime)
    c.save(S / (mode + '-ready.json'), dict(image=b.identity(image), source=prior['source'] if mode == 'qwen' else records[-1]['source'],
        link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
        current_compilation=b.identity(S / 'compiled.json'), prior=b.identity(base_ready),
        CXX=0, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('LINKED', mode, image, flush=True)
