"""Publish the executed finite batch and update the current full-results table."""
from pathlib import Path
import hashlib
import json
import re
import statistics
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
E = R / 'docs/evidence/performance'
STEM = 'qwen-paged-recording-2026-10-21'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    try:
        name = path.relative_to(R).as_posix()
    except ValueError:
        name = str(path)
    return dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def verify(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = R / path
    actual = identity(path)
    assert (actual['bytes'], actual['sha256']) == (record['bytes'], record['sha256']), path

timing = read(S / 'performance/timing/summary.json')
runs = read(S / 'performance/timing/runs.json')
memory = read(S / 'performance/memory/summary.json')
assert len(runs) == 9 and timing['same_Hyle_predictions']
assert len(read(S / 'performance/memory/runs.json')) == 3
independent = S / 'performance/independent-review.json'
cost = S / 'performance/paged-cost-source-review.json'
assert independent.is_file() and cost.is_file(), 'Wait for finite independent reports'
for mode in ('timing', 'memory'):
    for row in read(S / 'performance' / mode / 'runs.json'):
        assert row['process']['exit'] == 0 and not row['process'].get('timeout')
        verify(row['process']['image'])
        raw = row['observation']['raw']
        assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
        assert [p['context_after'] for p in raw['phases']] == [256, 288, 544, 576, 832, 864]
        if row['arm'] == 'hyle':
            assert raw['diagnostic'] is False

def stats(values):
    return dict(count=len(values), samples=values, median=statistics.median(values), min=min(values), max=max(values))

groups = {}
for variant, group in timing['groups'].items():
    selected = [x for x in runs if x['variant'] == variant]
    groups[variant] = dict(metrics=group['metrics'], phases=group['phases'], loading=group['loading'],
        complete_decode_tps=stats([96 / sum(p['seconds'] for p in x['observation']['raw']['phases'] if p['kind'] == 'decode') for x in selected]),
        memory_peaks=memory['groups'][variant]['sampled_peaks'],
        memory_gap_ms={k:v for k,v in memory['groups'][variant]['actual_sample_gaps_ms'].items() if k != 'samples'},
        phase_dedicated_peak_bytes={k:v['values']['gpu_dedicated_bytes']['max'] for k,v in memory['groups'][variant]['phase_windows'].items()})

single = read(S / 'single-run1/summary.json')
multi = read(S / 'multi-run1/summary.json')
assert single['passed'] and multi['passed'] and single['vector_count'] == 18 and multi['vector_count'] == 72
pairs = [*single['pairs'], *(p for ss in multi['sessions'].values() for p in ss)]
for pair in pairs:
    verify(pair['baseline']); verify(pair['actual'])
    assert pair['byte_equal']
assert read(S / 'cuda-run1/result.json')['exit'] == 0
ready = read(S / 'qwen-ready.json')
verify(ready['image'])
link = read(Path(ready['link_plan']['path']))
for item in link['inputs']:
    verify(item)
assert len(link['inputs']) == 192

# Keep the table generated from the same independently checked raw window.
order = ['current', 'dense', 'peer']
def median(arm, key):
    return groups[arm]['metrics'][key]['median']
def row(label, values, places=2):
    return '| ' + label + ' | ' + ' | '.join(f'{x:.{places}f}' for x in values) + ' |\n'
table = '| 指标 | 当前分页Hyle | 改造前dense Hyle | llama.cpp |\n| --- | ---: | ---: | ---: |\n'
for turn in (1, 2, 3):
    table += row(f'第{turn}轮prefill tok/s', [groups[a]['phases'][f'round{turn}_prefill']['median'] for a in order])
for turn in (1, 2, 3):
    table += row(f'第{turn}轮完整decode tok/s', [groups[a]['phases'][f'round{turn}_decode']['median'] for a in order])
table += row('完整decode合计 tok/s（96／三段decode总wall）', [groups[a]['complete_decode_tps']['median'] for a in order])
table += row('综合输出 tok/s（99／会话wall）', [median(a, 'output_tokens_per_second') for a in order])
table += row('会话wall s', [median(a, 'session_seconds') for a in order], 5)
table += row('消费者入口至末输出 s（含加载／冷准备）', [median(a, 'startup_total_seconds') for a in order], 5)
table += row('启动至ready s', [groups[a]['loading']['startup_to_ready_seconds']['median'] for a in order], 5)
for label, key in [('GPU dedicated全程观测峰 GiB', 'sampled_peak_gpu_dedicated_bytes'),
                   ('GPU shared全程观测峰 GiB', 'sampled_peak_gpu_shared_bytes'),
                   ('进程working set观测峰 GiB', 'sampled_max_working_set_bytes'),
                   ('进程private commit观测峰 GiB', 'sampled_max_private_commit_bytes')]:
    table += row(label, [groups[a]['memory_peaks'][key] / 2**30 for a in order], 3)
tail = '''## 最新完整性能对比

**2026-10-21，分页多会话改造后的首轮完整三臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN、无MTP／图片；单会话三轮`256输入＋32 decode`，同固定ID、容量1024、最终上下文864。
当前分页镜像`ff42c532…`、改造前dense `ff748694…`、llama.cpp `9b259137…`／`d9e03f1074db…`；各3进程交错测速，显存另各1进程旁采，trace和准备诊断关闭。两种Hyle与参考均复用完整历史，只算新增输入，无淘汰／重建；当前尚未测共享前缀收益、多人吞吐或Spark。

''' + table + '''
当前／dense／参考的综合输出样本范围分别为**53.74–64.13／56.98–76.63／60.18–89.67 tok/s**，完整decode范围为**58.34–70.47／62.17–84.77／67.97–102.14 tok/s**。窗口前后GPU背景负载53%／57%，SM时钟均2835MHz；不是独占GPU。各仅3进程、范围大且重叠，本窗不能判稳定差距或隔离归因单个修复，但当前中位仍落后，不能宣称分页改造无代价。
专用显存阶段峰按P1→D1→P2→D2→P3→D3：当前 **3.995→4.005→4.110→4.112→4.112→4.114 GiB**；dense **3.956→3.972→4.077→4.081→4.081→4.085**；参考 **4.191→4.194→4.194→4.194→4.194→4.194**。当前比dense观测峰多30MiB，不能将差值全部归因缓存载荷；私有workspace／capture等另有费用。旁采实际间隔中位约15.10／15.07／15.13ms，精确阶段边界占用未知，GPU峰是采样下界；CPU与GPU不相加。

长旅程每进程90／96次decode为0录制／7复用，仍有2次首用7／0和4次6／1；不能将短旅程热T1结果外推所有拓扑边界。零重录时的准备桶仍随历史增长，下一批处理未消费的lease查找及页集合平方扫描，再核COW／发布成本。新闭包也包含此前workspace查询消冗，不把整轮差异全归因本次录制修复。
[完整数据、全部样本、源码与独立复核](../evidence/performance/qwen-paged-recording-2026-10-21.json)；[前一完整窗口](../evidence/performance/qwen-next-phase-first-2026-10-21.json)。前窗综合85.15／82.32和decode95.03／93.78属于当时dense／参考窗口，不与本窗合算或冒充当前结果。
'''
work = R / 'docs/developer/current-work.md'
text = work.read_text(encoding='utf-8')
work.write_text(text.split('## 最新完整性能对比')[0] + tail, encoding='utf-8')

product_paths = {x['source']['path'] for x in read(S / 'compiled.json')['records']}
product_paths.update([read(S / 'checks/provider/identity.json')['source']['path'],
    str(R / 'tools/qwen35_text/main.cc'), str(R / 'tools/qwen35_text/session_state.h'),
    str(R / 'src/graph/executable.cc'), str(R / 'include/hyle/graph/detail/region_access.h')])
files = {}
allowed = {'.py', '.json', '.log', '.xml', '.tsv', '.diff', '.cc', '.h'}
for path in S.rglob('*'):
    if path.is_file() and path.suffix in allowed:
        files[path.relative_to(R).as_posix()] = path
for name in product_paths:
    path = Path(name)
    files['product/' + path.relative_to(R).as_posix()] = path
for name in ('docs/developer/current-work.md', 'docs/developer/performance/decode.md',
             'docs/architecture/compute-design.md', 'tools/qwen35_text/README.md'):
    files['documentation/' + name] = R / name
zpath = E / (STEM + '.zip')
members = []
with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        archive.writestr(name, data)
        members.append(dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(zpath) as archive:
    assert archive.testzip() is None

report = dict(schema='hyle.qwen-paged-recording.v1', date='2026-10-21',
    status='Conditional dormant recording preservation implemented and executed; full comparison completed; speed target and full cache feature remain unfinished',
    implementation=dict(image=ready['image'], product=[identity(p) for p in sorted(product_paths)],
        host_CXX=7, NVCC=0, SDK_builds=0, links=3,
        unexecuted_intermediate_image='qwen-link1/4e459435: retained closure before current provider integration; actual model/performance uses qwen-link2/ff42c532'),
    correctness=dict(append_CUDA_exit=0, stale_submit='FailedPrecondition required after take without rebind/prepare; original success oracle also passed',
                     single_vectors=18, four_session_vectors=72, all_byte_identical=True,
                     vector_pairs=pairs, model_image=ready['image'], restored_calls=18, restored_tokens=185),
    workload=read(S / 'performance/timing/inputs.json'), groups=groups,
    timing_processes=9, memory_processes=3, per_arm_timing_processes=3,
    statistical_significance=False, independent_quality_acceptance=False,
    diagnosis=dict(short='Hot T1 6 recorded/1 reused before; 0/7 after',
        long='Each current process: 90 of 96 decode calls 0/7; 2 first uses 7/0 and 4 other calls 6/1. Genuine boundary/physical changes retain invalidation.',
        source_cost_review=identity(cost), independent_review=identity(independent),
        next='Skip unused lease lookup for proven borrowed TensorView carriers; remove quadratic page identity scans; then evaluate real COW/commit/metadata costs. No old dense executor fallback.'),
    interpretation=[
        'The stable-capture and selected-reader facts preserve only dormant physical commands. All old guards, binding and replay/output readiness are still withdrawn; fresh actual permission/token/topology/physical arguments remain required.',
        'This complete window is a three-program comparison, not an isolated speed estimate of the single recording patch. Current also integrates the earlier workspace-sizing provider fix.',
        'Current full-window medians trail both prior dense Hyle and llama.cpp. Samples are broad and overlap; before/after GPU utilization53/57% disallows idle/exclusive or stable gap claims. No sample discarded or rerun merely to obtain a favorable result.',
        'Sampled current dedicated peak is30MiB above dense and below llama.cpp. Cache backing, IO/workspace/capture/vendor-private and driver allocations are distinct; difference is not attributed entirely to cache payload.',
        'Same fixed tokens, weights, BF16/F32-GDN policy and host-token timing boundary. Reference has its original F32 intermediates and greedy/logits readback; no estimated cost subtracted.',
        'Single session, no prefix hits or eviction in performance workload; four-session correctness is serial interleaving, not a concurrent throughput measurement.',
        'Native Apple/Vulkan host results in the parent batch do not qualify native paged writers. No new Linux/Apple/Vulkan runtime execution in this change.',
    ],
    parent='docs/evidence/correctness/qwen-paged-snapshot-2026-10-21.json',
    previous_full='docs/evidence/performance/qwen-next-phase-first-2026-10-21.json',
    archive=identity(zpath), members=members, goal_complete=False)
out = E / (STEM + '.json')
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), archive=identity(zpath), members=len(members)), ensure_ascii=False))
