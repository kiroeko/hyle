"""Compile the existing current workspace-sizing fix into this CUDA closure."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
recipe = W / 'checks/attempt1/identity.json'
source = R / 'src/compute_provider_flashinfer/flashinfer_provider.cc'
out = S / 'checks/provider'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
command = b.host_command(c.read(recipe)['command'], source, 'provider', out)
frozen = b.identity(source)
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'provider-deps.json')['Data']
record = dict(source=frozen, object=b.identity(out / 'provider.obj'), command=command,
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
c.save(out / 'identity.json', record)
print('Current existing provider compiled; no new math, NVCC or SDK build.', flush=True)
