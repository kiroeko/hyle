"""Independent host-only recomputation. Never launches a consumer or queries a device."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex
import statistics

S = Path(__file__).resolve().parent
R = S.parents[2]
D = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21'
F = D / 'first-decode-startup-2026-10-21'
W = F / 'layout-workspace-facts-reuse-2026-10-21'
KEYS = ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
        'gpu_shared_bytes', 'gpu_total_bytes']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def verify(record):
    actual = identity(record['path'])
    assert actual == record, (actual, record)
    return actual


def stats(values, samples=True):
    result = dict(count=len(values), min=min(values) if values else None,
                  median=statistics.median(values) if values else None,
                  max=max(values) if values else None)
    if samples:
        result['samples'] = values
    return result


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


def steps(stderr):
    result = []
    pending = None
    for line in stderr.splitlines():
        if line.startswith('prepared T='):
            pairs = dict(re.findall(r'(\w+)=([^\s]+)', line))
            pending = {k: int(pairs[k]) for k in ['T', 'visible', 'capture_recorded', 'capture_reused']}
            pending['replay'] = pairs['replay']
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+)))\s+tokens=', line)
        if not match:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        row = dict(name=match[1], turn=int(match[2]), kind='prefill' if match[3] == 'prefill' else 'decode',
                   local=int(match[4]) if match[4] else None, tokens=int(fields['tokens']),
                   visible=int(fields['visible']), predicted=int(fields.get('next', fields.get('predicted'))),
                   step_seconds=float(fields['step_seconds']))
        if pending:
            assert row['visible'] == pending['visible'] and row['tokens'] == pending['T']
            row['prepared'] = pending
            pending = None
        result.append(row)
    assert pending is None
    return result


plan = read(S / 'timing/inputs.json')['plan']
assert plan['processed_tokens'] == 864 and plan['generated_tokens'] == 99
assert plan['phase_count'] == 6 and plan['turn_count'] == 3
manifest = verify(plan['manifest'])
manifest_path = Path(manifest['path'])
input_files = []
position = 0
expected_steps = []
for line, phase in zip(manifest_path.read_text().splitlines(), plan['phases'], strict=True):
    kind, relative = shlex.split(line)
    assert kind == ('prompt' if phase['kind'] == 'prefill' else 'decode')
    path = manifest_path.parent / relative
    ids = [int(x) for x in path.read_text().split()]
    assert ids == phase['ids'] and len(ids) == phase['input_tokens']
    assert all(0 <= x < 248320 for x in ids)
    assert phase['visible_before'] == position
    input_files.append(identity(path))
    count = 1 if kind == 'prompt' else len(ids)
    assert count == phase['calls']
    for i in range(count):
        n = len(ids) if kind == 'prompt' else 1
        position += n
        expected_steps.append(dict(name=phase['name'] if kind == 'prompt' else phase['name'] + str(i + 1),
                                   tokens=n, visible=position))
    assert phase['visible_tokens'] == position
assert position == 864 and len(expected_steps) == 99

timing_input = read(S / 'timing/inputs.json')
memory_input = read(S / 'memory/inputs.json')
assert timing_input['plan'] == memory_input['plan']
assert timing_input['order'] == ['dense', 'current', 'peer', 'peer', 'dense', 'current', 'current', 'peer', 'dense']
assert memory_input['order'] == ['dense', 'current', 'peer']
assert timing_input['profiler'] is False and timing_input['memory_monitor'] is False
assert memory_input['profiler'] is False and memory_input['memory_monitor'] is True
images = {k: verify(v) for k, v in timing_input['images'].items()}
assert images == memory_input['images']

processes = []
raw_ids = []
driver_summary = read(S / 'timing/summary.json')
recorded_runs = read(S / 'timing/runs.json')
for index, variant in enumerate(timing_input['order'], 1):
    folder = S / 'timing' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and not receipt.get('timeout') and not receipt['reader_errors']
    assert receipt['image'] == images[variant]
    assert receipt['command'] == timing_input['commands'][index - 1]['command']
    assert '--trace' not in receipt['command'] and '--preparation-diagnostics' not in receipt['command']
    stderr = (folder / 'stderr.log').read_text()
    raw = read(folder / 'peer-result.json') if variant == 'peer' else json.loads(
        next(x for x in reversed((folder / 'stdout.log').read_text().splitlines()) if x.startswith('{')))
    for key in ['processed_tokens', 'generated_tokens', 'phase_count', 'turn_count']:
        assert raw[key] == plan[key]
    assert not raw.get('diagnostic', False)
    actual_steps = steps(stderr)
    assert len(actual_steps) == 99
    for actual, expected in zip(actual_steps, expected_steps, strict=True):
        for key in ['name', 'tokens', 'visible']:
            assert actual[key] == expected[key]
        assert actual['step_seconds'] > 0
    ids = raw.get('predicted_ids', raw.get('generated_ids'))
    assert ids == [x['predicted'] for x in actual_steps] and len(ids) == 99
    raw_ids.append(ids)
    phases = []
    for p, expected in zip(raw['phases'], plan['phases'], strict=True):
        for key in ['name', 'kind', 'turn', 'input_tokens']:
            assert p[key] == expected[key]
        assert p['context_before'] == expected['visible_before'] and p['context_after'] == expected['visible_tokens']
        selected = [x for x in actual_steps if x['turn'] == p['turn'] and x['kind'] == p['kind']]
        assert len(selected) == expected['calls']
        rounded_step_sum = sum(x['step_seconds'] for x in selected)
        # stderr uses six significant digits; JSON keeps the unrounded double sum.
        precision_bound = sum(5.1 * 10 ** (math.floor(math.log10(x['step_seconds'])) - 6) for x in selected)
        assert abs(rounded_step_sum - p['step_sum_seconds']) <= precision_bound
        phases.append(dict(name=p['name'], kind=p['kind'], turn=p['turn'],
                           context_before=p['context_before'], context_after=p['context_after'],
                           input_tokens=p['input_tokens'], seconds=p['seconds'],
                           step_sum_seconds=p['step_sum_seconds'], tps=p['input_tokens'] / p['seconds'],
                           first_two_step_seconds=sum(x['step_seconds'] for x in selected[:2]) if p['kind'] == 'decode' else None,
                           decode7_to32_tps=26 / sum(x['step_seconds'] for x in selected[6:]) if p['kind'] == 'decode' else None))
    pre = sum(x['seconds'] for x in phases if x['kind'] == 'prefill')
    dec = sum(x['seconds'] for x in phases if x['kind'] == 'decode')
    step_sum = sum(x['step_sum_seconds'] for x in phases)
    totals = dict(session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
                  processed_tokens_per_second=864 / raw['session_seconds'], output_tokens_per_second=99 / raw['session_seconds'],
                  cold_processed_tokens_per_second=864 / raw['startup_total_seconds'], cold_output_tokens_per_second=99 / raw['startup_total_seconds'],
                  compute_step_sum_seconds=step_sum, session_minus_step_sum_seconds=raw['session_seconds'] - step_sum)
    for key, value in totals.items():
        close(value, recorded_runs[index - 1]['observation']['metrics'][key])
    totals.update(aggregate_prefill_tps=768 / pre, aggregate_decode_tps=96 / dec,
                  prefill_seconds=pre, decode_seconds=dec)
    capture_counts = Counter((x['tokens'], x['prepared']['replay'], x['prepared']['capture_recorded'],
                             x['prepared']['capture_reused']) for x in actual_steps if 'prepared' in x)
    loading = dict(raw.get('loading', {}))
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            for key, value in re.findall(r'(\w+)=([^\s]+)', line):
                try:
                    loading[key] = float(value)
                except ValueError:
                    pass
    process = dict(index=index, variant=variant, result=identity(folder / 'result.json'),
                   stdout=identity(folder / 'stdout.log'), stderr=identity(folder / 'stderr.log'),
                   command=receipt['command'], metrics=totals, phases=phases, loading=loading,
                   decision_calls=99, decode_calls=96, input_tokens=864,
                   ids_sha256=hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                   replay_counts=[dict(tokens=k[0], replay=k[1], recorded=k[2], reused=k[3], calls=v)
                                  for k, v in sorted(capture_counts.items())],
                   recapture_steps=[dict(name=x['name'], visible=x['visible'], recorded=x['prepared']['capture_recorded'], reused=x['prepared']['capture_reused'])
                                    for x in actual_steps if 'prepared' in x and x['prepared']['capture_recorded']])
    processes.append(process)
assert all(ids == raw_ids[0] for ids in raw_ids)
groups = {}
for variant in images:
    selected = [x for x in processes if x['variant'] == variant]
    groups[variant] = dict(metrics={k: stats([x['metrics'][k] for x in selected]) for k in selected[0]['metrics']},
                           phases={p['name']: stats([x['phases'][j]['tps'] for x in selected])
                                   for j, p in enumerate(selected[0]['phases'])},
                           loading={k:stats([x['loading'][k] for x in selected]) for k,v in selected[0]['loading'].items()
                                    if isinstance(v, (float,int))})
    for key, value in driver_summary['groups'][variant]['metrics'].items():
        assert value == groups[variant]['metrics'][key]
    for name, value in driver_summary['groups'][variant]['phases'].items():
        assert value == groups[variant]['phases'][name]
    assert groups[variant]['loading'] == driver_summary['groups'][variant]['loading']

memory = {}
peak_keys = dict(working_set_bytes='sampled_max_working_set_bytes', private_commit_bytes='sampled_max_private_commit_bytes',
                 gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes', gpu_shared_bytes='sampled_peak_gpu_shared_bytes',
                 gpu_total_bytes='sampled_peak_gpu_total_bytes')
for index, variant in enumerate(memory_input['order'], 1):
    folder = S / 'memory' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and receipt['memory_only'] and not receipt['throughput_evidence']
    assert receipt['image'] == images[variant]
    data, reported = read(folder / 'memory.json'), read(folder / 'memory-summary.json')
    assert not data['gpu_setup_error'] and not data['thread_error']
    samples = data['samples']
    running = [x for x in samples if x['process_running']]
    assert len(samples) == reported['sample_count'] and len(running) == reported['running_sample_count']
    peaks = {key: max((x[key] for x in samples if x.get(key) is not None), default=None) for key in KEYS}
    for key, value in peaks.items():
        assert value == data['peaks'][peak_keys[key]]
    assert peaks['gpu_total_bytes'] == max((x['gpu_dedicated_bytes'] + x['gpu_shared_bytes'] for x in samples
        if x.get('gpu_dedicated_bytes') is not None and x.get('gpu_shared_bytes') is not None), default=None)
    intervals = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(running, running[1:])]
    costs = [x['sample_duration_ns'] / 1e6 for x in running]
    assert stats(intervals) == reported['actual_sample_gaps_ms'] and stats(costs) == reported['sample_cost_ms']
    assert reported['sampled_peaks'] == data['peaks']
    boundaries = {x['name']: x['timestamp_ns'] for x in receipt['markers']}
    ready_rows = [x for x in running if boundaries.get('ready_before_prefill') is not None and
                  boundaries['ready_before_prefill'] <= x['timestamp_ns'] <= boundaries['round1_prefill_begin']]
    assert reported['ready_baseline']['unknown'] == (not ready_rows)
    assert reported['ready_baseline']['sample'] == (ready_rows[-1] if ready_rows else None)
    windows = {}
    for phase in plan['phases']:
        name = phase['name'];begin, end = boundaries[name + '_begin'], boundaries[name + '_end']
        rows = [x for x in running if begin <= x['timestamp_ns'] <= end]
        original = reported['phase_windows'][name]
        assert original['sample_count'] == len(rows) and not original['missing_boundary']
        vals = {k: stats([x[k] for x in rows if x.get(k) is not None], samples=False) for k in KEYS}
        for k in KEYS:
            for stat in ['count', 'min', 'median', 'max']:
                assert vals[k][stat] == original['values'][k][stat]
            assert sum(x.get(k) is None for x in rows) == original['null_sample_counts'][k]
        before = max((x for x in running if x['timestamp_ns'] <= begin), key=lambda x:x['timestamp_ns'], default=None)
        after = min((x for x in running if x['timestamp_ns'] >= end), key=lambda x:x['timestamp_ns'], default=None)
        ages = dict(before=begin-before['timestamp_ns'] if before else None, after=after['timestamp_ns']-end if after else None)
        delta = {k:after[k]-before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in KEYS}
        assert ages == original['bracket_ages_ns'] and delta == original['bracket_delta_bytes']
        windows[name] = dict(samples=len(rows), values=vals, null_counts=original['null_sample_counts'],
                             bracket_delta_bytes=delta, bracket_ages_ns=ages)
    memory[variant] = dict(result=identity(folder / 'result.json'), raw=identity(folder / 'memory.json'),
                           summary=identity(folder / 'memory-summary.json'), sample_count=len(samples), running_sample_count=len(running),
                           requested_interval_seconds=data['requested_interval_s'], actual_gaps_ms=stats(intervals, False),
                           sample_cost_ms=stats(costs, False), sampled_peaks_bytes=peaks,
                           null_counts={k: sum(x.get(k) is None for x in running) for k in KEYS},
                           ready_baseline_unknown=reported['ready_baseline']['unknown'], phases=windows,
                           setup_error=data['gpu_setup_error'], thread_error=data['thread_error'])

diagnostics = {}
for name in ['single-run1', 'multi-run1']:
    folder = S.parent / name
    summary, receipt = read(folder / 'summary.json'), read(folder / 'result.json')
    assert summary['passed'] and receipt['exit'] == 0 and receipt['image'] == images['current']
    pairs = summary['pairs'] if name == 'single-run1' else [x for v in summary['sessions'].values() for x in v]
    for pair in pairs:
        actual, baseline = verify(pair['actual']), verify(pair['baseline'])
        assert pair['byte_equal'] and actual['sha256'] == baseline['sha256'] and actual['bytes'] == baseline['bytes']
    assert len(pairs) == summary['vector_count']
    diagnostics[name] = dict(result=identity(folder / 'result.json'), summary=identity(folder / 'summary.json'),
                             verified_byte_equal_vectors=len(pairs), throughput_evidence=False)
cuda = read(S.parent / 'cuda-run1/result.json')
assert cuda['exit'] == 0
verify(cuda['image']);verify(cuda['source'])
diagnostics['append_cuda'] = dict(result=identity(S.parent / 'cuda-run1/result.json'),
    stdout=identity(S.parent / 'cuda-run1/stdout.log'), stderr=identity(S.parent / 'cuda-run1/stderr.log'),
    scope='Existing causal means/COW/retained snapshot checks and both take_append followed by submit FailedPrecondition; source and actual image bound by receipt.')

current_ready = read(S.parent / 'qwen-ready.json');dense_ready = read(W / 'ready-for-root.json')
provider = read(S.parent / 'checks/provider/identity.json')
assert provider['source']['sha256'] == '7f7d4d036c187fd206955a61f9e9f7a7873d2ab56f4eb8ee6e5476f44f9674e7'
verify(provider['object'])
assert provider['object'] in read(current_ready['link_plan']['path'])['inputs']
assert dense_ready['provider_source']['sha256'] == provider['source']['sha256']
compiled = read(S.parent / 'compiled.json')
current_link = read(current_ready['link_plan']['path'])
cuda_link = read(read(S.parent / 'cuda-ready.json')['link_plan']['path'])
for entry in compiled['records']:
    verify(entry['object'])
    assert entry['object'] in (cuda_link['inputs'] if '/tests/' in entry['source']['path'].replace('\\','/') else current_link['inputs'])
assert compiled['CXX'] == 6 and compiled['NVCC'] == 0 and compiled['SDK_builds'] == 0

comparisons = {}
for other in ['dense', 'peer']:
    comparisons[other] = {k: (groups['current']['metrics'][k]['median'] / groups[other]['metrics'][k]['median'] - 1) * 100
        for k in ['processed_tokens_per_second', 'output_tokens_per_second', 'aggregate_prefill_tps', 'aggregate_decode_tps']}
memory_delta = {other: {k: memory['current']['sampled_peaks_bytes'][k] - memory[other]['sampled_peaks_bytes'][k]
    if memory['current']['sampled_peaks_bytes'][k] is not None and memory[other]['sampled_peaks_bytes'][k] is not None else None
    for k in KEYS} for other in ['dense', 'peer']}

report = dict(status='Final independent host-only recomputation of completed fixed-window records; no new model execution, build, device query or sampling.',
    script=identity(__file__), driver=identity(S.parent / 'performance.py'), original_driver=identity(F / 'multiturn/multiturn_run.py'),
    scope=dict(timing_processes=9, timing_processes_per_arm=3, separate_memory_processes=3,
               schedule_calls_per_process=99, decode_calls=96, prompt_calls=3, processed_tokens=864,
               generated_token_definition='3 last-row returned prompt tokens plus 96 teacher-forced decode results; not free-running generation.',
               capacity=1024, phases=[{k:p[k] for k in ['turn','name','input_tokens','calls','visible_before','visible_tokens']} for p in plan['phases']]),
    inputs=dict(manifest=manifest, files=input_files), images=images,
    provider_closure=dict(current_receipt=identity(S.parent / 'checks/provider/identity.json'), current_source=provider['source'], current_object=provider['object'],
        dense_source=dense_ready['provider_source'], current_link_plan=verify(current_ready['link_plan']), dense_link_plan=verify(dense_ready['link_plan']),
        compiled=identity(S.parent / 'compiled.json'), refreshed_objects=[dict(source=x['source'], object=x['object']) for x in compiled['records']],
        build_scope='Six scoped host TUs plus the current FI host provider: seven CXX, zero SDK/NVCC. All applicable fresh objects occur in their actual final current/CUDA link plans.',
        distinction='Both dense ff748694 and current ff42c532 use current 7f7d workspace-sizing source. The earlier paged 51e10e79 baseline used old 606ca/ac20 FI provider. This comparison also includes the paged Snapshot consumer, append and selective-unbind/core changes; it is not an isolated causal estimate of the recording patch.'),
    fairness=dict(same_manifest_capacity_and_teacherforced_inputs=True, unchanged_matched_native_cache_per_arm=True,
        timing_profiler=False, timing_memory_monitor=False, concurrent_benchmark_processes=False,
        order=timing_input['order'], same_99_ids_across_all_9_processes=True,
        endpoint='First phase input preparation to final host-visible next-token endpoint. Each evaluate includes actual prepare/submit/retirement/result work. Per-step logging is deferred; phase markers remain. Cold startup/model/family preparation is separately reported.',
        total_rate='864/session_seconds and 99/session_seconds; aggregate prefill=768/sum(three prefill phase seconds), aggregate decode=96/sum(three complete decode phase seconds). Never average phase TPS.',
        stable_rate='decode7..32 per round is diagnostic only; full 32-step phase and complete-session clocks include first use/capture. No samples, startup calls or tails removed.',
        environment='Stored outside-session GPU snapshots show utilization 53% before and 57% after, P0 and 2835MHz. No claim of idle/isolated/fixed-clock GPU; no new query performed.'),
    all_driver_timing_statistics_recomputed_match=True, groups=groups, timing_processes=processes,
    current_median_rate_change_percent=comparisons,
    memory_observations=memory, current_sampled_peak_delta_bytes=memory_delta,
    memory_limits=['One independently monitored process per arm; do not mix its timings with the nine unmonitored timing processes.',
        'Requested 10ms sampling is not exact cadence. Actual intervals/costs and null counts are retained. Phase values are samples/brackets, not exact allocation endpoints.',
        'GPU dedicated/shared process counters are sampled attribution, not exact physical VRAM allocation; total uses simultaneous available values, not sum of independent maxima.',
        'Do not add CPU private commit, working set and GPU shared as disjoint physical memory. Unknown remains null; phase sample counts may be small.',
        'Peak differences combine the full implementations, allocator/cache/private-workspace changes and sampling; they are not the footprint of one patch.'],
    actual_correctness_and_take_rejection=diagnostics,
    limits=['All predictions agree on this one teacher-forced long schedule; no independent model quality gate, full checkpoint or all internal state-byte proof.',
        'Matched BF16 model/input and host-visible returned-token timing do not imply identical intermediate arithmetic or identical public logits/argmax transfer strategy across Hyle and llama.cpp; existing D4 precision/transfer limits remain.',
        'Three samples per arm have substantial overlap/spread and external GPU activity. Preserve the negative current median results; no stable speedup or statistical significance claim.',
        'Reader ranges are reused only until real native topology/carrier changes: long current logs have four T1 calls with 6 recorded/1 reused as well as ninety with 0 recorded/7 reused, and two first-use calls with 7/0.',
        'No new run/build/GPU operation or product edit by this review. No cleanup performed.'])
target = S / 'independent-review.json'
target.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(target), medians={a:{k:v['median'] for k,v in g['metrics'].items()
    if k in ['session_seconds','aggregate_prefill_tps','aggregate_decode_tps','processed_tokens_per_second','output_tokens_per_second']} for a,g in groups.items()},
    sampled_GPU_peak_bytes={a:{k:v for k,v in m['sampled_peaks_bytes'].items() if k.startswith('gpu_')} for a,m in memory.items()})))
