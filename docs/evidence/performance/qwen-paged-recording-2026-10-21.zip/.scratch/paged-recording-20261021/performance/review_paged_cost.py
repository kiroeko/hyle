from pathlib import Path
import hashlib
import json
import re
import statistics

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent

def identity(path):
    path = Path(path)
    value = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(value), "sha256": hashlib.sha256(value).hexdigest()}

def summarize(rows):
    if not rows:
        return None
    return {
        "calls": len(rows),
        "cold_sum_seconds": sum(x["cold_seconds"] for x in rows),
        "cold_median_seconds": statistics.median(x["cold_seconds"] for x in rows),
        "cold_min_seconds": min(x["cold_seconds"] for x in rows),
        "cold_max_seconds": max(x["cold_seconds"] for x in rows),
        "body_sum_seconds": sum(x["body_seconds"] for x in rows),
        "submit_sum_seconds": sum(x["submit_seconds"] for x in rows),
        "step_sum_seconds": sum(x["step_seconds"] for x in rows),
        "capture_ranges_recorded": sum(x["recorded"] for x in rows),
        "capture_ranges_reused": sum(x["reused"] for x in rows),
    }

processes = []
raw_inputs = []
for folder in sorted((HERE / "timing").iterdir()):
    if not folder.is_dir():
        continue
    arm = folder.name.split("-", 1)[1]
    output = folder / ("peer-result.json" if arm == "peer" else "stdout.log")
    parsed = json.loads(output.read_text())
    phases = parsed["phases"]
    process = {
        "name": folder.name,
        "arm": arm,
        "session_seconds": parsed["session_seconds"],
        "session_generated_tokens_per_second": parsed["generated_tokens"] / parsed["session_seconds"],
        "decode_seconds": sum(x["seconds"] for x in phases if x["kind"] == "decode"),
        "prefill_seconds": sum(x["seconds"] for x in phases if x["kind"] == "prefill"),
        "exit": json.loads((folder / "result.json").read_text())["exit"],
    }
    raw_inputs.extend(identity(folder / name) for name in ("stderr.log", "result.json"))
    raw_inputs.append(identity(output))
    if arm != "peer":
        rows = []
        prepared = None
        for line in (folder / "stderr.log").read_text().splitlines():
            if line.startswith("prepared "):
                prepared = dict(item.split("=", 1) for item in line.split()[1:])
                continue
            match = re.match(r"round([1-3])_(prefill|decode\d+) tokens=", line)
            if not match or prepared is None:
                continue
            step = dict(item.split("=", 1) for item in line.split()[1:])
            rows.append({
                "turn": int(match[1]), "kind": "decode" if match[2].startswith("decode") else "prefill",
                "name": line.split()[0], "T": int(prepared["T"]), "visible": int(prepared["visible"]),
                "cold_seconds": float(prepared["cold_batch_seconds"]),
                "recorded": int(prepared["capture_recorded"]), "reused": int(prepared["capture_reused"]),
                "step_seconds": float(step["step_seconds"]), "body_seconds": float(step["seconds"]),
                "submit_seconds": float(step["submit_seconds"]),
            })
            prepared = None
        assert len(rows) == 99
        process["logged_buckets"] = {
            "all_decode": summarize([x for x in rows if x["kind"] == "decode"]),
            "pure_reuse_decode": summarize([x for x in rows if x["kind"] == "decode" and x["recorded"] == 0]),
            "per_turn": [
                {"turn": turn,
                 "decode": summarize([x for x in rows if x["kind"] == "decode" and x["turn"] == turn]),
                 "pure_reuse_decode": summarize([x for x in rows if x["kind"] == "decode" and x["turn"] == turn and x["recorded"] == 0]),
                 "prefill": summarize([x for x in rows if x["kind"] == "prefill" and x["turn"] == turn])}
                for turn in range(1, 4)
            ],
        }
        process["rows"] = rows
    processes.append(process)

aggregates = []
for arm in ("dense", "current", "peer"):
    selected = [x for x in processes if x["arm"] == arm]
    aggregate = {
        "arm": arm, "processes": len(selected),
        "session_generated_TPS_median": statistics.median(x["session_generated_tokens_per_second"] for x in selected),
        "decode_TPS_from_summed_wall": 96 * len(selected) / sum(x["decode_seconds"] for x in selected),
        "prefill_TPS_from_summed_wall": 768 * len(selected) / sum(x["prefill_seconds"] for x in selected),
    }
    if arm != "peer":
        pooled = [row for process in selected for row in process["rows"]]
        aggregate["pooled_pure_reuse_by_turn"] = [
            {"turn": turn, "metrics": summarize([x for x in pooled if x["kind"] == "decode" and x["turn"] == turn and x["recorded"] == 0])}
            for turn in range(1, 4)
        ]
    aggregates.append(aggregate)

sources = {
    "main": ("tools/qwen35_text/main.cc", ["1097-1270"]),
    "private_snapshot_policy": ("tools/qwen35_text/session_state.h", ["28-58", "88-131", "157-168"]),
    "append": ("src/graph_batch/paged_append.cc", ["41-56", "67-145", "166-176", "231-259"]),
    "arena": ("src/compute_batch/paged_arena.cc", ["83-91", "101-113", "218-247"]),
    "layout": ("src/compute_batch/batch_layout.cc", ["264-287", "349-363"]),
    "batch": ("src/graph_batch/batch.cc", ["937-964", "1039-1070"]),
    "resources": ("src/graph/resources.cc", ["499-524", "614-671", "689-710", "1063-1110", "1345-1385"]),
    "command_bindings": ("src/graph/executable.cc", ["1213-1303", "1340-1358"]),
    "permission_set": ("src/graph/lease_submission.cc", ["19-70"]),
    "resource_leases": ("src/compute/resource_leases.cc", ["201-227", "339-348"]),
    "borrow_contract": ("include/hyle/graph/detail/region_access.h", ["15-27"]),
    "actual_cuda_carrier": ("src/graph_provider_ggml_cuda/ggml_cuda_region.cc", ["1160-1187"]),
    "retained_dense_source_comparison": (".scratch/paged-append-20261021/qwen-snapshot/before/main.cc", ["770-778", "970-978", "1030-1071"]),
}

report = {
    "status": "read-only-source-and-existing-timing-review",
    "scope": "No new instrumentation, build, link, GPU run, product edits or stable performance verdict.",
    "symbols": {
        "P": "Active logical/unique prefix page count; one serial request in this observed workload, page size 16.",
        "D": "Dirty target pages, normally 1 for T1 and 16 for aligned T256.",
        "B": "ResourceEpisode lease binding candidates, fixed ports plus approximately 12*P historical KV page guards.",
        "M": "Input ports of all native prepare-bindings regions actually revisited this preparation.",
        "G": "Selected Graph region/step count (current T1 1041 steps, dense 1047).",
    },
    "source_identities_and_anchors": {key: {**identity(ROOT / path), "line_ranges": lines} for key, (path, lines) in sources.items()},
    "timing_semantics": {
        "cold_batch_seconds": "main 1122-1199: snapshot/page policy, layout creation, twelve append transactions, 36 input-state binds and 36 output lease-pool allocations/binds, batch prepare/bind and replay preparation/report. Token/position writes occur just before this timer. This is not just native scheduler time.",
        "seconds": "main 1200-1238/1253: submit + wait + next-ID read + 36 state lease exports + 12 take/ready publications + selective unbind + head swap + old transaction destruction. It is not GPU-only or publish-only time.",
        "submit_seconds": "run.submit elapsed, includes host permission admission and enqueue work; asynchronous GPU work may proceed during it. Do not add this bucket to seconds because it is already included.",
        "step_seconds": "End-to-end host token step, including cold_batch_seconds and seconds; phase/session timers add small outer-loop costs. Rounded stderr buckets are descriptive, not a causal partition of GPU/CPU.",
    },
    "existing_window": {
        "per_arm_process_count": 3, "each_process": "3 x (prefill 256 + decode 32), context 1024; 864 processed tokens and 99 predictions.",
        "aggregate_formula": "decode=288/sum(three decode phase walls); prefill=2304/sum(three prefill phase walls); session median uses each process 99/session_seconds.",
        "aggregates": aggregates,
        "per_process": [{key: value for key, value in process.items() if key != "rows"} for process in processes],
        "confirmed_replay_fact": "Each current process has 90/96 decode calls with 0 recorded and 7 reused capture ranges (30 per turn). The first two T1 parity slots per turn still record 14,12,12 ranges in total across each turn. Therefore hot capture re-recording is not the historical-length-growing cost in the 90 hot steps.",
        "range_count_limit": "0 recorded does not mean zero enqueue work or one native launch. Current steady steps replay seven ranges, whereas the retained dense process reuses one. Range count is not kernel count and its cost is not separately measured here.",
        "background_limit": "Parent observed desktop GPU background utilization about 53% before and 57% after the window. Whole-process GPU timings fluctuate substantially. Neither stable regression nor any function-level share is established by these nine processes.",
        "raw_inputs": raw_inputs,
    },
    "confirmed_complexity_findings": [
        {
            "id": "quadratic-append-page-set-work", "owner": "Graph batch typed append; no Qwen-specific fast path needed",
            "actual": "create: final_pages line98 linear find for every logical page; old_page line90 scans and revalidates old leases, called for each untouched prefix page at121. This is O(P^2 + P*D + D^2), even with T1/D=1. ready lines140-143 scans final_pages and growing ready_pages for every old lease, again O(P^2). Twelve banks repeat it.",
            "minimal_algorithm": "Use canonical sorted physical IDs already guaranteed by PagedArena::read_impl. Extract and validate old lease IDs once into a private ordered index, then binary-search/merge rather than repeated full scans. Obtain next layout's sorted unique footprint once, or sort_unique once, replacing final_pages repeated find. Merge old-ready and dirty-ready IDs in linear order. Preserve original dirty-writer indices for copy ranges. This makes set work O(P log P + D log D) or linear merge once sorted; one shared BatchLayoutVersion footprint can be reused across all twelve banks.",
            "retain": "Every supplied lease/writer must still pass arena/root/generation/exact range/current initialized-prefix checks. Preserve dirty uniqueness, untouched-prefix identity, separate partial-tail COW target, per-request logical mapping, exact active rows and writer ownership-on-failure. Never infer permission from an integer ID or capacity TensorView.",
            "timing_claim": "True source-level avoidable quadratic work. No exclusive timing of this function was collected; no measured speedup claimed.",
        },
        {
            "id": "unused-native-lease-search", "owner": "Graph prepare_command_bindings generic borrowed carrier contract",
            "actual": "executable.cc1252 unconditionally input_lease for each native input; resources.cc1096 scans candidates and asks each lease for its view. New page guards make B grow with P, producing O(M*B) work. borrowed_tensor_carrier is already positively proven at1227 but only suppresses the following native_inputs bit. GGML CUDA's actual prepare_bindings1167-1174 consumes only inputs[i].tensor; its callback ABI cannot consume RegionValue leases.",
            "minimal_algorithm": "For the exact positive borrows_tensor_views_only artifact contract, set value.lease=nullptr and skip this unused lookup. Preserve existing input_lease behavior for all unproven/private-native import paths. No new cache, provider allowlist or Qwen condition is needed.",
            "retain": "Keep true Episode owners, complete projected reader/writer validation, per-submit LeasePermissionSet, real readiness/generation checks, current physical tensor comparison, backend stable capture identity, seal hooks, cancellation and retirement unchanged. A borrowed carrier must never gain permission from a retained TensorView.",
            "timing_claim": "Removes provably unconsumed work; extent and gain are not isolated by the current timer.",
        },
        {
            "id": "flat-snapshot-metadata-and-lifecycle-churn", "owner": "Consumer snapshot policy plus typed append/arena metadata",
            "actual": "main1140-1152 copies all full-prefix PageRefs and page IDs each call: O(P). It constructs twelve append owners with fresh vectors; append81-84 reserve eight nonempty metadata vectors including temporary facts on this workload. Each ready frame later allocates its own frame and page-lease vector, copies O(P) leases and sorts O(P log P). Shared BatchLayoutVersion itself allocates host metadata buffer and copies page table once (layout264-287); its footprint is memoized within that immutable version (349-363). Neither recurrent outputs nor all KV contents are re-copied just to publish a Snapshot.",
            "minimal_direction": "First remove repeated searches above. If allocation/profile evidence still warrants it, reuse bounded transaction scratch in its original idle Invocation/slot, and transfer already-reserved validated ready-list storage into a new immutable frame rather than build/copy a second temporary list. Escaped immutable Snapshot/frame owners must retain their own live metadata and budget; scratch cannot alias or overwrite an old frame. Preserve source/layout exact identity and no hidden global cache. Main's policy PageRef/page-ID O(P) flattening is a separate later concern, not a reason to add a new persistent-tree framework now.",
            "additional_fixed_work": "bind_append proof/find and take_append use region visits proportional to G multiple times per bank; twelve banks make large O(12*G) constants, not growing P by themselves. Do not blame these visitors for a quadratic history curve without measurements.",
        },
    ],
    "permission_admission_is_not_the_quadratic_bug": {
        "actual_path": "resources.reserve_reads521 enables LeasePermissionSet. begin_submission1367 collects bindings once and1382 admits; lease_submission38-70 sorts by original block identity, validates duplicate generations/modes and calls trusted read_unique/write_unique. resource_leases339-348 uses add_use<true>, bypassing the generic linear duplicate scan at205-212.",
        "complexity": "O(B log B) sort plus O(unique permissions) actual locking/validation/retain/retire. Not O(B^2) on this path. Admission still grows with active historical page count and is included in submit_seconds.",
        "required": "Do not skip real current page admission or reuse an old episode's permissions to improve timing. Unread capacity and another user's pages remain unqualified.",
    },
    "copy_and_space_costs": {
        "row_and_page_bytes": "Each K or V bank has 1024 bytes/row and 16 rows/page; 12 independent banks. Prefix COW copies only the partial old tail, not the entire historical cache.",
        "decode_exact_for_logged_schedule_per_process": {
            "calls": 96,
            "required_new_KV_copy_commands": 1152,
            "partial_tail_COW_copy_commands": 1080,
            "required_new_KV_bytes": 1179648,
            "extra_COW_prefix_bytes": 8847360,
            "derivation": "Each aligned 32-step decode round has two 16-step periods with inherited rows 0..15; sum=240 old rows/bank/round. Three rounds times12banks times1024bytes=8,847,360 extra bytes. Copy commands are source-derived accepted-success command counts, not a new instrumented GPU measurement.",
        },
        "prefill": "Each observed T256 begins at an aligned old length (0,288,576), so no partial-tail COW. It creates sixteen new target pages per bank, enqueuing192 separate new-row copies rather than one Scatter operation per bank. Exact old-prefix metadata still processed for all P pages. Physical contiguity may permit a generic future segment-coalescing/device-append implementation; do not broaden writable bank permissions or use a Qwen-only executor.",
        "exclusive_append_constraint": "Do not simply bypass COW based on shared_ptr/PageRef counts. Existing page WriteLease is whole-page and failures poison that generation; modifying a retained page could invalidate old committed head/prefix rollback. A safe exclusive suffix-write contract must prove real uniqueness and protect the committed prefix on failure, or retain this small COW. Cross-session/shared-prefix cases always require the genuine immutable old version.",
        "backing": "Shared KV arenas plus N+1 conv/GDN state slots are preallocated and globally budgeted once. Current N1/context1024 stdout reports51,855,408 cache backing bytes. LeasePool.allocate each step recycles reserved backing; it is not a fresh19.5MB GPU allocation or an extra full-state memcpy per token. Published Snapshot adds O(P) host lease/policy metadata per live version. Exact old snapshots continue consuming their actual page/state budgets.",
    },
    "recommended_next_order": [
        "Apply exact borrowed TensorView carrier lease-lookup skip; narrow Graph core change preserving all permissions.",
        "Replace typed append create/ready quadratic page-set work with validated sorted-index/merge algorithms, then reuse its shared immutable layout footprint. Keep current cross-session COW and atomic head publication.",
        "Only after those algorithmic fixes, use the same existing benchmark boundaries to assess remaining metadata allocation/fragmented copy/range-launch costs. No stable speed verdict or extra validation matrix is needed from this read-only review.",
    ],
    "actions": {"product_edits": 0, "builds": 0, "new_GPU_runs": 0, "new_instrumentation": 0},
}
path = HERE / "paged-cost-source-review.json"
path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": identity(path), "aggregates": aggregates}, indent=2))
