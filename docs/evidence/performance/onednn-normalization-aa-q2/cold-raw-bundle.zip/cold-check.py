"""Exactly two real verify-only processes, no Bench::compare or performance verdict."""
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

task = Path(__file__).resolve().parent
repo = task.parents[3]
module = repo / 'bench/graph_provider_onednn/normalization_preflight.py'
spec = importlib.util.spec_from_file_location('preflight', module)
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
build = Path('C:/hyle-scratch/active-cpu/p1')
root = task / 'cold-attempt-1'
root.mkdir(exist_ok=False)
ctypes.WinDLL('kernel32', use_last_error=True).SetErrorMode(0x8003)
binaries = {'primary': build / 'bin/hyle_onednn_normalization_bench.exe',
            'placement': build / 'bin/hyle_onednn_normalization_bench_placement.exe'}
runtime = p.stage_runtime(binaries, build)
profile = p.get_machine_profile(p.load_registry(), 'W1-WIN')
probe = p.probe_machine(paths=[('build', build)])
gate = p.evaluate_machine_profile(profile, probe, role='engineering', sampling_topology='single-logical-cpu')
assert gate['gate'] == 'PASS', gate
policy = p.expected_child_policy(profile, probe=probe, sampling_topology='single-logical-cpu')
contract = json.loads((repo / 'bench/contracts/onednn-normalization-p1-v1.json').read_text(encoding='utf-8'))
workloads = [r['id'] for r in contract['workloads']]
records = []
for variant, route in (('primary', 'selected'), ('placement', 'peer')):
    binary = binaries[variant]
    overrides = {'HYLE_BENCH_VERIFY_ONLY': '1', 'HYLE_BENCH_AA_ROUTE': route,
                 'HYLE_BENCH_OBSERVE_INSTANCES': '1', 'ONEDNN_JIT_DUMP': '1',
                 'HYLE_PERF_RUN_NONCE': 'q2-cold-' + variant}
    if route == 'selected':
        overrides.update(HYLE_BENCH_RIVAL_FIRST='1', HYLE_BENCH_PEER_ALLOCATION_FIRST='1')
    environment = p._child_environment(contract['extensions']['runner']['controlled_environment'] +
                                      ['ONEDNN_JIT_DUMP', 'DNNL_JIT_DUMP'], overrides, profile, policy)
    environment.pop('PATH', None)
    directory = root / variant
    result = p.run_child(directory, [str(binary)], environment, overrides, timeout=120, policy=policy)
    assert result['exit_code'] == 0 and not result['timed_out'], result
    text = ''.join((directory / n).read_bytes().decode('utf-8', errors='replace') for n in ('stdout.bin', 'stderr.bin'))
    assert 'relative' not in text and 'ns/op' not in text
    observations = p.validate_instances(text, workloads, route, pid=result['pid'],
                                       affinity_mask=int(str(policy['affinity_mask']), 0), require_intervals=False)
    jit = {n: v for n, v in result['files'].items() if n.startswith('dnnl_dump_') and n.endswith('.bin')}
    assert len(jit) == (32 if route == 'selected' else 0), len(jit)
    p.write_record(directory / 'observations.json', observations)
    records.append({'variant': variant, 'route': route, 'status': 'PASS', 'workloads': len(workloads),
                    'instances': len(observations['instances']), 'jit_files': len(jit),
                    'executable_sha256': p.digest(binary), 'process': result})
summary = {'scope': 'Q2 two cold correctness and observation processes; no performance samples',
           'status': 'PASS', 'P1': 'NOT_RUN', 'records': records, 'policy': policy,
           'machine_gate': gate, 'runtime': runtime,
           'source_sha256': {str(f.relative_to(repo)): p.digest(f) for f in (
               module, module.with_name('normalization_p1_bench.cc'), module.with_name('normalization_preflight_test.py'),
               repo / 'bench/contracts/onednn-normalization-p1-v1.json')}}
p.write_record(root / 'result.json', summary)
print(json.dumps({'status': 'PASS', 'processes': 2, 'workloads': 32, 'instances': 64, 'timing': 'NOT_RUN'}))
