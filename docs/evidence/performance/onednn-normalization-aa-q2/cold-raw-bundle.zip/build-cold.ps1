$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\onednn-aa\q2'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VSLANG = '1033'
& ./scripts/hyle-windows.ps1 -Action Build -BinaryDir C:/hyle-scratch/active-cpu/p1 -ExtraArgs @('--parallel','2','--target','hyle_onednn_normalization_bench','hyle_onednn_normalization_bench_placement') > (Join-Path $taskRoot 'cold-build.log') 2>&1
$result = $LASTEXITCODE
Get-Content -LiteralPath (Join-Path $taskRoot 'cold-build.log') -Tail 16
exit $result
