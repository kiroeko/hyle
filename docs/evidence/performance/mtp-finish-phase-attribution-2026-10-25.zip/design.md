# Finish phase 最小私有诊断（仅源准备）

状态：未编译、未链接、未运行、未采集。只补两轮原 K1 的 1.5423ms/episode 归因断点；不测速、不做peer/普通/多K矩阵、不改canonical/SDK/数学。目录 `source/` 是此前已行为验证的625f系逻辑NVTX冻结源（32份自实现文件，约700KB），与当前产品源码不混用。新 `source.patch` 只插原 `finish_selected_evaluations`，反向移除标记可逐字恢复原整份main；源码检查见 `source-checks.json`，不是编译通过声明。

## 固定阶段

| phase | 原边界与包含的实际工作 |
|---|---|
| ledger_precheck | 构造原输出临时lease/guard，核各ledger/expected record，直到completion.wait之前。 |
| completion_wait | 原 `check(step.completion.wait()); step.completion={};`，保其原等待/退休语义；不把它当CPU自耗。 |
| readback_select_layout | 原trace输出pin、draft ID、valid/accept、target IDs读回，原select与accepted-boundary/layout更新。可能触发GPU传输/等待。 |
| export_state | 原GDN history/recurrent、carry/prior/必要probe storage lease导出，直到首次take_append。先导出后take_append顺序不变。 |
| take_appends_reframe | target/draft原append ready取回、reframe、draft tail权限转移，直到complete(step)之前。 |
| complete_validate_ledger | 原complete callback、完整MTP快照检查、ledger事实/expected校验、target tail所有权归整；不假定callback绝无GPU。 |
| unbind_authority | 原 `run.unbind(state_resource_ports)` 与 expected-base/no-stopping 检查。 |
| publish_retire | 原不可失败Head/tails交换、ledger committed、candidate admission转移与detach；结束后才执行原finished时钟行。 |
| observe_after_endpoint | 原finished与旧NVTX父范围关闭之后的endpoint事实赋值、可选preparation report、StepObservation和原observe callback。端点外，仍可能触发IO/传输。 |

没有重新排序原语句、改变scope或引入新同步。所有旧 `Clock::now()`、submit、wait、采样/选择、unbind、publish、abort及正常stdout/stderr报告语句保持原文本和顺序。标记本身必有开销，本诊断不输出TPS。异常在原abort之前只关闭当前诊断范围；不改变原abort/重抛。late-IO失败保head_published与endpoint已过的事实，不伪称未提交。

## 固定记录与生命周期

`finish_trace.h` 用256条冷静态纯数值Record、每条9对steady_clock ns、seq/role/T/R/context/frontier/lag、原record/reuse、accepted_inputs/发布长度/pending与结果标志。原同一工况预期68条（2prefill+66decode）、612个子范围；要求overflow=0、所有正常行seen=511、normal_return=true。单请求/串行原进程，不加锁或线程统计设施；sizeof在最终dump实际报告，不预签布局字节数。栈recorder只持固定记录指针，不保存Session/Step/ReadLease/Graph引用；detach后不再访问step。无热vector/string/分配/逐行打印/CUDAevent。

复用原NVTX域HyleLogicalCalls和seq；子范围固定字符串，payload为seq，不改旧helper的sequence/finished_ranges计数。POD和原NVTX摘要均在 `qwen35::run` 返回后输出，保原正常日志；不用静态析构承诺初始化顺序。POD的steady_clock epoch不与Nsight/CUDA epoch相减，只以seq+phase对齐、各取自己的delta。

## CUDA活动归属，避免把post-wait写成纯host

1. 保原Nsight配置 `cuda,cublas,nvtx`、node graph trace、sample/cpuctxsw none、20s/120s。若将来授权，仅一次原Hyle进程，原argv只换EXE；当前命令只记录在plan，没有执行入口自动触发。
2. **提交来源**：取同globalTid、被该NVTX phase包含的实际runtime/driver API，按实际correlationId关联kernel/copy/memset。同时保旧prepare/replay/submit桶；嵌套时选实际最细phase。没有唯一关联、driver表缺失、API跨界或不支持字段一律unknown，不靠originalGraph/originalNode lineage补造。
3. **实际执行区间**：另按GPU时间与每个CPU NVTX phase求交、取区间并集。提交在readback但执行到后一个phase的工作，保origin与execution两维并列；之前submit发出的正文即使主要落在completion_wait，也不改称“wait提交”。不可双加origin统计、execution统计、父范围及子范围。
4. 每phase wall、观察到的GPU union、API种类/次数和未知关联分别保留；wall−GPU union只叫“未见GPU活动”，不是CPU利用率或可回收量。post-wait的读回、append或unbind发现新GPU工作就按原证据记，绝不整体预标pure-host。

root已核原 `src/compute_backend_cuda/cuda_backend.cc:444` 的wait_event直调cudaEventSynchronize，event仅DisableTiming，无库层固定sleep/poll。可在原同Nsight时钟里描述最后可见GPU活动→该wait API返回的间隔和同期API，但不把该间隔叫固定1ms轮询或CPU自耗；POD时钟不参与跨域相减。

## 构建/对照与停止

`plan.json` 给原O2/W4/WX app编译命令和精确link/profile argv。仅将原c343 app OBJ替为这个新1TU；复用native-seed `graph2/unit.obj`/`region/unit.obj`、原另外3个Graph/batch/CUDA-region OBJ、原report OBJ及其余真实193-object闭包，没有CUDA/报告重编。所有绝对旧link输入已存在（系统短库名仍由原LIB环境解析），原CPU companion只复用seed/link2已有同DLL，不复制SDK。两个seed对象已经实际同c343 app验证，不声称当前全部quant provider新SDK都认证。

将来一次原输入/schedule/seed/greedy/K1进程若获授权，完整128IDs、dispatch/batches/rounds、ledger/pending/RNG、66验证/132target行、124draft decode行/434总行、60接受/6拒绝、2prefill309target/310draft及原所有非时间报告必须对既有baseline全同；沿用原 `analyze.py` 已审normalize规则，新增FINISH_*只属于仪器。计时/新范围不能混入正式32窗。首失败/overflow/缺阶段保留并停止分析完整性声明，无自动重采、无补样矩阵。

源级可简化的判断：原shared `prepared_output.h:146–151` 的retain_output只调用run.result+storage_lease，合同明确不wait/copy/publish；`main.cc:2164` 成功路径只是转移原ReadLease。因此不在36份状态端口再造“逐份D2D计数器”，也没有证据直接删除状态导出/权限。底层lease控制成本及可能原生行为仍由本次phase/API事实检查；短owners/tail容器的存在尚不能证明大额热点，不据源码外观直接优化。
