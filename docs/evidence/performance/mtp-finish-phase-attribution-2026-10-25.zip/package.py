"""Package existing one-profile observations only. No compile, model, GPU or HTTP."""
import hashlib,json,sqlite3,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path.cwd(); W=R/'.scratch/mtp-finish-phase-20261025'; A=json.loads((W/'analysis.json').read_bytes())
E=W/'extracts'; E.mkdir(exist_ok=True)
def pin(p):
 return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
c=sqlite3.connect('file:'+(W/'trace1/trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;c.execute('PRAGMA query_only=ON')
queries=dict(A['SQL']);queries['diagnostics']='SELECT * FROM DIAGNOSTIC_EVENT';queries['strings']='SELECT id,value FROM StringIds'
extracts={}
for name,sql in queries.items():
 p=E/(name+'.jsonl');count=0
 with p.open('w',encoding='utf-8',newline='\n') as f:
  for row in c.execute(sql):
   f.write(json.dumps(dict(row),separators=(',',':'))+'\n');count+=1
 extracts[name]={'SQL':sql,'rows':count,**pin(p)}
save(E/'index.json',{'source_sqlite':pin(W/'trace1/trace.sqlite'),'extracts':extracts,'columns':A['table_columns'],'driver_table_present':A['driver_table_present']})
ready=json.loads((W/'ready.json').read_bytes()); plan=json.loads((W/'plan.json').read_bytes()); terminal=json.loads((W/'run-terminal.json').read_bytes())
o=A['same_trace_outer_episode']; coverage=A['coverage']
metadata=[]
import re
for line in re.findall(r'^FINISH_META (.*)$',(W/'trace1/native-stderr.log').read_text(),re.M):
 metadata.append({k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',line)})
by_seq={m['seq']:m for m in metadata}
coverage['POD_metadata_observation_by_seq']=[{'seq':i,'normal_return':by_seq.get(i,{}).get('normal_return'),'seen':by_seq.get(i,{}).get('seen')} for i in range(1,69)]
phase_summary={name:{k:v for k,v in d.items() if k!='largest3_wall'} for name,d in A['decode_phase'].items()}
summary={
 'status':'ONE_PROFILE_WORK_PASS_NVTX_COMPLETE_POD_STREAM_PARTIAL',
 'observed_on':'2026-10-25','scope':'One private Hyle CUDA greedy K1 real two-turn Nsight profile; diagnostic attribution only, no new throughput baseline.',
 'execution':{'new_app_TUs':1,'links':2,'new_core_TUs':0,'new_CUDA_TUs':0,'SDK_builds':0,'model_profile_processes':1,'HTTP':0,'terminal':terminal,'image':ready['image'],'app_object':ready['app_object']},
 'source_and_closure':{'app':'Private11-marker finish_selected_evaluations instrumentation, whole main reverse-diff equals prior successful logical-call source; original math/work/endpoints/normal logging unchanged.',
 'source_checks':json.loads((W/'source-checks.json').read_bytes()),'source_checks_status_is_original_source_only_checkpoint':True,
 'seed_correction_present':True,'key_objects':plan['retained_key_objects'],'merged_lifetime_replacements':plan['merged_lifetime_replacements'],
 'merged_lifetime_proof':plan['merged_lifetime_public_proof'],
 'closure_limit':'Frozen successful BF16 application+merged seed Graph objects+two merged current lifetime objects. No fresh whole-SDK or new formal32-process certification; unchanged original native BF16 math/templates reused.'},
 'work':A['work'],'coverage':coverage,
 'same66_decode_episode':{k:v for k,v in o.items() if k!='episodes'},
 'decode_finish_phase':phase_summary,
 'post_wait_inside_original_endpoint':{'phases':['readback_select_layout','export_state','take_appends_reframe','complete_validate_ledger','unbind_authority','publish_retire'],'total_ms':13.350560,'mean_ms_per_episode':13.350560/66,'scope':'Not pureCPU: readback contains132 actual cuMemcpyDtoH calls and0.149311ms observed GPUunion.'},
 'caller_gap':{k:v for k,v in A['caller_dispatch_gap'].items() if k!='samples'},
 'last_observed_GPU_end_to_wait_API_return':{k:v for k,v in A['decode_last_visible_GPU_to_wait_return'].items() if k!='rows'},
 'same_role_T_GPU_comparison':A['same_role_T_GPU_comparison'],
 'conclusion':['The same66 episodes close to1076.618326ms wall,899.218108ms observedGPUunion and177.400218ms wall without observedGPU. These are overlapping CPU/GPU views, not additive costs or recoverableCPU.',
 'prepare137.692054ms includes replay107.096586ms. Cold-record groups are longer;45 no-record episodes median14.806485ms. The same profile actually contains13 Instantiate and19 ExecUpdate calls, all recorded APIreturn0; Update result-info payload was not captured.',
 'Post-wait state/readback/publication inside original endpoint averages0.202281ms perdecode episode. It alone does not support attributing the historical1.5423ms difference; no cross-profile subtraction is performed.',
 'Source-backed follow-up may examine complete binding changes at cold-record misses. Existing first-difference-only tuples do not establish that small I/O addresses explain every miss; no staging implementation or new run is claimed.'],
 'retained_failures':[
 {'kind':'FIRST_LINK_LNK2019_LNK1120','path':'.scratch/mtp-finish-phase-20261025/link','model_started':False,'reason':'Old c343 budget/leases objects lacked retain_allocator_owner referenced by current public inline StorageOwner. Reused two already merged objects and same appOBJ for successful link2; no SDK/core compile.'},
 {'kind':'PRIVATE_PREFLIGHT_WDDM_DESKTOP_MISCLASSIFICATION','path':'.scratch/mtp-finish-phase-20261025/preflight-failure1.json','model_started':False,'correction':'Desktop graphicsN/A is not a competing inference workload. Corrected inventory classifier before sole authorized profile.'}],
 'limitations':A['limits']+['Nsight runtime table has returnValue. Separate driver table absent; unknown driver-only activity and missing original graph/node lineage remain unknown.',
 'Complete raw normal stdout/report is retained. Nsight ProcessStreams stderr is actually truncated midway through seq8 POD dump; original tool temp files no longer exist. Only8 normal_return/seen metadata rows directly observed; remaining60 are null. No recapture.',
 'Parent/child intervals are not added: replay is nested in prepare, finish phases are nested in wait_publish; observe_after_endpoint is outside original logical endpoint.',
 'GPU role attribution uses actual nonzeroGraphId kernel groups with exactlyone matching runtime GraphLaunch correlation and unchanged known738 target/37-or41 draft kernel count. It is not proof of original-node lineage.',
 'Peer table comes from its previous own profile, same role/T only; context/precision/cold mix and completion boundaries differ. No difference of Hyle/peer episode scopes is taken.',
 'All phase times are profiled diagnostic times, not TPS; historical clean32-process latency and1.5423ms algebraic difference are not refreshed.'],
 'raw_trace_retained_private':{'nsys_rep':pin(W/'trace1/trace.nsys-rep'),'sqlite':pin(W/'trace1/trace.sqlite')},
 'public_recompute_data':{'SQL_extract_index':'extracts/index.json','complete_phase_rows':'analysis.json:phase_rows','complete_episodes':'analysis.json:same_trace_outer_episode.episodes','parser':'analyze.py','work_normalizer':'references/logical-call-analyze.py','baseline_raw':'references/baseline-hyle-mtp.stdout.log'},
 'reproduction':['python .scratch/mtp-finish-phase-20261025/analyze.py','Exact compile/link/profile argv in archive compile/command.json,link2/command.json,trace1/command.json; no rerun is needed for this conclusion.']}
save(W/'proof-summary.json',summary)
files={}
def add(p,name=None):
 if p.is_file():files[name or p.relative_to(W).as_posix()]=p
for p in W.iterdir():
 if p.is_file() and p.suffix in {'.json','.py','.h','.cc','.patch','.md'} and p.name!='analysis-console.json':add(p)
for folder in ['source','extracts','compile','link','link2','trace1']:
 for p in (W/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.jsonl','.log','.h','.cc','.py','.md','.patch'}:add(p)
add(R/'.scratch/mtp-logical-call-trace-20261025/analyze.py','references/logical-call-analyze.py')
add(R/'.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/stdout.log','references/baseline-hyle-mtp.stdout.log')
add(R/'docs/evidence/performance/mtp-logical-call-attribution-2026-10-25.json','references/peer-logical-call-public.json')
manifest={name:pin(p) for name,p in sorted(files.items())};save(W/'archive-members.json',manifest);add(W/'archive-members.json')
out=R/'docs/evidence/performance/mtp-finish-phase-attribution-2026-10-25.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert all(not n.lower().endswith(('.obj','.exe','.lib','.dll','.pdb','.nsys-rep','.sqlite')) for n in z.namelist())
 count=len(z.namelist())
summary['archive']={**pin(out),'members':count,'contains':'Bounded frozen self-written sources/delta, exact commands/dependency pins, failures, complete raw stdout, actualpartial stderr,612 phase rows, complete queried NVTX/API/kernel/copy/memset/diagnostic/string SQLextracts and parser. No executable/object/SDK/weights/large originaltrace duplicate.'}
public=R/'docs/evidence/performance/mtp-finish-phase-attribution-2026-10-25.json';save(public,summary)
save(W/'publication-check.json',{'status':'PASS','public_json':pin(public),'archive':summary['archive'],'extract_rows':{k:v['rows'] for k,v in extracts.items()},'zip_integrity':True,'no_binary_or_original_trace_duplicates':True})
print(json.dumps({'public_json':pin(public),'archive':summary['archive'],'extract_rows':{k:v['rows'] for k,v in extracts.items()}},indent=2))
