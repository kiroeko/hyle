"""One authorized app TU/link only. This script never starts the native image."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
plan = b.read(W / 'plan.json')
pins = b.read(W / 'source-pins.json')

def verify(item):
    path = R / item['path']
    actual = b.pin(path)
    if actual['bytes'] != item['bytes'] or actual['sha256'] != item['sha256']:
        raise RuntimeError('Input changed: ' + str(path))

for item in pins:
    verify(item)
for item in plan['retained_key_objects']:
    verify(item)
verify(plan['runtime_cpu_companion_source'])
b.save(W / 'build-before.json', {'sources': pins, 'key_objects': plan['retained_key_objects'],
    'plan': b.pin(W / 'plan.json'), 'build_script': b.pin(Path(__file__).resolve()),
    'scope': 'One app compiler TU and link only; no SDK/core/CUDA build or native run.'})
env = b.environment(plan['commands']['compile'][0])
b.execute(plan['commands']['compile'], W / 'compile', env, 120)
deps = b.read(W / 'compile/dependencies.json')['Data']
actual_pins = []
for name in [deps['Source'], *deps['Includes']]:
    path = Path(name).resolve()
    if any(path.is_relative_to(R / prefix) for prefix in ('engine', 'tests', 'tools')):
        raise RuntimeError('Canonical private source leaked into diagnostic: ' + str(path))
    if path.is_relative_to(R) or 'nvtx3' in str(path):
        actual_pins.append(b.pin(path))
b.save(W / 'compile/source-pins.json', actual_pins)
b.execute(plan['commands']['link'], W / 'link', env, 120)
source_dll = R / plan['runtime_cpu_companion_source']['path']
os.link(source_dll, W / 'link' / source_dll.name)
for item in pins:
    verify(item)
for item in plan['retained_key_objects']:
    verify(item)
for item in actual_pins:
    path = Path(item['path'])
    if b.pin(path) != item:
        raise RuntimeError('Actual dependency changed during build: ' + str(path))
b.save(W / 'ready.json', {'status': 'COMPILED_LINKED_NOT_RUN',
    'image': b.pin(W / 'link/consumer.exe'), 'app_object': b.pin(W / 'compile/unit.obj'),
    'CPU_companion_hardlink': b.pin(W / 'link' / source_dll.name),
    'source_pins': actual_pins, 'source_unchanged_after_build': True,
    'compiler_TUs': 1, 'links': 1, 'SDK_builds': 0, 'new_CUDA_TUs': 0,
    'GPU_processes': 0, 'HTTP': 0,
    'parent_GPU_grant_still_required': True})
print(json.dumps({'status': 'READY_NOT_RUN', 'image': b.pin(W / 'link/consumer.exe'),
    'actual_source_dependencies': len(actual_pins), 'GPU_processes': 0}), flush=True)
