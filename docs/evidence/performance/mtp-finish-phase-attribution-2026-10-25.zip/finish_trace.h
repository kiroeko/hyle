#pragma once
#include "logical_trace.h"
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdio>

// Private one-thread, one-Model diagnostic. No product hook, new synchronization,
// allocation or CUDA event is introduced into the original execution path.
namespace finish_trace {
enum class Phase : unsigned {
  kLedgerPrecheck, kCompletionWait, kReadbackSelectLayout, kExportState,
  kTakeAppendsReframe, kCompleteValidateLedger, kUnbindAuthority,
  kPublishRetire, kObserveAfterEndpoint, kCount
};
inline constexpr unsigned phase_count = static_cast<unsigned>(Phase::kCount);
inline constexpr std::array<const char *, phase_count> names{
  "hyle/finish/ledger_precheck", "hyle/finish/completion_wait",
  "hyle/finish/readback_select_layout", "hyle/finish/export_state",
  "hyle/finish/take_appends_reframe", "hyle/finish/complete_validate_ledger",
  "hyle/finish/unbind_authority", "hyle/finish/publish_retire",
  "hyle/finish/observe_after_endpoint"};
struct Metadata final {
  std::uint64_t sequence = 0, role = 0, target_rows = 0, requests = 0;
  std::uint64_t context = 0, frontier = 0, lag = 0, recorded = 0, reused = 0;
};
struct Record final {
  Metadata metadata;
  std::array<std::int64_t, phase_count> begin{}, end{};
  std::uint64_t seen = 0, accepted_inputs = 0, published_length = 0;
  std::int64_t pending = -1;
  bool head_published = false, ledger_committed = false;
  bool before_abort = false, endpoint_reached = false, normal_return = false;
};
inline constexpr std::size_t capacity = 256;
inline std::array<Record, capacity> records{};
inline std::size_t used = 0, overflow = 0;
inline std::uint64_t range_starts = 0;
inline std::int64_t tick() noexcept {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count();
}
class Episode final {
  Record *record_ = nullptr;
  unsigned current_ = phase_count;
  nvtxRangeId_t range_ = 0;
  bool active_ = false;
 public:
  explicit Episode(Metadata metadata) noexcept {
    if (used == capacity) { ++overflow; return; }
    record_ = &records[used++]; record_->metadata = metadata;
    enter(Phase::kLedgerPrecheck);
  }
  Episode(const Episode &) = delete;
  Episode &operator=(const Episode &) = delete;
  ~Episode() { stop(); }
  void stop() noexcept {
    if (!record_ || !active_) return;
    record_->end[current_] = tick();
    nvtxDomainRangeEnd(logical_trace::domain, range_);
    active_ = false; current_ = phase_count;
  }
  void enter(Phase phase) noexcept {
    if (!record_) return;
    stop(); current_ = static_cast<unsigned>(phase);
    nvtxEventAttributes_t event{};
    event.version = NVTX_VERSION; event.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
    event.messageType = NVTX_MESSAGE_TYPE_ASCII; event.message.ascii = names[current_];
    event.payloadType = NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;
    event.payload.ullValue = record_->metadata.sequence;
    range_ = nvtxDomainRangeStartEx(logical_trace::domain, &event); active_ = true;
    record_->begin[current_] = tick(); record_->seen |= std::uint64_t{1} << current_;
    ++range_starts;
  }
  void selected(std::size_t accepted) noexcept {
    if (record_) record_->accepted_inputs = static_cast<std::uint64_t>(accepted);
  }
  void published(std::size_t length, std::int32_t pending, bool ledger) noexcept {
    if (!record_) return;
    record_->head_published = true; record_->published_length = static_cast<std::uint64_t>(length);
    record_->pending = pending; record_->ledger_committed = ledger;
  }
  void before_abort() noexcept { stop(); if (record_) record_->before_abort = true; }
  void end_publish() noexcept { stop(); }
  void after_endpoint() noexcept {
    if (record_) record_->endpoint_reached = true;
    enter(Phase::kObserveAfterEndpoint);
  }
  void returned() noexcept { stop(); if (record_) record_->normal_return = true; }
};
inline void dump() noexcept {
  std::fprintf(stderr, "FINISH_POD records=%zu capacity=%zu overflow=%zu range_starts=%llu record_bytes=%zu\n",
      used, capacity, overflow, static_cast<unsigned long long>(range_starts), sizeof(Record));
  for (std::size_t i = 0; i < used; ++i) {
    const auto &r = records[i]; const auto &m = r.metadata;
    std::fprintf(stderr,
        "FINISH_META seq=%llu role=%llu target_T=%llu R=%llu context=%llu frontier=%llu lag=%llu record=%llu reuse=%llu accepted_inputs=%llu published_length=%llu pending=%lld head_published=%u ledger_committed=%u before_abort=%u endpoint=%u normal_return=%u seen=%llu\n",
        static_cast<unsigned long long>(m.sequence), static_cast<unsigned long long>(m.role),
        static_cast<unsigned long long>(m.target_rows), static_cast<unsigned long long>(m.requests),
        static_cast<unsigned long long>(m.context), static_cast<unsigned long long>(m.frontier),
        static_cast<unsigned long long>(m.lag), static_cast<unsigned long long>(m.recorded),
        static_cast<unsigned long long>(m.reused), static_cast<unsigned long long>(r.accepted_inputs),
        static_cast<unsigned long long>(r.published_length), static_cast<long long>(r.pending),
        static_cast<unsigned>(r.head_published), static_cast<unsigned>(r.ledger_committed),
        static_cast<unsigned>(r.before_abort), static_cast<unsigned>(r.endpoint_reached),
        static_cast<unsigned>(r.normal_return), static_cast<unsigned long long>(r.seen));
    for (unsigned phase = 0; phase < phase_count; ++phase)
      if ((r.seen & (std::uint64_t{1} << phase)) != 0)
        std::fprintf(stderr, "FINISH_PHASE seq=%llu phase=%s begin_ns=%lld end_ns=%lld duration_ns=%lld\n",
            static_cast<unsigned long long>(m.sequence), names[phase],
            static_cast<long long>(r.begin[phase]), static_cast<long long>(r.end[phase]),
            static_cast<long long>(r.end[phase] - r.begin[phase]));
  }
}
}
