"""Prepare exact private source/commands only. No compiler, profiler or model."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/mtp-logical-call-trace-20261025'
SEED = R / '.scratch/mtp-native-seed-candidate-20261025'

def read(path):
    return json.loads(path.read_bytes())

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')

def pin(path):
    return {'path': path.relative_to(R).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

source = W / 'source'
source.mkdir(exist_ok=False)
for path in (OLD / 'hyle/source').rglob('*'):
    if path.is_file():
        target = source / path.relative_to(OLD / 'hyle/source')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
shutil.copyfile(OLD / 'logical_trace.h', W / 'logical_trace.h')
main = source / 'engine/models/qwen35/main.cc'
before_bytes = main.read_bytes()
(W / 'before-main.cc').write_bytes(before_bytes)
original = before_bytes.decode('utf-8')
start = original.index('  template<class Select, class Complete, class Observe>\r\n')
end = original.index('  template<class Select, class Observe>\r\n', start)
body = original[start:end]
changes = []

def replace(old, new):
    global body
    old = old.replace('\n', '\r\n'); new = new.replace('\n', '\r\n')
    assert body.count(old) == 1, old
    body = body.replace(old, new)
    changes.append((old, new))

replace('    const auto capture_recorded = step.capture_recorded, capture_reused = step.capture_reused;\n',
    '    const auto capture_recorded = step.capture_recorded, capture_reused = step.capture_reused;\n'
    '    finish_trace::Episode trace_finish(finish_trace::Metadata{\n'
    '        .sequence = logical_trace::sequence, .role = static_cast<std::uint64_t>(phase.family->role),\n'
    '        .target_rows = tokens, .requests = outputs.size(), .context = step.members.front().base->length,\n'
    '        .frontier = step.members.front().base->draft ? step.members.front().base->draft->frontier : 0,\n'
    '        .lag = step.members.front().base->draft ? step.members.front().base->draft->lag : 0,\n'
    '        .recorded = capture_recorded, .reused = capture_reused});\n')
replace('      check(step.completion.wait()); step.completion = {};\n',
    '      trace_finish.enter(finish_trace::Phase::kCompletionWait);\n'
    '      check(step.completion.wait()); step.completion = {};\n'
    '      trace_finish.enter(finish_trace::Phase::kReadbackSelectLayout);\n')
replace("      // Export every participant's ordinary outputs before taking ANY append:\n",
    '      trace_finish.selected(step.members.front().accepted_tokens);\n'
    '      trace_finish.enter(finish_trace::Phase::kExportState);\n'
    "      // Export every participant's ordinary outputs before taking ANY append:\n")
replace('      for (std::size_t layer = 0; layer < page_inventory.keys.size(); ++layer) {\n',
    '      trace_finish.enter(finish_trace::Phase::kTakeAppendsReframe);\n'
    '      for (std::size_t layer = 0; layer < page_inventory.keys.size(); ++layer) {\n')
replace('      // Caller-supplied completion is confined to this unpublished episode.\n',
    '      trace_finish.enter(finish_trace::Phase::kCompleteValidateLedger);\n'
    '      // Caller-supplied completion is confined to this unpublished episode.\n')
replace('      check(run.unbind(phase.state_resource_ports));\n',
    '      trace_finish.enter(finish_trace::Phase::kUnbindAuthority);\n'
    '      check(run.unbind(phase.state_resource_ports));\n')
replace('      // All fallible native/export/metadata work is complete. The head swaps\n',
    '      trace_finish.enter(finish_trace::Phase::kPublishRetire);\n'
    '      // All fallible native/export/metadata work is complete. The head swaps\n')
replace('      return_readback.admission = std::exchange(step.candidate_admission, nullptr);\n',
    '      trace_finish.published(step.members.front().session->head->length, next_ids.front(),\n'
    '          step.members.front().commit_record && step.members.front().commit_record->committed);\n'
    '      return_readback.admission = std::exchange(step.candidate_admission, nullptr);\n')
replace('    } catch (...) { abort_episode().IgnoreError(); throw; }\n    const auto finished = Clock::now();\n',
    '    } catch (...) { trace_finish.before_abort(); abort_episode().IgnoreError(); throw; }\n'
    '    trace_finish.end_publish();\n'
    '    const auto finished = Clock::now();\n')
replace('    trace_wait.finish(); logical_trace::episode.finish();\n',
    '    trace_wait.finish(); logical_trace::episode.finish();\n'
    '    trace_finish.after_endpoint();\n')
replace('      observe(j, completed);\n    }\n  }\n',
    '      observe(j, completed);\n    }\n'
    '    trace_finish.returned();\n  }\n')
restored = body
for old, new in reversed(changes):
    assert restored.count(new) == 1
    restored = restored.replace(new, old)
assert restored == original[start:end]
modified = original[:start] + body + original[end:]
main.write_bytes(modified.encode('utf-8'))
(W / 'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),
    modified.splitlines(True), fromfile='existing-logical-trace/main.cc', tofile='finish-phase/main.cc')),
    encoding='utf-8', newline='')
(W / 'consumer.cc').write_text('#include "logical_trace.h"\n#include "finish_trace.h"\n'
    '#include "source/engine/models/qwen35/main.cc"\n'
    'int main(int argc,char **argv){logical_trace::initialize();const int code=qwen35::run(argc,argv);'
    'logical_trace::episode.finish();logical_trace::dump();finish_trace::dump();return code;}\n', encoding='utf-8')

compile_original = read(OLD / 'hyle/compile/command.json')['command']
compile_command = []
for word in compile_original:
    word = word.replace(str(OLD / 'hyle/source'), str(source))
    word = word.replace(str(OLD / 'hyle/consumer.cc'), str(W / 'consumer.cc'))
    word = word.replace(str(OLD / 'hyle/compile'), str(W / 'compile'))
    compile_command.append(word)
link_original = read(SEED / 'link2/command.json')['command']
old_app = str(R / '.scratch/mtp-performance-convergence-20261025/baseline/compile/unit.obj')
assert sum(word.lower() == old_app.lower() for word in link_original) == 1
link_command = [str(W / 'compile/unit.obj') if word.lower() == old_app.lower() else word
    for word in link_original
    if not word.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))]
link_command.extend(['/OUT:' + str(W / 'link/consumer.exe'), '/IMPLIB:' + str(W / 'link/consumer.lib')])
original_profile = read(OLD / 'plan.json')['commands'][0]
profile = []
for word in original_profile['command']:
    word = word.replace(str(OLD / 'hyle/trace1'), str(W / 'trace1'))
    word = word.replace(str(OLD / 'hyle/link/consumer.exe'), str(W / 'link/consumer.exe'))
    profile.append(word)
absolute_inputs = [Path(word) for word in link_command[1:]
    if word.lower().endswith(('.obj', '.lib')) and Path(word).is_absolute()
    and not word.lower() == str(W / 'compile/unit.obj').lower()]
assert all(path.is_file() for path in absolute_inputs)
key_objects = [path for path in absolute_inputs if any(part in str(path).replace('\\', '/')
    for part in ['/mtp-native-seed-candidate-20261025/', '/current-cuda/product-', '/current-cuda/report/'])]
source_files = [path for path in source.rglob('*') if path.is_file()]
save(W / 'source-pins.json', [pin(path) for path in [*sorted(source_files), W / 'before-main.cc',
    W / 'logical_trace.h', W / 'finish_trace.h', W / 'consumer.cc', W / 'source.patch']])
save(W / 'source-checks.json', {
    'status': 'SOURCE_ONLY_NOT_COMPILED', 'scope': 'Private phase markers and fixed POD only',
    'function_changes': len(changes), 'whole_main_reverse_instrumentation_equal': restored == original[start:end],
    'outside_finish_function_byte_equal': modified[:start] == original[:start] and modified[start+len(body):] == original[end:],
    'original_Clock_now_statements_preserved': original.count('Clock::now()') == modified.count('Clock::now()'),
    'model_math_or_submission_or_sampling_statement_changed': False,
    'original_normal_reporting_code_byte_equal_after_marker_removal': True,
    'native_compilation_or_execution_claimed': False})
save(W / 'plan.json', {
    'status': 'PRIVATE_SOURCE_AND_COMMANDS_READY_NOT_COMPILED_NOT_RUN',
    'scope': 'One possible Hyle original K1 two-turn finish-phase diagnostic, not TPS; no peer or new matrix.',
    'before': pin(OLD / 'hyle/source/engine/models/qwen35/main.cc'),
    'after': pin(main), 'helper': pin(W / 'finish_trace.h'),
    'source_checks': pin(W / 'source-checks.json'),
    'frozen_self_written_files': len(source_files),
    'frozen_self_written_bytes': sum(path.stat().st_size for path in source_files),
    'commands': {'compile': compile_command, 'link': link_command, 'profile_if_later_authorized': profile},
    'commands_are_not_executed_by_this_script': True,
    'retained_link_manifest': pin(SEED / 'link2/command.json'),
    'retained_absolute_link_inputs_existing': len(absolute_inputs),
    'retained_key_objects': [pin(path) for path in key_objects],
    'new_compiler_TUs_if_later_authorized': 1, 'new_CUDA_TUs': 0, 'new_report_TUs': 0,
    'runtime': original_profile['runtime'],
    'runtime_cpu_companion_source': pin(SEED / 'link2/hyle_ggml_cpu_gdn_scale_v3.dll'),
    'bounded_recording': {'capacity_records': 256, 'phases_per_record': 9,
        'expected_original_episodes': 68, 'expected_prefills': 2, 'expected_decode_episodes': 66,
        'expected_phase_ranges': 612, 'expected_overflow': 0,
        'storage': 'One zero-initialized fixed global POD array; scalar stack recorder; no hot vector/string/allocation/print/synchronize.',
        'dump': 'Explicit call after qwen35::run returns, after original stdout/stderr normal path; raw nanoseconds and metadata only.'},
    'work_comparison': {'baseline_report': pin(R / '.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/consumer-result.json'),
        'reuse_normalization': pin(OLD / 'analyze.py'),
        'required': 'All original non-time fields, full128 IDs, dispatch/batches/rounds, 66 verifies/132 rows, 124 decode draft rows/434 total, 60 accepts/6 rejects, 2prefills309target/310draft, all ledger/pending/RNG/frontier facts; no changed acceptance or forced prefix.',
        'diagnostic_fields_only': 'New FINISH_* stderr lines; original report output order/text/statements unchanged.'},
    'GPU_activity_association': {
        'submission_origin': 'Actual runtime/driver API same globalTid contained within a phase, correlationId to kernel/copy/memset where available. Do not require resulting GPU work to end inside the CPU phase.',
        'execution_interval': 'Separately clip actual GPU timestamps to each CPU NVTX phase and take per-process interval unions. Cross-phase work retains originating API phase and actual execution phase; missing/ambiguous correlations remain unknown.',
        'clock_domains': 'POD steady_clock deltas and Nsight timestamps stay separate; join seq/phase, never subtract epochs.',
        'no_original_graph_lineage': True,
        'post_wait': 'Readback/state export/append/unbind may enqueue or wait for new GPU work. Never label the entire region pure host.'},
    'failure_handling': 'Original failures/abort unchanged; recorder closes phase before abort and marks unsuccessful, preserving late observer failures after a committed Head. Overflow or incomplete stages invalidate diagnostic completeness, never trigger automatic retry.',
    'source_level_findings': 'K1 reports auxiliary repair/restore0; complete(step) remains original callback. Existing source does not prove expensive hidden work can be removed. Repeated short owners/tail vectors exist, but no new hotspot is asserted without phase cost.',
    'compiled_TUs': 0, 'GPU_processes': 0, 'HTTP': 0, 'SDK_builds': 0})
print(json.dumps({'state': 'SOURCE_ONLY_READY', 'main': pin(main),
    'helper': pin(W / 'finish_trace.h'), 'source_only_checks': read(W / 'source-checks.json'),
    'planned_new_TUs': 1, 'GPU_processes': 0}))
