"""Read the single retained SQLite/report. No build/run/capture or new native work."""
from pathlib import Path
from collections import Counter, defaultdict
import ast
import hashlib
import json
import re
import sqlite3
import statistics

W = Path(__file__).resolve().parent
R = W.parents[1]
F = W / 'trace1'

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    return {'path': path.relative_to(R).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def union(intervals):
    joined = []
    for a, b in sorted(intervals):
        if b <= a:
            continue
        if joined and a <= joined[-1][1]:
            joined[-1][1] = max(joined[-1][1], b)
        else:
            joined.append([a, b])
    return sum(b - a for a, b in joined)

def stats(values):
    return {'count': len(values), 'total_ms': sum(values) / 1e6,
        'median_ms': statistics.median(values) / 1e6,
        'min_ms': min(values) / 1e6, 'max_ms': max(values) / 1e6} if values else {'count': 0}

def report(path):
    text = path.read_text(encoding='utf-8')
    return json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0]

prior_analysis = R / '.scratch/mtp-logical-call-trace-20261025/analyze.py'
tree = ast.parse(prior_analysis.read_text(encoding='utf-8'))
namespace = {}
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
    and node.name in {'normalize', 'differences'}], type_ignores=[]), str(prior_analysis), 'exec'), namespace)
old_raw_path = R / '.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/stdout.log'
old = report(old_raw_path)
new = report(F / 'native-stdout.log')
differences = namespace['differences'](namespace['normalize'](old), namespace['normalize'](new))

def at(value, path):
    try:
        for part in path.split('/')[1:]:
            value = value[int(part)] if isinstance(value, list) else value[part]
        return value
    except (KeyError, ValueError, IndexError):
        return '<missing>'

work = {'status': 'PASS' if not differences else 'DIFFERENCES_REQUIRE_EXPLANATION',
    'baseline_actual_raw_stdout': pin(old_raw_path), 'current_actual_raw_stdout': pin(F / 'native-stdout.log'),
    'normalization_source': pin(prior_analysis), 'metadata_fields_excluded_beyond_existing_time_rules': [],
    'differences': [{'path': path, 'old': at(old, path), 'new': at(new, path)} for path in differences],
    'facts': {key: new[key] for key in ['generated_tokens', 'generated_decode_tokens', 'actual_graph_calls',
        'prefill_graph_calls', 'decode_graph_calls', 'prefill_target_rows', 'verified_target_rows',
        'actual_target_rows', 'prefill_draft_rows', 'draft_rows', 'actual_draft_rows',
        'agreements', 'consumed_drafts', 'cache_metadata_requested_bytes',
        'cache_live_requested_bytes', 'cache_peak_requested_bytes']}}
save(W / 'work-comparison.json', work)

connection = sqlite3.connect('file:' + (F / 'trace.sqlite').resolve().as_posix() + '?mode=ro', uri=True)
connection.row_factory = sqlite3.Row
connection.execute('PRAGMA query_only=ON')
tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
SQL = {
    'nvtx': 'SELECT n.start,n.end,n.globalTid,n.uint64Value,COALESCE(n.text,s.value) AS label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL ORDER BY n.start',
    'runtime': 'SELECT r.*,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start',
    'kernel': 'SELECT start,end,correlationId,graphId,streamId FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start',
    'copy': 'SELECT start,end,correlationId FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start',
    'memset': 'SELECT start,end,correlationId FROM CUPTI_ACTIVITY_KIND_MEMSET ORDER BY start'}
ranges = [dict(row) for row in connection.execute(SQL['nvtx']) if row['label'] and row['label'].startswith('hyle/')]
for item in ranges:
    item['seq'] = item['uint64Value']
    item['meta'] = {key: int(value) for key, value in re.findall(r'(\w+)=(\d+)', item['label'])}
roots = {item['seq']: item for item in ranges if item['label'].startswith('hyle/episode')}
decode = {seq for seq, item in roots.items() if item['meta']['target_T'] == 2}
phases = [item for item in ranges if item['label'].startswith('hyle/finish/')]
origin_ranges = [item for item in ranges if item['label'].startswith('hyle/finish/') or item['label'] in
    {'hyle/prepare_replay', 'hyle/prepare', 'hyle/submit', 'hyle/wait_publish'}]
apis = [dict(row) for row in connection.execute(SQL['runtime'])]
api_by_corr = defaultdict(list)
for item in apis:
    candidates = [phase for phase in origin_ranges if phase['globalTid'] == item['globalTid']
        and phase['start'] <= item['start'] and item['end'] <= phase['end']]
    closest = min(candidates, key=lambda phase: phase['end'] - phase['start']) if candidates else None
    item['origin'] = (closest['seq'], closest['label']) if closest else None
    api_by_corr[item['correlationId']].append(item)
gpu = []
for name, table in [('kernel', 'CUPTI_ACTIVITY_KIND_KERNEL'), ('copy', 'CUPTI_ACTIVITY_KIND_MEMCPY'),
                    ('memset', 'CUPTI_ACTIVITY_KIND_MEMSET')]:
    if table in tables:
        for row in connection.execute(SQL[name]):
            item = dict(row); item['kind'] = name
            associated = {api['origin'] for api in api_by_corr[item['correlationId']] if api['origin']}
            item['origin'] = next(iter(associated)) if len(associated) == 1 else None
            gpu.append(item)
gpu.sort(key=lambda item: item['start'])
phase_rows = []
for phase in phases:
    activity = [item for item in gpu if item['start'] < phase['end'] and phase['start'] < item['end']]
    linked = [item for item in gpu if item['origin'] == (phase['seq'], phase['label'])]
    local_apis = [item for item in apis if item['origin'] == (phase['seq'], phase['label'])]
    execution = union([(max(phase['start'], item['start']), min(phase['end'], item['end'])) for item in activity])
    phase_rows.append({'seq': phase['seq'], 'phase': phase['label'],
        'decode': phase['seq'] in decode, 'start_ns': phase['start'], 'end_ns': phase['end'],
        'wall_ns': phase['end'] - phase['start'], 'execution_gpu_union_ns': execution,
        'wall_without_observed_gpu_ns': phase['end'] - phase['start'] - execution,
        'gpu_execution_kinds': dict(Counter(item['kind'] for item in activity)),
        'gpu_origin_kinds': dict(Counter(item['kind'] for item in linked)),
        'gpu_origin_union_ns': union([(item['start'], item['end']) for item in linked]),
        'origin_work_crossing_cpu_phase': sum(item['end'] > phase['end'] or item['start'] < phase['start'] for item in linked),
        'api': {name: {'calls': len(items), 'total_ns': sum(item['end'] - item['start'] for item in items),
            'return_values': dict(Counter(str(item.get('returnValue', '<missing>')) for item in items))}
            for name in sorted({item['api'] for item in local_apis})
            for items in [[item for item in local_apis if item['api'] == name]]}})
grouped = defaultdict(list)
for item in phase_rows:
    if item['decode']:
        grouped[item['phase']].append(item)
groups = {}
for name, items in grouped.items():
    api_counts = Counter()
    for item in items:
        api_counts.update({key: value['calls'] for key, value in item['api'].items()})
    groups[name] = {'wall': stats([item['wall_ns'] for item in items]),
        'execution_gpu_union': stats([item['execution_gpu_union_ns'] for item in items]),
        'wall_without_observed_gpu': stats([item['wall_without_observed_gpu_ns'] for item in items]),
        'origin_gpu_union': stats([item['gpu_origin_union_ns'] for item in items]),
        'origin_work_crossing_cpu_phase': sum(item['origin_work_crossing_cpu_phase'] for item in items),
        'api_counts': dict(api_counts),
        'largest3_wall': sorted(items, key=lambda item: -item['wall_ns'])[:3]}

wait_rows = []
for phase in phases:
    if phase['label'] != 'hyle/finish/completion_wait' or phase['seq'] not in decode:
        continue
    sync = [api for api in apis if api['origin'] == (phase['seq'], phase['label'])
        and 'EventSynchronize' in api['api']]
    for api in sync:
        visible = [item for item in gpu if roots[phase['seq']]['start'] <= item['start'] and item['end'] <= api['end']]
        last = max(visible, key=lambda item: item['end']) if visible else None
        wait_rows.append({'seq': phase['seq'], 'api': api['api'], 'api_start_ns': api['start'],
            'api_end_ns': api['end'], 'api_duration_ns': api['end'] - api['start'],
            'returnValue': api.get('returnValue', '<missing>'),
            'last_observed_gpu_end_ns': last['end'] if last else None,
            'last_observed_gpu_kind': last['kind'] if last else None,
            'gap_to_api_return_ns': api['end'] - last['end'] if last else None})

stderr = (F / 'native-stderr.log').read_text(encoding='utf-8')
pod_summary = re.findall(r'^FINISH_POD (.*)$', stderr, re.MULTILINE)
pod_meta = [{key: int(value) for key, value in re.findall(r'(\w+)=(-?\d+)', line)}
    for line in re.findall(r'^FINISH_META (.*)$', stderr, re.MULTILINE)]
pod_phases = re.findall(r'^FINISH_PHASE .*duration_ns=\d+$', stderr, re.MULTILINE)
phase_sets = defaultdict(set)
for phase in phases:
    phase_sets[phase['seq']].add(phase['label'])
diagnostics = [dict(row) for row in connection.execute('SELECT * FROM DIAGNOSTIC_EVENT')]
strings = {row[0]: row[1] for row in connection.execute('SELECT id,value FROM StringIds')}
for item in diagnostics:
    for key in ('text', 'message', 'textId', 'messageId'):
        if key in item and isinstance(item[key], int) and item[key] in strings:
            item[key + '_resolved'] = strings[item[key]]

# Close the original outer episode using its nonoverlapping top-level phases.
# prepare_replay remains a child of prepare, never another additive phase.
prepared = [dict(zip(['T', 'visible', 'recorded', 'reused'], map(int, item))) for item in re.findall(
    r'^prepared T=(\d+) visible=(\d+).*capture_recorded=(\d+) capture_reused=(\d+)$', stderr, re.MULTILINE)]
assert len(prepared) == 68
ordered_roots = sorted(roots.values(), key=lambda item: item['start'])
prep_by_seq = {root['seq']: values for root, values in zip(ordered_roots, prepared)}
assert all(root['meta']['target_T'] == prep_by_seq[root['seq']]['T'] for root in ordered_roots)
episodes = []
role_gpu = defaultdict(list)
for root in ordered_roots:
    seq = root['seq']
    child = {item['label']: item for item in ranges if item is not root and item['seq'] == seq
        and item['label'] in {'hyle/prepare', 'hyle/prepare_replay', 'hyle/submit', 'hyle/wait_publish'}}
    own = [item for item in gpu if item['start'] < root['end'] and root['start'] < item['end']]
    own_api = [item for item in apis if item['globalTid'] == root['globalTid']
        and root['start'] <= item['start'] and item['end'] <= root['end']]
    special = [item for item in own_api if any(name in item['api']
        for name in ['GraphInstantiate', 'GraphExecUpdate', 'StreamBeginCapture', 'StreamEndCapture'])]
    native = {name: {'calls': len(items), 'total_ms': sum(item['end']-item['start'] for item in items)/1e6,
        'return_values': dict(Counter(str(item.get('returnValue', '<missing>')) for item in items))}
        for name in sorted({item['api'] for item in special})
        for items in [[item for item in special if item['api'] == name]]}
    has_instantiate = any('GraphInstantiate' in item['api'] for item in special)
    capture = prep_by_seq[seq]
    classification = 'instantiate' if has_instantiate else 'record_no_instantiate' if capture['recorded'] else 'no_record'
    phase_wall = {key: value['end']-value['start'] for key, value in child.items()}
    top_level = [value for key, value in child.items() if key != 'hyle/prepare_replay']
    assert child['hyle/prepare']['start'] <= child['hyle/prepare_replay']['start'] <= child['hyle/prepare_replay']['end'] <= child['hyle/prepare']['end']
    top_sorted = sorted(top_level, key=lambda item: item['start'])
    assert all(a['end'] <= b['start'] for a,b in zip(top_sorted,top_sorted[1:]))
    phase_activity = {}
    for label,span in child.items():
        active = union([(max(span['start'],item['start']),min(span['end'],item['end'])) for item in own
            if item['start'] < span['end'] and span['start'] < item['end']])
        phase_activity[label] = {'wall_ns': span['end']-span['start'], 'execution_gpu_union_ns': active,
            'wall_without_observed_gpu_ns': span['end']-span['start']-active}
    assigned = []
    graph_calls = []
    kernels_by_corr = defaultdict(list)
    for item in own:
        if item['kind'] == 'kernel' and item.get('graphId') not in (None, 0):
            kernels_by_corr[item['correlationId']].append(item)
    for correlation, kernels in kernels_by_corr.items():
        launch = [item for item in own_api if item['correlationId'] == correlation and 'GraphLaunch' in item['api']]
        count = len(kernels)
        role = 'target' if count == 738 else 'draft' if count in (37, 41) else 'unknown'
        if len(launch) != 1:
            role = 'unknown'
        events = [item for item in own if item['correlationId'] == correlation]
        active = union([(max(root['start'], item['start']), min(root['end'], item['end'])) for item in events])
        graph_calls.append({'role': role, 'correlationId': correlation, 'captured_kernel_count': count,
            'actual_runtime_GraphLaunch_matches': len(launch), 'gpu_union_ns': active})
        if role != 'unknown':
            assigned.extend(events)
            if seq in decode:
                rows = root['meta']['target_T' if role == 'target' else 'draft_T']
                role_gpu[role + '/T' + str(rows) + '/captured'].append(active)
    busy = union([(max(root['start'], item['start']), min(root['end'], item['end'])) for item in own])
    assigned_busy = union([(max(root['start'], item['start']), min(root['end'], item['end'])) for item in assigned])
    episodes.append({'seq': seq, 'decode': seq in decode, 'meta': root['meta'],
        'capture': capture, 'classification': classification,
        'wall_ns': root['end']-root['start'], 'gpu_execution_union_ns': busy,
        'wall_without_observed_gpu_ns': root['end']-root['start']-busy,
        'outer_phase_wall_ns': phase_wall, 'outer_phase_activity': phase_activity,
        'outer_unlabelled_ns': root['end']-root['start']-union([(item['start'], item['end']) for item in top_level]),
        'native_capture_API': native, 'actual_captured_graphs': graph_calls,
        'gpu_not_assigned_to_captured_target_draft_union_ns': busy-assigned_busy,
        'origin_unknown_gpu_event_kinds': dict(Counter(item['kind'] for item in own if item['origin'] is None))})
classes = {}
decode_episodes = [item for item in episodes if item['decode']]
for name in sorted({item['classification'] for item in decode_episodes}):
    rows = [item for item in decode_episodes if item['classification'] == name]
    classes[name] = {'count': len(rows), 'seq': [item['seq'] for item in rows],
        'wall': stats([item['wall_ns'] for item in rows]),
        'gpu_execution_union': stats([item['gpu_execution_union_ns'] for item in rows]),
        'wall_without_observed_gpu': stats([item['wall_without_observed_gpu_ns'] for item in rows]),
        'outer_phase': {phase: stats([item['outer_phase_wall_ns'][phase] for item in rows])
            for phase in ['hyle/prepare', 'hyle/prepare_replay', 'hyle/submit', 'hyle/wait_publish']}}
outer = {phase: stats([item['outer_phase_wall_ns'][phase] for item in decode_episodes])
    for phase in ['hyle/prepare', 'hyle/prepare_replay', 'hyle/submit', 'hyle/wait_publish']}
outer_activity = {phase: {field: stats([item['outer_phase_activity'][phase][field] for item in decode_episodes])
    for field in ['wall_ns','execution_gpu_union_ns','wall_without_observed_gpu_ns']}
    for phase in ['hyle/prepare','hyle/prepare_replay','hyle/submit','hyle/wait_publish']}
api_total = defaultdict(lambda: {'calls': 0, 'total_ms': 0.0, 'return_values': Counter()})
for episode in decode_episodes:
    for name, values in episode['native_capture_API'].items():
        api_total[name]['calls'] += values['calls']
        api_total[name]['total_ms'] += values['total_ms']
        api_total[name]['return_values'].update(values['return_values'])
caller_gaps = []
for previous, following in zip(ordered_roots, ordered_roots[1:]):
    if previous['seq'] not in decode:
        continue
    left, right = previous['end'], following['start']
    observers = [item for item in phases if item['seq'] == previous['seq']
        and item['label'] == 'hyle/finish/observe_after_endpoint']
    observe = union([(max(left,item['start']), min(right,item['end'])) for item in observers])
    active = [item for item in gpu if item['start'] < right and left < item['end']]
    caller_gaps.append({'after_seq': previous['seq'], 'next_seq': following['seq'],
        'next_target_T': following['meta']['target_T'], 'span_ns': right-left,
        'observed_finish_observer_ns': observe, 'other_caller_gap_ns': right-left-observe,
        'gpu_execution_union_ns': union([(max(left,item['start']),min(right,item['end'])) for item in active]),
        'scope': 'Original logical episode endpoint to next prepare marker; includes actual caller progress/logging/turn handling and possible work before prepare marker, not CPU-utilization.'})
peer_old = json.loads((R/'docs/evidence/performance/mtp-logical-call-attribution-2026-10-25.json').read_bytes())['analysis']['arms']['peer']
role_by_record = defaultdict(list)
for episode in decode_episodes:
    for graph in episode['actual_captured_graphs']:
        if graph['role'] == 'unknown': continue
        rows = episode['meta']['target_T' if graph['role'] == 'target' else 'draft_T']
        label = graph['role'] + '/T' + str(rows) + ('/record_present' if episode['capture']['recorded'] else '/no_record')
        role_by_record[label].append(graph['gpu_union_ns'])
role_comparison = {'hyle_current_by_episode_record': {key: stats(value) for key,value in role_by_record.items()},
    'hyle_current_profile': {key: stats(value) for key,value in role_gpu.items()},
    'peer_prior_own_profile_same_T_role': {key: {'calls': item['actual_calls'], 'gpu_active': item['gpu_active']}
        for key,item in peer_old['by_role_T'].items()},
    'limit': 'Descriptive same-T/role only. Different context/precision/capture mix and CPU completion boundaries; no Hyle-versus-peer episode subtraction or formalTPS.'}
out = {'status': 'NVTX_COMPLETE_PARTIAL_POD_STREAM', 'scope': 'One Hyle profile only, no TPS or equal-peer causal subtraction.',
    'work': work, 'SQL': SQL,
    'table_columns': {name: [dict(row) for row in connection.execute('PRAGMA table_info(' + name + ')')]
        for name in ['NVTX_EVENTS', 'CUPTI_ACTIVITY_KIND_RUNTIME', 'CUPTI_ACTIVITY_KIND_KERNEL',
                     'CUPTI_ACTIVITY_KIND_MEMCPY', 'CUPTI_ACTIVITY_KIND_DRIVER'] if name in tables},
    'driver_table_present': 'CUPTI_ACTIVITY_KIND_DRIVER' in tables,
    'coverage': {'episodes': len(roots), 'decode_episodes': len(decode), 'phases': len(phases),
        'phase_counts': dict(Counter(item['label'] for item in phases)),
        'every_episode_has_9_completed_NVTX_ranges': all(len(value) == 9 for value in phase_sets.values()),
        'POD_summary': pod_summary, 'POD_metadata_rows_preserved': len(pod_meta),
        'POD_preserved_metadata_normal_return_all_true': all(item['normal_return'] == 1 for item in pod_meta),
        'POD_preserved_metadata_seen_all511': all(item['seen'] == 511 for item in pod_meta),
        'POD_phase_rows_preserved': len(pod_phases),
        'POD_remaining_metadata_flags': 'unknown: Nsight ProcessStreams stderr ends mid-seq8; original temporary stream removed by tool. No recapture.',
        'consumer_report_complete_and_work_comparison': work['status']},
    'decode_phase': groups, 'phase_rows': phase_rows,
    'same_trace_outer_episode': {'wall': stats([item['wall_ns'] for item in decode_episodes]),
        'gpu_execution_union': stats([item['gpu_execution_union_ns'] for item in decode_episodes]),
        'wall_without_observed_gpu': stats([item['wall_without_observed_gpu_ns'] for item in decode_episodes]),
        'outer_phase': outer, 'outer_phase_activity': outer_activity, 'outer_unlabelled': stats([item['outer_unlabelled_ns'] for item in decode_episodes]),
        'classification': classes, 'native_capture_API': dict(api_total),
        'top3_longest_episodes': sorted(decode_episodes, key=lambda item:-item['wall_ns'])[:3],
        'episodes': episodes,
        'outer_closure_verified': 'prepare/replay nesting and nonoverlap of prepare,submit,wait_publish asserted for all68; replay not additive.',
        'seed_source': 'Actual .scratch/mtp-native-seed-candidate-20261025/graph2/unit.obj + region/unit.obj pinned in plan/ready; two separately merged budget/leases objects, no newcore build.'},
    'caller_dispatch_gap': {'samples': caller_gaps, 'span': stats([item['span_ns'] for item in caller_gaps]),
        'other_caller_gap': stats([item['other_caller_gap_ns'] for item in caller_gaps]),
        'last_episode_to_CLI_end_unknown': True},
    'same_role_T_GPU_comparison': role_comparison,
    'decode_last_visible_GPU_to_wait_return': {'rows': wait_rows,
        'gap': stats([item['gap_to_api_return_ns'] for item in wait_rows if item['gap_to_api_return_ns'] is not None]),
        'scope': 'Same Nsight timestamps, last observed activity within episode ending before EventSynchronize return. Not CUDA event timestamp, polling, scheduler latency or reclaimable CPU time.'},
    'diagnostics': diagnostics,
    'limits': ['POD stream partial; NVTX phase timestamps complete. Record flags not captured cannot be signed as directly observed.',
        'GPU origin classification and execution-intersection unions are different views, not additive.',
        'Unknown API/driver-only correlations remain unknown; no original graph/node lineage proof.',
        'wall minus observed GPU union is not pure CPU utilization or recoverable time.',
        'Profile phase costs cannot be subtracted from formal clean unprofiled1.5423ms episode mean difference.',
        'Frozen app plus two merged lifetime objects is not a new formal32-process comparison.']}
save(W / 'analysis.json', out)
print(json.dumps({'status': out['status'], 'work': work,
    'coverage': out['coverage'], 'top_decode_phase': {key: {name: item[name] for name in
        ['wall', 'execution_gpu_union', 'wall_without_observed_gpu', 'origin_gpu_union', 'api_counts']}
        for key, item in sorted(groups.items(), key=lambda pair: -pair[1]['wall']['total_ms'])},
    'wait_return_gap': out['decode_last_visible_GPU_to_wait_return']['gap']}, indent=2))
