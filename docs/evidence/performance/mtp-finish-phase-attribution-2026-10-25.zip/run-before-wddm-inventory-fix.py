"""Exactly one authorized Hyle profile; no retry or build path."""
from pathlib import Path
import datetime
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
ready = b.read(W / 'ready.json')
plan = b.read(W / 'plan.json')
for item in [ready['image'], ready['app_object'], ready['CPU_companion_hardlink'],
             *ready['source_pins'], *[item['new'] for item in ready['merged_lifetime_replacements']]]:
    assert b.pin(Path(item['path'])) == item, item['path']
runtime = R / plan['runtime']['path']
assert b.pin(runtime)['sha256'] == plan['runtime']['sha256']
env = os.environ.copy()
env['PATH'] = str(W / 'link2') + ';' + b.read(runtime)['PATH']
env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
gpu_command = ['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader']
gpu = subprocess.run(gpu_command, env=env, capture_output=True, text=True,
    creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
assert gpu.returncode == 0, gpu.stderr
gpu_lines = [line for line in gpu.stdout.splitlines() if line.strip()]
assert not gpu_lines, 'GPU has another compute process; profile not started: ' + repr(gpu_lines)
inventory = subprocess.run(['powershell', '-NoProfile', '-Command',
    "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(hyle|peer|consumer|probe|recursive-probe)(\\.exe)?$' } | Select-Object ProcessId,Name,ExecutablePath | ConvertTo-Json -Compress"],
    env=env, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=20)
assert inventory.returncode == 0, inventory.stderr
assert not inventory.stdout.strip(), 'Another named inference process exists; profile not started.'
b.save(W / 'run-start.json', {'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'image': ready['image'], 'plan': b.pin(W / 'plan.json'), 'source_hash_checks': 'PASS',
    'gpu_inventory': {'command': gpu_command, 'exit': gpu.returncode, 'stdout': gpu.stdout, 'stderr': gpu.stderr},
    'named_inference_inventory': {'exit': inventory.returncode, 'stdout': inventory.stdout},
    'scope': 'Exactly one profile-only Hyle original K1 two-turn process, no TPS or automatic retry.'})
command = plan['commands']['profile_if_later_authorized']
assert command.count(str(W / 'link2/consumer.exe')) == 1
assert '--duration=20' in command
b.execute(command, W / 'trace1', env, 120)
b.save(W / 'run-terminal.json', {'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'process': b.read(W / 'trace1/process.json'), 'GPU_released': True,
    'additional_native_processes_started': 0})
