from pathlib import Path
from collections import Counter,defaultdict
import sqlite3,json,re,hashlib,statistics
W=Path(__file__).resolve().parent;R=W.parents[1]
SQL=dict(nvtx="SELECT n.start,n.end,n.globalTid,n.endGlobalTid,n.rangeId,n.uint64Value,COALESCE(n.text,s.value) AS label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NOT NULL ORDER BY n.start",runtime="SELECT r.*,s.value AS api FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start",streams='SELECT f.value,c.value FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def merged(intervals):
 out=[]
 for a,b in sorted(intervals):
  if out and a<=out[-1][1]:out[-1][1]=max(out[-1][1],b)
  else:out.append([a,b])
 return out
def busy(events):return sum(b-a for a,b in merged([(v['start'],v['end'])for v in events]))
def moments(values):return dict(count=len(values),mean_ms=statistics.mean(values)/1e6,median_ms=statistics.median(values)/1e6,min_ms=min(values)/1e6,max_ms=max(values)/1e6)if values else dict(count=0)
def normalize(v):
 if isinstance(v,list):return [normalize(x)for x in v]
 if isinstance(v,dict):return {k:normalize(x)for k,x in v.items()if not any(t in k for t in ['seconds','tokens_per_second','clock_unix','unix_ns','unix_ms'])}
 return v
def report(p,arm):
 text=p.read_text(encoding='utf8');needle='{"source_id"'if arm=='hyle'else'{\n  "scope"';start=text.index(needle);return json.JSONDecoder().raw_decode(text[start:])[0]
def differences(a,b,path=''):
 if type(a)!=type(b):return [path+':type']
 if isinstance(a,dict):return [path+'/'+str(k)+':key'for k in a.keys()^b.keys()]+[x for k in a.keys()&b.keys() for x in differences(a[k],b[k],path+'/'+str(k))]
 if isinstance(a,list):return ([path+':length']if len(a)!=len(b)else[x for i,(v,w)in enumerate(zip(a,b))for x in differences(v,w,path+'/'+str(i))])
 return []if a==b else[path]
out=dict(status='OFFLINE_ANALYSIS_COMPLETE',no_new_run=True,SQL=SQL,scope='One privateNVTX+CUDA profile per arm; noTPS. CPU NVTX interval association uses same globalTid and contained original runtime API; GPU kernel/copy uses original CUPTI correlationId when available. Original graph lineage is not used.',arms={})
for arm,oldfolder in [('hyle','02-hyle_mtp'),('peer','04-peer_mtp')]:
 F=W/arm/'trace1';c=sqlite3.connect('file:'+(F/'trace.sqlite').as_posix()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 names={r[0]:r[1]for r in c.execute('SELECT id,value FROM StringIds')}
 for name,content in c.execute(SQL['streams']):
  if 'stdout_'not in name and'stderr_'not in name:continue
  suffix='stdout'if'stdout_'in name else'stderr';(F/('native-'+suffix+'.log')).write_text(content,encoding='utf8')
 raw=report(F/'native-stdout.log',arm)if arm=='hyle'else read(F/'consumer-result.json')
 prior=report(R/'.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing'/oldfolder/'stdout.log',arm)
 diff=differences(normalize(prior),normalize(raw))
 logical=[dict(r)for r in c.execute(SQL['nvtx'])if r['label']and r['label'].startswith(('hyle/','peer/'))]
 for v in logical:v['meta']={k:int(x)for k,x in re.findall(r'(\w+)=(\d+)',v['label'])}
 roots=[v for v in logical if v['label'].startswith('hyle/episode'if arm=='hyle'else'peer/')]
 runtime=[dict(r)for r in c.execute(SQL['runtime'])];runtime_by_corr=defaultdict(list)
 for v in runtime:runtime_by_corr[v['correlationId']].append(v)
 kernel=[dict(r)for r in c.execute('SELECT start,end,correlationId,graphId,streamId,demangledName FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start')]
 for v in kernel:v['kind']='kernel';v['name']=names[v['demangledName']]
 gpu=kernel[:]
 for table,kind in [('CUPTI_ACTIVITY_KIND_MEMCPY','copy'),('CUPTI_ACTIVITY_KIND_MEMSET','memset')]:
  for r in c.execute('SELECT start,end,correlationId FROM '+table+' ORDER BY start'):
   v=dict(r);v['kind']=kind;gpu.append(v)
 gpu.sort(key=lambda v:v['start']);records=[]
 for root in roots:
  a,b,tid=root['start'],root['end'],root['globalTid'];apis=[v for v in runtime if v['globalTid']==tid and a<=v['start']and v['end']<=b]
  corr={v['correlationId']for v in apis};contained=[v for v in gpu if a<=v['start']and v['end']<=b]
  linked=[v for v in contained if v['correlationId']in corr];unlinked=[v for v in contained if v['correlationId']not in corr]
  k=[v for v in contained if v['kind']=='kernel'];activity=busy(contained);span=b-a
  special=[v for v in apis if any(x in v['api']for x in ['GraphInstantiate','GraphExecUpdate','StreamBeginCapture','StreamEndCapture'])]
  api_groups={name:dict(calls=len(rows),total_ms=sum(v['end']-v['start']for v in rows)/1e6,return_values=dict(Counter(str(v['returnValue'])for v in rows)))for name in sorted(set(v['api']for v in special))for rows in [[v for v in special if v['api']==name]]}
  phase=[]
  if arm=='hyle':
   for p in logical:
    if p is root or p['label'].startswith('hyle/episode')or p['uint64Value']!=root['uint64Value']:continue
    pg=[dict(v,start=max(v['start'],p['start']),end=min(v['end'],p['end']))for v in contained if p['start']<v['end']and v['start']<p['end']];pa=[v for v in special if p['start']<=v['start']and v['end']<=p['end']]
    phase.append(dict(label=p['label'],span_ns=p['end']-p['start'],gpu_contained_union_ns=busy(pg),special_api_counts=dict(Counter(v['api']for v in pa))))
  # Assign captured native launch roles only from actual launch->kernel correlation.
  # HyleclassicK1 has causal draft then target and unique37/41-vs738 signatures.
  groups=defaultdict(list)
  for v in k:
   if v['graphId']:groups[v['correlationId']].append(v)
  captures=[]
  for cid,events in sorted(groups.items(),key=lambda item:min(v['start']for v in item[1])):
   calls=[v for v in apis if v['correlationId']==cid and'GraphLaunch'in v['api']]
   role=('target'if len(events)==738 else'draft'if len(events)in[37,41]else'unknown')if arm=='hyle'else('target'if root['label'].startswith('peer/target')else'draft')
   all_events=[v for v in contained if v['correlationId']==cid]
   captures.append(dict(role=role,correlationId=cid,kernels=len(events),runtime_graph_launch_matches=len(calls),start_ns=min(v['start']for v in events),end_ns=max(v['end']for v in events),kernel_union_ns=busy(events),all_activity_union_ns=busy(all_events),kernel_activity_ns=sum(v['end']-v['start']for v in events)))
  records.append(dict(label=root['label'],meta=root['meta'],payload=root['uint64Value'],start_ns=a,end_ns=b,globalTid=tid,endGlobalTid=root['endGlobalTid'],cpu_range_ns=span,gpu_contained_union_ns=activity,no_gpu_activity_ns=span-activity,kernels=len(k),captured_kernels=sum(bool(v['graphId'])for v in k),eager_kernels=sum(not v['graphId']for v in k),gpu_runtime_correlated=len(linked),gpu_runtime_uncorrelated=len(unlinked),uncorrelated_by_kind=dict(Counter(v['kind']for v in unlinked)),special_apis=api_groups,phases=phase,captured_launches=captures))
 decode=[v for v in records if (v['meta']['target_T']==2 if arm=='hyle'else'_decode'in v['label'])]
 if arm=='hyle':
  # Complete logical calls also include any real single-row MTP tail.
  decode=[v for v in records if v['meta']['role']in[3,4,5,6]]
 roles={}
 for role in ['target','draft']:
  if arm=='hyle':
   selected=[(p,rec)for rec in decode for p in rec['captured_launches']if p['role']==role]
   roles[role]=dict(captured_calls=len(selected),gpu_active=moments([p['all_activity_union_ns']for p,rec in selected]),kernel_active=moments([p['kernel_union_ns']for p,rec in selected]),captured_runtime_launch_matching=sum(p['runtime_graph_launch_matches']==1 for p,rec in selected))
  else:
   selected=[rec for rec in decode if rec['label'].startswith('peer/'+role)]
   roles[role]=dict(actual_calls=len(selected),gpu_active=moments([rec['gpu_contained_union_ns']for rec in selected]),cpu_range=moments([rec['cpu_range_ns']for rec in selected]),eager_only_calls=sum(rec['captured_kernels']==0 for rec in selected),captured_calls=sum(rec['captured_kernels']>0 for rec in selected))
  for v in records:
   v['first_use_class']='instantiate'if any('Instantiate'in n for n in v['special_apis'])else'record_without_instantiate'if any('BeginCapture'in n for n in v['special_apis'])else'no_record_or_instantiate'
 phase_totals={}
 for label in ['hyle/prepare','hyle/prepare_replay','hyle/submit','hyle/wait_publish']:
  values=[p['span_ns']for rec in decode for p in rec['phases']if p['label']==label]
  if values:phase_totals[label]=dict(total_ms=sum(values)/1e6,stats=moments(values))
 by_class={cl:dict(calls=len(v),cpu_range=moments([x['cpu_range_ns']for x in v]),gpu_active=moments([x['gpu_contained_union_ns']for x in v]),no_gpu_activity=moments([x['no_gpu_activity_ns']for x in v]),total_no_gpu_ms=sum(x['no_gpu_activity_ns']for x in v)/1e6)for cl in sorted(set(x['first_use_class']for x in decode))for v in [[x for x in decode if x['first_use_class']==cl]]}
 for cl,stats in by_class.items():
  selected=[v for v in decode if v['first_use_class']==cl]
  stats['phases']={label:dict(total_ms=sum(p['span_ns']for v in selected for p in v['phases']if p['label']==label)/1e6,stats=moments([p['span_ns']for v in selected for p in v['phases']if p['label']==label]),gpu_inside_phase_union_total_ms=sum(p['gpu_contained_union_ns']for v in selected for p in v['phases']if p['label']==label)/1e6)for label in phase_totals}
  stats['contexts']=[v['meta']for v in selected]
  stats['special_api_counts']=dict(Counter({name:sum(x['special_apis'].get(name,{}).get('calls',0)for x in selected)for name in set(n for x in selected for n in x['special_apis'])}))
 phase_totals['runtime_api_summary']={name:dict(calls=sum(x['special_apis'].get(name,{}).get('calls',0)for x in decode),total_ms=sum(x['special_apis'].get(name,{}).get('total_ms',0)for x in decode))for name in sorted(set(n for x in decode for n in x['special_apis']))}
 native_groups=defaultdict(list)
 for rec in decode:
  if arm=='hyle':
   for launch in rec['captured_launches']:
    role=launch['role'];T=rec['meta']['target_T']if role=='target'else rec['meta']['draft_T'];key=f'{role}/T{T}/captured';native_groups[key].append(dict(context=rec['meta']['context'],active_ns=launch['all_activity_union_ns'],kernel_ns=launch['kernel_union_ns'],source_seq=rec['meta']['seq']))
  else:
   role='target'if rec['label'].startswith('peer/target')else'draft';T=rec['meta']['T'];key=f'{role}/T{T}/'+('captured'if rec['captured_launches']else'eager')
   native_groups[key].append(dict(context=rec['meta']['context'],active_ns=rec['gpu_contained_union_ns'],source_seq=rec['meta']['seq'],cpu_range_ns=rec['cpu_range_ns']))
 native_summary={key:dict(actual_calls=len(values),contexts=[min(v['context']for v in values),max(v['context']for v in values)],gpu_active=moments([v['active_ns']for v in values]),context_buckets={str(b):dict(calls=len(rows),gpu_active=moments([v['active_ns']for v in rows]))for b in sorted(set(v['context']//128*128 for v in values))for rows in [[v for v in values if v['context']//128*128==b]]},scope='Hylecapturedlaunch activity with runtimecorrelation; peer actualdecode GPUcontainment includes inputtransfers. SameT isnecessary butnot sameprecision/work/copycontract.')for key,values in native_groups.items()}
 # Same-window first/last fixed number of actualcalls; role/rows remain explicit.
 work=dict(generated_tokens=raw.get('generated_tokens',len(raw.get('generated_ids',[]))),target_prefill_rows=raw['prefill_target_rows'],target_decode_rows=raw['verified_target_rows'],draft_prefill_rows=raw.get('prefill_draft_rows',0),draft_total_rows=raw.get('actual_draft_rows',0),accepted=raw.get('consumed_drafts',raw.get('accepted_drafts')),target_decode_calls=raw.get('decode_graph_calls',raw.get('target_decode_calls')))
 diag=[dict(r)for r in c.execute('SELECT * FROM DIAGNOSTIC_EVENT')]
 missing_ends=sum(1 for r in c.execute("SELECT COALESCE(n.text,s.value) FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId WHERE n.end IS NULL")if r[0]and r[0].startswith(('hyle/','peer/')))
 out['arms'][arm]=dict(process=read(F/'process.json'),artifacts=[pin(F/name)for name in ['trace.sqlite','trace.nsys-rep','native-stdout.log','native-stderr.log']],source_work_equal=not diff,non_time_differences=diff,work=work,NVTX=dict(actual_rows=len(logical),logical_calls=len(records),missing_ends=missing_ends,one_globalTid=len(set(x['globalTid']for x in roots))==1,known_nested_semantics='Hyleprepare_replay lies insideprepare; wait_publish also contains nativeprogress, synchronization andpublication. Parent/children/API cannot be added.'),role_gpu=roles,by_role_T=native_summary,decode_classification=by_class,decode_phase_totals=phase_totals,first_decode=decode[0],first6_decode=decode[:6],last_decode=decode[-1],records=records,diagnostics=diag,driver_table_present=bool(c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='CUPTI_ACTIVITY_KIND_DRIVER'").fetchone()[0]))
 (W/arm/'logical-records.json').write_text(json.dumps(records,indent=2)+'\n');c.close()
out['limits']=['NVTXroot spans profile-onlyCPU wall, gpu union is actual tracedkernel/copy/memset interval union; subtraction gives no observedGPUactivity, never pureCPU utilization or recoverable time.','Hyleactualepisode combinesdraft+target. Per-nativegraph role assignment requires uniqueactualkernel count andcausalorder plusone matchingruntimeGraphLaunch. Unknownnotforced; prefillGPU isnot artificiallysplit.','PeerNVTXdecode ends aftersynchronize beforeactualsampled/hidden/state-trim hostlogic. Gaps outside it may contain realGPUcopy/readback. Do notcompare nativecallCPUspans directly withwholeHyleepisode.','The driver table may be absent; uncorrelateddriver-onlyGPUactivity stays explicit, not assumedzero.','OriginalGraph/originalNode lineage warnings persist; correlationId/runtimeLaunch andrawtimestamps areused, not originalgraphIDs.','Differentnaturalacceptance/math retained. No cold/warmprofileduration pooled with uninstrumentedformalTPS. No morecapture authorized.']
summary={k:v for k,v in out.items()if k!='arms'};summary['arms']={a:{k:v for k,v in x.items()if k not in ['records','diagnostics']}for a,x in out['arms'].items()}
(W/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
for a,v in out['arms'].items():print(a,'workEqual',v['source_work_equal'],'NVTX',v['NVTX'],'roles',v['role_gpu'],'classes',v['decode_classification'],'phases',v['decode_phase_totals'])
assert all(v['source_work_equal']for v in out['arms'].values()),'non-time work changed, stopattribution'
