# Static CUDA-graph input staging: finite source review

2026-10-25，仅本地源码/已有证据；未实现、编译、运行、HTTP 或推算收益。Hyle HEAD `efefaacc046c6e3010c9b1b91121a704aae39912`，main raw SHA `177628b2d6df809f6bd987cd43841f7ff59d27235c77ae0251480d84f7817a57`。

**结论：可用原 IO/Graph 合同表达，但目前只是有条件的小候选。** tokens/positions/identity 本来已有稳定 Phase 存储；值得先证伪的是少数动态 hidden 输入，而不是把所有 state/cache 改成可写固定地址。当前13 Instantiate/19 Update 已包含 native seed 修正；不重开倒序hidden、paired-parent、fixed-chunk 或双投影。

## 参考源码的真实机制

- TensorRT-LLM HEAD `46d9966b54d9d11998b712e732fb20f64d4d35c0`。`tensorrt_llm/_torch/pyexecutor/engine/input_buffers.py:13–76` 按冷容量保留 token/position/gather/draft 存储，并明确复用同步及先销 graphs 再换 storage。`cuda_graph_runner.py:678–710` capture 使用共享 static tensor 切片；`:782–859` replay 检查 exact token/position extent 后 `copy_` 更新内容，`:866–910` 可向静态 encoder-hidden 存储复制/清尾，然后 replay。`:612–664` 禁止任意 live capture 扩工作区而使旧地址失效。并非把新请求 Tensor 地址直接替换进 captured kernels，也不是无复制。
- llama.cpp HEAD `23b0202a189c44a54625aadcb37a946dd1d6278d`。`src/llama-context.cpp:1428–1477` 在可复用图上只更新 inputs；pipeline 尚在读时先等原执行。`src/llama-graph.cpp:70–82,140–158` 将 token/embedding/hidden-state 内容写入已分配 graph input tensor，尺寸复用检查在`:119–132,161–169`。`ggml/src/ggml-cuda/ggml-cuda.cu:2681–2720` 检查实际节点和源指针/shape/stride；`:2723–2748` 仍使用 GraphExecUpdate，更新不兼容时重新 instantiate；`:4648–4673` 地址/属性变化也可回 eager warmup。不能概括为对手永不重录。
- 上述5个实际读取文件均与各自 HEAD blob **LF规范化相同**，逐文件核过；不以仓库整体索引状态推断源码身份。不需要再展开 vLLM 调研。

## Hyle 的现有边界与最小表达

- `main.cc:3734–3749,4117–4133` 的 token/position/identity/catchup 已在冷 Phase Tensor 上更新，照搬 TRT 再包一层没有地址收益。动态读者在`:4023–4026`（draft carry/prior hidden）、`:3303`（递归隐藏输入）和`:3563`（frontier）；各自用途/工作频率不同，不能捆绑成同一个热点。
- `src/graph/executable.cc:1105–1114,1178–1225` 的 key 是**该 range 每个实际命令 input 和 output**的描述/resource/native handle/offset/size；`:9777–9806` 已保2 variants，`:9859–9891` 仅在后端承诺稳定 identity 后记 key。稳定一个 hidden 输入不自动稳定输出、页/状态池切片、私有 native 参数或资格 epoch，也不能放宽这些判断。
- 若完整差异证明某 range 主要受1–2个 hidden 入口地址影响，冷 Phase/真实重叠 slot 内分配固定的原 dtype/extent/resource Tensor，按实际 prepared facts 认证。继续保留原 Snapshot carry/prior ReadLease；**复制进入临时 ingress，不把它当 Snapshot/state 的新版本，也不改原状态权威**。
- CUDA 已有 `compute::CopyBatchProgram/CopyBatchInvocation/CopyBatchUpdate`（`include/hyle/compute/batch_transfer.h:80–139,175–230`）：固定资源/范围容量；源绑定原 ready lease；目标暂移交原独占 writer；一次批内做所需 D2D；真实完成后 `take_mutable` 取回同一 writer，再让原 Graph 读该 Tensor 的 borrowed const view。无需发布一个会阻止下轮写入的 ingress ReadLease；writer/borrow 在实际主图消费者退休前必须保持。小型独立 `Copy` Graph（显式Copy可要求caller目的，`executable.h:798–811`）也是现有设施，但不要把动态源 Copy 节点一起捕获进同一个目标 range，否则其源地址仍会改变该 key。
- 初版可保守等 copy Completion 后执行原主图；不能宣称这个额外等待免费。若后续用同队列依赖消除 host wait，必须复用原可信 producer/退休接缝，不能直接跨过 pending/unknown。CopyUpdate 的 source/目标恢复、失败、取消及 retained submission 限制仍原样适用。元数据在冷容量准备，不能每 token 新建 copy program/host vector/lease pool。
- 作用域只收 ingress；Graph/Backend 不识别模型名或 provider 名，不加第二执行器/manager/registry。CPU/mac/Vulkan 保其已有合法 IO 路线；CopyBatch 当前公共合同是CPU/CUDA，不为统一外观强塞新后端。

## 代价与必须保留的权限

- 字节增量为实际动态端口数 × `required_bytes(actual_desc)`，多请求通常随 R 增长；每个真正可重叠 slot 需独立目的存储，不能按总用户数或历史 turns 复制一套。按原实际 resource/metadata/requested-byte scope 计费，保持借用 Backend/Queue 的地址和寿命。现有单 carrier 序列化只能证明当前窗口复用，不授权未来多 carrier 共用同一可写 ingress。
- 每步新增 D2D copy/native phase、bind/metadata 准备及可能 wait；会改变内存带宽/提交开销，降低 record 数也可能更慢。原输入必须完整复制，无Cast/精度变化、隐式padding或shape广播；copy失败不启动主图或发布 state/RNG，unknown retirement 不允许覆盖目的。旧 Snapshot/GraphOutput readers 和跨请求 key/generation 不被重新解释。
- 范围不包含把输出/状态池改为单地址：它们的旧只读读者是必要语义。若输出tuple仍轮换超过2 variants，单独 ingress staging 很可能无法消除该 range 的 miss。

## 现有证据不能回答什么；最小证伪条件

1. 原 binding 诊断只记 first difference；尚不知同一次 miss 的**全部** input/output差异。需要按 role/Phase/slot/range，两现存variant分别统计全tuple差异（input/output、ValueId/step、dtype/extent/resource/offset/identity），以及 private-qualification/queue/retirement invalidation 原因。只固定容量POD、退出后输出即可，不需通用监控框架；不能由 first hidden 推断其余不变。
2. 把实测差异归到 logical call/turn、页边界、source generation；区分必要拓扑/query/KV计划变化与纯地址轮换。即使公共tuple相同，也不能据此断言 native内部拓扑/权限 epoch 未变。
3. 若去掉候选 ingress 对应差异后，其余tuple仍不能命中现存variant，或主要record来自native资格/输出地址，则该小方案被证伪；若有对应 miss 才值得一次私有字节一致/完整state-RNG检查和包含copy/等待的端到端计时。**此审查没有该观测，更没有测得收益**；不得将 warmup移出decode当综合加速。
