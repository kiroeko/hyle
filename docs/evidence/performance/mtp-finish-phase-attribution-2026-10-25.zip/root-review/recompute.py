from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parents[2]
path = root / 'docs/evidence/performance/mtp-finish-phase-attribution-2026-10-25.json'
public = json.loads(path.read_bytes())
archive = root / public['archive']['path']
assert len(archive.read_bytes()) == public['archive']['bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == public['archive']['sha256']
assert public['work']['status'] == 'PASS' and public['work']['differences'] == []
assert public['work']['metadata_fields_excluded_beyond_existing_time_rules'] == []
assert public['execution']['model_profile_processes'] == 1
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == public['archive']['members']
    assert len(z.namelist()) == len(set(z.namelist()))
    index = json.loads(z.read('extracts/index.json'))
    for label, item in index['extracts'].items():
        raw = z.read('extracts/' + Path(item['path']).name)
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], label
        assert len(raw.splitlines()) == item['rows'], label
    rows = [json.loads(line) for line in z.read('extracts/nvtx.jsonl').splitlines()]
    decode = set()
    for row in rows:
        match = re.match(r'hyle/episode seq=(\d+) role=\d+ target_T=(\d+) ', row['label'] or '')
        if match and int(match[2]) == 2:
            decode.add(int(match[1]))
    assert len(decode) == 66
    phase_rows = [row for row in rows if (row['label'] or '').startswith('hyle/finish/')]
    counts = Counter(row['label'] for row in phase_rows)
    assert len(phase_rows) == 612 and len(counts) == 9 and set(counts.values()) == {68}
    selected = {'hyle/finish/' + name for name in public['post_wait_inside_original_endpoint']['phases']}
    post = [row for row in phase_rows if row['uint64Value'] in decode and row['label'] in selected]
    ns = sum(row['end'] - row['start'] for row in post)
    assert len(post) == 66 * 6 and ns == 13350560
    assert abs(ns / 1e6 - public['post_wait_inside_original_endpoint']['total_ms']) < 1e-10
result = dict(status='ROOT_PUBLIC_EXTRACT_RECOMPUTE_PASS',
    decode_episodes=66, completed_NVTX_phases=612,
    post_wait_ns=ns, post_wait_mean_us=ns / 66 / 1000,
    work_fields_beyond_original_time_normalization_excluded=0,
    scope='Archive-only independent checksum/row-count and six-phase duration sum from original NVTX SQL extraction. No new profile/build, no new peer timing; missing POD metadata remains unknown.')
Path(__file__).with_name('mtp-finish-public-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
