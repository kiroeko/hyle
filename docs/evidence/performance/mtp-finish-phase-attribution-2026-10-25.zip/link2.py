"""Root-authorized same-app-object relink with the two merged lifetime objects."""
from pathlib import Path
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
old_plan = (W / 'plan.json').read_bytes()
(W / 'plan-before-link2.json').write_bytes(old_plan)
plan = b.read(W / 'plan.json')
core_base = R / '.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1'
replacements = []
for name, expected in [('budget', '4c434358cd6807490401d4c38b3cf0912ac93b99f84d4a6396988be16bd227b9'),
                       ('leases', '97c3079899d4c9cf599bfbaa6693f4e178e568c0a7a8b1e8a9247fee5a94e3fd')]:
    new = core_base / name / 'unit.obj'
    assert b.pin(new)['sha256'] == expected
    old = R / '.scratch/engine-product-20261024/cpu-budget-fix1' / name / (name + '.obj')
    replacements.append({'old': b.pin(old), 'new': b.pin(new),
        'compile_command': b.pin(new.parent / 'command.json'),
        'dependencies': b.pin(new.parent / 'dependencies.json')})
mapping = {item['old']['path'].lower(): item['new']['path'] for item in replacements}
link = [mapping.get(word.lower(), word) for word in plan['commands']['link']]
for item in replacements:
    assert sum(word.lower() == item['new']['path'].lower() for word in link) == 1
    assert not any(word.lower() == item['old']['path'].lower() for word in link)
link = [word.replace(str(W / 'link/consumer.'), str(W / 'link2/consumer.')) for word in link]
app = b.pin(W / 'compile/unit.obj')
actual_pins = b.read(W / 'compile/source-pins.json')
for item in actual_pins:
    assert b.pin(Path(item['path'])) == item
proof = R / 'docs/evidence/correctness/compute-lease-retirement-quota-and-readonly-freeze-2026-10-25.json'
plan['status'] = 'APP_COMPILED_FIRST_LINK_UNRESOLVED_CURRENT_LIFETIME_OBJECTS_APPROVED'
plan['first_link_failure'] = {
    'process': b.pin(W / 'link/process.json'), 'stderr': b.pin(W / 'link/stderr.log'),
    'stdout': b.pin(W / 'link/stdout.log'),
    'reason': 'Current StorageOwner::adopt_buffer inline references retain_allocator_owner missing from old c343 lifetime objects; app strict compile passed.',
    'GPU_started': False}
plan['merged_lifetime_replacements'] = replacements
plan['merged_lifetime_public_proof'] = b.pin(proof)
plan['commands']['link2'] = link
plan['commands']['profile_if_later_authorized'] = [word.replace(str(W / 'link/consumer.exe'),
    str(W / 'link2/consumer.exe')) for word in plan['commands']['profile_if_later_authorized']]
plan['work_comparison']['metadata_contract'] = 'Do not drop cache budget/footprint fields from comparison. Any change caused by the two real merged lifetime objects must be listed field-by-field with source explanation; all logical IDs/work/ledger/pending/RNG remain strict.'
b.save(W / 'plan.json', plan)
b.save(W / 'link2-plan.json', {'command': link, 'app_object': app,
    'replacements': replacements, 'source_pins': actual_pins,
    'new_compiler_TUs': 0, 'SDK_builds': 0, 'GPU_processes': 0})
env = b.environment(plan['commands']['compile'][0])
b.execute(link, W / 'link2', env, 120)
source_dll = R / plan['runtime_cpu_companion_source']['path']
os.link(source_dll, W / 'link2' / source_dll.name)
assert b.pin(W / 'compile/unit.obj') == app
for item in actual_pins:
    assert b.pin(Path(item['path'])) == item
for item in replacements:
    assert b.pin(Path(item['new']['path'])) == item['new']
b.save(W / 'ready.json', {'status': 'COMPILED_LINKED_NOT_RUN',
    'image': b.pin(W / 'link2/consumer.exe'), 'app_object': app,
    'CPU_companion_hardlink': b.pin(W / 'link2' / source_dll.name),
    'source_pins': actual_pins, 'source_unchanged_after_build': True,
    'merged_lifetime_replacements': replacements,
    'compiler_TUs': 1, 'links_attempted': 2, 'first_link_preserved': True,
    'SDK_builds': 0, 'new_CUDA_TUs': 0, 'new_core_TUs': 0, 'GPU_processes': 0, 'HTTP': 0,
    'scope': 'Frozen behavioral app plus the two actually merged lifetime core objects, not a new TPS baseline.',
    'parent_GPU_grant_still_required': True})
print('READY_NOT_RUN', b.pin(W / 'link2/consumer.exe'), flush=True)
