"""Offline-only summary of the one authorized fresh12-process window."""
from pathlib import Path
import json,re
V=Path(__file__).resolve().parent;S=V/'screen1';R=V.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
summary=read(S/'summary.json');rows=read(S/'runs.json')
assert summary['status']=='COMPLETE' and len(rows)==12 and summary['all_work_passed']
assert [x['arm'] for x in rows]==['H','C','P','P','C','H','C','H','P','H','C','P']
assert all(x['process']['exit']==0 for x in rows)
compiled={}
for arm in ['H','C']:
    variants=[]
    for row in rows:
        if row['arm']!=arm:continue
        text=(Path(row['folder'])/'stderr.log').read_text(errors='replace')
        match=re.search(r'compiled text finite family variants=(\d+) compiled_known_bytes=(\d+) compiled_unknown_providers=(\d+).*operation_proposals=(\d+).*placement_attempts=(\d+)',text)
        assert match
        family=dict(zip(['variants','compiled_known_bytes','compiled_unknown_providers','operation_proposals','placement_attempts'],map(int,match.groups())))
        phases=[dict(zip(['T','steps','workspace_per_slot','compiled_known_bytes','compiled_unknown_providers'],map(int,m)))
                for m in re.findall(r'compiled T=(\d+) steps=(\d+) workspace/slot=(\d+) compiled_known_bytes=(\d+) compiled_unknown_providers=(\d+)',text)]
        variants.append(dict(family=family,phases=phases))
    assert all(x==variants[0] for x in variants)
    compiled[arm]=variants[0]
triplets=[]
for i in range(0,9,3):
    group=rows[i:i+3];arms={x['arm']:x for x in group}
    triplets.append(dict(order=[x['arm'] for x in group],C_vs_H={k:(arms['C']['metrics'][k]/arms['H']['metrics'][k]-1)*100
                    for k in ['prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second']}))
memory={}
for row in rows[9:]:
    f=Path(row['folder']);m=read(f/'memory-summary.json');t=read(f/'threads.json')
    assert m['setup_error'] is None and m['thread_error'] is None
    memory[row['arm']]=dict(pid=row['process']['pid'],peaks=m['sampled_peaks'],memory_samples=m['sample_count'],running_samples=m['running_sample_count'],
        OS_threads=dict(count=t['count'],peak=t['peak'],min=t['values']['min'],max=t['values']['max'],requested_interval_seconds=.1),
        GPU_unavailable_reasons=m['unavailable_reasons'],limits='Sampled memory/thread lower bounds;OSthreads not busythreads. Peer small GPU registry allocation is not GPU inference.')
out=dict(status='FRESH_CPU_VIEW_REGION_WINDOW_COMPLETE',decision='ROOT_ADOPTED_RESOURCE_AND_PREFILL_OPTIMIZATION_NO_DECODE_GAIN_CLAIM',
    timing=summary['timing'],comparisons=summary['comparisons'],interleaved_triplets=triplets,memory=memory,compiled=compiled,
    work=dict(all12_within_arm_complete_non_time_reports_equal_own_reference=True,
        H_reference='caller217e behavior1',C_reference='candidate7e53 behavior1 with exactly2 explicit workspace changes',P_reference='same-versionAVX2 original own report',
        cross_arm_prompt_rows=154,target_rows=169,target_calls=16,decode_calls=15,output_tokens=16,
        all16_ids_same=True,greedy=True,N=1,R=1,C=256,MTP=False,logical_state_and_ledgers_unchanged=True,
        ignored_fields='Only original clock/time-derived fields;no structure ignored. H/C workspace peak22920576/16029056 fixed and checked in everyprocess.'),
    correctness=dict(build='2strict TUs +2links,0failures',suite='3tests/0fail/0skip',single_behavior='PID58600 exit0;only2 documented workspace fields differ',
        scope='Originalprovider boundary helper;View4modes/2invocations;pernodeBF16exactwitness. No CUDA/Apple/Vulkan or multi-request Model runtime claim.'),
    scope='One fresh3timing+1memory perarm. Initial correctness/older windows are gates only,never pooled.',
    limits=summary['limits'],new_builds_during_screen=0,warmups=0,retries=0,additional_runs=0,CPU_released=True)
(S/'final-summary.json').write_bytes((json.dumps(out,indent=2,allow_nan=False)+'\n').encode())
print(json.dumps(dict(summary=str(S/'final-summary.json'),compiled=compiled,interleaved_triplets=triplets),indent=2))
