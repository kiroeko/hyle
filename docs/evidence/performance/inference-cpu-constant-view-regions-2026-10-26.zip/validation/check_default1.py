"""Only strict test TU refresh, suite relink and4test run; no Model/product compile."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
V=Path(__file__).resolve().parent;O=V/'default1';OLD=V/'candidate1'
s=importlib.util.spec_from_file_location('view_test_tools',V/'check.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
read,pin,save,key=b.read,b.pin,b.save,b.key
assert not O.exists(),'Do not overwrite a recorded attempt'
plan=read(OLD/'plan.json');ready=read(OLD/'ready.json')
for item in plan['helper_pins']:assert pin(item['path'])==item,item['path']
assert pin(V/'consumer.cc')==plan['consumer']
assert pin(b.W/'product-pins.json')==plan['product_pins']
source=V/'consumer-default1.cc';cmd=[];skip=False
for a in plan['commands']['test']:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 cmd.append(a)
out=O/'compile-test';cmd += [str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
save(O/'source-pins.json',dict(source=pin(source),original_consumer=plan['consumer'],helpers=plan['helper_pins'],product_pins=plan['product_pins'],reused_product=pin(OLD/'compile-region/unit.obj')))
compiled=b.b.h.execute(cmd,b.b.env(cmd),out,timeout=180)
d=read(out/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
save(out/'actual-dependencies.json',deps)
assert key(d['Source'])==key(source)
assert all(any(key(p['path'])==key(item['path']) and p==item for p in deps) for item in plan['helper_pins'])
oldtest=OLD/'compile-test/unit.obj';args=[];replacements=0
for a in plan['commands']['link-suite']:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if key(a)==key(oldtest):a=str(out/'unit.obj');replacements+=1
 args.append(a)
assert replacements==1
for p in read(OLD/'link-suite/link-inputs.json'):
 assert pin(p['path'])==p,p['path']
image=O/'link-suite/suite.exe';args += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
linked=b.b.h.execute(args,b.b.env(cmd),image.parent,timeout=180)
save(image.parent/'link-inputs.json',[pin(a) for a in args[1:] if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj','.lib'}])
rt=read(OLD/'runtime.json');target=image.parent/Path(rt['native_hardlink']['path']).name;os.link(rt['native']['path'],target)
env=b.b.env(cmd);env['PATH']=str(image.parent)+os.pathsep+rt['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
run=O/'run';result=b.b.h.execute([str(image),'--gtest_filter=CpuRegionViewsValidation.*','--gtest_output=xml:'+str(run/'results.xml')],env,run,timeout=120)
x=ET.parse(run/'results.xml').getroot();counts={k:int(x.attrib.get(k,0)) for k in ['tests','failures','errors']};counts['skipped']=sum(t.find('skipped') is not None for t in x.iter('testcase'))
save(O/'summary.json',dict(status='PASS' if counts==dict(tests=4,failures=0,errors=0,skipped=0) else 'TEST_FAILED',compile=compiled,link=linked,run=result,counts=counts,source_pins=pin(O/'source-pins.json'),actual_dependencies=pin(out/'actual-dependencies.json'),image=pin(image),reused_product=pin(OLD/'compile-region/unit.obj'),product_TUs=0,test_TUs=1,model_links=0,model_runs=0,SDK_builds=0,GPU_runs=0))
assert counts==dict(tests=4,failures=0,errors=0,skipped=0),counts
print('DEFAULT1_SUITE4_PASS CPU_RELEASED',json.dumps(result),flush=True)
