"""Compile-only current registered graph test TU; no link/run or SDK build."""
from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
V=Path(__file__).resolve().parent;R=V.parents[2];O=V/'formal1'
s=importlib.util.spec_from_file_location('view_formal_tools',V/'check.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
read,pin,save,key=b.read,b.pin,b.save,b.key
assert not O.exists()
source=R/'tests/graph_route_cpu/graph_test.cc'
old=read(V/'candidate1/plan.json')['commands']['test'];cmd=[];skip=False
for a in old:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 cmd.append(a)
for macro in ['/DHYLE_TEST_GGML_CPU=1','/DHYLE_TEST_GRAPH_ROUTE_CPU=1']:
 if macro not in cmd:cmd.append(macro)
cmd += [str(source),'/sourceDependencies',str(O/'dependencies.json'),'/Fo'+str(O/'unit.obj'),'/Fd'+str(O/'unit.pdb')]
before=pin(source);result=b.b.h.execute(cmd,b.b.env(cmd),O,timeout=180)
d=read(O/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
assert pin(source)==before
assert key(d['Source'])==key(source)
helpers=[R/'tests/graph_ggml_constant_view_test.h',R/'tests/graph_ggml_bf16_store_test.h']
assert all(any(p==pin(h) for p in deps) for h in helpers)
assert not any('view-test-source' in p['path'] or 'math-test-source' in p['path'] for p in deps)
save(O/'actual-dependencies.json',deps)
save(O/'summary.json',dict(status='CANONICAL_REGISTERED_TEST_TU_STRICT_COMPILE_PASS',process=result,source=before,helpers=[pin(h) for h in helpers],actual_dependencies=pin(O/'actual-dependencies.json'),dependency_count=len(deps),product_pin=pin(R/'src/graph_route_cpu/ggml_region.cc'),target_macros=['HYLE_TEST_GGML_CPU=1','HYLE_TEST_GRAPH_ROUTE_CPU=1'],link=False,run=False,SDK_builds=0))
print('FORMAL_COMPILE_ONLY_PASS',json.dumps(result),flush=True)
