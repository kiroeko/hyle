"""One fresh CPU H/C/P window; retained execute, PSAPI/PDH and ThreadProbe."""
from pathlib import Path
import copy, importlib.util, json, os, re, sys
sys.dont_write_bytecode = True
V=Path(__file__).resolve().parent;W=V.parent;R=V.parents[2];OUT=V/'screen1'
CPU=R/'.scratch/inference-cpu-shared-pool-20261026'
adapter=R/'.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py'
spec=importlib.util.spec_from_file_location('view_cpu_screen',adapter)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=m.read(m.W/'commands.json')
arms={
 'H':dict(name='caller217e_control',producer='hyle',ready=CPU/'inline-executor1/ready.json',runtime=CPU/'inline-executor1/runtime.json',reference=CPU/'inline-executor1/behavior1/stdout.log',sha='217ed76d90430b3dd0eec6944ec0d257b2c80e26fe736f5349ac2ca32f42c39a'),
 'C':dict(name='constant_View_region_candidate',producer='hyle',ready=V/'candidate1/ready.json',runtime=V/'candidate1/runtime.json',reference=V/'candidate1/behavior1/stdout.log',sha='7e53ba106be4728e2a874014eb035211c6379e7cbfa3bcec3167d7f0d61954bc'),
 'P':dict(name='same_version_AVX2_peer',producer='peer',ready=Path(base['peer']['ready']['path']),runtime=Path(base['peer']['runtime']['path']),reference=m.W/'future-run/peer-result.json',sha='27a49a73fdafccde9528bda413aee69f2e2d755b7705fa60bbd60fc8a8ca5404')}
metrics=('prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second')
more=('prefill_seconds','decode_seconds','session_seconds','startup_to_ready_seconds','startup_to_endpoint_seconds','weights_load_seconds')
order=[('timing',a) for a in ['H','C','P','P','C','H','C','H','P']]+[('memory',a) for a in ['H','C','P']]

def summarize(rows):
 grouped={a:{k:m.stats([x['metrics'][k] for x in rows if x['mode']=='timing' and x['arm']==a]) for k in (*metrics,*more)} for a in arms}
 comparisons={}
 for a,b in [('C','H'),('P','H'),('P','C')]:
  comparisons[a+'_vs_'+b]={}
  for k in (*metrics,*more):
   x,y=grouped[a][k],grouped[b][k]
   if x['count'] and y['count']:
    comparisons[a+'_vs_'+b][k]=dict(median_percent=(x['median']/y['median']-1)*100,ranges_overlap=max(x['min'],y['min'])<=min(x['max'],y['max']))
 return dict(status='COMPLETE' if len(rows)==12 else 'PARTIAL',processes=rows,timing=grouped,comparisons=comparisons,
  memory={x['arm']:dict(summary=m.read(Path(x['folder'])/'memory-summary.json'),threads=m.read(Path(x['folder'])/'threads.json')) for x in rows if x['mode']=='memory'},
  all_work_passed=all(x['work']['all_within_arm_non_time_fields_equal_initial_AVX2_pair'] for x in rows),
  protocol=dict(timing_order='H,C,P,P,C,H,C,H,P',memory_order='H,C,P',timing_each=3,memory_each=1,prior_samples_pooled=False,warmups=0,retries=0,timeout_seconds=180),
  limits=['CPU-only Windows, original P154/16/C256/N1/R1/greedy/noMTP endpoints. Requested native4/ATen4 and peer4 are not processwide thread caps.',
   'Each arm checked against its complete own fixed semantic reference. Candidate differs from control only at2 specified workspace peak fields; no structural field is removed.',
   'Peer matched AVX2/FMA/F16C same-version archive; F32 intermediate operations differ from Hyle BF16 storepoints. Matching greedy IDs is not intermediatebit/math/quality equivalence or latest-upstream claim.',
   'Startup clock excludes different outer ATen/Scheduler setups, so no fair cross-engine coldstart ranking.',
   'Memory processes do not enter timing statistics. PSAPI/PDH/100ms OS-thread peaks are sampled lower bounds, not busy threads or energy. Missing GPU counters remain null. No GPU model.',
   'Only3 short timing samples perarm. No stable deployment/scaling/general model claim or cross-window gain attribution.'])

def prepare():
 refs={a:m.read(x['reference']) for a,x in arms.items()}
 expected=copy.deepcopy(refs['H'])
 assert expected['workspace_domains'][0]['known_peak_bytes']==22920576
 assert refs['C']['workspace_domains'][0]['known_peak_bytes']==16029056
 expected['workspace_domains'][0]['known_peak_bytes']=16029056
 expected['sessions'][0]['result']['workspace_domains'][0]['known_peak_bytes']=16029056
 assert m.normalize(expected)==m.normalize(refs['C']), 'Unexpected candidate semantic reference difference'
 plan={}
 for a,arm in arms.items():
  ready=m.read(arm['ready']);assert ready['image']['sha256']==arm['sha'] and m.pin(ready['image']['path'])==ready['image']
  cmd=list(m.read(CPU/'inline-executor1/behavior1/command.json')['command'] if a!='P' else base['peer']['command']);cmd[0]=ready['image']['path']
  plan[a]=dict(name=arm['name'],producer=arm['producer'],ready=m.pin(arm['ready']),runtime=m.pin(arm['runtime']),image=ready['image'],command=cmd,reference=m.pin(arm['reference']))
 m.save(V/'screen-plan.json',dict(status='PREPARED_NOT_RUN',arms=plan,script=m.pin(__file__),adapter=m.pin(adapter),runner=m.pin(m.protocol.base.RUNNER),observer=m.pin(m.protocol.base.OBSERVER),sampler=m.pin(m.runner.SAMPLER),order=order,
  permitted_reference_differences=[dict(path='$.workspace_domains[0].known_peak_bytes',before=22920576,after=16029056),dict(path='$.sessions[0].result.workspace_domains[0].known_peak_bytes',before=22920576,after=16029056)],no_old_samples_pooled=True))
 print('VIEW_CPU3_PREPARED_NOT_RUN',flush=True)

def run():
 assert not OUT.exists(),'Refuse overwrite/repeat'
 plan=m.read(V/'screen-plan.json');assert m.pin(__file__)==plan['script']
 for arm in plan['arms'].values():
  for k in ['ready','runtime','image','reference']:assert m.pin(arm[k]['path'])==arm[k],arm[k]['path']
 OUT.mkdir();m.save(OUT/'plan.json',plan);rows=[]
 peer=m.read(arms['P']['reference'])
 try:
  for index,(mode,a) in enumerate(order,1):
   arm=plan['arms'][a];folder=OUT/f'{index:02d}-{mode}-{a}';cmd=list(arm['command'])
   if a=='P':cmd[cmd.index('--output')+1]=str(folder/'consumer-result.json')
   rt=m.read(arm['runtime']['path']);env=os.environ.copy();env['PATH']=rt['PATH'];env.update(rt.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
   m.current_folder=folder
   process=m.runner.execute(folder,arm['producer'],cmd,env,mode=='memory')
   j=m.raw(folder,arm['producer']);m.references=dict(hyle=m.read(arms[a]['reference']) if a!='P' else m.read(arms['H']['reference']),peer=peer)
   work=m.check(j,arm['producer']);work['actual_reference']=arm['reference'];m.save(folder/'checks.json',work)
   text=(folder/'stderr.log').read_text(errors='replace')
   found=re.search(r'weights_load_seconds=([0-9.eE+-]+)',text)
   load=j.get('weights_load_seconds',float(found.group(1)) if found else None)
   assert load is not None,'Missing actual weight-loading endpoint'
   row=dict(index=index,mode=mode,arm=a,folder=str(folder),process=process,work=work,
    metrics={**{k:j[k] for k in (*metrics,*more[:-1])},'weights_load_seconds':load})
   rows.append(row);m.save(OUT/'runs.json',rows);m.save(OUT/'summary.json',summarize(rows))
   print('VIEW_CPU3_TERMINAL',process['pid'],process['exit'],mode,a,'WORK_PASS',flush=True)
 except Exception as exc:
  m.save(OUT/'failure.json',dict(error=repr(exc),completed=len(rows),stopped_before_next_process=True));raise
 print('VIEW_CPU3_WINDOW_COMPLETE_RELEASED',flush=True)

if __name__=='__main__':
 assert sys.argv[1:] in (['prepare'],['run'])
 globals()[sys.argv[1]]()
