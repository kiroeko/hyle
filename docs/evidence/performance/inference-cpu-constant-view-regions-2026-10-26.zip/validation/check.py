"""Finite candidate-region/test build; actions are explicit, never a model screen."""
from pathlib import Path
import argparse, importlib.util, json, os, sys, xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
V = Path(__file__).resolve().parent
W, R = V.parent, V.parents[2]
B = R / '.scratch/inference-cpu-shared-pool-20261026'
spec = importlib.util.spec_from_file_location('region_validation_tools', B / 'check_build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, pin, save, key = b.read, b.pin, b.save, b.key
CONTROL = B / 'inline-executor1'
REGION_RECIPE = R / '.scratch/inference-current-closure-20261026/headers79/graph_route_cpu--ggml_region_cc/command.json'
TEST_RECIPE = R / '.scratch/inference-f32-append-20261025/cpu1/compile/cpu-test/command.json'
OLD_REGION = REGION_RECIPE.parent / 'unit.obj'
SOURCE = W / 'source/src/graph_route_cpu/ggml_region.cc'

def flags(recipe):
    original = read(recipe)['command']
    result, skip = [], False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd', '/i', '/external:i')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        result.append(arg)
    assert '/W4' in result and '/WX' in result and '/MD' in result and '/O2' in result
    return [original[0], *result]

def command(name, source, recipe, attempt):
    out = attempt / ('compile-' + name)
    includes = [R / 'include', R, R / 'src/compute', R / 'src/graph',
                R / 'src/graph_route_cpu', R / 'src/compute_provider_ggml',
                R / 'src/compute_ggml_runtime']
    old = read(recipe)['command']
    # Only original third-party includes survive; no historical project-support overlay.
    external = [a for a in old[1:] if a.lower().startswith('/external:i')]
    return [*flags(recipe), *['/I' + str(p) for p in includes], *external,
            str(source), '/sourceDependencies', str(out / 'dependencies.json'),
            '/Fo' + str(out / 'unit.obj'), '/Fd' + str(out / 'unit.pdb')]

def prepare(attempt):
    assert not attempt.exists(), 'Do not overwrite an attempt'
    product = read(W / 'product-pins.json')
    assert len(product['files']) == 1 and product['files'][0]['path'] == 'src/graph_route_cpu/ggml_region.cc'
    row = product['files'][0]
    assert {k:v for k,v in pin(SOURCE).items() if k != 'path'} == row['after']
    assert {k:v for k,v in pin(R / row['path']).items() if k != 'path'} == row['before']
    consumer = V / 'consumer.cc'
    assert consumer.is_file()
    helper_pins = [pin(p) for p in [R / 'tests/graph_ggml_discovery_test.h',
        W / 'view-test-source/tests/graph_ggml_constant_view_test.h',
        W / 'math-test-source/tests/graph_ggml_bf16_store_test.h']]
    inputs = read(CONTROL / 'link-inputs.json')
    for item in inputs:
        assert pin(item['path']) == item, item['path']
    old = read(CONTROL / 'link/command.json')['command']
    assert sum(key(a) == key(OLD_REGION) for a in old) == 1
    remove = [CONTROL / 'compile/unit.obj',
              R / '.scratch/inference-cpu-representative-20261026/compile/model/unit.obj',
              R / '.scratch/inference-current-closure-20261026/engine/report/unit.obj',
              R / '.scratch/inference-cpu-representative-20261026/compile/weights/unit.obj']
    assert all(sum(key(a) == key(p) for a in old) == 1 for p in remove)
    base = [a for a in old if not a.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:'))]
    base = [str(attempt / 'compile-region/unit.obj') if key(a) == key(OLD_REGION) else a for a in base]
    suite = [a for a in base if key(a) not in {key(p) for p in remove}]
    suite.append(str(attempt / 'compile-test/unit.obj'))
    commands = {'region': command('region', SOURCE, REGION_RECIPE, attempt),
                'test': command('test', consumer, TEST_RECIPE, attempt)}
    for tag, args in [('suite', suite), ('model', base)]:
        image = attempt / ('link-' + tag) / (tag + '.exe')
        commands['link-' + tag] = [*args, '/OUT:' + str(image),
            '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    save(attempt / 'plan.json', dict(status='PREPARED_NOT_COMPILED_NOT_RUN',
        product_pins=pin(W / 'product-pins.json'), consumer=pin(consumer),
        helper_pins=helper_pins,
        recipes=[pin(REGION_RECIPE), pin(TEST_RECIPE), pin(CONTROL / 'link/command.json')],
        control=pin(CONTROL / 'ready.json'), cached_inputs=inputs,
        suite_removed_engine_objects=[str(p) for p in remove], commands=commands,
        scope='1 candidate product TU + 1 thin test TU + 2 links; no SDK/core/native rebuild; no model screen'))

def build(attempt):
    plan = read(attempt / 'plan.json')
    assert pin(W / 'product-pins.json') == plan['product_pins']
    assert pin(V / 'consumer.cc') == plan['consumer']
    for item in plan['helper_pins']:
        assert pin(item['path']) == item, item['path']
    results, dependency_pins = {}, {}
    for tag in ['region', 'test']:
        cmd = plan['commands'][tag]
        out = attempt / ('compile-' + tag)
        results[tag] = b.h.execute(cmd, b.env(cmd), out, timeout=180)
        d = read(out / 'dependencies.json')['Data']
        deps = [pin(p) for p in dict.fromkeys([d['Source'], *d['Includes']])]
        save(out / 'actual-dependencies.json', deps)
        dependency_pins[tag] = deps
        assert key(d['Source']) == key(SOURCE if tag == 'region' else V / 'consumer.cc')
        assert not any('/cpu1/source/' in p['path'].replace('\\', '/').lower() for p in deps)
    for item in plan['cached_inputs']:
        assert pin(item['path']) == item, item['path']
    ready = {'status': 'BUILT_NOT_RUN', 'compile': results, 'product_pins': plan['product_pins'],
             'test_source': plan['consumer'], 'actual_dependencies': dependency_pins,
             'model_runs': 0, 'unit_runs': 0, 'GPU_runs': 0, 'SDK_builds': 0}
    runtime = read(CONTROL / 'runtime.json')
    for tag in ['suite', 'model']:
        cmd = plan['commands']['link-' + tag]
        out = attempt / ('link-' + tag)
        result = b.h.execute(cmd, b.env(plan['commands']['region']), out, timeout=180)
        image = out / (tag + '.exe')
        inputs = [pin(a) for a in cmd[1:] if Path(a).is_absolute()
                  and Path(a).suffix.lower() in {'.obj','.lib'}]
        save(out / 'link-inputs.json', inputs)
        target = out / Path(runtime['native_hardlink']['path']).name
        os.link(runtime['native']['path'], target)
        ready[tag] = {'image': pin(image), 'link': result, 'native_alias': pin(target),
                      'link_inputs': pin(out / 'link-inputs.json')}
    save(attempt / 'runtime.json', runtime)
    ready['image'] = ready['model']['image']
    ready['runtime'] = pin(attempt / 'runtime.json')
    ready['control'] = pin(CONTROL / 'ready.json')
    save(attempt / 'ready.json', ready)
    print('READY_NOT_RUN', json.dumps({k:ready[k]['image'] for k in ['suite','model']}), flush=True)

def suite(attempt):
    ready = read(attempt / 'ready.json')
    image = ready['suite']['image']
    assert pin(image['path']) == image
    rt = read(attempt / 'runtime.json')
    env = b.env(read(attempt / 'plan.json')['commands']['test'])
    env['PATH'] = str(Path(image['path']).parent) + os.pathsep + rt['PATH']
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    out = attempt / 'suite-run'
    result = b.h.execute([image['path'], '--gtest_filter=CpuRegionViewsValidation.*',
        '--gtest_output=xml:' + str(out / 'results.xml')], env, out, timeout=120)
    root = ET.parse(out / 'results.xml').getroot()
    counts = {k:int(root.attrib.get(k,0)) for k in ['tests','failures','errors']}
    counts['skipped'] = sum(t.find('skipped') is not None for t in root.iter('testcase'))
    save(out / 'summary.json', dict(process=result,counts=counts,ready=pin(attempt / 'ready.json')))
    assert counts == {'tests':3,'failures':0,'errors':0,'skipped':0}, counts
    print('SUITE_PASS', counts, flush=True)

def behavior(attempt):
    suite_summary = read(attempt / 'suite-run/summary.json')
    assert suite_summary['counts'] == {'tests':3,'failures':0,'errors':0,'skipped':0}
    ready = read(attempt / 'ready.json')
    image = ready['model']['image']
    assert pin(image['path']) == image
    reference = CONTROL / 'behavior1'
    cmd = list(read(reference / 'command.json')['command'])
    cmd[0] = image['path']
    rt = read(attempt / 'runtime.json')
    env = b.env(read(attempt / 'plan.json')['commands']['region'])
    env['PATH'] = str(Path(image['path']).parent) + os.pathsep + rt['PATH']
    env.update(rt.get('configured_flags', {}))
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    out = attempt / 'behavior1'
    result = b.h.execute(cmd, env, out, timeout=180)
    clock_keys = {'seconds','unix_ms','unix_ns','clock_unix'}
    def normalize(value):
        if isinstance(value, dict):
            return {k:normalize(v) for k,v in value.items() if k not in clock_keys
                    and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
        if isinstance(value, list):
            return [normalize(v) for v in value]
        return value
    def differences(old, new, path='$'):
        if type(old) != type(new):
            return [dict(path=path,before=old,after=new)]
        if isinstance(old, dict):
            result = []
            for k in sorted(old.keys() | new.keys()):
                if k not in old or k not in new:
                    result.append(dict(path=path+'.'+k,before=old.get(k),after=new.get(k)))
                else:
                    result.extend(differences(old[k],new[k],path+'.'+k))
            return result
        if isinstance(old, list):
            if len(old) != len(new):
                return [dict(path=path,before=old,after=new)]
            return [d for i,(x,y) in enumerate(zip(old,new)) for d in differences(x,y,path+f'[{i}]')]
        return [] if old == new else [dict(path=path,before=old,after=new)]
    old, actual = read(reference / 'stdout.log'), read(out / 'stdout.log')
    diff = differences(normalize(old),normalize(actual))
    save(out / 'nontime-diff.json',diff)
    save(out / 'summary.json',dict(status='BEHAVIOR_RECORDED_REQUIRES_FIELD_REVIEW' if diff else 'BEHAVIOR_FULL_NONTIME_EQUAL',
         process=result,reference=pin(reference / 'stdout.log'),ready=pin(attempt / 'ready.json'),
         nontime_differences=len(diff),normalization=dict(clock_keys=sorted(clock_keys),
         suffixes=['_seconds','tokens_per_second'],structural_fields_ignored=[]),
         model_runs=1,GPU_runs=0,performance_claim=False))
    print('BEHAVIOR_COMPLETE_DIFF_COUNT',len(diff),flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare','build','suite','behavior'])
    parser.add_argument('--attempt', default='candidate1')
    args = parser.parse_args()
    assert args.attempt.isidentifier()
    globals()[args.action](V / args.attempt)
