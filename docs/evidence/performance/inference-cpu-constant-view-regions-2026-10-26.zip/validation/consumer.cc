#include <gtest/gtest.h>
#include "hyle/graph/cpu.h"
#include "tests/graph_ggml_discovery_test.h"
#include "../view-test-source/tests/graph_ggml_constant_view_test.h"
#include "../math-test-source/tests/graph_ggml_bf16_store_test.h"

TEST(CpuRegionViewsValidation, OriginalProviderBoundaries) {
  auto context = hyle::graph::cpu::create_context({.native_threads = 4}).value();
  ggml_discovery_test::exercise(context, hyle::mem::system_resource());
}

TEST(CpuRegionViewsValidation, ConstantViewBridgeAndFences) {
  auto context = hyle::graph::cpu::create_context({.native_threads = 4}).value();
  ggml_constant_view_test::exercise(context, hyle::mem::system_resource());
}

TEST(CpuRegionViewsValidation, OriginalBfloatStorePoints) {
  ggml_bf16_store_test::exercise();
}
