#include "consumer.cc"

TEST(CpuRegionViewsValidation, DefaultNativeThreadsConstantViewBridgeAndFences) {
  auto context = hyle::graph::cpu::create_context().value();
  ggml_constant_view_test::exercise(context, hyle::mem::system_resource());
}
