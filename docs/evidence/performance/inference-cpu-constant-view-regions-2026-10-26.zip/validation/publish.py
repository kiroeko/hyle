"""Compact evidence only; no builds, model processes or product edits."""
from pathlib import Path
import hashlib,json,zipfile
V=Path(__file__).resolve().parent;W=V.parent;R=V.parents[2];S=V/'screen1';C=V/'candidate1';D=V/'default1'
PUBLIC=R/'docs/evidence/performance';NAME='inference-cpu-constant-view-regions-2026-10-26'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def blob(v):return (json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
if (PUBLIC/(NAME+'.json')).exists() or (PUBLIC/(NAME+'.zip')).exists():
 old=read(V/'publication.json')
 assert pin(PUBLIC/(NAME+'.json'))==old['report'] and pin(PUBLIC/(NAME+'.zip'))==old['archive'],'Do not overwrite external changes'
final=read(S/'final-summary.json');assert final['status']=='FRESH_CPU_VIEW_REGION_WINDOW_COMPLETE'
assert read(D/'summary.json')['counts']==dict(tests=4,failures=0,errors=0,skipped=0)
product=read(W/'product-pins.json');assert product['files'][0]['after']['sha256']=='5213250b4aea87eb2c43966a49500dc8a48138eb1ea949f217c6ad2863412d1a'
assert read(C/'ready.json')['image']['sha256']=='7e53ba106be4728e2a874014eb035211c6379e7cbfa3bcec3167d7f0d61954bc'
rows=read(S/'runs.json');assert len(rows)==12 and all(x['process']['exit']==0 for x in rows)
ids=read(C/'behavior1/stdout.log')['sessions'][0]['result']['generated_ids']
summary={
 'schema':'hyle.performance.evidence.v1','date':'2026-10-26',
 'decision':'ADOPTED_AS_RESOURCE_AND_PREFILL_OPTIMIZATION_NO_DECODE_GAIN_CLAIM',
 'change':'Only CPU ggml region discovery: constant-root, no-effect/no-control, nonpublished View chains can connect discovery; Views are filtered out of native members and retain original Graph metadata, bindings and permissions.',
 'source':dict(product=product,view_helper=read(W/'view-test-pins.json'),BF16_helper=read(W/'math-test-pins.json'),independent_review=pin(W/'independent-review-sampling.json')),
 'identities':read(S/'plan.json')['arms'],
 'frozen_scope':'Only ggml_region object changes versus caller217e. Test-only refresh does not change the tested7e53 Model image. The retained CPU Model consumer predates R>1 sampling work; N1 greedy remains the same path. Not a current-full-canonical or latest-upstream benchmark claim.',
 'results':dict(timing=final['timing'],comparisons=final['comparisons'],interleaved_triplets=final['interleaved_triplets'],memory=final['memory']),
 'interpretation':[
  'Candidate/control prefill median+1.14895% with nonoverlapping3sample ranges; decode median-0.37068% and combined+0.71773% have overlapping ranges. No stable decode or combined gain established.',
  'Independent candidate memory process has341282816 fewer sampled working-set bytes and348819456 fewer private-commit bytes. Threads peak17/17 for H/C; these are whole-process sampled facts,not decode allocation accounting.',
  'Compiled plans have1195->1039 steps perT, placement_attempts1368->1056, known workspace T154:22920576->16029056 and T1:438464->185536 bytes. Family known compiled storage119552->1893344 increases; native private storage is still unknown. Do not infer physical allocation solely from these logical reports.',
  'Peer has matched same-version AVX2/FMA/F16C archive and T4 CPU placement/nooffload. Its F32 intermediate operations differ from Hyle BF16 storepoints; identical16greedy IDs are not intermediate-bit/math/quality equivalence.',
  'Startup clocks omit different outer setup work and are not ranked across engines. Memory runs are separate from timing. Missing H/C GPU counters are null; peer24KiB registry observation is not GPU inference.'
 ],
 'correctness':dict(initial_build=dict(product_TUs=1,test_TUs=1,links=2,compile=read(C/'ready.json')['compile']),
  initial_suite=read(C/'suite-run/summary.json'),default_native_threads1=read(D/'summary.json'),
  single_behavior=read(C/'behavior1/summary.json'),behavior_difference=read(C/'behavior1/nontime-diff.json'),
  work=final['work'],generated_ids=ids,numerical_boundary='Independent Add/Subtract BF16 witness requires exact[0000,3c00],distinct from omitting intermediate store[3b80,3b80]. Viewhelper4modes/twoinvocations also retains oldoutput/originalW,exactalias and packedbytes0.',
  formal_registered_TU_compile_only=read(V/'formal1/summary.json'),
  failures=dict(compile_link_runtime=0,integration_patch_format=1),scope='WindowsCPU only. 3 initial tests then4default-inclusive tests,1Model behavior,12newscreen processes. Current registered graph_test.cc strictly compiled with bothtargetmacros and canonicalhelpers;not linked/run. No nativeGPU/Mac/Linux/multirequest Model runtime claim.'),
 'integration':read(V/'formal1/canonical-integration.json'),
 'patch_format_repair':'Initial LF-only diff could not apply against tracked CRLF with core.autocrlf=false; Root retained thefailure then regenerated finalproduct.patch preservingCRLF. Finalpatch is21d387bd.../4100bytes; source afterSHA5213250b is identical to every check/window. OldLFdiff/pins are historical only; finalproduct.patch/product-pins.json are authoritative. No Model rerun or source/math/lifetime change.',
 'protocol':dict(timing_order='H,C,P,P,C,H,C,H,P',memory_order='H,C,P',timing_each=3,memory_each=1,watchdog_seconds=180,warmups=0,retries=0,old_samples_pooled=False,work_gate='Every complete report equals its own frozen reference except only originalclock fields. H/C reference pair has exactly2 explicitly checked workspace peak differences;no structural fields discarded.',endpoints=dict(prefill='154/prefill_seconds',decode='15/decode_seconds',combined='16/session_seconds'),fixed_work='P154/16outputs/C256/N1/R1/greedy/noMTP,169targetrows/16calls/15decode; all16IDs same.'),
 'source_findings_reference':dict(memo=pin(R/'.scratch/inference-cpu-shared-pool-20261026/cpu-small-graph-review1/memo.json'),counts=pin(R/'.scratch/inference-cpu-shared-pool-20261026/cpu-small-graph-review1/counts.json'),prior_archive='docs/evidence/performance/inference-cpu-graph-submission-attribution-2026-10-26.zip',limit='Old570callbacks/207regions and569native calls are separate prior diagnostics,not a new candidatecatalog. Defaultprovider extension and hardpolicy wiring were intact;511nonemitting remainder was not identified solely as Views.'),
 'limits':final['limits'],'canonical_changes_by_publisher':False,'new_builds_or_runs_by_publisher':0,
}
members={}
def add(p,name=None):
 p=Path(p);name=name or p.relative_to(W).as_posix();assert name not in members
 assert p.suffix.lower() not in {'.exe','.obj','.map','.lib','.exp','.dll','.gguf','.safetensors','.pdb'}
 members[name]=p.read_bytes()
for name in ['product.patch','product-pins.json','product-initial-lf.patch','product-initial-lf-pins.json','integration-first-failure.json','scope.json','view-test-pins.json','math-test-pins.json','math-test-scope.json','independent-review-sampling.json']:
 add(W/name)
for name in ['view-test-source/tests/graph_ggml_constant_view_test.h','math-test-source/tests/graph_ggml_bf16_store_test.h']:
 add(W/name)
for name in ['check.py','consumer.cc','consumer-default1.cc','check_default1.py','check_formal.py','screen.py','analyze.py','publish.py','screen-plan.json']:
 add(V/name)
for root in [C,D,S,V/'formal1']:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  if p.suffix.lower() not in {'.json','.log','.xml'}:continue
  if p.name=='live.json' or p.name=='running.json':continue
  add(p)
add(V/'formal1/graph-test.patch')
CPU=R/'.scratch/inference-cpu-shared-pool-20261026'
for name in ['memo.json','counts.json','analyze.py']:
 add(CPU/'cpu-small-graph-review1'/name,'source-review/'+name)
for name in ['ready.json','runtime.json','link/command.json','link-inputs.json','behavior1/stdout.log','behavior1/stderr.log','behavior1/command.json']:
 add(CPU/'inline-executor1'/name,'control/'+name)
add(R/'tests/graph_ggml_discovery_test.h','source-review/original-graph_ggml_discovery_test.h')
plan=read(S/'plan.json')
for key in ['adapter','runner','observer','sampler']:
 p=Path(plan[key]['path']);assert pin(p)==plan[key]
 add(p,'retained-tools/'+key+'-'+p.name)
members['report.json']=blob(summary)
manifest=[dict(name=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(members.items())]
members['archive-members.json']=blob(manifest)
PUBLIC.mkdir(parents=True,exist_ok=True);archive=PUBLIC/(NAME+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
# One complete read verifies each member's ZIP CRC and independent SHA.
with zipfile.ZipFile(archive) as z:
 assert len(z.infolist())==len(members)
 for entry in z.infolist():
  data=z.read(entry.filename)
  assert len(data)==len(members[entry.filename]) and hashlib.sha256(data).digest()==hashlib.sha256(members[entry.filename]).digest()
summary['archive']=pin(archive)
summary['archive_verification']=dict(CRC_and_member_SHA256='PASS',members=len(members),manifest_sha256=hashlib.sha256(members['archive-members.json']).hexdigest(),verified_once=True,no_binary_SDK_model=True)
report=PUBLIC/(NAME+'.json');report.write_bytes(blob(summary))
(V/'publication.json').write_bytes(blob(dict(report=pin(report),archive=pin(archive),verification=summary['archive_verification'])))
print(json.dumps(read(V/'publication.json'),indent=2))
