from pathlib import Path
import collections,hashlib,json,re
ROOT=Path(__file__).resolve().parents[3]
W=ROOT/'.scratch/inference-cpu-shared-pool-20261026'
OUT=Path(__file__).resolve().parent
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
 b=p.read_bytes();return {'path':str(p.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
raw=W/'graph-submission-diagnostic1/run/stderr.log'
steps=[json.loads(x.split(' ',1)[1]) for x in raw.read_text(encoding='utf-8-sig').splitlines() if x.startswith('HYLE_CPU_SUBMISSION_CLOCK ') and '"tag":"step"' in x]
parents=collections.defaultdict(list)
for step in steps: parents[step['parent']].append(step)
assert len(parents)==16 and len(steps)==10944
signatures=[]
for rows in parents.values():
 c=collections.Counter((r['provider_name'] or 'UNKNOWN_ID_REGION',r['kind'],r['nodes']) for r in rows)
 signatures.append(c)
assert all(c==signatures[0] for c in signatures)
c=signatures[0]
hist=[{'provider':name,'step_kind':kind,'logical_nodes':nodes,'calls_per_episode':count} for (name,kind,nodes),count in sorted(c.items())]
assert sum(c.values())==684
assert sum(nodes*n for (_,_,nodes),n in c.items())==1359
assert sum(n for (name,_,_),n in c.items() if name=='ggml-cpu')==570
assert sum(n for (name,kind,_),n in c.items() if name=='ggml-cpu' and kind==1)==207
save(OUT/'counts.json',{'scope':'old retained Graph-submission process only; 1 prefill+15 decode; all 16 callback signatures identical','raw':pin(raw),'episodes':len(parents),'per_episode':hist,'command_steps':684,'ggml_callbacks':570,'ggml_regions':207,'ggml_multinode_regions':201,'represented_ir_nodes':1359,'reported_plan_steps':1195,'reported_ir_nodes':1870,'nonemitting_plan_step_remainder':511,'unrepresented_ir_node_remainder':511,'caveat':'511 is not independently identified as all Views; emits_command excludes both View and zero-dispatch compiled region. Raw has no node IDs, operation kind, route, implementation or policy.'})
