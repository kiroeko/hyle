"""Three fresh fixed128+31 memory observations, outside throughput windows."""
import importlib.util
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
import threading
import time
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=load('memory_current_helpers',A/'projected-bind-cold-index/build.py');b,c=h.b,h.c
probe_path=A/'qwen-gpu-comparison/memory-probe/memory_probe.py'
MemoryProbe=load('memory_current_probe',probe_path).MemoryProbe
def marker(line):
    if line.startswith('weights_load_seconds='):return 'model_loaded'
    if line.startswith('initialized '):return 'ready_before_prefill'
    if line.startswith('prefill tokens='):return 'prefill_complete'
    if line.startswith('decode31 tokens='):return 'inference_complete'
    if line.startswith('measure_memory '):
        found=re.search(r'\bname=(\S+)',line)
        if found:return found.group(1)
    return None
def stats(values):
    return dict(samples=len(values),min=min(values),median=statistics.median(values),max=max(values)) if values else dict(samples=0,min=None,median=None,max=None)
def main():
    out=S/'observations';out.mkdir(exist_ok=False)
    (out/'tmp').mkdir()
    plan=c.read(A/'qwen-finite-family/performance-prepared/plan.json')
    adopted=c.read(A/'qwen-finite-family/adoption.json');assert b.same(adopted['product']) and adopted['compiled_product']
    images=dict(baseline=plan['images']['baseline'],current=adopted['product_image'],llama=plan['images']['llama'])
    for row in images.values():assert b.same(row)
    link=c.read(A/'qwen-finite-family/product-checks/qwen-link-plan.json')
    for row in link['inputs']:assert b.same(row)
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']]+[row['path'] for row in plan['peer_inputs']],out)
    source=S/'source/memory_probe.py';source.parent.mkdir();source.write_bytes(probe_path.read_bytes())
    c.execute('hardware',['nvidia-smi','--query-gpu=name,driver_version,driver_model.current,memory.total,memory.used','--format=csv'],env,out)
    c.save(out/'inputs.json',dict(images=images,adopted_product=adopted['product'],sampler=b.identity(probe_path),
        copied_sampler=b.identity(source),retained_fixed_plan=b.identity(A/'qwen-finite-family/performance-prepared/plan.json'),
        order=['baseline','current','llama'],requested_interval_seconds=.01,runtime=runtime,
        throughput_claim=False,compiles=0,links=0,model_or_native_changes=False,
        scope='One fresh process per image, identical fixed128+31 and context256. Memory-only observation, not timing samples or independent quality.'))
    results={}
    for arm in ('baseline','current','llama'):
        run=out/arm;run.mkdir()
        request=next(row for row in plan['requests'] if row['arm']==arm)
        argv=request['command'].copy();argv[0]=images[arm]['path']
        if arm=='llama':argv[-1]=str(run/'peer-result.json')
        assert '--trace' not in argv
        assert b.same(images[arm])
        row=dict(arm=arm,image=images[arm],command=argv,markers=[],started=time.time())
        c.save(run/'command.json',row)
        def reader(stream,output):
            for raw in iter(stream.readline,b''):
                output.write(raw)
                line=raw.decode('utf-8',errors='replace').rstrip();kind=marker(line)
                if kind:row['markers'].append(dict(name=kind,timestamp_ns=time.perf_counter_ns(),unix_time_ns=time.time_ns(),line=line))
        with MemoryProbe(interval_s=.01) as memory,(run/'stdout.log').open('wb') as so,(run/'stderr.log').open('wb') as se:
            row['popen_perf_ns']=time.perf_counter_ns();row['popen_unix_ns']=time.time_ns()
            process=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=so,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
            row['pid']=process.pid
            print('MEMORY_START',arm,process.pid,flush=True)
            thread=threading.Thread(target=reader,args=(process.stderr,se),daemon=True);thread.start()
            memory.start(process.pid)
            row['exit']=process.wait();thread.join();memory.stop();sampled=memory.result()
            c.save(run/'memory.json',sampled)
            row['finished_perf_ns']=time.perf_counter_ns()
        row.update(terminal=True,finished=time.time());c.save(run/'result.json',row)
        print('MEMORY_END',arm,row['exit'],len(sampled['samples']),flush=True)
        assert row['exit']==0
        raw=c.read(run/'peer-result.json') if arm=='llama' else json.loads((run/'stdout.log').read_text().splitlines()[-1])
        ids=raw['predicted_ids'] if arm=='llama' else raw['generated_ids']
        assert ids==plan['expected_baseline_ids']
        assert raw['decode_input_ids']==plan['fixed']['decode_input_ids']
        if arm=='llama':assert raw['prompt_ids']==plan['fixed']['prompt_ids'] and raw['context_capacity']==256
        else:assert raw['visible_tokens']==159 and raw['source_id']==plan['source_id'] and raw['fixed_decode']
        assert sampled['gpu_setup_error'] is None and sampled['thread_error'] is None
        boundaries={m['name']:m['timestamp_ns'] for m in row['markers']}
        assert all(k in boundaries for k in ('model_loaded','ready_before_prefill','prefill_complete','inference_complete'))
        samples=[r for r in sampled['samples'] if r.get('process_running')]
        windows={}
        for name,start,end in [('loading',row['popen_perf_ns'],boundaries['model_loaded']),
            ('post_load_preparation',boundaries['model_loaded'],boundaries['ready_before_prefill']),
            ('prefill',boundaries['ready_before_prefill'],boundaries['prefill_complete']),
            ('decode',boundaries['prefill_complete'],boundaries['inference_complete'])]:
            rows=[r for r in samples if start<=r['timestamp_ns']<=end]
            windows[name]=dict(start_ns=start,end_ns=end,sample_count=len(rows),
                **{k:stats([r[k] for r in rows if r.get(k) is not None]) for k in
                ('working_set_bytes','private_commit_bytes','gpu_dedicated_bytes','gpu_shared_bytes')})
        infer=[r for r in samples if boundaries['prefill_complete']<=r['timestamp_ns']<=boundaries['inference_complete']]
        assert len(infer)>=10
        assert all(r['gpu_dedicated_available'] and r['gpu_shared_available'] for r in infer)
        gaps=[(n['timestamp_ns']-p['timestamp_ns'])/1e6 for p,n in zip(samples,samples[1:])]
        results[arm]=dict(executed=True,exit=0,pid=row['pid'],image=images[arm],same_fixed_predictions=True,
            peaks=sampled['peaks'],samples=len(sampled['samples']),running_samples=len(samples),
            max_sample_gap_ms=max(gaps),sample_cost_ms=stats([r['sample_duration_ns']/1e6 for r in samples]),
            adapter_instances=sorted({name.split('_luid_',1)[-1] for r in infer for name in r['gpu_instances']}),
            missing_GPU_while_decode=0,marker_windows=windows)
        c.save(run/'summary.json',results[arm])
    c.save(out/'summary.json',dict(executed=True,terminal_zero=3,arms=results,throughput_claim=False,
        units='bytes; MiB=2^20; CPU working set/private commit and GPU shared usage are separate, overlapping accounting views, never added.',
        method='Reused PSAPI/PDH external sampler initialized before target creation, 10ms requested interval. No CUDA/NVML context, new synchronization or tensor access.',
        limits=['One fresh process per image; no statistical memory distribution or causally isolated allocation attribution.',
            'Sampled GPU peaks are lower bounds, not exact maxima; actual timestamp gaps and missing-counter windows retained.',
            'Marker arrival windows include stderr delivery delay. Engine loading/preparation sub-boundaries differ.',
            'Working set includes mapped/shared resident pages; private commit is commit charge. Neither measures disk pagefile occupancy.',
            'Per-process WDDM GPU counters can include cross-process shared resources; do not sum PIDs as card usage.',
            'No throughput samples from these monitored runs enter the existing unmonitored performance windows.'],
        primary_metric_definitions=['https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex',
            'https://devblogs.microsoft.com/directx/gpus-in-the-task-manager/']))
    print('CURRENT_MEMORY_OBSERVATIONS_COMPLETE',flush=True)
if __name__=='__main__':main()
