# Qwen3.5-2B 推理架构实验消费者

这是检验 Compute/Graph 架构的独立测试产物，不是已交付的推理引擎。使用本地官方权重运行完整24层CUDA纯文本计算，关闭MTP和视觉。
消费者只调用公共接口，模型格式、tokenizer和生成策略仍由消费者负责。

`prepare.py` 校验原输入清单的13个文件，输出权重偏移和token IDs；Python只做输入准备与独立参考。
`main.cc` 用一份模型语义图表达prefill、带状态的多token continuation和decode，在启动时预列本次需要的token数，
以有限shape图族一次冷编译。每个实际child有两个Invocation槽；运行时只查找已准备入口，不临时建图、编译或padding。
conv/GDN状态真实反馈，KV使用固定容量且只更新新增行；失败使当前请求失效。

六个BF16 GQA attention共用一份BatchSchema，每次执行共享同一owned layout与metadata输入。
schema容量为最大预列chunk，具体Q/output行数等于当前chunk，KV可见长度由layout和positions表达。
例如23-token prefill→4-token continuation→单token decode使用同图族的23/4/1三个child；head深度等模型常数保持固定。
每步沿原Invocation执行`graph::batch::prepare`→bind→`prepare_replay`→submit→Completion，再反馈状态和读取token。
两个槽不授权并发覆盖同一个Model的tokens、KV或状态；`evaluate`须顺序调用。退出先drain槽，再结束运行时和释放数据。

构建消费者的已安装SDK须包含CUDA `compute;graph;graph_progress;compute_stream;mem` 产品。
CMake只查包和链接，不构建原生依赖。`--inputs DIR` 指向准备后的输入；可用选项：

- `--continuation IDS`：prefill后追加多token输入；`--steps N`指定生成阶段数。
- `--progress direct|scheduler`：默认direct；scheduler在原槽上准备进度驱动，复用同一提交机制。
- `--replay commands|prefer-capture`：默认commands；后者使用公共Graph分段录制，日志区分实际录制与复用。
- `--decode-ids FILE`：固定单token输入带，允许跨过预测EOS；若同时给steps，须等于输入数加一。正常生成遇到endoftext或im_end停止。
- `--trace DIR --trace-level decisions`：仅导出logits与最后hidden；默认full还导出状态。路由写入DIR/routes，不增加图输出。
- `--layer0-probe DIR`：诊断时另行发布layer0边界并比较实际路由；诊断图会影响合法融合，因此与普通图分别冷准备，均计入启动时间。

加载沿现有FileResourcePipeline，用两个8MiB pinned暂存读取原权重范围并上传，保留320个device分配和持久目标租约。
完整Model／ready／首token计时包含文件关闭、管线退休和临时运行时销毁。新进程未清OS页缓存，不能称冷盘加载。
`step_seconds`包含输入上传、layout准备、绑定、replay准备、提交、等待及token读回；首次shape编译在启动时完成，trace导出不在step内。
`seconds`和`submit_seconds`是更窄子段，不可直接与另一引擎的完整decode相比；完整启动至首token看`first_token_elapsed_seconds`。

本次有限图族已完成原128+31旅程的64份hidden/logits逐byte对照，以及23/4/1 scheduler＋capture旅程的6份对照。
两组独立性能窗口确认准备开销减少；decode小差异反向，未证明稳定提速。详见[有限图族实测](../../docs/evidence/performance/qwen-finite-family-2026-10-20.json)，
最新同窗指标见[当前工作](../../docs/developer/current-work.md)。报告中的compiled storage保留unknown计数，不等于完整显存峰值。
另有独立的[进程内存／显存采样](../../docs/evidence/performance/qwen-memory-current-2026-10-20.json)：GPU峰值为采样下界，
驻留集、private commit和GPU共享内存分别记录；mmap与文件缓存会影响归属，不能将进程差直接当作全机RAM节省。

`reference.py`是独立Torch参考，候选不会读取参考状态或结果。固定输入与向量相同属于回归检查，独立质量验收仍未完成；
BF16舍入、归约和RoPE诊断见[底座审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
原输入位于仓库`.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，不复制权重或SDK。
