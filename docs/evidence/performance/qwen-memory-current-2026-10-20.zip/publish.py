"""Freeze memory-only observations with explicit accounting and timing limits."""
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(path):
    path=path.resolve();data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def same(row):return identity(Path(row['path']))==row
def main():
    observed=read(S/'observations/summary.json');assert observed['executed'] and observed['terminal_zero']==3 and not observed['throughput_claim']
    for arm in observed['arms'].values():
        assert arm['executed'] and arm['exit']==0 and arm['same_fixed_predictions'] and same(arm['image'])
        assert arm['missing_GPU_while_decode']==0 and arm['marker_windows']['decode']['sample_count']>=10
    plan=read(A/'qwen-finite-family/performance-prepared/plan.json')
    source_inputs=[]
    for row in plan['frozen']:
        path=Path(row['path'])
        if path.suffix.lower() in ('.safetensors','.gguf','.ids') or path.name in ('weights.tsv','fixed-inputs.json'):
            assert same(row),row['path'];source_inputs.append(row)
    assert any(Path(r['path']).suffix=='.safetensors' for r in source_inputs)
    assert any(Path(r['path']).suffix=='.gguf' for r in source_inputs)
    save(S/'source-input-freshness.json',dict(inputs=source_inputs,matched_retained_fixed_plan=True,
        check_time='After the completed observations; no model payload or input was copied or modified by this task.'))
    attribution=read(S/'source-attribution.json')
    for row in attribution['inputs']:
        path=ROOT/row['path'];now=identity(path)
        assert now['sha256']==row['sha256'] and now['bytes']==row['bytes'],row['path']
        if path.suffix in ('.cc','.cpp','.h'):
            snapshot=S/'source-attribution-snapshot'/row['path']
            snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(path.read_bytes())
    review=A/'common-chain-review-2026-10-20/source-review.json'
    copied_review=S/'reviews/common-chain-review.json';copied_review.parent.mkdir(exist_ok=True);copied_review.write_bytes(review.read_bytes())
    docs=[]
    for rel in ('docs/developer/current-work.md','tools/qwen35_text/README.md'):
        path=ROOT/rel;snapshot=S/'documentation'/rel;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(path.read_bytes())
        docs.append(dict(relative=rel,current=identity(path),snapshot=identity(snapshot)))
    save(S/'documentation-freeze.json',docs)
    dest=ROOT/'docs/evidence/performance/qwen-memory-current-2026-10-20.zip'
    files=sorted(p for p in S.rglob('*') if p.is_file() and
        not set(p.relative_to(S).parts)&{'tmp','__pycache__'} and
        p.name not in {'publication.json','payload-sha256.json'} and
        p.suffix.lower() in {'.py','.json','.log','.md','.cc','.cpp','.h'})
    rows=[]
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in files:
            row=dict(**identity(path),member=path.relative_to(S).as_posix());rows.append(row);archive.writestr(row['member'],path.read_bytes())
        archive.writestr('payload-sha256.json',json.dumps(rows,indent=2,ensure_ascii=False).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        for row in rows:assert hashlib.sha256(archive.read(row['member'])).hexdigest()==row['sha256']
    report=dict(date='2026-10-20',status='three_current_memory_observations_executed',observations=observed,
        current_product=read(A/'qwen-finite-family/adoption.json')['product'],input_freshness=identity(S/'source-input-freshness.json'),
        interpretation=dict(
            GPU='Sampled dedicated GPU peaks: current Hyle3895.074MiB, prior pinned Hyle3897.074MiB, peer4041.090MiB. Current/prior near-equality is not evidence of a stable2MiB saving.',
            resident_process='Observed OS peak working set: current1076.668MiB, peer4166.586MiB. Includes resident mapped/shared pages; this is not whole-machine physical RAM saved.',
            private_commit='Observed OS peak private commit: current5608.906MiB, peer5000.098MiB. Current is higher; commit is not resident RAM and must not be added to GPU counters.',
            engine_boundary='FileResourcePipeline versus peer loader/mmap can change which process owns resident file pages; global file cache is outside a per-process-only comparison. The numbers alone do not isolate allocation causes.',
            resolution='10ms requested, actual largest running-sample gaps16.095/16.709/16.492ms for prior/current/peer; prefill windows only6/8/9 samples. GPU peaks are sampled lower bounds.',
            throughput='No monitored-run timings are admitted into prior unmonitored throughput windows; the same31 fixed decode inputs and all32 predictions matched.'),
        source_attribution=attribution,
        attribution_limits='Raw320 weights borrow original device pointers; no full duplicate bank was found in the inspected route. Loader mmap lifetime is confirmed. Exact heap/pinned/driver/commit byte decomposition and systemwide file-cache residency remain unmeasured.',
        scoped_common_chain_review=dict(identity=identity(review),new_confirmed_omission=None,builds=0,GPU_runs=0,
            limits='Focused source-only common family/result/state/retirement review; not whole-platform runtime validation or overall completion.'),
        documentation=docs,
        archive=dict(**identity(dest),payloads=len(rows),CRC_checked=True,all_payload_SHA256_checked=True))
    target=dest.with_suffix('.json');save(target,report)
    save(S/'publication.json',dict(report=identity(target),archive=identity(dest),payloads=len(rows),passed=True))
    print('MEMORY_OBSERVATIONS_PUBLISHED',len(rows),dest.stat().st_size,flush=True)
if __name__=='__main__':main()
