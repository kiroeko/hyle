"""Offline comparison of the single authorized GDN working-IO behavior run."""
from pathlib import Path
import hashlib, json, re

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-current-closure-20261026/full-window/two-turn-timing/02-hyle_mtp'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(p):
    return dict(path=str(p.resolve()), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def report(p):
    return json.loads(next(s for s in reversed(p.read_text(encoding='utf-8').splitlines())
                           if s.startswith('{')))

TIME_NAMES = ['seconds', 'tokens_per_second', 'clock_unix', 'unix_ns', 'unix_ms']

def normalize(v):
    if isinstance(v, list):
        return [normalize(x) for x in v]
    if isinstance(v, dict):
        return {k: normalize(x) for k, x in v.items()
                if not any(t in k for t in TIME_NAMES)}
    return v

def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, baseline=a, actual=b)]
    if isinstance(a, dict):
        rows = []
        for k in sorted(set(a) | set(b)):
            rows += differences(a[k], b[k], path + '.' + k) if k in a and k in b else [
                dict(path=path + '.' + k, baseline=a.get(k), actual=b.get(k))]
        return rows
    if isinstance(a, list):
        if len(a) != len(b):
            return [dict(path=path, baseline_length=len(a), actual_length=len(b))]
        return [d for i, (x, y) in enumerate(zip(a, b))
                for d in differences(x, y, f'{path}[{i}]')]
    return [] if a == b else [dict(path=path, baseline=a, actual=b)]

actual = report(W / 'run/stdout.log')
baseline = report(B / 'stdout.log')
save(W / 'run/report.json', actual)
delta = differences(normalize(baseline), normalize(actual))
save(W / 'run/non-time-differences.json', delta)

def lines(p):
    return p.read_text(encoding='utf-8').splitlines()

def clock_normalized(s):
    return re.sub(r'([A-Za-z0-9_]*(?:seconds|tokens_per_second|clock_unix[A-Za-z0-9_]*|unix_ns|unix_ms)\s*[=:]\s*)[-+0-9.eE]+',
                  r'\1<TIME>', s)

bs, cs = lines(B / 'stderr.log'), lines(W / 'run/stderr.log')
stderr_delta = differences([clock_normalized(s) for s in bs],
                           [clock_normalized(s) for s in cs], 'stderr')
save(W / 'run/stderr-non-time-differences.json', stderr_delta)

def prepared(ls):
    rows = []
    for line_no, s in enumerate(ls):
        if not s.startswith('prepared '):
            continue
        v = dict(re.findall(r'(\w+)=([^ ]+)', s))
        rows.append(dict(index=len(rows), line=line_no, rows=int(v['T']),
                         visible=int(v['visible']), replay=v['replay'],
                         recorded=int(v['capture_recorded']), reused=int(v['capture_reused'])))
    return rows

bp, cp = prepared(bs), prepared(cs)
changes = []
for before, after in zip(bp, cp):
    if before['recorded'] != after['recorded'] or before['reused'] != after['reused']:
        changes.append(dict(index=before['index'], rows=before['rows'], visible=before['visible'],
                            baseline={k: before[k] for k in ['recorded', 'reused']},
                            candidate={k: after[k] for k in ['recorded', 'reused']}))

# This second comparison explains only the exact logged capture counters.
# All other non-time stderr fields, including replay mode, remain compared.
def explain_capture(s):
    return re.sub(r'(capture_(?:recorded|reused)=)\d+', r'\1<CAPTURE_COUNT>', clock_normalized(s)) \
        if s.startswith('prepared ') else clock_normalized(s)

unexpected = differences([explain_capture(s) for s in bs], [explain_capture(s) for s in cs], 'stderr')
save(W / 'run/stderr-unexpected-differences.json', unexpected)
capture = dict(baseline=dict(calls=len(bp), recorded=sum(p['recorded'] for p in bp),
                             reused=sum(p['reused'] for p in bp)),
               candidate=dict(calls=len(cp), recorded=sum(p['recorded'] for p in cp),
                              reused=sum(p['reused'] for p in cp)), changes=changes)
save(W / 'run/capture-comparison.json', capture)

summary = dict(status='PASS_SINGLE_K1_BEHAVIOR' if not delta and not unexpected and len(bp) == len(cp) == 68 else 'DIFFERENCES_RETAINED_STOP',
               GPU='RELEASED', process=read(W / 'run/process.json'),
               image=read(W / 'ready.json')['image'], baseline_image=read(B / 'result.json')['image'],
               stdout_non_time_difference_count=len(delta),
               stderr_non_time_difference_count=len(stderr_delta),
               stderr_unexpected_difference_count=len(unexpected), capture=capture,
               source=read(W / 'source-pins.json'),
               limits=['One candidate process only; baseline is existing frozen2a94, not the new b346 control.',
                       'b346 CPU-forward/shared-selector default GPU semantics are source-neutral; this run is not a throughput comparison.',
                       'Only named original timing keys are excluded from stdout. No state/ledger/route/budget field is excluded.',
                       'Capture differences are exact prepared-line counters, not an API trace or range-key attribution.',
                       'No independent device-byte, old-reader failure-injection, or unknown-completion test in this run.',
                       'Programmed GDN copy cost remains source-derived, not physical API traffic measurement.'],
               raw={name: pin(W / 'run' / name) for name in ['command.json', 'stdout.log', 'stderr.log', 'process.json']})
save(W / 'behavior-summary.json', summary)
print(json.dumps({k: summary[k] for k in ['status', 'process', 'stdout_non_time_difference_count',
    'stderr_non_time_difference_count', 'stderr_unexpected_difference_count', 'capture']}, indent=2))
