"""Package the closed finite experiment; no build, model or device operation."""
from pathlib import Path
import hashlib, json, zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
C = R / '.scratch/inference-current-control-b346-20261026'
B = R / '.scratch/inference-current-closure-20261026'
P = R / 'docs/evidence/performance/mtp-fixed-gdn-work-io-screen-2026-10-26.json'
Z = P.with_suffix('.zip')

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

s = read(W / 'final-summary.json')
screen = read(W / 'screen/summary.json')
behavior = read(W / 'behavior-summary.json')
candidate = read(W / 'ready.json')
control = read(C / 'ready.json')
assert s['status'] == 'MECHANISM_PASS_NO_NET_THROUGHPUT_GAIN_CLOSED'
assert len(s['processes']) == 8 and all(x['exit'] == 0 for x in s['processes'])
assert behavior['stdout_non_time_difference_count'] == 0

files = {}
def add(p, member):
    assert p.is_file() and member not in files
    assert p.suffix.lower() not in {'.obj', '.exe', '.dll', '.lib', '.exp', '.pdb', '.bin'}
    files[member] = p

for name in ['prepare.py', 'build.py', 'run.py', 'analyze.py', 'screen.py', 'publish.py',
             'plan.json', 'build-plan.json', 'source.patch', 'source-pins.json',
             'ready.json', 'runtime.json', 'object-map.json', 'link-inputs.json',
             'run-plan.json', 'behavior-summary.json', 'final-summary.json',
             'independent-review-performance.json', 'byte-check-plan.json']:
    add(W / name, 'candidate/' + name)
for directory in ['compile', 'link/process', 'run', 'screen']:
    for p in sorted((W / directory).rglob('*')):
        if p.is_file() and p.suffix in {'.json', '.log'}:
            add(p, 'candidate/' + p.relative_to(W).as_posix())
for name in ['build.py', 'plan.json', 'build-plan.json', 'source-pins.json', 'ready.json',
             'runtime.json', 'object-map.json', 'link-inputs.json']:
    p = C / name
    if p.is_file():
        add(p, 'control/' + name)
for directory in ['compile', 'link/process']:
    for p in sorted((C / directory).rglob('*')):
        if p.is_file() and p.suffix in {'.json', '.log'}:
            add(p, 'control/' + p.relative_to(C).as_posix())
for name in ['ready-current.json', 'runtime-current.json']:
    add(B / name, 'frozen2a94/' + name)
for name in ['command.json', 'result.json', 'stdout.log', 'stderr.log']:
    add(B / 'full-window/two-turn-timing/02-hyle_mtp' / name, 'frozen2a94/behavior/' + name)

# Small retained runners are source references, not another copied SDK/tree.
references = [
    '.scratch/inference-synchronous-step-report-20261025/check_host.py',
    '.scratch/mtp-performance-convergence-20261025/baseline/window.py',
    '.scratch/mtp-native-seed-candidate-20261025/screen.py',
    '.scratch/qwen-mtp-window-20261022/window.py',
    '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
    '.scratch/qwen-mtp-final-window-20261024/turns.py',
    '.scratch/shared-execution-20261021/observer.py',
    '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
]
for name in references:
    p = R / name
    add(p, 'retained-runners/' + p.relative_to(R / '.scratch').as_posix())
schedule = R / '.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt'
add(schedule, 'workload/performance64.txt')

manifest = [dict(member=name, **pin(p)) for name, p in sorted(files.items())]
with zipfile.ZipFile(Z, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, p in sorted(files.items()):
        archive.write(p, name)
    archive.writestr('archive/manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(Z) as archive:
    assert archive.testzip() is None
    members = archive.infolist()
archive_pin = dict(**pin(Z), members=len(members), logical_bytes=sum(x.file_size for x in members), CRC='PASS')

report = dict(
    status=s['status'], date='2026-10-26', GPU='RELEASED', CPU='NO_ACTIVE_BUILD_OR_MODEL',
    scope='Private K1 fixed GDN working ingress and both-prefix outputs, retaining independent canonical selected Snapshots. Closed after one behavior process and a finite6 timing +2 memory process screen.',
    decision='Do not integrate, resample, or perform the planned byte check. Five fewer actual recordings produced no observed net throughput gain on this finite workload. No causal breakdown of the slowdown is claimed.',
    source=read(W / 'source-pins.json'), product_edits=0, canonical_integration=False,
    images=dict(control=control['image'], candidate=candidate['image']),
    build=dict(Model_TUs=2, other_TUs=0, SDK_builds=0,
               control=dict(compile=control['compile'], link=control['link'], actual_dependencies=control['actual_dependencies']),
               candidate=dict(compile=candidate['compile'], link=candidate['link'], actual_dependencies=candidate['actual_dependencies']),
               closure='Both arms replace only the Model app object in the same retained2a94 221 absolute +13 system link inputs. Current b346 control includes CPU-options forwarding/shared selector; candidate is d71 on the identical baseline. No private sampling or diagnostic clock hook.'),
    mechanism=dict(eligibility='Existing K1 PreferCapture and actual caller-owned same-resource output qualification, without a backend whitelist.',
                   lifecycle='Original WorkingStateCopy/CopyBatch/RetainedResources chain: copy canonical input to fixed scratch and actually retire; Graph reads/writes fixed original-resource blocks; selected-prefix GDN and hidden egress share one original copy submit/wait; independent canonical Head and ledger publish only after real copy retirement. Original unbind and unique try_write precede reuse.',
                   budget='Working scratch/Copy metadata use the existing allocation/workspace budget; canonical selected states keep the existing cache pools. No second owner/manager, no fake ready, no overwrite of escaped readers.',
                   programmed_cost=s['programmed_extra_cost']),
    first_behavior=dict(process=s['first_behavior'], reference='Previously recorded frozen2a94 behavior only, not a throughput sample.',
                        full_stdout_non_time_differences=0, capture=behavior['capture'],
                        stderr_unexpected_differences=behavior['stderr_unexpected_difference_count']),
    screen=dict(timing_order=['B', 'C', 'C', 'B', 'B', 'C'], independent_memory_order=['B', 'C'],
                timeout_seconds_per_process=120, processes=s['processes'], all_exit0=True,
                stdout_non_time_differences=0, unexpected_stderr_differences=0,
                comparison_gate='Every report, including the new control first sample, is compared with frozen2a94 after original named timing exclusions only. Exact per-arm prepared capture lines are compared with preserved behavior stderr; no route, budget, state, ledger, RNG, ID or work field is excluded.',
                metrics=screen['metrics'], comparisons=screen['comparisons'],
                actual_capture=dict(control=behavior['capture']['baseline'], candidate=behavior['capture']['candidate'], changed_prepares=behavior['capture']['changes'])),
    memory=dict(sampled_peaks={arm: value['sampled_peaks'] for arm, value in screen['memory'].items()},
                delta=s['sampled_memory_delta'],
                qualification='One independent memory process per arm; PSAPI/PDH sampled maxima are lower bounds. The96MiB sampled dedicated-GPU delta is not the111.796875MiB programmed payload, exact physical allocation, or a physical cap. No inference from the small host working-set difference.'),
    byte_check=dict(status='PLANNED_NOT_IMPLEMENTED_OR_RUN', plan=pin(W / 'byte-check-plan.json')),
    limits=s['limits'] + [
        'The6 timed processes contain no private instrumentation or profiler; original logging and all added copy/wait costs remain in the natural endpoints. The earlier single behavior wall is not pooled into timing.',
        'Both decode timing sample ranges are disjoint with candidate slower; combined ranges overlap. Three points do not establish a stable regression or noise distribution. Prefill improvement overlaps and is not signed as a stable gain.',
        'No current API trace certifies exact range keys or attribution. Only complete original prepared-line recording/reuse counters are observed.',
        'Source plan and Ready files preserve their pre-run checkpoints, including BUILT_NOT_RUN/GPU_runs0. Later process logs and this report are authoritative.',
        'No independent GDN bytes or retained-old-reader/unknown-completion fault check was executed; source review alone does not certify those runtime cases.',
        'Control Ready and shared object/runtime cache remain available for reuse; no cleanup was executed.'
    ],
    HTTP=0, added_tests=0, archive=archive_pin)
save(P, report)
save(W / 'publication.json', dict(report=pin(P), archive=archive_pin))
print(json.dumps(dict(report=pin(P), archive=archive_pin)))
