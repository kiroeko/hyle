"""Private source-only two-way GDN working IO pilot; no build/run."""
from pathlib import Path
import difflib,hashlib,json
W=Path(__file__).resolve().parent;R=W.parents[1]
def pin(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
p=R/'engine/models/qwen35/main.cc';raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
before=W/'before/engine/models/qwen35/main.cc';before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
nl='\r\n'if b'\r\n'in raw else'\n';s=raw.decode().replace('\r\n','\n')
s=s.replace('HiddenOutputCopy','WorkingStateCopy')
anchor='struct WorkingStateCopy final {\n'
assert s.count(anchor)==1
s=s.replace(anchor,'''// Private finite pilot only: retain the original eligibility and retirement owner.
constexpr bool fixed_gdn_work_io_pilot = true;
struct WorkingStateCopy final {
  std::size_t hidden_count = 0, gdn_fields = 0;
  std::size_t input_index(std::size_t field) const noexcept { return hidden_count + field; }
  std::size_t output_index(std::size_t field, std::size_t row, std::size_t prefixes) const noexcept {
    return hidden_count + gdn_fields + field * prefixes + row;
  }
''')
anchor='  // Copy controls borrow the original Queue. Their accepted Completion, not\n'
extra=r'''  void submit_and_wait(const std::shared_ptr<ColdResources> &resources) {
    constexpr std::array<c::CopyPhase, 1> phases{};
    check(invocation.prepare_replay(phases, ranges));
    check(retirement.reserve(resources));
    auto submitted = invocation.submit();
    if (!submitted) { retirement.reject(); (void)take(std::move(submitted)); }
    // Same original single-phase/no-producer capacity proof as hidden egress.
    auto accepted = c::CopyBatchUpdate::take(std::move(invocation), std::move(*submitted));
    HYLE_FATAL_ASSERT(accepted.has_value()); update = std::move(*accepted);
    std::array<c::Completion *, 1> original;
    const auto sources = c::detail::CopyStreamAccess::retirement_sources(update, original);
    HYLE_FATAL_ASSERT(sources && *sources == 1);
    HYLE_FATAL_ASSERT(retirement.attach(*original[0]).ok());
    check(update.wait());
  }
'''
assert s.count(anchor)==1;s=s.replace(anchor,extra+anchor)
begin=s.index('  void copy_selected_hidden_outputs(StepState &step) {\n')
end=s.index('  void validate_mtp_snapshot(',begin)
s=s[:begin]+r'''  void copy_fixed_gdn_inputs(StepState &step) {
    auto &copy = step.phase->hidden_output[slot_index];
    if (!copy.program.valid() || !copy.gdn_fields) return;
    step.hidden_output = &copy; // Abort also owns a possibly accepted ingress.
    const auto count = copy.scratch.size(); std::size_t field = 0;
    copy.ranges.clear();
    for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
      for (const auto &member : step.members)
        for (const auto *source : {&member.base->state[layer].history, &member.base->state[layer].recurrent}) {
          const auto index = copy.input_index(field++);
          const auto bytes = take(copy.scratch[index].description.required_bytes());
          check(copy.invocation.bind_source({static_cast<std::uint32_t>(index)}, *source));
          check(copy.invocation.bind_mutable({static_cast<std::uint32_t>(count + index)}, std::move(copy.scratch[index].writer)));
          copy.ranges.push_back({{static_cast<std::uint32_t>(index)}, {static_cast<std::uint32_t>(count + index)}, {0}, 0, 0, bytes});
        }
    if (field != copy.gdn_fields) throw std::runtime_error("fixed GDN ingress extent differs");
    copy.submit_and_wait(resources_);
    for (std::size_t field_index = 0; field_index < copy.gdn_fields; ++field_index) {
      const auto index = copy.input_index(field_index);
      auto writer = take(copy.update.take_mutable({static_cast<std::uint32_t>(count + index)}));
      copy.readers[index] = take(writer.publish());
    }
    hyle::Status terminal;
    if (!take(copy.recover(terminal))) throw std::runtime_error("fixed GDN ingress retirement is pending");
    check(terminal); // Copy bindings withdrawn; original Graph gets readonly leases below.
  }

  void copy_selected_work_outputs(StepState &step) {
    if (!step.hidden_output) return;
    auto &copy = *step.hidden_output; auto &phase = *step.phase; auto &run = *step.run;
    const auto count = copy.scratch.size();
    copy.ranges.clear();
    // Export all fixed working outputs before ANY take_append revokes results.
    // Unselected prefixes survive only through Graph withdrawal/writer recovery.
    for (std::size_t j = 0; j < step.members.size(); ++j)
      for (std::size_t row = 0; row < phase.prefix_rows; ++row)
        copy.readers[j * phase.prefix_rows + row] = take(inference::retain_output(run,
            phase.child->output(phase.carry_ports[j][row])));
    std::size_t field = 0;
    if (copy.gdn_fields) for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
      for (std::size_t j = 0; j < step.members.size(); ++j) {
        const auto &ports = phase.layers[layer].sequences[j];
        for (const auto *prefixes : {&ports.history_prefix, &ports.recurrent_prefix}) {
          for (std::size_t row = 0; row < phase.prefix_rows; ++row)
            copy.readers[copy.output_index(field, row, phase.prefix_rows)] =
                take(inference::retain_output(run, phase.child->output(prefixes->at(row))));
          ++field;
        }
      }
    const auto bind = [&](std::size_t index, c::LeasePool &pool) {
      const auto bytes = take(copy.scratch[index].description.required_bytes());
      check(copy.invocation.bind_source({static_cast<std::uint32_t>(index)}, copy.readers[index]));
      check(copy.invocation.bind_mutable({static_cast<std::uint32_t>(count + index)},
          take(pool.allocate(bytes, cache::state_pool_alignment))));
      copy.ranges.push_back({{static_cast<std::uint32_t>(index)}, {static_cast<std::uint32_t>(count + index)}, {0}, 0, 0, bytes});
    };
    for (std::size_t j = 0; j < step.members.size(); ++j) {
      const auto last = verifies_prefix(phase.family->role) ? step.members[j].accepted_tokens - 1 : 0;
      bind(j * phase.prefix_rows + last, hidden_pool);
      if (verifies_prefix(phase.family->role) && step.members[j].accepted_tokens > 1)
        bind(j * phase.prefix_rows + last - 1, hidden_pool);
    }
    field = 0;
    if (copy.gdn_fields) for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
      for (const auto &member : step.members) {
        const auto last = verifies_prefix(phase.family->role) ? member.accepted_tokens - 1 : 0;
        bind(copy.output_index(field++, last, phase.prefix_rows), state_pools[layer].history);
        bind(copy.output_index(field++, last, phase.prefix_rows), state_pools[layer].recurrent);
      }
    // Hidden and selected GDN share this original egress submission/wait.
    copy.submit_and_wait(resources_);
    const auto ready = [&](std::size_t index) {
      auto writer = take(copy.update.take_mutable({static_cast<std::uint32_t>(count + index)}));
      return take(writer.publish()); // Exact complete original state extent, after real success.
    };
    field = 0;
    if (copy.gdn_fields) for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer))
      for (auto &member : step.members) {
        const auto last = verifies_prefix(phase.family->role) ? member.accepted_tokens - 1 : 0;
        member.next->state[layer].history = ready(copy.output_index(field++, last, phase.prefix_rows));
        member.next->state[layer].recurrent = ready(copy.output_index(field++, last, phase.prefix_rows));
      }
    for (std::size_t j = 0; j < step.members.size(); ++j) {
      auto &member = step.members[j];
      const auto last = verifies_prefix(phase.family->role) ? member.accepted_tokens - 1 : 0;
      member.next->carry_hidden = ready(j * phase.prefix_rows + last);
      if (verifies_prefix(phase.family->role) && member.accepted_tokens > 1)
        member.next->prior_hidden = ready(j * phase.prefix_rows + last - 1);
    }
    hyle::Status terminal;
    if (!take(copy.recover(terminal))) throw std::runtime_error("fixed work output retirement is pending");
    check(terminal);
    // All working readers remain readonly until original Graph unbind below.
  }

'''+s[end:]
begin=s.index('  void initialize_hidden_output(Phase &phase, std::size_t slot) {\n')
end=s.index('  void initialize_slot(',begin)
s=s[:begin]+r'''  void initialize_hidden_output(Phase &phase, std::size_t slot) {
    if (!drafts_token(phase.family->role) ||
        recursive_mtp() || max_drafts() != 1 ||
        phase.replay_modes[slot] != g::ReplayMode::kPreferCapture) return;
    auto &copy = phase.hidden_output[slot];
    if (copy.retirement.pending() || copy.update.in_flight() || copy.invocation.in_flight())
      throw std::runtime_error("fixed working IO still retains original copy work");
    if (!copy.program.valid()) {
      const auto description = dense(precision.activation_type(), {1, hidden});
      const auto hidden_count = cache::multiply(phase.family->requests, phase.prefix_rows);
      for (const auto &ports : phase.carry_ports) for (auto port : ports) {
        const auto &output = phase.child->output(port);
        if (!output.caller_owned()) return;
        validate_state_output(output, description);
      }
      auto context = execution.common_context(); auto queue = execution.common_queue();
      if (!context || !queue) return;
      std::vector<c::TensorDesc> fields;
      bool fixed_gdn = fixed_gdn_work_io_pilot;
      if (fixed_gdn) for (std::size_t layer = 0; layer < state_schema.size(); ++layer) if (geometry.is_gdn(layer)) {
        const auto &schema = state_schema[layer];
        for (const auto &ports : phase.layers[layer].sequences) {
          fields.push_back(schema.history); fields.push_back(schema.recurrent);
          for (std::size_t row = 0; row < phase.prefix_rows; ++row) {
            const auto &history = phase.child->output(ports.history_prefix.at(row));
            const auto &recurrent = phase.child->output(ports.recurrent_prefix.at(row));
            if (!history.caller_owned() || !recurrent.caller_owned()) { fixed_gdn = false; continue; }
            validate_state_output(history, schema.history); validate_state_output(recurrent, schema.recurrent);
            if (take(execution.resource_for(history.storage)) != execution.device() ||
                take(execution.resource_for(recurrent.storage)) != execution.device()) fixed_gdn = false;
          }
        }
      }
      if (!fixed_gdn) fields.clear(); // Original generated/nonqualified GDN path remains.
      const auto count = cache::add(hidden_count, cache::multiply(fields.size(), cache::add(phase.prefix_rows, 1)));
      if (!count || count > UINT32_MAX / 2) throw std::runtime_error("fixed working IO capacity overflow");
      std::vector<c::TensorDesc> descriptions(hidden_count, description);
      descriptions.insert(descriptions.end(), fields.begin(), fields.end());
      for (const auto &field : fields) for (std::size_t row = 0; row < phase.prefix_rows; ++row) descriptions.push_back(field);
      std::vector<Tensor> scratch; std::vector<c::CopyResourceSpec> specs;
      scratch.reserve(count); specs.reserve(count * 2);
      for (const auto &desc : descriptions) {
        const auto bytes = take(desc.required_bytes()); Tensor value; value.description = desc;
        value.pool = take(c::LeasePool::create(execution.device(), bytes,
            {.max_blocks = 1, .backing_alignment = cache::state_pool_alignment, .resource_budget = execution_budget}));
        value.writer = take(value.pool.allocate(bytes, cache::state_pool_alignment));
        scratch.push_back(std::move(value)); specs.push_back({execution.device(), bytes});
      }
      for (const auto &desc : descriptions) specs.push_back({execution.device(), take(desc.required_bytes())});
      auto copy_bytes = cache::multiply(hidden_count, take(description.required_bytes()));
      for (const auto &desc : fields) copy_bytes = cache::add(copy_bytes, take(desc.required_bytes()));
      const auto max_copies = cache::add(hidden_count, fields.size());
      auto program = take(c::CopyBatchProgram::prepare(**context, specs,
          {.max_resources = static_cast<std::uint32_t>(count * 2),
           .max_copies = static_cast<std::uint32_t>(max_copies), .max_phases = 1,
           .max_bytes = copy_bytes, .resource_budget = execution_budget}));
      auto invocation = take(c::CopyBatchInvocation::create(program, **queue));
      std::vector<c::ReadLease> readers(count); std::vector<c::CopyRange> ranges; ranges.reserve(max_copies);
      // All allocation/factory work precedes this no-throw cold publication.
      copy.scratch = std::move(scratch); copy.readers = std::move(readers); copy.ranges = std::move(ranges);
      copy.program = std::move(program); copy.invocation = std::move(invocation);
      copy.hidden_count = hidden_count; copy.gdn_fields = fields.size();
    } else if (!copy.invocation.valid())
      copy.invocation = take(c::CopyBatchInvocation::create(copy.program, *take(execution.common_queue())));
    check(copy.restore_writers());
  }

'''+s[end:]
anchor='''      if (has_mtp(role)) prepare_draft_append(step, role);
      for (std::size_t i = 0; i < state_schema.size(); ++i) if (geometry.is_gdn(i))
'''
assert s.count(anchor)==1;s=s.replace(anchor,anchor.replace('      for (std::size_t i','      copy_fixed_gdn_inputs(step);\n      std::size_t gdn_field = 0;\n      for (std::size_t i'))
old='''          check(run.bind(ports.history, descriptions.history, step.members[j].base->state[i].history));
          check(run.bind(ports.recurrent, descriptions.recurrent, step.members[j].base->state[i].recurrent));
          const auto bind_state = [&](V port, c::LeasePool &pool) {
            const auto &output = phase.child->output(port);
            if (output.caller_owned())
              check(run.bind(output.value, output.description, take(pool.allocate(take(output.description.required_bytes()), cache::state_pool_alignment))));
          };
          for (auto row = phase.prefix_rows; row != 0; --row) {
            bind_state(ports.history_prefix[row - 1], state_pools[i].history);
            bind_state(ports.recurrent_prefix[row - 1], state_pools[i].recurrent);
          }
'''
new='''          auto *work = step.hidden_output && step.hidden_output->gdn_fields ? step.hidden_output : nullptr;
          const auto field = gdn_field; gdn_field += 2;
          check(run.bind(ports.history, descriptions.history,
              work ? work->readers[work->input_index(field)] : step.members[j].base->state[i].history));
          check(run.bind(ports.recurrent, descriptions.recurrent,
              work ? work->readers[work->input_index(field + 1)] : step.members[j].base->state[i].recurrent));
          const auto bind_state = [&](V port, c::LeasePool &pool, std::size_t state_field, std::size_t row) {
            const auto &output = phase.child->output(port);
            if (output.caller_owned()) {
              auto writer = work ? std::move(work->scratch[work->output_index(state_field, row, phase.prefix_rows)].writer)
                  : take(pool.allocate(take(output.description.required_bytes()), cache::state_pool_alignment));
              check(run.bind(output.value, output.description, std::move(writer)));
            }
          };
          for (auto row = phase.prefix_rows; row != 0; --row) {
            bind_state(ports.history_prefix[row - 1], state_pools[i].history, field, row - 1);
            bind_state(ports.recurrent_prefix[row - 1], state_pools[i].recurrent, field + 1, row - 1);
          }
'''
assert s.count(old)==1;s=s.replace(old,new)
anchor='''      for (std::size_t i = 0; i < state_schema.size(); ++i) if (geometry.is_gdn(i))
        for (std::size_t j = 0; j < outputs.size(); ++j) {
          const auto &ports = phase.layers[i].sequences[j];
'''
assert s.count(anchor)==1;s=s.replace(anchor,'      if (!step.hidden_output || !step.hidden_output->gdn_fields)\n'+anchor)
s=s.replace('      copy_selected_hidden_outputs(step);','      copy_selected_work_outputs(step);')
after=W/'source/engine/models/qwen35/main.cc';after.parent.mkdir(parents=True,exist_ok=True);after.write_bytes(s.replace('\n',nl).encode())
patch=''.join(difflib.unified_diff(raw.decode().splitlines(True),after.read_bytes().decode().splitlines(True),fromfile='a/engine/models/qwen35/main.cc',tofile='b/engine/models/qwen35/main.cc'))
(W/'source.patch').write_bytes(patch.encode())
save(W/'source-pins.json',dict(before=pin(before),canonical=pin(p),after=pin(after),patch=pin(W/'source.patch')))
print(json.dumps(pin(after)))
