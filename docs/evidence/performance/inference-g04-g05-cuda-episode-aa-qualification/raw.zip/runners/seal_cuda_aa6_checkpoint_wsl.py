from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path('/mnt/c/public/project-hyle/hyle')
p=Path('/root/hyle-scratch/compute-unified/g04-cuda-encoded-p1-output-6')
dest=root/'evidence/performance/inference-g04-g05-cuda-episode-aa-qualification'
dest.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=p/'cuda-encoded-aa.json';r=json.loads(a.read_text());assert r['gate']=='PASS' and not r['errors'] and len(r['runs'])==16
for row in r['runs']:assert sha(Path(row['log']))==row['sha256'] and len(row['ratios'])==3
shutil.copyfile(a,dest/a.name)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(a,a.name)
 for row in r['runs']:z.write(row['log'],'raw/'+Path(row['log']).name)
 z.write(Path(__file__),'runners/'+Path(__file__).name)
 source=Path('/root/hyle-scratch/compute-unified/g04-cuda-encoded-p1-source-6')
 for name in ('bench/inference_resident_sdpa/cuda_encoded_page_bench.cc','bench/inference_resident_sdpa/cuda_encoded_p1/validate_aa.py','bench/inference_resident_sdpa/cuda_encoded_p1/contract.json'):
  z.write(source/name,'inputs/'+name)
values=[v for row in r['runs'] for v in row['ratios'].values()]
receipt=dict(kind='CUDA_EPISODE_INTERLEAVE_FULL16_WORKLOAD_AA_CHECKPOINT',verdict='PASS_FULL_AA_ONLY_PRODUCT_CONTROLS_PENDING',
 attempt='6',source_commit='2f01f4d991d58973d1cb1f0882f2fc86bd4b9ebc',product_candidate='982676cb05a6e6244e66e0a596347aa96043617b',
 aa_gate=r['gate'],runs=16,shape_ratios=48,ratio_range=[min(values),max(values)],
 immutable_aa_receipt_sha256=sha(a),raw_zip_sha256=sha(dest/'raw.zip'),
 numeric_receipt='evidence/correctness/inference-g04-g05-cuda-episode-interleave-numeric-rebind/receipt.json',
 numeric_receipt_sha256=r['identity']['numeric_preflight'],
 scope='Both native/selected same-implementation routes,primary/placement,execution/allocation dual orders; original3 geometries,16 arithmetic groups of2048 complete episode pairs,all elapsed tails retained.',
 next='Continue SAME live attempt6 originaln15/31 product/control sequence and strictverify. Do not rerun these matching A/A or claim product performance PASS before terminal.',
 limits=['Intermediate actual A/A receipt,not a terminal performance manifest or wholeG04/G05 acceptance','Original4/40/200/500 failures andattempt5hash setupFAIL preserved','No new product/math/SDK/sanitizer execution;only finitebenchmark build and A/A','Full timing totals remain with live parent; do not substitute observer elapsed for terminal cumulative time'])
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'gate':r['gate'],'runs':16,'range':receipt['ratio_range'],'path':str(dest)}))
