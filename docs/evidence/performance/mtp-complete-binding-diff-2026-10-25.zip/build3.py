"""One authorized private Graph TU/link. No model or GPU run in this script."""
from pathlib import Path
import importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');pins=b.read(W/'source-pins3.json')
def verify(item):
 p=Path(item['path']);p=p if p.is_absolute() else R/p
 a=b.pin(p)
 assert a['bytes']==item['bytes'] and a['sha256']==item['sha256'],str(p)
for item in pins:verify(item)
verify(plan['reused_app'])
for item in plan['reused_report_and_Graph_objects']:verify(item)
for item in plan['reused_merged_lifetime_objects']:verify(item['new'])
compile_command=b.read(W/'compile-command3.json')['command'];link=b.read(W/'link-command3.json')['command']
old=b.read(R/'.scratch/mtp-finish-phase-20261025/link2/command.json')['command']
expected=[]
for a in old:
 if a.lower()==str(R/'.scratch/mtp-native-seed-candidate-20261025/graph2/unit.obj').lower():a=str(W/'graph3/unit.obj')
 if a.lower().startswith('/out:'):a='/OUT:'+str(W/'link3/consumer.exe')
 if a.lower().startswith('/implib:'):a='/IMPLIB:'+str(W/'link3/consumer.lib')
 if a.lower().startswith('/pdb:'):a='/PDB:'+str(W/'link3/consumer.pdb')
 expected.append(a)
assert link==expected
retained=[b.pin(Path(a)) for a in link if re.match(r'^[A-Za-z]:[\\/]',a) and Path(a).is_file()]
b.save(W/'build-before3.json',{'sources':pins,'retained_link_inputs':retained,'exact_singleGraph_replacement_in_old_link':True,'compile_command':b.pin(W/'compile-command3.json'),'link_command':b.pin(W/'link-command3.json')})
env=b.environment(compile_command[0]);b.execute(compile_command,W/'graph3',env,120)
raw=b.read(W/'graph3/dependencies.json')['Data'];actual=[Path(raw['Source']),*[Path(a) for a in raw['Includes']]]
restore=b.read(W/'dependency-restore.json');mapping={str(R/i['private']['path']).lower():i for i in restore['restored_original_dependencies']}
seen=set();dependencies=[];unexpected=[]
for p in actual:
 a=b.pin(p)
 if p.is_relative_to(R):
  if str(p).lower() in mapping:
   original=mapping[str(p).lower()]['original'];assert a['sha256']==original['sha256'];seen.add(str(p).lower());kind='original_actual_header_exact'
  elif p in [W/'source2/src/graph/executable.cc',W/'binding_diff.inc',W/'logical_trace.h']:kind='private_instrumentation_or_source'
  else:unexpected.append(str(p));kind='UNEXPECTED_REPOSITORY_DEPENDENCY'
  dependencies.append({'kind':kind,**a})
 elif 'nvtx3' in str(p):
  dependencies.append({'kind':'same_cached_NVTX_toolchain_header',**a})
assert not unexpected,unexpected
assert set(mapping)==seen,{'missing_original_headers':list(set(mapping)-seen)}
for item in pins:verify(item)
b.save(W/'graph3/source-pins.json',dependencies)
b.save(W/'dependency-check3.json',{'status':'PASS','original_actual_headers_exact':len(seen),'original_source_and_header_total':len(seen)+1,'private_instrumentation_files':2,'unexpected_canonical_or_other_repository_dependencies':unexpected,'actual_sourceDependencies':b.pin(W/'graph3/dependencies.json'),'actual_pins':b.pin(W/'graph3/source-pins.json')})
b.execute(link,W/'link3',env,120)
dll=R/'.scratch/mtp-finish-phase-20261025/link2/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(dll,W/'link3'/dll.name)
for item in pins:verify(item)
for item in retained:verify(item)
for item in dependencies:verify(item)
b.save(W/'ready.json',{'status':'COMPILED_LINKED_NOT_RUN','image':b.pin(W/'link3/consumer.exe'),'graph_object':b.pin(W/'graph3/unit.obj'),'CPU_companion':b.pin(W/'link3'/dll.name),'source_pins':dependencies,'retained_link_inputs':retained,'compiler_TUs':1,'app_core_CUDA_SDK_TUs':0,'links':1,'GPU_processes':0,'HTTP':0,'exact_singleGraph_replacement_in_old_link':True,'dependency_check':b.pin(W/'dependency-check3.json')})
print('READY_NOT_RUN',json.dumps(b.pin(W/'link3/consumer.exe')),flush=True)
