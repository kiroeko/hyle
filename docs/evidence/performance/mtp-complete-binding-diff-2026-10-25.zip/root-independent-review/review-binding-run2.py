from pathlib import Path
from collections import Counter
import hashlib
import json

root = Path(__file__).resolve().parents[2]
log = root / '.scratch/mtp-complete-binding-diff-20261025/run2/stderr.log'
raw = log.read_bytes()
events, ports, descriptions, headers = [], [], {}, {}
finish_count = 0
for line in raw.decode('utf-8').splitlines():
    if not line.startswith(('BIND_', 'FINISH_META ', 'FINISH_POD ')):
        continue
    tag, _, body = line.partition(' ')
    fields = dict(word.split('=', 1) for word in body.split())
    if tag == 'BIND_EVENT':
        events.append({k: int(v) for k, v in fields.items()})
    elif tag == 'BIND_PORT':
        ports.append({k: int(v) for k, v in fields.items()})
    elif tag == 'BIND_DESC':
        descriptions[int(fields['diff']), fields['side']] = fields
    elif tag in ('BIND_POD', 'BIND_END', 'FINISH_POD'):
        assert tag not in headers
        headers[tag] = {k: int(v) for k, v in fields.items()}
    elif tag == 'FINISH_META':
        assert int(fields['normal_return']) == 1 and int(fields['seen']) == 511
        finish_count += 1

pod = headers['BIND_POD']
assert finish_count == headers['FINISH_POD']['records'] == 68
assert headers['FINISH_POD']['overflow'] == 0
assert all(pod[k] == 0 for k in ('event_overflow', 'difference_overflow', 'concurrent_skips'))
assert pod['events'] == len(events) == headers['BIND_END']['events'] == 5005
assert pod['differences'] == len(ports) == headers['BIND_END']['differences'] == 2701
assert len(descriptions) == 2 * len(ports)
assert [v['i'] for v in events] == list(range(len(events)))
assert [v['i'] for v in ports] == list(range(len(ports)))
misses = [v for v in events if v['kind'] == 3]
for event in misses:
    assert event['expected_ports'] == event['examined']
    assert event['equal'] + event['changed'] == event['examined']
    assert event['missing_old'] == event['extra_old'] == 0
    assert event['changed'] > 0
assert sum(v['changed'] for v in misses) == len(ports)
for port in ports:
    assert events[port['event']]['kind'] == 3
    assert port['flags'] == 16  # Only offset changed in this actual journey.
    old, new = (descriptions[port['i'], side] for side in ('old', 'new'))
    assert {k: v for k, v in old.items() if k not in ('side', 'offset')} == {
        k: v for k, v in new.items() if k not in ('side', 'offset')}
    assert old['offset'] != new['offset']

shapes = Counter()
for port in ports:
    desc = descriptions[port['i'], 'new']
    shapes[port['output'], desc['type'], desc['dims'], int(desc['required_bytes'])] += 1
result = {
    'status': 'PASS_FINITE_RAW_DIAGNOSTIC_REVIEW',
    'raw': {'path': str(log.relative_to(root)), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()},
    'events': len(events), 'differences': len(ports), 'valid_key_misses': len(misses),
    'examined_ports': sum(v['examined'] for v in misses),
    'all_changed_ports_offset_only': True,
    'event_kinds': dict(Counter(v['kind'] for v in events)),
    'changed_shapes': [dict(output=k[0], type=k[1], dimensions=k[2], bytes=k[3], count=v)
                       for k, v in shapes.items()],
    'new_build_or_process': False,
    'scope': 'Independent raw metadata check only; no TPS or causal savings claim.',
}
Path(__file__).with_name('binding-run2-review.json').write_bytes(
    (json.dumps(result, indent=2) + '\n').encode('utf-8'))
print(json.dumps(result, indent=2))
