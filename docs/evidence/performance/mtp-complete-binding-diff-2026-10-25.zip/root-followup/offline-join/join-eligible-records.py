"""Join existing traces only when every logical seq/record role/order matches."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,re,statistics
R=Path.cwd();W=Path(__file__).resolve().parent;OLD=R/'.scratch/mtp-finish-phase-20261025'
def load(p):return json.loads(p.read_bytes())
def pin(p):return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def stats(v):return {'count':len(v),'total_ms':sum(v),'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} if v else {'count':0}
a=[json.loads(l) for l in (OLD/'extracts/runtime.jsonl').read_text().splitlines()];nv=[json.loads(l) for l in (OLD/'extracts/nvtx.jsonl').read_text().splitlines()]
new=load(W/'records.json');metas={int(k):v for k,v in new['FINISH_meta'].items()};ranges=new['range_decision_rows'];events=new['events']
oldroots={r['uint64Value']:r for r in nv if r['label'] and r['label'].startswith('hyle/episode')}
assert len(oldroots)==len(metas)==68
for seq,r in oldroots.items():
 m={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',r['label'])};n=metas[seq]
 for k in ['role','target_T','R','context','frontier','lag']:assert m[k]==n[k],(seq,k,m[k],n[k])
def prep(p):return [tuple(map(int,x)) for x in re.findall(r'^prepared T=(\d+) visible=(\d+).*capture_recorded=(\d+) capture_reused=(\d+)$',p.read_text(),re.M)]
assert prep(OLD/'trace1/native-stderr.log')==prep(W/'run2/stderr.log') and len(prep(W/'run2/stderr.log'))==68
joined=[]
for rp in [r for r in nv if r['label']=='hyle/prepare_replay']:
 seq=rp['uint64Value'];local=[x for x in a if x['globalTid']==rp['globalTid'] and rp['start']<=x['start'] and x['end']<=rp['end']]
 begins=[x for x in local if 'StreamBeginCapture' in x['api']];ends=[x for x in local if 'StreamEndCapture' in x['api']]
 actual=[e for e in events if e['seq']==seq and e['kind']==8]
 assert len(begins)==len(ends)==len(actual)
 for ordinal,(b,e,rec) in enumerate(zip(begins,ends,actual)):
  assert b['end']<=e['start']
  inner=[x for x in local if b['end']<=x['start'] and x['end']<=e['start']]
  launch=Counter(x['api'] for x in inner if 'LaunchKernel' in x['api']);nk=sum(launch.values())
  lag=metas[seq]['lag'];geometry=(0,55) if nk==37 and lag==0 else (0,53) if nk==41 and lag==1 else ((57 if lag==0 else 55),1269) if nk==738 else None
  assert geometry==(rec['begin'],rec['count']),(seq,ordinal,nk,geometry,rec)
  limit=begins[ordinal+1]['start'] if ordinal+1<len(begins) else rp['end']
  native=[x for x in local if e['end']<=x['start'] and x['end']<=limit and ('GraphExecUpdate' in x['api'] or 'GraphInstantiate' in x['api'])]
  assert len(native)==1 and native[0]['returnValue']==0,(seq,ordinal,native)
  row=next(r for r in ranges if r['seq']==seq and (r['begin'],r['count'])==geometry)
  eligible=row['begin']==0 and row['counterfactual_existing_candidate_hit']['fixed_hidden_inputs_only']
  joined.append({'seq':seq,'ordinal_in_prepare':ordinal,'range_begin':geometry[0],'range_steps':geometry[1],'context':metas[seq]['context'],'frontier':metas[seq]['frontier'],'lag':lag,'captured_kernel_launch_API_signature':dict(launch),'source_kernel_calls_total':nk,
    'capture_begin_API':{k:b[k] for k in ['api','start','end','returnValue']},'capture_end_API':{k:e[k] for k in ['api','start','end','returnValue']},
    'capture_span_ms':(e['end']-b['start'])/1e6,'following_native_API':{k:native[0][k] for k in ['api','start','end','returnValue']},'native_API_ms':(native[0]['end']-native[0]['start'])/1e6,
    'capture_through_native_API_end_ms':(native[0]['end']-b['start'])/1e6,'eligible_small_hidden_record':eligible,'counterfactual_scope':'Existing-comparisonprojection only, not a simulatednewcachetrajectory.'})
assert len(joined)==32
eligible=[r for r in joined if r['eligible_small_hidden_record']];assert len(eligible)==12
out={'status':'ALL32_SEQ_ROLE_RANGE_ORDER_MATCHED_BY_CAPTURE_API_SIGNATURE','scope':'Offline match of complete directbindingdiagnostic to priorsolefinish-phaseNVTXtrace. No newprofile/nativeprocess. No originalGraph/nodeID lineage claim.',
 'inputs':{'old_runtime_extract':pin(OLD/'extracts/runtime.jsonl'),'old_NVTX_extract':pin(OLD/'extracts/nvtx.jsonl'),'old_stderr':pin(OLD/'trace1/native-stderr.log'),'new_records':pin(W/'records.json'),'new_stderr':pin(W/'run2/stderr.log')},
 'join_gates':{'all68_seq_role_T_context_frontier_lag_equal':True,'all68_prepared_T_visible_record_reuse_equal':True,'all32_capture_window_count_and_order_equal':True,'perwindow_unique_kernelLaunch_API_signature_matches_actualrecord_geometry':True,'onefollowing_nativeAPI_per_capture_return0':True},
 'signature_mapping':{'37':'lag0 small(0,55)','41':'lag1 small(0,53)','738':'body(57,1269)lag0 or(55,1269)lag1'},
 'all32':joined,'eligible12':eligible,
 'eligible12_summary':{'capture_span':stats([x['capture_span_ms'] for x in eligible]),'following_native_API':stats([x['native_API_ms'] for x in eligible]),'capture_through_native_API_end':stats([x['capture_through_native_API_end_ms'] for x in eligible]),'native_API_counts':dict(Counter(x['following_native_API']['api'] for x in eligible))},
 'all_small17_summary':{'capture_span':stats([x['capture_span_ms'] for x in joined if x['range_begin']==0]),'capture_through_native_API_end':stats([x['capture_through_native_API_end_ms'] for x in joined if x['range_begin']==0])},
 'limits':['Oldtrace rangegeometry is identified by exactsource/role plus uniqueobservedcapture kernelAPIcount signature and full32record order, not directly by originalgraphID; unsupportedoriginal-node-lineagewarning remains.',
 'Only BeginCapture.start to EndCapture.end and the immediatelyfollowing nativeAPI are observed here; capture-throughnativeend contains nestedcalls/gaps. Do not add these views, allAPI durations or whole107msreplay.',
 'These are previousprofile CPU/APIwall windows, not sameprocessTPS, reclaimableCPU, GPUactivitytime or cost saved by a proposedcopy. They do not include all otherprepare/replaymetadata aroundthewindow.',
 'NewdirectfixedPODdiagnostic made noAPItrace. Logicalwork andrecordgeometry match; deviceaddresses/absoluteclocks differ and are notcrossjoined.',
 'No stagingimplementation orcopy/waitcost measured. Old12eligiblewindowtimes boundthisdescriptivesubsetonly; no guaranteedperformanceimprovement.']}
(W/'eligible-record-api-windows.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':out['status'],'eligible12_summary':out['eligible12_summary'],'all_small17_summary':out['all_small17_summary'],'rows':[(x['seq'],x['range_steps'],x['capture_span_ms'],x['following_native_API']['api'],x['native_API_ms'],x['capture_through_native_API_end_ms']) for x in eligible]},indent=2))
