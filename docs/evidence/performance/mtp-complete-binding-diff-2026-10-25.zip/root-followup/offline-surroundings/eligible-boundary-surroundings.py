"""One offline attribution pass around the already-joined capture windows."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import statistics

R = Path.cwd()
W = Path(__file__).resolve().parent
P = R / '.scratch/mtp-finish-phase-20261025'


def load(path):
    return json.loads(path.read_bytes())


def lines(name):
    return [json.loads(line) for line in (P / 'extracts' / f'{name}.jsonl').read_text().splitlines()]


def pin(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def stats(values):
    return dict(count=len(values), total_ms=sum(values), median_ms=statistics.median(values),
                min_ms=min(values), max_ms=max(values)) if values else dict(count=0)


def union_ns(intervals):
    total = 0
    end = -1
    for a, b in sorted(intervals):
        total += max(0, b - max(a, end))
        end = max(end, b)
    return total


runtime, nvtx = lines('runtime'), lines('nvtx')
activities = [(kind, x) for kind in ('kernel', 'copy', 'memset') for x in lines(kind)]
join = load(W / 'eligible-record-api-windows.json')
original = load(P / 'analysis.json')
replays = {x['uint64Value']: x for x in nvtx if x['label'] == 'hyle/prepare_replay'}


def activity_window(start, end):
    found = [(kind, x) for kind, x in activities if x['start'] < end and x['end'] > start]
    return dict(execution_union_ms=union_ns([(max(start, x['start']), min(end, x['end']))
                                             for _, x in found]) / 1e6,
                overlapping_activity_counts=dict(Counter(kind for kind, _ in found)))


def api_summary(rows):
    groups = defaultdict(list)
    for x in rows:
        groups[x['api']].append((x['end'] - x['start']) / 1e6)
    return {name: stats(values) for name, values in sorted(groups.items())}


rows = []
all_before_APIs = []
for record in join['eligible12']:
    seq = record['seq']
    rp = replays[seq]
    local = [x for x in runtime if x['globalTid'] == rp['globalTid']
             and rp['start'] <= x['start'] and x['end'] <= rp['end']]
    begin, native_end = record['capture_begin_API']['start'], record['following_native_API']['end']
    assert record['ordinal_in_prepare'] == 0
    later = [x for x in local if x['start'] >= native_end]
    cleanup = later[:3]
    # The actual CUDA end_capture destroys its temporary graph, then Graph's
    # finish_preparation calls QueueSequence::finish followed by Completion::wait.
    assert [x['api'] for x in cleanup] == ['cudaGraphDestroy_v10000',
                                          'cudaEventRecord_v3020',
                                          'cudaEventSynchronize_v3020'], (seq, cleanup)
    assert all(x['returnValue'] == 0 for x in cleanup)
    next_begin = next((x['start'] for x in later if 'StreamBeginCapture' in x['api']), rp['end'])
    before = [x for x in local if x['end'] <= begin]
    all_before_APIs.extend(before)
    before_launch = [x for x in before if 'Launch' in x['api'] or 'Memcpy' in x['api']]
    assert not before_launch
    cleanup_end = cleanup[-1]['end']
    row = dict(seq=seq, context=record['context'], frontier=record['frontier'], lag=record['lag'],
               range_begin=0, range_steps=record['range_steps'],
               prepare_replay=dict(start=rp['start'], end=rp['end']),
               unseparated_before_BeginCapture=dict(start=rp['start'], end=begin,
                    wall_ms=(begin-rp['start'])/1e6, api_summary=api_summary(before),
                    **activity_window(rp['start'], begin)),
               capture_through_native_API_end_ms=record['capture_through_native_API_end_ms'],
               anchored_after_native_end=dict(start=native_end, end=cleanup_end,
                    wall_ms=(cleanup_end-native_end)/1e6,
                    API_rows=[{k: x[k] for k in ('api', 'start', 'end', 'returnValue', 'correlationId')}
                              for x in cleanup], **activity_window(native_end, cleanup_end)),
               unseparated_until_next_BeginCapture_or_replay_end=dict(start=cleanup_end, end=next_begin,
                    wall_ms=(next_begin-cleanup_end)/1e6,
                    **activity_window(cleanup_end, next_begin)),
               full_replay_GPU=activity_window(rp['start'], rp['end']))
    rows.append(row)


def capture_group(records):
    per_api = defaultdict(list)
    for record in records:
        per_api[record['following_native_API']['api']].append(record['native_API_ms'])
    return dict(count=len(records),
                capture_span=stats([x['capture_span_ms'] for x in records]),
                following_native_API={name: stats(v) for name, v in per_api.items()},
                capture_through_native_API_end=stats([x['capture_through_native_API_end_ms'] for x in records]))


all_records = join['all32']
small = [x for x in all_records if x['range_begin'] == 0]
body = [x for x in all_records if x['range_begin'] > 0]
assert len(rows) == 12 and len(small) == 17 and len(body) == 15
capture_total = sum(x['capture_through_native_API_end_ms'] for x in all_records)
outer = original['same_trace_outer_episode']
replay_total = outer['outer_phase']['hyle/prepare_replay']['total_ms']
prepare_total = outer['outer_phase']['hyle/prepare']['total_ms']
cleanup_api = [x for row in rows for x in row['anchored_after_native_end']['API_rows']]
out = dict(
    status='OFFLINE_EXISTING_CAPTURE_SURROUNDINGS_CHECK_COMPLETE',
    scope='No new GPU, profile, build, model, network, or public-evidence mutation.',
    inputs=dict(join=pin(W/'eligible-record-api-windows.json'), analysis=pin(P/'analysis.json'),
                runtime=pin(P/'extracts/runtime.jsonl'), nvtx=pin(P/'extracts/nvtx.jsonl'),
                kernel=pin(P/'extracts/kernel.jsonl'), copy=pin(P/'extracts/copy.jsonl'),
                memset=pin(P/'extracts/memset.jsonl')),
    source_readonly_references=dict(
        frozen_Graph=pin(R/'.scratch/mtp-native-seed-candidate-20261025/source/executable.cc'),
        CUDA_source=pin(R/'src/compute_backend_cuda/cuda_backend.cc'),
        queue_source=pin(R/'src/compute/device.cc')),
    eligible12=dict(rows=rows,
        before_begin_API_summary=api_summary(all_before_APIs),
        anchored_cleanup_API=api_summary(cleanup_api),
        anchored_native_end_through_EventSynchronize_return=stats([
            x['anchored_after_native_end']['wall_ms'] for x in rows]),
        before_begin_unseparated=stats([x['unseparated_before_BeginCapture']['wall_ms'] for x in rows]),
        after_sync_unseparated=stats([x['unseparated_until_next_BeginCapture_or_replay_end']['wall_ms'] for x in rows]),
        any_observed_GPU_overlap=any(x['full_replay_GPU']['execution_union_ms'] for x in rows)),
    same66_decode_trace=dict(
        prepare_wall_ms=prepare_total, replay_child_wall_ms=replay_total,
        eligible12_capture_through_native_ms=sum(x['capture_through_native_API_end_ms'] for x in join['eligible12']),
        all_small17=capture_group(small), all_body15=capture_group(body),
        disjoint_all32_capture_through_native_ms=capture_total,
        replay_outside_these32_windows_ms=round(replay_total-capture_total, 6),
        prepare_outside_replay_ms=round(prepare_total-replay_total, 6),
        replay_execution_GPU_union_ms=outer['outer_phase_activity']['hyle/prepare_replay']['execution_gpu_union_ns']['total_ms'],
        prepare_execution_GPU_union_ms=outer['outer_phase_activity']['hyle/prepare']['execution_gpu_union_ns']['total_ms'],
        submit_execution_GPU_union_ms=outer['outer_phase_activity']['hyle/submit']['execution_gpu_union_ns']['total_ms']),
    source_boundary_facts=[
        'Frozen executable.cc:9618 onward performs shared prepare_invocation_bindings/routes/input-source/queue/report work before the range loop. No per-range boundary marker exists before CommandCaptureAccess::begin(:9834).',
        'CUDA begin_capture(:1245-1269) performs no warmup kernel. An optional4B status-word malloc precedes StreamBeginCapture, but none occurs in these12 replay prefixes; only cudaGetDeviceProperties is observed. No execution GPU overlap occurs anywhere in their full replay ranges.',
        'CUDA end_capture calls temporary cudaGraphDestroy(:1350) after Update/Instantiate. Frozen Graph then calls finish_preparation(sequence)(:9750-9756,9861): sequence.finish followed by completion.wait. The immediately following API sequence Destroy/Record/Synchronize is unique and return0 for all12.',
        'After that synchronization, stable-identity/key bookkeeping and next-range selection/begin are not separately marked. The remaining interval is not uniquely chargeable to the small range.',
    ],
    conclusions=[
        'The eligible12 observed capture-through-native subset is4.259603ms. No additional eager GPU warmup is observed around it; only the anchored small cleanup sequence can be separately identified.',
        'The largest identified replay cost is the15 body-range capture-through-native windows78.431404ms, not the small-range17 windows6.308232ms. Both are CPU/API wall observations with zero concurrent observed GPU activity; not recoverable-time estimates.',
        'The22.356950ms replay residual includes common preparation, key/variant traversal, capture cleanup and unmarked gaps across all66 calls; it cannot be allocated to the eligible12. Another30.595468ms prepare lies outside replay.',
        'The56.628347ms visible GPU union belongs to submit overlap, not prepare/replay warmup. Replay GPU union is0; prepare GPU union is0.438298ms.',
        'Next evidence-led scope is the body-range repeated capture/instantiation and large mutable state binding contract, with copy/immutable-state/retirement costs included. Small ingress remains a narrow candidate, without any claim to recover the107ms replay total.',
    ],
    limits=[
        'Full true per-range preparation boundaries are not present in the existing NVTX. Shared prelude and inter-range bookkeeping remain unknown.',
        'Runtime extracts do not expose graph/event argument handles. The cleanup attribution uses the unique immediate same-thread API sequence and normal source call order, not a direct graph/event handle or call-stack join.',
        'API wall intervals and GPU execution union are different views; nested API intervals must not be added to parent capture windows.',
        'No cross-trace address or original graph/node identity join, no new performance claim, no direct subtraction from the historical unprofiled1.54ms episode algebra.',
    ])
(W/'eligible-boundary-surroundings.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({k: v for k, v in out['eligible12'].items() if k != 'rows'}, indent=2))
print(json.dumps(out['same66_decode_trace'], indent=2))
