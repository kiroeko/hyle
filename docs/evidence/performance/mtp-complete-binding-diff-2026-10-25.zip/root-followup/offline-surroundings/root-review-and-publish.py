from pathlib import Path
import hashlib
import json
import zipfile

R = Path.cwd()
W = R / '.scratch/mtp-complete-binding-diff-20261025'
J = R / 'docs/evidence/performance/mtp-complete-binding-diff-2026-10-25.json'
Z = J.with_suffix('.zip')
S = Path(__file__).resolve().parent

def load(p):
    return json.loads(p.read_bytes())

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def eq(a, b):
    assert abs(a - b) < 0.0000011, (a, b)

d = load(W / 'eligible-boundary-surroundings.json')
j = load(W / 'eligible-record-api-windows.json')
for v in [*d['inputs'].values(), *d['source_readonly_references'].values()]:
    assert pin(R / v['path']) == v, v
t = d['same66_decode_trace']
assert len(j['all32']) == 32
small = [v for v in j['all32'] if v['range_begin'] == 0]
body = [v for v in j['all32'] if v['range_begin'] > 0]
assert len(small) == 17 and len(body) == 15
for group, summary in [(small, t['all_small17']), (body, t['all_body15'])]:
    # Recompute from the original exact API timestamps, not summary durations.
    raw_sum = sum(v['following_native_API']['end'] - v['capture_begin_API']['start'] for v in group) / 1e6
    eq(raw_sum, summary['capture_through_native_API_end']['total_ms'])
    for v in group:
        assert v['following_native_API']['returnValue'] == 0
    spans = sorted((v['capture_begin_API']['start'], v['following_native_API']['end']) for v in group)
    assert all(a[1] <= b[0] for a, b in zip(spans, spans[1:]))
eq(t['all_small17']['capture_through_native_API_end']['total_ms'] + t['all_body15']['capture_through_native_API_end']['total_ms'], t['disjoint_all32_capture_through_native_ms'])
eq(t['replay_child_wall_ms'] - t['disjoint_all32_capture_through_native_ms'], t['replay_outside_these32_windows_ms'])
eq(t['prepare_wall_ms'] - t['replay_child_wall_ms'], t['prepare_outside_replay_ms'])
assert len(d['eligible12']['rows']) == 12
for v in d['eligible12']['rows']:
    assert [x['api'] for x in v['anchored_after_native_end']['API_rows']] == ['cudaGraphDestroy_v10000', 'cudaEventRecord_v3020', 'cudaEventSynchronize_v3020']
    assert v['full_replay_GPU']['execution_union_ms'] == 0
eq(sum(v['anchored_after_native_end']['wall_ms'] for v in d['eligible12']['rows']), 0.224217)
assert t['replay_execution_GPU_union_ms'] == 0
eq(t['prepare_execution_GPU_union_ms'], 0.438298)
eq(t['submit_execution_GPU_union_ms'], 56.628347)
review = dict(status='PASS_FINITE_OFFLINE_TIMESTAMP_AND_PIN_REVIEW',
              source=pin(W / 'eligible-boundary-surroundings.json'),
              source_and_raw_pins_verified=True, exact_timestamps_recomputed=True,
              record_windows_disjoint=True, no_new_GPU_build_download=True,
              claim='Observed API/wall attribution only; not recoverable time or new TPS')
review_path = S / 'replay-surroundings-review.json'
review_path.write_text(json.dumps(review, indent=2) + '\n', encoding='utf-8', newline='\n')

files = {
    'root-followup/offline-surroundings/eligible-boundary-surroundings.py': W / 'eligible-boundary-surroundings.py',
    'root-followup/offline-surroundings/eligible-boundary-surroundings.json': W / 'eligible-boundary-surroundings.json',
    'root-followup/offline-surroundings/root-review.json': review_path,
    'root-followup/offline-surroundings/root-review-and-publish.py': Path(__file__).resolve(),
}
with zipfile.ZipFile(Z) as src:
    original = {n: src.read(n) for n in src.namelist()}
assert not (set(original) & set(files)), 'Already appended; inspect rather than duplicate'
original.update({name: p.read_bytes() for name, p in files.items()})
with zipfile.ZipFile(Z, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in original.items():
        out.writestr(name, data)
with zipfile.ZipFile(Z) as check:
    assert check.testzip() is None and len(check.namelist()) == len(original)
metadata = load(J)
metadata['offline_replay_surroundings'] = dict(
    status=d['status'], same66_decode_trace=t,
    eligible12_cleanup_ms=0.224217,
    unseparated_before_small_begin_ms=2.884520,
    unseparated_after_small_sync_ms=0.511857,
    evidence='archive:root-followup/offline-surroundings/eligible-boundary-surroundings.json',
    independent_root_review=review,
    limits=d['limits'], conclusions=d['conclusions'])
metadata['archive'].update(pin(Z), members=len(original))
J.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(review=review['status'], archive=metadata['archive']), ensure_ascii=False))
