"""Publish existing finite metadata observations only. No build/run/GPU/network."""
from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/mtp-complete-binding-diff-20261025';A=json.loads((W/'analysis.json').read_bytes())
def pin(p):return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
ready=json.loads((W/'ready.json').read_bytes());dep=json.loads((W/'dependency-check4.json').read_bytes());plan=json.loads((W/'plan.json').read_bytes())
# Inventory only exact known outputs, never remove anything.
cleanup={}
for label,folders in [('superseded_first_capacity_run',['graph3','link3']),('final_diagnostic_retain_for_now',['graph4','link4'])]:
 files=[]
 for folder in folders:
  for name in ['unit.obj','unit.pdb','consumer.exe','consumer.exp','consumer.lib','consumer.pdb','hyle_ggml_cpu_gdn_scale_v3.dll']:
   p=W/folder/name
   if p.is_file():files.append({**pin(p),'relative_repository_path':p.relative_to(R).as_posix()})
 cleanup[label]={'files':files,'count':len(files),'logical_bytes':sum(i['bytes'] for i in files),'action':'NOT_DELETED; root owns exact guarded cleanup. DLL is a hardlink; logicalbytes are not claimed freedphysicalbytes.'}
save(W/'cleanup-candidates.json',cleanup)
range_summary={k:{f:v for f,v in d.items() if f!='copy_new_changed_unique_bytes_by_record'} for k,d in A['range_decisions'].items()}
shape_summary={k:{f:v for f,v in d.items() if f!='offset_pairs'} for k,d in A['shape_classes'].items()}
root_review=R/'.scratch/inference-system-review-20261025/binding-run2-review.json';root_parser=R/'.scratch/inference-system-review-20261025/review-binding-run2.py'
assert json.loads(root_review.read_bytes())['raw']['sha256']==A['raw_stderr']['sha256']
summary={
 'status':'COMPLETE_CAPTURE_KEY_DIAGNOSTIC_WORK_PASS_SMALL_INGRESS_DESIGN_ONLY','observed_on':'2026-10-25',
 'scope':'Original real BF16 Qwen3.5-2B greedy K1 two-turn128outputs, private one-Graph-TU metadata diagnostic. No productoptimization, newperformancebaseline, tensorreadback, Nsight or modeldownload.',
 'decision':{'preferred_next_candidate':'Fixed carry/prior hidden ingress for smallfirstcapture range only; prepared by a separateowner, notimplemented here.',
 'source_evidence':'Whole original capture_key_matches unchanged; original commands/keyshortcircuit still evaluated once. Only originalfalse triggers extra allportwalk. No authority/resource/key weakening, variantsize or ownerchange.',
 'observed_projection':'Among17 smallrange records,12 have an existing originalvalidcandidate whose complete differences are hidden-inputoffset only. Five have no comparablevalidcandidate (2first,3same-seq explicitnativeinvalidations). This is a projection of observed comparisons, not actualfuturecachetrajectory17to5 or proof ofspeedup.',
 'body_range_boundary':'All15 bodyrange records remain unmatched when only hiddeninputs are fixed. GDN input/output and hiddenoutput changes are different heavier work.'},
 'execution':{'unique_refreshed_product_TU':'Graph executable.cc only','compiler_invocations':4,'successful_compiles':2,'failed_private_compiles':2,'successful_links':2,'native_processes':2,'native_process_authorization':'Initialone directprocess hit eventoverflow; parent explicitly authorized onecapacity-onlysecondprocess. No thirdprocess.','SDK_core_CUDA_app_compiles':0,'HTTP':0,'GPU_released':True,'final_process':A['process'],'diagnostic_process_seconds_not_TPS':True},
 'final_inputs':{'ready':pin(W/'ready.json'),'image':ready['image'],'graph_object':ready['graph_object'],'reused_app':plan['reused_app'],'baseline_graph_source':plan['baseline_graph_source'],'baseline_graph_object':plan['baseline_graph_object'],'private_graph_source':plan['private_graph_source'],'final_helper':pin(W/'binding_diff.inc'),'source_patch':pin(W/'source.patch'),'dependency_check':dep,'dependency_map':pin(W/'dependency-restore.json'),'merged_core_objects':plan['reused_merged_lifetime_objects'],'closure_limit':'Exact originalGraph2selfwrittenheaders restored by originalactualdependencyhash; same frozenfinishapp/report/native-seedregion/otheroldclosure and twoactuallymergedlifetimecores. No newcache/scopesheader or wholeSDKcertification.'},
 'work':A['work'],'coverage':A['coverage'],'invalidation_and_seed':A['invalidation_and_seed'],'shape_classes':shape_summary,'range_decisions':range_summary,'counterfactual_projection':A['counterfactual_projection'],
 'physical_interval_bytes':{'method':A['copy_volume_limits']['dedup'],'scope':A['copy_volume_limits']['not_sum_of_mismatches'],'full_schema_example':A['copy_volume_limits']['full_staging_schema_example'],'actual_per_seq_range_dedup':'analysis.json:range_decisions.copy_new_changed_unique_bytes_by_record and records.json:range_decision_rows; old/new alternatives andaliases deduped withinactualseq/inv/range.'},
 'small_candidate':A['candidate'],
 'source_candidate_contracts':['Cold fixedBF16ingress remains in originalPhase/ColdResources andResourceBudget. OriginalimmutableSnapshot/ReadLease survivesbothcopy andGraphretirement; destinationmustnotbeoverwrittenwhileoldGraphreaders exist.',
 'Use existing boundedCopyBatch/IO resource/Queue/Completion mechanics; demonstrate realwriterhandoff andcopy-before-Graphdependency. No secondexecutor, no rawpermissionbypass, no enlargedvariants.',
 'Keepcopycostinsideoriginaltimedprepare/submit path; no movedwarmup. Actual66decodecopypayloadwouldbe507904B/124entries, notmeasuredcopycost. Twelveprojectedeligiblematches are not a recoverablems estimate.',
 'GDN fixedworkoutputs/copyout is a separatedeferredcandidate: originalindependentacceptedprefixleases/Headpublication/actualretirementmustremain; tensofMB/round are materiallydifferent fromhiddeningress.'],
 'first_failures':[
 {'stage':'SOURCE_PREPARATION','artifact':'first-preparation-failure.json','native_process_started':False,'reason':'Known908leaseaccessheaderdidnotmatchactualGraph2SHA. Assertionrejected; usedknown087dexactoriginalheaderSHA. Firstpartialsourceandpreparefile retainedprivately.'},
 {'stage':'GRAPH_COMPILE1','artifact':'graph/process.json','exit':2,'native_process_started':False,'reason':'C2127 constinitStorecontainsnonconstexprTensorDescdefaultconstruction. Minimalordinarysame-TUstaticStoredefinedbeforePOD-onlyDumper; no ownerorcapacitychange. Originalhelper retainedbinding_diff-first.inc.'},
 {'stage':'GRAPH_COMPILE2','artifact':'graph2/process.json','exit':2,'native_process_started':False,'reason':'C4335 under/WX: privaterewriteproducedCRCRLF. NormalizedonlynewlineencodingtoLF, no warningsuppression. Originalhelper retainedbinding_diff-second.inc.'},
 {'stage':'NATIVE_DIAGNOSTIC1','artifact':'first-run-summary.json','exit':0,'work':'PASS0diff','diagnostic':'INCOMPLETE eventcapacity2048+2957overflow, seq2to33only; diffcap0overflow/concurrent0. No completejourneyclaim. Actual68finishrecordsand612phasescomplete.',
 'correction':'Parentexplicitlyauthorizedonlyeventcapacity2048to8192; +737280BactualStore, differencecapacity32768andalltuple/algorithmcodeunchanged. Complete5005eventsretainedinsecondrun; noeventfiltering.'}],
 'independent_root_review':{'review':pin(root_review),'parser':pin(root_parser),'status':'PASS_FINITE_RAW_DIAGNOSTIC_REVIEW','scope':'Independentall5005/2701rawvalidation; portcounts/descriptors/offsetonly/fullfinishcoverage, noextraGPU/build.'},
 'artifacts':{'full_raw_final_stdout':pin(W/'run2/stdout.log'),'full_raw_final_stderr':pin(W/'run2/stderr.log'),'first_actual_run_stdout':pin(W/'run/stdout.log'),'first_actual_run_stderr':pin(W/'run/stderr.log'),'analysis':pin(W/'analysis.json'),'parsed_complete_records':pin(W/'records.json'),'candidate_design':pin(W/'candidate.md')},
 'limitations':A['limitations']+['Thisgreedyrealprocessdoesnotaddstochasticnumericalcoverage. IDs/workequalitydoesnotcertifynewmath; no modelmathwaschanged.',
 '80candidatefalseeventsincludeother-varianthits. Only32actualrecorddecisionscountasrecordings. All2701deltasareoffset-only foractualselectedoriginalkeys, notuniversalmodel/capacityproof.',
 '4547originalstepinvalidationobservationsarepreserved, not4547newrecordings.36nativeargumentobservationsmaptothesixno-comparablekeyrecordgroups; remaining4suchgroupsareinitialcold.',
 'DirectdiagnosticdoesnotrecordnativeCUDAAPIreturncodes.19seedvalid/13noseedrecordsfactsaregenericstateonly; earlierfinish-phaseprofileactual13Instantiate/19UpdateisreferencedwithoutclaimingfreshAPImeasurement.',
 'Staticstagingprojectionsremovecategoriesfromexistingcomparisons; avoidinganearlierrecordwouldchangefuturevariantpopulation. No simulatedexactfuturecountortimingbenefit.',
 'No extraRAM/VRAMbenchmark.16973856BfixeddiagnosticStore is selfmetadata, notcandidatebufferallocation or enginecacheusage.'],
 'related_previous_profile':'docs/evidence/performance/mtp-finish-phase-attribution-2026-10-25.json',
 'reproduction':{'parse_existing':'python .scratch/mtp-complete-binding-diff-20261025/analyze.py','final_compile':'compile-command4.json','final_link':'link-command4.json','final_run':'run2/command.json','old_actual_dependency_map':'dependency-restore.json','original_headers':'Known087d04eed/originalactualSHA; notcopiedasfullpublicdependencytree. Retainedprivatefrozenclosureandcurrentrepo are required for rebuild.'},
 'cleanup':cleanup}
save(W/'proof-summary.json',summary)
files={}
def add(p,name=None):
 if p.is_file():files[name or p.relative_to(W).as_posix()]=p
for p in W.iterdir():
 if p.is_file() and p.suffix in {'.json','.py','.inc','.h','.cc','.md','.patch'} and p.name!='analysis-console.json':add(p)
# Exact finalGraphdiagnostic+privateoriginalseeddeclaration only; no fulldependencytree.
add(W/'source2/src/graph/executable.cc');add(W/'source2/src/graph/plan_state.h')
for folder in ['graph','graph2','graph3','graph4','link3','link4','run','run2']:
 for p in (W/folder).iterdir():
  if p.is_file() and p.suffix in {'.json','.log'}:add(p)
add(root_review,'root-independent-review/binding-run2-review.json');add(root_parser,'root-independent-review/review-binding-run2.py')
add(R/'.scratch/mtp-logical-call-trace-20261025/analyze.py','references/work-normalizer.py')
add(R/'.scratch/mtp-finish-phase-20261025/trace1/native-stdout.log','references/baseline-actual-stdout.log')
add(R/'.scratch/mtp-finish-phase-20261025/compile/command.json','references/reused-app-command.json')
add(R/'.scratch/mtp-finish-phase-20261025/compile/source-pins.json','references/reused-app-actual-source-pins.json')
add(R/'.scratch/mtp-finish-phase-20261025/link2/command.json','references/reused-link-template.json')
manifest={name:pin(p) for name,p in sorted(files.items())};save(W/'archive-members.json',manifest);add(W/'archive-members.json')
public=R/'docs/evidence/performance/mtp-complete-binding-diff-2026-10-25.json';archive=public.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert all(not name.lower().endswith(('.exe','.obj','.pdb','.exp','.lib','.dll','.nsys-rep','.sqlite')) for name in z.namelist())
 members=len(z.namelist())
summary['archive']={**pin(archive),'members':members,'scope':'Completebothactualrunlogs, finalall-portrecords/parser, source-delta/finalGraph/privatehelper/failurecopies, precisecommands/dependencyandclosurepins/rootindependentreview. No binaries/SDK/weights/wholedependencytree.'}
save(public,summary)
save(W/'publication-check.json',{'status':'PASS','public_json':pin(public),'archive':summary['archive'],'zip_integrity':True,'no_binaries_or_full_dependency_tree':True,'cleanup_not_executed':True})
print(json.dumps({'public_json':pin(public),'archive':summary['archive'],'cleanup':{k:{x:v for x,v in d.items() if x!='files'} for k,d in cleanup.items()}},indent=2))
