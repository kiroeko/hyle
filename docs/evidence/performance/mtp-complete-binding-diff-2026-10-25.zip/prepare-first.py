"""Prepare one private Graph TU diagnostic. This script never builds or runs."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path.cwd();W=Path(__file__).resolve().parent
BASE=R/'.scratch/mtp-native-seed-candidate-20261025'
FIN=R/'.scratch/mtp-finish-phase-20261025'
def pin(p):return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
oldpins=json.loads((BASE/'graph2/source-pins.json').read_bytes())
S=W/'source';S.mkdir(exist_ok=False)
baseline_source=BASE/'source/executable.cc'
before=baseline_source.read_bytes();assert hashlib.sha256(before).hexdigest()=='6476518eaf59eef59d46fc1b0ad770024c0bee99a616663b1032ea33c2d8cf59'
assert b'\r\n' not in before
s=before.decode('utf-8');changes=[];mapping=[]
for d in oldpins:
 p=Path(d['path'])
 if p==baseline_source or str(p).lower()==str(baseline_source).lower():continue
 try:rel=p.relative_to(R)
 except ValueError:continue
 if rel.parts[0]=='.scratch':
  mapping.append({'original':d,'restore':'unchanged retained cache; not copied','current':pin(p)});continue
 current=p.read_bytes();how='current byte-equals original actual dependency'
 if hashlib.sha256(current).hexdigest()!=d['sha256']:
  git=subprocess.run(['git','show','908ad39d0:'+rel.as_posix()],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
  current=git.stdout;how='git908ad39d0 exact original actual dependency hash'
 assert hashlib.sha256(current).hexdigest()==d['sha256'],(p,how)
 dest=S/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(current)
 mapping.append({'original':d,'restore':how,'private':pin(dest)})
# The original actual app keeps its own existing frozen source and object.
# Its shared inline sequence is the sole cross-TU association, not a new hook.
(W/'logical_trace.h').write_bytes((FIN/'logical_trace.h').read_bytes())
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:90],s.count(old))
 changes.append({'before':old,'after':new});s=s.replace(old,new)
def add(anchor,payload,before_anchor=False):
 text='// COMPLETE_BINDING_DIFF_BEGIN\n'+payload+'\n// COMPLETE_BINDING_DIFF_END\n'
 replace(anchor,text+anchor if before_anchor else anchor+text)
add('namespace hyle::graph {\n', '#include <atomic>\n#include <cstdio>\n#include <type_traits>\n#pragma push_macro("interface")\n#include "'+(W/'logical_trace.h').as_posix()+'"\n#pragma pop_macro("interface")',True)
add('void discard_capture_variants(detail::CaptureRebuildRange &saved) noexcept {\n', '#include "'+(W/'binding_diff.inc').as_posix()+'"',True)
add('void discard_capture_variants(detail::CaptureRebuildRange &saved) noexcept {\n', '  complete_binding_diff::note(complete_binding_diff::Kind::kDiscardKeys, nullptr, &saved);')
old='''        if (!variant.commands.valid() || !capture_key_matches(*state_, *saved, variant))
          continue;
'''
new='''        if (!variant.commands.valid() || !capture_key_matches(*state_, *saved, variant)) {
          complete_binding_diff::mismatch(*state_, *saved, variant, index);
          continue;
        }
'''
replace(old,new)
add('    auto *saved = capture_storage(*state_, range.step_begin, range.step_count);\n',
 '    complete_binding_diff::range(complete_binding_diff::Kind::kRangeCandidate, *state_, range.step_begin, range.step_count, saved);')
add('''      ++reused_range_count;
      captured_command_count += candidate.command_count;
      continue;
    }
    auto *saved = capture_storage''',
 '      complete_binding_diff::range(complete_binding_diff::Kind::kRetainedHit, *state_, range.step_begin, range.step_count, capture_storage(*state_, range.step_begin, range.step_count));',True) if False else None
# Retained-hit site is before saved exists; use an insertion immediately inside
# the original true branch. No extra capture key evaluation is introduced.
add('''    if (retained != state_->captured_ranges.end() &&
        retained->step_begin == range.step_begin &&
        retained->step_count == range.step_count) {
''', '      complete_binding_diff::range(complete_binding_diff::Kind::kRetainedHit, *state_, range.step_begin, range.step_count, capture_storage(*state_, range.step_begin, range.step_count));')
add('''        selected_variant = index;
        break;
''', '        complete_binding_diff::note(complete_binding_diff::Kind::kVariantHit, state_, saved, index);',True)
add('''    compute::detail::CaptureRebuildStorage rebuild;
''', '    complete_binding_diff::note(complete_binding_diff::Kind::kRecordBegin, state_, saved, selected_variant);',True)
add('''    append_capture_range(*state_, range.step_begin, range.step_count, std::move(*captured));
    ++recorded_range_count;
''', '    complete_binding_diff::note(complete_binding_diff::Kind::kRecorded, state_, saved, selected_variant);')
add('''  HYLE_FATAL_ASSERT(selected_step < invocation.step_bindings.size());
  const bool recycle = mode == CaptureInvalidation::kStableBindings;
''', '  complete_binding_diff::invalidation(invocation, selected_step, static_cast<std::uint32_t>(mode));',True)
restored=s
for d in reversed(changes):
 assert restored.count(d['after'])==1
 restored=restored.replace(d['after'],d['before'])
assert restored.encode('utf-8')==before
start='bool capture_key_matches(';stop='void remember_capture_key('
original_body=before.decode().split(start,1)[1].split(stop,1)[0]
assert s.split(start,1)[1].split(stop,1)[0]==original_body
p=S/'src/graph/executable.cc';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
(W/'before-executable.cc').write_bytes(before)
(W/'source.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='actualGraph2/executable.cc',tofile='privateCompleteBindingDiff/executable.cc')),encoding='utf-8')
save(W/'replacement-map.json',changes)
save(W/'dependency-restore.json',{'baseline_actual_command':pin(BASE/'graph2/command.json'),'baseline_actual_dependencies':pin(BASE/'graph2/dependencies.json'),'baseline_actual_pins':pin(BASE/'graph2/source-pins.json'),'baseline_source':pin(baseline_source),'restored_original_dependencies':mapping})
command=json.loads((BASE/'graph2/command.json').read_bytes());argv=command['command']
private_args=[argv[0],'/I'+str(S/'include'),'/I'+str(S/'src/graph'),'/I'+str(S/'src/compute')]
for i,a in enumerate(argv[1:],1):
 if a.lower()==str(baseline_source).lower():a=str(p)
 if i and argv[i-1]=='/sourceDependencies':a=str(W/'graph/dependencies.json')
 if a.startswith('/Fo'):a='/Fo'+str(W/'graph/unit.obj')
 private_args.append(a)
command['command']=private_args;command['cwd']=str(R);save(W/'compile-command.json',command)
link=json.loads((FIN/'link2/command.json').read_bytes());oldobj=str(BASE/'graph2/unit.obj')
assert sum(a.lower()==oldobj.lower() for a in link['command'])==1
link['command']=[str(W/'graph/unit.obj') if a.lower()==oldobj.lower() else a for a in link['command']]
for i,a in enumerate(link['command']):
 if a.lower().startswith('/out:'):link['command'][i]='/OUT:'+str(W/'link/consumer.exe')
 if a.lower().startswith('/implib:'):link['command'][i]='/IMPLIB:'+str(W/'link/consumer.lib')
 if a.lower().startswith('/pdb:'):link['command'][i]='/PDB:'+str(W/'link/consumer.pdb')
save(W/'link-command.json',link)
trace_command=json.loads((FIN/'trace1/command.json').read_bytes())['command']; image=str(FIN/'link2/consumer.exe')
assert sum(a.lower()==image.lower() for a in trace_command)==1
app_argv=trace_command[trace_command.index(image)+1:]
save(W/'run-command.json',{'command':[str(W/'link/consumer.exe'),*app_argv],'cwd':str(R),'timeout_seconds':120,'stdout':str(W/'run/stdout.log'),'stderr':str(W/'run/stderr.log'),'profiler':False,'runtime_from':pin(FIN/'run.py'),'runtime_plan':json.loads((FIN/'plan.json').read_bytes())['runtime'],'execute_now':False})
ready=json.loads((FIN/'ready.json').read_bytes())
source_pins=[pin(x) for x in sorted(S.rglob('*')) if x.is_file()]+[pin(W/'binding_diff.inc'),pin(W/'logical_trace.h')]
save(W/'source-pins.json',source_pins)
save(W/'source-checks.json',{'status':'SOURCE_ONLY_NOT_COMPILED_NOT_RUN','original_capture_key_matches_whole_function_byte_equal':True,'reverse_all_diagnostic_changes_restores_actualGraph2_full_source':True,'original_variant_condition_shortcircuit_text_preserved':True,'changes':len(changes),'extra_full_port_walk':'Only after original false for commands-valid,key-valid candidate; original false remains unchanged. No-key/no-command cases log separate reason without invented port comparisons.','original_clear_recycle_variant_policy_not_changed':True,'no_tensor_contents_or_lease_resource_GPU_operations':True})
plan={'status':'PREPARED_NOT_COMPILED_NOT_RUN','scope':'One private Graph TU and one later authorized original Hyle K1 realtwo-turn diagnostic process only; no TPS/profile/peer/matrix.',
 'baseline_graph_source':pin(baseline_source),'baseline_graph_object':pin(BASE/'graph2/unit.obj'),'baseline_graph_compile':pin(BASE/'graph2/command.json'),'actual_dependency_mapping':pin(W/'dependency-restore.json'),
 'private_graph_source':pin(p),'helper':pin(W/'binding_diff.inc'),'reused_app':ready['app_object'],'reused_app_source_pins':pin(FIN/'compile/source-pins.json'),'reused_app_command':pin(FIN/'compile/command.json'),'reused_report_and_Graph_objects':json.loads((FIN/'plan.json').read_bytes())['retained_key_objects'][1:],
 'reused_merged_lifetime_objects':ready['merged_lifetime_replacements'],'link_template':pin(FIN/'link2/command.json'),'new_compiler_TUs_if_authorized':1,'new_app_TUs':0,'new_core_or_CUDA_or_SDK_TUs':0,
 'planned_commands':[pin(W/'compile-command.json'),pin(W/'link-command.json'),pin(W/'run-command.json')],
 'fixed_bounds':{'events':2048,'differences':32768,'event_record_static_size_upper_bytes':160,'difference_record_static_size_upper_bytes':640,'array_payload_upper_bytes':2048*160+32768*640,'Store_header_and_guard_overhead_bytes_upper':256,'static_checks':'trivially-copyable Store/Physical, record size upper bounds; actual sizeof will be emitted only after compile/run.','overflow_or_concurrent_skip':'Must be0. If nonzero, incomplete diagnostic, no inference from missing ports, no automatic retry.'},
 'record_estimate':{'old_native_process_decode_ranges':132,'recorded_ranges':32,'two_candidate_upper_before_selection':264,'event_expected_order':'hundreds, below2048; invalidations/discards/record begin/end retained explicitly','difference_capacity':'No artificial first20 cutoff. All changed ports over complete journey; source-only cannot guarantee count, zerooverflow required. Expected hundreds/thousands of changed state tuples rather than every constant port.'},
 'after_main_output':'Noninline TU-local Dumper reads only constinit POD, copied TensorDesc metadata and own atomic skip counter; stdio after normalCLIreturn. No graph/tensor/lease/queue owner is held or read at exit. Existing finish app already normal-exit dumps after qwen35::run; its object remains unchanged. Direct stdout/stderr files, no Nsight ProcessStreams.',
 'meaning':{'role':'Input/output port and original instance_roles/domain/value ID; logical seq joins unchanged FINISH_META with actual modelrole,T,R,context,frontier,lag. No semantic modelrole inferred from dtype.','same_key':'Original validity/entire TensorDesc/resource/nativehandle/offset/size comparison. Detailed dumps include shape,strides,dtype,format/axis plus required_bytes from copied metadata afterCLI; resource token is address identity only, never dereferenced as a resource operation.','no_seed':'Current saved seedValid snapshot separately recorded; no seed does not itself mean binding mismatch or APIupdate failure.','invalidated':'Explicit original invalidate disposition plus discard snapshot, distinct from no-key/no-command and valid-key mismatch.','trailing_size':'Missing-old and extra-old key entries explicit; unknown new role for unmatched old tail remainsUINT32_MAX.'},
 'work_gate':{'baseline_actual_raw':pin(FIN/'trace1/native-stdout.log'),'comparison':'Existing exact normalize excludes existing timefields only;128 IDs and all work/ledger/pending/RNG/cache metadata remain0diff. No widening exclusions.','phase_record_gate':'68 logicalepisodes/612 closed ranges from original retainedapp expectation, now direct stderr must contain68 FINISH_META normal_return1/seen511 and FINISH_POD overflow0. This does not retroactively certify prior truncated rows.','diagnostic_gate':'BIND_POD/BIND_END counts agree; events/diffs parse complete; every valid-key mismatch examined all expected current ports and has nonzero changed/size mismatch. No-key/no-commands distinguished. All pointers are scalar snapshots; no owner address touched atdump.'},
 'no_execution':{'compile':0,'link':0,'GPU':0,'HTTP':0}}
save(W/'plan.json',plan)
print(json.dumps({'status':plan['status'],'baseline_graph_source':plan['baseline_graph_source'],'private_graph_source':plan['private_graph_source'],'helper':plan['helper'],'frozen_self_written_dependency_files':len(source_pins),'restored_exact_git_headers':[x['original']['path'] for x in mapping if x['restore'].startswith('git')],'commands_prepared_only':3},indent=2))
