# Complete capture-key miss diagnostic（私有，仅源准备）

- 目标：解释原同一 K1 两轮工作里**完整** capture key 变化；不修改 cache、失效、选择、回收、比较、绑定、权限、数学或报告端点。
- 原 `capture_key_matches` 整个函数逐字不动。原 `!commands.valid() || !capture_key_matches(...)` 短路仍只执行一次；进入原 continue 分支后才诊断。
- 无 commands / 无 key 单列，不伪造端口比较。只有原返回 false 且 commands+key 有效，才遍历原 step / input / output 次序，逐项比较全部真实原 tuple。
- 每个候选记录 seq / invocation / plan / range / variant，原 key、commands、rebuild seed、qualification、private-argument flags；retained/variant hit、record begin/end、原 invalidation disposition、discard 分开记。
- 每次 mismatch 保存 expected/cached/examined/equal/changed 计数。只保存变化端口的两端完整 TensorDesc、resource/handle 整数身份、offset/size、原 instance/value/domain/role；shape/dtype/strides/format/required bytes 在正常返回后由复制描述输出。
- 不读 tensor 内容，不查询/分配/修改资源，不保存 TensorView/Lease/Invocation/Queue 等对象。resource 地址只是原比较所用身份的整数拷贝。
- cached key 比当前更短或更长也明确记录：missing-old 和 extra-old；多余旧项的新角色未知保 UINT32_MAX。
- 初始固定2048 events、32768 differences（首趟实际event overflow；root明确授权仅events增至8192补采，第二趟完整）。静态断言 Event<=160B、Difference<=640B、Store trivially-copyable；数组载荷上界22,282,240B（最终8192 event静态上界21.25MiB），小计数器/guard另<256B，实际 sizeof 只在以后编/跑后签。
- 所有 miss 贯穿整趟，无旧 first20 截断。已有132 decode range decisions/32录制是容量估计依据，预计数百事件、数千变化端口；不是强行假定上界。overflow/并发skip任一非零即完整性失败，不据缺项归因，不自动补采。
- 普通 main 返回后，本 Graph TU 的非inline Dumper 只读同TU普通静态owner-free POD（定义早于Dumper；原TensorDesc不支持constinit，首编失败已保留） 并 stdio 输出；不持 owner 或读已销毁对象。无 inline Dumper ODR-use 风险。

## 精确复用与原依赖

- 原 Graph2：`.scratch/mtp-native-seed-candidate-20261025/source/executable.cc`，SHA6476518e…；其实际 compile/dependencies/source-pins 原件列在 dependency-restore.json。
- `source2/src/graph/executable.cc` 仅私有诊断 delta；87个私有源/头 pin 在 source-pins.json。
- 原86个仓库依赖逐字恢复。当前5头已变化：storage_owner / lease_access / resource_leases / resource_budget_access / graph/result；从已知087d04eed按**原实际SHA逐一确认**恢复。其余原依赖当前仍完全相等；没有采用新cache/scopes接口。
- 首次 prepare 错选更早908版本 lease_access，原hash断言明确失败，未编/链/跑；prepare-first.py、first-preparation-failure.json、部分source/保留。第二份source2正确恢复全部原实际头。
- 复用成功finish appOBJ `35a38e9b…`（其main/11markers/原完整源码与实际依赖仍在原batch），原report、seed regionOBJ及其它原217-input闭包。仅把原Graph2 OBJ换成拟编诊断OBJ。
- 两个已合lifetime core OBJ仍为root指定的4c434358…/97c30798…；不换新cache3core，不编SDK/core/CUDA/app。
- 三个准备命令只写JSON：compile-command.json、link-command.json、run-command.json。不会自动执行。/I为完整单参数，私有原依赖路径在原include路径之前；实际编后必须核sourceDependencies没有意外自有头泄漏。

## 以后获授权才执行的唯一过程

- 原 Hyle real-two-turn K1/P154/+64、原输入/运行环境/全部参数；无 profiler、无 peer、无普通或K矩阵；原120s watchdog。
- stdout/stderr直接重定向原文件，不经Nsight ProcessStreams；必须同时有 BIND_POD、所有事件/差异/描述、BIND_END，计数相等且 overflow/concurrent_skip=0。
- 正常报告完整128 IDs及所有非时间work/ledger/pending/RNG/cache字段，对上一轮实际raw stdout严格0diff；只沿既有time规则normalize。
- 原finish APP保留：直接stderr应实际完整68 FINISH_META且normal_return1/seen511、FINISH_POD overflow0。不会反向补签上次被Nsight截断的60行。
- 每个 commands-valid/key-valid 的原false应 examined==expected、equal+changed==expected（若extra_old另记）、changed或长度差非零；完整变化字节按唯一实际storage区间去重后再判断staging复制规模，不能把端口别名重复相加。
- 只据完整原key及失效事实决定下一步；不预设小buffer为根因，不扩variants或恢复已拒绝的hidden布局方向，不把本诊断作为TPS。
