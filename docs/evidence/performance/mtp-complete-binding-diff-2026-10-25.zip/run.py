"""One authorized direct K1/two-turn diagnostic. No retry/build/profile path."""
from pathlib import Path
import datetime,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(W/'ready.json');command=b.read(W/'run-command3.json')
def verify(d):
 p=Path(d['path']);p=p if p.is_absolute() else R/p;a=b.pin(p)
 assert a['bytes']==d['bytes'] and a['sha256']==d['sha256'],str(p)
for item in [ready['image'],ready['graph_object'],ready['CPU_companion'],*ready['source_pins'],*ready['retained_link_inputs']]:verify(item)
runtime=R/command['runtime_plan']['path'];verify(command['runtime_plan'])
env=os.environ.copy();env['PATH']=str(W/'link3')+';'+b.read(runtime)['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
gpu_command=['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader']
gpu=subprocess.run(gpu_command,env=env,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=20);assert gpu.returncode==0,gpu.stderr
known={'hyle.exe','peer.exe','consumer.exe','probe.exe','recursive-probe.exe','llama-cli.exe','llama-server.exe','llama-bench.exe','python.exe','pythonw.exe'}
lines=[line for line in gpu.stdout.splitlines() if line.strip()]
inference=[line for line in lines if len(line.split(','))>=2 and (Path(line.split(',')[1].strip()).name.lower() in known or str(R).lower() in line.lower())]
assert not inference,inference
inventory=subprocess.run(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(hyle|peer|consumer|probe|recursive-probe|llama-cli|llama-server|llama-bench)(\\.exe)?$' } | Select-Object ProcessId,Name,ExecutablePath | ConvertTo-Json -Compress"],env=env,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=20)
assert inventory.returncode==0 and not inventory.stdout.strip(),inventory.stdout
inputs=Path(command['command'][command['command'].index('--inputs')+1]);metadata=[b.pin(p) for p in inputs.iterdir() if p.is_file() and p.stat().st_size<1024*1024]
schedule=Path(command['command'][command['command'].index('--schedule')+1])
b.save(W/'run-start.json',{'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'image':ready['image'],'ready':b.pin(W/'ready.json'),'gpu_preflight':{'command':gpu_command,'exit':gpu.returncode,'reported_rows':len(lines),'inference':inference,'WDDM_desktop_not_excluded':True},'named_inventory':{'exit':inventory.returncode,'stdout':inventory.stdout},'inputs_metadata':metadata,'schedule':b.pin(schedule),'scope':'One direct original K1 two-turn diagnostic, no TPS/profile/automatic retry.'})
b.execute(command['command'],W/'run',env,120)
b.save(W/'run-terminal.json',{'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'process':b.read(W/'run/process.json'),'GPU_released':True,'additional_native_processes':0})
print('GPU_RELEASED',flush=True)
