"""Offline full-key parsing/counterfactual projection only; no native work."""
from pathlib import Path
from collections import Counter,defaultdict
import ast,hashlib,json,re
R=Path.cwd();W=Path(__file__).resolve().parent;F=W/'run2'
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def kv(line):
 d={}
 for k,v in re.findall(r'(\w+)=([^\s]*)',line):
  if k in ('dims','strides'):d[k]=[int(a) for a in v.split(',') if a]
  else:
   try:d[k]=int(v)
   except ValueError:d[k]=v
 return d
s=(F/'stderr.log').read_text();lines=s.splitlines()
events=[kv(l) for l in lines if l.startswith('BIND_EVENT ')];ports=[kv(l) for l in lines if l.startswith('BIND_PORT ')]
desc=defaultdict(dict)
for l in lines:
 if l.startswith('BIND_DESC '):
  d=kv(l);desc[d['diff']][d.pop('side')]=d
for p in ports:p.update(desc[p['i']]);assert set(desc[p['i']])=={'old','new'}
header=next(kv(l) for l in lines if l.startswith('BIND_POD '));end=next(kv(l) for l in lines if l.startswith('BIND_END '))
assert header['event_overflow']==header['difference_overflow']==header['concurrent_skips']==0
assert len(events)==header['events']==end['events']==5005
assert len(ports)==header['differences']==end['differences']==2701
assert [e['i'] for e in events]==list(range(len(events)))
assert [p['i'] for p in ports]==list(range(len(ports)))
by_event=defaultdict(list)
for p in ports:by_event[p['event']].append(p)
miss=[e for e in events if e['kind']==3]
for e in miss:
 assert e['examined']==e['expected_ports']==e['cached_ports']
 assert e['equal']+e['changed']==e['examined'] and not e['missing_old'] and not e['extra_old']
 assert e['changed']==len(by_event[e['i']]) and e['changed']>0
for p in ports:
 assert p['flags']==16
 a={k:v for k,v in p['old'].items() if k not in ('diff','offset')};b={k:v for k,v in p['new'].items() if k not in ('diff','offset')}
 assert a==b
meta={d['seq']:d for d in [kv(l) for l in lines if l.startswith('FINISH_META ')]}
phases=[kv(l) for l in lines if l.startswith('FINISH_PHASE ')]
assert len(meta)==68 and all(m['normal_return']==1 and m['seen']==511 for m in meta.values())
assert len(phases)==612
prior=R/'.scratch/mtp-logical-call-trace-20261025/analyze.py';tree=ast.parse(prior.read_text());ns={};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'normalize','differences'}],type_ignores=[]),str(prior),'exec'),ns)
def report(p):
 t=p.read_text();return json.JSONDecoder().raw_decode(t[t.index('{"source_id"'):])[0]
base=R/'.scratch/mtp-finish-phase-20261025/trace1/native-stdout.log';old=report(base);new=report(F/'stdout.log');differences=ns['differences'](ns['normalize'](old),ns['normalize'](new));assert not differences
DT={5:'BF16',6:'F32'}
def tensor_class(p):
 d=p['new'];shape=tuple(d['dims']);typ=DT.get(d['type'],str(d['type']))
 what='hidden' if shape==(1,2048) else 'GDN_history' if shape==(1,3,6144) else 'GDN_recurrent' if shape==(1,16,128,128) else 'other'
 return ('output' if p['output'] else 'input')+'/'+what+'/'+typ+'/'+str(shape)
def what(p):return tensor_class(p).split('/')[1]
def unique_bytes(ps,side='new',carrier=False):
 intervals=defaultdict(list)
 for p in ps:
  v=p[side]
  if not v['valid']:continue
  assert v['required_known']==1
  size=v['size'] if carrier else v['required_bytes']
  intervals[(v['resource'],v['handle'])].append((v['offset'],v['offset']+size))
 total=0
 for spans in intervals.values():
  joined=[]
  for a,b in sorted(spans):
   if joined and a<=joined[-1][1]:joined[-1][1]=max(joined[-1][1],b)
   else:joined.append([a,b])
  total+=sum(b-a for a,b in joined)
 return total
# Group the actual range decision; a candidate mismatch can precede another
# valid candidate's hit, so it is not automatically a new recording.
key=lambda e:(e['seq'],e['inv'],e['begin'],e['count'])
groups=defaultdict(list)
for e in events:
 if e['kind'] in (0,1,2,3,4,5,8,9):groups[key(e)].append(e)
rows=[]
scenarios={
 'fixed_hidden_inputs_only':lambda p:not p['output'] and what(p)=='hidden',
 'fixed_hidden_inputs_and_outputs':lambda p:what(p)=='hidden',
 'fixed_all_observed_inputs_only':lambda p:not p['output'],
 'fixed_all_observed_GDN_IO_only':lambda p:what(p).startswith('GDN_'),
 'fixed_all_observed_inputs_and_outputs':lambda p:True}
for k,es in groups.items():
 outcomes=[e for e in es if e['kind'] in (4,5,9)];assert len(outcomes)==1,(k,outcomes)
 outcome=outcomes[0];ms=[e for e in es if e['kind']==3]
 ps=[p for e in ms for p in by_event[e['i']]]
 invs=[e for e in events if e['kind']==7 and key(e)==k]
 record_begin=[e for e in es if e['kind']==8]
 r={'seq':k[0],'inv':k[1],'begin':k[2],'count':k[3],'model':meta[k[0]],'outcome':{4:'variant_hit',5:'retained_hit',9:'recorded'}[outcome['kind']],
 'candidate_mismatches':[e['i'] for e in ms],'no_command_candidates':sum(e['kind']==1 for e in es),'no_key_candidates':sum(e['kind']==2 for e in es),
 'record_seed_valid':record_begin[0]['seed'] if record_begin else None,'invalidations_by_disposition':dict(Counter(e['aux'] for e in invs)),
 'new_changed_unique_tensor_bytes':unique_bytes(ps),'new_changed_unique_carrier_bytes':unique_bytes(ps,carrier=True),
 'changed_unique_bytes_by_direction':{direction:unique_bytes([p for p in ps if bool(p['output'])==output]) for direction,output in [('input',False),('output',True)]},
 'changed_port_classes':dict(Counter(tensor_class(p) for p in ps)),'counterfactual_existing_candidate_hit':{name:any(all(ignore(p) for p in by_event[e['i']]) for e in ms) for name,ignore in scenarios.items()}}
 rows.append(r)
assert len(rows)==132 and Counter(r['outcome'] for r in rows)=={'recorded':32,'variant_hit':90,'retained_hit':10}
shape_stats={}
for cls in sorted({tensor_class(p) for p in ports}):
 ps=[p for p in ports if tensor_class(p)==cls]
 shape_stats[cls]={'port_occurrences':len(ps),'candidate_miss_events':len({p['event'] for p in ps}),'required_bytes_per_tensor':ps[0]['new']['required_bytes'],'offset_pairs':dict(Counter(str((p['old']['offset'],p['new']['offset'])) for p in ps)),
 'process_union_new_tensor_bytes_not_transfer_volume':unique_bytes(ps)}
range_stats={}
for bc in sorted({(r['begin'],r['count']) for r in rows}):
 rs=[r for r in rows if (r['begin'],r['count'])==bc];rec=[r for r in rs if r['outcome']=='recorded'];recmiss=[r for r in rec if r['candidate_mismatches']]
 range_stats[str(bc)]={'logical_calls':len(rs),'model_lag_counts':dict(Counter(r['model']['lag'] for r in rs)),'outcome_counts':dict(Counter(r['outcome'] for r in rs)),
 'recorded_seq':[r['seq'] for r in rec],'record_seed_counts':dict(Counter(r['record_seed_valid'] for r in rec)),
 'native_invalidation_seq':[r['seq'] for r in rs if r['invalidations_by_disposition'].get(2,0)],
 'recorded_with_actual_valid_key_mismatch':len(recmiss),'recorded_without_any_comparable_valid_candidate':len(rec)-len(recmiss),
 'counterfactual_recorded_where_existing_candidate_would_match':{name:[r['seq'] for r in rec if r['counterfactual_existing_candidate_hit'][name]] for name in scenarios},
 'copy_new_changed_unique_bytes_by_record':[{k:r[k] for k in ['seq','changed_unique_bytes_by_direction','new_changed_unique_tensor_bytes']} for r in rec]}
scenario_summary={}
for name,ignore in scenarios.items():
 remain=[e for e in miss if any(not ignore(p) for p in by_event[e['i']])]
 scenario_summary[name]={'candidate_misses_with_remaining_changed_ports':len(remain),'candidate_misses_original':len(miss),
 'recorded_ranges_with_observed_eligible_candidate_becoming_equal':sum(r['outcome']=='recorded' and r['counterfactual_existing_candidate_hit'][name] for r in rows),
 'scope':'Projection of actual original candidate comparisons only; not a replay simulation or causal futurecache trajectory, no changes to no-command/no-key/invalidation or private argument qualification.'}
out={'status':'COMPLETE_DIAGNOSTIC_WORK_PASS','process':json.loads((F/'process.json').read_bytes()),'raw_stdout':pin(F/'stdout.log'),'raw_stderr':pin(F/'stderr.log'),
 'work':{'status':'PASS','difference_count':0,'differences':differences,'baseline_actual_raw':pin(base),'normalizer':pin(prior),'metadata_exclusions_beyond_original_time_rules':[],
 'facts':{k:new[k] for k in ['generated_tokens','generated_decode_tokens','actual_graph_calls','prefill_graph_calls','decode_graph_calls','prefill_target_rows','verified_target_rows','prefill_draft_rows','draft_rows','agreements','consumed_drafts','cache_live_requested_bytes','cache_peak_requested_bytes']}},
 'coverage':{'BIND_POD':header,'BIND_END':end,'FINISH_meta':len(meta),'FINISH_phases':len(phases),'all_FINISH_normal_return':True,'all_FINISH_seen511':True,'valid_key_candidate_misses':len(miss),'all_misses_full_port_walk':True,'examined_ports_total':sum(e['examined'] for e in miss),'all_changed_port_flags':dict(Counter(p['flags'] for p in ports)),'all_descriptors_and_tuple_fields_equal_except_offset':True,'events_by_kind':dict(Counter(e['kind'] for e in events))},
 'shape_classes':shape_stats,'range_decisions':range_stats,'counterfactual_projection':scenario_summary,
 'copy_volume_limits':{'dedup':'Union of [offset,offset+TensorDesc.required_bytes) grouped by originalresource/nativehandle. Within actual seq/inv/range, combines both candidate comparisons to avoid double-counting aliases. Carrier-size union also separately available. A union over process lifetime is not transferred bytes.',
 'not_sum_of_mismatches':'Repeated use of same actual logical source, output alias or candidate comparison does not require repeated copies. Per-step/per-range copy footprint is distinct from process-static working set.',
 'full_staging_schema_example':{'source':'Frozen Model state_schema_for and actuallogged 18GDN history/recurrent output identities','one_history_bytes':36864,'one_recurrent_bytes':1048576,'18_layer_one_boundary_bytes':18*(36864+1048576),'R1_T2_ingress_plus_selected_boundary_copyout_bytes':2*18*(36864+1048576),'R1_T2_ingress_plus_both_prefix_copyout_bytes':3*18*(36864+1048576),'limit':'Schema scope only; fixed stage would still require originalpage/lease/acceptance/publication/retirement/finitebudget contracts. Selected-only latecopy adds another actual completion boundary; copying both originalprefixes inside graph costs more bandwidth. No implementation or speedclaim.'}},
 'first_incomplete_actual_run':json.loads((W/'first-run-summary.json').read_bytes()),
 'limitations':['All2701 actual differences are offset-only for these exact original candidate checks. This does not prove later arbitrarymodels/contexts/caches have identical keys.',
 'A candidate miss followed by another variant hit is already a successful cache hit; it is not a rerecording. Counterfactual counts separate actualrecord groups.',
 'No CUDA API profile collected here. record_seed_valid is generic source state, not proof of current native Update success; prior finish-phase trace has actual13Instantiate/19Update with this seedclosure.',
 'POD/metadata-only diagnostic is not TPS; process wall includes normalexit dump and is not compared to a benchmark.',
 'Firstrun eventoverflow retained as completenessfailure. Secondrun onlyeventcap2048to8192 under separateparentauthorization; diffcapunchanged. No thirdnative process.']}
save(W/'records.json',{'events':events,'ports':ports,'range_decision_rows':rows,'FINISH_meta':meta})
save(W/'analysis.json',out)
print(json.dumps({k:out[k] for k in ['status','coverage','range_decisions','counterfactual_projection']},indent=2))
