# 小型 fixed hidden ingress 候选（只设计，未实现）

## 此次完整事实

- 完整5005事件、2701差异、80个有效key候选false；83742端口均完整检查。差异全部为offset；dtype/shape/strides/format/resource/nativehandle/size不变。
- 132个真实range决策：32重录、90另一variant命中、10retained命中。不能把80候选false都当重录。
- 小range `(0,53)`：58次lag1调用，13重录；`(0,55)`：8次lag0调用，4重录。其完整变化仅4KiB BF16 hidden输入，无变化output。
- 在**原实际比较**投影中，固定carry/prior hidden输入可使12次原record存在相等的旧有效候选（lag1十次、lag0两次）。另5次无可比较候选：两角色首次、三次显式native失效。此投影不是新的cache轨迹模拟，更不是17→5实测或速度承诺。
- 大range的15次record没有任何一次可仅固定hidden输入而获得相等旧候选。其GDN输入、输出和hidden输出另有真实offset变化。
- GDN一完整边界去重为18×(36,864B history+1,048,576B recurrent)=19,537,920B；输出变化常为同量加8,192B hidden，seq39两个prefix变化39,075,840B。不能把这些当小buffer，也不能按2701端口重复累计搬运。

## 优先保留的最小假设

- 仅在已准备的classic MTP decode两个Phase/其原slot中冷分配稳定BF16 `[1,2048]` ingress；lag0一个、lag1两个，当前slot数1，两Phase总device载荷12,288B，控制/权限元数据另按原预算计。
- 冻结main `prepare_draft_append` 3632/3635处目前直接绑定 `base->carry_hidden/prior_hidden`。候选只把这两类port绑定到固定物理入口；仍复制原BF16字节，不能换精度或重算hidden。
- 每轮按实际源lease复制到入口，原66轮需124项×4096B=507,904B。可复用 `compute/batch_transfer.h` 的有界 CopyBatchProgram/Invocation，而不是把两次未接线copy藏入一个wrapper。
- 复制必须在捕获之外，并以原Queue/Completion依赖保证Graph真正读取前完成；追加copy的准备/提交/等待仍留在原计时窗，不挪warmup或报告端点。
- 必须证明固定目标的WriteLease能在**所有旧Graph读者实际退休**后按现有writer handoff/replay合同重获写权限；不能只凭TensorView地址相同覆盖已发布reader。若公开CopyBatch/IO机制不能自然表达，应先报告此具体阻碍，不绕权限或另造executor。
- 原base Snapshot/ReadLease留到copy与Graph全部实际退休。取消/设备错误不得发布新Head/ledger/RNG，pending与原输出策略保持。固定入口归原Phase/ColdResources及现ResourceBudget，不建新owner或无限buffer池。
- 不改native page/layout/topology合同：三次小range显式失效仍按原规则处理，不保旧launch权、不增加variants。

## 本轮不实施的大状态路线

- 若未来尝试固定GDN工作输出，必须copy到原独立immutable lease后才发布，不能把后续会覆盖的workspace直接作为Snapshot。
- 输入+实际选中边界copyout约39,075,840B/轮；若两prefix都copyout约58,613,760B/轮，另有hidden与控制量。late selected-only copyout增加真实完成/失败边界，不能略过。
- 这条路线比当前hidden入口重得多，本轮不保守推成同一候选或提前声明收益。

## 可证伪门（以后另获授权才执行）

- 先证明小BF16复制的原值、writer/readers/取消/退休及原预算；再最多一个原K1两轮消费者，全部非时间/work/ledger/pending/RNG严格0diff。
- 用同样完整key事实核小range纯地址miss是否实际消失，原首次/native失效仍保留；不以更少kernel/range自动签吞吐。
- 若copy的host/Queue依赖开销抵消冷录制减少，或固定入口不能保持原权限，不做正式性能窗；本诊断没有计时收益结论。
