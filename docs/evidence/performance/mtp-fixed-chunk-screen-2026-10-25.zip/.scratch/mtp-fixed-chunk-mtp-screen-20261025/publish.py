from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
P=R/'.scratch/mtp-fixed-chunk-screen-20261025'
C=R/'.scratch/mtp-fixed-chunk-20261025'
E=R/'docs/evidence/performance'
NAME='mtp-fixed-chunk-screen-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def pin(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=h.hexdigest())

assert not(E/(NAME+'.json')).exists()and not(E/(NAME+'.zip')).exists()
review=C/'cold-policy-review.json'
assert pin(review)['sha256']=='c4709aaa8696add24cfb6d9cc3268dce9bb4ff51a0b1435b51363af1347fa5bf'
mtp=read(S/'summary.json');ordinary=read(P/'summary.json');classification=read(P/'difference-classification.json')
assert mtp['process_count']==6 and mtp['all_non_time_equal']and ordinary['accounting']['actual_started_processes']==2
assert classification['total']==1034 and not classification['unclassified']
processes=[]
for directory,kind in((P,'original12plan_stopped_ordinary'),(S,'separately_authorized_MTP6')):
    for p in sorted((directory/'runs').glob('*/result.json')):
        x=read(p);assert x['exit']==0 and not x.get('timeout')and not x['reader_errors']
        processes.append(dict(screen=kind,folder=p.parent.relative_to(R).as_posix(),pid=x['pid'],exit=x['exit'],
            started_unix_ns=x['started_unix_ns'],finished_unix_ns=x['finished_unix_ns'],process_wall_seconds=x['process_wall_seconds'],
            result=pin(p),image=x['image']))
assert len(processes)==8
cleanup_files=[]
for name in('cleanup-candidates.json','clean-cleanup-candidates.json'):
    for item in read(C/name)['files']:
        actual=pin(Path(item['path']));assert actual['bytes']==item['bytes']and actual['sha256']==item['sha256']
        cleanup_files.append(dict(relative_repository_path=actual['path'],bytes=actual['bytes'],sha256=actual['sha256']))
assert len(cleanup_files)==9 and len({x['relative_repository_path']for x in cleanup_files})==9
assert sum(x['bytes']for x in cleanup_files)==294658426
cleanup=dict(performed=False,files=cleanup_files,count=9,logical_bytes=294658426,
    scope='Only prototype native CUDA OBJ, diagnostic-link and clean-link EXE/EXP/LIB/DLL outputs under .scratch/mtp-fixed-chunk-20261025. No deletion performed here.',
    hardlink_note='Two staged native DLLs are hardlinks to preserved baseline DLL; logical bytes are not exclusive physical storage.',
    excluded=['Old native-plan5 diagnostic binaries/provider diagnostic OBJ: separately inventoried and cleaned by root branch.',
        'Independent numeric7 binaries: separate RemoveFixedChunkNumericBinaries branch.',
        'Original canonical provider4d69, original native batch OBJ, clean c343 baseline, original Graph/app/report/SDK closure.'])
save(S/'prototype-cleanup-candidates.json',cleanup)
decision=dict(status='CLOSED_NOT_MERGED',decision_owner='root',
    reason='MTP-only short-context descriptive benefit is limited (+1.396% decode/+1.241% combined). A safe product implementation additionally needs an immutable bounded cold policy and conservative workspace bounds; ordinary continuation changes need quality consideration. This limited benefit does not justify expanding this candidate or its validation scope in this round.',
    not_claimed=['Not a demonstrated algorithm error: independent numeric tolerance passed and reduction partitioning changes rounding.',
        'Not zero observed benefit, and not a generic requirement that all optimizations preserve greedy token identity.',
        'Not a long-context GPU failure: capacity rejection is an offline source/formula review.'],
    product_changes=0,followup_candidate_work='closed; no automatic further tests/candidates')
save(S/'decision.json',decision)

# Preserve source, original failure and raw eight-process records. Derived schema
# caches are reproducible from bundled raw logs and the unchanged parser.
payloads=[]
exclude_names={'proof.zip','proof-pins.json','proof-package.json','consumer-result.json','observation.json'}
for directory in(P,S):
    payloads.extend(p for p in directory.rglob('*')if p.is_file()and p.name not in exclude_names and
                    p.suffix.lower()not in{'.exe','.obj','.lib','.exp','.dll','.pdb','.map','.pyc'}and p.name!='publication-payloads.json')
prototype_names=['before-native_batch.cu','overlay/native_batch.cu','overlay/native_batch.h','source.patch','source-pins.json',
    'header-declarations-only.patch','check.py','plan.md','compile/command.json','compile/process.json','compile/stdout.log','compile/stderr.log',
    'clean-closure-delta.json','clean-image.json','clean-plan.md','prepare_clean.py','clean-link/command.json','clean-link/process.json',
    'clean-link/stdout.log','clean-link/stderr.log','cold-policy-review.json','clean-proof-package.json','proof-package.json']
payloads.extend(C/name for name in prototype_names)
numeric=R/'docs/evidence/correctness/mtp-fixed-chunk-numeric-2026-10-25.json'
payloads.append(numeric)
payloads=sorted(set(payloads))
entries=[pin(p)for p in payloads]
save(S/'publication-payloads.json',dict(files=entries,count=len(entries),payload_bytes=sum(x['bytes']for x in entries),
    exclusions='No OBJ/EXE/DLL/LIB/MAP/PDB/weights/SDK. Generated consumer-result/observation caches omitted; bundled raw stdout/stderr and unchanged parser can regenerate them. Existing private archives remain unchanged. Recipe/dependency paths not listed here are explicit external source/cache pins.'))
payloads.append(S/'publication-payloads.json')
archive=E/(NAME+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in payloads:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    for item in entries:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
public=dict(date='2026-10-25',status='CLOSED_NOT_MERGED',decision=decision,archive=pin(archive),
    scope='Private fixed512-logical-KV-row planning candidate; only C1024/N1/R1 two-turn greedy natural coding schedule. No product change.',
    chronology=[dict(stage='original12_process_value_screen',planned=12,actual=2,ordinary_processes=2,MTP_processes=0,
        result='Stopped on candidate ordinary token divergence; remaining10 never started; no retry or samples silently removed.'),
        dict(stage='separately_authorized_MTP_only_screen',planned=6,actual=6,order=['B','C','C','B','B','C'],
        result='All six native processes exit0; same128 IDs/work and every raw non-time field. Three fresh processes per image.')],
    actual_timing_screen_processes=8,actual_processes=processes,GPU_released=True,
    process_scope='Eight processes are the two performance screens only; prior one-shot native diagnostics and the separately linked numeric evidence are supporting phases, not pooled timing samples.',
    MTP=dict(groups=mtp['groups'],median_ratios=mtp['median_ratios'],all_raw_non_time_equal=True,
        work=dict(outputs=128,decode_outputs=126,prefill_target_rows=309,prefill_draft_rows=310,actual_target_rows=441,
            actual_draft_rows=434,draft_rounds=66,consumed_drafts=60,graph_calls=68),
        endpoint_scope=mtp['endpoints'],evidence=pin(S/'summary.json')),
    ordinary=dict(status='FAILED_STRICT_NON_TIME_EQUIVALENCE_not_algorithm_error_certificate',native_exit_codes=[0,0],
        original_parser_both_passed=True,first_divergence=ordinary['first_divergence'],token_derived_difference_classification=classification,
        work_context_rows_budgets_and_other_non_time_fields_equal=True,
        no_completed_ordinary_performance_comparison=True,first_failure=pin(P/'failure.json'),
        actual_accounting=read(P/'actual-terminal-accounting.json'),original_proof_unchanged=pin(P/'proof.zip')),
    numeric_evidence=dict(path=numeric.relative_to(R).as_posix(),identity=pin(numeric),archive=read(numeric)['archive'],
        scope='Independent original double oracle, bounded R1/H8/KV2/D256/page16 BF16 Q1/KV129 and Q2/KV257/385/513; not bit identity or whole-model task quality.'),
    long_capacity_review=dict(identity=pin(review),kind='read_only_source_formula_review_not_GPU_run',
        example=read(review)['definite_issue'],design_status='Optional capacity<=1024 immutable cold-policy/conservative-bound design was not implemented; candidate closed.'),
    sources=dict(clean_closure=pin(C/'clean-closure-delta.json'),clean_image=read(C/'clean-image.json'),candidate_source=pin(C/'source-pins.json')),
    cleanup=cleanup,timer=mtp['timer'],
    limitations=mtp['limitations']+['No VRAM/memory process window or peer comparison in these screens.',
        'Performance was assessed only after independent numeric tolerance passed; ordinary divergence remains visible and is not reclassified as equivalent-PASS.',
        'The source/helper descriptor domain is broader than the privately measured C1024 capacity; long-context safety is not inferred from this short window.',
        'Prior clean-image/source receipts describe their creation-time process count; this publication chronology/process results are authoritative for actual screen counts.'],
    SDK_builds_in_screens=0,HTTP=0,product_edits=0,archive_entries=len(payloads),payload_manifest=pin(S/'publication-payloads.json'))
save(E/(NAME+'.json'),public)
save(S/'publication.json',dict(json=pin(E/(NAME+'.json')),archive=pin(archive),cleanup=pin(S/'prototype-cleanup-candidates.json'),
    archive_entries=len(payloads),status='CLOSED_NOT_MERGED',actual_screen_processes=8,GPU_released=True))
print(json.dumps(read(S/'publication.json')))
