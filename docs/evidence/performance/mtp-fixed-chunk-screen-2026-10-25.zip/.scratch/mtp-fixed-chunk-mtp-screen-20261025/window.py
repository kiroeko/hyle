from pathlib import Path
import importlib.util,json,os,sys,traceback
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
P=R/'.scratch/mtp-fixed-chunk-screen-20261025'
spec=importlib.util.spec_from_file_location('frozen_first_window',P/'window.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
w=previous.w;B=previous.B;C=previous.C
read,save,pin=previous.read,previous.save,previous.pin

def make_plan():
    p=previous.make_plan()
    before=read(B/'two-turn-timing/02-hyle_mtp/command.json')['command']
    commands=[]
    for i,which in enumerate(('baseline','candidate','candidate','baseline','baseline','candidate'),1):
        command=before[:];command[0]=p['images'][which]['path']
        commands.append(dict(ordinal=i,arm=which+'_mtp',which=which,
            folder=str(S/'runs'/f'{i:02}-{which}_mtp'),command=command,image=p['images'][which]))
    p.update(status='frozen_before_reading_new_timing',commands=commands,arm_order=[x['arm']for x in commands],
        timing_processes=6,private_script=pin(Path(__file__)),retained_window=pin(P/'window.py'),
        original_ordinary_failure=pin(P/'failure.json'),original_ordinary_proof=pin(P/'proof.zip'),
        original_ordinary_difference_classification=pin(P/'difference-classification.json'),
        total_authorized_scope=dict(prior_ordinary_started=2,new_MTP_maximum=6,total_maximum=8,ordinary_additions=0),
        predeclared_gate='Each case must pass original parser and all raw non-time fields must equal the retained baseline MTP reference; first mismatch retained and stops without retry. No bitwise gate claimed for generic optimization acceptance.',
        scope='Private MTP-only C1024/N1/R1/K1 value screen: six fresh processes B,C,C,B,B,C. Same clean images, arguments, clocks and parser. No peer/memory/diagnostic/build/profile/warmup/new candidate. Ordinary divergence remains separate failed-equivalence evidence. Known long-context64MiB risk remains.')
    return p

def run():
    assert not(S/'runs').exists()
    plan=make_plan();save(S/'plan.json',plan)
    helpers=w.helpers();results=[];started=[]
    env=dict(os.environ,PATH=read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    helpers.gpu_snapshot(S,'window-before')
    try:
        for entry in plan['commands']:
            assert pin(Path(entry['command'][0]))==entry['image']
            folder=Path(entry['folder']);started.append(entry['ordinal'])
            print('BEGIN',entry['ordinal'],entry['arm'],flush=True)
            process=helpers.execute(folder,'hyle_mtp',entry['command'],env,False)
            observation=w.parse(folder,'hyle_mtp',plan)
            assert not any(x.startswith('NPLAN ')for x in(folder/'stderr.log').read_text().splitlines())
            reference=B/'two-turn-timing/02-hyle_mtp/stdout.log'
            differences=previous.diff(previous.clean(previous.raw_report(reference)),previous.clean(previous.raw_report(folder/'stdout.log')))
            save(folder/'non-time-comparison.json',dict(equal=not differences,differences=differences,
                excluded_paths=sorted(set(previous.excluded)),reference=pin(reference),actual=pin(folder/'stdout.log'),
                criterion='Only exact seconds/_seconds/tokens_per_second fields excluded; no non-time exceptions'))
            save(folder/'observation.json',observation)
            if differences:raise ValueError('Actual MTP non-time divergence; stop without retry: '+str(folder))
            result=dict(ordinal=entry['ordinal'],arm=entry['arm'],which=entry['which'],folder=str(folder),process=process,
                metrics=observation['metrics'],work=observation['work'],generated_ids=observation['generated_ids'],
                actual_context=observation['actual_context'],all_non_time_equal=True,
                raw_stdout=pin(folder/'stdout.log'),raw_stderr=pin(folder/'stderr.log'))
            results.append(result);save(S/'runs.json',results)
            print('PASS',entry['ordinal'],entry['arm'],json.dumps(result['metrics']),flush=True)
    except Exception as exc:
        save(S/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc(),actual_started=len(started),
            equivalent_processes=len(results),failed_ordinal=entry['ordinal'],failed_folder=entry['folder'],automatic_retry=False))
        raise
    finally:
        helpers.gpu_snapshot(S,'window-after')
        actual=list((S/'runs').glob('*/result.json'))
        save(S/'terminal.json',dict(actual_started=len(started),actual_terminal=len(actual),
            equivalent_processes=len(results),all_requested_completed=len(results)==6,
            images_unchanged={k:pin(Path(v['path']))==v for k,v in plan['images'].items()},GPU='released after terminal'))
    analyze()

def analyze():
    runs=read(S/'runs.json');assert len(runs)==6
    groups={}
    for which in('baseline','candidate'):
        selected=[x for x in runs if x['which']==which];assert len(selected)==3
        assert all(x['generated_ids']==runs[0]['generated_ids']and x['work']==runs[0]['work']and x['all_non_time_equal']for x in selected)
        groups[which]={k:previous.base.stats([x['metrics'][k]for x in selected if x['metrics'][k]is not None])for k in selected[0]['metrics']}
    ratios={k:dict(candidate_over_baseline=groups['candidate'][k]['median']/groups['baseline'][k]['median'],
                  percent_change=(groups['candidate'][k]['median']/groups['baseline'][k]['median']-1)*100)
        for k in('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','prefill_seconds','decode_seconds','session_seconds')}
    save(S/'summary.json',dict(status='six_fresh_MTP_processes_passed_all_non_time_equal',groups=groups,median_ratios=ratios,
        process_count=6,prior_ordinary_processes=2,total_native_processes_in_two_screens=8,
        timer=read(S/'plan.json')['timer'],plan=pin(S/'plan.json'),runs=pin(S/'runs.json'),terminal=read(S/'terminal.json'),
        all_non_time_equal=True,ordinary_equivalence=False,ordinary_evidence=pin(P/'proof.zip'),
        endpoints='Original top-level continuous P+D=session. Prefill309 actual target input rows; decode126 emitted outputs; combined128 outputs/session. No warmup or endpoint work moved out.',
        limitations=['Only three samples per image: descriptive median/min/max and all raw samples; no statistical significance claim.',
            'MTP-only C1024/N1/R1/K1/greedy identical continuation/work. No ordinary speed claim or all-model/all-context merge acceptance; ordinary token divergence and known long-context64MiB risk remain.',
            'Original producer/runner clocks and default stderr preserved; no profiler/memory sampler, GPU fixed clocks or desktop/page-cache/thermal control.',
            'Numeric F64 evidence is independent prior work; this window checks output/work equivalence and rates, not full task quality.',
            'No historical timing pooling, peer measurements, candidate/algorithm changes or retries.'],
        HTTP=0,SDK_builds=0,product_edits=0))
    print('COMPLETE',json.dumps(ratios),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='plan':save(S/'plan.json',make_plan());print('FROZEN_SIX_MTP_PLAN_NO_MODEL')
    elif sys.argv[1]=='run':run()
    elif sys.argv[1]=='analyze':analyze()
