# 固定512行KV分块：私有原型

只改私有`native_batch.cu`的纯冷helper，并让`query_batch_workspace`及`plan_batch`共同使用。条件严格为paged、BF16非FP8、causal、window=-1、R1、实际Q1/Q2、qk/value相等且在原64/128/256支持域；page_size必须为512正因子，转换后的pages须为正I32，否则保持原-1。固定值不随当前KV长度变化。

保留原scheduler、enable_cuda_graph=false、disable_split=false、数学方程、ABI、provider reuse检查、预算、owner/权限/退休机制。512行只改变scheduler规划选择；具体split是否发生由原scheduler决定，不声称逐位浮点相同。

使用原成功`native-batch-portable-llp64-posenc-command.json`和全部portable preincludes。`source-results.zip`中的原cu与canonical逐字相同，旧header仅比当前少新增函数声明，结构/inline/既有声明相同；私有TU使用完整旧header。只编1 CUDA TU，不改SDK/vendor缓存。

先链接一个诊断image：clean c343闭包只替一个native batch OBJ以及前一批保原算法的provider诊断OBJ。最多一次原MTP两轮，无GPU profile/下载/其它候选/其它分块/普通进程；终态后停止并交root决定。全部raw非时间差异、IDs/work、fresh/reuse分布如实保存；该插桩进程不作TPS证据，也不代替完整logits或任务质量检查。

实际已终态：1 CUDA TU编译exit0（57.703s），链接exit0（1.703s），唯一原MTP两轮进程exit0（4.016s），无timeout/重跑。GPU已释放，不再追加运行。全部非时间raw报告相等；fresh plan47→26、reuse427→448、chunk_count拒绝21→0。数值oracle、512边界与TPS未做，结果不承担这些结论。详细记录、源pins和精确未执行清理清单见summary/proof。
