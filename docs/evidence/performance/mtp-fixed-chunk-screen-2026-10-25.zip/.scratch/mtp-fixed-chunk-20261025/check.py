from pathlib import Path
import difflib,hashlib,importlib.util,json,os,re,sys,zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
OLD=R/'.scratch/inference-feature-completion-2026-10-18/windows-batch'
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
D=R/'.scratch/mtp-native-plan-diagnostics-20261025'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

def prepare():
    src=R/'src/compute_provider_flashinfer/native_batch.cu'
    raw=src.read_bytes();original=raw.decode('utf-8')
    with zipfile.ZipFile(OLD/'source-results.zip')as z:
        frozen=z.read('frozen/src/compute_provider_flashinfer/native_batch.cu')
        header=z.read('frozen/src/compute_provider_flashinfer/native_batch.h')
        scheduler=z.read('scheduler.portable.cuh')
    assert raw==frozen and hashlib.sha256(raw).hexdigest()=='c17e99b53e793e3357b36eec288d2a1e36211081b95a8d2145c4ff3b4234d6da'
    assert scheduler==(OLD/'scheduler.portable.cuh').read_bytes()
    current_header=(R/'src/compute_provider_flashinfer/native_batch.h').read_text()
    old_lines=header.decode().splitlines(True);new_lines=current_header.splitlines(True)
    diff=list(difflib.unified_diff(old_lines,new_lines,fromfile='frozen/native_batch.h',tofile='canonical/native_batch.h'))
    changed=[x for x in diff if x.startswith(('+','-'))and not x.startswith(('+++','---'))]
    assert len(changed)==7 and all(x.startswith('+')and x.rstrip().endswith(';')for x in changed)
    helper='''// FIXED_KV_CHUNK_PRIVATE_BEGIN
namespace {
std::int32_t fixed_kv_chunk_pages(BatchSpec s) noexcept {
  constexpr std::uint32_t logical_rows = 512;
  if (!s.paged || !s.bfloat16 || s.fp8 || !s.causal || s.window_left != -1 ||
      s.requests != 1 || (s.query_rows != 1 && s.query_rows != 2) ||
      s.qk_head_dim != s.value_head_dim ||
      (s.qk_head_dim != 64 && s.qk_head_dim != 128 && s.qk_head_dim != 256) ||
      s.page_size == 0 || logical_rows % s.page_size != 0)
    return -1;
  const auto pages = logical_rows / s.page_size;
  if (pages == 0 || pages > 0x7fffffffU) return -1;
  return static_cast<std::int32_t>(pages);
}
} // namespace
// FIXED_KV_CHUNK_PRIVATE_END
'''
    anchor='cudaError_t query_batch_workspace('
    assert original.count(anchor)==1
    out=original.replace(anchor,helper+anchor,1)
    old='s.window_left,-1,false,0,0,stream'
    new='s.window_left,fixed_kv_chunk_pages(s),false,0,0,stream'
    assert out.count(old)==2
    out=out.replace(old,new)
    restored=re.sub(r'// FIXED_KV_CHUNK_PRIVATE_BEGIN\n.*?// FIXED_KV_CHUNK_PRIVATE_END\n','',out,flags=re.S).replace(new,old)
    assert restored.encode()==raw
    (S/'overlay').mkdir(exist_ok=True)
    (S/'overlay/native_batch.cu').write_text(out,encoding='utf-8',newline='\n')
    (S/'overlay/native_batch.h').write_bytes(header)
    (S/'before-native_batch.cu').write_bytes(raw)
    (S/'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),out.splitlines(True),fromfile='canonical/native_batch.cu',tofile='private/native_batch.cu')),encoding='utf-8')
    (S/'header-declarations-only.patch').write_text(''.join(diff),encoding='utf-8')
    cmd=b.read(OLD/'native-batch-portable-llp64-posenc-command.json')['command']
    preincludes=[Path(cmd[i+1])for i,x in enumerate(cmd)if x=='--pre-include']
    provider=D/'compile/provider.obj'
    assert b.pin(provider)['sha256']=='5cdedea79fa7a51edefc678089e79ad835abe988bf1c7751f68ea2cf090abc0b'
    b.save(S/'source-pins.json',dict(original=b.pin(src),frozen_archive=b.pin(OLD/'source-results.zip'),
        overlay=b.pin(S/'overlay/native_batch.cu'),header=b.pin(S/'overlay/native_batch.h'),
        header_delta='Only seven additional unrelated function declarations; original structures/inline/decls byte-unchanged.',
        restored_sha256=hashlib.sha256(restored.encode()).hexdigest(),restored_byte_equal=True,
        argument_sites=2,original_command=b.pin(OLD/'native-batch-portable-llp64-posenc-command.json'),
        portable_preincludes=[b.pin(x)for x in preincludes],provider_diagnostic_object=b.pin(provider),
        provider_diagnostic_source_contract=b.pin(D/'equivalence.json'),baseline_image=b.pin(B/'link/hyle.exe')))
    print('SOURCE_EQUIVALENCE_PASS',flush=True)

def build():
    cmd=b.read(OLD/'native-batch-portable-llp64-posenc-command.json')['command'][:]
    source=str(R/'src/compute_provider_flashinfer/native_batch.cu');assert cmd.count(source)==1
    cmd=[str(S/'overlay/native_batch.cu')if x==source else x for x in cmd]
    cmd[cmd.index('-o')+1]=str(S/'compile/native-batch.obj')
    host=cmd[cmd.index('--compiler-bindir')+1]
    env=b.environment(str(Path(host)/'cl.exe'))
    b.execute(cmd,S/'compile',env,240)
    link=b.read(B/'link/command.json')['command'][:]
    native=str(OLD/'native-batch-portable-llp64-posenc.obj')
    provider=str(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_flashinfer--flashinfer_provider.obj')
    assert link.count(native)==link.count(provider)==1
    link=[str(S/'compile/native-batch.obj')if x==native else str(D/'compile/provider.obj')if x==provider else x
          for x in link if not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
    link+=['/OUT:'+str(S/'link/hyle.exe')]
    b.execute(link,S/'link',env,120)
    dll=B/'link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(dll,S/'link'/dll.name)
    b.save(S/'ready.json',dict(image=b.pin(S/'link/hyle.exe'),native_object=b.pin(S/'compile/native-batch.obj'),
        provider_object=b.pin(D/'compile/provider.obj'),original_native_object=b.pin(Path(native)),original_provider_object=b.pin(Path(provider)),
        baseline=b.pin(B/'link/hyle.exe'),source=b.pin(S/'source-pins.json'),
        SDK_builds=0,HTTP=0,host_TUs_built=0,CUDA_TUs_built=1,Graph_TUs_built=0))

def run():
    cmd=b.read(B/'two-turn-timing/02-hyle_mtp/command.json')['command'][:]
    assert b.pin(Path(cmd[0]))['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
    cmd[0]=str(S/'link/hyle.exe')
    env=dict(os.environ,PATH=str(S/'link')+';'+b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    b.execute(cmd,S/'run',env,120)

if __name__=='__main__':{'prepare':prepare,'build':build,'run':run}[sys.argv[1]]()
