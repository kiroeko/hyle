from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
D=R/'.scratch/mtp-native-plan-diagnostics-20261025'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def pin(p):
    h=hashlib.sha256()
    with p.open('rb')as f:
        for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())

before=b.read(B/'link/command.json')['command']
native=R/'.scratch/inference-feature-completion-2026-10-18/windows-batch/native-batch-portable-llp64-posenc.obj'
new_native=S/'compile/native-batch.obj'
assert before.count(str(native))==1
provider=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_flashinfer--flashinfer_provider.obj'
assert before.count(str(provider))==1
assert pin(provider)['sha256']=='4d69d0689714294b5c21dee97d1e9ca91ba6455bf0782b1ba26341a264d1660a'
after=[str(new_native)if x==str(native)else '/OUT:'+str(S/'clean-link/hyle.exe')if x.upper().startswith('/OUT:')else x for x in before]
changes=[dict(index=i,before=a,after=z)for i,(a,z)in enumerate(zip(before,after))if a!=z]
assert len(before)==len(after)==240 and len(changes)==2
assert changes[0]['before']==str(native)and changes[1]['before'].upper().startswith('/OUT:')
absolute_inputs=[Path(x)for x in before if Path(x).is_absolute()and x.lower().endswith(('.obj','.lib'))]
assert len(absolute_inputs)==218 and len(set(absolute_inputs))==218
unchanged=[pin(p)for p in absolute_inputs if p!=native]
assert len(unchanged)==217
assert str(D/'compile/provider.obj')not in after
bare_libs=[x for x in before if not Path(x).is_absolute()and x.lower().endswith('.lib')]
assert len(bare_libs)==13
manifest=dict(original_command=pin(B/'link/command.json'),argv_count=len(after),argument_changes=changes,
    absolute_inputs=218,unchanged_absolute_inputs=unchanged,changed_native=dict(before=pin(native),after=pin(new_native)),
    unchanged_system_libraries=bare_libs,all_other_arguments_byte_equal=True,
    scope='Only NativeBatch OBJ changes in the entire clean baseline link closure; OUT redirected. Original app/report/Graph/provider/SDK objects retained.',
    canonical_provider=pin(provider),source=pin(S/'source-pins.json'),
    domain=dict(paged=True,bfloat16=True,fp8=False,causal=True,window_left=-1,requests=1,actual_query_rows=[1,2],
        equal_qk_value_head_dimensions=[64,128,256],positive_page_size_divides_logical_rows=512,
        positive_signed_I32_chunk_pages_required=True,fallback_fixed_split_size=-1),
    no_ModelID=True,no_user_parameter_or_new_macro=True,original_ABI_unchanged=True,
    enable_cuda_graph=False,disable_split_kv=False,mathematical_equations_unchanged=True,
    reduction_partition_may_differ=True,original_provider_reuse_permission_retirement_budget_unchanged=True)
b.save(S/'clean-closure-delta.json',manifest)
env=b.environment(b.read(D/'compile/command.json')['command'][0])
b.execute(after,S/'clean-link',env,120)
original_dll=B/'link/hyle_ggml_cpu_gdn_scale_v3.dll'
os.link(original_dll,S/'clean-link'/original_dll.name)
image=pin(S/'clean-link/hyle.exe')
b.save(S/'clean-image.json',dict(image=image,baseline=pin(B/'link/hyle.exe'),closure=pin(S/'clean-closure-delta.json'),
    original_provider=pin(provider),candidate_native=pin(new_native),source=pin(S/'source-pins.json'),
    diagnostic_provider_present=False,diagnostic_Graph_present=False,private_app_or_report_clocks=False,
    model_processes=0,TPS_measured=False,CUDA_TUs_rebuilt=0,SDK_builds=0,HTTP=0,
    runtime=pin(B/'runtime.json'),dll=pin(S/'clean-link'/original_dll.name)))
paths=sorted(p for p in(S/'clean-link').iterdir()if p.is_file()and p.suffix.lower()in{'.exe','.exp','.lib','.dll','.pdb','.map','.obj'})
cleanup=[dict(relative_repository_path=p.relative_to(R).as_posix(),**pin(p))for p in paths]
b.save(S/'clean-cleanup-candidates.json',dict(performed=False,count=len(cleanup),logical_bytes=sum(x['bytes']for x in cleanup),files=cleanup,
    scope='Only new clean-link outputs; reused native candidate OBJ and two original diagnostic images remain in prior inventories.',
    hardlink_note='DLL hardlinked to preserved baseline, logical bytes not exclusive physical bytes.'))
print(json.dumps(dict(image=image,unchanged_absolute_inputs=217,model_processes=0,cleanup_logical_bytes=sum(x['bytes']for x in cleanup))))
