# Clean candidate：仅离线链接

已用clean c343的原240参数链接：只替NativeBatch OBJ及输出路径。其余217个绝对OBJ/LIB逐文件bytes/SHA已保存，13个系统裸库名和所有flags原样。原provider为`4d69d068...`，原app/report/四Graph对象完全复用，没有本批观察器、私有时钟或热日志。

Helper只依赖真实BatchSpec：paged、BF16、非FP8、causal、window=-1、单request、actual Q1/Q2、相等qk/value维度64/128/256；page_size正且整除512、转换pages正且I32安全，否则原-1。无ModelID、用户选项或宏；ABI、原生数学方程、reuse检查、权限、退休、预算均未改变，归约分块和浮点舍入仍可能变化。

此次只链接1.703s，没有再次编译，没有运行模型/TPS/数值case，GPU仍已释放。两个诊断image、provider观察OBJ和native candidate OBJ全部保留；新clean输出精确4项另列清理清单，未执行清理。原诊断proof.zip及其pins保持不变，clean资料单独归档。
