from pathlib import Path
import collections,hashlib,json,re
S=Path(__file__).resolve().parent
p=S/'runs/02-candidate_plain/non-time-comparison.json'
d=json.loads(p.read_text())['differences'];counts=collections.Counter();unknown=[]
allowed={'next_id','target_first','before_next_id','committed_input_ids','first_input','input_hash','verification_input_ids'}
for x in d:
    path=x['path'];match=re.fullmatch('/sessions/0/ledger/[0-9]+/([^/]+)(?:/[0-9]+)?',path)
    if match and match[1]in allowed:counts['ledger/'+match[1]]+=1
    elif re.fullmatch('/sessions/0/result/generated_ids/[0-9]+',path):counts['generated_ids']+=1
    elif re.fullmatch('/sessions/0/result/rounds/[0-9]+/(next_id|pending)',path):counts['rounds/'+path.rsplit('/',1)[1]]+=1
    elif path in('/sessions/0/result/emitted_pending','/sessions/0/result/fresh_next_id'):counts[path.rsplit('/',1)[1]]+=1
    elif path=='/sessions/0/result/turns/1/input_ids/0':counts['turn2_pending_input']+=1
    else:unknown.append(x)
assert sum(counts.values())==1034 and not unknown
out=dict(total=1034,categories=dict(counts),unclassified=unknown,all_other_non_time_fields_equal=True,
    source=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),
    scope='Exhaustive classification of the original failed equality comparison. Does not convert token divergence into equivalent-PASS or an algorithm-error claim; work/context/lengths/frontiers/lag/RNG/rows/calls/budgets have no differing paths.',
    original_proof_preserved=dict(path=str(S/'proof.zip'),bytes=(S/'proof.zip').stat().st_size,sha256=hashlib.sha256((S/'proof.zip').read_bytes()).hexdigest()))
(S/'difference-classification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
