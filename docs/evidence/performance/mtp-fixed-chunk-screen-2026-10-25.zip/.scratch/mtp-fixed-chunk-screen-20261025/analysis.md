# C1024价值筛查：首个实际续文差异后停止

计划普通／K1 MTP各base/candidate三轮交错12进程，实际只启动前2个普通进程，两者exit0且原parser通过。baseline全部非时间报告与原基线相同；candidate首18输出相同，第19个token为11而原为271，最终128输出中104处不同。关联pending/ledger输入hash、第二轮pending随之改变；共1034个非时间路径差异，顶层模式/工作行数/调用数/几何/资源预算标量不变。

原raw、首次failure、comparison和stderr全部保存，没有重跑或换参数。原terminal中的completed_processes=1指通过等价核的1例；actual-terminal-accounting明确实际2个native进程已终态、2个parser通过、1个等价失败、10个未启动。GPU已释放。

分块改变归约舍入，独立F64容差通过并不保证greedy token逐位相等；当前没有首分歧logits或margin，不能把续文分叉直接判为算法错误。也不能悄悄忽略差异：剩余输入已不同，本轮不计算同输出收益或三样本分布。两进程原始prefill/decode/combined端点和速率仅作为原始记录保留，不形成速度结论。

没有MTP计时进程、peer、内存窗、profile、新候选/模型/权重或产品修改。已知长上下文64MiB风险仍在；候选关闭或后续处置由root决定，不自动续跑。
