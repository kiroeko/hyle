from pathlib import Path
import hashlib,importlib.util,json,os,statistics,sys,traceback
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
C=R/'.scratch/mtp-fixed-chunk-20261025'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
w=module('frozen_c343_window',B/'window.py')
w.WORKLOAD='two-turn'
base=w.base
def read(p):return base.read(p)
def save(p,x):base.save(p,x)
def pin(p):return base.identity(p)
def raw_report(p):return json.loads(next(x for x in p.read_text().splitlines()if x.startswith('{')))
excluded=[]
def clean(x,path=''):
    if isinstance(x,dict):
        out={}
        for k,v in x.items():
            if k=='seconds'or k.endswith('_seconds')or'tokens_per_second'in k:excluded.append(path+'/'+k)
            else:out[k]=clean(v,path+'/'+k)
        return out
    if isinstance(x,list):return[clean(v,path+'/'+str(i))for i,v in enumerate(x)]
    return x
def diff(a,b,path=''):
    if type(a)!=type(b):return[dict(path=path,baseline=a,actual=b)]
    if isinstance(a,dict):
        out=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b:out.append(dict(path=path+'/'+k,baseline=a.get(k),actual=b.get(k)))
            else:out.extend(diff(a[k],b[k],path+'/'+k))
        return out
    if isinstance(a,list):
        if len(a)!=len(b):return[dict(path=path,baseline_length=len(a),actual_length=len(b))]
        return[d for i,(x,y)in enumerate(zip(a,b))for d in diff(x,y,path+'/'+str(i))]
    return[]if a==b else[dict(path=path,baseline=a,actual=b)]

def make_plan():
    baseline=pin(B/'link/hyle.exe');candidate=pin(C/'clean-link/hyle.exe')
    assert baseline['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
    assert candidate['sha256']=='10bce5ec0b40d2b6181b072a83cd514aa2e36c63fb42f6a50b4d2001cb91366a'
    native=read(C/'clean-image.json');assert not native['diagnostic_provider_present']and not native['diagnostic_Graph_present']and not native['private_app_or_report_clocks']
    source=read(C/'source-pins.json');assert source['restored_byte_equal']and source['argument_sites']==2
    oldcmd=read(B/'link/command.json')['command'];newcmd=read(C/'clean-link/command.json')['command']
    changes=[dict(index=i,before=a,after=z)for i,(a,z)in enumerate(zip(oldcmd,newcmd))if a!=z]
    assert len(oldcmd)==len(newcmd)==240 and len(changes)==2
    assert changes[0]['after']==native['candidate_native']['path']and changes[1]['after'].startswith('/OUT:')
    assert native['original_provider']['sha256']=='4d69d0689714294b5c21dee97d1e9ca91ba6455bf0782b1ba26341a264d1660a'
    arms=('baseline_plain','candidate_plain','baseline_mtp','candidate_mtp')
    commands=[]
    for round_ in range(3):
        for i in range(4):
            arm=arms[(i+round_)%4];mode='mtp'if arm.endswith('_mtp')else'plain'
            template=B/'two-turn-timing'/('02-hyle_mtp'if mode=='mtp'else'01-hyle_plain')/'command.json'
            cmd=read(template)['command'][:]
            if arm.startswith('candidate'):cmd[0]=candidate['path']
            for flag,value in(('--capacity','1024'),('--max-sessions','1'),('--active-sequences','1'),('--mtp','on'if mode=='mtp'else'off'),('--backend','cuda'),('--sampling','greedy'),('--prefix-cache','off'),('--replay','auto'),('--progress','direct')):
                assert cmd.count(flag)==1 and cmd[cmd.index(flag)+1]==value
            assert '--trace'not in cmd and '--memory-snapshots'not in cmd
            if mode=='mtp':assert cmd[cmd.index('--mtp-max-drafts')+1]=='1'
            ordinal=len(commands)+1
            commands.append(dict(ordinal=ordinal,round=round_+1,arm=arm,mode=mode,logical_arm='hyle_'+mode,
                folder=str(S/'runs'/f'{ordinal:02}-{arm}'),command=cmd,image=baseline if arm.startswith('baseline')else candidate,
                original_command=pin(template)))
    schedule=Path(commands[0]['command'][commands[0]['command'].index('--schedule')+1])
    manifest=Path(commands[0]['command'][commands[0]['command'].index('--inputs')+1])/'weights.tsv'
    return dict(status='planned',commands=commands,arm_order=[x['arm']for x in commands],
        images=dict(baseline=baseline,candidate=candidate),candidate_clean_manifest=pin(C/'clean-image.json'),
        clean_closure=pin(C/'clean-closure-delta.json'),link_argument_changes=changes,source=pin(C/'source-pins.json'),
        runtime=pin(B/'runtime.json'),schedule=pin(schedule),manifest=pin(manifest),
        capacity=1024,N=1,R=1,user_ids=[int(x)for x in(R/'.scratch/qwen-mtp-window-20261022/inputs/prompt.ids').read_text().split()],
        quota=64,turn_count=2,timer=base.timer_info(),
        runner=pin(base.RUNNER),window=pin(B/'window.py'),turns_parser=pin(R/'.scratch/qwen-mtp-final-window-20261024/turns.py'),
        private_script=pin(Path(__file__)),timing_processes=12,memory_processes=0,peer_processes=0,
        pre_run_numeric_evidence=pin(R/'docs/evidence/correctness/mtp-fixed-chunk-numeric-2026-10-25.json'),
        pre_run_numeric_private_proof=pin(R/'.scratch/mtp-performance-convergence-20261025/attention-numeric-plan/proof-summary.json'),
        pre_run_numeric_basis='Independent original F64 oracle PASS for Q1/KV129 and Q2/KV257/385/513, R1/H8/KVheads2/D256/page16 BF16; 43008 values per baseline/candidate process; original .007 absolute threshold, max candidate .000746/base .000798. Not rerun here.',
        scope='Private C1024 value screen only. Fixed512 has a known long-context64MiB risk; no all-context product acceptance. No new clocks/profiler/observer/warmup/SDK/download/candidate.',
        historical_timing_pooled=False)

def run():
    assert not(S/'runs').exists()
    plan=make_plan();save(S/'plan.json',plan)
    helpers=w.helpers();results=[]
    env=dict(os.environ,PATH=read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    helpers.gpu_snapshot(S,'window-before')
    try:
        for entry in plan['commands']:
            assert pin(Path(entry['command'][0]))==entry['image']
            folder=Path(entry['folder'])
            print('BEGIN',entry['ordinal'],entry['arm'],flush=True)
            process=helpers.execute(folder,entry['logical_arm'],entry['command'],env,False)
            # Retain exact existing parser/schema adaptation, no consumer endpoint changes.
            observation=w.parse(folder,entry['logical_arm'],plan)
            assert not any(x.startswith('NPLAN ')for x in(folder/'stderr.log').read_text().splitlines())
            original=B/'two-turn-timing'/('02-hyle_mtp'if entry['mode']=='mtp'else'01-hyle_plain')/'stdout.log'
            differences=diff(clean(raw_report(original)),clean(raw_report(folder/'stdout.log')))
            comparison=dict(equal=not differences,differences=differences,excluded_paths=sorted(set(excluded)),
                baseline=pin(original),actual=pin(folder/'stdout.log'),criterion='Only exact seconds/_seconds/tokens_per_second fields excluded')
            save(folder/'non-time-comparison.json',comparison)
            save(folder/'observation.json',observation)
            if differences:raise ValueError('Actual non-time behavior differs; stop without completing further cases: '+str(folder))
            result=dict(ordinal=entry['ordinal'],round=entry['round'],arm=entry['arm'],mode=entry['mode'],folder=str(folder),
                process=process,metrics=observation['metrics'],work=observation['work'],generated_ids=observation['generated_ids'],
                actual_context=observation['actual_context'],all_non_time_equal=True,raw=pin(folder/'stdout.log'))
            results.append(result);save(S/'runs.json',results)
            print('PASS',entry['ordinal'],entry['arm'],json.dumps(result['metrics']),flush=True)
    except Exception as exc:
        save(S/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc(),completed_processes=len(results),
            failed_ordinal=entry['ordinal'],failed_folder=entry['folder'],no_automatic_retry=True))
        raise
    finally:
        helpers.gpu_snapshot(S,'window-after')
        save(S/'terminal.json',dict(completed_processes=len(results),all_requested_completed=len(results)==12,
            images_unchanged={name:pin(Path(value['path']))==value for name,value in plan['images'].items()},GPU='released after terminal'))
    analyze()

def analyze():
    runs=read(S/'runs.json');assert len(runs)==12
    groups={}
    for arm in('baseline_plain','candidate_plain','baseline_mtp','candidate_mtp'):
        selected=[x for x in runs if x['arm']==arm];assert len(selected)==3
        assert all(x['generated_ids']==selected[0]['generated_ids']and x['work']==selected[0]['work']and x['all_non_time_equal']for x in selected)
        groups[arm]={key:base.stats([x['metrics'][key]for x in selected if x['metrics'][key]is not None])for key in selected[0]['metrics']}
    ratios={}
    for mode in('plain','mtp'):
        old=groups['baseline_'+mode];new=groups['candidate_'+mode]
        ratios[mode]={key:dict(candidate_over_baseline=new[key]['median']/old[key]['median'],percent_change=(new[key]['median']/old[key]['median']-1)*100)
            for key in('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','prefill_seconds','decode_seconds','session_seconds')}
    save(S/'summary.json',dict(status='12_fresh_processes_completed_all_non_time_equal',groups=groups,median_ratios=ratios,
        process_count=12,memory_processes=0,peer_processes=0,all_outputs_work_and_non_time_equal=True,
        timer=read(S/'plan.json')['timer'],plan=pin(S/'plan.json'),runs=pin(S/'runs.json'),terminal=read(S/'terminal.json'),
        endpoints='Original producer top-level continuous P+D=session; prefill309 target-input rows, decode126 emitted outputs, combined128 outputs/session. No endpoint exclusion or warmup.',
        limitations=['Three fresh processes per arm, descriptive median/min/max and raw samples only; no significance or instrument-resolution claim.',
            'Original default stderr/unitbuf, original runner clocks, no GPU profiler or memory sampler; desktop/thermal/page-cache variation uncontrolled.',
            'Private single C1024/N1/R1/greedy two-turn workload; known long-context64MiB risk remains. Not all-context merge acceptance.',
            'Independent F64 numeric evidence is root-provided separate work; this window checks reports/tokens/work, not task quality or cross-model safety.',
            'No historical timing samples pooled; historical raw reports are behavior-only references.'],HTTP=0,SDK_builds=0,product_edits=0))
    print('COMPLETE',json.dumps(ratios),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='plan':save(S/'plan.json',make_plan());print('PINNED_PLAN_NO_MODEL')
    elif sys.argv[1]=='run':run()
    elif sys.argv[1]=='analyze':analyze()
