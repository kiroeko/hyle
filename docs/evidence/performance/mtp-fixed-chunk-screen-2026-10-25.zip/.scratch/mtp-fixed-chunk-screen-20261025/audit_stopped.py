from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
C=R/'.scratch/mtp-fixed-chunk-20261025'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(p):return json.loads(next(x for x in p.read_text().splitlines()if x.startswith('{')))

folders=sorted(p.parent for p in(S/'runs').glob('*/result.json'))
assert len(folders)==2
base=raw(folders[0]/'stdout.log');candidate=raw(folders[1]/'stdout.log')
old_ids=base['sessions'][0]['result']['generated_ids'];new_ids=candidate['sessions'][0]['result']['generated_ids']
changed=[i for i,(a,b)in enumerate(zip(old_ids,new_ids))if a!=b]
assert len(old_ids)==len(new_ids)==128 and changed[0]==18 and len(changed)==104
assert old_ids[18]==271 and new_ids[18]==11
processes=[]
for p in folders:
    result=read(p/'result.json');observation=read(p/'observation.json');comparison=read(p/'non-time-comparison.json')
    assert result['exit']==0 and not result.get('timeout')and not result['reader_errors']
    processes.append(dict(folder=p.relative_to(S).as_posix(),exit=result['exit'],timeout=bool(result.get('timeout')),
        process_wall_seconds=result['process_wall_seconds'],parser_passed=True,non_time_equal=comparison['equal'],
        non_time_difference_count=len(comparison['differences']),metrics=observation['metrics'],
        work=observation['work'],actual_context=observation['actual_context'],generated_ids=observation['generated_ids'],
        command=pin(p/'command.json'),raw_stdout=pin(p/'stdout.log'),raw_stderr=pin(p/'stderr.log')))
assert processes[0]['non_time_equal']and not processes[1]['non_time_equal']
save(S/'actual-terminal-accounting.json',dict(requested_processes=12,actual_started_processes=2,actual_terminal_processes=2,
    zero_exit_processes=2,parser_passed_processes=2,non_time_equivalent_processes=1,non_time_failed_processes=1,
    unstarted_processes=10,GPU='released',no_retry=True,
    original_terminal=pin(S/'terminal.json'),clarification='Original terminal.completed_processes=1 and failure.completed_processes=1 count cases that passed equivalence; actual result.json files establish two completed native processes. Original records preserved.'))
summary=dict(status='stopped_on_first_actual_non_time_divergence_no_complete_timing_result',
    accounting=read(S/'actual-terminal-accounting.json'),processes=processes,
    first_divergence=dict(zero_based_output_index=18,one_based_output=19,baseline_token=271,candidate_token=11,
        common_prefix_tokens=18,changed_positions=104,total_outputs_each=128),
    non_time_differences=pin(folders[1]/'non-time-comparison.json'),
    same_top_level_non_time_scalar_counters=True,
    observed_differences='Generated token IDs, associated pending/next IDs, committed/verification input IDs/hashes and second-turn pending. 1034 paths; no top-level non-time scalar counter changes.',
    conclusion='Actual natural ordinary continuation differs, with both runs internally satisfying the existing parser/ledger/context contract. This is not in itself proof of an algorithm error: reduction partition changed and the separate F64 oracle only certifies tolerance, not bit identity. No first-divergence logits/margin captured.',
    performance_status='No medians, paired speedup or complete12-process screen computed; subsequent input IDs differ and only one ordinary process per image ran. Per-process raw metrics retained without a same-work acceleration claim.',
    pre_run_numeric_evidence=read(S/'plan.json')['pre_run_numeric_evidence'],
    plan=pin(S/'plan.json'),source_clean_manifest=pin(C/'clean-image.json'),closure=pin(C/'clean-closure-delta.json'),
    image_pins_unchanged=read(S/'terminal.json')['images_unchanged'],
    failures_preserved=[pin(S/'failure.json'),pin(S/'terminal.json')],
    boundaries=['No MTP timing processes were started in this screen; earlier one-shot MTP native diagnostic had unchanged IDs/work and remains separate evidence.',
        'No retries, new seed, different prompt, candidate/chunk adjustment or silently excluded mismatch.',
        'C1024 private prototype only; known long-context64MiB concern remains, no product acceptance.',
        'No new binaries, GPU profiling, memory sampler, SDK builds, HTTP or product changes.'],
    canonical_product_edits=0,HTTP=0,SDK_builds=0,new_binaries=0)
save(S/'summary.json',summary)
files=sorted(p for p in S.rglob('*')if p.is_file()and p.name not in{'proof.zip','proof-pins.json','proof-package.json'}and p.suffix.lower()not in{'.exe','.obj','.lib','.exp','.dll','.pdb','.map','.pyc'})
pins=[dict(archive_path=p.relative_to(S).as_posix(),**pin(p))for p in files]
save(S/'proof-pins.json',dict(files=pins,entries=len(pins),source_scope='Raw stdout/stderr, original runner results, failed comparison, plan/commands and all private scripts are payloads. Source/closure/SDK/model paths are external pinned prerequisites; no binary/weights payloads.'))
with zipfile.ZipFile(S/'proof.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files+[S/'proof-pins.json']:z.write(p,p.relative_to(S).as_posix())
with zipfile.ZipFile(S/'proof.zip')as z:
    assert z.testzip()is None
    for item in pins:assert hashlib.sha256(z.read(item['archive_path'])).hexdigest()==item['sha256']
save(S/'proof-package.json',dict(archive=pin(S/'proof.zip'),summary=pin(S/'summary.json'),pins=pin(S/'proof-pins.json'),entries=len(files)+1,
    actual_processes=2,unstarted_processes=10,GPU='released',cleanup='No new binary artifacts in this screen; preexisting candidate/diagnostic binaries preserved.'))
print(json.dumps(dict(archive=pin(S/'proof.zip'),summary=pin(S/'summary.json'),actual_processes=2,unstarted_processes=10)))
