# CUDA decode 性能提升计划

本页维护当前 Qwen3.5-2B BF16、纯文本、单 CUDA GPU 测试消费者的性能工作。
总体功能与交付顺序见[当前工作计划](../current-work.md)，测量方法沿用[性能指南](README.md)。
这里只保留当前基线、待验证假设、执行顺序和完成条件；原始实验留在 `docs/evidence`。
每次完整对比固定报告prefill、decode、显存变化和多轮会话综合速度，定义见[统一测量口径](README.md#推理对比固定报告)。

## 目标与当前基线

目标是查清并消除可重复的额外成本，在相同权重、输入及明确的计算和完成边界下追平 llama.cpp，
再根据实际热点争取反超。同时保持数值、状态、寿命和资源限制正确，检查 prefill、启动和内存是否退化。
每批改动以真实 tokens/s 判断收益；kernel 数减少和微基准变快只用于解释。

**当前优先项（2026-10-21）：多会话分页路径的单会话开销。** 原dense与新paged均保留完整KV＋conv/GDN续算；新增分页快照并不自动证明提速。
取回append事务无条件销毁reader录制的问题已修：短旅程热T1从6录制／1复用变为0／7；长旅程90／96次decode为0／7，首用与少量边界仍重录。旧guard全撤，精确端口、native变更、fresh token和退休检查保留，18／72份向量与撤权拒绝回归通过。
该批的[首轮完整比较](../../evidence/performance/qwen-paged-recording-2026-10-21.json)显示paged准备开销随历史增长，随后已修两项通用算法：明确只借TensorView的载体跳过未消费的lease查找；append的旧页／dirty查询及ready集合改为真实租约校验一次、排序索引／二分／合并，保原writer顺序、COW与失败回收。
[新完整四臂窗口](../../evidence/performance/qwen-paged-prepare-2026-10-21.json)仍用三轮256输入＋32decode、容量1024、各3进程：current／修复前paged／dense／llama合计decode中位100.65／91.63／104.97／105.46tok/s，综合90.33／82.95／93.67／92.00。当前相对修复前decode约＋9.9%、综合＋8.9%，GPU观测峰不变；参考decode仍快约4.6%，不能宣布收工或全面胜出。[最新四项表](../current-work.md#最新完整性能对比)保留prefill、空间及加载。
窗口快照是nvidia-smi滚动利用率，可能含刚结束的消费者，不能直接称为外部背景负载；旧窗53%／57%不足以解释波动原因。新窗12份样本集中，但仍未固定时钟／独占GPU，各臂仅3进程，不与旧窗合算收益。下面D1/D2表是此前dense路径的已结调查，不作为新paged的当前性能。

**最新一批已完成**：[前缀／分支与有界恢复](../../evidence/correctness/qwen-prefix-reuse-2026-10-21.json)新增52份向量逐字节一致，原18／72另过。append接线链的已知节点／reader证明从全plan遍历改为原plan定点及既有frame_slots，原38次全访变为2次全访＋36次定点；12份K/V复用同layout已有的sorted unique页集合。原权限、wholeGraph成功、COW及退休检查保留，CPU／CUDA功能检查已过。
[本批完整四臂窗口](../../evidence/performance/qwen-indexed-preparation-2026-10-21.json)current／本批前aa486／dense／llama的合计decode中位为101.58／100.77／104.90／105.56，综合90.90／90.37／93.88／91.83tok/s。current对before只高0.81%／0.59%，合计prefill低1.13%，范围重叠，不能签稳定收益；对参考decode仍差3.77%，综合差1.01%，显存观测峰未变。本窗单会话prefix关闭，不是共享前缀命中速度。当前完整表始终看[工作计划末表](../current-work.md#最新完整性能对比)，上段100.65窗口保留作前一批事实。
零重录调用的完整准备桶按每轮3进程共90次取中位，current约0.200／0.217／0.241ms，before约0.253／0.281／0.278ms；不是单函数自耗时。冷8形状请求也暴露whole-family的operation候选及制品准备默认额度不足，已由消费者按实际变体数有界计算并记录额度／使用数，库累计硬预算不变，热执行不新增搜索。

**本轮结果（异步回收与输出发布，2026-10-21）**：[真实在途回收](../../evidence/correctness/qwen-native-retirement-2026-10-21.json)已接原Graph，输出发布循环只遍历实际owned writer所在的固定绑定前缀，不再为36份state输出反复检查匿名页记录。原发布／失败／退休门不变，原18／72及前缀52份向量通过。[完整四臂复测](../../evidence/performance/qwen-retirement-publication-2026-10-21.json)只替换main及resources两个对象：current／before／dense／llama的进程中位decode为91.34／91.51／94.23／95.67，综合82.42／82.31／84.68／83.88tok/s。current比before的decode低0.19%、综合高0.14%，范围重叠，**没有证明提速**；比参考decode慢4.53%、综合慢1.74%，GPU观测峰与before相同。四臂绝对速率均低于上一窗口，不能用跨窗差值给本次修改归因；不再为了有利中位重复跑窗。

**原生归因这轮已完成**：[同负载两份Nsight时间线](../../evidence/performance/qwen-paged-native-cost-2026-10-21.json)各核99个4B D2H完成、全部96decode；90次零重录另列。每decode分页版584kernel／7GraphLaunch，dense596／1；额外eager D2D共2232次、10,027,008B，GPU占时平均23.3µs／步。零重录的6个capture段间边界平均96.1µs／步，其中copy23.7µs、无设备活动72.4µs，不能保证全部可收回。热路径两端均无EventCreate，EventRecord／EventSync／StreamSync均2次／步，排除“每append建event／同步”这个猜测。

分页版未记录API且无设备活动的间隔按轮约316／358／421µs，dense约104／78／82µs；它支持继续查随页数增长的主机组织成本，不是C++函数自耗时。Memcpy提交API及多GraphLaunch亦有额外成本，但其时间与GPU执行重叠，不能相加估算收益。软件插桩下两端全decode包络胜负反转，且collector对驱动13.4回退13.3；**本轮只用物理工作量和有界间隔定位，不更新页末无插桩TPS表**。

本轮已删除旧frame的私有old_ids分配／逐页身份重核，借其已验证且强持有的旧layout footprint；全部动态页权限与成功／退休检查保留，CPU／CUDA与52份实际向量通过。没有声称此小修已收回上述主机时间，也未再跑一个完整测速窗口。

下一步实现metadata驱动的可录制分页写入：固定原生参数地址，冷阶段更新布局descriptor内容，Graph按实际writer回调／capture后端决定是否保录制。普通动态copy地址没有这个合同，不能只翻capture标志。独占续写另需已提交前缀读／唯一尾权和append epoch故障隔离；只省COW前缀copy不会自动消除7段提交。机制设计归[Compute架构](../../architecture/compute-design.md#多会话缓存与共享前缀)，沿同Graph effect／权限／退休，不增加消费者原生专线。输出发布发生在完成后，不归入提交前`cold_batch_seconds`；缓存命中收益另测，不恢复旧dense执行分支。

当前选用的 D1 基线是 **2026-10-20 18:39:26–18:39:46 与 18:40:15–18:40:43，北京时间**两组同窗。
固定 128-token prompt、context 256；每窗修改前／当前／llama 各 3 个新进程交错运行。

| 负载与指标 | 修改前 Hyle | 当前 Hyle | llama.cpp | 当前相对修改前 |
|---|---:|---:|---:|---:|
| 完整 31 步 decode | 102.56 | 103.99 | 104.13 | +1.39% |
| 稳态第 7–31 步 | 106.34 | 107.74 | 106.28 | +1.31% |
| 完整 127 步 decode | 105.93 | 107.07 | 106.31 | +1.08% |
| 稳态第 7–127 步 | 106.86 | 108.03 | 106.85 | +1.10% |

单位均为 tok/s。短窗当前相对 llama 完整 −0.13%、稳态 +1.37%；长窗完整 +0.71%、稳态 +1.10%。
本批修复后两种长度均有约 1.1%–1.4% 的中位提升；每臂仍仅 3 个进程，不签稳定全面胜出。
短窗 prefill 为当前 2039.84／参考 1335.99，长窗为 2084.23／1347.16 tok/s。
相对修改前 prefill 分别 −1.13%／−0.008%；保留全部样本，不由此签回归或无回归。

长窗将原 31-token 固定输入带重复并截取到 127，最终可见 255 tokens；参考消费者仅放开有界阶段数，
底层 llama 实现和采样路径不变。它用于延长固定负载观察，不代表自然生成或质量验收；两窗不合池。
本次保留原 BF16 图闭包，只替换两个通用 Graph 实现对象；后续量化能力对象未全部重编，不能称为完整当前源码交付。
“无插桩”指没有新增 D1 计时或外部采样，原计时、日志和参考的粗粒度 memory snapshot 仍保留。
[源码、原始样本、独立复算与限制](../../evidence/performance/qwen-prepare-bindings-2026-10-20.json)；
[此前 16:27 窗口](../../evidence/performance/qwen-decode-rebenchmark-2026-10-20.json)保留为历史依据，不与本批合算增益。

### 尚需明确的比较边界

- 两端使用同一组 BF16 权重和固定输入；Hyle 的 activation/output 主要为 BF16，参考 decode
  多处使用 F32 中间计算。当前结果是两种实际计算路线的比较，尚非逐算子同数学比较。
- 两端当前都计到 host token 可见。参考官方 greedy 路径每步还自动回传约 0.99 MB logits，
  Hyle 通常只回传 4 B token；参考不是由消费者主动读取 raw logits 才付出该成本，现有公开入口
  未见省略开关。主比较保留双方自然 token 路线，不移动计时端点或从参考时间里估算扣除拷贝。
  如需诊断输出差异，另测双方都交付 host F32 logits 和 token 的负载，使用预分配缓冲并完整计时；
  这个补充结果不能替换 token 主结果，也不能抹平中间计算精度差异。
- 当前固定序列的 hidden/logits 与 Hyle 既有基线逐字节相同，用于回归；它不构成独立模型质量验收。
- 当前短序列用于保留前后可比性。较长 decode 另列结果，明确增加后的上下文长度；不能把不同
  KV 工作量的样本合成一组，也不能把进程内各 token 当作独立进程样本。

## 执行顺序

| 步骤 | 当前状态 | 做什么 | 本步结束条件 |
|---|---|---|---|
| D1：每步准备 | 已定位并修复本批重复绑定准备 | 同物理配置复用已构造的 spans，新权限和 seal 仍准备；18 CPU＋6 CUDA、64 份向量和两窗复测已完成 | 当前这条调查结束，后续仅在新证据指出冗余时重开；metadata 上传等待保持原合同 |
| D2：投影计算 | 已完成真实后缀对照，默认保留 D1 的 F32 Top1；直接 BF16 消费者候选本轮不采用，已结项 | 3 个独立进程和 1 次结构 trace 的数值、配对、空间和失败记录见下文 | 无挂起候选；不因 kernel 数减少或选择有利统计量自动采用 |
| D3：吞吐复测 | 本批 31／127 步各一组完成，仍为有限样本 | 后续有新热点改动时再比较，复用本批短长负载 | 报完整与稳态吞吐、分布和失败，确认收益及剩余可重复慢项 |
| D4：最终整机性能对比 | 进行中，初轮及auto修复后比较已完成 | 当前源码统一比较加载、prefill、cached continuation、decode、内存和显存 | 性能、资源、正确性和公平性结论均有对应实际证据；未解决项明确保留 |

Top1 的这次有限决策已完成，接下来推进总体计划中的格式／功能补全。格式补全使用独立的功能清单推进；
CT/NVFP4 的新增能力没有进入当前 BF16 Qwen 图，不计为本图的 decode 优化。

2026-10-20的[DeepInfer源码调研](../../evidence/research/deepseek-runtime-inspiration-2026-10-20.json)另提供一个有限检查方向：
D4前核一条真实投影→residual链能否保原BF16舍入、读者与alias而直接写最终输出，减少一次实体搬运。
先核实际native epilogue与数值边界，有成立的完整候选再测吞吐；否则记录具体不采用原因并关闭本轮候选。
这不是已证明的额外开销或提速，不重开已结项的Top1实验；FP8输出布局与MTP GPU metadata分别随总体第3／6步推进。

[TensorRT-LLM固定源码研究](../../evidence/research/tensorrt-llm-inspiration-2026-10-20.json)另核冷准备、共享量化及执行重叠：
已读源码的SM89普通BF16投影沿F.linear／cuBLAS路径；可见的low-M／persistent特化有SM100条件，
CUDA-core GEMM的已读公开调用者则要求FP8输入。它们不能直接解释当前4070 BF16 Qwen还能快多少。
D4前沿现真实热点只检查同dtype／shape的选路、实际权重读取和host-token空隙；已有共享FP8 prologue与有限图族不重做。
只有发现新前提或可执行候选才做配对测量；保持同权重、精度、上下文与结果可见边界，
区分单请求decode、并发总吞吐和MTP，不将大batch或B200的收益挪入本基线。

### D1：查清每步准备

诊断构建先拆消费者，再只拆 replay：三个新进程中 replay 准备中位约 92–97 µs，
其中绑定准备约 91–95 µs，累计约占 replay 桶的 98%。这些插桩结果用于归因，不作吞吐排名。
实际冗余是配置撤销后重新扫描整图、构造未改变的物理 TensorView spans。
现已复用同址、同描述、同范围的配置事实；普通绑定、命令变化、失败准备和 full reset 撤销候选，
source、opaque/native owner、派生 alias 和投影等仍保守走完整准备，未知 identity hook 照常执行。

无新增插桩窗口中，稳态准备桶的“各进程中位再取中位”短窗 **165.3→64.3 µs**，长窗 **156.4→60.9 µs**。
18 CPU 与 6 CUDA 定向回归通过、0 skip；64 份 hidden/logits 和 4 份冷图 route/boundary TSV 与保留基线逐字节相同。
本批没有新测显存／内存峰值、能耗或物理 kernel trace。
`submit_seconds` 已包含在后续提交到结果可见的时间内，不能再相加。

本轮沿[消费者 evaluate](../../../tools/qwen35_text/main.cc)分段，保持原调用和等待顺序：

1. 既有输入写入，包括 token/position 两次 H2D；它们在 `cold_batch_seconds` 桶外，但在完整 step 内。
2. layout 版本创建及六个 reader 的布局装配。
3. `batch::prepare` 的配置撤销、权限/别名检查、metadata 绑定及上传。
4. `Invocation::prepare_replay` 的绑定准备、capture 检查/复用和退休查询。
5. 原提交、等待及 host token 读回，作为完整 step 的核对边界。

绑定重建假设已经确认并修复。共享 metadata 只有首个 owner 执行实际上传和等待，
其余 reader 使用共享准备，不能按六次上传计算成本。capture 已复用也不等于绑定准备已经跳过。
本轮没有额外调用 `batch::prepare_replay` 或改变现有捕获旅程。
若要复用缓存，缓存身份必须覆盖布局、来源、权限、alias 和旧结果存活，不能绕过 idle/owner 检查。

插桩只用于归因；吞吐收益由去掉插桩后的同窗确认。若剩余工作都是必要检查、实际上传或 capture
依赖，就在这里结束这条线，不把这些行为悄悄挪出完整 step 计时。

### D2：按投影角色优化

历史匹配 trace 中，投影约占双方 kernel 累计时间的 92%；head、gate/up、down 占每步逻辑权重
字节的约 75.2%。这说明它们值得优先核查，但累计 kernel 时间不是可直接相加回收的 wall 时间。

先在当前图确认热点角色，再检查：

- 同一实际矩阵形状和 operand/output dtype 下，是否有额外读写、repack、转换或中间落地。
- 同 A 投影和 FFN 融合是否保留规定的 BF16 舍入，是否重复读权重或复制权重 bank。
- 实际带宽、cache 命中、launch 和完成等待中，哪部分解释了当前差异；由此选择现有 provider、
  融合候选或实现修复。一般机制留在底座，模型角色和生成策略留在测试消费者。

当前总 kernel 是 **596 对 558**；395 是参考非投影部分，不能再用作总数。
以前测过的整批 MMVF 替换、通用大投影替换、FFN 两行 CTA 未证实收益，
只有新证据改变其前提时才重开。历史图内空隙、GraphLaunch 主机区间也不能直接承诺为可回收预算。
[热点与计数](../../evidence/performance/decode-major-hotspots-2026-10-20.json)、
[busy union 与归因限制](../../evidence/performance/decode-busy-union-2026-10-20.json)。

若更大提升需要降低权重精度，单列相同量化与质量检查的比较，保留 BF16 结果；
硬件 FP8/FP4 数学也不能自动当作现有 QDQ 路径的等价融合。

#### 本轮 D2 结论

head/down 沿既有 cuBLAS BF16 输入、权重和输出及 F32 累积；gate/up 保留严格 BF16 舍入的双输出融合。
当前核查未找到额外热 repack、全权重 bank 扩宽或可确证的大投影缺陷。原来 FFN 的 DRAM store
现象也不能据逻辑 store 次数解释为隐藏中间副本或 spill；没有新前提时不重开旧负结果。

消费者另试了直接 BF16 Top1，移除 head 后整行 BF16→F32 Cast。3 项 CUDA 回归通过、0 skip，
64 份 hidden/logits 保持逐字节相同；结构 trace 是 596→595 kernels、55→54 Cast。
这证明测试范围内的数学和结构变化，不构成吞吐或模型质量结论。

| 同窗完整 decode（tok/s） | D1 | Top1 候选 | 候选相对 D1 |
|---|---:|---:|---:|
| 31 步 | 104.89 | 103.90 | −0.945% |
| 127 步 | 99.31 | 98.50 | −0.815% |

每臂各 3 个新进程，长窗 D1 样本 max/min 跨度达 8.22%；没有确证真实退化幅度或根因，不能称为单纯计时器分辨率。
原投影 kernel、路由前缀及其余 149 个链接输入均不变；未发现 D1 全图绑定重建重新出现的明确证据。

一次固定的同进程局部对照，使用原 decode7 的 248320 个实际 logits、相同 Commands 路线、
32 次／臂预热及 ABBA/BAAB 的 128 次／臂相关样本，计时含 submit、wait 和实际 4 B host token：
直接 BF16 的耗时中位 39.95 µs，Cast＋F32 Top1 为 44.05 µs，每 cycle 的配对节省中位 2.25 µs。
这次局部观察中直接 BF16 更快，不能把整模型窗口的负号归因于 BF16 Top1 更慢。
原模型 Cast 位于更大的捕获段，这个 Commands 对照并不等价于模型后缀；辅助 stream event 还包含 host
admission 空隙，不当纯 kernel 时间，也不据此换算整模型收益。

已完成的第一轮保持 D1 基线，保存候选和全部正／负结果，保留新增的大词表 Top1 测试；
未提升基线不等于证明优化方向错误。真实 head 后缀的最终选择见下文，完整模型窗口没有继续扩张寻找正号。
[源码、完整样本、局部对照和选择依据](../../evidence/performance/qwen-bf16-top1-2026-10-20.json)。
归档核验后通过根 `test.ps1` 精确回收本轮 76 个可重建镜像／链接副产物和重复向量，约 464 MiB；
保留当前 D1 程序、参考、源码、对象和输入，[清理实录](../../evidence/performance/qwen-bf16-top1-2026-10-20.cleanup.json)。

最终对照保持真实公共投影与 capture／host-token 边界：两图共享同一原始 BF16 `[248320,2048]`
权重和 decode7 的真实 hidden，经过相同 Copy 并发布 caller hidden／logits／ID，TopK value 不发布。
原臂保留 private BF16 head→Cast→caller F32 logits，候选直接写 caller BF16 logits，保留真实存储差异。
3 个独立进程各做 32 次／臂预热、64 个 ABBA/BAAB cycle，128 个相关样本／臂；全部 768 个计时提交保留。

| 进程 | 原臂中位 µs | BF16 候选中位 µs | cycle 配对节省中位 µs | 候选均值多耗时 µs |
|---|---:|---:|---:|---:|
| 1 | 2156.00 | 2151.95 | −6.20 | +50.515 |
| 2 | 2157.50 | 2151.00 | −0.55 | +8.105 |
| 3 | 2154.55 | 2147.70 | +5.00 | +2.821 |

预定的配对方向未在独立进程间重复，不能换用普通中位数较好来签收益；均值也未改善。
独立复算未发现计时不公平或可确证的周期噪声机制。另一次结构 trace 确认两臂 head 全部被捕获，
符号与 `62080×1×1 / 16×4×1` 几何和整模型相同；4 个 CUB kernel 均为 eager 尾。
Cast 本身中位约 3.04 µs，尾部确有小节省，但 head 和完成边界的变化覆盖了它。
profiler 的时间只用于归因，不混入无 profiler 的性能结论。

4 个进程的完整 logits 和 hidden 与原始向量逐字节一致、token 均为 10462，capture 均实际复用。
后缀 workspace 从 508416 降到 11778 B，caller logits 从 993280 降到 496640 B；
这些组件的空间减少是真实结果，未据此签整模型峰值或吞吐改善。

**本轮决定：默认保留原 D1／F32 Top1，直接 BF16 消费者候选不采用并结项，无挂起候选。**
保留通用 BF16 Top1 能力、新增测试和已完成实验记录；这不是对其它硬件、负载或 BF16 Top1 算法的普遍否定。
[最终决策、真实输入身份、失败编译、全部样本和结构归因](../../evidence/performance/qwen-top1-real-suffix-2026-10-20.json)。

权重流式读取占主导时，小算子或 host 调度的改善可能被总耗时和漂移掩盖；减少实际 DRAM 读写或提高复用仍有价值。
保留的历史单节点 NCU 中，LM head 为 97.55% sustained DRAM peak（实际总流量约 491.22 GB/s），
FFN 双投影为 92.71%、L2 hit 0.89%；这支持这些大投影受带宽限制，不能代签当前整步始终饱和。
不能只凭投影占比或 GPU 利用率就声称整步达到显存带宽上限。按 NVIDIA 的
[Nsight Compute 归因方法](https://docs.nvidia.com/nsight-compute/ComputeTriage/)，
分别看实际 DRAM bytes／持续带宽、L2 命中与吞吐及延迟／dispatch，再对照绝对耗时；数值正确性仍独立验证。

### D3/D4：确认实际收益并收工

复用已有权重、参考程序、构建对象和原始输入，只增量构建受影响部分。先运行相关数值/寿命回归，
再运行无 profiler 的吞吐对照；设备分析和内存旁采另开观察，不混入吞吐样本。

每轮保留当前/前版/参考的必要同窗；记录硬件、driver、工具链、源码和二进制身份。
交换顺序，保存慢进程和失败，按需要增加独立样本及同路径 A/A，先解释波动再增加重复。
已有证据未受改动影响时直接引用，不重跑跨后端、格式、shape 的笛卡尔积。

最终报告至少包含：

| 结果 | 完成边界 |
|---|---|
| 加载、ready、TTFT | 文件读取/解码、上传、准备及必要清理分别可解释；OS 热页缓存不称冷盘 |
| prefill 与 cached continuation | 相同 token 输入、context 和状态，输出实际可见 |
| 完整 decode 与稳态 decode | 首次 capture 保留在完整结果中，稳态另列；报告样本数和分布 |
| 内存、显存、workspace、搬运 | 说明采集区间与已知/未知，workspace 为零不等于总分配为零 |
| 数值与状态 | 改动相关的独立数学/生命周期检查、固定序列回归及尚未完成的质量验证 |

“追平”需要反复独立同窗不再出现超过实际测量波动的持续落后；未测出显著差异不能直接宣称等价。
若仍有可重复的小输，继续按本页具体热点调查；没有证据时保留不确定结论，不制造任意容忍值。
反超幅度由测量决定，目前不承诺额外 15% 或 50%。

完成本轮以后，将本页更新为实际结果与剩余问题；已否定的方向留简短结论和证据链接，
避免重新从旧假设开始。总体 goal 还要求[当前工作计划](../current-work.md)中的功能和交付余项完成。

### 2026-10-21：D4 实测与一次性 capture 修复

首次实际测128-token前缀后的16-token续算，发现811.46对999.86 tok/s、慢18.84%，三对三样本无交叠。
[首轮证据](../../evidence/performance/qwen-current-delivery-2026-10-21.json)保留全部负结果及当时源码，不由后续数据覆盖。
两次同负载Nsight诊断确认该一次性调用付出了capture准备成本；当前trace的图内kernel不可见，未将整段图span冒称busy union，或将API耗时之和当可回收收益。
现有全局Commands对照使续算更快，却使decode变慢；因此仅改测试消费者的使用政策，复用库原有ReplayMode：
按完整计划冷统计每个exact child的两个全局parity槽，一次性槽Commands、预计复用的槽PreferCapture。
没有按shape／模型／Provider特殊判断，热路径只读预选数组，没有虚假预热或移走首次执行；生成提前结束时使用数是请求上界。

新默认auto的64份hidden／logits与原基线逐字节相同，固定预测一致。以下各窗每臂3个新进程，均无profiler或外部旁采，保完整host-token step。
同源BF16权重、固定tokens、context256；中间精度及原引擎采样读回仍不同，不能推出数学或模型质量等价。
参考消费者沿原backend greedy／public sampler，不读raw logits或做CPU argmax；引擎额外sampled-logits读回留在实际计时内。

| 输入窗／指标，tok/s中位 | Hyle auto | llama.cpp |
| --- | ---: | ---: |
| 128 prefill，短窗 | 2217.97 | 1401.10 |
| 31步完整decode | 103.63 | 105.22 |
| 短窗decode7起 | 107.91 | 107.64 |
| 128 prefill，长窗 | 2300.60 | 1284.26 |
| 127步完整decode | 107.12 | 106.47 |
| 长窗decode7起 | 108.00 | 107.04 |
| 缓存后一次追加16 | 1020.63 | 977.54 |
| 续算后15步完整decode | 100.34 | 102.74 |
| 续算后decode7起 | 107.09 | 106.36 |

16-token续算在这次同窗中从旧capture策略835.94提高至1020.63，约22.09%；此前811.46属于另一窗口，不混作这一提速比例。
缓存续算输入为原31-token tape拆成16＋15，沿同一状态从128→144→159；17个可见前缀分别与各自逐token旅程预测一致。
**D4仍未结项**：完整31步与续算后15步仍小输，稳态较快不能代签完整调用。下一动作只分解最初两槽的capture启动代价，保初始调用，不靠删样本或另设任意容忍值收工。
现有样本的均值差额集中在前两次decode：31步前两次多5.84ms、全窗多3.88ms；续算后15步前两次多4.68ms、全窗多4.21ms。
既有trace中Hyle前两M1各实例化一次、参考在decode2实例化一次；原迹不是新auto实采，API耗时差不能直接当可回收收益。
[修复源码、完整同窗／旁采、独立复算与首次成本分析](../../evidence/performance/qwen-auto-replay-policy-2026-10-21.json)保留实际边界及尚未解决项。

短窗同次进程的加载／ready／TTFT中位：Hyle约0.792／1.134／1.192s，参考1.432／1.511／1.602s；加载子边界不同，OS页缓存未控制，不称冷盘加载。
独立50ms PSAPI／PDH旁采各1个新进程：当前／参考驻留working-set观测峰约1.05／4.07GiB，private commit约5.47／4.88GiB，GPU dedicated采样峰约3.80／3.95GiB。
commit不是驻留RAM，各类内存不相加；GPU峰是采样下界，启动缺失实例保留null，过短阶段没有样本不推测phase峰。

### 首次capture的资源消冗（2026-10-21）

新auto的实际node trace确认前两M1各596个kernel，参考各558个；Hyle的记录／实例化在首次执行中，不能据此合并两份固定绑定制品。
已复用Queue中未被capture引用的状态字，并在原退休链已有同context／stream完成证明、无需原生查询时省去context guard。
新迹每个首M1的push／pop由各1313次降至945次；第二次capture少一次malloc，两次各少一次free，数学kernel数不变。
5项定向回归、64份原向量逐字节检查、Linux原安装SDK的两个消费者通过；仅增量编译两份产品C++，没有重建SDK。

另一次无profiler短窗每臂3个新进程：旧auto／当前／参考完整decode为93.04／92.29／95.79 tok/s，稳态96.64／96.18／98.27；
前两步合计中位33.67／32.05／26.35ms。样本波动较大，**没有证明吞吐提升或回归**，不与上表较快窗口混算。
[原始样本、三次node trace、数值和安装消费者实录](../../evidence/performance/qwen-capture-resource-reuse-2026-10-21.json)保留源码及限制。
接下来结合本地参考引擎调查具体的计算／搬运缺口；不因减少API次数宣告D4完成。

### 本地引擎研究与下一批

[7个本地仓库的源码对照](../../evidence/research/local-inference-optimization-2026-10-21.json)将23条机制记录归并为5个方向，尚未作为提速结果。
当前BF16 Qwen已确认T1的103／187个MatMul选direct Lt，包括down／head；T128为187／187。原provider只取一个heuristic，
下一步只选一个真实热点形状，比较少量合法冷算法；保输入、累积／舍入及workspace边界，实际会话变快才采用，不建通用调优系统。
之后处理保BF16／F16舍入的norm／activation→quant融合，以及数学合同匹配的4bit packed分块MMA。
后两者服务实际量化模型，不会自动加速当前未用该格式的BF16 Qwen。

图池／资源复用已有主体机制，只调查实际重复；expert流式驻留与CPU/GPU重叠留给需要它们的真实消费者。
不将SM100／多GPU结果外推4070，不用覆写旧结果的共享输出换取显存，源码研究不代签吞吐收益。
两侧消费者现已支持同一有序多轮phase输入和显式容量，沿原缓存记录完整会话；首轮四项比较见下节。

### 三轮共享缓存的四项基线（2026-10-21）

已完成上一段的消费者扩展。双方沿一个缓存执行`(256输入＋32单token decode)×3`，上下文0→256→288→544→576→832→864，容量均为1024。
每臂3个新进程交错测速，另各1个新进程独立旁采显存；重复原固定ID带，是合成teacher-forced性能回放。
99个host预测（3个prompt首token＋96个decode输出）在全部8进程一致。

| 阶段 | Hyle tok/s | llama.cpp tok/s | Hyle显存峰 GiB | llama.cpp显存峰 GiB |
| --- | ---: | ---: | ---: | ---: |
| 第1轮输入256 | 3279.28 | 2286.93 | 3.956 | 4.191 |
| 第1轮完整decode32 | 101.69 | 102.30 | 3.972 | 4.194 |
| 第2轮追加256 | 7527.04 | 8903.17 | 4.077 | 4.194 |
| 第2轮完整decode32 | 103.55 | 103.10 | 4.081 | 4.194 |
| 第3轮追加256 | 8410.15 | 8681.64 | 4.081 | 4.194 |
| 第3轮完整decode32 | 102.88 | 103.45 | 4.085 | 4.194 |
| 综合输出 `99/session` | 91.78 | 89.67 | 4.085（全程） | 4.194（全程） |

速度为各进程值的中位数；显存列是独立旁采进程的GPU dedicated阶段观测峰，采样下界，不是精确阶段边界占用。
完整会话中位1.07872对1.10410s，描述性综合输出差约+2.35%；第二／三轮输入仍为−15.46%／−3.13%，各3样本均较慢。
本窗无独占GPU／固定频率，不签稳定胜出或统计显著性；不与过去短窗合并计算增益。
加载／ready、完整decode与稳态分布、working-set／commit及shared GPU值在[完整数据](../../evidence/performance/qwen-multiturn-current-2026-10-21.json)。
内部启动到末输出约2.25549对2.70460s，从消费者入口计时，不包括OS装载DLL；进程wall还包括销毁，两者分列。

请求旁采间隔10ms，实际中位约15.2ms；两端ready到首prefill没有样本，因此加载后基线及严格阶段边界增量均为unknown。
不能将相邻样本跨下一阶段／退出清理的变化称为本阶段释放；dedicated和shared的独立峰也不能相加。

第二轮Hyle的完整输入约34.01ms，combined batch/replay准备约5.12ms，准备后到host token约28.82ms；参考完整28.75ms。
第三轮prefill仍record1／reuse0；每轮decode均record2／reuse30。FlashInfer按实际KV分片拓扑决定是否可复用，源码存在重规划→失效原capture范围的合法链，
但本次没有记录实际拒绝gate，尚不能认定根因。下一步只细分两项准备时间并记录已有六份公开BatchPlanReport。

新单轮schedule与原消费者64份向量逐字节一致。短多轮与逐token共享端点25个ID一致，追加后32／50份向量不同；独立Torch同计划25个ID也一致、全部值有限，
相对L2误差约1%量级及其变化已完整保留，未设事后门限、不签模型质量通过。此诊断不计入速度窗口。

### 新阶段首轮与准备诊断（2026-10-21）

最新完整四项对比集中在[当前工作末表](../current-work.md#最新完整性能对比)，[原始数据与源码](../../evidence/performance/qwen-next-phase-first-2026-10-21.json)保留本次窗口及前窗限制。
本窗各3个进程测速、另各1个显存旁采；两端均比前窗慢，不将跨窗变化归因本批workspace查询消冗，也不签稳定胜出。

独立的一次host诊断已拆开准备成本：第二轮T256使用slot1，属于该槽首次native plan，batch／replay约3.926／0.559ms；
第三轮回slot0，KV256→832按固定FlashInfer分块规则必改拓扑，batch／replay约0.542／3.623ms。
每轮decode首两次native计划均不复用，随后30次复用；等同workspace／CTA尺寸不能证明整个原生计划可复用。
已在同一BatchSlot的准备事务中一次性交接精确workspace sizing facts，保原生materialize、容量与退休检查，未单独证明吞吐收益。
下一步检查capture在实际拓扑寿命内的复用与摊销，避免只有一次使用的重录；不通过放宽计划或页权限失效规则换取速度。
