"""Exactly two serial native timelines, original workload; no timing claim."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
A = R / '.scratch/architecture-refactor-2026-10-18'
W = A / 'd4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_profile', W/'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c = h.b,h.c
prior = c.read(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json')
nsys = Path(c.read(A/'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0])
assert nsys.is_file()
receipts = dict(current=R/'.scratch/paged-retirement-20261021/qwen-ready-attempt1.json', dense=W/'ready-for-root.json')
for arm, ready_path in receipts.items():
    ready = c.read(ready_path)
    image = ready['image']
    assert h.same(image)
    command = next(x['command'].copy() for x in prior['commands'] if x['variant']==arm)
    assert command[0] == image['path'] and '--trace' not in command
    out = S/arm
    out.mkdir(parents=True,exist_ok=False)
    (out/'tmp').mkdir()
    stem = out/'capture'
    commands = dict(profile=[str(nsys),'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
        '--cuda-trace-all-apis=true','--cuda-graph-trace=node:host-only','--discard-environment=true',
        '--output='+str(stem),*command],
        export=[str(nsys),'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'])
    env = os.environ.copy()
    env['PATH'] = c.read(ready['runtime_environment']['path'])['PATH']
    env['TEMP'] = env['TMP'] = str(out/'tmp')
    c.save(out/'plan.json',dict(arm=arm, image=image, ready=b.identity(ready_path),
        runtime_environment=ready['runtime_environment'], commands=commands,
        source_workload=b.identity(R/'.scratch/paged-retirement-20261021/performance/timing/inputs.json'),
        profiler=b.identity(nsys), throughput_evidence=False, concurrent_GPU=False,
        purpose='Inspect all actual99 host-visible decisions/96decode calls in original3turns256+32 schedule; compare physical native work/gaps, not measured tokens/s.'))
    for tag, argv in commands.items():
        c.execute(tag,argv,env,out)
    print('NATIVE_TRACE_READY',arm,flush=True)
