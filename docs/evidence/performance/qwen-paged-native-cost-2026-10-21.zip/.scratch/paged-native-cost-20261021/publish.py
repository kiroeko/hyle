"""Publish actual native work/cost evidence and the separately checked small source change."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import zipfile
S=Path(__file__).resolve().parent
R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def identity(p):
    p=Path(p).resolve()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
report_path=R/'docs/evidence/performance/qwen-paged-native-cost-2026-10-21.json'
archive=report_path.with_suffix('.zip')
assert not report_path.exists() and not archive.exists()
native=read(S/'native-summary.json')
details=read(S/'native-analysis.json')
regression=read(S/'host-review/runtime-comparison.json')
assert regression['total_decision_vectors']==52 and regression['all_byte_equal']
for mode in ('cpu','cuda'):
    assert read(S/f'{mode}-run1/result.json')['exit']==0
for mode in ('main','pressure'):
    assert read(S/f'{mode}-run1/result.json')['exit']==0
for arm in ('current','dense'):
    assert read(S/f'{arm}/profile.result.json')['exit']==0
    assert read(S/f'{arm}/export.result.json')['exit']==0
    counts=details['arms'][arm]['groups']['all96decode']['totals']
    assert counts['kernel_count']==96*(584 if arm=='current' else 596)
    assert counts['GraphLaunch_count']==96*(7 if arm=='current' else 1)
actual_source=identity(R/'src/graph_batch/paged_append.cc')
assert actual_source['sha256']=='6456d7d9a5a658e6f89daf19c98e3ba33042818b6e5a8c8deff1f0ae81390199'
source_files=['src/graph_batch/paged_append.cc','docs/developer/current-work.md',
    'docs/developer/performance/decode.md','docs/architecture/compute-design.md']
paths={}
allowed={'.json','.py','.ps1','.log','.diff','.patch','.tsv','.txt','.md','.cc','.h','.sqlite'}
for p in S.rglob('*'):
    if p.is_file() and p.suffix in allowed and 'tmp' not in p.relative_to(S).parts and '__pycache__' not in p.parts and p.name!='published.json':
        paths[p.relative_to(R).as_posix()]=p
for name in source_files:paths[name]=R/name
inventory=[dict(archive_path=name,**identity(p))for name,p in sorted(paths.items())]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name,p in sorted(paths.items()):z.write(p,name)
    z.writestr('manifest.json',json.dumps(dict(files=inventory,
        scope='Both original SQLite native event exports, extraction/analysis scripts and logs, exact changed source/before/diff, minimal build/fixture/model commands and results,52vector hash comparison, plans and cleanup script.',
        excluded='No weights/SDKs/executables/objects/maps/duplicate decision-vector payloads. Original .nsys-rep files are retained in scratch and hashed in the public report; SQLite exports are included for offline checking without GPU/tool installation.'),indent=2))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
save(report_path,dict(
    date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
    status='Two actual root-owned native traces analyzed; one related host-only redundancy removed and checked. Main append/capture and exclusive-suffix mechanisms remain unimplemented.',
    archive=identity(archive),archive_file_count=len(inventory),
    native_scope='Windows RTX4070; current2941 and olddenseff748; original3turn256prefill+32decode schedule,capacity1024,864inputs/99host-visible IDs/96decode calls. No MTP/images/concurrent users. Each arm profiled once, separately from the existing throughput window.',
    original_traces={a:dict(nsys=identity(S/a/'capture.nsys-rep'),sqlite=identity(S/a/'capture.sqlite'),
        profile=identity(S/a/'profile.result.json'),export=identity(S/a/'export.result.json'))for a in ('current','dense')},
    actual_native_results=native,
    full_native_review=identity(S/'native-analysis.json'),
    source_change=dict(source=actual_source,freeze=identity(S/'host-review/implementation/source-freeze.json'),
        source_review=identity(S/'host-review/source-review.json'),
        change='Borrow previous immutable layout canonical footprint already checked by original PagedArena.read_impl; retain owner/schema/count checks and all dynamic dirty/copy/ready/permission/retirement gates. Removes12private old-ID allocations and12*P page_id/view rechecks for nonempty T1 history. It does not remove every O(P) operation or solve capture fragmentation.',
        build=dict(CXX=1,links=3,NVCC=0,SDK_builds=0,
            ready=identity(S/'qwen-ready-attempt1.json'),image=read(S/'qwen-ready-attempt1.json')['image'],
            changed_link_inputs='Exactly one paged_append object versus2941, other191identical.'),
        numerical_regression=identity(S/'host-review/runtime-comparison.json'),
        actual_vectors=52,all_byte_equal=True,
        checked='22prefix/branch/full-hit and30pressure/restore decision vectors; all non-time IDs/phase/dispatch/Graph/hit/restore/budget observations equal to prior2941. Original real CPU/CUDA append fixtures also exit0.',
        fixture_results={m:identity(S/f'{m}-run1/result.json')for m in ('cpu','cuda')},
        no_postpatch_full_throughput_window=True,
        distinction='The native timeline is before this small source change, so neither timeline nor latest full throughput table certifies3859 speed.'),
    architecture=dict(
        exclusive_design=identity(S/'exclusive-design/design.json'),
        capturable_append_design=identity(S/'paged-append-native-design.json'),
        scope='Design constraints only, not delivered functionality. Compute batch narrow device-descriptor append program via actual backend extension; selected writer update proof plus actual capture identity; one original Graph effect/executor and ordinary fallback. Separate bounded committed-prefix reads and one move-only tail authority with append-epoch failure/actual-use isolation; shared branches retain COW.',
        source_review='Do not flip capture_compatible, infer write permission from use_count, poison an old committed prefix on suffix failure, or bypass per-root native admission by retaining a frame owner.'),
    conclusions=[
        'Actual extra payload-copy device time is about23us/decode, not evidence that copy bandwidth alone explains the unprofiled loss.',
        'Seven graph submissions versus one and23.25eagerD2D copies/decode are real extra mechanisms. Six inter-capture transitions contain observed device gaps; they are not guaranteed recoverable time.',
        'Recurring event construction is absent in90pure-reuse calls in both arms; do not optimize an imagined per-append EventCreate hotspot.',
        'Unmarked no-device/no-API gaps grow with history in paged and remain lower in dense. CPU sampling was disabled, so no individual C++ function share is proven.',
        'Instrumented total envelope reverses unprofiled ordering; counts and bounded gap mechanisms inform next implementation, not a tokens/s win or attribution of the full3% loss.'],
    latest_full_throughput_evidence='docs/evidence/performance/qwen-retirement-publication-2026-10-21.json',
    next='Implement descriptor-driven capturable native append on the existing typed Graph write path first, preserving actual permission renewal and whole-state publication; then safe exclusive suffix support. Test and run one full comparison after a substantive hot-path batch.'))
save(S/'published.json',dict(files=[identity(report_path),identity(archive)],archive_files=len(inventory),
    uncompressed_bytes=sum(x['bytes']for x in inventory)))
print(json.dumps(read(S/'published.json'),indent=2))
