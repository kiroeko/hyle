"""Exact leaf cleanup, written to root test.ps1 and inspected before execution."""
from pathlib import Path
import hashlib
import json
S=Path(__file__).resolve().parent
R=S.parents[1]
T=R/'.scratch/paged-retirement-20261021'
def identity(p):
    return dict(path=str(p.resolve()),bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest())
targets=[T/'cpu-link1/cpu.exe',T/'cuda-link1/cuda.exe']
for mode in ('qwen','cpu','cuda'):
    targets += [S/(mode+'-link1')/(mode+suffix) for suffix in ('.map','.lib','.exp')
                if (S/(mode+'-link1')/(mode+suffix)).is_file()]
assert len(set(targets))==len(targets) and all(p.is_file() for p in targets)
assert all(p.resolve().is_relative_to(R/'.scratch') for p in targets)
plan=dict(targets=[identity(p) for p in targets],total_bytes=sum(p.stat().st_size for p in targets),
    receipt=str(R/'docs/evidence/performance/qwen-paged-native-cost-2026-10-21.cleanup.json'),
    kept=['Both raw native timelines and SQLite exports; latest3859/current-profile2941/beforee155/denseff748 model images; new CPU/CUDA append fixtures; final async probe; all original objects/SDKs/weights/source/commands/vector baselines.'],
    reason='Superseded append-fixture images and reconstructible link maps/import stubs only.')
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=(T/'cleanup-script.ps1').read_text(encoding='utf-8')
assert script.count('paged-retirement-20261021')==1
assert script.count(r'correctness\qwen-native-retirement-2026-10-21.cleanup.json')==1
script=script.replace('paged-retirement-20261021','paged-native-cost-20261021')
script=script.replace(r'correctness\qwen-native-retirement-2026-10-21.cleanup.json',
    r'performance\qwen-paged-native-cost-2026-10-21.cleanup.json')
(R/'test.ps1').write_text(script,encoding='utf-8')
(S/'cleanup-script.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(targets),bytes=plan['total_bytes'],script=identity(R/'test.ps1'),
    targets=[str(p.relative_to(R)) for p in targets]),indent=2))
