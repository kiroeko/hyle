"""One changed host owner, retained current native closure, no SDK/NVCC."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
T = R/'.scratch/paged-retirement-20261021'
P = R/'.scratch/qwen-prefix-20261021'
spec=importlib.util.spec_from_file_location('cached_build',T/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def compile_owner():
    source=R/'src/graph_batch/paged_append.cc'
    recipe=P/'core-checks/attempt1/graph_batch--paged_append/identity.json'
    out=S/'host-check1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    frozen=b.identity(source)
    snap=out/'source/src/graph_batch/paged_append.cc'
    snap.parent.mkdir(parents=True);snap.write_bytes(source.read_bytes())
    command=b.host_command(c.read(recipe)['command'],source,'paged_append',out)
    assert all(x in command for x in ('/W4','/WX','/O2','/MD'))
    c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),CXX=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps=c.read(out/'paged_append-deps.json')['Data']
    record=dict(source=frozen,object=b.identity(out/'paged_append.obj'),command=command,
        replaced_object=c.read(recipe)['object'],
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
    assert all(h.h.same(x) for x in record['dependencies']) and h.h.same(frozen)
    c.save(out/'identity.json',record)

def link(mode):
    prior=c.read(T/f'{mode}-ready-attempt1.json')
    base=c.read(prior['link_plan']['path'])
    record=c.read(S/'host-check1/identity.json')
    assert h.h.same(record['source']) and h.h.same(record['object'])
    assert all(h.h.same(x) for x in base['inputs'])
    old=c.key(record['replaced_object']['path']);new=record['object']
    assert sum(c.key(x['path'])==old for x in base['inputs'])==1
    out=S/f'{mode}-link1';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/(mode+'.exe')
    inputs=[new if c.key(x['path'])==old else x for x in base['inputs']]
    command=[new['path'] if c.key(x)==old else x for x in base['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=record['replaced_object'],after=new)],links=1,NVCC=0,SDK_builds=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
    runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH']
    runtime['staged_dlls']=[b.identity(x) for x in out.glob('*.dll')]
    if mode=='cpu' and 'CPU_native_overlay' in runtime:
        runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
    c.save(out/'runtime-environment.json',runtime)
    c.save(S/f'{mode}-ready-attempt1.json',dict(image=b.identity(image),source=prior['source'],
        fresh_sources=[record['source']],link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
    print('READY',mode,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=('compile','qwen','cpu','cuda'))
    args=parser.parse_args()
    if args.mode=='compile':compile_owner()
    else:link(args.mode)
