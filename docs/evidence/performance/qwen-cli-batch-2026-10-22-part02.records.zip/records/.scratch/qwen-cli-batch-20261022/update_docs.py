from pathlib import Path
import json
D=Path(__file__).resolve().parent;R=D.parents[1]
read=lambda p:json.loads(p.read_text())
t=read(D/'performance/timing/summary.json');mem=read(D/'performance/memory/summary.json')
groups=t['groups'];arms=('serial','batch','peer')
def median(arm,key):return groups[arm][key]['median']
def row(label,key,digits=2):return '| '+label+' | '+' | '.join(f'{median(a,key):.{digits}f}'for a in arms)+' |\n'
def mr(label,key):return '| '+label+' | '+' | '.join(f'{mem["groups"][a]["sampled_peaks"][key]/2**30:.3f}'for a in arms)+' |\n'
evidence='../evidence/performance/qwen-cli-batch-2026-10-22.json'
p=R/'docs/developer/current-work.md';s=p.read_text()
a=s.index('**当前正在做：');b=s.index('\n当前每进程',a)
s=s[:a]+'''**当前正在做：CLI真实批次调度及首轮完整性能窗口已完成，接下来定量定位批次decode差距，再接真实MTP。** 等实际T与阶段种类分组，一次Graph提交返回各会话的完整KV／conv／GDN与结果；容量按N份committed＋最多R份候选准备。精确前缀、分支、完全命中、LRU重算及真实CUDA退休已有对应检查。B2→R1淘汰重算出现一处真实greedy差异，现明确保原token历史、使用真实重算head，差异单列；不再把重算冒充逐字节恢复。其它系统原生路径、已选模型完整覆盖、MTP与图片仍未完成。'''+s[b:]
s=s.replace('当前每进程加载一份权重、编译一份图族，在同一队列串行交错；缓存数量／字节准入、空闲淘汰与按原chunk重建已验证。',
'''当前每进程加载一份权重、按批宽编译有限图族；同一Queue上提交实际等T批次，不是每会话复制执行器。缓存数量／字节准入、空闲淘汰与按原chunk重算已验证；旧R1逐字节结果仅对应下面列明的原分块／批宽。''')
s=s.replace('当前仍串行交错，未接GPU同时批处理。其它系统原生写页与完整消费者仍有实现／验证工作',
'''CLI等T真实批次已接通；新窗口B2合计decode153.64对参考186.58tok/s，仍慢17.65%。其它系统原生写页与完整消费者仍有实现／验证工作''')
s=s.replace('下一步接CLI等T调度与N份committed准入，再做完整四项性能对照。Apple／Vulkan原生新写页及完整消费者另有缺口',
'''[CLI等T调度、整批N份committed准入与完整四项对照已做]('''+evidence+''')：8项host检查、真实B2、T1／T16分支、0Graph完整命中与N2淘汰重算通过；48份原R1向量仍逐字节相同。跨B重算保真实差异，不能签质量完成。Apple／Vulkan原生新写页及完整消费者另有缺口''')
s=s.replace('**typed页帧、真实B2计算及批次退休已接通 → CLI等T调度 → 真batch完整性能对照 → MTP真实消费者 → 图片链路**',
'''**typed页帧、真实B2、批次退休、CLI及首轮对照已完成列明范围 → 定量拆分批次decode余差 → MTP真实消费者 → 图片链路**''')
s=s.replace('执行资源复用的完整性能窗口保留在页末；新增B2代码尚未完成新的性能对照。',
'''执行资源复用的旧单会话／串行前缀窗口保留在页末，新双会话B2窗口接在其后，不混合工作量推算收益。''')
s=s.replace('多序列batch与其它后端仍须实现，不是只剩验证，也不以一个CUDA消费者通过代替全部模型／系统完成。',
'''多序列CLI已实现列明范围；其它后端、MTP和图片仍有必要实现，不是只剩验证，也不以一个CUDA消费者通过代替全部模型／系统完成。''')
s=s.replace('包含串行候选版本与COW尾页；不再用旧dense每会话公式计算。容量256、保留1／2会话时分别预留42,418,224／65,101,872字节；',
'''包含最多R份批次候选版本与COW尾页；不再用旧dense每会话公式计算。容量256、R1保留1／2会话时分别预留42,418,224／65,101,872字节，N2／R2为84,836,400字节；''')
s=s.replace('## 最新完整性能对比\n',
'''## 最新完整性能对比

**最新双会话真实B2窗口见本节末尾；下面2026-10-21的单会话与串行共享前缀窗口保留各自工作量，不能互换。**
''')
s=s.replace('下一步接真实多序列batch；MTP、图片及其它原生后端仍未完成。',
'''该窗口之后已接通真实多序列batch，见下；MTP、图片及其它原生后端仍未完成。''')
assert '### 双会话真实批处理：2026-10-22'not in s
s+='''
### 双会话真实批处理：2026-10-22

同一RTX 4070／Windows，Qwen3.5-2B BF16，F32 GDN，无MTP／图片。两条独立会话各执行原`(256新增输入＋32 decode)×3`固定输入，逻辑上下文上限1024、N2；关闭前缀，无淘汰恢复。共1728实际输入、198返回结果，其中1536个prefill、192个decode token。相同脚本／输入复用原SDK和权重，不新造自然对话样本。

Hyle R1与B2是同一新镜像，仅参数R1／R2不同；参考固定d9e03库。R1共198次Graph，双方B2均99次原生批次、相同请求顺序／T与完成边界；波次wall只计一次，不能相加会话或phase的重叠延迟。各3个新进程交错测速，另各1进程内存旁采；三臂每次198个greedy ID全相同，不据此宣称独立模型质量通过。

| 指标 | 同源Hyle R1串行 | Hyle B2 | llama.cpp B2 |
| --- | ---: | ---: | ---: |
'''
s+=row('合计prefill tok/s（1536／P波次总wall）','prefill_tps')
s+=row('合计完整decode tok/s（192／D波次总wall）','full_decode_tps')
s+=row('综合输出 tok/s（198／全程wall）','session_output_tps')
s+=row('推理全程wall s','session_seconds',5)
s+=row('入口至末输出 s（含加载／冷准备）','startup_total_seconds',5)
s+=row('启动至ready s','ready_seconds',5)
s+=row('权重加载 s（未清OS页缓存）','load_seconds',5)
s+=mr('GPU dedicated观测峰 GiB','sampled_peak_gpu_dedicated_bytes')
s+=mr('GPU shared观测峰 GiB','sampled_peak_gpu_shared_bytes')
s+=mr('GPU同点总量观测峰 GiB','sampled_peak_gpu_total_bytes')
s+=mr('CPU working set观测峰 GiB','sampled_max_working_set_bytes')
s+=mr('进程private commit观测峰 GiB','sampled_max_private_commit_bytes')
s+='''
B2相对同源R1：prefill＋17.21%、decode＋52.23%、综合＋47.38%。相对参考B2：prefill＋18.72%、decode－17.65%、综合－12.60%。**真实batch提高双路合计吞吐，尚未追平参考；不是单用户decode提高五成。** B2每路平均decode约76.82tok/s，也不等于每人独占GPU的单请求速度。

R1／B2／参考的decode范围为100.91–101.74／153.46–153.96／186.14–186.86tok/s，综合范围为92.58–93.35／135.44–136.77／155.63–156.64。只3进程、桌面单卡，不宣称全部场景统计稳定；没有丢慢样本或用kernel数量代替速度。

三者实际状态backing为83,976,240／103,710,768／105,971,712字节。Hyle B2有N＋R=4份状态块、2080物理KV行；参考4个native ID、2048行共享KV池，`n_ctx_seq`报告2048但消费者逻辑上限仍1024。参考在无旧读者时原地续写，失败取消合同也与Hyle整批保旧head不同；同输入／N／R不等于逐字节资源或故障合同相同。GPU峰值差不全部归因于KV预算。

内存实际中位采样间隔约15.2ms，三个ready基线均无区间样本；dedicated／shared独立峰不可相加，总量取同一点。阶段峰及邻样变化在证据中，短P可能缺样；上述是观测下界，未证明精确分配节省，旁采进程时间不进入测速表。

本批正确性另核8项host检查；普通B2为26次独立Graph／36次会话参与、239输入；分支窗口813逻辑输入、297实际token、10次Graph，4次前缀命中中2次完整命中0Graph。N2／R2压力窗口单列18次重算、185额外token；B2来源的一次历史greedy在R1重算时由5548变958，hidden／logits均有限且描述性余弦大于0.99992，**保留真实差异，不把它算成精确恢复或质量通过**。原R1的18份及N2前缀压力的30份决策向量仍逐字节相同；新重算history与真实新head一致，旧共享history与已返回token不改。显式R2预算少1字节在Model加载前拒绝；auto预算能同时收缩N与R。

下一步用一次实际GPU分析拆分B2状态收集／回写、准备／录制与原生计算，确认17.65%余差的组成再改；当前每请求每步存在约39.1MB状态打包／拆分载荷是调查方向，**尚未证明是主因**。之后接真实MTP，保无MTP基线。源码、失败、完整原始样本、向量与独立复算见[本批证据]('''+evidence+''')。
'''
p.write_text(s)
p=R/'docs/developer/performance/decode.md';s=p.read_text();a=s.index('**当前优先项');b=s.index('\n\n',a)
s=s[:a]+'''**当前优先项（2026-10-22）：真实CLI batch与首轮四项对照已完成，定量定位B2的decode余差，同时保留单会话分页慢项。** 同源R1／Hyle B2／llama B2合计完整decode为100.92／153.64／186.58tok/s，综合92.61／136.48／156.15；新B2比参考慢17.65%，不是单用户延迟窗口。prefill、内存、启动、范围与差异见[当前末表](../current-work.md#双会话真实批处理2026-10-22)及[原始证据](../../evidence/performance/qwen-cli-batch-2026-10-22.json)。下一步只做一次针对实际B2计算的GPU定量拆分，核状态收集／回写、Graph准备／重录和原生计算占比后选择优化，不凭额外载荷推定主因。'''+s[b:]
s=s.replace('最新[执行资源复用窗口]','此前[执行资源复用窗口]')
a=s.index('顺序：**可录制写页');b=s.index('\n\n',a)
s=s[:a]+'''顺序：**可录制写页、独占续写、Radix、执行资源复用、typed页帧、真实批次及CLI完整对照均已完成列明范围 → 定量拆分B2 decode余差 → 真实MTP消费者**。Conv／GDN独立B维、页帧组合／投影、完整状态／结果分流与N＋R预算已接通，8项host及实际批次／淘汰检查有结果。精确快照命中与原token重算分别报告；跨B重算允许实际数值差异，未签完整质量。单会话延迟、缓存命中收益和多人吞吐分开；其它系统原生写页与图片仍有必要实现，不扩大成重复全量验证。'''+s[b:]
p.write_text(s)
print('updated current-work and decode plan')
