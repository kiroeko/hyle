"""Filesystem-only independent review of the completed D performance window."""
from pathlib import Path
import collections, hashlib, json, math, re, statistics

D = Path(__file__).resolve().parent.parent
R = D.parents[1]
P = D / 'performance'
ARMS = ('serial', 'batch', 'peer')
MEM_KEYS = ('working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes', 'gpu_total_bytes')


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def stats(xs):
    return dict(count=len(xs), median=statistics.median(xs), min=min(xs), max=max(xs), samples=xs)


def percent(a, b):
    return (a / b - 1) * 100


def check_run(folder, arm, memory):
    process = read(folder / 'result.json')
    command = read(folder / 'command.json')
    assert process['exit'] == 0 and process['reader_errors'] == []
    assert process['memory_only'] == memory and process['throughput_evidence'] != memory
    raw_path = folder / ('peer-result.json' if arm == 'peer' else 'stdout.log')
    raw = read(raw_path)
    expected_image = read(D / ('peer-ready.json' if arm == 'peer' else 'qwen-ready-attempt3.json'))['image']
    assert command['image'] == expected_image == process['image']
    assert raw['processed_tokens'] == raw['actual_graph_tokens'] == 1728
    assert raw['generated_tokens'] == 198 and raw['reused_tokens'] == 0
    assert raw['prefix_cache'] == 'off' and raw['prefix_hits'] == raw['prefix_full_hits'] == 0
    width = 1 if arm == 'serial' else 2
    assert raw['actual_graph_calls'] == 198 // width
    units = raw['episodes'] if arm == 'peer' else raw['batches']
    waves = raw['waves']
    assert len(waves) == len(units) == 198 // width
    phases = collections.defaultdict(float)
    positions = dict(alice=0, bob=0)
    orders = []
    round_seconds = [dict(prefill=0.0, decode=0.0) for _ in range(3)]
    wave_seconds = 0
    for wave, unit in zip(waves, units):
        names = tuple(x['session'] for x in unit['members']) if arm == 'peer' else tuple(unit['session_ids'])
        t = unit['T'] if arm == 'peer' else unit['query_rows']
        kind = unit['kind']
        assert len(names) == unit['requests'] == width and len(set(names)) == width
        assert wave['kind'] == kind and wave['outputs'] == width and wave['graph_calls'] == 1
        assert wave['logical_tokens'] == wave['actual_tokens'] == width * t
        assert t == (256 if kind == 'prefill' else 1)
        rounds = set()
        for name in names:
            pos = positions[name]
            rounds.add(pos // 288)
            assert (pos % 288 == 0) if kind == 'prefill' else (256 <= pos % 288 < 288)
            positions[name] += t
        assert len(rounds) == 1
        round_seconds[next(iter(rounds))][kind] += wave['seconds']
        phases[kind] += wave['seconds']; wave_seconds += wave['seconds']
        orders.append((kind, t, names))
    assert positions == dict(alice=864, bob=864)
    assert sum(w['logical_tokens'] for w in waves) == 1728
    assert sum(w['outputs'] for w in waves) == 198
    ids = {}
    for session in raw['sessions']:
        name = session['id' if arm == 'peer' else 'session_id']
        ids[name] = session['generated_ids']
        assert len(ids[name]) == 99 and all(type(x) is int and 0 <= x < 248320 for x in ids[name])
        assert session['visible_tokens'] == 864 and len(session['phases']) == 6
        for i, phase in enumerate(session['phases']):
            before = (i // 2) * 288 + (256 if i % 2 else 0)
            assert phase['context_before'] == before
            assert phase['context_after'] == before + (32 if i % 2 else 256)
        if arm != 'peer':
            assert session['restored_calls'] == session['restored_tokens'] == 0 and session['recomputed_decision_changes'] == []
    wall = raw['session_seconds' if arm == 'peer' else 'interleaved_seconds']
    assert 0 < wave_seconds <= wall and wall - wave_seconds < 0.001
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8-sig')
    if arm == 'peer':
        load = raw['model_load_seconds']; ready = raw['ready_seconds']
        cold = dict(model_load_seconds=load, ready_seconds=ready, context_seconds=raw['context_seconds'])
        assert raw['native_sequence_quota'] == 4 and raw['native_n_ctx'] == raw['native_n_ctx_seq'] == 2048
        assert raw['seq_copy_api_calls'] == 0 and raw['peak_native_versions'] == 2
    else:
        load = float(re.search(r'^weights_load_seconds=(\S+)', stderr, re.M)[1])
        match = re.search(r'initialized model_seconds=(\S+) shape_prepare_seconds=(\S+) startup_to_ready_seconds=(\S+)', stderr)
        ready = float(match[3])
        cold = dict(weights_load_seconds=load, model_seconds=float(match[1]), shape_prepare_seconds=float(match[2]), ready_seconds=ready)
        assert raw['source_id'] == '4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155'
        assert raw['text_tensors'] == 320 and raw['max_batch_requests'] == width
        assert raw['cache_peak_committed_versions'] <= 2 and raw['cache_live_requested_bytes'] == raw['cache_shared_backing_bytes']
    metrics = dict(prefill_tps=1536 / phases['prefill'], decode_tps=192 / phases['decode'],
        session_output_tps=198 / wall, session_input_tps=1728 / wall,
        startup_inclusive_output_tps=198 / raw['startup_total_seconds'],
        prefill_seconds=phases['prefill'], decode_seconds=phases['decode'], session_seconds=wall,
        startup_total_seconds=raw['startup_total_seconds'], model_load_seconds=load, ready_seconds=ready,
        request_outside_wave_seconds=wall-wave_seconds)
    replay = None
    if arm != 'peer':
        sections = re.split(r'session_steps id=(\w+)\n', stderr)
        per_session = {}
        rx = r'prepared T=(\d+) visible=(\d+) replay=(\S+) cold_batch_seconds=(\S+) capture_recorded=(\d+) capture_reused=(\d+)'
        for at in range(1, len(sections), 2):
            per_session[sections[at]] = re.findall(rx, sections[at+1])
        assert set(per_session) == {'alice', 'bob'} and all(len(rows) == 99 for rows in per_session.values())
        if width == 2:
            assert per_session['alice'] == per_session['bob']
            rows = per_session['alice']  # each physical batch reported once per participant
        else:
            rows = per_session['alice'] + per_session['bob']
        assert len(rows) == raw['actual_graph_calls']
        replay = dict(physical_preparation_calls=len(rows), per_session_log_rows=198,
            recorded_calls=sum(int(x[4]) for x in rows), reused_calls=sum(int(x[5]) for x in rows),
            routes=dict(collections.Counter(x[2] for x in rows)),
            cold_prefill_seconds=sum(float(x[3]) for x in rows if x[0] == '256'),
            cold_decode_seconds=sum(float(x[3]) for x in rows if x[0] == '1'),
            pure_reuse_decode_calls=sum(x[0] == '1' and x[4] == '0' for x in rows),
            pure_reuse_decode_preparation_ms=stats([float(x[3])*1000 for x in rows if x[0] == '1' and x[4] == '0']))
    return dict(folder=str(folder), arm=arm, exit=process['exit'], image=expected_image,
        raw=identity(raw_path), stderr=identity(folder/'stderr.log'), command=identity(folder/'command.json'),
        actual_input_tokens=1728, outputs=198, actual_graph_calls=raw['actual_graph_calls'],
        metrics=metrics, rounds=round_seconds, cold=cold, replay=replay), ids, orders


def check_memory(folder):
    raw = read(folder/'memory.json'); process = read(folder/'result.json')
    running = [x for x in raw['samples'] if x['process_running']]
    assert process['exit'] == 0 and raw['gpu_setup_error'] is None and raw['thread_error'] is None
    phases = {}
    for marker in process['markers']:
        match = re.fullmatch(r'(.+_(?:prefill|decode))_(begin|end)', marker['name'])
        if match:
            phases.setdefault(match[1], {}).setdefault(match[2], []).append(marker['timestamp_ns'])
    assert len(phases) == 12
    counts = {}
    for name, edges in phases.items():
        assert len(edges['begin']) == len(edges['end']) == 1 and edges['begin'][0] <= edges['end'][0]
        counts[name] = sum(edges['begin'][0] <= x['timestamp_ns'] <= edges['end'][0] for x in running)
    begin = min(e['begin'][0] for e in phases.values()); end = max(e['end'][0] for e in phases.values())
    inference = [x for x in running if begin <= x['timestamp_ns'] <= end]
    ready = max(x['timestamp_ns'] for x in process['markers'] if x['name'] in ('ready_before_first', 'ready_before_prefill'))
    assert ready <= begin
    ready_samples = [x for x in running if ready <= x['timestamp_ns'] <= begin]
    peaks = {k:max((x[k] for x in running if x.get(k) is not None), default=None) for k in MEM_KEYS}
    lifetime = {k:max(x[k] for x in raw['samples'] if x.get(k) is not None) for k in ('os_peak_working_set_bytes', 'os_peak_commit_bytes')}
    growth = {}
    for k in MEM_KEYS:
        usable = [x for x in inference if x.get(k) is not None]
        growth[k] = dict(first=usable[0][k], last=usable[-1][k], first_to_last=usable[-1][k]-usable[0][k],
            min=min(x[k] for x in usable), max=max(x[k] for x in usable), null_count=len(inference)-len(usable))
    gaps = [(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(running,running[1:])]
    summary = read(folder/'memory-summary.json')
    check_names = dict(working_set_bytes='sampled_max_working_set_bytes', private_commit_bytes='sampled_max_private_commit_bytes',
        gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes', gpu_shared_bytes='sampled_peak_gpu_shared_bytes', gpu_total_bytes='sampled_peak_gpu_total_bytes')
    assert all(peaks[k] == summary['sampled_peaks'][mapped] for k,mapped in check_names.items())
    assert counts == {k:v['sample_count'] for k,v in summary['phase_windows'].items()}
    assert summary['ready_baseline']['unknown'] == (not ready_samples)
    return dict(raw=identity(folder/'memory.json'), result=identity(folder/'result.json'),
        requested_interval_seconds=raw['requested_interval_s'], samples=len(raw['samples']), running_samples=len(running),
        peaks_bytes=peaks, observed_os_lifetime_peaks_bytes=lifetime,
        peaks_GiB={k:v/(1024**3) if v is not None else None for k,v in peaks.items()},
        ready_baseline_available=bool(ready_samples), ready_to_inference_delta=None if not ready_samples else 'not needed',
        observed_inference_sample_window=dict(samples=len(inference), first_after_begin_ms=(inference[0]['timestamp_ns']-begin)/1e6,
            last_before_end_ms=(end-inference[-1]['timestamp_ns'])/1e6, values_bytes=growth),
        running_sample_gap_ms={k:v for k,v in stats(gaps).items() if k != 'samples'},
        actual_phase_sample_counts=counts, original_memory_summary_verified=True)


def main():
    runs=[]; reference_ids={}; reference_order=None; memory={}; memory_runs=[]
    for mode in ('timing','memory'):
        inputs=read(P/mode/'inputs.json')
        for entry in inputs['commands']:
            arm=entry['variant']; folder=Path(entry['folder'])
            row, ids, order=check_run(folder,arm,mode=='memory')
            if arm in reference_ids: assert reference_ids[arm] == ids
            else: reference_ids[arm]=ids
            if arm != 'serial':
                if reference_order is None: reference_order=order
                else: assert reference_order == order
            if mode=='timing': runs.append(row)
            else:
                memory_runs.append(row);memory[arm]=check_memory(folder)
    assert len(runs)==9 and len(memory)==3
    assert reference_ids['batch'] == reference_ids['serial'] == reference_ids['peer']
    grouped={a:[x for x in runs if x['arm']==a] for a in ARMS}
    metrics={a:{k:stats([x['metrics'][k] for x in rows]) for k in rows[0]['metrics']} for a,rows in grouped.items()}
    rounds={a:[{kind:stats([512/x['rounds'][i]['prefill'] if kind=='prefill_tps' else 64/x['rounds'][i]['decode'] for x in rows])
        for kind in ('prefill_tps','decode_tps')} for i in range(3)] for a,rows in grouped.items()}
    changes={a:{k:percent(metrics['batch'][k]['median'],metrics[a][k]['median']) for k in ('prefill_tps','decode_tps','session_output_tps','startup_inclusive_output_tps')} for a in ('serial','peer')}
    pooled={a:dict(prefill_tps=3*1536/sum(x['metrics']['prefill_seconds'] for x in rows),
        decode_tps=3*192/sum(x['metrics']['decode_seconds'] for x in rows),
        session_output_tps=3*198/sum(x['metrics']['session_seconds'] for x in rows)) for a,rows in grouped.items()}
    decomposition={a:statistics.mean(x['metrics'][a] for x in grouped['batch'])-statistics.mean(x['metrics'][a] for x in grouped['peer'])
        for a in ('prefill_seconds','decode_seconds','request_outside_wave_seconds','session_seconds')}
    report=dict(status='PASS independent raw-work/episode/ID/timing/memory recomputation; no quality or statistical-significance acceptance',
        checker=identity(Path(__file__)), actual_timing_processes=9, independent_memory_processes=3,
        process_results=runs, metric_definitions=dict(prefill_tps='1536 actual prefill input tokens / sum measured prefill wave wall',
        decode_tps='192 actual decode input/output tokens / sum decode wave wall (aggregate two-session throughput)',
        session_output_tps='198 returned greedy IDs / full interleaved request wall; includes six prefill decisions',
        startup_inclusive_output_tps='198 returned decisions / consumer startup-to-last-publication wall; excludes process teardown',
        aggregation='Process median/min/max from 3 fresh processes per arm. Pooled rates are separate sum(tokens)/sum(wall), never arithmetic mean of TPS.'),
        process_statistics=metrics, round_statistics=rounds, pooled=pooled,
        batch_vs_other_median_rate_change_percent=changes, mean_batch_minus_peer_wall_decomposition_seconds=decomposition,
        work_verified=dict(input_tokens=1728,prefill_tokens=1536,decode_tokens=192,outputs=198,session_ids=['alice','bob'],
            logical_contexts=[0,256,288,544,576,832,864],R1_actual_Graph_calls=198,B2_actual_Graph_calls=99,
            B2_episode_order_equal=True,all_12_processes_work_checked=True,all_12_processes_greedy_ids_equal=True,
            prefix='off; no hits, no reused input, no eviction/recompute in this load',
            observation='R2 means actual two-member episodes, not two independently submitted graphs. Native API call/Graph submission count is not CUDA kernel or CUDA graph-launch count.'),
        memory=memory,memory_process_work=memory_runs,
        source_and_math=dict(hyle_ready=read(D/'qwen-ready-attempt3.json'),peer_ready=read(D/'peer-ready.json'),
            same_Hyle_source_and_image_for_R1_and_B2=True,
            source_checkpoint='Same original Qwen3.5-2B checkpoint; 320 text tensors, no MTP/vision or low-bit quantization.',
            converted_model_audit=identity(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/converted-model-audit.json'),
            representations='Hyle reads original Safetensors BF16/F32; retained peer GGUF has187BF16+133F32, including97 original BF16 small tensors promoted to F32. Prior audit checked all F32 exception values/name/shape/type mapping. This review does not rehash multi-GB weights.',
            intermediate_math='Actual full model and tokens are comparable, but intermediate evaluation is not bit-identical: Hyle conv history BF16/GDN F32 (main.cc183-194), peer original recurrent R/S F32. BF16 KV on both. Equal198 IDs here does not establish cross-B or cross-engine tensor tolerance/quality.',
            capacities='Logical C1024,N2,R2 for batch/peer. Hyle serial candidate capacityN+1 vs batchN+2 is intentional. HyleR1 backing83,976,240B; HyleB2 backing103,710,768B (130x16 physical KV rows=2080); peer KV+RS105,971,712B/native2048-token pool/native IDs4. Peer native_n_ctx_seq2048 is an allocation ability; common input remains864 tokens/session and logical cap1024.',
            failure_contract='Hyle retains bounded immutable snapshot candidates and whole-batch atomic completion/abort. Peer may update unretained native sequence versions in place (zero seq_cp observed here); benchmark does not equate their failure/cancel contracts.'),
        fairness_and_limits=[
            'Timing order serial,batch,peer / peer,batch,serial / batch,serial,peer rotates arms. Timing has no side memory probe/profiler; memory uses separate fresh processes. Only3 timing processes/arm and1 sampled memory process/arm, no significance or general four-user forecast.',
            'Actual manifest has two independent Session owners using identical fixed token histories. Prefix is off; neither engine can count prefix skips as work. This is controlled synthetic synchronized B2 throughput, not free-running generation, asynchronous arrivals, heterogenous prompts or p50/p95 serving latency.',
            'Wave timers on both arms cover preparation/admission, native work, synchronization, all host greedy IDs and publication. Hyle has a few more microseconds of result accounting outside each wave; full request wall retains it. Never add overlapping per-session/request latency or duplicated per-participant cold logs.',
            'Load labels differ: Hyle weights_load_seconds is the physical weight-loader subsection, peer model_load_seconds includes original native model load. Ready/startup endpoints retain backend/context/family/slot work; compare complete startup separately, not those load subsections alone.',
            'Window-before GPU snapshot22%/SM210MHz and after78%/SM2820MHz are rolling snapshots around the consumers, not proven external background utilization. No locked clock or exclusive-desktop guarantee; OS page cache was not cleared. Range across samples is retained.',
            'Memory uses PSAPI+PDH at requested10ms; actual median running gaps about15ms, plus marker-triggered fast samples. Parent-received phase markers are not device timestamps; per-session B2 windows overlap. GPU sampled peaks are lower bounds, unknown counters remain null, dedicated/shared independent maxima must not be added.',
            'No sample falls between ready and the near-immediate first prefill in any memory arm. Ready-to-inference delta is unknown. Report observed first-to-last inference samples with explicit missed-boundary ages, not an exact allocation-growth attribution.',
            'CPU WorkingSet includes mapped/shared resident pages (peer mmap loader retains a different host mapping footprint); PrivateUsage is process commit rather than private resident RAM. Neither is physical RAM plus VRAM. CUDA buffer totals, state backing ledger and per-PID WDDM allocation accounting measure different things.'
        ], remaining_gap_and_directions=[
            'Batching materially raises aggregate decode throughput relative to same-image serial. Remaining peer loss is decode: mean decode wall difference is positive and dominates, while prefill is faster. This conclusion uses actual wave walls, not kernel counts.',
            'Existing host cold/preparation buckets can quantify part of overhead, but do not isolate GPU bandwidth, launch gaps, conversions, state copy or output publication. HyleR2 T1 selected child reports1234 steps vs R1 T1 1041; inspect shape-dependent plans/fusion and physical native boundaries in a matched R2 trace before calling them a cause.',
            'All measured Hyle physical episodes use hybrid replay; first two parity slots/turn are recorded, later calls reuse. This is a source/host-log fact, not evidence of the number/time of CUDA graph launches. Do not reuse earlier single-session native profile percentages for B2.',
            'A next narrowly scoped native comparison could separate R2 device busy/copy bytes/graph-launch API/gaps from host permission+metadata+whole-state publication, preserving original contract. No extra profiling process is launched by this checker.'
        ])
    out=D/'review/performance-review.json'
    out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=identity(out),medians={a:{k:metrics[a][k]['median'] for k in ('prefill_tps','decode_tps','session_output_tps','startup_inclusive_output_tps')} for a in ARMS},changes=changes,decomposition=decomposition),indent=2))


if __name__ == '__main__': main()
