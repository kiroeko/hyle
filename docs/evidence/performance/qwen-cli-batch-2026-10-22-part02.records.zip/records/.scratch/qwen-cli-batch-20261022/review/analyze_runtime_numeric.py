"""Host-only audit of completed finite CLI runs; never starts a consumer."""
from pathlib import Path
from collections import Counter
import json
import re
import xml.etree.ElementTree as ET

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
D = ROOT / ".scratch/qwen-cli-batch-20261022"
Q = ROOT / ".scratch/qwen-multisequence-20261021"


def load(path):
    duplicates = []

    def object_pairs(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                duplicates.append(key)
            value[key] = item
        return value

    value = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=object_pairs)
    assert not duplicates, (str(path), duplicates)
    return value


def calls(session):
    result = []
    for phase in session["phases"]:
        count = 1 if phase["kind"] == "prefill" else phase["input_tokens"]
        for local in range(count):
            name = phase["name"] if phase["kind"] == "prefill" else phase["name"] + str(local + 1)
            result.append({"name": name, "kind": phase["kind"],
                           "tokens": phase["input_tokens"] if phase["kind"] == "prefill" else 1,
                           "context_after": phase["context_after"] if phase["kind"] == "prefill"
                               else phase["context_before"] + local + 1})
    return result


def audit_run(name):
    directory = D / name
    terminal = load(directory / "result.json")
    assert terminal["exit"] == 0
    value = load(directory / "stdout.log")  # Check original stream, not only re-serialized JSON.
    assert value == load(directory / "output.json")
    sessions = {s.get("session_id", "default"): s for s in value.get("sessions", [value])}
    batches = value["batches"]
    participations, tokens, restores, restore_tokens = Counter(), Counter(), Counter(), Counter()
    for batch in batches:
        assert batch["requests"] == len(batch["session_ids"]) > 0 and batch["query_rows"] > 0
        assert len(set(batch["session_ids"])) == batch["requests"]
        for sid in batch["session_ids"]:
            assert sid in sessions
            participations[sid] += 1
            tokens[sid] += batch["query_rows"]
            if batch["restore"]:
                restores[sid] += 1
                restore_tokens[sid] += batch["query_rows"]
    assert value["actual_graph_calls"] == len(batches)
    assert value["actual_graph_tokens"] == sum(tokens.values())
    assert value["max_batch_requests"] == max(b["requests"] for b in batches)
    assert value["graph_participations"] == sum(participations.values())
    for sid, session in sessions.items():
        assert session["graph_participations"] == participations[sid]
        assert session["graph_input_tokens"] == tokens[sid]
        assert session["restored_calls"] == restores[sid]
        assert session["restored_tokens"] == restore_tokens[sid]
        assert tokens[sid] == session["processed_tokens"] - session["reused_tokens"] + restore_tokens[sid]
        assert participations[sid] == session["generated_tokens"] - session["prefix_full_hits"] + restores[sid]
        assert len(session["generated_ids"]) == len(calls(session)) == session["generated_tokens"]
        previous = 0
        for phase in session["phases"]:
            assert phase["context_before"] == previous
            previous += phase["input_tokens"]
            assert phase["context_after"] == previous
        assert previous == session["processed_tokens"]
    dispatch = value.get("logical_dispatch_session_ids", ["default"] * value["generated_tokens"])
    logical = {sid: calls(s) for sid, s in sessions.items()}
    cursor, start, batch_start, full_hits = Counter(), 0, 0, []
    for wave in value["waves"]:
        members = dispatch[start:start + wave["outputs"]]
        assert len(members) == wave["outputs"] and len(set(members)) == len(members)
        selected = [(sid, logical[sid][cursor[sid]]) for sid in members]
        assert wave["logical_tokens"] == sum(c["tokens"] for _, c in selected)
        kinds = {c["kind"] for _, c in selected}
        assert wave["kind"] == (next(iter(kinds)) if len(kinds) == 1 else "mixed")
        episode = batches[batch_start:batch_start + wave["graph_calls"]]
        assert len(episode) == wave["graph_calls"]
        assert wave["actual_tokens"] == sum(b["requests"] * b["query_rows"] for b in episode)
        normal = {sid: b for b in episode if not b["restore"] for sid in b["session_ids"]}
        assert sum(b["requests"] for b in episode if not b["restore"]) == len(normal)
        assert set(normal) <= set(members)
        for sid, call in selected:
            session = sessions[sid]
            relative = Path(session.get("trace_subdirectory", "")) / call["name"]
            trace = directory / "trace" / relative
            if sid in normal:
                assert normal[sid]["kind"] == call["kind"]
                assert 0 < normal[sid]["query_rows"] <= call["tokens"]
            else:
                assert call["kind"] == "prefill"
                hit = load(trace / "cache-hit.json")
                assert hit["graph_calls"] == 0 and hit["tensor_payload_available"] is False
                assert not list(trace.glob("*.bf16")) and not list(trace.glob("*.f32"))
                assert hit["next_id"] == session["generated_ids"][cursor[sid]]
                assert hit["visible_tokens"] == call["context_after"]
                full_hits.append({"session": sid, "call": cursor[sid], "trace": str(relative),
                                  "visible_tokens": hit["visible_tokens"], "next_id": hit["next_id"]})
            cursor[sid] += 1
        start += wave["outputs"]
        batch_start += wave["graph_calls"]
    assert start == len(dispatch) == value["generated_tokens"] and batch_start == len(batches)
    assert sum(w["logical_tokens"] for w in value["waves"]) == value["processed_tokens"]
    assert sum(w["actual_tokens"] for w in value["waves"]) == value["actual_graph_tokens"]
    assert len(full_hits) == value["prefix_full_hits"]
    limit = value["cache_committed_version_limit"]
    assert value["cache_live_snapshot_versions"] <= limit and value["cache_peak_committed_versions"] <= limit
    return value, {"terminal_exit": terminal["exit"], "image_sha256": terminal["image"]["sha256"],
                   "duplicate_JSON_keys": 0, "stdout_equals_saved_JSON": True,
                   "graph_calls": len(batches), "graph_participations": sum(participations.values()),
                   "graph_tokens": sum(tokens.values()), "restore_graph_calls": sum(restores.values()),
                   "restore_tokens": sum(restore_tokens.values()), "logical_outputs": value["generated_tokens"],
                   "logical_tokens": value["processed_tokens"], "wave_count": len(value["waves"]),
                   "max_batch_requests": value["max_batch_requests"], "full_hits": full_hits,
                   "reported_versions": {"limit": limit, "live": value["cache_live_snapshot_versions"],
                                         "peak_committed": value["cache_peak_committed_versions"]},
                   "accounting_checks": "all batches, per-Session participation/token/restore counters and wave partitions agree"}


def array(path):
    if path.suffix == ".bf16":
        return (np.fromfile(path, dtype="<u2").astype(np.uint32) << 16).view(np.float32)
    return np.fromfile(path, dtype="<f4")


def compare(a, b):
    assert a.stat().st_size == b.stat().st_size
    x, y = array(a).astype(np.float64), array(b).astype(np.float64)
    assert x.shape == y.shape
    finite = bool(np.isfinite(x).all() and np.isfinite(y).all())
    den = float(np.sqrt(np.sum(x * x)) * np.sqrt(np.sum(y * y)))
    return {"elements": int(x.size), "all_finite": finite,
            "byte_equal": a.read_bytes() == b.read_bytes(),
            "max_abs": float(np.max(np.abs(x - y))),
            "cosine": float(np.sum(x * y) / den) if den else (1.0 if np.array_equal(x, y) else None)}


def main():
    reports, values = {}, {}
    for name in ["batch-run1", "r1-run1", "pressure-run2", "prefix-run3", "batch-run2", "prefix-pressure-run1"]:
        values[name], reports[name] = audit_run(name)
    host = load(D / "host-run1/result.json")
    xml = ET.parse(D / "host-run1/gtest.xml").getroot()
    assert host["exit"] == 0 and xml.get("tests") == "8" and xml.get("failures") == "0"
    reports["host-run1"] = {"exit": 0, "tests": 8, "new_scheduler_checks": 3,
                             "failures": 0, "skipped": sum(int(s.get("skipped", 0)) for s in xml)}
    r1, base = D / "r1-run1/trace", Q / "single-run3/trace"
    files = sorted(p.relative_to(r1) for p in r1.rglob("*") if p.suffix in [".bf16", ".f32"])
    baseline_files = sorted(p.relative_to(base) for p in base.rglob("*") if p.suffix in [".bf16", ".f32"])
    assert files == baseline_files and len(files) == 18
    assert all((r1 / p).read_bytes() == (base / p).read_bytes() for p in files)
    reports["R1_against_Q_single_run3"] = {"vector_files": 18, "all_byte_equal": True,
                                           "baseline": str(base.relative_to(ROOT))}
    pressure = values["pressure-run2"]
    restore_metrics = []
    for session in pressure["sessions"]:
        trace = D / "pressure-run2/trace" / session["trace_subdirectory"]
        names, changes = calls(session), []
        for restored in sorted((trace / "restores").iterdir()):
            match = re.fullmatch(r"restore(\d+)_call(\d+)", restored.name)
            assert match is not None and session["prefix_cache"] == "off"
            index = int(match[2])
            original = trace / names[index]["name"]
            raw, old = array(restored / "logits.f32"), array(original / "logits.f32")
            actual, previous = int(np.argmax(raw)), session["generated_ids"][index]
            assert int(np.argmax(old)) == previous
            if actual != previous:
                changes.append({"chunk": index, "previous": previous, "actual": actual})
            metric = {"session": session["session_id"], "call": index, "original": names[index]["name"],
                      "restored": restored.name, "original_argmax": previous, "restore_argmax": actual}
            for file in ["hidden.bf16", "logits.f32"]:
                metric[file] = compare(original / file, restored / file)
                assert metric[file]["all_finite"]
            restore_metrics.append(metric)
        assert sorted(changes, key=lambda x: x["chunk"]) == sorted(session["recomputed_decision_changes"], key=lambda x: x["chunk"])
        assert sum(m["session"] == session["session_id"] for m in restore_metrics) == session["restored_calls"]
    assert len(restore_metrics) == 18
    prefix_directory, prefix_baseline = D / "prefix-pressure-run1/trace", Q / "pressure-run3/trace"
    original_files = lambda directory: sorted(p.relative_to(directory) for p in directory.rglob("*")
        if p.suffix in [".bf16", ".f32"] and "restores" not in p.relative_to(directory).parts)
    files = original_files(prefix_directory)
    assert files == original_files(prefix_baseline) and len(files) == 30
    assert all((prefix_directory / p).read_bytes() == (prefix_baseline / p).read_bytes() for p in files)
    original_value = load(Q / "pressure-run3/stdout.log")
    original_sessions = {s["session_id"]: s for s in original_value["sessions"]}
    for session in values["prefix-pressure-run1"]["sessions"]:
        original_session = original_sessions[session["session_id"]]
        assert session["generated_ids"] == original_session["generated_ids"]
        assert [(p["context_before"], p["context_after"]) for p in session["phases"]] == [
            (p["context_before"], p["context_after"]) for p in original_session["phases"]]
    prefix_restores = []
    for path in sorted(prefix_directory.rglob("*")):
        if path.suffix not in [".bf16", ".f32"] or "restores" not in path.relative_to(prefix_directory).parts:
            continue
        data = array(path)
        assert bool(np.isfinite(data).all())
        prefix_restores.append({"path": str(path.relative_to(prefix_directory)),
                                "elements": int(data.size), "all_finite": True,
                                "argmax": int(np.argmax(data)) if path.suffix == ".f32" else None})
    assert len(prefix_restores) == 10
    reports["prefix_pressure_against_Q_pressure_run3"] = {
        "original_vector_files": 30, "all_byte_equal": True, "all_generated_ids_and_contexts_equal": True,
        "baseline": str(prefix_baseline.relative_to(ROOT)), "new_restore_vectors": prefix_restores,
        "scope": "New restore2_chunk0..4 are original imported history chunks, not the same Session's logical call0..4."
                 " They are listed separately as finite; no invented call-index comparison or cross-B quality acceptance."}
    result = {"status": "Finite accounting/byte/argmax checks complete; no cross-batch quality or throughput acceptance",
              "runs": reports, "pressure_restore_comparisons": restore_metrics,
              "pressure_restore_summary": {file: {
                  "pairs": len(restore_metrics), "byte_equal_pairs": sum(m[file]["byte_equal"] for m in restore_metrics),
                  "all_finite": all(m[file]["all_finite"] for m in restore_metrics),
                  "largest_max_abs": max(m[file]["max_abs"] for m in restore_metrics),
                  "minimum_cosine": min(m[file]["cosine"] for m in restore_metrics)
                  } for file in ["hidden.bf16", "logits.f32"]},
              "changed_restore_argmax": [{k: m[k] for k in ["session", "call", "original", "original_argmax", "restore_argmax"]}
                                         for m in restore_metrics if m["original_argmax"] != m["restore_argmax"]],
              "limits": ["batch-run1 uses an earlier image; its recorded counters/math are reviewed as historical, not final-image validation.",
                         "Per-Session Graph participation sums are not independent Graph submission counts; shared batches count once.",
                         "The reported N-bound covers observed committed counters, not an independent instantaneous candidate/driver-memory measurement.",
                         "Pressure restores recompute the original input chunks via R1. Equal IDs/finite tensors do not imply same full recurrent state as the original B2 execution.",
                         "Cosine/maxabs are descriptive. No cross-B error/quality threshold is applied or inferred; changed restored argmax is retained as a real difference.",
                         "Final ready3 batch-run2 and prefix-pressure-run1 are included separately; prior batch-run1 remains historical.",
                         "prefix-pressure-run1 explicitly configured --active-sequences=1 and --max-sessions=2. Its max_batch_requests=1 is the intended original R1 pressure regression, not a quota fallback or split. This CLI reports insufficient batch quota as an error; it does not automatically split batches.",
                         "No throughput is inferred from these diagnostic single runs."],
              "activity": {"CXX_builds": 0, "GPU_runs": 0, "product_edits": 0},
              "freeze_note": "Final requested runs included. Report/script frozen after host-only checks; raw inputs/results/tensors are unchanged."}
    output = D / "review/runtime-numeric-review.json"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(output.relative_to(ROOT)), "runs": {k: {f: v.get(f) for f in
                     ["graph_calls", "graph_participations", "graph_tokens", "restore_graph_calls"]} for k, v in reports.items()},
                      "restore_pairs": len(restore_metrics), "changed_restore_argmax": result["changed_restore_argmax"]}, indent=2))


if __name__ == "__main__":
    main()
