"""Freeze finite source, receipts and raw data, without copying SDKs/models."""
from pathlib import Path
import hashlib,json,zipfile,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[1]
P=R/'docs/evidence/performance';stem='qwen-cli-batch-2026-10-22'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    p=p.resolve();h=hashlib.sha256()
    with p.open('rb')as f:
        for chunk in iter(lambda:f.read(8<<20),b''):h.update(chunk)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
required=[D/'review/runtime-numeric-review.json',D/'review/performance-review.json',D/'limits-explicit/result.json']
assert all(p.is_file()for p in required)
qwen=read(D/'qwen-ready-attempt3.json');peer=read(D/'peer-ready.json');unit=read(D/'prefix-tests-ready-attempt1.json')
assert all(ident(Path(x['image']['path']))==x['image']for x in (qwen,peer,unit))
assert ident(R/'tools/qwen35_text/main.cc')==qwen['source']
timing=read(D/'performance/timing/summary.json');memory=read(D/'performance/memory/summary.json')
assert timing['processes']==9 and memory['processes']==3 and timing['batch_episode_order_equal'] and not any(timing['greedy_id_differences'].values())
source_paths=[R/x for x in ('tools/qwen35_text/main.cc','tools/qwen35_text/batch_schedule.h','tools/qwen35_text/session_state.h','tools/qwen35_text/session_schedule.h','tools/qwen35_text/prefix_cache.h','tools/qwen35_text/README.md','tests/tools/qwen_prefix_cache_test.cc')]
paths=list(source_paths)
F=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
for folder in (F/'multi-session-isolation-2026-10-21/inputs',F/'multiturn/inputs/long',R/'.scratch/qwen-prefix-20261021/inputs'):
    paths.extend(p for p in folder.rglob('*')if p.is_file()and p.suffix in('.txt','.ids','.json'))
paths.append(R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp')
paths.append(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/converted-model-audit.json')
for p in D.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(D)
    if any(x in ('__pycache__','tmp')for x in rel.parts):continue
    # Original source, recorded commands, logs and actual tensor data are the
    # evidence. Retained object/DLL caches and rebuildable images/maps stay local.
    if p.suffix.lower()in('.exe','.obj','.dll','.map','.pdb','.lib','.exp'):continue
    if rel.parts[0]in('archive','published'):continue
    paths.append(p)
paths=sorted(set(paths),key=lambda p:p.relative_to(R).as_posix())
files=[dict(**ident(p),entry=p.relative_to(R).as_posix())for p in paths]
archives=[];current=None;z=None
try:
    for p,row in zip(paths,files):
        if z is None or z.fp.tell()>90_000_000:
            if z is not None:z.close();archives.append(ident(current))
            current=P/f'{stem}.data.part{len(archives)+1:02}.zip'
            assert not current.exists()
            z=zipfile.ZipFile(current,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)
        z.write(p,row['entry'])
    if z is not None:z.close();z=None;archives.append(ident(current))
finally:
    if z is not None:z.close()
entries={}
for archive in archives:
    assert archive['bytes']<100*2**20
    with zipfile.ZipFile(archive['path'])as z:
        assert z.testzip()is None
        for item in z.infolist():
            assert item.filename not in entries
            data=z.read(item.filename);entries[item.filename]=(len(data),hashlib.sha256(data).hexdigest())
assert len(entries)==len(files)and all(entries[x['entry']]==(x['bytes'],x['sha256'])for x in files)
manifest=dict(schema='hyle.qwen-cli-batch-window.v1',date='2026-10-22',status='CLI equal-T real batching and this finite CUDA window completed; broad goal remains incomplete',
    sources=[ident(p)for p in source_paths],archives=archives,archive_layout='Each volume is an ordinary ZIP below100MiB. Extract every volume into one directory. repo-relative entries preserve source, logs, raw vectors and receipts; no model/SDK copies.',archive_files=files,
    hyle_final=qwen,peer=peer,host_test=unit,
    implementation=['Private consumer turn/cohort waves; at most one dependency-ready call per Session. Resolve all previous-prefix lookups before stable equal actualT/kind buckets; zero-row full hits do not submit Graph. No padding.',
      'One original Model.prepare/submit/finish batch and one Invocation/Completion per bucket. All independent KV/conv/GDN and decisions published together via the previously verified core episode.',
      'CachePlan receives realR; N committed versions plus at mostR candidate state blocks/COW tails. Before commit requireL+R-D<=N whereD counts truly disappearing distinct selected bases after all external Session/directory owners. Recompute after every actual prefix eviction.',
      'Cold wave/suffix shape domains and conservative per-slot replay use bounds precede carriers. Single off mode preserves exact ordered slot use/preparation. Only actual selected children/slots initialized.',
      'Global Graph calls count batches once. PerSession graph_participations are separate. Physical batches, logical dispatch and overlapping wave walls are reported independently.',
      'Eviction rebuild recomputes original actual input chunks, never resamples/changes already returned history. New realhead.next_id is not overwritten. Imported history rebuild creates new ReplayHistory with real recomputed nexts and leaves old shared history untouched. Exact snapshot reuse and recompute are different contracts.'],
    correctness=dict(host_tests=8,ordinary_B2=dict(graph_calls=26,graph_participations=36,input_tokens=239),prefix_B2=dict(logical_tokens=813,actual_tokens=297,graph_calls=10,prefix_hits=4,full_hits_zero_graph=2),pressure_B2=dict(new_tokens=239,recompute_tokens=185,recompute_calls=18,all_graph_calls=44),R1_regression=dict(single_byte_identical_vectors=18,prefix_pressure_byte_identical_vectors=30),
      cross_B_recompute=dict(changed_historical_greedy=dict(session='carol',call=2,previous=5548,actual=958),hidden_max_abs=0.5,hidden_min_cosine=0.9999225,logits_max_abs=0.15625,logits_min_cosine=0.9999254,description='Rounded descriptive minima; full metrics/raw vectors archived. No cross-B error threshold or model quality acceptance.'),limits=read(D/'limits-explicit/result.json')),
    performance=dict(timing=timing,memory=memory,workload=read(D/'performance/timing/inputs.json'),comparison='Two independent copies of retained fixed-ID three-round journey;C1024/N2/prefixoff/no eviction;1728actualinputs,198decisions,1536P/192D. Same-source HyleR1 versus HyleB2 and fixed d9e03 llamaB2. Three fresh processes per timing arm, separately one memory process each. This is aggregate two-session throughput, not single-user improvement.'),
    comparison_limits=read(D/'review/performance-review.json')['source_and_math'],
    reviews=[ident(p)for p in required[:2]]+[ident(D/'review/recompute-contract.json'),ident(D/'review/main-integration-review.json')],
    incidents=['Initial host compile failed/WX C4456(local shadow); fixed named restored_members before native runs.',
      'First pressure run truly failed the old identical-greedy recompute assertion. Kept logs and source. New contract is explicitly recompute of actual tokens, matching mature engine distinction; real5548->958 remains reported and finite-vector metrics do not become quality acceptance.',
      'Initial five-Session prefix test had N5 directory pressure and no complete hit. Six-session reference manifest retains enough real committed budget; measured two complete hits, no fabricated outcome.',
      'First limits checker incorrectly expected rejection for active=auto. Native completed and legitimately reducedN/R to1/1; its terminal exit code was not retained and is not called a passed process receipt. Separate explicitR2 test records exit1 before CUDA/weights with budget one byte short.'],
    previous_evidence=['qwen-multisequence-2026-10-22.json (R2 native cancel/retire/retry not rerun in this CLI-only change)','paged-frame-reframe-2026-10-21.json','qwen-shared-execution-2026-10-21.json (previous separate single/serial-prefix performance workloads)'],
    not_completed=['Full model quality acceptance across batch/precision/recompute','Actual GPU attribution of remainingB2 decode gap; no new kernel count/profile claim','Apple/Vulkan new native paged paths and full consumers; full selected-model/quant coverage','Real MTP weights/draft/verify/accept/reject consumer and matched peer','Image encoder/projector-to-text chain','Broad architecture and three-OS goal completion'])
save(P/f'{stem}.json',manifest)
save(D/'published.json',dict(manifest=ident(P/f'{stem}.json'),archives=archives,archive_verified_entries=len(entries),archived_uncompressed_bytes=sum(x['bytes']for x in files),sources_current_and_image_matched=True))
print('PUBLISHED',len(files),'entries',sum(x['bytes']for x in archives),'compressed bytes',len(archives),'volumes')
