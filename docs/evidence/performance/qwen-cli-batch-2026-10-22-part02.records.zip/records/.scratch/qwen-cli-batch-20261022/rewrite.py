from pathlib import Path
R=Path(__file__).resolve().parents[2]
D=Path(__file__).resolve().parent
p=R/'tools/qwen35_text/main.cc'
s=(D/'before/tools/qwen35_text/main.cc').read_text()
s=s.replace('#include "prefix_cache.h"','#include "prefix_cache.h"\n#include "batch_schedule.h"')
at=s.index('  std::shared_ptr<Session> create_session(')
s=s[:at]+'''  // Finite wave/suffix plans can count many possible restores without
  // materializing repeated host call tapes or execution carriers.
  void plan_replay_uses(std::size_t tokens, std::size_t requests, std::size_t count) {
    if (!phases.empty() || !probe_phases.empty() || carrier_borrowed)
      throw std::runtime_error("execution use plans must precede carrier preparation");
    if (!families.contains(requests) ||
        std::find(families.at(requests)->chunks.begin(), families.at(requests)->chunks.end(), tokens) == families.at(requests)->chunks.end())
      throw std::runtime_error("execution use shape is outside the shared finite family");
    for (auto &uses : planned_slot_uses[{requests, tokens}]) uses = cache::add(uses, count);
  }

'''+s[at:]
a=s.index('      for (std::size_t s = 0; s < schedules.size(); ++s) {',s.index('    if (prefix_enabled) {',s.index('// Immutable host token owners')))
b=s.index('    const auto max_query_rows',a)
s=s[:a]+'    }\n'+s[b:]
a=s.index('    auto selected_cache = qwen35::cache::plan(')
b=s.index('    const auto model_start',a)
s=s[:a]+'''    const auto input_sessions = scheduled ? schedules.size() : std::size_t{1};
    const auto requested_active = (std::min)(active_sequences, input_sessions);
    const auto plan_for = [&](std::size_t residents) {
      return qwen35::cache::plan(capacity, residents, max_query_rows, recurrent_payload,
          active_sequences == 0 ? residents : requested_active);
    };
    const auto minimum_residents = active_sequences == 0 ? std::size_t{1} : requested_active;
    auto selected_cache = plan_for(cached_slots);
    if (cache_bytes == 0) cache_bytes = selected_cache.backing_bytes;
    else if (selected_cache.backing_bytes > cache_bytes) {
      const auto minimum = plan_for(minimum_residents);
      if (minimum.backing_bytes > cache_bytes)
        throw std::runtime_error("--cache-bytes cannot hold the configured active sequences: requires " +
            std::to_string(minimum.backing_bytes) + " shared KV/RNN backing bytes");
      std::size_t low = minimum_residents, high = cached_slots;
      while (low < high) {
        const auto middle = low + (high - low + 1) / 2;
        if (plan_for(middle).backing_bytes <= cache_bytes) low = middle;
        else high = middle - 1;
      }
      selected_cache = plan_for(low);
    }
    const auto cache_slots = selected_cache.resident_sessions;
    const auto active_slots = selected_cache.active_sequences;
'''+s[b:]
s=s.replace('    model.prepare_family(planned_chunks);\n    if (!layer0_probe.empty()) model.prepare_family(planned_chunks, true);\n    if (!scheduled) model.plan_execution(planned_chunks);\n','')
s=s.replace('      model.plan_execution(run.chunks, prefix_enabled || multiple_schedules);\n','')
a=s.index('    if (prefix_enabled) {\n      // A hit can replace')
b=s.index('    std::vector<std::size_t> evicted_sessions;',a)
s=s[:a]+(D/'cold_plan.inc').read_text()+s[b:]
a=s.index('    const auto make_advance_room = ')
b=s.index('    const auto ensure_resident = ',a)
s=s[:a]+(D/'batch_quota.inc').read_text()+s[b:]
s=s.replace('          model.prepare_execution(run.chunks, multiple_schedules);\n','')
s=s.replace('            const auto next = model.evaluate(*run.session, ids, name, {}, false, nullptr, nullptr,',
'''            const auto restore_start = qwen35::Clock::now();
            make_advance_room(*run.session);
            const auto next = model.evaluate(*run.session, ids, name, {}, false, nullptr, nullptr,''',1)
s=s.replace('            ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();',
'''            ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();
            const std::array members{s};
            record_batch(phase.kind, ids.size(), members, true,
                std::chrono::duration<double>(qwen35::Clock::now() - restore_start).count());''',1)
marker='    if (!prefix_enabled) for (std::size_t s = 0;'
at=s.index(marker)
s=s[:at]+'''    if (scheduled && !prefix_enabled) {
      // Exact nominal buckets are known before admission. Suffix alternatives
      // stay cold metadata until an actual prefix hit selects one.
      for (const auto &wave : waves) {
        std::vector<std::size_t> rows;
        rows.reserve(wave.calls.size());
        for (const auto &call : wave.calls) rows.push_back(call.query_rows);
        for (const auto &bucket : qwen35::benchmark::bucket_schedule_wave(wave, rows)) {
          const std::array chunks{bucket.query_rows};
          model.prepare_execution(chunks, multiple_schedules, bucket.calls.size());
        }
      }
      if (schedules.size() > cache_slots) for (const auto &run : runs)
        model.prepare_execution(run.chunks, true);
    }
'''+s[at:]
a=s.index('      for (std::size_t d = 0; d < dispatch.size(); ++d) {')
b=s.index('      for (std::size_t s = 0; s < runs.size(); ++s) {',a)
s=s[:a]+(D/'runtime.inc').read_text()+s[b:]
s=s.replace('actual_graph_calls = 0, actual_graph_tokens = 0;','graph_participations = 0, actual_graph_tokens = 0;',1)
s=s.replace('run.actual_graph_calls','run.graph_participations')
s=s.replace('<< ",\\\"actual_graph_tokens\\\":" << run.actual_graph_tokens',
            '<< ",\\\"graph_input_tokens\\\":" << run.actual_graph_tokens')
s=s.replace('<< ",\\\"actual_graph_calls\\\":" << run.graph_participations','<< ",\\\"graph_participations\\\":" << run.graph_participations')
# Global submissions are counted once per real batch, never once per member.
s=s.replace('std::size_t processed = 0, actual_graph_calls = 0, actual_graph_tokens = 0;',
            'std::size_t processed = 0, graph_participations = 0;')
s=s.replace('actual_graph_calls += run.graph_participations; actual_graph_tokens += run.actual_graph_tokens;',
            'graph_participations += run.graph_participations;')
s=s.replace('turn_round_robin_serial','equal_T_batched')
s=s.replace('<< ",\\\"actual_graph_calls\\\":" << actual_graph_calls << ",\\\"actual_graph_tokens\\\":" << actual_graph_tokens',
            '<< ",\\\"graph_participations\\\":" << graph_participations')
s=s.replace('\\\"dispatch_session_ids\\\"','\\\"logical_dispatch_session_ids\\\"')
# The execution metrics lambda is shared only by the top-level report.
at=s.index('      const auto print_result = ')
s=s[:at]+(D/'metrics.inc').read_text()+s[at:]
marker='        std::cout << ",\\\"phases\\\":[";'
s=s.replace(marker,'        if (!multiple_schedules) print_execution();\n'+marker,1)
marker='        std::cout << "],\\\"sessions\\\":[";'
s=s.replace(marker,'        std::cout << \']\';\n        print_execution();\n        std::cout << ",\\\"sessions\\\":[";',1)
p.write_text(s)
print('rewritten',p,len(s))
