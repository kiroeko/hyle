from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
D=Path(__file__).resolve().parent;R=D.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
p=argparse.ArgumentParser();p.add_argument('case',choices=('host','batch','prefix','pressure','budget-pressure','prefix-pressure','r1'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--ready-attempt',type=int,default=1);a=p.parse_args()
mode='prefix-tests'if a.case=='host'else'qwen'
ready_path=D/f'{mode}-ready-attempt{a.ready_attempt}.json';ready=read(ready_path)
assert ident(Path(ready['image']['path']))==ready['image']
out=D/f'{a.case}-run{a.attempt}';out.mkdir(exist_ok=False)
command=[ready['image']['path']]
I=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21/inputs'
if a.case=='host':command+=['--gtest_filter=Qwen*','--gtest_output=xml:'+str(out/'gtest.xml')]
else:
    command+=['--inputs',str(R/'.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/128-prefill/inputs')]
    if a.case=='r1':command+=['--schedule',str(I/'alice/schedule.txt')]
    elif a.case=='prefix-pressure':command+=['--session-schedules',str(R/'.scratch/qwen-prefix-20261021/inputs/pressure.txt'),'--max-sessions','2','--active-sequences','1','--prefix-cache','auto']
    elif a.case=='prefix':
        manifest=D/'prefix-sessions.txt'
        manifest.write_text(''.join(name+' '+str(R/'.scratch/qwen-prefix-20261021/inputs'/directory/'schedule.txt')+'\n'for name,directory in [('seed','seed'),('changed','changed'),('A','branch_a'),('B','branch_b'),('full','full_hit'),('changed_hit','changed')]))
        command+=['--session-schedules',str(manifest),'--max-sessions','8','--active-sequences','2','--prefix-cache','auto']
    else:
        command+=['--session-schedules',str(I/'sessions4.txt'),'--max-sessions','2'if a.case=='pressure'else'4','--active-sequences','auto'if a.case=='budget-pressure'else'2','--prefix-cache','off']
        if a.case=='budget-pressure':command+=['--cache-bytes','84836400']
    command+=['--capacity','256','--progress','direct','--replay','auto','--trace',str(out/'trace'),'--trace-level','decisions']
env=os.environ.copy();env['PATH']=read(ready['runtime_environment']['path'])['PATH']
record=dict(command=command,image=ready['image'],ready=ident(ready_path),cwd=str(R),throughput_evidence=False,started_unix_ns=time.time_ns())
save(out/'command.json',record)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    process=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
    record['pid']=process.pid
    try:record['exit']=process.wait(timeout=180)
    except subprocess.TimeoutExpired:record['timeout']=True;process.kill();record['exit']=process.wait()
record['finished_unix_ns']=time.time_ns();save(out/'result.json',record)
print(a.case,'exit',record['exit'],flush=True)
if record['exit']:print((out/'stderr.log').read_text(encoding='utf-8-sig')[-8000:])
else:
    stdout=(out/'stdout.log').read_text(encoding='utf-8-sig')
    if a.case=='host':print(stdout)
    else:
        value=json.loads(stdout,object_pairs_hook=lambda pairs:dict(pairs)if len(dict(pairs))==len(pairs)else (_ for _ in ()).throw(RuntimeError('duplicate JSON key')))
        save(out/'output.json',value)
        print({k:value[k]for k in ('actual_graph_calls','actual_graph_tokens','max_batch_requests','prefix_hits','prefix_full_hits','reused_tokens')if k in value})
assert record['exit']==0 and not record.get('timeout'),out
