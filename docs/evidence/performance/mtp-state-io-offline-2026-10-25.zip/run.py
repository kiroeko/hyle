"""Capture only the offline Python result; never launches a native consumer."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

work = Path(__file__).resolve().parent
root = work.parents[1]
command = [sys.executable, str(work / 'simulate.py')]
started = datetime.now(timezone.utc).isoformat()
clock = time.perf_counter()
result = subprocess.run(command, cwd=root, capture_output=True, timeout=30, check=False)
seconds = time.perf_counter() - clock
(work / 'stdout.log').write_bytes(result.stdout)
(work / 'stderr.log').write_bytes(result.stderr)
record = dict(command=command, cwd=str(root), started_utc=started,
              seconds=seconds, exit_code=result.returncode, native_processes=0,
              GPU_work=0, downloads=0, canonical_edits=0)
(work / 'command.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
assert result.returncode == 0, result.stderr.decode(errors='replace')
summary = json.loads((work / 'summary.json').read_bytes())
assert json.loads(result.stdout) == summary
files = []
for path in sorted(work.iterdir()):
    if path.is_file() and path.name != 'output-pins.json':
        raw = path.read_bytes()
        files.append(dict(path=path.relative_to(root).as_posix(), bytes=len(raw),
                          sha256=hashlib.sha256(raw).hexdigest()))
(work / 'output-pins.json').write_text(json.dumps(dict(files=files), indent=2) + '\n',
                                     encoding='utf-8', newline='\n')
print(json.dumps(dict(exit_code=result.returncode, seconds=seconds,
    original=[summary['original']['records'], summary['original']['hits']],
    gdn_only=[summary['gdn_io_offset_only']['records'], summary['gdn_io_offset_only']['hits']],
    gdn_and_carry=[summary['gdn_and_carry_io_offset_only']['records'], summary['gdn_and_carry_io_offset_only']['hits']],
    summary_sha256=hashlib.sha256((work / 'summary.json').read_bytes()).hexdigest())))
