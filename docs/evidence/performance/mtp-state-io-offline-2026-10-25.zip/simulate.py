"""Exact, offline binding-key counterfactual. No native work or model loading."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
INPUT = ROOT / '.scratch/mtp-complete-binding-diff-20261025/records.json'
FROZEN = ROOT / '.scratch/mtp-finish-phase-20261025/source/engine/models/qwen35/main.cc'
CURRENT = ROOT / 'engine/models/qwen35/main.cc'
GEOMETRY = ROOT / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
PINS = ROOT / '.scratch/mtp-finish-phase-20261025/compile/source-pins.json'
READY = ROOT / '.scratch/mtp-complete-binding-diff-20261025/ready.json'
HELPER = ROOT / '.scratch/mtp-complete-binding-diff-20261025/binding_diff.inc'


def pin(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def save(name, value):
    (WORK / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def anchor(path, text):
    lines = path.read_text(encoding='utf-8').splitlines()
    rows = [i + 1 for i, line in enumerate(lines) if text in line]
    assert len(rows) == 1, (path, text, rows)
    return dict(path=path.relative_to(ROOT).as_posix(), line=rows[0], text=text)


assert pin(INPUT)['sha256'] == '40b823e7a1b9490c817785074d0d0ca48559f8b0254d150101a8ce2951317ba8'
frozen_pin = pin(FROZEN)
frozen_compile_pins = json.loads(PINS.read_bytes())
assert any(p['sha256'] == frozen_pin['sha256'] and p['bytes'] == frozen_pin['bytes']
           and p['path'].endswith('source\\engine\\models\\qwen35\\main.cc')
           for p in frozen_compile_pins)
assert frozen_pin['sha256'] == '71c9e0b8f06d1f1cf43b20374d2f53e835d4a992635db971c922dd19280d6494'
ready = json.loads(READY.read_bytes())
assert any(p['path'].endswith('mtp-finish-phase-20261025\\compile\\unit.obj')
           and p['sha256'] == '35a38e9b82d434102eca6e877dc16a0d7c53e805f0ad7ae77f5144f4a3051ca2'
           for p in ready['retained_link_inputs'])
geometry_line = GEOMETRY.read_text(encoding='utf-8').splitlines()[2]
assert geometry_line.startswith('geometry\t2048\t6144\t248320\t8\t2\t256\t256\t64\t16\t16\t128\t128\t4\t')
assert geometry_line.endswith('"GGGAGGGAGGGAGGGAGGGAGGGA"')
gdn_layers = [i for i, kind in enumerate('GGGAGGGAGGGAGGGAGGGAGGGA') if kind == 'G']

data = json.loads(INPUT.read_bytes())
events = data['events']
event_by_id = {e['i']: e for e in events}
groups = {e['saved']: (e['inv'], e['plan'], e['begin'], e['count'])
          for e in events if e['inv'] and e['saved'] and e['begin'] > 0}
assert len(groups) == 2 and {g[2:] for g in groups.values()} == {(55, 1269), (57, 1269)}
widths = {e['saved']: e['expected_ports'] for e in events if e['kind'] == 3 and e['saved'] in groups}
assert set(widths) == set(groups) and set(widths.values()) == {2031}
ports_by_event = defaultdict(dict)
metadata = defaultdict(dict)
for p in data['ports']:
    assert p['flat'] not in ports_by_event[p['event']]
    ports_by_event[p['event']][p['flat']] = p
    saved = event_by_id[p['event']]['saved']
    if saved not in groups:
        continue
    immutable = {k: p[k] for k in ('flat', 'step', 'output', 'port', 'instance', 'value', 'domain', 'instance_roles')}
    immutable['description'] = {k: v for k, v in p['new'].items()
                                if k not in ('diff', 'resource', 'handle', 'offset')}
    if p['flat'] in metadata[saved]:
        assert metadata[saved][p['flat']] == immutable
    metadata[saved][p['flat']] = immutable

# These are actual external StatePorts, not shape-matched temporary values:
# instance_roles 1/2 are compiler kExternalInput/kExternalOutput. The frozen
# non-diagnostic R1 T2 family publishes exactly 2 histories, 2 recurrent states,
# and 2 chronological carry rows per target layer/request. Only changed ports
# were dumped; unchanged ports are deliberately not inferred or normalized.
source_evidence = {
    'frozen': [
        anchor(FROZEN, 'struct StateSchema final'),
        anchor(FROZEN, 'layer.history = dense(Type::kBFloat16'),
        anchor(FROZEN, 'layer.recurrent = dense(Type::kFloat32'),
        anchor(FROZEN, 'struct StatePorts final'),
        anchor(FROZEN, 'const std::size_t prefix_rows = role == GraphRole::kVerify'),
        anchor(FROZEN, 'sequence.history = r.input(state_schema[i].history)'),
        anchor(FROZEN, 'sequence.recurrent = r.input(state_schema[i].recurrent)'),
        anchor(FROZEN, 'sequence.history_prefix.back() = r.copy'),
        anchor(FROZEN, 'sequence.history_prefix[row] = r.copy(selected_history)'),
        anchor(FROZEN, 'ports.sequences[request].recurrent_prefix[row] = r.copy'),
        anchor(FROZEN, 'r.publish(sequence.history_prefix[row - 1]); r.publish(sequence.recurrent_prefix[row - 1])'),
        anchor(FROZEN, 'definition.carry_ports[request][row] = carry'),
        anchor(FROZEN, 'r.publish(carry); definition.state_resource_ports.push_back(carry)'),
        anchor(FROZEN, 'check(run.bind(ports.history, descriptions.history, step.members[j].base->state[i].history))'),
        anchor(FROZEN, 'check(run.bind(ports.recurrent, descriptions.recurrent, step.members[j].base->state[i].recurrent))'),
        anchor(FROZEN, 'const auto bind_state = [&](V port, c::LeasePool &pool)'),
        anchor(FROZEN, 'step.members[j].next->state[i].history = retain_state_storage'),
        anchor(FROZEN, 'step.members[j].next->state[i].recurrent = retain_state_storage'),
        anchor(FROZEN, 'member.next->carry_hidden = retain_state_storage'),
        anchor(FROZEN, 'member.next->prior_hidden = retain_state_storage'),
    ],
    'current_correspondence_only_not_logged_graph_ids': [
        anchor(CURRENT, 'struct StatePorts final'),
        anchor(CURRENT, 'sequence.history = r.input(state_schema[i].history)'),
        anchor(CURRENT, 'sequence.history_prefix.back() = r.copy'),
        anchor(CURRENT, 'ports.sequences[request].recurrent_prefix[row] = r.copy'),
        anchor(CURRENT, 'r.publish(sequence.history_prefix[row - 1]); r.publish(sequence.recurrent_prefix[row - 1])'),
        anchor(CURRENT, 'definition.carry_ports[request][row] = carry'),
        anchor(CURRENT, 'const auto bind_state = [&](V port, c::LeasePool &pool)'),
        anchor(CURRENT, 'step.members[j].next->state[i].history = retain_state_storage'),
        anchor(CURRENT, 'member.next->carry_hidden = retain_state_storage'),
    ],
    'instrumentation': [
        anchor(HELPER, 'plan.instance_storage[instance], plan.instance_roles[instance], flags, old_value, new_value'),
        anchor(HELPER, 'if (!flags) { ++event->equal; ++flat; return; }'),
    ],
    'role_bits': [
        anchor(ROOT / 'src/graph/plan_state.h', 'kExternalInput = 1u << 0'),
        anchor(ROOT / 'src/graph/plan_state.h', 'kExternalOutput = 1u << 1'),
    ],
}

manifest = []
state_sets = {}
gdn_sets = {}
for saved, group in sorted(groups.items(), key=lambda pair: pair[1][2]):
    rows = sorted(metadata[saved].values(), key=lambda p: p['flat'])
    input_history = [p for p in rows if p['description']['dims'] == [1, 3, 6144] and not p['output']]
    assert len(input_history) == len(gdn_layers) == 18
    # Graph ValueIds are assigned in source creation order, and each target
    # layer is built serially. These boundary input ids partition subsequent
    # published state results up to the following layer's boundary inputs.
    assert [p['value'] for p in input_history] == sorted(p['value'] for p in input_history)
    layer_for_flat = {}
    for index, h in enumerate(input_history):
        lower = h['value']
        upper = input_history[index + 1]['value'] if index + 1 < 18 else 2500
        layer_rows = [p for p in rows if lower <= p['value'] < upper and
                      p['description']['dims'] in ([1, 3, 6144], [1, 16, 128, 128])]
        assert len(layer_rows) == (6 if group[2] == 57 else 4)
        assert len([p for p in layer_rows if not p['output']]) == 2
        for p in layer_rows:
            layer_for_flat[p['flat']] = gdn_layers[index]
    state_sets[saved], gdn_sets[saved] = set(), set()
    for p in rows:
        desc = p['description']
        assert p['domain'] == 0 and p['instance_roles'] == (2 if p['output'] else 1)
        assert desc['valid'] == 1 and desc['format'] == 0 and desc['required_known'] == 1
        role, layer, prefix = None, None, None
        shape = desc['dims']
        if shape in ([1, 3, 6144], [1, 16, 128, 128]):
            is_history = shape == [1, 3, 6144]
            assert desc['type'] == (5 if is_history else 6)
            assert desc['required_bytes'] == desc['size'] == (36864 if is_history else 1048576)
            layer = layer_for_flat[p['flat']]
            role = ('history' if is_history else 'recurrent') + ('_prefix_output' if p['output'] else '_snapshot_input')
            if p['output']:
                # Source creates final history first, then the earlier copy;
                # recurrent copies are created in chronological order. In the
                # catchup family only the final outputs actually changed.
                same = sorted(q['value'] for q in rows if q['output'] and
                              q['description']['dims'] == shape and layer_for_flat.get(q['flat']) == layer)
                if group[2] == 57:
                    assert len(same) == 2
                    prefix = (2 - same.index(p['value'])) if is_history else (1 + same.index(p['value']))
                else:
                    assert len(same) == 1
                    # This dump omits unchanged ports. Do not infer whether
                    # the sole changed catchup output is chronological row 1
                    # or 2 solely from its shape/position. Both are genuine
                    # independent state outputs under the original contract.
                    prefix = None
            gdn_sets[saved].add(p['flat'])
        elif shape == [1, 2048]:
            # `last` is [2,2048] in these exact verifier families. The only
            # non-diagnostic external [1,2048] target outputs are carry rows.
            assert p['output'] == 1 and desc['type'] == 5 and desc['required_bytes'] == desc['size'] == 4096
            same = sorted(q['value'] for q in rows if q['description']['dims'] == [1, 2048])
            assert len(same) == 2
            role, prefix = 'carry_prefix_output', 1 + same.index(p['value'])
        else:
            raise AssertionError(('unmapped changing port', group, p))
        state_sets[saved].add(p['flat'])
        manifest.append(dict(range_begin=group[2], range_steps=group[3], saved=saved,
                             **p, role=role, target_layer=layer, accepted_input_prefix=prefix,
                             normalized_fields=['offset'],
                             evidence='Original compiled Family external state IO and independent publication boundary; not internal workspace'))
    assert len(state_sets[saved]) == (110 if group[2] == 57 else 74)

# Union-find reconstruction is the previous exact full-key method. Unknown
# literal tuples stay symbolic: a different root without two known tuples
# stops the simulation; it is never optimistically treated as a hit/miss.
parents, values, physical_values, physical_ids = [], [], [], {}


def fresh():
    nodes = list(range(len(parents), len(parents) + 2031))
    parents.extend(nodes)
    values.extend([None] * 2031)
    return nodes


def root(node):
    while parents[node] != node:
        parents[node] = parents[parents[node]]
        node = parents[node]
    return node


def physical(desc):
    desc = {k: v for k, v in desc.items() if k != 'diff'}
    key = json.dumps(desc, sort_keys=True)
    if key not in physical_ids:
        physical_ids[key] = len(physical_values)
        physical_values.append(desc)
    return physical_ids[key]


def assign(node, literal):
    node = root(node)
    assert values[node] is None or values[node] == literal
    values[node] = literal


def equal(a, b):
    a, b = root(a), root(b)
    if a == b:
        return
    assert values[a] is None or values[b] is None or values[a] == values[b]
    parents[b] = a
    if values[a] is None:
        values[a] = values[b]


def equate(a, b):
    for x, y in zip(a, b):
        equal(x, y)


live, active, current, timeline = {}, {}, {}, []
for event in events:
    saved, kind = event['saved'], event['kind']
    if saved not in groups:
        continue
    live.setdefault(saved, [None, None])
    if kind == 6:
        live[saved] = [None, None]
        active.pop(saved, None)
        timeline.append(('clear', saved, event['seq'], None, event['i']))
    elif kind in (0, 5):
        key = saved, event['seq']
        assert key not in current
        current[key] = fresh()
        timeline.append(('query', saved, event['seq'], current[key], event['i']))
        if kind == 5:
            equate(current[key], active[saved])
    elif kind == 3:
        previous = live[saved][event['variant']]
        assert previous is not None and event['examined'] == event['expected_ports'] == event['cached_ports'] == 2031
        assert event['equal'] + event['changed'] == 2031 and not event['missing_old'] and not event['extra_old']
        changed = ports_by_event[event['i']]
        assert len(changed) == event['changed']
        for flat, (a, b) in enumerate(zip(previous, current[saved, event['seq']])):
            if flat in changed:
                p = changed[flat]
                assert p['flags'] == 16
                assert {k: v for k, v in p['old'].items() if k not in ('diff', 'offset')} == {
                    k: v for k, v in p['new'].items() if k not in ('diff', 'offset')}
                assign(a, physical(p['old']))
                assign(b, physical(p['new']))
            else:
                equal(a, b)
    elif kind == 4:
        equate(current[saved, event['seq']], live[saved][event['variant']])
        active[saved] = live[saved][event['variant']]
    elif kind == 9:
        live[saved][event['variant']] = current[saved, event['seq']]
        active[saved] = current[saved, event['seq']]


def compare(a, b, normalized):
    unknown = []
    changed = []
    for flat, (x, y) in enumerate(zip(a, b)):
        x, y = root(x), root(y)
        if x == y:
            continue
        if values[x] is None or values[y] is None:
            unknown.append(flat)
            continue
        vx, vy = physical_values[values[x]], physical_values[values[y]]
        if flat in normalized:
            # Retain the entire descriptor/resource/native handle/span; only
            # the named external IO boundary's offset is normalized.
            vx = {k: v for k, v in vx.items() if k != 'offset'}
            vy = {k: v for k, v in vy.items() if k != 'offset'}
        if vx != vy:
            changed.append(flat)
    return (False if changed else None if unknown else True), changed, unknown


def simulate(normalized):
    cache, clock, result, clears = {}, 0, [], []
    for kind, saved, sequence, key, event_id in timeline:
        if kind == 'clear':
            cache.pop(saved, None)
            clears.append(dict(event=event_id, seq=sequence, range_begin=groups[saved][2]))
            continue
        clock += 1
        entries = cache.setdefault(saved, [None, None])
        comparisons, selected = [], None
        for index, entry in enumerate(entries):
            if entry is None:
                continue
            match, changed, unknown = compare(entry[0], key, normalized.get(saved, set()))
            comparisons.append(dict(variant=index, match=match, remaining_different_flats=changed,
                                    unknown_flats=unknown))
            if match is None:
                return dict(status='UNKNOWN_FULL_TUPLE_EQUALITY', stop_at=dict(seq=sequence, event=event_id),
                            completed_queries=len(result), rows=result, hard_clears=clears,
                            unknown_comparison=comparisons[-1])
            if match:
                selected = index
                break
        hit = selected is not None
        if not hit:
            selected = next((i for i, entry in enumerate(entries) if entry is None), None)
            if selected is None:
                selected = min(range(2), key=lambda i: entries[i][1])
        entries[selected] = key, clock
        result.append(dict(seq=sequence, event=event_id, range_begin=groups[saved][2],
                           hit=hit, selected=selected, comparisons=comparisons))
    return dict(status='EXACT_LOGGED_TUPLE_EQUALITY_SIMULATION', records=sum(not r['hit'] for r in result),
                hits=sum(r['hit'] for r in result), rows=result, hard_clears=clears)


base = simulate({})
actual = sorted((e['seq'], e['begin']) for e in events if e['kind'] == 9 and e['saved'] in groups)
base_records = sorted((r['seq'], r['range_begin']) for r in base['rows'] if not r['hit'])
assert base['status'] == 'EXACT_LOGGED_TUPLE_EQUALITY_SIMULATION'
assert (base['records'], base['hits']) == (15, 51) and actual == base_records

# Counterfactuals run only after original complete-key stream reproduces every
# actual body-record decision. All hard clears, both variants and other ports
# stay exactly as in the original stream; no changes to native qualification.
gdn_only = simulate(gdn_sets)
all_state = simulate(state_sets)
for result in (gdn_only, all_state):
    assert result['hard_clears'] == base['hard_clears']

inputs = [pin(p) for p in (INPUT, FROZEN, CURRENT, GEOMETRY, PINS, READY, HELPER,
          ROOT / 'src/graph/plan_state.h', ROOT / '.scratch/mtp-complete-binding-diff-20261025/proof-summary.json',
          ROOT / '.scratch/mtp-finish-phase-20261025/compile/command.json',
          ROOT / '.scratch/mtp-complete-binding-diff-20261025/run2/command.json',
          Path(__file__).resolve())]
save('inputs.json', dict(inputs=inputs, original_model_source_in_actual_app_dependency_pins=True,
                         reused_original_app_object_pin_in_actual_link=True, geometry_metadata=geometry_line))
save('state-ports.json', dict(status='SOURCE_BOUND_EXTERNAL_STATE_IO_MAPPING',
    scope='Only actual changed key positions; invariant positions need no normalization and are not invented.',
    original_value_ids_not_current_model_ids=True, body_groups=[dict(saved=saved, invocation=g[0], plan=g[1],
         range_begin=g[2], range_steps=g[3], complete_key_ports=2031,
         changing_state_ports=len(state_sets[saved]), changing_gdn_ports=len(gdn_sets[saved]),
         preserved_other_ports=2031-len(state_sets[saved])) for saved, g in sorted(groups.items())],
    source=source_evidence, ports=manifest,
    limits=['External role/descriptor plus serial layer/source creation/publication order identifies these actual boundary values; no cold graph was rebuilt.',
            'The dump contains metadata for changed cells only. The other 1921/1957 positions remain exact symbolic keys; no unrecorded ValueId is inferred.',
            'Only one history and one recurrent output per catchup target layer changed in this stream; its exact chronological prefix index is not established by the changed-only dump and remains null. The unchanged counterpart is not inferred or normalized.',
            'Original carry[0]/carry[1] use separate caller-owned leases; fixed work buffers would still need original accepted-prefix export/old-reader lifetime.']))


def compact(result):
    return {**{k: v for k, v in result.items() if k not in ('rows', 'hard_clears')},
            'hard_clear_events': len(result['hard_clears']),
            'hard_clear_boundaries': sorted({(c['seq'], c['range_begin']) for c in result['hard_clears']}),
            'record_set': [[r['seq'], r['range_begin']] for r in result['rows'] if not r['hit']]}


save('simulation.json', dict(original=base, gdn_io_offset_only=gdn_only,
                             gdn_and_carry_io_offset_only=all_state))
summary = dict(status='OFFLINE_ONLY_COMPLETED', original_record_set_exactly_reproduced=True,
               original=compact(base), gdn_io_offset_only=compact(gdn_only),
               gdn_and_carry_io_offset_only=compact(all_state),
               all_native_hard_clears_preserved=True, variants_per_range=2,
               normalized_field='offset only; descriptor/resource/native handle/span are never wildcarded',
               normalization_scope='Each named logical boundary gets its own invariant address token for equality; different ValueIds/prefixes are never merged or granted alias permission.',
               source_bound_candidates={'GDN_IO': 'actual external Snapshot history/recurrent inputs and independently published prefix outputs',
                                        'GDN_AND_CARRY_IO': 'GDN_IO plus two explicitly published immutable carry prefix rows'},
               remaining_ports_preserved={'begin57': 2031-len(state_sets[next(s for s,g in groups.items() if g[2] == 57)]),
                                          'begin55': 2031-len(state_sets[next(s for s,g in groups.items() if g[2] == 55)])},
               limits=['This fixes only the recorded binding-stream address dimension. It proves neither a legal implementation nor any throughput gain.',
                       'No buffer allocation/staging/copy, budget increase, native configuration/queue/arguments change, model run, GPU work or download was performed.',
                       'A realizable fixed-work boundary must preserve distinct chronological prefix outputs, immutable escaped old readers, expected-head publication, cancellation and true retirement.',
                       'Copy cost and added completion/dependency boundaries remain unmeasured; fewer offline records are not saved wall time.',
                       'The logged 2026-10-25 app is frozen and pinned. Current Model source is read only to confirm the state IO mechanism still exists, not to claim current graph ids/TPS.'])
save('summary.json', summary)
save('state-role-table.json', [dict(range_begin=g[2], layers=[dict(target_layer=layer,
    boundaries=[dict(role=p['role'], value=p['value'], flat=p['flat'], instance=p['instance'],
                     accepted_input_prefix=p['accepted_input_prefix']) for p in manifest
                if p['saved'] == saved and p['target_layer'] == layer]) for layer in gdn_layers],
    carry=[dict(role=p['role'], value=p['value'], flat=p['flat'],
                accepted_input_prefix=p['accepted_input_prefix']) for p in manifest
           if p['saved'] == saved and p['target_layer'] is None])
    for saved, g in sorted(groups.items(), key=lambda pair: pair[1][2])])
print(json.dumps(summary, indent=2))
