from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';attempt=sys.argv[1];assert attempt=='13'
numeric=ROOT/'evidence/correctness/inference-g04-g05-cuda-ce27-owned-conversion-numeric-rebind/receipt.json'
assert json.loads(numeric.read_text())['state']=='TERMINAL_PASS'
assert json.loads(numeric.read_text())['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8'
for name in ['inference-g04-g05-cuda-ce27-owned-conversion-source-device',
             'inference-g04-g05-cuda-ce27-static-sdk','inference-g04-g05-cuda-ce27-shared-sdk',
             'inference-g04-g05-cuda-ce27-host-asan','inference-g04-g05-cuda-ce27-host-ubsan',
             'inference-g04-g05-cuda-ce27-host-tsan']:
    receipt=json.loads((ROOT/'evidence/correctness'/name/'receipt.json').read_text())
    assert receipt['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8' and 'PASS' in receipt['verdict']
host=json.loads((ROOT/'evidence/correctness/inference-g04-g05-cuda-ce27-host-tsan/batch-summary.json').read_text())
assert host['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8' and host['verdict']=='PASS_THREE_HOST_FACETS_ONLY'
runtime=json.loads((ROOT/'evidence/architecture/inference-g04-g05-cuda-ce27-owned-conversion/runtime-receipt.json').read_text())
assert runtime['product_candidate']=='d41431f82a373ae400fb10e97418931031fa48e8' and runtime['verdict']=='PASS_RUNTIME_DISPATCH_AND24_ORACLES_ONLY'

assert subprocess.check_output(['git','ls-files',str(numeric.relative_to(ROOT))],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
OUT=BASE/'cuda-encoded-p1';OUT.mkdir(exist_ok=True);run=OUT/attempt;run.mkdir(exist_ok=False)
snapshot={'attempt':attempt,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'product_candidate':'d41431f82a373ae400fb10e97418931031fa48e8','numeric_receipt_sha256':hashlib.sha256(numeric.read_bytes()).hexdigest(),
 'contract_file_sha256':hashlib.sha256((ROOT/'bench/inference_resident_sdpa/cuda_encoded_p1/contract.json').read_bytes()).hexdigest()}
(run/'snapshot.json').write_text(json.dumps(snapshot,indent=2)+'\n')
command=['wsl','-e','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/ce27_cuda_p1_wsl.py',attempt]
started=time.monotonic()
with (run/'launch.log').open('wb') as stream:
 child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 record={'state':'OBSERVING','pid':child.pid,'snapshot':snapshot,'command':command}
 (run/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);code=child.wait()
job=run/'job.json';state=json.loads(job.read_text()) if job.is_file() else None
record.update(state='TERMINAL' if state and state['state'] in ('TERMINAL','TERMINAL_SETUP_FAIL') else 'OBSERVATION_ENDED_UNKNOWN',
 exit_code=code,elapsed_seconds=time.monotonic()-started,actual_job=state)
(run/'launch.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(code)
