"""Sixteen fresh intra-Hyle observations; root exclusively schedules run actions."""
from pathlib import Path
import copy, importlib.util, json, math, os, sys, time, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
OLD=R/'.scratch/inference-hidden-state-window-20261028/attempt1'
BUILD=R/'.scratch/inference-slot-cohort-refinement-20261028'
spec=importlib.util.spec_from_file_location('retained_hidden_window',OLD/'window.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
b=f.base;read,pin=b.read,b.identity
GROUPS=(('ordinary','timing'),('mtp','timing'),('ordinary','memory'),('mtp','memory'))
METRICS=('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','session_processed_tokens_per_second')


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


def exact(row):assert pin(row['path'])==row,row['path']


def prepare():
    assert not (W/'plan.json').exists(),'Preserve the original window plan'
    control_path=R/'.scratch/inference-hidden-indexed-refinement-20261028/ready.json'
    candidate_path=BUILD/'ready-model.json'
    control,candidate=read(control_path),read(candidate_path)
    assert control['image']['sha256'].startswith('b59fe852') and candidate['image']['sha256'].startswith('d4425096')
    for ready in (control,candidate):
        for field in ('image','inputs','recipe'):exact(ready[field])
    assert control['compiled']['snapshot']['sha256'].startswith('01c1b576')
    original_build=read(BUILD/'plan.json');compiled=read(BUILD/'compile/model/compiled.json')
    assert compiled['source']==candidate['source'] and compiled['process']['exit']==0 and candidate['process']['exit']==0
    control_rows,candidate_rows=read(control['inputs']['path']),read(candidate['inputs']['path'])
    assert len(control_rows)==len(candidate_rows)==226
    changes=[dict(control=a,candidate=c) for a,c in zip(control_rows,candidate_rows) if a!=c]
    assert len(changes)==2,'Only actual Model+arena objects differ'
    snapshots=original_build['snapshots']
    model=next(x['snapshot'] for x in snapshots if x['original']==compiled['source']);exact(model)
    snapshots=[x for x in snapshots if str(x['original']['path']).replace('/','\\').casefold().endswith(('engine\\models\\qwen35\\main.cc','engine\\inference\\slot_transactions.h','include\\hyle\\compute\\paged_arena.h'))]
    for row in snapshots:exact(row['snapshot'])
    runtime=original_build['bases']['cli']['runtime'];exact(runtime)
    binding=dict(control=dict(ready=pin(control_path),image=control['image'],source=control['compiled']['snapshot'],
            inputs=control['inputs'],recipe=control['recipe'],compiled_source=control['compiled']),
        candidate=dict(ready=pin(candidate_path),image=candidate['image'],source=model,inputs=candidate['inputs'],recipe=candidate['recipe'],
            compiled=pin(BUILD/'compile/model/compiled.json'),actual_dependencies=compiled['dependencies'],snapshots=snapshots),
        object_count_each=226,replacements=changes,runtime=runtime,protocol=pin(OLD/'window.py'),
        original_plan=pin(OLD/'single-timing-plan.json'),prompt=pin(Path(read(OLD/'single-timing-plan.json')['prompt']['path'])),
        input_manifest=pin(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'),
        scope='Only newly run control/candidate samples; retained old runner/flags are references, never old samples or functional-run TPS. No peer process.')
    save(W/'binding.json',binding)
    ordinal=0;plans=[]
    for role,mode in GROUPS:
        mapped='hyle_auto' if role=='ordinary' else 'hyle_mtp'
        source=read(OLD/('single-'+mode+'-plan.json'));template=next(x for x in source['commands'] if x['arm']==mapped)
        cfg=copy.deepcopy(source)
        for field in ('canonical_main','retained_plan','configuration'):cfg.pop(field,None)
        order=('control','candidate','candidate','control','control','candidate') if mode=='timing' else ('control','candidate')
        commands=[]
        for local,variant in enumerate(order,1):
            ordinal+=1;image=binding[variant]['image'];args=[image['path'],*template['command'][1:]]
            commands.append(dict(ordinal=local,window_ordinal=ordinal,variant=variant,role=role,arm=mapped,
                folder=str(W/(role+'-'+mode)/(f'{local:02d}-'+variant)),command=args,image=image,
                environment=runtime,ready=binding[variant]['ready']))
        cfg.update(mode=mode,commands=commands,arm_order=list(order),binding=pin(W/'binding.json'),script=pin(__file__),
            timing_processes=6 if mode=='timing' else 0,memory_processes=2 if mode=='memory' else 0,
            workload='single',processes=len(commands),retained_parser_arm=mapped,N=1,R=1,capacity=1024,
            historical_samples_pooled=False,plan_only=True)
        path=W/(role+'-'+mode+'-plan.json');save(path,cfg);plans.append(dict(role=role,mode=mode,plan=pin(path)))
    assert ordinal==16
    save(W/'plan.json',dict(status='PREPARED16_NOT_RUN',script=pin(__file__),binding=pin(W/'binding.json'),groups=plans,
        timing_processes=12,independent_memory_processes=4,total_processes=16,automatic_retries=0,
        scope='Single-turn R1, same P154/C1024/greedy/64 natural output quota. Ordinary auto and MTP K1 overlap-off; each version 3 timing+1 separate memory. No compiler, peer, model download, warmup or profiler.'))
    print('PREPARED16 12 timing + 4 independent memory; 0 processes started')


def config(role,mode):
    assert (role,mode) in GROUPS
    plan=read(W/'plan.json');exact(plan['script']);exact(plan['binding'])
    entry=next(x for x in plan['groups'] if x['role']==role and x['mode']==mode);exact(entry['plan'])
    return read(entry['plan']['path'])


def parse_one(entry,cfg):
    folder=Path(entry['folder']);process=read(folder/'result.json')
    assert process['exit']==0 and not process.get('reader_errors') and not process.get('timeout') and not process.get('timed_out')
    assert process['command']==entry['command'] and process['image']==entry['image'] and process['arm']==entry['arm']
    observation=f.parse(folder,entry['arm'],cfg)
    b.save(folder/'observation.json',observation)
    return dict(variant=entry['variant'],role=entry['role'],folder=str(folder),window_ordinal=entry['window_ordinal'],process=process,observation=observation)


def analyze(role,mode):
    cfg=config(role,mode);out=W/(role+'-'+mode)
    rows=[parse_one(entry,cfg) for entry in cfg['commands']]
    groups={};facts={};complete={}
    for variant in ('control','candidate'):
        selected=[x for x in rows if x['variant']==variant];expect=3 if mode=='timing' else 1
        assert len(selected)==expect
        normalized=[f.facts_parser.non_time(x['observation']['raw']) for x in selected]
        changes=[dict(folder=selected[i]['folder'],differences=f.differences(normalized[0],v)) for i,v in enumerate(normalized[1:],1) if v!=normalized[0]]
        complete[variant]=dict(processes=expect,stable=not changes,changes=changes)
        facts[variant]=normalized[0]
        if mode=='timing':
            groups[variant]={key:b.stats([x['observation']['metrics'][key] for x in selected if x['observation']['metrics'][key] is not None]) for key in selected[0]['observation']['metrics']}
        else:groups[variant]=read(Path(selected[0]['folder'])/'memory-summary.json')
    between=f.differences(facts['control'],facts['candidate'])
    b.save(out/'runs.json',rows)
    b.save(out/'complete-non-time-differences.json',between)
    value=dict(status='COMPLETE_STABLE' if not between and all(x['stable'] for x in complete.values()) else 'PRESERVED_FACT_DIFFERENCES',
        role=role,mode=mode,processes=len(rows),groups=groups,within_variant_complete_non_time=complete,
        control_candidate_complete_non_time_equal=not between,memory_unknown_values_preserved=True,
        original_endpoints_and_sampler=True,historical_samples_pooled=False)
    b.save(out/'summary.json',value)
    assert value['status']=='COMPLETE_STABLE','Retain actual variation; no replacing successful samples'
    print(value['status'],role,mode,len(rows));return value


def run(role,mode):
    cfg=config(role,mode);out=W/(role+'-'+mode)
    assert not out.exists(),'No overwrite or success rerun'
    out.mkdir();save(out/'inputs.json',cfg)
    runner=b.load_helpers();runner.gpu_snapshot(out,'window-before')
    try:
        for entry in cfg['commands']:
            exact(entry['ready']);exact(entry['environment'])
            env=os.environ.copy();env['PATH']=read(entry['environment']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
            print('BEGIN',role,mode,entry['ordinal'],entry['variant'],flush=True)
            runner.execute(Path(entry['folder']),entry['arm'],entry['command'],env,mode=='memory')
            parse_one(entry,cfg)
            print('END',role,mode,entry['ordinal'],entry['variant'],flush=True)
    finally:runner.gpu_snapshot(out,'window-after')
    analyze(role,mode)


def summary():
    tables=[];comparisons=[];processes=[]
    for role in ('ordinary','mtp'):
        timing=read(W/(role+'-timing/summary.json'));memory=read(W/(role+'-memory/summary.json'))
        assert timing['status']==memory['status']=='COMPLETE_STABLE'
        for variant in ('control','candidate'):
            monitored=memory['groups'][variant];stats=timing['groups'][variant]
            tables.append(dict(role=role,variant=variant,timing=stats,memory=dict(sampled_peaks=monitored['sampled_peaks'],
                ready_baseline=monitored['ready_baseline'],actual_sample_gaps_ms={k:monitored['actual_sample_gaps_ms'].get(k) for k in ('min','median','max')},
                running_sample_count=monitored['running_sample_count'],null_sample_counts=monitored['null_sample_counts'])))
        comparisons.append(dict(role=role,median_delta_percent={key:100*(timing['groups']['candidate'][key]['median']/timing['groups']['control'][key]['median']-1) for key in METRICS}))
        for mode in ('timing','memory'):
            for row in read(W/(role+'-'+mode)/'runs.json'):
                p=row['process'];raw=row['observation']['raw']
                processes.append(dict(role=role,mode=mode,variant=row['variant'],window_ordinal=row['window_ordinal'],pid=p['pid'],exit=p['exit'],
                    started_unix_ns=p['started_unix_ns'],finished_unix_ns=p['finished_unix_ns'],image=p['image'],
                    submissions=raw['overlap_successor_submissions'],publications=raw['overlap_successor_publications'],
                    refusals=raw['overlap_successor_refusals'],discards=raw['overlap_successor_discards'],
                    actual_target_rows=raw['actual_target_rows'],actual_draft_rows=raw['actual_draft_rows'],
                    generated_tokens=raw['generated_tokens'],rounds=len(raw.get('rounds',[])),accepted_drafts=raw['accepted_drafts']))
    assert len(processes)==16 and len({x['window_ordinal'] for x in processes})==16
    b.save(W/'summary.json',dict(status='COMPLETE16_FOUR_ARMS_STABLE',processes=16,timing_processes=12,independent_memory_processes=4,
        binding=pin(W/'binding.json'),plan=pin(W/'plan.json'),table=tables,within_window_comparison=comparisons,actual_processes=processes,
        limits=['Only fresh intra-Hyle samples enter these tables; prior 40-process peer table remains separate and unchanged.',
            'Three timing samples/one independent memory sample per version and mode are descriptive; no significance or broad no-regression guarantee.',
            'Memory samples do not enter timing medians; 10ms requested is not actual gap. Missing ready/counters stay null; sampled peaks are lower bounds.',
            'Original complete producer endpoints include preparation/draft/synchronization and actual speculative work. Do not sum overlapping step lifetimes as wall time.']))
    print('COMPLETE16_FOUR_ARMS_STABLE')


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='run':run(*sys.argv[2:])
        elif action=='analyze':analyze(*sys.argv[2:])
        elif action=='summary':summary()
        else:raise ValueError(action)
    except BaseException:
        (W/('failure-'+'-'.join(sys.argv[1:4])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
