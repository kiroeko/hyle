"""Offline-only summary fix: ordinary does not emit MTP-only acceptance fields."""
from pathlib import Path
import hashlib,json,time
W=Path(__file__).resolve().parent
METRICS=('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second','session_processed_tokens_per_second')
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):
 with Path(p).open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def main():
 assert not (W/'summary.json').exists(),'Keep any actual completed receipt'
 original=W/'window.py';snapshot=W/'window-before-summary-amendment.py'
 if not snapshot.exists():
  with snapshot.open('xb') as f:f.write(original.read_bytes())
 assert original.read_bytes()==snapshot.read_bytes()
 failures=sorted(W.glob('failure-summary-*.log'));assert failures
 assert 'KeyError' in failures[-1].read_text() and 'accepted_drafts' in failures[-1].read_text()
 tables=[];comparisons=[];processes=[]
 for role in ('ordinary','mtp'):
  timing=read(W/(role+'-timing/summary.json'));memory=read(W/(role+'-memory/summary.json'))
  assert timing['status']==memory['status']=='COMPLETE_STABLE'
  assert timing['control_candidate_complete_non_time_equal'] and memory['control_candidate_complete_non_time_equal']
  for variant in ('control','candidate'):
   monitored=memory['groups'][variant]
   tables.append(dict(role=role,variant=variant,timing=timing['groups'][variant],memory=dict(sampled_peaks=monitored['sampled_peaks'],
    ready_baseline=monitored['ready_baseline'],actual_sample_gaps_ms={k:monitored['actual_sample_gaps_ms'].get(k) for k in ('min','median','max')},
    running_sample_count=monitored['running_sample_count'],null_sample_counts=monitored['null_sample_counts'])))
  comparisons.append(dict(role=role,median_delta_percent={k:100*(timing['groups']['candidate'][k]['median']/timing['groups']['control'][k]['median']-1) for k in METRICS}))
  for mode in ('timing','memory'):
   rows=read(W/(role+'-'+mode)/'runs.json');assert len(rows)==(6 if mode=='timing' else 2)
   for row in rows:
    folder=Path(row['folder']);p=read(folder/'result.json');producer=read(folder/'stdout.log')
    assert p==row['process'] and p['exit']==0 and not p.get('reader_errors')
    assert producer['mtp']==(role=='mtp') and len(producer['sessions'])==1
    result=producer['sessions'][0]['result'];assert result['mtp']==producer['mtp']
    if role=='mtp':
     # Exact original emitted counters, not the normalizer's accepted_drafts alias.
     assert producer['consumed_drafts']==result['consumed_drafts']
     assert producer['draft_rounds']==result['draft_rounds']==len(result['rounds'])
     assert producer['actual_draft_rows']==result['actual_draft_rows']
     draft=dict(applicable=True,consumed_drafts=producer['consumed_drafts'],rounds=producer['draft_rounds'],
       actual_draft_rows=producer['actual_draft_rows'],source='stdout top-level counters; checked against sessions[0].result and its actual rounds')
    else:
     # Ordinary has no MTP acceptance event. Preserve absence, never fabricate zero.
     missing=('consumed_drafts','accepted_drafts','draft_rounds','actual_draft_rows')
     assert all(k not in producer and k not in result for k in missing)
     assert producer['mtp_tensors']==0 and producer['draft_program_graph_calls']==0
     draft=dict(applicable=False,not_emitted=list(missing),source='Original ordinary stdout omits these MTP-only fields')
    processes.append(dict(role=role,mode=mode,variant=row['variant'],window_ordinal=row['window_ordinal'],pid=p['pid'],exit=p['exit'],
     started_unix_ns=p['started_unix_ns'],finished_unix_ns=p['finished_unix_ns'],image=p['image'],
     submissions=producer['overlap_successor_submissions'],publications=producer['overlap_successor_publications'],
     refusals=producer['overlap_successor_refusals'],discards=producer['overlap_successor_discards'],
     actual_target_rows=producer['actual_target_rows'],generated_tokens=producer['generated_tokens'],
     generation_records=len(result['rounds']),draft=draft,raw_report=pin(folder/'stdout.log')))
 assert len(processes)==16 and len({x['window_ordinal'] for x in processes})==16
 save(W/'summary-amendment.json',dict(status='OFFLINE_SCHEMA_CORRECTION',original_script=pin(original),preserved_script=pin(snapshot),
   original_failure=[pin(p) for p in failures],new_reducer=pin(__file__),new_model_processes=0,
   correction='The failing accepted_drafts lookup was on ordinary, not a missing MTP event. Ordinary absence is explicit not-applicable; MTP uses actual consumed_drafts with exact original schema checks. No missing numerical field is replaced by zero.'))
 save(W/'summary.json',dict(status='COMPLETE16_FOUR_ARMS_STABLE',processes=16,timing_processes=12,independent_memory_processes=4,
  binding=pin(W/'binding.json'),plan=pin(W/'plan.json'),table=tables,within_window_comparison=comparisons,actual_processes=processes,
  amendment=pin(W/'summary-amendment.json'),limits=['All16 successful processes are retained; one offline schema failure corrected without reruns.',
   'Only fresh intra-Hyle samples enter these tables; previous40 peer table remains separate and unchanged.',
   'Three timing samples/one separate memory sample per version and mode: descriptive median/ranges, not significance or a broad no-regression guarantee.',
   'Null ready and actual sampling gaps remain unchanged; dedicated/shared/WS/commit are separate and sampled peaks are lower bounds.']))
 print(json.dumps(dict(status='COMPLETE16_FOUR_ARMS_STABLE',new_model_processes=0,comparisons=comparisons)))
if __name__=='__main__':main()
