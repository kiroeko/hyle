"""Offline sixteen-process receipt/archive. Root executes; no run/build APIs."""
from pathlib import Path
import hashlib,json,math,statistics,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
OUT=R/'docs/evidence/performance/inference-slot-cohort-current-window-2026-10-28'
BUILD=R/'.scratch/inference-slot-cohort-refinement-20261028'
PRIOR=R/'docs/evidence/performance/inference-hidden-state-current-window-2026-10-28'
METRICS={'prefill':'prefill_tokens_per_second','decode':'full_decode_tokens_per_second',
 'session_output':'session_output_tokens_per_second','session_processed':'session_processed_tokens_per_second'}
FORBIDDEN={'.exe','.obj','.pdb','.dll','.lib','.exp','.bin','.gguf','.safetensors','.pt','.spv','.zip','.nsys-rep','.sqlite','.db','.pyc'}
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p).resolve();body=p.read_bytes();return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def exact(p):assert pin(p['path'])==p,p['path']
def save(p,v):
 with Path(p).open('x',encoding='utf-8') as out:out.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def compact(p,v):
 text=json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
 with Path(p).open('x',encoding='utf-8') as out:out.write(text)
def non_time(v):
 if isinstance(v,list):return [non_time(x) for x in v]
 if isinstance(v,dict):return {k:non_time(x) for k,x in v.items() if not any(t in k for t in ('seconds','per_second','clock_unix','unix_ns','unix_ms'))}
 return v
def triple(v):return None if v is None else [round(v[k],6) if v[k] is not None else None for k in ('median','min','max')]
def mib(v):return None if v is None else round(v/(1024**2),3)


def main():
 summary=read(W/'summary.json');assert summary['status']=='COMPLETE16_FOUR_ARMS_STABLE'
 assert (summary['processes'],summary['timing_processes'],summary['independent_memory_processes'])==(16,12,4)
 binding=read(W/'binding.json');plan=read(W/'plan.json');exact(summary['binding']);exact(summary['plan']);exact(summary['amendment'])
 assert binding['object_count_each']==226 and len(binding['replacements'])==2
 for group in plan['groups']:exact(group['plan'])
 assert binding['control']['image']['sha256'].startswith('b59fe852') and binding['candidate']['image']['sha256'].startswith('d4425096')
 for version in ('control','candidate'):
  for field in ('ready','inputs','recipe','source'):exact(binding[version][field])
  assert len(read(binding[version]['inputs']['path']))==226
 tables=[];cold=[];memory=[];work=[];index=[]
 for role in ('ordinary','mtp'):
  for mode in ('timing','memory'):
   config=read(W/(role+'-'+mode+'-plan.json'));rows=read(W/(role+'-'+mode)/'runs.json');group=read(W/(role+'-'+mode)/'summary.json')
   assert group['status']=='COMPLETE_STABLE' and group['control_candidate_complete_non_time_equal']
   assert len(rows)==len(config['commands'])==(6 if mode=='timing' else 2)
   facts={}
   for row,entry in zip(rows,config['commands']):
    folder=Path(row['folder']);process=read(folder/'result.json');raw=read(folder/'consumer-result.json')
    assert process==row['process'] and process['exit']==0 and not process.get('reader_errors') and not process.get('timeout') and not process.get('timed_out')
    assert process['command']==entry['command'] and process['image']==entry['image']==binding[row['variant']]['image']
    assert process['memory_only']==(mode=='memory') and process['arm']==('hyle_auto' if role=='ordinary' else 'hyle_mtp')
    assert read(folder/'timing-partition-gate.json')['status']=='PASS'
    assert math.isclose(raw['prefill_seconds']+raw['decode_seconds'],raw['session_seconds'],rel_tol=1e-5,abs_tol=2e-6)
    facts.setdefault(row['variant'],[]).append(non_time(raw))
    index.append(dict(role=role,mode=mode,variant=row['variant'],window_ordinal=row['window_ordinal'],pid=process['pid'],
     started_unix_ns=process['started_unix_ns'],finished_unix_ns=process['finished_unix_ns'],image=process['image'],exit=process['exit'],
     raw_files=[pin(folder/x) for x in ('command.json','result.json','stdout.log','stderr.log','consumer-result.json')]))
   assert all(all(x==items[0] for x in items) for items in facts.values()) and facts['control'][0]==facts['candidate'][0]
  for variant in ('control','candidate'):
   value=next(x for x in summary['table'] if x['role']==role and x['variant']==variant);stats=value['timing'];mon=value['memory']
   rows=[x for x in read(W/(role+'-timing/runs.json')) if x['variant']==variant];assert len(rows)==3
   for field,expected in stats.items():
    values=[x['observation']['metrics'][field] for x in rows if x['observation']['metrics'][field] is not None]
    if expected is None:assert not values;continue
    assert expected['count']==len(values)
    for label,actual in (('median',statistics.median(values)),('min',min(values)),('max',max(values))):assert math.isclose(actual,expected[label],rel_tol=1e-12)
   tables.append(dict(role=role,version=variant,**{label:triple(stats[field]) for label,field in METRICS.items()}))
   cold.append(dict(role=role,version=variant,**{k:triple(stats[k]) for k in ('weights_load_seconds','startup_to_ready_seconds','first_token_elapsed_seconds','startup_to_endpoint_seconds','cold_output_tokens_per_second')}))
   peaks=mon['sampled_peaks'];memory.append(dict(role=role,version=variant,
    GPU_dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']),GPU_shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']),
    GPU_same_sample_total_MiB=mib(peaks['sampled_peak_gpu_total_bytes']),RAM_working_set_MiB=mib(peaks['sampled_max_working_set_bytes']),
    RAM_private_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']),ready_baseline=mon['ready_baseline'],
    running_samples=mon['running_sample_count'],actual_gap_ms=mon['actual_sample_gaps_ms'],null_samples=mon['null_sample_counts']))
   actual=[x for x in summary['actual_processes'] if x['role']==role and x['variant']==variant]
   assert len(actual)==4
   work.append(dict(role=role,version=variant,processes=[{k:x[k] for k in ('mode','pid','generated_tokens','actual_target_rows','generation_records','submissions','publications','refusals','discards','draft')} for x in actual]))
 assert len(index)==16 and len({x['window_ordinal'] for x in index})==16
 save(W/'process-index.json',index)
 comparisons=[dict(role=x['role'],candidate_vs_control_percent={k:round(x['median_delta_percent'][field],6) for k,field in METRICS.items()}) for x in summary['within_window_comparison']]
 receipt=dict(schema='hyle.performance.slot-cohort-current-window.v1',date='2026-10-28',status=summary['status'],
  scope='Finite intra-Hyle check of the common SlotTransactions/public arena identity patch. Single-turn R1 ordinary-auto and MTP K1. No new peer processes or historical timing pool.',
  counts=dict(actual_model_processes=16,timing=12,independent_memory=4,per_role_version_timing=3,per_role_version_memory=1,compiler_processes_in_window=0,success_reruns=0),
  binding=dict(control=binding['control'],candidate=binding['candidate'],actual_object_count_each=226,replacements=binding['replacements'],runtime=binding['runtime']),
  configuration='Same original P154/C1024/N1/R1/greedy/64 natural-output quota. Ordinary --decode-overlap auto; MTP --mtp-max-drafts1 with overlap off. Original BF16 physical inputs; no warmup/profiler/download.',
  metric_order='Each array is [median,min,max]. Four metrics use complete producer endpoints; session processed-context TPS is distinct from output TPS. Percent=100*(candidate median/control median-1).',
  timing_four_metrics=tables,within_window_comparison=comparisons,ready_and_cold=cold,memory_MiB=memory,actual_work=work,
  consistency='Each variant is complete-non-time stable in all four groups, and candidate/control complete-non-time reports match within each mode. Original IDs/work/acceptance preserved in raw reports.',
  offline_schema_amendment=read(W/'summary-amendment.json'),
  prior_peer_table=dict(json=pin(PRIOR.with_suffix('.json')),zip=pin(PRIOR.with_suffix('.zip')),
   scope='Retained prior40-process peer table is unchanged and independent. Its samples and percentages are not reused here; this finite patch note cannot refresh that peer comparison.'),
  process_index=pin(W/'process-index.json'),package_script=pin(__file__),
  limits=['Three timing observations per role/version describe this finite window, not statistical significance or a broad proof of no regression. Ordinary decode median +0.0413%; MTP -0.9237%; ranges overlap, with no causal gain claim.',
   'Observed prefill medians are lower by2.8878%/2.1130%; session output/context medians by0.2399%/0.6713%. These differences remain visible, not normalized away.',
   'One independent memory process per arm is excluded from timing statistics. All four ready baselines lack a sample and remain null/unknown. Requested10ms is not actual sampling interval.',
   'PSAPI working set/private commit and WDDM dedicated/shared/same-sample total are separate quantities. Sampled peaks are lower bounds; no exact CUDA allocation/physical peak or summed CPU+GPU claim.',
   'MTP uses original emitted consumed_drafts/rounds/rows. Ordinary MTP-only fields are absent/not-applicable, never invented zero. No EOS/fault/other-platform/concurrency beyondR1 proof comes from this window.'])
 allowed={'.json','.py','.log','.txt','.csv'};skip={'package-manifest.json','package-result.json','evidence-summary.json'}
 paths={p.resolve() for p in W.rglob('*') if p.is_file() and p.suffix.lower() in allowed and p.name not in skip and '__pycache__' not in p.parts}
 extra=[BUILD/'plan.json',BUILD/'compile/model/compiled.json',BUILD/'logs/model/command.json',Path(binding['candidate']['actual_dependencies']['path']),Path(binding['runtime']['path']),PRIOR.with_suffix('.json')]
 for variant in ('control','candidate'):
  extra.extend(Path(binding[variant][k]['path']) for k in ('ready','inputs','recipe','source'))
 for row in binding['candidate']['snapshots']:extra.append(Path(row['snapshot']['path']))
 for field in ('protocol','prompt','input_manifest'):extra.append(Path(binding[field]['path']))
 # Keep original sampler/parser implementation and dependency identities; no SDK tree.
 for group in plan['groups']:
  cfg=read(group['plan']['path']);extra.extend(Path(x['path']) for x in cfg['helpers'])
 paths.update(p.resolve() for p in extra)
 assert all(p.is_relative_to(R) and p.is_file() and p.suffix.lower() not in FORBIDDEN for p in paths)
 manifest=[dict(member=p.relative_to(R).as_posix(),**pin(p)) for p in sorted(paths)]
 save(W/'package-manifest.json',dict(files=manifest,policy='Original current raw16 only; no EXE/OBJ/PDB/DLL/model/SDK payload. Prior archive references retain source/include ancestry.'))
 compact(W/'evidence-summary.json',receipt)
 OUT.parent.mkdir(parents=True,exist_ok=True);archive=OUT.with_suffix('.zip')
 assert not archive.exists() and not OUT.with_suffix('.json').exists(),'Never replace released evidence'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for row in manifest:z.write(row['path'],row['member'])
  for p in (W/'package-manifest.json',W/'evidence-summary.json'):z.write(p,p.relative_to(R).as_posix())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(manifest)+2
  assert not any(Path(x).suffix.lower() in FORBIDDEN for x in z.namelist())
  for row in manifest:
   body=z.read(row['member']);assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
  assert json.loads(z.read((W/'evidence-summary.json').relative_to(R).as_posix()))==receipt
  size=sum(x.file_size for x in z.infolist())
 receipt['archive']=dict(**pin(archive),files=len(manifest)+2,uncompressed_bytes=size)
 receipt['manifest']=pin(W/'package-manifest.json');compact(OUT.with_suffix('.json'),receipt)
 assert OUT.with_suffix('.json').stat().st_size<100000 and read(OUT.with_suffix('.json'))==receipt
 result=dict(status='PACKAGED_READ_BACK_VERIFIED',json=pin(OUT.with_suffix('.json')),archive=receipt['archive'],new_processes=0)
 save(W/'package-result.json',result);print(json.dumps(result))
if __name__=='__main__':main()
