$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$probeRoot = 'C:\hyle-scratch\active-cpu\norm-diag'
$buildRoot = 'C:\hyle-scratch\active-cpu\p1'
$recordRoot = Join-Path $repoRoot '.scratch\validation\onednn-aa'
New-Item -ItemType Directory -Path $probeRoot -Force | Out-Null
. (Join-Path $repoRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-cpu\static' -ExtraArgs @('--target','help') > (Join-Path $recordRoot 'norm-impl-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$compileArgs = @('/nologo','/std:c++20','/O2','/EHsc','/MD','/DDNNL_STATIC_LIB',
  ('/I' + (Join-Path $repoRoot '.scratch\perf-peers\onednn-v3.13.2\include')),
  ('/I' + (Join-Path $buildRoot '_deps\onednn-build\include')),
  (Join-Path $recordRoot 'norm-impl-probe.cc'),
  ('/Fo' + (Join-Path $probeRoot 'norm-impl-probe.obj')),
  ('/Fe' + (Join-Path $probeRoot 'norm-impl-probe.exe')),
  '/link',(Join-Path $buildRoot 'bin\dnnl.lib'))
& cl.exe @compileArgs > (Join-Path $recordRoot 'norm-impl-build.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $recordRoot 'norm-impl-build.log'); exit $LASTEXITCODE }
Get-ChildItem -LiteralPath (Join-Path $buildRoot 'bin') -Filter '*.dll' -File |
  ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $probeRoot }
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleNormProbeErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleNormProbeErrorMode]::SetErrorMode(0x8003) | Out-Null
$savedPath = $env:PATH
try {
  $env:PATH = ''
  & (Join-Path $probeRoot 'norm-impl-probe.exe') > (Join-Path $recordRoot 'norm-impl-probe.csv') 2> (Join-Path $recordRoot 'norm-impl-run.err')
  $result = $LASTEXITCODE
} finally { $env:PATH = $savedPath }
Get-Content (Join-Path $recordRoot 'norm-impl-probe.csv')
exit $result
