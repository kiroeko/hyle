#define NOMINMAX
#include <windows.h>

#include <oneapi/dnnl/dnnl.h>
#include <oneapi/dnnl/dnnl_threadpool.h>

#include <array>
#include <cstdio>
#include <cstdlib>

static void check(dnnl_status_t status) {
  if (status != dnnl_success) {
    std::fprintf(stderr, "oneDNN status=%d\n", static_cast<int>(status));
    std::exit(1);
  }
}

static void probe(dnnl_engine_t engine, dnnl_dim_t rows, dnnl_dim_t width,
                  bool rms, int rank, int pattern) {
  dnnl_memory_desc_t data = nullptr, row = nullptr, full = nullptr;
  dnnl_post_ops_t ops = nullptr;
  dnnl_primitive_attr_t attr = nullptr;
  dnnl_primitive_desc_t pd = nullptr;
  const std::array<dnnl_dim_t, 3> dims{rows, rank == 2 ? width : 1, width};
  const std::array<dnnl_dim_t, 3> vec{1, rank == 2 ? width : 1, width};
  const auto tag = rank == 2 ? dnnl_ab : dnnl_abc;
  check(dnnl_memory_desc_create_with_tag(&data, rank, dims.data(), dnnl_f32, tag));
  check(dnnl_memory_desc_create_with_tag(&row, rank, vec.data(), dnnl_f32, tag));
  check(dnnl_memory_desc_create_with_tag(&full, rank, dims.data(), dnnl_f32, tag));
  check(dnnl_post_ops_create(&ops));
  if (pattern == 1 || pattern == 3)
    check(dnnl_post_ops_append_binary(ops, dnnl_binary_mul, row));
  if (pattern == 2 || pattern == 3)
    check(dnnl_post_ops_append_binary(ops, dnnl_binary_add, full));
  check(dnnl_primitive_attr_create(&attr));
  check(dnnl_primitive_attr_set_scratchpad_mode(attr, dnnl_scratchpad_mode_user));
  check(dnnl_primitive_attr_set_fpmath_mode(attr, dnnl_fpmath_mode_strict));
  check(dnnl_primitive_attr_set_post_ops(attr, ops));
  const unsigned flags = dnnl_use_scale | (rms ? dnnl_rms_norm : dnnl_use_shift);
  check(dnnl_layer_normalization_forward_primitive_desc_create_v2(
      &pd, engine, dnnl_forward_inference, data, data, nullptr, dnnl_f32,
      1.e-5F, flags, attr));
  const char *impl = nullptr;
  check(dnnl_primitive_desc_query(pd, dnnl_query_impl_info_str, 0, &impl));
  constexpr std::array patterns{"none", "vector-mul", "full-add", "vector-mul-full-add"};
  std::printf("%s,%lld,%lld,%d,%s,%s\n", rms ? "rms" : "layer",
              static_cast<long long>(rows), static_cast<long long>(width), rank,
              patterns[pattern], impl);
  dnnl_primitive_desc_destroy(pd);
  dnnl_primitive_attr_destroy(attr);
  dnnl_post_ops_destroy(ops);
  dnnl_memory_desc_destroy(full);
  dnnl_memory_desc_destroy(row);
  dnnl_memory_desc_destroy(data);
}

int main() {
  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);
  check(dnnl_threadpool_interop_set_max_concurrency(1));
  dnnl_engine_t engine = nullptr;
  check(dnnl_engine_create(&engine, dnnl_cpu, 0));
  std::puts("operation,rows,width,descriptor_rank,post_ops,implementation");
  for (const bool rms : {true, false})
    for (const auto shape : {std::array<dnnl_dim_t, 2>{1, 2048}, {17, 2048},
                             {128, 2048}, {17, 257}})
      for (const int rank : {2, 3})
        for (int pattern = 0; pattern != 4; ++pattern)
          probe(engine, shape[0], shape[1], rms, rank, pattern);
  check(dnnl_engine_destroy(engine));
}
