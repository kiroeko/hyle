param([Parameter(Mandatory=$true)][string]$Candidate)
$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
$buildRoot = 'C:\hyle-scratch\active-cpu\p1'
$outputRoot = Join-Path $sourceRoot '.scratch\perf-runs\onednn-normalization-p1'
$logRoot = Join-Path $sourceRoot '.scratch\validation\onednn-aa'
if ($Candidate -notmatch '^[0-9a-f]{40}$' -or (git -C $sourceRoot rev-parse HEAD) -ne $Candidate -or
    (git -C $sourceRoot status --porcelain)) {
  throw 'Qualified normalization requires the exact clean frozen candidate'
}
foreach ($path in @($buildRoot, $outputRoot)) {
  if ((Test-Path -LiteralPath $path) -and @(Get-ChildItem -LiteralPath $path -Force).Count -ne 0) {
    throw ('Qualified run needs an empty task directory: ' + $path)
  }
}
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VSLANG = '1033'
if ($env:CMAKE_TOOLCHAIN_FILE) { throw 'Unexpected inherited toolchain override' }
# Reuse the standard environment importer without configuring the fresh P1 build.
. (Join-Path $sourceRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-cpu\static' -ExtraArgs @('--target','help') > (Join-Path $logRoot 'p1-environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleNormP1ErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleNormP1ErrorMode]::SetErrorMode(0x8003) | Out-Null
& python (Join-Path $sourceRoot 'scripts\hyle-perf.py') qualify-platform `
  --contract (Join-Path $sourceRoot 'bench\contracts\onednn-normalization-p1-v1.json') `
  --machine W1-WIN --source $sourceRoot --build $buildRoot --output $outputRoot `
  --peer ('native=' + (Join-Path $sourceRoot '.scratch\perf-peers\hyle-native-2c9338e1')) `
  --peer ('onednn=' + (Join-Path $sourceRoot '.scratch\perf-peers\onednn-v3.13.2')) `
  > (Join-Path $logRoot 'normalization-p1-launch.log') 2>&1
$result = $LASTEXITCODE
Get-Content -LiteralPath (Join-Path $logRoot 'normalization-p1-launch.log') -Tail 60
exit $result
