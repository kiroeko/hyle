"""One bounded four-child diagnostic; never qualifies or restarts P1."""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_perf import (evaluate_machine_profile, expected_child_policy,
                       get_machine_profile, load_registry, probe_machine,
                       sampling_mutex)
from hyle_perf.nanobench import parse_nanobench, select_pair
from hyle_perf.runner import _apply_sampling_policy, _child_environment

OUTPUT = Path(__file__).with_suffix('')
OUTPUT.mkdir(exist_ok=False)
BINARY = Path('C:/hyle-scratch/active-cpu/p1/bin/hyle_onednn_normalization_bench.exe')
contract = json.loads((ROOT / 'bench/contracts/onednn-normalization-p1-v1.json').read_text())
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
if candidate != 'e33b6fea4b80d4b82adb6a267dc52ba2ad7a73f9':
    raise RuntimeError('Unexpected diagnostic candidate')
artifact = hashlib.sha256(BINARY.read_bytes()).hexdigest()
profile = get_machine_profile(load_registry(), 'W1-WIN')
results = []
ctypes.WinDLL('kernel32', use_last_error=True).SetErrorMode(0x8003)
with sampling_mutex(profile) as lease:
    probe = probe_machine(paths=[('build', BINARY.parent)])
    gate = evaluate_machine_profile(profile, probe, role='engineering',
                                    sampling_topology='single-logical-cpu')
    if gate['gate'] != 'PASS':
        raise RuntimeError(gate)
    policy = expected_child_policy(profile, probe=probe,
                                   sampling_topology='single-logical-cpu')
    for order in ('candidate-first', 'peer-first'):
        for allocation in ('candidate-first', 'peer-first'):
            additions = {'HYLE_BENCH_AA_ROUTE': 'peer'}
            if order == 'peer-first':
                additions['HYLE_BENCH_RIVAL_FIRST'] = '1'
            if allocation == 'peer-first':
                additions['HYLE_BENCH_PEER_ALLOCATION_FIRST'] = '1'
            environment = _child_environment(
                contract['extensions']['runner']['controlled_environment'],
                additions, profile, policy)
            with _apply_sampling_policy(policy):
                result = subprocess.run([str(BINARY)], cwd=ROOT,
                    capture_output=True, text=True, encoding='utf-8', errors='replace',
                    env=environment, timeout=120, creationflags=0x00008000)
            raw = result.stdout + result.stderr
            path = OUTPUT / f'{order}-{allocation}.log'
            path.write_text(raw, encoding='utf-8')
            if result.returncode:
                raise RuntimeError(f'Diagnostic child failed: {path}')
            parsed = parse_nanobench(raw)
            ratios = {}
            titles = contract['extensions']['runner']['executables'][0]['workloads']
            for row, title in zip(contract['workloads'], titles):
                a, b = select_pair(parsed, row['pair']['candidate'], row['pair']['peer'],
                                   title=title['title'])
                ratios[row['id']] = a.operations_per_second / b.operations_per_second
            results.append({'order': order, 'allocation': allocation, 'ratios': ratios,
                            'log': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
            print(json.dumps({'order': order, 'allocation': allocation,
                'direct-rms-1x2048': ratios['direct-rms-1x2048']}), flush=True)
    receipt = {'qualification': 'DIAGNOSTIC', 'candidate': candidate,
        'purpose': 'Four fixed primary Native/Native strata after one high-variance A/A observation; no retries, no A/B, no P1 qualification',
        'child_policy': policy, 'sampling_mutex': lease.manifest_record(),
        'binary_sha256': artifact, 'results': results,
        'binary_unchanged': hashlib.sha256(BINARY.read_bytes()).hexdigest() == artifact}
    (OUTPUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
