$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $sourceRoot '.scratch\validation\onednn-aa'
$buildRoot = 'C:\hyle-scratch\active-cpu\p1'
$outputRoot = Join-Path $sourceRoot '.scratch\perf-runs\onednn-normalization-p1'
$archiveRoot = Join-Path $logRoot 'p1-preflight-failure'
if (Test-Path -LiteralPath $archiveRoot) { throw 'Do not overwrite the original A/A failure' }
if ((git -C $sourceRoot rev-parse HEAD) -ne 'e33b6fea4b80d4b82adb6a267dc52ba2ad7a73f9' -or
    (git -C $sourceRoot status --porcelain)) { throw 'Candidate identity changed' }
if (Get-Process -Name hyle_onednn_normalization_bench,hyle_onednn_normalization_bench_placement,ninja -ErrorAction SilentlyContinue) {
  throw 'A validation process is still running'
}
$inventories = @()
foreach ($target in @($buildRoot,$outputRoot)) {
  $resolved = (Resolve-Path -LiteralPath $target).ProviderPath
  if ($resolved -ne [IO.Path]::GetFullPath($target) -or
      ($resolved -ne 'C:\hyle-scratch\active-cpu\p1' -and
       $resolved -ne 'C:\public\project-hyle\hyle\.scratch\perf-runs\onednn-normalization-p1')) {
    throw ('Unexpected cleanup root: ' + $resolved)
  }
  $items = @((Get-Item -LiteralPath $target)) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
  if (@($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) {
    throw ('Reparse point in cleanup tree: ' + $target)
  }
  $files = @($items | Where-Object { -not $_.PSIsContainer })
  $inventories += [ordered]@{path=$target; files=$files.Count; logical_bytes=($files | Measure-Object Length -Sum).Sum}
}
New-Item -ItemType Directory -Path $archiveRoot | Out-Null
Copy-Item -LiteralPath $outputRoot -Destination (Join-Path $archiveRoot 'run') -Recurse
Copy-Item -LiteralPath (Join-Path $logRoot 'aa-short-diagnostic') -Destination (Join-Path $archiveRoot 'diagnostic') -Recurse
foreach ($name in @('normalization-p1-launch.log','p1-environment.log','normalization-p1.ps1','aa-short-diagnostic.py','archive-aa-failure.ps1')) {
  Copy-Item -LiteralPath (Join-Path $logRoot $name) -Destination (Join-Path $archiveRoot $name)
}
$buildEvidence = Join-Path $archiveRoot 'build'
New-Item -ItemType Directory -Path $buildEvidence | Out-Null
foreach ($name in @('CMakeCache.txt','build.ninja','.ninja_log','CMakeFiles\CMakeConfigureLog.yaml')) {
  Copy-Item -LiteralPath (Join-Path $buildRoot $name) -Destination (Join-Path $buildEvidence ([IO.Path]::GetFileName($name)))
}
$artifactPaths = @('hyle_onednn_normalization_bench.exe','hyle_onednn_normalization_bench_placement.exe','hyle_perf_control_bench.exe') |
  ForEach-Object { Join-Path $buildRoot ('bin\' + $_) }
$artifacts = @($artifactPaths | ForEach-Object {
  [ordered]@{name=[IO.Path]::GetFileName($_); bytes=(Get-Item -LiteralPath $_).Length; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()}
})
Compress-Archive -LiteralPath $artifactPaths -DestinationPath (Join-Path $archiveRoot 'diagnostic-artifacts.zip')
$receipt = [ordered]@{
  candidate='e33b6fea4b80d4b82adb6a267dc52ba2ad7a73f9'
  qualification='INCONCLUSIVE'
  phase='workload A/A preflight rejected; first A/B child exited before measurement; zero P1 samples'
  failure='One Native/Native direct-rms-1x2048 row ratio 1.1652618919; row error 16.5%, paired CI includes 1; all order/placement/allocation group medians within original 5% limit'
  diagnostic='Four predeclared primary Native/Native order x allocation children; target ratios 1.00884,1.01869,1.01054,1.02070; no gross >10% row; same binary hashes'
  interpretation='Transient perturbation is more consistent than fixed arm bias; no specific OS cause proved; no product winner or failure inferred'
  next_attempt_budget=1
  next_attempt_contract='Unchanged candidate, contract, artifact build flags, workload, thresholds, sample schedule, P-core2 and orders. Original full qualification entry with fresh build; any repeated preflight failure ends this attempt budget.'
  artifacts=$artifacts
  artifact_archive_sha256=(Get-FileHash -LiteralPath (Join-Path $archiveRoot 'diagnostic-artifacts.zip') -Algorithm SHA256).Hash.ToLowerInvariant()
  cleanup=$inventories
}
$receipt | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $archiveRoot 'receipt.json') -Encoding utf8
foreach ($target in @($buildRoot,$outputRoot)) { Remove-Item -LiteralPath $target -Recurse -Force }
$receipt | ConvertTo-Json -Depth 10
