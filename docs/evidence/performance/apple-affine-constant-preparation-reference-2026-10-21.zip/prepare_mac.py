from pathlib import Path
import base64,hashlib,json,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-affine-constant-preparation-2026-10-21';O=P/'apple/mac';O.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
OLD=A/'apple-immutable-materialization-2026-10-21/apple/mac/final';oldplan=read(OLD/'plan.json');oldroot=oldplan['remote'];remote=oldroot.replace('/apple-immutable-materialization-2026-10-21/apple','/apple-affine-constant-preparation-2026-10-21/apple')
sources=['src/compute_route_apple/apple_tensor.cc','src/compute_route_apple/apple_operations.cc','src/graph_route_apple/apple_lowering.cc','src/graph_route_apple/native_region.cc','tests/graph_route_apple/affine_metadata_test.cc']
recipes=[read(A/('batch-query-extent/delegated/apple/results/'+s.replace('/','--')+'.json'))['argv']for s in sources[:4]]
recipes.append(read(A/'glm-flash-mixed-mlx-2026-10-21/apple/mac/final/results/tests--graph_route_apple--glm_flash_mixed_mlx_test.cc-compile.command.json')['argv'])
link=read(OLD/'results/link.command.json')['argv'];excluded=[]
inputs=[x for x in read(OLD/'results/link-inputs.json')if x['path']in link]
compiles=[]
for s,recipe in zip(sources,recipes):
 old=next((x for x in link if x.endswith('/'+s.replace('/','--')+'.o')or x.endswith('/'+s.replace('/','--').replace('.cc','.o'))),None)if not s.startswith('tests/')else None
 assert s.startswith('tests/')or old is not None,s
 compiles.append(dict(source=s,recipe=recipe,old_object=old))
plan=dict(oldplan,remote=remote,image='affine-constant-preparation',filter='AppleAffineMetadata.*:AppleGlmFlashMixedMlx.*:AppleImmutableMetadataDiagnostic.*',compile=compiles,link=link,inputs=inputs,run_environment={},excluded_test_objects=excluded,diagnostic_nonproduct=True)
relative=list(dict.fromkeys(['tests/graph_route_apple',*[x for x in oldplan['include_roots']if not x.startswith('/')]]));plan['include_roots']=list(dict.fromkeys([*relative,*[oldroot+'/'+x for x in relative],*[x for x in oldplan['include_roots']if x.startswith('/')]]))
previous={x['path']:dict(x,remote_path=oldroot+'/'+x['path'])for x in read(OLD/'source-manifest.json')};previous.update({x['path']:x for x in read(OLD/'reused-source-manifest.json')})
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]];seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(p):
 p=p.resolve()
 if p in seen or not p.is_relative_to(ROOT)or not p.is_file()or p.suffix not in['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(p);key=p.relative_to(ROOT).as_posix();actual=p
 for name in include.findall(actual.read_text(encoding='utf-8',errors='replace')):
  target=next((b/name for b in[p.parent,*search]if(b/name).is_file()),None)
  if target:visit(target)
for rel in sources:visit(ROOT/rel)
for item in read(OLD.parent.parent/'actual-dependencies-audit.json')['compiles']:
 for row in item['canonical_or_diagnostic']:
  q=ROOT/row['expected']['path']
  if q.suffix not in['.cc','.mm']:visit(q)
files=[];reuse=[]
for p in sorted(seen):
 key=p.relative_to(ROOT).as_posix();b=p.read_bytes();row=dict(path=key,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),diagnostic_nonproduct=False)
 if key not in sources and key in previous and row['sha256']==previous[key]['sha256']and not key.startswith('tests/'):reuse.append(dict(row,remote_path=previous[key]['remote_path']))
 else:files.append(dict(row,data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in x.items()if k!='data'}for x in files]);save(O/'reused-source-manifest.json',reuse);save(O/'plan.json',plan)
script=(A/'apple-compact-fp8-scales-2026-10-21/apple/build_mac.py').read_bytes();(P/'apple/build_mac.py').write_bytes(script)
code=r'''from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for x in p['reuse']:
 q=Path(x['remote_path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
for x in p['files']:
 b=base64.b64decode(x['data']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];q=r/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
for name,value in [('source-manifest',[{k:v for k,v in x.items()if k!='data'}for x in p['files']]),('reused-source-manifest',p['reuse']),('plan',p['plan'])]:(r/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for x in p['plan']['inputs']:
 q=Path(x['path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(remote=str(r),delta_files=len(p['files']),delta_bytes=sum(x['bytes']for x in p['files']),reuse_files=len(p['reuse']),hardware=h)))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,dict(plan=plan,files=files,reuse=reuse,script=base64.b64encode(script).decode()));save(O/'sync.result.json',result);print(json.dumps(result,indent=2))
