from pathlib import Path
import base64,hashlib,json,runpy,sys
A=Path('.scratch/architecture-refactor-2026-10-18');P=A/'apple-affine-constant-preparation-2026-10-21';O=P/'apple/mac';plan=json.loads((O/'plan.json').read_text());rows=json.loads((O/'source-manifest.json').read_text());files=[]
for rel in sys.argv[1:]:
 b=Path(rel).read_bytes();row=next(x for x in rows if x['path']==rel);row.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest());files.append(dict(row,data=base64.b64encode(b).decode()))
(O/'source-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
code='''from pathlib import Path
import json,sys,base64
p=json.load(sys.stdin);r=Path(p['remote'])
for x in p['files']:(r/x['path']).write_bytes(base64.b64decode(x['data']))
(r/'source-manifest.json').write_text(json.dumps(p['manifest'],indent=2)+chr(10));print(json.dumps(dict(updated=[x['path']for x in p['files']])))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];print(ssh(code,dict(remote=plan['remote'],files=files,manifest=rows)))
