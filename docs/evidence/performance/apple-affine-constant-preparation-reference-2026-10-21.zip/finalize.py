from pathlib import Path
import hashlib,json,runpy,xml.etree.ElementTree as E
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-affine-constant-preparation-2026-10-21';O=P/'apple/mac/final';Q=O/'results'
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def ident(p):
 b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
audit=read(P/'apple/actual-dependencies-audit.json');assert audit['accidental_drift']==0
cases=[]
for c in E.parse(Q/'tests.xml').findall('.//testcase'):
 assert not c.findall('failure')and not c.findall('skipped');cases.append(dict(name=c.get('classname')+'.'+c.get('name'),properties={p.get('name'):p.get('value')for p in c.findall('./properties/property')}))
assert len(cases)==4;successes=sum(int(x['properties'].get('successful_submissions',0))for x in cases);assert successes==16
frames=[json.loads(x[len('HYLE_MLX_GRAPH '):])for x in(Q/'run.stderr.log').read_text().splitlines()if x.startswith('HYLE_MLX_GRAPH ')]
assert not any(x['truncated']for x in frames)
actual=[x for x in frames if x['phase']=='actual_before_eval'];constants=[x for x in actual if x['label'].startswith('constants.phase')];dynamic=[x for x in actual if x['label'].startswith('dynamic.slot')];assert len(constants)==3 and len(dynamic)==5
assert all(not any(c['input']['dtype']=='float16'for c in x['casts'])for x in constants)
assert all(sum(c['input']['dtype']=='float16'for c in x['casts'])==12 for x in dynamic)
new_main=[x for x in actual if x['label']=='unset'and any(i['shape'] in[[2,1,64],[1,64]]for i in x['inputs'])];assert len(new_main)==9
assert all(not any(c['input']['shape']in[[3,8,1],[8,1]]for c in x['casts'])for x in new_main)
observations=dict(scope='Observer is the unchanged nonproduct context object from the diagnostic package. New products/tests are canonical current source.',frames=len(frames),new_main_calls=9,new_main_pending_metadata_casts=0,old_tiny_constants_calls=3,before_pending_F16_casts_per_call=2,after_pending_F16_casts_per_call=0,dynamic_X_calls=5,dynamic_F16_pending_casts_per_call=12,dynamic_weight_cache_implemented=False,raw_frames=[dict(sequence=x['sequence'],phase=x['phase'],label=x['label'],inputs=x['inputs'],casts=x['casts'])for x in frames],physical_dispatches=None,physical_allocations=None,throughput_delta=None)
save(P/'apple/prepared-observation.json',observations)
plan=read(O/'plan.json');ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote']);image=r/'affine-constant-preparation';files=[image,Path(str(image)+'.map')]
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink(),resolved=str(p.resolve()))
rows=[x for x in files[1].read_text().splitlines()if x.startswith('[')];owners=[x for x in rows if any(w in x for w in ['apple_tensor','apple_operations','apple_lowering','native_region','affine_metadata','glm_flash_mixed_mlx','apple_context'])];old=[x for x in owners if '.a('in x];assert not old
lsof=subprocess.run(['/usr/sbin/lsof','-t',*map(str,files)],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),remote_root_is_symlink=r.is_symlink(),deletable_files=[ident(x)for x in files],retained_objects=[ident(x)for x in(r/'objects').glob('*.o')],active_lsof=lsof.stdout.strip().splitlines(),lsof_exit=lsof.returncode,map_owner_check=dict(actual=owners,stale_changed_archive_members=old),retained_diagnostic_context='Explicit nonproduct observer compiled previously;canonical context source remains unchanged.')))
''',dict(remote=plan['remote']))
assert not remote['active_lsof']and not remote['remote_root_is_symlink'];save(P/'apple/cleanup-inventory.json',remote);save(P/'apple/map-owner-check.json',remote['map_owner_check'])
freeze=read(P/'source-freeze.json')
for s in freeze['sources']:assert ident(R/s['path'])==s
save(P/'apple/final-validation.json',dict(status='actual_focused_Apple_product_validation_passed',cases=cases,passed=4,skipped=0,successful_submissions=successes,new_cases=2,new_successful_submissions=9,neighbor_cases=2,neighbor_successful_submissions=7,expected_failed_submissions=1,expected_compile_budget_rejections=1,actual_project_dependencies=audit['unique_project_files'],actual_dependency_references=audit['actual_dependency_references'],accidental_source_drift=0,source_freeze=ident(P/'source-freeze.json'),observation=ident(P/'apple/prepared-observation.json'),cleanup=ident(P/'apple/cleanup-inventory.json'),compile_exit_codes=[x['exit']for x in read(Q/'compile-summary.json')['compiles']],link_exit=read(Q/'link.result.json')['exit'],run_exit=read(Q/'run.result.json')['exit'],known_limits=['Tests execute canonical current loose object overrides plus an explicit validation-only observer. Current installed SDK is not signed.','No physical allocator/dispatch/tokens-per-second measurement. Pending graph-node elimination is the observation.','Normal dyadic F16/BF16 outputs are byte checked. Tiny/nonfinite widening uses the identical original mx::astype source path but was not separately GPU-tested here.','Budget escape case holds GraphOutput/Program, then observes last release zero. Independent sole derived-array alias is structurally reviewed, not separately executed.'],source_review=ident(P/'independent-source-review.json'),first_compile_red='Mac first lowering compile used const auto* for custom_as optional;fixed exactly two declarations.',first_runtime_red='Budget test omitted the required default system metadata resource in limits;setup rejected before any product conversion;fixed limits only.',installed_producer=ident(P/'apple/installed-producer-refresh-plan.json')))
print(json.dumps(dict(validation=ident(P/'apple/final-validation.json'),cleanup=ident(P/'apple/cleanup-inventory.json'),deletable_bytes=sum(x['bytes']for x in remote['deletable_files']),source_freeze=ident(P/'source-freeze.json')),indent=2))
