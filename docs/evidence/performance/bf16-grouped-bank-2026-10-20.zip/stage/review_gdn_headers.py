"""Read-only GDN include-identity check after canonical-header compile retry."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
OLD = STAGE.parent / 'gdn-typed-load'
CURRENT = STAGE.parent / 'gguf-nvfp4/cpu-cuda/native-source'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    old = {r['path']: r for r in json.loads((OLD / 'native-header-closure.json').read_text())['headers']}
    now = {r['path']: r for r in json.loads((STAGE / 'native-header-closure.json').read_text())['headers']}
    changed = [k for k in sorted(old.keys() | now.keys())
               if old.get(k, {}).get('sha256') != now.get(k, {}).get('sha256')]
    depfile = STAGE / 'checks/native1/native--gated_delta_net.d'
    deps = depfile.read_text()
    assert not any(Path(k).name in deps for k in changed)
    same = []
    for name in ('common.cuh', 'gated_delta_net.cuh', 'convert.cuh'):
        rel = 'src/ggml-cuda/' + name
        a = identity(OLD / 'native-source' / rel)
        b = identity(CURRENT / rel)
        assert a['sha256'] == b['sha256'] == old[rel]['sha256'] == now[rel]['sha256']
        same.append(dict(header=rel, old=a, current=b, identical=True))
    src = identity(OLD / 'native-source/src/ggml-cuda/gated_delta_net.cu')
    rebound = identity(STAGE / 'checks/native1/native-current-owners/src/ggml-cuda/gated_delta_net.cu')
    assert src['sha256'] == rebound['sha256']
    report = dict(
        status='No GDN mathematical header delta found; source-only identity review, no compiler/GPU invocation by reviewer.',
        source_before=src, source_materialized_for_retry=rebound,
        actual_dependency_file=identity(depfile),
        identical_GDN_headers=same,
        full_header_closure=dict(old_count=len(old), current_count=len(now),
            changed_headers=changed, changed_headers_present_in_actual_GDN_deps=False),
        interpretation=[
            'The source first includes gated_delta_net.cuh, which uses a relative common.cuh include, then includes ggml-cuda/common.cuh explicitly. Selecting the first through the old adjacent source directory and the second through canonical -I roots loads byte-identical common declarations from different physical files. pragma once is physical-file based and does not promise deduplication for independently copied identical headers.',
            'Materializing the exact unchanged CU in an otherwise header-free source location selects both include spellings from one canonical header tree. The retry source hash is unchanged; relevant common/gated_delta_net/convert header hashes are equal.',
            'The only complete-closure differences since old GDN are new mmid.cuh and changed mmvf.cuh/ssm-conv.cuh/unary.cuh. None occurs in the actual successful retry GDN dependency file, so these cannot change its compiled mathematical definitions.',
            'This comparison does not make all linked objects or old/current program.h ABI equivalent. Root refreshes actual owners independently; only the GDN source/header mathematical identity is established here.',
            'No source-based reason for a GDN arithmetic change was found. Generated code, runtime and any whole-model regression remain separate evidence.'
        ], build_run=False, GPU_run=False, product_modified=False)
    out = STAGE / 'gdn-header-review.json'
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(identity(out), indent=2))


if __name__ == '__main__':
    main()
