"""Compile one shared BF16 benchmark consumer against the accepted v29 image closure."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
base=c.read(h.P / "checks/native1/new-link-plan.json")
out=S / "checks/before"
out.mkdir(parents=True,exist_ok=False);(out / "tmp").mkdir()
recipe=c.read(h.P / "checks/native1/bench-pinned-identity.json")
source=S / "bench.cc"
command=b.host_command(recipe["command"],source,"bench",out)
frozen=b.identity(source)
for item in base["inputs"]:assert b.same(item),item["path"]
env,runtime=b.environment(base["command"],[row["path"] for row in base["inputs"]],out)
c.execute("bench-compile",command,env,out)
assert b.same(frozen)
data=c.read(out / "bench-deps.json")["Data"]
obj=b.identity(out / "bench.obj")
c.save(out / "bench-identity.json",dict(command=command,source=frozen,object=obj,
    dependencies=[b.identity(path) for path in dict.fromkeys([data["Source"],*data["Includes"]])]))
old=recipe["object"]
lookup={c.key(row["path"]):row for row in base["inputs"]}
lookup[c.key(obj["path"])]=obj
args=[]
for arg in base["command"]:
    if arg.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:")):continue
    args.append(obj["path"] if c.key(arg)==c.key(old["path"]) else arg)
image=out / "control.exe"
args += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
c.execute("control-link",args,env,out)
inputs=[arg for arg in args if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj",".lib")]
c.save(out / "control-link-plan.json",dict(command=args,inputs=[lookup[c.key(path)] for path in inputs]))
c.save(out / "control-image.json",b.identity(image))
c.save(out / "runtime-environment.json",dict(runtime=runtime,PATH=env["PATH"]))
print("BF16_GROUPED_BEFORE_BUILT",out,flush=True)
