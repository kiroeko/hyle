"""Run affected BF16 experts plus adjacent F32/NVFP4/explicit-Cast/CT regressions."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
build=S / "checks/native1"
out=S / "runs" / (sys.argv[1] if len(sys.argv)>1 else "first-actual")
out.mkdir(parents=True,exist_ok=False);(out / "tmp").mkdir()
image,link=c.read(build / "tests-image.json"),c.read(build / "tests-link-plan.json")
assert b.same(image)
for item in link["inputs"]:assert b.same(item),item["path"]
env,runtime=b.environment(link["command"],[r["path"] for r in link["inputs"]],out)
filters=["CudaGroupedShared.*","GgmlCudaGraph.*BfloatExpert*",
    "GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs",
    "GgmlCudaGraph.BfloatTypedElementwiseMatchesFloatRecipeAndKeepsEveryRoundingBoundary",
    "GgmlCudaGraph.BfloatChainsPreserveEveryRoundingAndPublishedIntermediate",
    "CudaCtPackedLinear.*"]
c.save(out / "runtime.json",dict(image=image,link=b.identity(build / "tests-link-plan.json"),runtime=runtime,filters=filters))
try:
    c.execute("tests",[image["path"],"--gtest_filter="+":".join(filters),
        "--gtest_output=xml:"+str(out / "results.xml")],env,out)
finally:
    cases=ET.parse(out / "results.xml").findall(".//testcase") if (out / "results.xml").is_file() else []
    passed=len(cases)==16 and all(case.find(tag) is None for case in cases for tag in ("failure","error","skipped"))
    c.save(out / "summary.json",dict(passed=passed,cases=len(cases),expected=16,
        names=[case.attrib["classname"]+"."+case.attrib["name"] for case in cases],
        skipped=sum(case.find("skipped") is not None for case in cases),image=image))
assert passed
print("BF16_GROUPED_ACTUAL",len(cases),"tests passed",flush=True)
