"""Keep owned-ready constants distinct from valid raw borrowed-constant fallback."""
from collections import Counter
import importlib.util
from pathlib import Path
import sqlite3
import statistics
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
paired={}
for variant,prefix,build in (("ready_owned_constant","owned","constant-owned"),
                             ("raw_borrowed_constant","constant","constant")):
    arms={}
    for arm in ("control","new"):
        rows=[c.read(S / "runs" / f"{prefix}-{arm}-p{index}" / "summary.json") for index in (1,2,3)]
        assert all(row["passed"] and row["warmup"]==512 and row["iterations"]==512 and row["caller_cpu"]==2 for row in rows)
        medians=[row["submit_and_wait_ns_median"] for row in rows]
        arms[arm]=dict(process_medians_ns=medians,median_of_process_medians_ns=statistics.median(medians),
            caller_workspace_bytes=rows[0]["reported_caller_workspace_bytes"],packed_constant_bytes=rows[0]["packed_constant_bytes"],
            images=[row["image"] for row in rows])
    a,z=arms["control"]["median_of_process_medians_ns"],arms["new"]["median_of_process_medians_ns"]
    paired[variant]=dict(**arms,latency_change_percent=100*(z/a-1),
        order=["control1","new1","new2","control2","control3","new3"],
        timing="Already prepared public command Invocation::submit through Completion::wait; no compile/packing/upload or final output D2H",
        conclusion="No demonstrated stable latency gain; process spread overlaps, remove 32MiB extra resident F32 pack" if prefix=="owned" else
            "Valid raw constant has no ready owner for old queued cold packing, so old whole-bank cast stays in replay; this is not the strongest old constant baseline")
    plans={arm:c.read(S / "checks" / build / (arm+"-link-plan.json")) for arm in ("control","new")}
    left,right=plans["control"]["inputs"],plans["new"]["inputs"]
    assert len(left)==len(right)
    differences=[];identical=[]
    for before,after in zip(left,right):
        assert b.same(before) and b.same(after)
        if before==after: identical.append(before)
        else: differences.append(dict(before=before,after=after))
    assert len(differences)==9,len(differences)
    c.save(S / (build+"-matched-link-check.json"),dict(passed=True,identical_inputs=len(identical),changed_inputs=differences,
        scope="One common benchmark object; only three changed host and six required native owners differ, all remaining input objects/libraries shared",
        no_SDK_build=True))
c.save(S / "paired-results.json",dict(variants=paired,limitations=[
    "Synthetic T1/S4/E8/N512/K2048; repeated IDs select expert0. This is not whole-model MoE/Qwen throughput.",
    "No GPU frequency lock, device total peak or quality result; desktop is present. Each process has 512 warmups and 512 measurements on caller core2.",
    "Three process medians are kept; per-iteration samples and exact bounds remain in runs.",
    "Preferred constant comparison has actual StorageOwner/ReadLease in both arms. Raw borrowed constants are separately retained, not substituted as the best control."] ))

traces={}
for arm in ("control","new"):
    path=S / "profile" / arm / "trace.sqlite"
    conn=sqlite3.connect(path);conn.row_factory=sqlite3.Row
    def rows(query):return [dict(row) for row in conn.execute(query)]
    kernels=rows("select k.start,k.end,k.correlationId,s.value name from CUPTI_ACTIVITY_KIND_KERNEL k join StringIds s on s.id=k.demangledName order by k.start")
    copies=rows("select start,end,bytes,copyKind from CUPTI_ACTIVITY_KIND_MEMCPY order by start")
    apis=rows("select r.start,r.end,s.value name from CUPTI_ACTIVITY_KIND_RUNTIME r join StringIds s on s.id=r.nameId order by r.start")
    checks=[row for row in kernels if "::check(" in row["name"]]
    publishes=[row for row in kernels if "::publish(" in row["name"]]
    assert len(checks)==len(publishes)==1
    start,end=checks[0]["start"],publishes[0]["end"]
    overlap=lambda row:row["start"]<end and row["end"]>start
    hot=[row for row in kernels if overlap(row)]
    assert len(hot)==3 and "mul_mat_vec_f" in hot[1]["name"] and "void, (bool)1>" in hot[1]["name"]
    assert ("__nv_bfloat16" in hot[1]["name"])==(arm=="new")
    assert not [row for row in copies if overlap(row)]
    assert not [row for row in apis if "StreamSynchronize" in row["name"] and overlap(row)]
    assert any(row["bytes"]==4 and row["copyKind"]==2 and row["start"]>=end for row in copies)
    cold=[row for row in kernels if row["end"]<=start]
    assert len(cold)==(1 if arm=="control" else 0)
    if cold:assert "cpy_scalar_contiguous<__nv_bfloat16, float>" in cold[0]["name"]
    traces[arm]=dict(all_kernels=kernels,cold_preparation_kernels=cold,hot_kernels=hot,
        operation_window_ns=dict(start=start,end=end),all_copies=copies,
        operation_copies=[],operation_stream_synchronizations=[],
        all_process_stream_synchronizations=dict(Counter(row["name"] for row in apis if "StreamSynchronize" in row["name"])))
c.save(S / "profile-analysis.json",dict(passed=True,variant="Actual ready-owned constant consumer, one cold preparation and one command invocation per arm",arms=traces,
    result="Hot kernels remain three in both arms. Old cold whole-bank BF16->F32 preparation is absent; new dot reads BF16 directly with strict F32 arithmetic.",
    retained="Original checked IDs, guarded publication and asynchronous4-byte Completion status plus final explicit result readback",
    limitation="This zero-warmup trace establishes physical shape only; its cold timings are not the accepted latency benchmark or a total-memory-peak measurement."))
print("BF16_GROUPED_ANALYSIS",[(key,value["control"]["median_of_process_medians_ns"],value["new"]["median_of_process_medians_ns"]) for key,value in paired.items()],flush=True)
