"""Dump only the 32 actual strict F32/BF16 ID specializations, not all kernels."""
import importlib.util
from pathlib import Path
import re
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S / "sass";out.mkdir(exist_ok=False);(out / "tmp").mkdir()
build=S / "checks/native1"
receipt=c.read(build / "native--mmvf-identity.json")
assert b.same(receipt["source"]) and b.same(receipt["object"])
for item in receipt["dependencies"]: assert b.same(item),item["path"]
base=c.read(build / "new-link-plan.json")
env,_=b.environment(base["command"],[r["path"] for r in base["inputs"]],out)
tool=Path("C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/cuobjdump.exe")
c.execute("symbols",[str(tool),"--dump-elf-symbols",receipt["object"]["path"]],env,out)
raw=(out / "symbols.stdout.log").read_text(encoding="utf-8-sig")
names=sorted(set(re.findall(r"\b(_Z13mul_mat_vec_f\S+)",raw)))
names=[name for name in names if "vLb1EE" in name]
assert len(names)==32,len(names)
c.execute("strict-sass",[str(tool),"--dump-sass","--function",",".join(names),receipt["object"]["path"]],env,out)
text=(out / "strict-sass.stdout.log").read_text(encoding="utf-8-sig")
functions=list(re.finditer(r"Function\s*:\s*(\S+)",text))
rows=[]
for index,match in enumerate(functions):
    name=match.group(1)
    body=text[match.start():functions[index+1].start() if index+1<len(functions) else len(text)]
    row=dict(name=name,weight_type="BF16" if "bfloat" in name else "F32",
        FFMA=bool(re.search(r"\bFFMA\b",body)),FADD=bool(re.search(r"\bFADD\b",body)),FTZ_modifier=".FTZ" in body)
    assert name in names and row["FFMA"] and row["FADD"] and not row["FTZ_modifier"],row
    rows.append(row)
assert len(rows)==32 and sum(row["weight_type"]=="BF16" for row in rows)==16
c.save(S / "sass-math-check.json",dict(passed=True,architecture="sm89",entries=rows,
    actual_object=receipt["object"],tool=b.identity(tool),selected_disassembly=b.identity(out / "strict-sass.stdout.log"),
    limitation="Only actual SM89 cubin strict specializations, not a blanket device or floating-payload proof; native emits no PTX."))
print("BF16_GROUPED_STRICT_SASS",len(rows),"entries, no FTZ",flush=True)
