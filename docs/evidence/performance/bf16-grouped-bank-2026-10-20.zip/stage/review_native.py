"""Source-only delta/identity checks. Does not compile or submit GPU work."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    freeze = json.loads((STAGE / 'native-source-freeze.json').read_text())
    edits = json.loads((STAGE / 'replacements.json').read_text())['files']
    inverse = []
    for file in edits:
        after = STAGE / 'native-source' / file['path']
        restored = after.read_text()
        for edit in reversed(file['edits']):
            assert restored.count(edit['after']) == 1, file['path']
            restored = restored.replace(edit['after'], edit['before'], 1)
        before = STAGE / 'before' / file['path']
        assert restored.encode() == before.read_bytes(), file['path']
        inverse.append(dict(file=file['path'], unique_reverse_edits=len(file['edits']),
                            equals_exact_v29_source=True))
    headers = json.loads((STAGE / 'native-header-closure.json').read_text())['headers']
    for row in headers:
        assert identity(Path(row['source']))['sha256'] == row['sha256'], row['path']
    assert [r['path'] for r in headers if r['changed']] == ['src/ggml-cuda/mmvf.cuh']
    for name, sha in freeze['sources'].items():
        assert identity(STAGE / 'native-source' / name)['sha256'] == sha, name
    report = dict(
        status='source review complete; independent review and actual compilation/numerics remain separate',
        version=freeze['version'], source_id=freeze['source_id'],
        freeze=identity(STAGE / 'native-source-freeze.json'),
        source_identities=[identity(STAGE / 'native-source' / name) for name in freeze['sources']],
        reversible_delta=inverse,
        header_identity_check=dict(count=len(headers), changed=['src/ggml-cuda/mmvf.cuh']),
        findings=[
            dict(source='ggml-cuda.cu:2222,2390,2465,2510',
                 fact='Strict mixed identity requires NVIDIA, BF16 weights, F32 activation/output, F32 accumulator and source1 markers. Dispatch and capture use the same ID-MMVF predicate. BF16 tensor-core MMF is excluded for this identity.'),
            dict(source='mmvf.cu:352-384; ggml-cuda.cu:2406-2439',
                 fact='Actual BF16 pair/stride/index spans are validated before the unchanged bounded F32 arithmetic preference. Ampere T<=3 is retained without the old BF16 N<=512/E1 preference. Actual GPU launch caps, I32 offsets and view/payload alignment remain qualified.'),
            dict(source='mmvf.cuh:35-59,308-323,398+',
                 fact='BF16 pairs are widened by uint32 bit placement. F32 activations are float2 loads. The existing strict explicit fma.rn.f32/add.rn.f32 helpers, original column order, shuffle/shared reduction and barriers are reused. Source-level PTX spells no FTZ; generated code and witnesses require actual validation.'),
            dict(source='ggml-cuda.cu:2525-2635; 1735-1762',
                 fact='Misses retain F32 sorted activation and both parent precision markers. Each nonempty expert slice invokes the existing F32 cuBLAS specialization. Its weight conversion is N*K F32 temporary for this slice; it does not construct a persistent E*N*K bank or narrow activation. Existing host ID sorting and synchronization remain.'),
            dict(source='ggml-cuda.cu:2240-2245; mmvf.cuh/mmvf.cu reversible delta',
                 fact='Only strict mixed indexed epilogues are declined to avoid the old fast-math dot/epilogue. Default-false BF16, original strict F32-ID code, quantized and AMD domains retain their prior arithmetic/selection. Relative to v29 host-widened F32, fusion and performance may change; no blanket equality/performance claim.'),
            dict(source='convert.cu via original cuda_bf16.hpp __internal_device_bfloat162float',
                 fact='Existing BF16-to-F32 conversion uses cvt.f32.bf16 or bit mov and preserves exact source widening; convert.cu remains unchanged. SDK is not copied or modified.')
        ],
        required_actual_evidence=[
            'Compile the actual mmvf.cuh owners and inspect strict generated arithmetic if needed.',
            'W=1,A=1+2^-20; BF16 Wbits0x0008*A2^120; BF16 W2^120*Abits0x00080000.',
            'Odd K37 and T9 fallback, A1/AS/slot0, repeated/invalid IDs and ordinary explicit-Cast neighbour.',
            'Report retained bank/temporary memory and real capture/route facts; no throughput assertion from source.'
        ],
        compile_run=False, GPU_run=False, SDK_modified=False)
    out = STAGE / 'native-implementation-review.json'
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(identity(out), indent=2))


if __name__ == '__main__':
    main()
