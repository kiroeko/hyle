"""Share one constant-weight consumer object across the real v29/v30 closures."""
import importlib.util
import argparse
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
parser=argparse.ArgumentParser();parser.add_argument("--name",default="constant-owned")
args=parser.parse_args();assert Path(args.name).name==args.name
out=S / "checks" / args.name
out.mkdir(parents=True,exist_ok=False);(out / "tmp").mkdir()
source=S / "constant-bench.cc"
original=c.read(S / "checks/before/bench-identity.json")
command=b.host_command(original["command"],source,"bench",out)
base=c.read(S / "checks/native1/control-link-plan.json")
env,runtime=b.environment(base["command"],[row["path"] for row in base["inputs"]],out)
frozen=b.identity(source)
c.execute("bench-compile",command,env,out)
assert b.same(frozen)
data=c.read(out / "bench-deps.json")["Data"]
obj=b.identity(out / "bench.obj")
c.save(out / "bench-identity.json",dict(command=command,source=frozen,object=obj,
    dependencies=[b.identity(path) for path in dict.fromkeys([data["Source"],*data["Includes"]])]))
for arm in ("control","new"):
    base=c.read(S / "checks/native1" / (arm+"-link-plan.json"))
    for row in base["inputs"]:assert b.same(row),row["path"]
    args=[]
    for arg in base["command"]:
        if arg.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:")):continue
        args.append(obj["path"] if c.key(arg)==c.key(original["object"]["path"]) else arg)
    image=out / (arm+".exe")
    args += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
    c.execute(arm+"-link",args,env,out)
    lookup={c.key(row["path"]):row for row in base["inputs"]};lookup[c.key(obj["path"])]=obj
    inputs=[arg for arg in args if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj",".lib")]
    assert sum(c.key(path)==c.key(obj["path"]) for path in inputs)==1
    c.save(out / (arm+"-link-plan.json"),dict(command=args,inputs=[lookup[c.key(path)] for path in inputs]))
    c.save(out / (arm+"-image.json"),b.identity(image))
c.save(out / "runtime-environment.json",dict(runtime=runtime,PATH=env["PATH"]))
print("BF16_GROUPED_CONSTANT_BUILT",out,flush=True)
