"""Extend the original mixed grouped carrier; no build/GPU or SDK mutation."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('plain_helpers',
    STAGE.parent / 'plain-grouped-cuda/prepare_native.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
n = p.n
NAMES = p.NAMES


def main():
    assert not (STAGE / 'native-source-freeze.json').exists()
    manifest = n.read(STAGE / 'product-before/third_party/ggml_cuda_runtime/patches.json')
    rows = {r['path']: r for r in manifest['files']}
    source = {name: n.replay(rows[name]).decode() for name in NAMES}
    changes = {name: [] for name in NAMES}

    def edit(name, old, new):
        assert source[name].count(old) == 1, (name, old[:100])
        source[name] = source[name].replace(old, new, 1)
        changes[name].append(dict(before=old, after=new))

    main_name, header, host = NAMES
    identity = '''// This contract keeps the original BF16 weight values and F32 activation
// values. BF16 tensor-core operands are not a substitute for source1 F32.
static bool ggml_cuda_mul_mat_id_bf16_f32(const ggml_tensor * dst, int cc) {
    return GGML_CUDA_CC_IS_NVIDIA(cc) && dst->op == GGML_OP_MUL_MAT_ID &&
        dst->src[0]->type == GGML_TYPE_BF16 && dst->src[1]->type == GGML_TYPE_F32 &&
        dst->type == GGML_TYPE_F32 && ggml_get_op_params_i32(dst, 0) == GGML_PREC_F32 &&
        ggml_get_op_params_i32(dst, 3) == GGML_PREC_F32;
}

'''
    anchor = 'static bool ggml_cuda_should_fuse_mul_mat_vec_f(const ggml_tensor * tensor) {'
    edit(main_name, anchor, identity + anchor)
    old = '    const int cc      = ggml_cuda_info().devices[ggml_cuda_get_device()].cc;\n    use_mul_mat_vec_f = use_mul_mat_vec_f &&'
    new = '''    const int cc      = ggml_cuda_info().devices[ggml_cuda_get_device()].cc;
    // Existing indexed fusion uses default fast-math dot/epilogue stages.
    // Keep strict mixed BF16 weights as separate native operations instead.
    if (ggml_cuda_mul_mat_id_bf16_f32(tensor, cc)) {
        return false;
    }
    use_mul_mat_vec_f = use_mul_mat_vec_f &&'''
    edit(main_name, old, new)
    edit(main_name, 'if (!GGML_CUDA_CC_IS_NVIDIA(cc) || w->type != GGML_TYPE_F32 ||',
         'if (!GGML_CUDA_CC_IS_NVIDIA(cc) ||\n            (w->type != GGML_TYPE_F32 && !ggml_cuda_mul_mat_id_bf16_f32(dst, cc)) ||')
    edit(main_name, '''        if (value->nb[0] != sizeof(float)) return false;
        size_t span = sizeof(float);''', '''        const size_t element = ggml_type_size(value->type);
        if (value->nb[0] != element) return false;
        size_t span = element;''')
    edit(main_name, '''value->nb[axis] % sizeof(float) != 0 ||
                    value->nb[axis] / sizeof(float) > INT_MAX''',
         '''value->nb[axis] % element != 0 ||
                    value->nb[axis] / element > INT_MAX''')
    edit(main_name, '''        if (span / sizeof(float) > INT_MAX) return false;
        const size_t alignment = pairs ? 2 * sizeof(float) : sizeof(float);''',
         '''        if (span / element > INT_MAX) return false;
        const size_t alignment = pairs ? 2 * element : element;''')
    edit(main_name, 'ggml_cuda_should_use_mmvf(w->type, cc, w->ne, w->nb, a->ne[2]))',
         'ggml_cuda_should_use_mmvf(w->type, cc, w->ne, w->nb, a->ne[2], ggml_cuda_mul_mat_id_bf16_f32(dst, cc)))')
    old = '''    if (!(src0->type == GGML_TYPE_F32 && dst->op_params[0] == GGML_PREC_F32) &&
        ggml_cuda_should_use_mmf(src0->type, cc, WARP_SIZE, src0->ne, src0->nb, src1->ne[2], /*mul_mat_id=*/true)) {'''
    edit(main_name, old, old.replace('if (!(', 'if (!ggml_cuda_mul_mat_id_bf16_f32(dst, cc) &&\n        !(', 1))
    old = '''        if (!(src0->type == GGML_TYPE_F32 && dst->op_params[0] == GGML_PREC_F32) &&
            ggml_cuda_should_use_mmf(src0->type, cc, WARP_SIZE, src0->ne, src0->nb, src1->ne[2], /*mul_mat_id=*/true)) {'''
    edit(main_name, old, old.replace('if (!(', 'if (!ggml_cuda_mul_mat_id_bf16_f32(dst, cc) &&\n            !(', 1))
    edit(main_name, '''    const ggml_type type_src1_sorted = (src0->type == GGML_TYPE_F16 && !fast_fp16_hardware_available(cc))
        || ggml_is_quantized(src0->type) ? GGML_TYPE_F32 : src0->type;''',
         '''    const ggml_type type_src1_sorted = ggml_cuda_mul_mat_id_bf16_f32(dst, cc) ||
        (src0->type == GGML_TYPE_F16 && !fast_fp16_hardware_available(cc)) ||
        ggml_is_quantized(src0->type) ? GGML_TYPE_F32 : src0->type;''')
    edit(main_name, '        ggml_cuda_mul_mat(ctx, &src0_slice, &src1_slice, &dst_slice);',
         '''        if (ggml_cuda_mul_mat_id_bf16_f32(dst, cc)) {
            // The existing F32 cuBLAS carrier widens this one expert slice,
            // not the E*N*K bank. F32 source1 is reused without conversion.
            ggml_cuda_mul_mat_cublas_impl<GGML_TYPE_F32>(ctx, &src0_slice, &src1_slice, &dst_slice);
        } else {
            ggml_cuda_mul_mat(ctx, &src0_slice, &src1_slice, &dst_slice);
        }''')

    edit(header, '''static_assert(!strict_f32_ids || (std::is_same_v<T, float> && std::is_same_v<Y, float> &&''',
         '''static_assert(!strict_f32_ids || ((std::is_same_v<T, float> || std::is_same_v<T, nv_bfloat16>) && std::is_same_v<Y, float> &&''')
    edit(header, 'bool ggml_cuda_should_use_mmvf(enum ggml_type type, int cc, const int64_t * src0_ne, const size_t * src0_nb, int64_t ne11);',
         'bool ggml_cuda_should_use_mmvf(enum ggml_type type, int cc, const int64_t * src0_ne, const size_t * src0_nb, int64_t ne11, bool strict_f32_source = false);')
    old = '    } else if constexpr (std::is_same_v<T, nv_bfloat16>) {\n//TODO:'
    new = '''    } else if constexpr (std::is_same_v<T, nv_bfloat16> && strict_f32_ids) {
        // BF16 widening is an exact bit placement, including subnormals.
        // No F32 activation or partial sum passes through a low-type cast.
        const uint32_t * x2 = (const uint32_t *) x;
        for (int col2 = tid; col2 < ncols2; col2 += block_size) {
            const uint32_t pair = x2[col2];
            const float x0 = __uint_as_float(pair << 16);
            const float x1 = __uint_as_float(pair & 0xffff0000u);
#pragma unroll
            for (int j = 0; j < ncols_dst; ++j) {
                const float2 tmpy = load_pair(j*stride_col_y2 + col2);
                ggml_cuda_mmvf_mad<true>(sumf[j], x0, tmpy.x);
                ggml_cuda_mmvf_mad<true>(sumf[j], x1, tmpy.y);
            }
        }
    } else if constexpr (std::is_same_v<T, nv_bfloat16>) {
//TODO:'''
    edit(header, old, new)
    edit(host, '''template<typename T, typename Y = float, typename Dst = float>
static void mul_mat_vec_f_cuda(''',
         '''template<typename T, typename Y = float, typename Dst = float, bool strict_bf16_source = false>
static void mul_mat_vec_f_cuda(''')
    edit(host, '''if constexpr (std::is_same_v<T, float> && std::is_same_v<Y, float> && std::is_same_v<Dst, float>) {''',
         '''if constexpr ((std::is_same_v<T, float> || (std::is_same_v<T, nv_bfloat16> && strict_bf16_source)) &&
                std::is_same_v<Y, float> && std::is_same_v<Dst, float>) {''')
    old = '''        case GGML_TYPE_BF16: {
            const nv_bfloat16 * src0_d = (const nv_bfloat16 *) src0->data;
            mul_mat_vec_f_cuda(src0_d, src1_d, ids_d, fusion_local, dst_d, ne00, ne01, ncols_dst, s01, stride_col_y, stride_col_dst,
                ne02, nchannels_y, nchannels_dst, s02, stride_channel_y, stride_channel_dst,
                ne03,              ne3,           s03, s13,              s3,                 ids_stride, prec, ctx.stream());
        } break;'''
    new = '''        case GGML_TYPE_BF16: {
            const nv_bfloat16 * src0_d = (const nv_bfloat16 *) src0->data;
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
            if (ids && precision == GGML_PREC_F32 && ggml_get_op_params_i32(dst, 3) == GGML_PREC_F32 &&
                    GGML_CUDA_CC_IS_NVIDIA(cc) && !fusion) {
                mul_mat_vec_f_cuda<nv_bfloat16, float, float, true>(src0_d, src1_d, ids_d, fusion_local, dst_d,
                    ne00, ne01, ncols_dst, s01, stride_col_y, stride_col_dst,
                    ne02, nchannels_y, nchannels_dst, s02, stride_channel_y, stride_channel_dst,
                    ne03, ne3, s03, s13, s3, ids_stride, prec, ctx.stream());
                break;
            }
#endif
            mul_mat_vec_f_cuda(src0_d, src1_d, ids_d, fusion_local, dst_d, ne00, ne01, ncols_dst, s01, stride_col_y, stride_col_dst,
                ne02, nchannels_y, nchannels_dst, s02, stride_channel_y, stride_channel_dst,
                ne03,              ne3,           s03, s13,              s3,                 ids_stride, prec, ctx.stream());
        } break;'''
    edit(host, old, new)
    edit(host, 'bool ggml_cuda_should_use_mmvf(enum ggml_type type, int cc, const int64_t * src0_ne, const size_t * src0_nb, int64_t ne11) {',
         'bool ggml_cuda_should_use_mmvf(enum ggml_type type, int cc, const int64_t * src0_ne, const size_t * src0_nb, int64_t ne11, bool strict_f32_source) {')
    old = '''    switch (type) {
        case GGML_TYPE_F32:
            if (GGML_CUDA_CC_IS_NVIDIA(cc)) {'''
    new = '''    // Pair/stride eligibility above uses physical weight storage. The strict
    // mixed BF16/F32 domain has F32 arithmetic and cannot use BF16 tensor-core
    // operands, so compare its algorithms with the existing F32 preference.
    const ggml_type preference = strict_f32_source && type == GGML_TYPE_BF16 && GGML_CUDA_CC_IS_NVIDIA(cc)
        ? GGML_TYPE_F32 : type;
    switch (preference) {
        case GGML_TYPE_F32:
            if (GGML_CUDA_CC_IS_NVIDIA(cc)) {'''
    edit(host, old, new)

    for name in NAMES:
        rows[name]['edits'].extend(changes[name]); rows[name]['after_sha256'] = n.sha(source[name].encode())
    draft = STAGE / 'patches-draft.json'; n.save(draft, manifest)
    n.load('prepare_cuda_iq1_manifest').derive(n.UPSTREAM, STAGE / 'mixed-cpu-manifest.json', draft,
        n.VENDOR / 'iq1-patches.json', STAGE / 'combined-manifest.json')
    before_full = {r['path']: n.replay(r) for r in n.read(STAGE / 'before-combined-manifest.json')['files']}
    full = {r['path']: n.replay(r) for r in n.read(STAGE / 'combined-manifest.json')['files']}
    assert {name for name in full if full[name] != before_full[name]} == set(NAMES)
    for name in NAMES + ['src/ggml-cuda/unary.cu']:
        out = STAGE / 'native-source' / name; out.parent.mkdir(parents=True, exist_ok=True); out.write_bytes(full[name])
    n.save(STAGE / 'replacements.json', dict(files=[dict(path=k, edits=v) for k, v in changes.items()]))
    (STAGE / 'native-changes.diff').write_text(''.join(''.join(difflib.unified_diff(
        before_full[name].decode().splitlines(True), full[name].decode().splitlines(True),
        'before/' + name, 'after/' + name)) for name in NAMES), encoding='utf-8', newline='\n')
    (n.VENDOR / 'patches.json').write_bytes(draft.read_bytes())
    notice = n.VENDOR / 'NOTICE.md'
    notice.write_text((STAGE / 'product-before/third_party/ggml_cuda_runtime/NOTICE.md').read_text().rstrip() + '''

An indexed NVIDIA BF16-weight/F32-activation/F32-output operation requesting
both F32 accumulation and F32 source1 now retains that actual mixed contract.
The original small-token MMVF reads each BF16 pair by exact bit widening and
reuses the strict RN no-FTZ FMA and original reduction tree. Its metadata
qualification measures pair alignment, strides and index spans in the actual
weight element width. Only this strict mixed contract reuses the original
bounded F32 arithmetic preference, since a BF16 tensor-core alternative would
narrow its activation; default callers retain their original preferences.
Existing default-false arithmetic, the strict F32-ID path and other backends
remain unchanged. The old indexed fused epilogues are declined only for this
new strict mixed domain so their default fast-math dot cannot bypass it.

Other shapes, including odd reduction widths and larger token counts, keep
the original host-sorted expert execution and both parent precision markers.
Strict mixed activations sort as F32, BF16 MMF is not used, and each nonempty
expert calls the original F32 cuBLAS carrier. Its existing conversion expands
only that expert's N*K slice into a pooled temporary; it does not construct a
persistent F32 E*N*K bank or narrow F32 activations. Sorting, synchronization,
pool/workspace ownership and checked publication remain real costs. A previous
widened-F32 bank could admit different fusion/preferences, so no universal
latency or fusion-count improvement is implied by this storage reduction.
''', encoding='utf-8', newline='\n')
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'; lock = n.read(lock_path)
    entries = {r['name']: r for r in lock['dependencies']}; tree = n.tree(n.VENDOR)
    entry = entries['ggml_cuda_runtime_patches']; entry['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v30'
    entry['vendored']['tree_sha256'] = tree
    for item in entry['license']['files']:
        if item['root'] == 'hyle' and item['path'] == 'third_party/ggml_cuda_runtime/NOTICE.md':
            item['sha256'] = n.sha(notice.read_bytes())
    n.save(lock_path, lock)
    sid = n.sha((entries['ggml_runtime_patches']['vendored']['tree_sha256'] +
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        n.sha((ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        n.sha((ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) + tree).encode())[:16]
    (STAGE / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + sid + '"\n', encoding='utf-8')
    prior = n.read(STAGE.parent / 'plain-grouped-cuda/native-header-closure.json'); headers = []
    for item in prior['headers']:
        name = item['path']; data = full[name] if name in full else n.original(name)
        before = before_full[name] if name in before_full else n.original(name)
        assert n.sha(before) == item['sha256'], name
        actual = STAGE / 'native-source' / name if name in NAMES else Path(item['source'])
        assert actual.read_bytes() == data, name
        headers.append(dict(path=name, bytes=len(data), sha256=n.sha(data), source=str(actual), changed=data != before))
    n.save(STAGE / 'native-header-closure.json', dict(headers=headers, header_count=len(headers)))
    n.save(STAGE / 'native-source-freeze.json', dict(version=entry['version'], source_id=sid,
        files=[dict(path=name, before=n.identity(STAGE / 'before' / name), after=n.identity(STAGE / 'native-source' / name)) for name in NAMES],
        sources={name: n.sha(full[name]) for name in NAMES + ['src/ggml-cuda/unary.cu']},
        header_root=prior.get('previous_header_root'), header_closure=n.identity(STAGE / 'native-header-closure.json'),
        native_TUs_requiring_refresh=['ggml-cuda.cu', 'mmvf.cu', 'unary.cu'],
        native_unchanged_TUs='convert.cu and all other native kernels retain source/header definitions; actual BF16 conversion already uses exact source widening',
        changed_private_template_header='mmvf.cuh, only original three include owners',
        public_or_struct_ABI_changed=False, compile_run=False, GPU_run=False, SDK_modified=False,
        product_files=[n.identity(ROOT / rel) for rel in ['third_party/ggml_cuda_runtime/patches.json', 'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json']]))
    n.save(STAGE / 'cuda-lock-proposal.json', dict(dependency=entry['name'], version=entry['version'], source_id=sid,
        vendored_tree_sha256=tree, notice_sha256=n.sha(notice.read_bytes()), central_lock_modified=True))
    print(json.dumps(n.read(STAGE / 'cuda-lock-proposal.json'), indent=2))


if __name__ == '__main__':
    main()
