#include "common.cuh"
#include "mmid.cuh"

// Build one compact entry for every actual (token,slot), including repeated
// experts in the same token. Keep the original token-major, slot-major order.
// Both passes are integer metadata only; quantization and dot math are unchanged.
template <int n_expert_used_template>
__launch_bounds__(ggml_cuda_get_physical_warp_size(), 1)
static __global__ void mm_ids_helper(
        const int32_t * __restrict__ ids, int32_t * __restrict__ ids_src1, int32_t * __restrict__ ids_dst, int32_t * __restrict__ expert_bounds,
        const int n_tokens, const int n_expert_used_var, const int nchannels_y, const int si1, const int sis1, const bool write_inverse) {
    constexpr int warp_size = ggml_cuda_get_physical_warp_size();
    const int n_expert_used = n_expert_used_template == 0 ? n_expert_used_var : n_expert_used_template;
    const int expert = blockIdx.x;
    const int64_t nslots = int64_t(n_tokens)*n_expert_used;

    int nex_prev = 0;
    for (int64_t flat = threadIdx.x; flat < nslots; flat += warp_size) {
        const int it = int(flat / n_expert_used);
        const int slot = int(flat % n_expert_used);
        nex_prev += ids[int64_t(it)*si1 + slot] < expert;
    }
    nex_prev = warp_reduce_sum<warp_size>(nex_prev);

    int it_compact = 0;
    for (int64_t base = 0; base < nslots; base += warp_size) {
        const int64_t flat = base + threadIdx.x;
        const int it = int(flat / n_expert_used);
        const int slot = int(flat % n_expert_used);
        const bool match = flat < nslots && ids[int64_t(it)*si1 + slot] == expert;
        int prefix = match ? 1 : 0;
#pragma unroll
        for (int offset = 1; offset < warp_size; offset <<= 1) {
            const int lower = __shfl_up_sync(0xFFFFFFFF, prefix, offset, warp_size);
            if (threadIdx.x >= static_cast<unsigned int>(offset)) {
                prefix += lower;
            }
        }
        if (match) {
            const int compact = nex_prev + it_compact + prefix - 1;
            ids_dst[compact] = int(flat);
            if (write_inverse) {
                ids_src1[flat] = compact;
            } else {
                ids_src1[compact] = it*sis1 + slot % nchannels_y;
            }
        }
        it_compact += __shfl_sync(0xFFFFFFFF, prefix, warp_size - 1, warp_size);
    }

    if (threadIdx.x == 0) {
        expert_bounds[expert] = nex_prev;
        if (expert == static_cast<int>(gridDim.x) - 1) {
            expert_bounds[gridDim.x] = nex_prev + it_compact;
        }
    }
}

template <int n_expert_used_template>
static void launch_mm_ids_helper(
        const int32_t * __restrict__ ids, int32_t * __restrict__ ids_src1, int32_t * __restrict__ ids_dst, int32_t * __restrict__ expert_bounds,
        const int n_experts, const int n_tokens, const int n_expert_used_var, const int nchannels_y, const int si1, const int sis1, const bool write_inverse, cudaStream_t stream) {
    GGML_ASSERT(n_tokens >= 0 && n_expert_used_var >= 0);

    // Native maps store flattened output indices in I32. No per-token shared
    // store is needed: repeated slots are emitted directly to disjoint entries.
    GGML_ASSERT(n_expert_used_var == 0 || n_tokens <= INT_MAX/n_expert_used_var);
    const int id = ggml_cuda_get_device();
    const int warp_size = ggml_cuda_info().devices[id].warp_size;
    const dim3 num_blocks(n_experts, 1, 1);
    const dim3 block_size(warp_size, 1, 1);
    mm_ids_helper<n_expert_used_template><<<num_blocks, block_size, 0, stream>>>
        (ids, ids_src1, ids_dst, expert_bounds, n_tokens, n_expert_used_var, nchannels_y, si1, sis1, write_inverse);
}

void ggml_cuda_launch_mm_ids_helper(
        const int32_t * __restrict__ ids, int32_t * __restrict__ ids_src1, int32_t * __restrict__ ids_dst, int32_t * __restrict__ expert_bounds,
        const int n_experts, const int n_tokens, const int n_expert_used, const int nchannels_y, const int si1, const int sis1, const bool write_inverse, cudaStream_t stream) {
    switch (n_expert_used) {
        case  2:
            launch_mm_ids_helper< 2>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case  4:
            launch_mm_ids_helper< 4>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case  6:
            launch_mm_ids_helper< 6>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case  8:
            launch_mm_ids_helper< 8>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case 10:
            launch_mm_ids_helper<10>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case 16:
            launch_mm_ids_helper<16>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        case 32:
            launch_mm_ids_helper<32>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
        default:
            launch_mm_ids_helper< 0>(ids, ids_src1, ids_dst, expert_bounds, n_experts, n_tokens, n_expert_used, nchannels_y, si1, sis1, write_inverse, stream);
            break;
    }
}
