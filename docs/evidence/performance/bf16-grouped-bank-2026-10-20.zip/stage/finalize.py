"""Publish bounded actual results and source/command evidence; omit rebuildable binaries."""
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location("bf16_grouped_build",S / "build.py")
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
build=S / "checks/native1"
plan=c.read(build / "plan.json")
for item in plan["frozen"]:assert b.same(item),item["path"]
for arm in ("tests","control","new"):
    assert b.same(c.read(build / (arm+"-image.json")))
    for item in c.read(build / (arm+"-link-plan.json"))["inputs"]:assert b.same(item),item["path"]
for name in ("native-source-freeze.json","host-source-freeze.json","tests-source-freeze.json",
             "native-independent-review.json","tests-independent-review.json","gdn-header-review.json"):
    assert (S / name).is_file()
tests=c.read(S / "runs/with-CT-neighbours/summary.json")
assert tests["passed"] and tests["cases"]==16 and tests["skipped"]==0
sass=c.read(S / "sass-math-check.json");assert sass["passed"] and len(sass["entries"])==32
trace=c.read(S / "profile-analysis.json");assert trace["passed"]
paired=c.read(S / "paired-results.json")
cases=ET.parse(S / "runs/with-CT-neighbours/results.xml").findall(".//testcase")
properties={case.attrib["name"]:{row.attrib["name"]:row.attrib["value"] for row in case.findall("./properties/property")} for case in cases if case.find("properties") is not None}
products=["src/compute_provider_ggml_cuda/tensor_program.cc","src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
    "src/compute_provider_ggml_cuda/program.h","src/graph_provider_ggml_cuda/ggml_cuda_region.cc",
    "third_party/ggml_cuda_runtime/patches.json","third_party/ggml_cuda_runtime/NOTICE.md","cmake/HyleDependencyLock.json",
    "tests/graph_route_cuda/grouped_shared_activation_test.cc","tests/graph_provider_ggml_cuda/region_test.cc",
    "docs/user/compute.md","docs/developer/current-work.md","docs/implementation/model-operators.md"]
c.execute("diff-check",["git","diff","--check","--",*products],dict(__import__("os").environ),S)
c.execute("hardware",["nvidia-smi","--query-gpu=name,driver_version,memory.total,temperature.gpu,pstate","--format=csv,noheader"],dict(__import__("os").environ),S)
dynamic={name:c.read(S / "runs" / name / "summary.json") for name in (
    "baseline-witness","new-witness","baseline-larger-T9","new-larger-T9","baseline-larger-N1024","new-larger-N1024")}
assert all(row["passed"] for row in dynamic.values())
report=dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    scope="CUDA GroupedMatMul original BF16 expert bank, F32 activation/accumulator/output; not whole-model MoE or Qwen performance",
    source_identity=c.read(S / "native-source-freeze.json"),
    result="Remove unconditional E*N*K F32 bank cast, CUDA-only grouped cold widening factory/singleton; keep actual BF16 storage and exact F32 activation contract in native MMVF or original per-expert F32 cuBLAS fallback",
    design=["Graph/engine has no new backend/model/shape branch, option, public op or executor; original Prepared/Invocation/Completion/checked-output lifetimes remain",
        "SmallT reuses original bounded F32 arithmetic preference with actual BF16 element/pair/stride/span/device-grid checks; exact BF16 register bit widening including subnormals",
        "Original strict F32 no-FTZ FMA/reduction topology reused, legacy default/quantized/AMD math remains; native old mixed fused epilogues declined instead of silently narrowing activation",
        "OddK/largeT keep original F32 sorted activation and both precision markers; original computeF32 cuBLAS widens only one active expert N*K into pooled temporary"],
    actual_build=dict(unique_refreshed_native_owners=6,unique_refreshed_product_host_owners=3,refreshed_test_owners=2,
        cached_CT_test_owner_relinked=True,shared_dependency_cache=True,no_SDK_build=True,
        history=["First GDN compile failed on duplicate same-byte common headers from two physical snapshot paths; exact source materialized beside one canonical header closure, only failed TU retried",
            "Initial image ran12/12 but wrapper correctly rejected expected16 because cached CT tests were absent from link; added actual cached CT test object, final16/16 passed"],
        plan=b.identity(build / "plan.json"),image=tests["image"]),
    correctness=dict(actual_tests=tests,named_test_properties=properties,strict_compiled_code=sass,
        dynamic_and_boundary_consumers={name:{k:v for k,v in row.items() if k!="samples_ns"} for name,row in dynamic.items()},
        witnesses=["F32 activation 1+2^-20 remains bits0x3f800008", "BF16 Wbits0x0008 times F32 A2^120 equals bits0x3a800000", "BF16 W2^120 times F32 Abits0x00080000 equals bits0x3a800000"]),
    space=dict(ready_constant_original_BF16_payload_bytes=16777216,removed_extra_resident_F32_bank_bytes=33554432,
        ready_constant_caller_workspace_control_and_new_bytes=8192,
        dynamic_T1_caller_workspace_control_bytes=33562624,dynamic_T1_caller_workspace_new_bytes=8192,
        dynamic_T9_caller_workspace_control_bytes=33628160,dynamic_T9_caller_workspace_new_bytes=73728,
        small_borrowed_constants="E3 and E17: no materialized/packed F32 bank, workspace256B, compiled known bytes0 with one unknown provider; actual immutable lease retained",
        remaining="LargerT sorting O(T*S*(K+N)) floats/maps and host scan/sync remain; strict BF16 fallback adds a pooled4*N*K expert temporary. Native/vendor pool and total process/device peak not measured."),
    performance=paired,physical_trace=trace,
    not_claimed=["No stable latency gain for the strongest old ready-owned constant baseline (54.9us vs55.6us new, overlapping process spread)",
        "No new Qwen tokens/s, accuracy, long-run state or total GPU/CPU memory peak", "No selected27B/2.4T weight payload or complete MoE model run",
        "No current Linux/macOS validation; CPU widening unchanged; strict mixed indexed GLU remains to be fused", "No claim of zero native allocation/synchronization across fallback shapes"],
    evidence=dict(stage=str(S),products=[b.identity(ROOT / name) for name in products],
        reproduce=["python .scratch/architecture-refactor-2026-10-18/bf16-grouped-bank/build.py --build --resume",
            "python .scratch/architecture-refactor-2026-10-18/bf16-grouped-bank/run_cases.py NEW_UNIQUE_RUN_NAME"],
        source_and_command_archive="bf16-grouped-bank-2026-10-20.zip"),
    goal="Active; this completed batch does not complete architecture, model/operator/quantization coverage or cross-platform lifecycle requirements")
c.save(S / "summary.json",report)
public=ROOT / "docs/evidence/performance/bf16-grouped-bank-2026-10-20.json"
archive=public.with_suffix(".zip")
assert not archive.exists()
files={}
ignored={".exe",".obj",".lib",".exp",".pdb",".map",".pyc"}
for path in S.rglob("*"):
    if path.is_file() and path.suffix.lower() not in ignored and "tmp" not in path.relative_to(S).parts and path.name not in ("archive-manifest.json","publication.json"):
        files["stage/"+path.relative_to(S).as_posix()]=path
for name in products:files["product/"+name]=ROOT / name
manifest=[dict(name=name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in sorted(files.items())]
manifest_bytes=(json.dumps(dict(payloads=manifest,excluded="Rebuildable exe/obj/lib/maps/pdb, SDK and temporary directories"),ensure_ascii=False,indent=2)+"\n").encode("utf-8")
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr("manifest.json",manifest_bytes)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        payload=z.read(row["name"])
        assert len(payload)==row["bytes"] and hashlib.sha256(payload).hexdigest()==row["sha256"]
receipt=dict(archive=b.identity(archive),payload_count=len(manifest),manifest_entries=len(manifest)+1,all_payload_SHA256_checked=True,CRC_checked=True)
c.save(S / "archive-manifest.json",dict(payloads=manifest,receipt=receipt))
report["evidence"]["archive"]=receipt
c.save(public,report)
c.save(S / "publication.json",dict(report=b.identity(public),**receipt))
print("BF16_GROUPED_PUBLISHED",public,"archive bytes",receipt["archive"]["bytes"],"payloads",len(manifest),flush=True)
