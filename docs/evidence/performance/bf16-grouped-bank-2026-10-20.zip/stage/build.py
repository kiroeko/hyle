"""Focused mixed BF16 grouped increment, using the actual accepted v29 closure."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
P = S.parent / "plain-grouped-cuda"
spec = importlib.util.spec_from_file_location("bf16_grouped_helpers", S.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", type=Path, default=S / "checks/native1")
    p.add_argument("--build", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--only-link-tests", action="store_true")
    args = p.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "tmp").mkdir(exist_ok=True)
    bases = {arm: c.read(P / "checks/native1" / (name + "-link-plan.json"))
             for arm, name in (("tests", "tests"), ("bench", "new"))}
    metadata = h.metadata(bases)
    changed_sources = {c.key(ROOT / name) for name in (
        "src/compute_provider_ggml_cuda/tensor_program.cc",
        "src/compute_provider_ggml_cuda/ggml_cuda_provider.cc",
        "src/graph_provider_ggml_cuda/ggml_cuda_region.cc")}
    changed_header = c.key(ROOT / "src/compute_provider_ggml_cuda/program.h")
    owners, native, missing, header_native = [], {}, [], []
    for obj in {c.key(row["path"]): row for plan in bases.values() for row in plan["inputs"]}.values():
        if Path(obj["path"]).suffix.lower() != ".obj":
            continue
        row = metadata.get(c.key(obj["path"]))
        if not row:
            missing.append(obj)
            continue
        source = Path(row["source_path"])
        if source.name in ("ggml-cuda.cu", "mmvf.cu", "unary.cu"):
            native[source.name] = dict(row, old_object=obj)
        if c.key(source) in changed_sources or any(c.key(dep["path"]) == changed_header for dep in row["dependencies"]):
            if source.suffix.lower() == ".cu":
                if source.name not in native: header_native.append(dict(row,old_object=obj))
            elif source.is_relative_to(ROOT / "src"):
                owners.append(dict(row, old_object=obj))
    inventory = dict(bases={arm:str(P / "checks/native1" / (name + "-link-plan.json"))
        for arm,name in (("tests","tests"),("bench","new"))}, host_owners=owners,
        native_owners=native, private_header_native_owners=header_native, unresolved=missing,
        no_SDK_build=True, previous_turn="no progress: status reply; next safe action is current source implementation and focused compilation")
    c.save(S / "build-inventory.json", inventory)
    print("BF16_GROUPED_INVENTORY", len(owners), "host owners", len(native)+len(header_native), "native owners", "unresolved",len(missing),flush=True)
    if not args.build:
        return
    assert len(native) == 3
    assert {c.key(row["source_path"]) for row in owners} >= changed_sources
    freeze = c.read(S / "native-source-freeze.json")
    overlay = S / "native-source"
    headers = Path(c.read(P / "native-source-freeze.json")["header_root"])
    header_closure = c.read(S / "native-header-closure.json")["headers"]
    version = S / "provider-version.h"
    assert version.is_file()
    rows = []
    for owner in owners:
        source = Path(owner["source_path"])
        tag = source.parent.name + "--" + source.stem
        command = b.host_command(owner["command"], source, tag, out)
        command = ["/FI" + str(version) if arg.lower().startswith("/fi") and Path(arg[3:]).name == "provider-version.h" else arg for arg in command]
        rows.append(dict(tag=tag, kind="host", source=b.identity(source), command=command,
            object=str(out / (tag + ".obj")), old_object=owner["old_object"]))
    for name, owner in [*native.items(),*((Path(row["source_path"]).name,row) for row in header_native)]:
        source = overlay / "src/ggml-cuda" / name
        if not source.is_file(): source = P / "native-source/src/ggml-cuda" / name
        if not source.is_file(): source = Path(owner["source_path"])
        if source.name == "gated_delta_net.cu":
            # Its old cache contains adjacent headers. Compile the exact same
            # source beside no headers so both relative include spellings use
            # the one canonical closure, rather than two pragma-once files.
            original = source
            source = out / "native-current-owners/src/ggml-cuda/gated_delta_net.cu"
            source.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(original,source)
            assert b.identity(source)["sha256"] == b.identity(original)["sha256"]
        tag = "native--" + source.stem
        recipe, skip = [], False
        for arg in owner["command"]:
            if skip: skip=False
            elif arg in ("-ccbin", "--compiler-bindir"): skip=True
            elif not arg.startswith(("-ccbin=", "--compiler-bindir=")): recipe.append(arg)
        command = b.native_command(recipe, source, tag, out)
        command = [arg for arg in command if not (arg.startswith("-I") and (".scratch" in arg or "reference-windows" in arg))]
        command[1:1] = ["-I" + str(directory / name) for directory in (overlay, P / "native-source", headers)
                        for name in ("src/ggml-cuda", "src", "include")]
        command.insert(1, "-I" + str(ROOT / "src/compute_provider_ggml_cuda"))
        rows.append(dict(tag=tag, kind="native", source=b.identity(source), command=command,
            object=str(out / (tag + ".obj")), old_object=owner["old_object"]))
    test_recipe = c.read(P / "checks/native1/grouped-test-identity.json")["command"]
    for tag, name in (("grouped-test", "tests/graph_route_cuda/grouped_shared_activation_test.cc"),
                       ("region-test", "tests/graph_provider_ggml_cuda/region_test.cc")):
        source = ROOT / name
        command = b.host_command(test_recipe, source, tag, out)
        command[1:1] = ["/external:I" + str(directory / name) for directory in (overlay,P / "native-source",headers) for name in ("include","src")]
        rows.append(dict(tag=tag, kind="host", source=b.identity(source), command=command,
            object=str(out / (tag + ".obj"))))
    frozen = [b.identity(ROOT / name) for name in (
        "src/compute_provider_ggml_cuda/program.h", "third_party/ggml_cuda_runtime/patches.json",
        "third_party/ggml_cuda_runtime/NOTICE.md", "cmake/HyleDependencyLock.json")]
    frozen += [b.identity(path) for path in overlay.rglob("*") if path.is_file()]
    frozen += [b.identity(P / "native-source/src/ggml-cuda/unary.cu"), b.identity(version)]
    frozen += [row["source"] for row in rows]
    frozen += [b.identity(S / name) for name in ("native-source-freeze.json","host-source-freeze.json","tests-source-freeze.json")]
    for item in header_closure:
        actual = b.identity(item["source"])
        assert actual["sha256"] == item["sha256"] and actual["bytes"] == item["bytes"]
        frozen.append(actual)
    for item in frozen:
        path = Path(item["path"])
        if path.is_relative_to(ROOT):
            snapshot = out / "compiled-source" / path.relative_to(ROOT)
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path,snapshot)
    c.save(out / "plan.json",dict(compile=rows,frozen=frozen,no_SDK_build=True,base_paths=inventory["bases"]))
    def check():
        for item in frozen: assert b.same(item), item["path"]
    for plan in bases.values():
        for item in plan["inputs"]: assert b.same(item),item["path"]
    env,runtime = b.environment(bases["tests"]["command"],[r["path"] for r in bases["tests"]["inputs"]],out)
    c.save(out / "runtime-environment.json",dict(runtime=runtime,PATH=env["PATH"]))
    def compile_one(row):
        check()
        receipt_path=out / (row["tag"]+"-identity.json")
        if args.resume and receipt_path.is_file():
            receipt=c.read(receipt_path)
            if (receipt["command"] == row["command"] and b.same(receipt["source"])
                    and b.same(receipt["object"]) and all(b.same(item) for item in receipt["dependencies"])):
                print("REUSE",row["tag"],flush=True)
                return row["tag"],receipt
        c.execute(row["tag"] + "-compile",row["command"],env,out)
        check()
        if row["kind"] == "host":
            data=c.read(out / (row["tag"]+"-deps.json"))["Data"]
            paths=[data["Source"],*data["Includes"]]
        else:
            paths=[row["source"]["path"]]
            for line in (out / (row["tag"]+".d")).read_text().splitlines()[1:]:
                path=line.strip().removesuffix("\\").strip().replace("\\ "," ")
                if path: paths.append(path)
        receipt=dict(command=row["command"],source=row["source"],object=b.identity(row["object"]),
            dependencies=[b.identity(path) for path in dict.fromkeys(paths)])
        c.save(out / (row["tag"]+"-identity.json"),receipt)
        return row["tag"],receipt
    benchmark=c.read(S / "checks/before/bench-identity.json")
    assert b.same(benchmark["source"]) and b.same(benchmark["object"])
    for item in benchmark["dependencies"]:assert b.same(item),item["path"]
    finished,errors={"bench":benchmark},[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,receipt=future.result();finished[tag]=receipt
            except BaseException as error: errors.append(repr(error))
    c.save(out / "compile-summary.json",dict(passed=not errors,errors=errors,fresh_owners=len(rows),no_SDK_build=True))
    if errors: raise SystemExit(repr(errors))
    replacements={c.key(row["old_object"]["path"]):finished[row["tag"]]["object"] for row in rows if "old_object" in row}
    lookup={c.key(row["path"]):row for plan in bases.values() for row in plan["inputs"]}
    lookup.update({c.key(row["object"]["path"]):row["object"] for row in finished.values()})
    ct_receipt=c.read(S.parent / "ct-packed-linear/checks/mapped-prepared/tests--graph_route_cuda--ct_packed_linear_test-identity.json")
    assert b.same(ct_receipt["source"]) and b.same(ct_receipt["object"])
    for item in ct_receipt["dependencies"]: assert b.same(item),item["path"]
    ct_object=ct_receipt["object"]
    lookup[c.key(ct_object["path"])]=ct_object
    old_test = c.key(P / "checks/native1/grouped-test.obj")
    old_bench = c.key(P / "checks/native1/bench-pinned.obj")
    for arm,base in (("tests",bases["tests"]),("control",bases["bench"]),("new",bases["bench"])):
        if args.only_link_tests and arm != "tests":continue
        command=[]
        for arg in base["command"]:
            if arg.upper().startswith(("/OUT:","/MAP:","/IMPLIB:","/PDB:")):continue
            if c.key(arg) in (old_test,old_bench):continue
            command.append(replacements[c.key(arg)]["path"] if arm!="control" and c.key(arg) in replacements else arg)
        extras=("grouped-test","region-test") if arm=="tests" else ("bench",)
        command[1:1]=[finished[tag]["object"]["path"] for tag in extras]
        if arm=="tests": command.insert(1,ct_object["path"])
        image=out / (arm+".exe")
        command += ["/OUT:"+str(image),"/MAP:"+str(image.with_suffix(".map")),"/IMPLIB:"+str(image.with_suffix(".lib"))]
        inputs=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj",".lib")]
        assert len(inputs)==len(set(map(c.key,inputs)))
        for path in inputs:assert b.same(lookup[c.key(path)]),path
        c.execute(arm+"-link",command,env,out)
        check()
        c.save(out / (arm+"-link-plan.json"),dict(command=command,inputs=[lookup[c.key(path)] for path in inputs]))
        c.save(out / (arm+"-image.json"),b.identity(image))
    print("BF16_GROUPED_BUILT",out,flush=True)

if __name__ == "__main__": main()
