# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 完成独立Qwen3.5-2B纯文本、无MTP/多模态的CUDA测试消费者，以真实调用校正底座接口、布局和性能。
   已跑通完整推理，并与llama.cpp进行同窗对照；当前数值、吞吐及剩余边界见下面的重构主线和
   [实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)。

7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

当前目标是完成 Compute/Graph 推理执行体系的重构及余项，范围为 Windows/Linux/macOS 的单机
CPU、单 GPU、CPU＋一张 GPU，覆盖选定正式文本模型及主流量化。**主干已落地，整体尚未完成。**
设计与完成条件集中在[Compute 设计](../architecture/compute-design.md#推理执行体系的重构形状)，
模型、制品、角色、算子与融合以[现行总表](../implementation/model-operators.md)为准。
此前“约75%”只是旧功能审查的粗估，不作为当前完成比例。

当前调用链保持模型语义图→冷编译→不可变计划→独立 Invocation→prepare/bind/layout→严格 submit
→Completion／结果／状态发布。普通引擎中间层不判断平台、Provider 或原生算子。
Direct/Graph 共用实际实现事实；共同核心处理依赖、权限、alias、预算与寿命，各后端处理自己的数学、布局及原生资源。
CPU＋CUDA、CPU＋Apple/Vulkan 的旧专属运行时、Plan、Invocation 和 driver 已删除，不保兼容入口；
CUDA 仅保留冷环境 helper。普通图不强制 CPU 数学 Context、IO 或调度服务，后两项分别显式选用
`compute_stream`、`graph_progress`。可选进度驱动仍推进同一 SubmissionCursor，不另造执行器。

接下来交叉推进前四项，不能用单个模型成功或局部回归替代底座完成：

1. 查清当前 Qwen 的实际投影、准备／绑定／提交开销，继续公平比较加载、prefill、decode、显存和内存。
2. 按总表补非多模态功能、各种量化和融合接线；区分角色 header、算子运行与整制品执行。
3. 收敛三平台 CPU/GPU/混合调用链，补变长、有限 shape、KV/recurrent/conv 状态、分页、并发槽、
   旧结果与取消／失败／重试／关闭／退休的实际遗漏。
4. 清除重复路径，统一接口、构建和文档；新增普通算子或融合应集中于实际实现，不牵动共同调度和资源核心。
5. 完成 MTP 真实消费者闭环，复用已有状态、分支与接受前缀底座。
6. 补图像 encoder/projector（mmproj）和图像输入到文本推理的链路。

前四项是当前重构收工范围，后两项随后分别推进。测试引擎不扩张为正式产品；模型格式、tokenizer、
生成／接受策略与请求政策仍归引擎，可复用计算、存储、执行、搬运与状态能力归底座。

当前真实 CUDA 消费者已执行完整24层、23-token prefill→4-token cached continuation→decode，
也有128-token prefill及31步固定输入decode的持续回归。Direct与可选进度驱动的相关旅程已有逐字节对照；
固定32阶段的64份hidden/logits用于后续回归，并不构成独立质量验收。
与早期Torch参考仍有BF16舍入、归约与attention实现差异；固定序列的top1曾相同31/32，
唯一差异步最高两token并列，logits相对L2均值1.166%、KL均值6.462e-4。
源序列来自既有参考，不能由此签收模型准确率。数学诊断、失败和边界见
[底座审查证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

当前Qwen已将常量表达式、卷积权重转换及静态索引移入冷准备，接通typed RMS、36组GDN L2、
24组保BF16舍入的decode FFN、显式频率RoPE、typed Conv及Cast/稳定SiLU融合；普通投影保留cuBLAS叶偏好。
这些改动不复制gate/up整份权重，不改变公开舍入边界。最近一次实际trace为每步650个kernel、1次GraphLaunch，
其中独立BF16/F32转换91个、Repeat为0；后续正确性批次未重采整模型trace。
双方均有163次投影，但Hyle激活/输出主要为BF16、参考decode为F32，不能据kernel数推导同数学工作或提速。

最近接受的同窗测量仍是2026-10-20北京时间03:19:06–03:19:32，旧Hyle／新Hyle／llama各3进程交错：

| 指标 | 新Hyle | 同窗llama.cpp | 边界 |
| --- | --- | --- | --- |
| 完整31步decode tokens/s | 99.83 | 103.84 | 中位低3.86% |
| warm第7–31步 tokens/s | 103.10 | 105.68 | 中位低2.43% |
| 首token秒 | 1.981 | 1.775 | 加载／准备仍须继续归因 |

旧→新warm为102.51→103.10，未证明稳定提速。prefill中位2039.71→1989.22，回退2.48%，样本也重叠；
已观察差别主要在首次冷准备43.74→45.46ms，submit至token中位均约18.85ms，准备内部仍待归因。
转换核在既有trace合计约73.5μs，投影核合计约8.74ms，仅作调查方向。
当前没有新的整模型质量、吞吐或总显存／内存峰值验收；保留原BF16合同，未启用scratch里的F32消费者草稿。
逐批源码、时钟、物理trace和负结果见[实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)
及[最近测量](../evidence/performance/view-projection-reuse-2026-10-20.json)。

最近功能批次已沿原执行路径补CT非对称INT4冷decode、GGUF NVFP4独立block64/36身份，
并修正CUDA MMQ重复expert slot映射。它们各有实际算子与寿命回归，未执行所选27B整制品。
Apple随后已补原编码NVFP4 MV/MM、expert及所选行路径，保F32激活与原共享输入，
相关Direct／Graph数值与寿命验证见[Apple批次](../evidence/correctness/apple-gguf-nvfp4-2026-10-20.json)。
CUDA随后已接CT symmetric/asymmetric INT4的普通同图Decode→精确Transpose View→MatMul冷融合，
允许权重链一处Cast，保源scale乘法、decode和operand舍入，直接读packed输入，不留整份dense W。
[4项Graph测试及5项MLX回归](../evidence/correctness/ct-packed-linear-2026-10-20.json)通过，含正向RequireCapture、
动态双槽、borrowed常量和逃逸后备。未运行所选27B payload或整模型，也未重测吞吐或峰值内存；
CPU/Apple/Vulkan的CT冷decode、成熟tensorcore/FFN/专家、其他packing及HF W4A4仍分别处理。
见[CT INT4](../evidence/correctness/ct-asymmetric-int4-2026-10-20.json)、
[GGUF NVFP4](../evidence/correctness/gguf-nvfp4-2026-10-20.json)及现行总表。

随后GroupedMatMul已补共享激活A=1及实际零slot步幅View，保原F32激活与累加、真实span和行距；
修复CPU BF16权重提前窄化激活、常量冷准备漏接，以及CUDA/Metal/Vulkan重复expert slot承载。
Apple同时修正原生输出实际分配量；Vulkan边界保原共享backing，原生矩阵按全部occurrence覆盖执行块。
本批Windows18项、Air16个公共数值域及8个native域通过，完整Qwen64份向量保持。
[原批证据](../evidence/correctness/grouped-shared-activation-2026-10-20.json)保留跨后端数值与寿命边界。
CUDA plain随后已为合资格NVIDIA小T域接原MMVF，直接读GPU IDs，保A=1/独立slot、重复ID和原checked/guarded流程；
修复后备专家矩阵调用丢失F32 accumulator/source精度标记。[6项CUDA回归](../evidence/performance/plain-grouped-cuda-2026-10-20.json)通过，
含正常／非正规数精度见证和捕获；新F32-ID专域的实际SM89 SASS核对不带FTZ。
随后CUDA BF16专家bank已保留原存储，小T直接位扩宽后F32计算，奇K／大T保F32激活并仅临时转换单专家N×K；
删除整bank Cast、冷widen工厂及其专用singleton。相关[16项CUDA回归](../evidence/performance/bf16-grouped-bank-2026-10-20.json)通过，
含Direct64次动态重绑、borrowed常量及两个非正规数见证；实际32个严格F32/BF16-ID SM89 kernel无FTZ。
E8/N512/K2048常量对照消除32MiB F32副本，充分冷准备后的提交中位54.9→55.6μs，未证明提速；
raw常量缺owner而无法冷准备的旧路径另记。大T排序、IDs读回／同步及原生池空间仍在，严格mixed GLU融合尚未接。
本轮不代表新Qwen吞吐、整模型质量或峰值内存验收，也未重测Linux。

跨平台已验证过有限形状、变长／分页attention、ready/pending来源、双槽、旧结果和取消／退休的多条实际旅程，
但不能推广为全部模型、dtype、布局和平台组合均完成。Vulkan固定backing的旧结果阻止复用，
Apple独立生成Array可保活至后续准备；close停止接纳，drain等待该实例实际退休，Scheduler空闲不代表GPU退休。
队列、共享KV/state和同Model推进仍受实际顺序与所有权约束。
Scheduler task/stack、原生metadata上传、Apple变KV的eager数组图等费用尚在，不能宣传零热分配。
Linux已有当前CPU＋CUDA finite-family增量运行证据，其余Linux旅程未代签。
当前paged scorer→TopK→压缩行decoder→Sink已接普通Graph及真实页权限，完整scores仍为O(T×C)。
各域正确性、失败恢复与资源限制集中在底座审查证据和对应用户指南，本页不重复实验流水账。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode，并完成上述短程性能对照；
  数值接受、长期稳态性能与其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 2026-10-19 用户移除旧 DeepSeek-V4-Pro/Flash preview 及其 GGUF 衍生制品的支持要求，
  同时加入 V4 系列正式版 Pro-0813、Flash-0731，现行范围为 8 个文本模型，已锁定24个官方/GGUF基线配置；
  两个正式版各选官方、同版本 UD-Q4_K_XL 与 UD-Q8_K_XL，身份已锁定，GGUF 的逐角色 codec 与 DSpark 覆盖仍待核，
  见[模型—制品—算子总表](../implementation/model-operators.md)。不能把 API 别名或旧 preview 的制品身份当成正式版。
  用户随后明确还须覆盖这些模型的 Unsloth 与 Hugging Face 主流量化制品；24不是范围上限，
  按实际模型版本、角色和精确 codec/packing/数值合同扩充，不凭位宽或量化名称代替接线覆盖。
  先补正反向关系，再删除已证明仅服务旧 preview、正式版与其他现行模型均不需要的非通用实现，
  随后检查各量化精度的融合接线。正式版仍有 FP4 expert、hash routing、压缩与 mHC，不能整组删除。
  共享算子、独立公共能力及历史源码/日志/数据不因模型名删除；旧八模型审查仅提供历史事实。
- 后续融合和量化接线以该现行范围为准，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这批早期参考材料覆盖公式与片段；完整 CUDA 消费者及实测结果见第六项。
加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版已按第六项约定关闭 MTP/视觉；与 llama.cpp 对照的权重、精度和计时边界见该项实测记录。
