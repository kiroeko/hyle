"""Archive only completed D4 windows; no build, inference, trace, or cleanup."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile
import zlib

S = Path(__file__).resolve().parent
A = S.parent
R = A.parents[1]
DEST = R / 'docs/evidence/performance/qwen-current-delivery-2026-10-21.json'
ZIP = DEST.with_suffix('.zip')
EXCLUDED = {'.exe', '.obj', '.lib', '.exp', '.pdb', '.dll', '.map', '.bf16', '.f32', '.pyc'}


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda: f.read(8 << 20), b''):
            h.update(part)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')


def main():
    assert not DEST.exists() and not ZIP.exists(), 'Preserve any previously published observation.'
    review_path = S / 'independent-measurement-review.json'
    assert review_path.is_file(), 'Wait for the independent finite review to freeze.'
    short = read(S / 'short-timing/summary.json')
    long = read(S / 'long-timing/summary.json')
    cached = read(S / 'cached16-timing/attempt1/summary.json')
    memory = read(S / 'memory-observations/summary.json')
    correct = read(S / 'current-correctness/summary.json')
    assert short['passed'] and long['passed'] and cached['all_processes_exit_zero'] and correct['passed']
    runs = {name: read(S / sub / 'runs.json') for name, sub in [
        ('short', 'short-timing'), ('long', 'long-timing'), ('cached16', 'cached16-timing/attempt1')]}
    assert [len(runs[k]) for k in ['short', 'long', 'cached16']] == [9, 9, 6]
    for group in runs.values():
        assert all(x['process']['exit'] == 0 and not x['process']['profiler']
                   and not x['process']['memory_monitor'] for x in group)
    cvals = cached['groups']['current']['cached_continuation_tokens_per_second']['samples']
    pvals = cached['groups']['llama']['cached_continuation_tokens_per_second']['samples']
    assert len(cvals) == len(pvals) == 3 and max(cvals) < min(pvals)
    ratio = statistics.median(cvals) / statistics.median(pvals)

    members = {}

    def add(path, member):
        path = Path(path)
        assert path.is_file(), path
        assert path.suffix.lower() not in EXCLUDED, path
        data = path.read_bytes()
        if member in members:
            assert members[member] == data, member
        else:
            members[member] = data

    # Exact completed roots only. In particular do not traverse cached16-trace.
    top = ['build-report.json', 'build.py', 'compiles-attempt1.json', 'freeze.py',
           'loader-objects.json', 'measurement-plan.json', 'memory-observation-plan.json',
           'memory_run.py', 'preparation-plan.json', 'prepare.py', 'ready-for-root.json',
           'reference-interface-review.json', 'selected-owner-audit.json', 'root_run.py',
           'independent-measurement-review.json', 'publish_interim.py']
    for name in top:
        add(S / name, 'stage/' + name)
    roots = ['checks/attempt1', 'checks/link1', 'short-timing', 'long-timing',
             'cached16-timing/attempt1', 'memory-observations', 'inputs',
             'peer-continuation/checks/attempt1', 'peer-continuation/checks/attempt2',
             'peer-continuation/revisions/attempt1']
    for name in roots:
        base = S / name
        assert base.is_dir(), base
        for p in sorted(base.rglob('*')):
            if p.is_file() and p.suffix.lower() not in EXCLUDED:
                add(p, 'stage/' + p.relative_to(S).as_posix())
    for name in ['build.py', 'original-peer_benchmark.cpp', 'peer_benchmark.cpp',
                 'peer-continuation.diff', 'ready-for-root.json',
                 'review-static-input-link-facts.json', 'stable-window-marker-fix.diff']:
        add(S / 'peer-continuation' / name, 'stage/peer-continuation/' + name)
    peer_review = S / 'peer-continuation/independent-review.json'
    assert peer_review.is_file()
    add(peer_review, 'stage/peer-continuation/independent-review.json')
    for name in ['qwen.command.json', 'qwen.result.json', 'qwen.stdout.log', 'qwen.stderr.log', 'summary.json']:
        add(S / 'current-correctness' / name, 'stage/current-correctness/' + name)
    for p in sorted((S / 'current-correctness/trace/routes').glob('*.tsv')):
        add(p, 'stage/' + p.relative_to(S).as_posix())

    # Original small inputs/runner/peer source and exact build identities; no weight payload.
    old_files = [
        'qwen-gpu-comparison/128-prefill/fixed-inputs.json',
        'qwen-gpu-comparison/128-prefill/decode.ids',
        'qwen-gpu-comparison/128-prefill/inputs/prompt.ids',
        'qwen-gpu-comparison/128-prefill/inputs/weights.tsv',
        'qwen-gpu-comparison/128-prefill/peer_benchmark.cpp',
        'qwen-gpu-comparison/memory-probe/memory_probe.py',
        'decode-prepare-cost/long-peer/fixed-inputs.json',
        'decode-prepare-cost/long-peer/decode.ids',
        'decode-prepare-cost/long-peer/peer_benchmark.cpp',
        'decode-prepare-cost/long-peer/link-plan.json',
        'decode-prepare-cost/experiment.py', 'decode-prepare-cost/long_peer.py',
        'decode-prepare-cost/candidate/link-plan.json',
        'decode-prepare-cost/timing/inputs.json', 'decode-prepare-cost/long-timing/inputs.json']
    for rel in old_files:
        add(A / rel, 'reference/' + rel)
    for row in read(S / 'loader-objects.json')['records']:
        p = Path(row['recipe']['path'])
        add(p, 'reference/' + p.relative_to(A).as_posix())

    # Actual repository headers of the fresh consumer/provider owners and retained loader objects.
    sources = {}
    def current_source(path):
        p = Path(path)
        try:
            rel = p.relative_to(R)
        except ValueError:
            return
        if rel.parts[0] not in ['include', 'src', 'tools', 'third_party']:
            return
        member = 'current_sources/' + rel.as_posix()
        add(p, member)
        sources[rel.as_posix()] = dict(**identity(p), member=member)

    fresh = read(S / 'compiles-attempt1.json')['records']
    for row in fresh.values():
        assert identity(row['source']['path'])['sha256'] == row['source']['sha256']
        current_source(row['source']['path'])
        for dep in row['dependencies']:
            current_source(dep['path'])
    for row in read(S / 'loader-objects.json')['records']:
        rec = read(row['recipe']['path'])
        current_source(row['source']['path'])
        for dep in rec['dependencies']:
            current_source(dep['path'])
    related = [
        'src/graph/executable.cc', 'src/graph/resources.cc',
        'src/compute_provider_ggml_cuda/tensor_program.cc',
        'src/compute_provider_ggml_cuda/native_bridge.h',
        'src/compute_provider_ggml_cuda/native_bridge_impl.h',
        'src/compute_ggml_runtime/explicit_rope.h',
        'third_party/ggml_cuda_runtime/patches.json',
        'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json']
    for rel in related:
        p = R / rel
        assert p.is_file(), p
        if rel == 'cmake/HyleDependencyLock.json':
            add(p, 'current_sources/' + rel)
            sources[rel] = dict(**identity(p), member='current_sources/' + rel)
        else:
            current_source(p)

    # All64 duplicate numerical vectors are represented by existing actual/reference hashes.
    assert len(correct['vectors']) == 64 and all(x['byte_equal'] for x in correct['vectors'])
    members['vector-hashes.json'] = encoded(dict(vectors=correct['vectors'],
        raw_vectors_archived=False, actual_comparison='All64 byte-equal to the retained original reference.',
        reproduction='Use archived root_run.py correctness command and original model/trace reference; no model numeric payload is distributed.'))
    members['current-source-inventory.json'] = encoded(list(sources.values()))

    links = [
        '../performance/qwen-first-prepare-2026-10-20.json',
        '../performance/qwen-decode-rebenchmark-2026-10-20.json',
        '../performance/qwen-pinned-weight-load-2026-10-20.json',
        '../performance/qwen-bf16-top1-2026-10-20.json',
        '../performance/qwen-memory-current-2026-10-20.json',
        '../correctness/linux-current-package-install-2026-10-21.json',
        '../correctness/apple-current-sdk-reference-2026-10-21.json']
    for link in links:
        assert (DEST.parent / link).resolve().is_file(), link
    report = dict(
        date='2026-10-21', status='interim_D4_observation_not_complete',
        scope='Windows RTX4070 real24-layer Qwen3.5-2B text consumer; original source weights and teacher-forced inputs. No product changes.',
        delivery4_complete=False,
        result=dict(smoke=dict(processes=1, vectors=64, all_byte_equal=True),
            unmonitored_timing_processes=dict(short=9, long=9, cached16=6, total=24),
            independent_memory_processes=2, all_process_exits_zero=True,
            source_or_product_math_changes=0, current_image_fresh_CXX=3,
            continuation_adapter_CXX=2, total_CXX=5, links=3, NVCC=0, SDK_builds=0),
        measurements=dict(short=short, long=long, cached16=cached),
        interpretation=[
            'Short full decode median103.25 vs103.79token/s; long106.57 vs105.98. These small opposing differences do not establish a stable decode winner.',
            'Short prefill2070 vs1284token/s; long1926 vs1361. Retain the finite window and different preparation/math boundaries.',
            f'New cachedT16 median{statistics.median(cvals):.2f} vs{statistics.median(pvals):.2f}token/s ({(ratio-1)*100:.2f}% throughput, slower). All3 current samples are below all3 peer samples; this is a genuine finite-window disadvantage, not a D4 completion claim.',
            'The16-token continuation runs once in the original context after128-token prefill, followed by15 original singleton inputs. It is not a144-token fresh prefill or16 singleton decodes.',
            'Do not pool short/long/cached or monitored/unmonitored calls. No statistical significance, quality equivalence, or all-workload performance claim is established.'],
        cached16_gap=dict(current_token_per_second=cvals, peer_token_per_second=pvals,
            current_median=statistics.median(cvals), peer_median=statistics.median(pvals),
            current_over_peer=ratio, throughput_percent=(ratio-1)*100,
            no_sample_overlap=True, all_current_slower=True),
        measurement_contract=dict(metric='complete host-token step_seconds',
            Hyle='Input writes + batch/layout/replay preparation + submit + Completion.wait +4B selected-token read. Separate constructor/shape-family preparation and startup buckets are retained.',
            peer='Original public backend greedy plus token fastpath; engine sampled_logits readback remains included. Actual phase metadata reports248320sampled logits; consumer never calls CPUargmax or requests raw logits.',
            precision='Same original source weight provenance, but Hyle BF16 intermediate boundaries/F32 accumulation differ from peer F32 intermediates. Matching finite predictions are not numerical-tree/model-quality equivalence.',
            OS_page_cache='uncontrolled', warmup='no extra invisible warmup; all complete-call samples retained',
            capture='Original prefer-capture consumer and per-slot first preparation retained; no new blanket capture claim.'),
        build_and_input_identities=dict(current=read(S/'ready-for-root.json'),
            adapter=read(S/'peer-continuation/ready-for-root.json'),
            actual_windows_build_report=identity(S/'build-report.json'),
            actual_cached_inputs=read(S/'cached16-timing/attempt1/inputs.json')),
        corrections=[
            dict(kind='adapter_metadata_only', finding='Continuation shifted phase index, so index>=7 included decode6.',
                 fix='decode_index>=7, original flags; attempt2 fresh1CXX+1link exit0; math/input/step timing unchanged. Attempt1 retained, not a GPU failure.'),
            dict(kind='driver_before_launch', finding='Root reported one incorrect peer-continuation/inputs path before Popen.',
                 fix='Use stage inputs path. No model process launched; not a product or numerical failure. Empty original directory remains. Separate raw failure record was not provided.')],
        memory=dict(throughput_evidence=False, processes_per_arm=1,
            current=memory['arms']['current']['peaks'], reference=memory['arms']['reference']['peaks'],
            actual_sample_count=dict(current=memory['arms']['current']['samples'], reference=memory['arms']['reference']['samples']),
            caveats=['Independent short128+31 processes, not cachedT16 or the throughput processes.',
                     'Working set, private commit and WDDM dedicated/shared samples are different metrics; unavailable GPU samples stay null. These are finite sampled peaks, not proven allocation bounds.',
                     'Sample cadence about47.5ms; reference post-load preparation has0samples. Do not fill missing intervals or infer zero memory.']),
        independent_review=identity(review_path), related_evidence=links,
        current_sources=dict(count=len(sources), inventory_member='current-source-inventory.json'),
        limitations=['D4 remains open because cached continuation is slower in this bounded comparison.',
                     'Full-checkpoint quality, all platforms/models/lengths, cold-disk IO and steady slot initialization equivalence are not signed.',
                     'Root cached16-trace diagnostics are a separate experiment and deliberately excluded from this frozen intermediate package.',
                     'This archive stores binary/runtime/input identities and small reproducible sources/commands, not executables, objects, SDKs, weights, or duplicate64vectors.'],
        cleanup='No deletion performed; objects, SDK/cache, current binaries and raw source results remain separately managed by root.')
    members['report.json'] = encoded(report)
    manifest = []
    for name, data in sorted(members.items()):
        manifest.append(dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                             CRC32=f'{zlib.crc32(data)&0xffffffff:08x}'))
    members['manifest.json'] = encoded(dict(payloads=manifest,
        excluded='Executables/objects/libs/DLLs/fullmaps/SDK/model payloads/64duplicate raw vectors/new cached16-trace'))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(members.items()):
            z.writestr(name, data)
    with zipfile.ZipFile(ZIP) as z:
        assert z.testzip() is None
        for row in manifest:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
            assert f'{z.getinfo(row["member"]).CRC:08x}' == row['CRC32']
    report['archive'] = dict(**identity(ZIP), members=len(members), source_count=len(sources),
        manifest='manifest.json', CRC_checked=True, all_payload_SHA256_checked=True)
    DEST.write_bytes(encoded(report))
    print(json.dumps(dict(report=identity(DEST), archive=report['archive']), ensure_ascii=False))


if __name__ == '__main__':
    main()
