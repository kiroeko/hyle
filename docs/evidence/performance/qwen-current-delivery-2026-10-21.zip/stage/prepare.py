"""Read-only D4 cached Qwen consumer/selected-product plan; no build or GPU."""
from pathlib import Path
from collections import Counter
import hashlib
import json

S=Path(__file__).resolve().parent
A=S.parent
R=A.parents[1]
BASE=A/'quark-block128-scale-2026-10-21/cuda/checks/link1/link-plan.json'
D1=A/'decode-prepare-cost/candidate/link-plan.json'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def key(path):return str(Path(path).resolve()).casefold()
def identity(path):
    path=Path(path).resolve();digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):digest.update(block)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest.hexdigest())
def same(row):
    actual=identity(row['path'])
    return key(actual['path'])==key(row['path']) and all(actual[k]==row[k] for k in ['bytes','sha256'])


base,old=read(BASE),read(D1)
assert len(base['inputs'])==177 and len(old['inputs'])==150
assert all(same(row) for row in base['inputs'])
base_keys={key(x['path']) for x in base['inputs']}
old_keys={key(x['path']) for x in old['inputs']}
main_recipe=A/'decode-stable-bind/checks/main-identity.json'
provider_recipe=A/'decode-retirement-query-reuse/checks/provider-identity.json'
constant_recipe=A/'projected-bind-cold-index/checks/host1/07-graph-constant_artifact-identity.json'
main,provider=read(main_recipe),read(provider_recipe)
assert identity(R/'tools/qwen35_text/main.cc')==main['source']
assert key(provider['object']['path']) in base_keys
assert identity(R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc')['sha256']=='c87325fc25cc21cf228f5518ed25c8d7dc29985fe7f5d24473880757ef96b484'
loader=[]
for path in sorted((A/'qwen-pinned-weight-load/checks').glob('*-identity.json')):
    if path.name=='qwen-main-identity.json':continue
    record=read(path)
    if key(record['object']['path']) not in old_keys:continue
    assert key(record['object']['path']) not in base_keys
    assert same(record['source']) and same(record['object'])
    differences=[]
    for dep in record.get('dependencies',[]):
        p=Path(dep['path'])
        if p.is_file() and p.is_relative_to(R) and p.relative_to(R).parts[0] in ['src','include'] and not same(dep):
            differences.append(dict(compiled=dep,current=identity(p)))
    loader.append(dict(recipe=identity(path),source=record['source'],object=record['object'],
        source_matches_current=True,changed_header_dependencies=differences,
        disposition='Reuse only after the bounded header/API equivalence review.'))
assert len(loader)==15
save(S/'loader-objects.json',dict(records=loader,CXX=0,GPU_runs=0))

# Inspect nearby actual compile identities once per object directory. This is
# source-owner metadata auditing, not a new whole-SDK rebuild or header gate.
cache={}
owners=[]
missing=[]
for row in base['inputs']:
    path=Path(row['path'])
    if path.suffix.lower()!='.obj':continue
    if path.parent not in cache:
        values=[]
        for candidate in path.parent.glob('*identity*.json'):
            record=read(candidate)
            if isinstance(record,dict) and isinstance(record.get('object'),dict) and isinstance(record.get('source'),dict):
                values.append((candidate,record))
        cache[path.parent]=values
    matches=[(p,d) for p,d in cache[path.parent] if key(d['object']['path'])==key(path)]
    if not matches:
        missing.append(row)
        continue
    recipe,record=matches[0]
    assert all(record['object'].get(k)==row[k] for k in ['bytes','sha256']),(str(recipe),record['object'],row)
    source=Path(record['source']['path'])
    canonical=source.is_relative_to(R/'src') or source.is_relative_to(R/'include')
    owners.append(dict(object=row,recipe=identity(recipe),compiled_source=record['source'],
        canonical_source=canonical,current_source=identity(source) if source.is_file() else None,
        source_matches_current=same(record['source']) if source.is_file() else None))
save(S/'selected-owner-audit.json',dict(owners=owners,unresolved_nearby_recipe=missing,
    current_canonical_source_differences=[x for x in owners if x['canonical_source'] and not x['source_matches_current']],
    source_scope='Direct-object owners only; current validated Z library inputs are identity-preserved, not falsely described as newly recompiled.',
    builds=0,GPU_runs=0))
test=next(x['object'] for x in base['replacements'] if x['source']['path'].endswith('fp8_scale_policy_test.cc'))
drop=[x for x in base['inputs'] if key(x['path'])==key(test['path']) or Path(x['path']).name.lower() in ['gtest.lib','gtest_main.lib']]
assert len(drop)==3
main_diffs=[dict(compiled=x,current=identity(x['path'])) for x in main['dependencies']
    if Path(x['path']).is_file() and Path(x['path']).is_relative_to(R/'include') and not same(x)]
critical={}
for label,fragment in [('CUDA_weights_256','bank-alignment-product1'),('current_GraphResources','root-resources1'),
                       ('current_GraphExecutable','graph-exec1'),('current_CUDA_3D_RoPE','ga-ratio4-producer-2026-10-21\\common\\checks\\attempt1\\cuda-tensor')]:
    selected=[x for x in base['inputs'] if fragment.casefold() in x['path'].casefold()]
    assert len(selected)==1,(label,selected)
    critical[label]=selected[0]
plan=dict(status='bounded_readonly_plan_not_built_or_executed',base=identity(BASE),old_D1=identity(D1),
    current_consumer=identity(R/'tools/qwen35_text/main.cc'),
    consumer_byte_identical_to_D1_retained_main=True,
    never_restore_D1_compute_or_graph_objects=True,
    source_difference=dict(shared_inputs=len(base_keys&old_keys),D1_only=len(old_keys-base_keys),current_only=len(base_keys-old_keys)),
    required_CXX=[dict(source=identity(R/'tools/qwen35_text/main.cc'),recipe=identity(main_recipe),
        reason='Freshly instantiate the retained consumer against current public headers.',changed_public_dependencies=main_diffs),
        dict(source=identity(R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'),recipe=identity(provider_recipe),
        old_object=provider['object'],reason='Exact Linux GCC portability fix: two explicit empty initializers; mathematics and ABI unchanged.'),
        dict(source=identity(R/'src/graph/constant_artifact.cc'),recipe=identity(constant_recipe),
        old_object=read(constant_recipe)['object'],reason='Current cold artifact owner differs from retained Z object source; refresh one owner instead of claiming a stale source as current.')],
    required_CXX_count=3,retained_loader_objects=15,remove_test_inputs=drop,
    predicted_link_input_count=177-3+1+15,critical_current_products_preserved=critical,
    dependency_actions='Use the exact existing SDK/library inputs. No SDK, NVCC, GEMM or quantizer rebuild is planned.',
    pending='Original reference/timer interface review; then a focused 3-CXX/1-link preparation may proceed. The 15 loader/header equivalence checks are independently complete.',
    GPU_runs=0,benchmark_runs=0,SDK_builds=0,product_mutations=0)
save(S/'preparation-plan.json',plan)
print(json.dumps(dict(required_CXX=3,loader_objects=15,link_inputs=190,
    direct_owners_found=len(owners),unresolved_direct_object_recipes=len(missing),
    canonical_source_differences=[x['compiled_source']['path'] for x in owners if x['canonical_source'] and not x['source_matches_current']]),indent=2))
