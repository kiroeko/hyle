"""Freeze focused D4 build readiness. This does not execute the consumer."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1]
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    path=Path(path).resolve();digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):digest.update(block)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest.hexdigest())
def same(row):
    current=identity(row['path'])
    return all(current[k]==row[k] for k in ['bytes','sha256'])
records=read(S/'compiles-attempt1.json')['records']
for name,row in records.items():
    assert same(row['source']) and same(row['object']) and all(same(x) for x in row['dependencies'])
    assert read(Path(row['object']['path']).parent/'compile.result.json')['exit']==0
link=S/'checks/link1';plan=read(link/'link-plan.json');ready=read(S/'ready-for-root.json')
assert len(plan['inputs'])==190 and all(same(row) for row in plan['inputs'])
assert read(link/'link.result.json')['exit']==0 and same(ready['image'])
assert read(link/'imports.result.json')['exit']==0
review=read(S/'reference-interface-review.json')
assert review['status']=='bounded_read_only_cross_review_complete_no_blocker_for_focused_preparation'
baseline=A/'decode-prepare-cost/candidate/qwen.exe'
assert identity(baseline)['sha256']=='6e09735e395e86412d4588cf67507fe5902d149e3e03f674b688ddde5cddf1f8'
report=dict(status='focused_current_Qwen_artifact_ready_for_root_validation_no_GPU_run',
    image=ready['image'],link_plan=identity(link/'link-plan.json'),CXX=3,links=1,NVCC=0,SDK_builds=0,
    product_or_consumer_source_edits=0,GPU_runs=0,benchmark_runs=0,
    retained_D1_baseline=identity(baseline),retained_main=records['main']['source'],
    fresh_objects={name:row['object'] for name,row in records.items()},
    compile_identities=[identity(Path(row['object']['path']).parent/'identity.json') for row in records.values()],
    actual_selected_TU_dependency_drift=0,source_snapshots=[row['compiled_source_snapshot'] for row in records.values()],
    reused_loader_objects=15,independent_loader_and_interface_review=identity(S/'reference-interface-review.json'),
    critical_current_products=plan['critical_current_products_preserved'],
    runtime_audit=identity(link/'PE-imports-and-runtime.json'),
    preparation_source_audit=identity(S/'selected-owner-audit.json'),
    scope=['The current validated Z closure is the base. No D1 compute/Graph/provider object is restored over it.',
        'The real Qwen source is byte-identical to the retained D1 consumer. Its current math routes and numerical results still require execution.',
        'The 15 retained loader sources and object hashes match; six header-only differences are independently proved to contain comment changes only.',
        'No gtest or model-oracle test wrapper remains. PE imports/module availability do not measure actual CPU/GPU residency.',
        'The complete timing field is step_seconds; seconds begins after preparation. New full-window comparison must preserve the existing host-token endpoint.',
        'Short/long old timing runs do not constitute a cached-continuation measurement; the existing --continuation interface can be used separately.',
        'The peer uses its original public sampler/greedy path and may internally transfer logits. Do not attribute that to an explicit raw-logits request by the consumer.'])
(S/'build-report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(identity(S/'build-report.json'))
