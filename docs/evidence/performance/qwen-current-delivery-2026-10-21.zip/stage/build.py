"""Prepare the retained real Qwen consumer with three current CXX owners; never run."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('retained_d4_host',A/'quark-block128-scale-2026-10-21/windows/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
PLAN=c.read(S/'preparation-plan.json')


def same(row):
    actual=b.identity(row['path'])
    return c.key(actual['path'])==c.key(row['path']) and all(actual[k]==row[k] for k in ['bytes','sha256'])


def compile_one(job):
    tag,row,attempt=job
    out=S/'checks'/attempt/tag;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists()
    recipe=Path(row['recipe']['path']);original=c.read(recipe);source=Path(row['source']['path'])
    assert same(row['source']) and same(row['recipe'])
    command=b.host_command(original['command'],source,tag,out)
    assert '/WX' in command and '/W4' in command and '/MD' in command and '/O2' in command
    c.save(out/'compile-plan.json',dict(command=command,source=row['source'],recipe=row['recipe'],GPU_runs=0,SDK_builds=0))
    env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
    deps_path=out/(tag+'-deps.json');deps=c.read(deps_path)['Data']
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
    assert same(row['source']) and all(same(x) for x in dependencies)
    snapshot=out/'source'/source.relative_to(R);snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes())
    record=dict(source=row['source'],object=b.identity(out/(tag+'.obj')),command=command,
        recipe=row['recipe'],dependencies=dependencies,source_dependencies=b.identity(deps_path),
        compiled_source_snapshot=b.identity(snapshot),old_object=row.get('old_object'),GPU_runs=0,SDK_builds=0)
    c.save(out/'identity.json',record);print('COMPILED',tag,flush=True)
    return tag,record


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--attempt',default='attempt1');parser.add_argument('--link-dir',default='link1');args=parser.parse_args()
    assert PLAN['required_CXX_count']==3
    jobs=[(tag,row,args.attempt) for tag,row in zip(['main','provider','constant-artifact'],PLAN['required_CXX'])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=dict(pool.map(compile_one,jobs))
    c.save(S/('compiles-'+args.attempt+'.json'),dict(records=records,CXX=3,NVCC=0,GPU_runs=0,SDK_builds=0))
    base_path=Path(PLAN['base']['path']);base=c.read(base_path)
    assert all(same(row) for row in base['inputs'])
    drop={c.key(row['path']) for row in PLAN['remove_test_inputs']}
    replace={c.key(row['old_object']['path']):row['object'] for tag,row in records.items() if tag!='main'}
    kept=[replace.get(c.key(row['path']),row) for row in base['inputs'] if c.key(row['path']) not in drop]
    loader=c.read(S/'loader-objects.json')['records']
    assert all(same(row['source']) and same(row['object']) for row in loader)
    inputs=[records['main']['object'],*[row['object'] for row in loader],*kept]
    assert len(inputs)==190 and len({c.key(row['path']) for row in inputs})==190
    out=S/'checks'/args.link_dir;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists()
    command=[replace[c.key(x)]['path'] if c.key(x) in replace else x for x in base['command']
        if c.key(x) not in drop and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[records['main']['object']['path'],*[row['object']['path'] for row in loader]]
    image=out/'qwen.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    actual=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ['.obj','.lib']]
    assert list(map(c.key,actual))==[c.key(row['path']) for row in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replacements=[dict(source=row['source'],old_object=row['old_object'],object=row['object']) for tag,row in records.items() if tag!='main'],
        fresh_main=records['main']['object'],retained_loader_objects=[x['object'] for x in loader],removed_tests=PLAN['remove_test_inputs'],
        critical_current_products_preserved=PLAN['critical_current_products_preserved'],GPU_runs=0,SDK_builds=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    dumpbin=str(Path(records['main']['command'][0]).with_name('dumpbin.exe'))
    c.execute('imports',[dumpbin,'/nologo','/imports',str(image)],env,out)
    text=(out/'imports.stdout.log').read_text(encoding='utf-8',errors='replace')
    imports=sorted({x.lower() for x in re.findall(r'^\s+([^\s]+\.dll)\s*$',text,re.M|re.I)})
    dynamic=sorted({x.decode('ascii') for x in re.findall(rb'hyle_ggml_cpu_avx2_[A-Za-z0-9_]+\.dll(?=\x00)',image.read_bytes())})
    modules=[]
    for name in dynamic:
        source=next((Path(folder)/name for folder in runtime if (Path(folder)/name).is_file()),None)
        assert source is not None,name
        destination=out/name
        if not destination.exists():os.link(source,destination)
        assert os.path.samefile(source,destination)
        modules.append(dict(source=b.identity(source),destination=b.identity(destination),hardlink=True))
    c.save(out/'PE-imports-and-runtime.json',dict(imported_DLL_names=imports,
        possible_dynamic_CPU_modules=modules,SDK_search_paths=runtime,
        boundary='Import/module presence is not measured resident CPU or GPU memory. No inference was executed.',GPU_runs=0))
    ready=dict(status='current_retained_Qwen_consumer_compiled_and_linked_not_run',CXX=3,links=1,NVCC=0,SDK_builds=0,GPU_runs=0,
        image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),
        PE_runtime_audit=b.identity(out/'PE-imports-and-runtime.json'),base=PLAN['base'],
        source_byte_identical_to_D1=True,math_policy='Retained source declares the D1 BF16 arithmetic graph and F32 Top1. Current provider route, numerics and throughput remain unexecuted.',
        retained_D1_baseline='decode-prepare-cost/candidate/qwen.exe')
    c.save(S/'ready-for-root.json',ready);print(json.dumps(ready,indent=2),flush=True)


if __name__=='__main__':main()
