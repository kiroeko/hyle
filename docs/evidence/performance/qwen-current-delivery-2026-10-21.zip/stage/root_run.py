"""Finite D4 observations. No product builds, profiler or memory monitor."""
from pathlib import Path
import hashlib
import json
import os
import re
import statistics
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b''):
            h.update(chunk)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=h.hexdigest())


CURRENT = read(S / 'ready-for-root.json')['image']
BASELINE = read(S / 'build-report.json')['retained_D1_baseline']
assert identity(CURRENT['path']) == CURRENT
assert identity(BASELINE['path']) == BASELINE
ENV = os.environ.copy()
ENV['PATH'] = read(S / 'checks/link1/runtime-environment.json')['PATH']
assert not ENV.get('GGML_CUDA_DISABLE_GRAPHS')


def execute(out, tag, command):
    command = list(map(str, command))
    record = dict(tag=tag, command=command, cwd=str(ROOT), image=identity(command[0]),
                  started=time.time(), profiler=False, memory_monitor=False)
    save(out / (tag + '.command.json'), record)
    start = time.perf_counter_ns()
    with (out / (tag + '.stdout.log')).open('wb') as so, (out / (tag + '.stderr.log')).open('wb') as se:
        process = subprocess.run(command, cwd=ROOT, env=ENV, stdout=so, stderr=se,
                                 timeout=300, creationflags=subprocess.CREATE_NO_WINDOW)
    record.update(exit=process.returncode, process_wall_seconds=(time.perf_counter_ns() - start) / 1e9,
                  finished=time.time())
    save(out / (tag + '.result.json'), record)
    print(tag, 'exit', process.returncode, 'wall', round(record['process_wall_seconds'], 3), flush=True)
    if process.returncode:
        print((out / (tag + '.stderr.log')).read_text(errors='replace')[-5000:], flush=True)
        raise RuntimeError('D4 process failed; preserved original logs: ' + tag)
    return record


def hyle_observation(out, tag):
    stderr = (out / (tag + '.stderr.log')).read_text(encoding='utf-8')
    raw = read_stdout(out / (tag + '.stdout.log'))
    rows = []
    loading = {}
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        if line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        if line.startswith('initialized '):
            loading.update({k: float(v) for k, v in (x.split('=', 1) for x in line.split()[1:])})
        if re.match(r'^(prefill|continuation|decode\d+) tokens=', line):
            parts = line.split()
            f = dict(x.split('=', 1) for x in parts[1:])
            rows.append(dict(name=parts[0], input_tokens=int(f['tokens']), visible_tokens=int(f['visible']),
                             predicted_id=int(f['next']), step_seconds=float(f['step_seconds']),
                             submit_to_token_seconds=float(f['seconds']), submit_seconds=float(f['submit_seconds'])))
    captures = [[int(a), int(b)] for a, b in re.findall(r'capture_recorded=(\d+) capture_reused=(\d+)', stderr)]
    workspace = [dict(tokens=int(t), steps=int(n), workspace_bytes_per_slot=int(b),
                      compiled_known_bytes=int(k), compiled_unknown_providers=int(u))
                 for t, n, b, k, u in re.findall(r'^compiled T=(\d+) steps=(\d+) workspace/slot=(\d+) compiled_known_bytes=(\d+) compiled_unknown_providers=(\d+)', stderr, re.M)]
    assert len(rows) == len(captures)
    assert all(x['step_seconds'] > 0 for x in rows)
    return dict(raw=raw, phases=rows, loading=loading, capture_counts=captures, workspace=workspace)


def read_stdout(path):
    return json.loads(next(x for x in reversed(path.read_text().splitlines()) if x.startswith('{')))


def commands(long=False):
    hc = read(A / 'decode-current-rebenchmark/timing/02-current.command.json')['command'].copy()
    pc = read(A / 'decode-current-rebenchmark/timing/03-llama.command.json')['command'].copy()
    if long:
        hc[hc.index('--decode-ids') + 1] = str(A / 'decode-prepare-cost/long-peer/decode.ids')
        hc[hc.index('--steps') + 1] = '128'
        pc[0] = str(A / 'decode-prepare-cost/long-peer/peer.exe')
        pc[2] = str(A / 'decode-prepare-cost/long-peer/fixed-inputs.json')
    return hc, pc


def smoke():
    out = S / 'current-correctness'
    out.mkdir(exist_ok=False)
    ref = A / 'batch-graph-capture/correctness-final'
    command = read(ref / 'qwen.command.json')['command'].copy()
    command[0] = CURRENT['path']
    command[command.index('--trace') + 1] = str(out / 'trace')
    process = execute(out, 'qwen', command)
    observation = hyle_observation(out, 'qwen')
    references = {p.relative_to(ref / 'trace'): identity(p) for p in sorted((ref / 'trace').rglob('*'))
                  if p.suffix in ('.f32', '.bf16')}
    actual = {p.relative_to(out / 'trace'): identity(p) for p in sorted((out / 'trace').rglob('*'))
              if p.suffix in ('.f32', '.bf16')}
    assert len(actual) == len(references) == 64
    assert actual.keys() == references.keys()
    vectors = [dict(name=p.as_posix(), actual=v, reference=references[p],
                    byte_equal=(v['bytes'], v['sha256']) == (references[p]['bytes'], references[p]['sha256']))
               for p, v in actual.items()]
    old = read_stdout(ref / 'qwen.stdout.log')
    checks = dict(all_64_vectors_byte_equal=all(v['byte_equal'] for v in vectors),
                  same_generated_ids=observation['raw']['generated_ids'] == old['generated_ids'],
                  same_fixed_decode_inputs=observation['raw']['decode_input_ids'] == old['decode_input_ids'],
                  original_capture_pattern=observation['capture_counts'] == [[1, 0]] * 3 + [[0, 1]] * 29)
    save(out / 'summary.json', dict(passed=all(checks.values()), checks=checks, process=process,
                                   vectors=vectors, observation=observation, throughput_evidence=False,
                                   independent_quality_acceptance=False))
    assert all(checks.values()), checks
    print('CURRENT_64_VECTORS_AND_FIXED_IDS_EQUAL', flush=True)


def timing(long=False):
    assert read(S / 'current-correctness/summary.json')['passed']
    out = S / ('long-timing' if long else 'short-timing')
    out.mkdir(exist_ok=False)
    hc, pc = commands(long)
    images = dict(current=CURRENT, D1=BASELINE, llama=identity(pc[0]))
    # Three fresh processes per arm, cyclic and reversed neighbours; retain every sample.
    order = ['D1', 'current', 'llama', 'llama', 'D1', 'current', 'current', 'llama', 'D1']
    fixed = read(pc[2])
    save(out / 'inputs.json', dict(images=images, fixed_inputs=identity(pc[2]), order=order,
                                  profiler=False, memory_monitor=False, builds_during_window=False,
                                  context_capacity=256, OS_page_cache='uncontrolled; not cold-disk evidence',
                                  precision='Same BF16 source weights; intermediate arithmetic and GPU/host token-selection transfer differ.',
                                  complete_step='Hyle input writes + batch/replay + submit + wait + 4B token read; peer input batch + llama_decode + sampler. No explicit trace readbacks.',
                                  stable_window='decode7 through end; full decode includes initial capture',
                                  long_tape_repeats_original31=long))
    runs = []
    for i, arm in enumerate(order, 1):
        tag = f'{i:02}-{arm}'
        cmd = (pc if arm == 'llama' else hc).copy()
        cmd[0] = images[arm]['path']
        if arm == 'llama':
            cmd[-1] = str(out / (tag + '-peer-result.json'))
        process = execute(out, tag, cmd)
        if arm == 'llama':
            raw = read(cmd[-1])
            rows, loading, ids = raw['phases'], raw['loading'], raw['predicted_ids']
            assert raw['prompt_ids'] == fixed['prompt_ids']
            assert raw['decode_input_ids'] == fixed['decode_input_ids']
            obs = dict(raw=raw, phases=rows, loading=loading)
        else:
            obs = hyle_observation(out, tag)
            rows, loading, ids = obs['phases'], obs['loading'], obs['raw']['generated_ids']
            assert obs['raw']['decode_input_ids'] == fixed['decode_input_ids']
        count = 127 if long else 31
        assert len(rows) == len(ids) == count + 1
        assert [x['visible_tokens'] for x in rows] == list(range(128, 129 + count))
        times = [x['step_seconds'] for x in rows]
        metrics = dict(prefill_tokens_per_second=128 / times[0],
                       full_decode_tokens_per_second=count / sum(times[1:]),
                       stable_decode_tokens_per_second=(count - 6) / sum(times[7:]))
        print('  tps', {k: round(v, 2) for k, v in metrics.items()}, flush=True)
        runs.append(dict(tag=tag, arm=arm, process=process, metrics=metrics, observation=obs))
        save(out / 'runs.json', runs)
    groups = {arm: {k: dict(samples=[r['metrics'][k] for r in runs if r['arm'] == arm],
                           median=statistics.median(r['metrics'][k] for r in runs if r['arm'] == arm))
                    for k in runs[0]['metrics']} for arm in images}
    ids = next(r['observation']['raw']['generated_ids'] for r in runs if r['arm'] == 'D1')
    same = all(r['observation']['raw']['generated_ids'] == ids for r in runs if r['arm'] != 'llama')
    save(out / 'summary.json', dict(passed=same, groups=groups, Hyle_predictions_match_D1=same,
                                   processes=9, fresh_processes_per_arm=3,
                                   current_over_D1={k: groups['current'][k]['median'] / groups['D1'][k]['median'] for k in groups['current']},
                                   current_over_llama={k: groups['current'][k]['median'] / groups['llama'][k]['median'] for k in groups['current']},
                                   statistical_significance=False, independent_quality_acceptance=False))
    assert same
    print('D4_WINDOW_COMPLETE', out.name, flush=True)


def continuation():
    out = S / 'cached16-timing/attempt1'
    out.mkdir(parents=True, exist_ok=False)
    peer = read(S / 'peer-continuation/ready-for-root.json')
    assert identity(peer['image']['path']) == peer['image']
    fixed_path = S / 'inputs/cached16-fixed-inputs.json'
    fixed = read(fixed_path)
    old_fixed = read(A / 'qwen-gpu-comparison/128-prefill/fixed-inputs.json')
    assert fixed['prompt_ids'] == old_fixed['prompt_ids']
    assert fixed['continuation_ids'] + fixed['decode_input_ids'] == old_fixed['decode_input_ids']
    assert len(fixed['continuation_ids']) == 16 and len(fixed['decode_input_ids']) == 15
    hc, pc = commands()
    hc[0] = CURRENT['path']
    hc[hc.index('--decode-ids') + 1] = str(S / 'inputs/decode-after-continuation15.ids')
    hc[hc.index('--steps') + 1] = '16'
    hc += ['--continuation', str(S / 'inputs/continuation16.ids')]
    pc[0], pc[2] = peer['image']['path'], str(fixed_path)
    # Compare predictions at identical visible prefixes in the earlier sequential journey.
    short = read(S / 'short-timing/runs.json')
    old_ids = {}
    for arm in ('current', 'llama'):
        r = next(x for x in short if x['arm'] == arm)['observation']['raw']
        ids = r['predicted_ids'] if arm == 'llama' else r['generated_ids']
        old_ids[arm] = [ids[0], *ids[16:]]
    order = ['current', 'llama', 'llama', 'current', 'current', 'llama']
    save(out / 'inputs.json', dict(order=order, fixed_inputs=identity(fixed_path),
                                  current=CURRENT, peer=peer['image'], prompt=128, continuation=16, decode=15,
                                  same_native_context=True, context_capacity=256, profiler=False,
                                  memory_monitor=False, page_cache='uncontrolled; not cold disk',
                                  metric='complete host token step; cached continuation excludes cold family/model preparation'))
    runs = []
    for i, arm in enumerate(order, 1):
        tag = f'{i:02}-{arm}'
        cmd = (pc if arm == 'llama' else hc).copy()
        if arm == 'llama':
            cmd[-1] = str(out / (tag + '-peer-result.json'))
        process = execute(out, tag, cmd)
        if arm == 'llama':
            raw = read(cmd[-1])
            obs = dict(raw=raw, phases=raw['phases'], loading=raw['loading'])
            assert raw['prompt_ids'] == fixed['prompt_ids']
            assert raw['continuation_ids'] == fixed['continuation_ids']
            assert raw['decode_input_ids'] == fixed['decode_input_ids']
        else:
            obs = hyle_observation(out, tag)
            assert obs['raw']['decode_input_ids'] == fixed['decode_input_ids']
        rows = obs['phases']
        assert len(rows) == 17
        assert [x['input_tokens'] for x in rows] == [128, 16] + [1] * 15
        assert [x['visible_tokens'] for x in rows] == [128] + list(range(144, 160))
        predictions = [x['predicted_id'] for x in rows]
        differences = [i for i, (a, b) in enumerate(zip(predictions, old_ids[arm])) if a != b]
        t = [x['step_seconds'] for x in rows]
        metrics = dict(prefill_tokens_per_second=128 / t[0],
                       cached_continuation_tokens_per_second=16 / t[1],
                       complete_decode_tokens_per_second=15 / sum(t[2:]))
        print('  cached tps', {k: round(v, 2) for k, v in metrics.items()}, 'prediction_differences', differences, flush=True)
        runs.append(dict(tag=tag, arm=arm, process=process, metrics=metrics, observation=obs,
                         predictions=predictions, versus_same_arm_sequential_prediction_differences=differences))
        save(out / 'runs.json', runs)
    groups = {arm: {k: dict(samples=[r['metrics'][k] for r in runs if r['arm'] == arm],
                           median=statistics.median(r['metrics'][k] for r in runs if r['arm'] == arm))
                    for k in runs[0]['metrics']} for arm in ('current', 'llama')}
    same = all(not x['versus_same_arm_sequential_prediction_differences'] for x in runs)
    save(out / 'summary.json', dict(all_processes_exit_zero=True, groups=groups,
                                   same_arm_grouped_and_sequential_predictions_equal=same,
                                   all_prefix_and_input_boundaries_verified=True,
                                   independent_model_quality_acceptance=False, statistical_significance=False))
    print('D4_CACHED16_COMPLETE', 'same_predictions', same, flush=True)


if __name__ == '__main__':
    {'smoke': smoke, 'short': timing, 'long': lambda: timing(True), 'continuation': continuation}[sys.argv[1]]()
