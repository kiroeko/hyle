"""Two short memory-only observations; run separately from D4 throughput.

Root runs this script when the Windows GPU window is available. No builds.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import re
import statistics
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def marker(line):
    if line.startswith('weights_load_seconds='):
        return 'model_loaded'
    if line.startswith('initialized '):
        return 'ready_before_prefill'
    if line.startswith('prefill tokens='):
        return 'prefill_complete'
    if line.startswith('decode31 tokens='):
        return 'inference_complete'
    if line.startswith('measure_memory '):
        match = re.search(r'\bname=(\S+)', line)
        if match:
            return match.group(1)
    return None


def stats(values):
    return dict(count=len(values), min=min(values), median=statistics.median(values), max=max(values)) if values else dict(count=0, min=None, median=None, max=None)


def run_one(root, Probe, out, arm, command):
    folder = out / arm
    folder.mkdir()
    command = list(map(str, command))
    if arm == 'reference':
        command[-1] = str(folder / 'peer-result.json')
    record = dict(arm=arm, command=command, cwd=str(root.ROOT), image=root.identity(command[0]),
                  started_unix_ns=time.time_ns(), markers=[], memory_only=True,
                  throughput_evidence=False, profiler=False)
    root.save(folder / 'command.json', record)
    reader_errors = []

    def stderr_reader(stream, destination):
        try:
            for raw in iter(stream.readline, b''):
                timestamp = time.perf_counter_ns()
                unix_time = time.time_ns()
                destination.write(raw)
                line = raw.decode('utf-8', errors='replace').rstrip()
                name = marker(line)
                if name:
                    record['markers'].append(dict(name=name, timestamp_ns=timestamp,
                                                   unix_time_ns=unix_time, line=line))
        except Exception as error:
            reader_errors.append(repr(error))

    # Persistent PDH query creation/priming precedes target creation.
    with Probe(interval_s=0.05) as memory, (folder / 'stdout.log').open('wb') as so, (folder / 'stderr.log').open('wb') as se:
        record['popen_perf_ns'] = time.perf_counter_ns()
        record['popen_unix_ns'] = time.time_ns()
        process = subprocess.Popen(command, cwd=root.ROOT, env=root.ENV, stdout=so,
                                   stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        reader = threading.Thread(target=stderr_reader, args=(process.stderr, se), daemon=True)
        reader.start()
        try:
            memory.start(process.pid)
            try:
                record['exit'] = process.wait(timeout=300)
            except subprocess.TimeoutExpired:
                record['timeout'] = True
                process.kill()
                record['exit'] = process.wait()
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
            reader.join()
            process.stderr.close()
            memory.stop()
            sampled = memory.result()
            root.save(folder / 'memory.json', sampled)
            record.update(finished_perf_ns=time.perf_counter_ns(),
                          finished_unix_ns=time.time_ns(), reader_errors=reader_errors)
            root.save(folder / 'result.json', record)

    running = [row for row in sampled['samples'] if row.get('process_running')]
    keys = ('working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes', 'gpu_shared_bytes')
    boundaries = {row['name']: row['timestamp_ns'] for row in record['markers']}
    windows = {}
    points = [('loading', record['popen_perf_ns'], boundaries.get('model_loaded')),
              ('post_load_preparation', boundaries.get('model_loaded'), boundaries.get('ready_before_prefill')),
              ('prefill', boundaries.get('ready_before_prefill'), boundaries.get('prefill_complete')),
              ('decode31', boundaries.get('prefill_complete'), boundaries.get('inference_complete'))]
    for name, begin, end in points:
        rows = [row for row in running if begin <= row['timestamp_ns'] <= end] if begin is not None and end is not None else []
        windows[name] = dict(start_ns=begin, end_ns=end, sample_count=len(rows),
                             **{key: stats([row[key] for row in rows if row.get(key) is not None]) for key in keys})
    gaps = [(right['timestamp_ns'] - left['timestamp_ns']) / 1e6 for left, right in zip(running, running[1:])]
    reasons = {}
    for row in sampled['samples']:
        for kind in ('dedicated', 'shared'):
            reason = row.get('gpu_' + kind + '_unavailable_reason')
            if reason:
                key = kind + ':' + reason
                reasons[key] = reasons.get(key, 0) + 1
    summary = dict(exit=record['exit'], timeout=record.get('timeout', False),
                   process_terminal=True, peaks=sampled['peaks'], samples=len(sampled['samples']),
                   running_samples=len(running), actual_sample_gaps_ms=stats(gaps),
                   sample_cost_ms=stats([row['sample_duration_ns'] / 1e6 for row in running]),
                   gpu_valid_running_samples={kind: sum(bool(row.get('gpu_' + kind + '_available')) for row in running) for kind in ('dedicated', 'shared')},
                   unavailable_reasons=reasons, gpu_setup_error=sampled['gpu_setup_error'],
                   sampler_thread_error=sampled['thread_error'], reader_errors=reader_errors,
                   windows=windows, throughput_evidence=False)
    root.save(folder / 'summary.json', summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=S / 'memory-observations')
    args = parser.parse_args()
    root = load('d4_memory_original_root_run', S / 'root_run.py')
    sampler_path = root.A / 'qwen-gpu-comparison/memory-probe/memory_probe.py'
    Probe = load('d4_original_memory_probe', sampler_path).MemoryProbe
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    hyle, peer = root.commands(long=False)
    hyle[0] = root.CURRENT['path']
    assert '--trace' not in hyle and '--continuation' not in hyle
    root.save(out / 'inputs.json', dict(driver=root.identity(__file__),
              original_runner=root.identity(S / 'root_run.py'), sampler=root.identity(sampler_path),
              current_image=root.CURRENT, reference_image=root.identity(peer[0]),
              reference_fixed_inputs=root.identity(peer[2]), environment_source=root.identity(S / 'checks/link1/runtime-environment.json'),
              PATH=root.ENV['PATH'], requested_interval_seconds=0.05,
              order=['current', 'reference'], fresh_processes_per_arm=1,
              scope='Original short128+31 commands and root ENV; separate memory-only window, no throughput sample or continuation attribution.',
              builds=0, profiler=False, throughput_evidence=False,
              limits=['Missing WDDM/PDH counters stay null with reasons, never zero.',
                      'GPU/current-memory sampled maxima are lower bounds; marker windows use parent stderr receipt times.',
                      'Observed OS peaks are process-lifetime high-water marks, not phase peaks.',
                      'PrivateUsage is commit; working set can contain shared/mapped pages. Do not add CPU/GPU overlapping accounting.',
                      'One fresh process per arm is an observation, not a memory distribution or isolated allocation attribution.']))
    results = {}
    for arm, command in [('current', hyle), ('reference', peer)]:
        print('MEMORY_START', arm, flush=True)
        results[arm] = run_one(root, Probe, out, arm, command)
        root.save(out / 'summary.json', dict(arms=results, throughput_evidence=False))
        print('MEMORY_END', arm, 'exit', results[arm]['exit'], flush=True)
        if results[arm]['exit'] != 0 or results[arm]['timeout']:
            raise RuntimeError('Memory-only target failed; original logs retained: ' + arm)


if __name__ == '__main__':
    main()
