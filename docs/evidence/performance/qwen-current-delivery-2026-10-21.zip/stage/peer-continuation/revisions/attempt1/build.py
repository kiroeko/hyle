"""Build only the optional-continuation peer adapter; never run inference."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
D = S.parent
A = D.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('d4_existing_host_helpers', D / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def identity(path):
    return b.identity(Path(path))


def same(row):
    p = Path(row['path'])
    return p.exists() and all(identity(p)[k] == row[k] for k in ['bytes', 'sha256'])


def main():
    base_path = A / 'decode-prepare-cost/long-peer/link-plan.json'
    base = c.read(base_path)
    source = S / 'peer_benchmark.cpp'
    original = S / 'original-peer_benchmark.cpp'
    assert same(base['source']) and identity(original)['sha256'] == base['source']['sha256']
    out = S / 'checks/attempt1'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), 'Preserve the first actual attempt.'

    command = []
    skip = False
    for x in base['compile_command']:
        if skip:
            skip = False
            continue
        if x.lower() == '/sourcedependencies':
            skip = True
            continue
        if c.key(x) == c.key(base['source']['path']) or x.lower().startswith(('/fo', '/fd')):
            continue
        command.append(x)
    command += ['/sourceDependencies', str(out / 'peer-deps.json'), str(source),
                '/Fo' + str(out / 'peer.obj'), '/Fd' + str(out / 'peer.pdb')]
    # Preserve every original compiler option; no warning-mode changes.
    def flags(cmd):
        return [x for x in cmd if x.startswith('/') and not x.lower().startswith(('/fo', '/fd'))
                and x.lower() != '/sourcedependencies']
    assert flags(command) == flags(base['compile_command'])
    env, runtime = b.environment(command, [x['path'] for x in base['inputs']], out)
    runtime = list(dict.fromkeys([*base['runtime'], *runtime]))
    env['PATH'] = os.pathsep.join([*runtime, env['PATH']])
    c.save(out / 'compile-plan.json', dict(command=command, source=identity(source),
        original_source=identity(original), original_recipe=identity(base_path),
        unchanged_original_flags=True, SDK_builds=0, GPU_runs=0))
    c.execute('compile', command, env, out)
    dep_data = c.read(out / 'peer-deps.json')['Data']
    dependencies = [identity(p) for p in dict.fromkeys([dep_data['Source'], *dep_data['Includes']])]
    obj = identity(out / 'peer.obj')
    c.save(out / 'identity.json', dict(command=command, source=identity(source), object=obj,
        dependencies=dependencies, source_dependencies=identity(out / 'peer-deps.json'),
        original_recipe=identity(base_path), original_source=identity(original),
        warning_policy_unchanged=True, SDK_builds=0, GPU_runs=0))

    old = next(x for x in base['inputs'] if c.key(x['path']) == c.key(base['command'][6]))
    assert Path(old['path']).suffix == '.obj'
    kept = [x for x in base['inputs'] if c.key(x['path']) != c.key(old['path'])]
    assert all(same(x) for x in kept)
    image = out / 'peer.exe'
    link = [obj['path'] if c.key(x) == c.key(old['path']) else x for x in base['command']
            if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
             '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=link, inputs=[obj, *kept],
        source=identity(source), original_recipe=identity(base_path), replaced_object=old,
        CXX=1, links=1, SDK_builds=0, GPU_runs=0))
    c.execute('link', link, env, out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.save(S / 'ready-for-root.json', dict(status='adapter_compiled_and_linked_not_executed',
        image=identity(image), source=identity(source), object=obj,
        compile_identity=identity(out / 'identity.json'), link_plan=identity(out / 'link-plan.json'),
        runtime_environment=identity(out / 'runtime-environment.json'),
        original_source=identity(original), source_diff=identity(S / 'peer-continuation.diff'),
        CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0,
        scope='Only optional consumer continuation phase; original llama/ggml binaries and math remain unchanged.'))
    print('READY', image, flush=True)


if __name__ == '__main__':
    main()
