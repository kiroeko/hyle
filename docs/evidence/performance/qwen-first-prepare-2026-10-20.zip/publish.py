from pathlib import Path
import json,hashlib,zipfile
S=Path(__file__).resolve().parent;R=S.parents[2]
def J(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def I(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
freeze=J(S/'source-freeze.json');assert I(R/'tools/qwen35_text/main.cc')==freeze['product_before'];review=J(S/'source-review.json');diag=J(S/'diagnostic/summary.json');assert diag['passed']and diag['model_processes']==2
for row in J(S/'checks/link-plan.json')['inputs']:assert I(row['path'])==row
proof=[]
for arm in diag['arms']:
 for row in arm['vectors']:
  assert I(row['actual']['path'])==row['actual'] and I(row['reference']['path'])==row['reference'];assert row['actual']['sha256']==row['reference']['sha256'];proof.append(dict(mode=arm['mode'],logical_path=row['path'],actual=row['actual'],canonical_reference=row['reference'],byte_equal=True))
save(S/'diagnostic/vector-hash-proof.json',dict(exact_prefix_vectors_per_mode=6,raw_duplicate_vectors_excluded=True,prior_evidence=I(R/'docs/evidence/performance/qwen-stable-bind-2026-10-20.json'),vectors=proof))
allowed={'.cc','.h','.py','.json','.diff','.log','.xml','.tsv','.ids','.txt'}
files=sorted([p for p in S.rglob('*')if p.is_file()and not(set(p.relative_to(S).parts)&{'tmp','__pycache__'})and p.suffix in allowed and p.name not in {'publication.json','payload-sha256.json'}],key=lambda p:p.relative_to(S).as_posix())
dest=R/'docs/evidence/performance/qwen-first-prepare-2026-10-20.zip';manifest=[]
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  row=dict(member=p.relative_to(S).as_posix(),**I(p));manifest.append(row);z.writestr(row['member'],p.read_bytes())
 z.writestr('payload-sha256.json',json.dumps(manifest,indent=2,ensure_ascii=False).encode())
with zipfile.ZipFile(dest)as z:
 assert z.testzip()is None
 for row in manifest:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
 assert not any(Path(n).suffix.lower()in {'.exe','.obj','.lib','.exp','.map','.pdb','.bf16','.f32'}for n in z.namelist())
report=dict(date='2026-10-20',status='first_preparation_cost_localized_scratch_only',purpose='Locate the9.5–13.8ms first2parity coldpreparation from prior peerwindow; do not move preparation outside a timer or claim speedup.',prior_window=I(R/'docs/evidence/performance/qwen-stable-bind-2026-10-20.json'),source=dict(product_unchanged=freeze['product_before'],scratch_instrumented=freeze['candidate'],before=freeze['before'],diff=I(S/'main.diff'),freeze=I(S/'source-freeze.json'),common_link_plan=I(S/'checks/link-plan.json'),common_inputs=149),instrumentation=dict(original_total_cold_boundary_retained=True,interior_clock_points_added=3,stages=['layoutversion/arrays','batch::prepare','Invocation::prepare_replay','replay report'],private_or_core_hooks=False,profiler=False),observations=dict(first2_totals=review['first2_totals'],first2_replay_delta_seconds=review['first2_replay_delta_seconds'],all3phases={arm['mode']:arm['stages']for arm in diag['arms']},full_step_control=J(S/'diagnostic/full-boundary-control.json'),conclusions=review['conclusions']),root_cause_scope='Most extra firstcoldtime versus command-preparation control sits in the firstcapture lifecycle. This aggregate includes actualcommand encoding,CUDAgraphinstantiate andretirement; APIselftimes/callbackcounts are unmeasured. No particular allocator/query proven dominant.',source_findings=review['source_chain'],next_candidates=review['candidate_status'],source_excerpts=I(S/'source-excerpts/index.json'),route_inventory=review['route_inventory'],correctness=dict(both_modes_exit0=True,exact6prefix_each=True,all_finite=True,hash_proof=I(S/'diagnostic/vector-hash-proof.json'),summary=I(S/'diagnostic/summary.json'),independent_quality_acceptance=False),actual_process_counts=review['actual_process_counts'],first_CLI_rejection=review['failed_preflight'],limits=review['limits']+['Commands mode encodes during actualsubmit, not duringprepare: first2submit10.0989ms versus captured0.3699ms. The6.8561ms prepare delta is not saved inference time; fullstep sums are28.9378/25.2236ms in these single diagnostic processes.','No throughput window, furtherGPUexperiment,publiccorechange,precisionchange or optimization adopted in this diagnostic batch.','Parent may review same-Completion repeatednative query proof separately; no implementation or measured benefit signed here.'],archive=dict(**I(dest),payloads=len(manifest),CRC_checked=True,all_payload_SHA256_checked=True,excluded='Executables/objects/libs/SDK/fullmaps/duplicate raw prefixvectors.'))
path=dest.with_suffix('.json');save(path,report);save(S/'publication.json',dict(report=I(path),archive=I(dest),payloads=len(manifest),passed=True));print(json.dumps(dict(report=I(path),archive=I(dest),payloads=len(manifest)),indent=2))
