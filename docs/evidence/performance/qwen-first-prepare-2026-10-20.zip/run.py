from pathlib import Path
import importlib.util,sys,json,re
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;O=S/'diagnostic';O.mkdir(exist_ok=True)
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=load('first_prepare_run_helpers',A/'grouped-shared-activation/build_host.py');b,c=h.b,h.c;n=load('first_prepare_numeric_helpers',A/'cuda-bf16-dual-projection/compare_numerics.py');link=c.read(S/'checks/link-plan.json');image=c.read(S/'checks/image.json');freeze=c.read(S/'source-freeze.json');reference=A/'batch-graph-capture/correctness-final';template=c.read(reference/'qwen.command.json')['command'];refresult=n.final_json(reference/'qwen.stdout.log');results=[]
for row in [image,*link['inputs']]:assert h.same_identity(row)
for mode in ['prefer-capture','commands']:
 out=O/(mode+'-fixed-prefix');out.mkdir(exist_ok=False);(out/'tmp').mkdir();command=template.copy();command[0]=image['path'];command[command.index('--steps')+1]='3';command[command.index('--decode-ids')+1]=str(S/'fixed-prefix2.ids');command[command.index('--replay')+1]=mode;command[command.index('--trace')+1]=str(out/'trace')
 env,runtime=b.environment(link['command'],[x['path']for x in link['inputs']],out);c.save(out/'inputs.json',dict(command=command,image=image,source=freeze['candidate'],source_freeze=b.identity(S/'source-freeze.json'),link=b.identity(S/'checks/link-plan.json'),runtime=runtime,mode=mode,profiler=False,external_memory_monitor=False,throughput_window=False));c.execute('qwen',command,env,out)
 actual=n.final_json(out/'qwen.stdout.log');assert actual['generated_ids']==refresult['generated_ids'][:3]and actual['decode_input_ids']==refresult['decode_input_ids'][:2]and actual['visible_tokens']==130
 paths=sorted(p.relative_to(out/'trace')for p in (out/'trace').rglob('*')if p.suffix in('.bf16','.f32'));assert len(paths)==6;vectors=[]
 for rel in paths:
  v=n.identity(out/'trace'/rel);r=n.identity(reference/'trace'/rel);assert v['bytes']==r['bytes']and v['sha256']==r['sha256'];m=n.metrics(out/'trace'/rel,reference/'trace'/rel);assert not any(m[k]for k in ['candidate_nan','candidate_posinf','candidate_neginf']);vectors.append(dict(path=rel.as_posix(),actual=v,reference=r,byte_equal=True,metrics=m))
 text=(out/'qwen.stderr.log').read_text();stages=[]
 pattern=r'^prepared T=(\d+) visible=(\d+) replay=(\w+) cold_batch_seconds=([0-9.e+-]+) cold_layout_seconds=([0-9.e+-]+) cold_prepare_seconds=([0-9.e+-]+) cold_replay_seconds=([0-9.e+-]+) cold_report_seconds=([0-9.e+-]+) capture_recorded=(\d+) capture_reused=(\d+)'
 for t,v,route,total,layout,batch,replay,report,recorded,reused in re.findall(pattern,text,re.M):
  row=dict(tokens=int(t),visible=int(v),route=route,cold_total_seconds=float(total),layout_seconds=float(layout),batch_seconds=float(batch),replay_seconds=float(replay),report_seconds=float(report),recorded=int(recorded),reused=int(reused));row['printed_stage_sum_error_seconds']=row['cold_total_seconds']-sum(row[k]for k in ['layout_seconds','batch_seconds','replay_seconds','report_seconds']);assert abs(row['printed_stage_sum_error_seconds'])<2e-7;stages.append(row)
 assert len(stages)==3;assert all(r['recorded']==(1 if mode=='prefer-capture'else 0)and r['reused']==0 for r in stages)
 result=dict(mode=mode,passed=True,process=c.read(out/'qwen.result.json'),generated_ids=actual['generated_ids'],same_prefix_ids=True,exact_vectors=6,all_finite=True,vectors=vectors,stages=stages);c.save(out/'summary.json',result);results.append(result)
assert h.same_identity(freeze['product_before']);c.save(O/'summary.json',dict(passed=True,model_processes=2,exit0=2,arms=results,product_unchanged=True,throughput_window=False,limits=['One short128+2process per replay mode. Components locate cost, not stable timing medians or throughput improvements.','Both preserve the original total cold/step boundary and exact6prefix vectors. Commands mode changes recording behavior for diagnosis; its GPU submission timeline is not the captured production performance workload.','No core/native hook or private API instrumentation; replay_seconds includes generic binding/dependencies and capture lifecycle together.']))
print('FIRST_PREPARE_TWO_MODES_EXACT6_GREEN')
