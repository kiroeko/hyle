"""Only transform frozen copies; never writes product paths."""
from pathlib import Path
import difflib
import re


def once(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new, 1)


def section(text, start, end, transform):
    begin=text.index(start);finish=text.index(end,begin+len(start))
    return text[:begin]+transform(text[begin:finish])+text[finish:]


def frame(body, bucket, context='bind_diag::context()', root=False):
    # Locate the actual parameter list, then its anchored noexcept body.
    # A default ValueId{} is inside that list and cannot be the insertion site.
    opening=body.index('(');depth=0;closing=None
    for index in range(opening,len(body)):
        if body[index]=='(':depth+=1
        elif body[index]==')':
            depth-=1
            if depth==0:closing=index;break
    assert closing is not None
    match=re.match(r'\s*noexcept\s*\{',body[closing+1:])
    assert match is not None,body[:closing+100]
    at=closing+1+match.end()
    assert len(re.findall(r'\bnoexcept\b',body[:at]))==1
    line='\n  bind_diag::Frame bind_attribution_scope('+context+', bind_diag::Bucket::'+bucket+(', true' if root else '')+');'
    return body[:at]+line+body[at:]


def resources(text):
    text=once(text,'#include "hyle/graph/executable.h"',
        '#include "hyle/graph/executable.h"\n#include "bind_diag.h"\n'
        'namespace {\nstruct BindAttributionFinalReport final {\n'
        '  ~BindAttributionFinalReport() { bind_diag::print(); }\n};\n'
        'BindAttributionFinalReport bind_attribution_final_report;\n}\n')
    def native(body):
        body=frame(body,'NativeInputScan')
        body=once(body,'  const auto &plan = *state.plan;',
            '  bind_diag::event(bind_diag::Event::NativeStepsScanned, state.step_bindings.size());\n  const auto &plan = *state.plan;')
        body=once(body,'    if (!state.step_bindings[index].native_inputs)\n      continue;',
            '    if (!state.step_bindings[index].native_inputs)\n      continue;\n    bind_diag::event(bind_diag::Event::NativeInputsHit);')
        body=once(body,'    if (affected)\n      invalidate_step_recording(state, static_cast<std::uint32_t>(index));',
            '    if (affected) {\n      bind_diag::event(bind_diag::Event::NativeInvalidations);\n      invalidate_step_recording(state, static_cast<std::uint32_t>(index));\n    }')
        return body
    text=section(text,'void invalidate_native_input_bindings(', 'void clear_binding_owner(',native)
    def borrowed(body):
        body=frame(body,'BorrowedCleanup')
        return once(body,'  const auto extras = bindings.begin() + episode.fixed_binding_count;',
            '  bind_diag::event(bind_diag::Event::ExtrasScanned, bindings.size() - episode.fixed_binding_count);\n'
            '  const auto extras = bindings.begin() + episode.fixed_binding_count;')
    text=section(text,'void note_borrowed_binding(', 'Status RegionAccess::bind_configuration(',borrowed)
    text=section(text,'Status check_output_consumer(', 'bool same_projection(',lambda b:frame(b,'ConsumerCheck'))
    text=section(text,'Result<StoreProjectionInputs> RegionAccess::store_source_projection(',
        'SubmissionSource::SubmissionSource(',lambda b:frame(b,'SourceProjection'))
    text=section(text,'Status RegionAccess::bind_written_projection(',
        'Status RegionAccess::bind_write_effect(',lambda b:frame(b,'WrittenProjection'))
    text=section(text,'Status RegionAccess::bind_write_effect(',
        'Status RegionAccess::release_write_effect(',lambda b:frame(b,'WriteEffect'))
    def bind(body):
        body=frame(body,'BundleProof','bind_diag::Context::Bind',True)
        body=once(body,'  const auto allocator = source->metadata_owner.allocator();',
            '  bind_diag::event(bind_diag::Event::Entries, bindings.size());\n'
            '  bind_diag::event(bind_diag::Event::IncomingInputs, incoming_count);\n'
            '  bind_diag::event(bind_diag::Event::Tickets, ticket_count);\n'
            '  if (state->resources) bind_diag::event(bind_diag::Event::BindResourceRecords, state->resources.get()->bindings.size());\n'
            '  bind_attribution_scope.stage(bind_diag::Bucket::BundleMetadata);\n'
            '  const auto allocator = source->metadata_owner.allocator();')
        body=once(body,'    // Exact final input identities and selected projection qualification are',
            '    bind_attribution_scope.stage(bind_diag::Bucket::BundleProof);\n'
            '    // Exact final input identities and selected projection qualification are')
        body=once(body,'    HYLE_ASSIGN_OR_RETURN(bundle->all_ready, output_bundle_ready(*bundle));',
            '    bind_attribution_scope.stage(bind_diag::Bucket::BundleReady);\n'
            '    HYLE_ASSIGN_OR_RETURN(bundle->all_ready, output_bundle_ready(*bundle));\n'
            '    bind_diag::event(bundle->all_ready ? bind_diag::Event::AllReadyBundles : bind_diag::Event::PendingBundles);')
        body=once(body,'    HYLE_RETURN_IF_ERROR(check_output_consumer(invocation, *bundle, {}, false));',
            '    bind_attribution_scope.stage(bind_diag::Bucket::BundleProof);\n'
            '    HYLE_RETURN_IF_ERROR(check_output_consumer(invocation, *bundle, {}, false));\n'
            '    bind_attribution_scope.stage(bind_diag::Bucket::BundleMetadata);')
        body=once(body,'    HYLE_RETURN_IF_ERROR(InputAccess::bind(invocation, incoming,effects));',
            '    bind_attribution_scope.stage(bind_diag::Bucket::InputAtomic);\n'
            '    HYLE_RETURN_IF_ERROR(InputAccess::bind(invocation, incoming,effects));\n'
            '    bind_attribution_scope.stage(bind_diag::Bucket::BundleCommit);')
        return body
    text=section(text,'Status bind_outputs(', 'Status release_outputs(',bind)
    def prepare(body):
        body=frame(body,'PrepareResolve','bind_diag::Context::Prepare',True)
        return once(body,'  if (bundle->all_ready) {',
            '  bind_attribution_scope.stage(bind_diag::Bucket::PrepareReplay);\n  if (bundle->all_ready) {')
    text=section(text,'Status prepare_outputs(', 'Result<compute::Completion> submit_outputs(',prepare)
    def submit(body):
        body=frame(body,'SubmitResolve','bind_diag::Context::Submit',True)
        return once(body,'  auto result = RegionAccess::submit(invocation, queues, ordered);',
            '  bind_attribution_scope.stage(bind_diag::Bucket::SubmitNative);\n'
            '  auto result = RegionAccess::submit(invocation, queues, ordered);')
    text=section(text,'Result<compute::Completion> submit_outputs(', '} // namespace detail\n\nGraphOutput::GraphOutput',submit)
    return text


def slots(text):
    text=once(text,'#include "slots_region.h"','#include "slots_region.h"\n#include "bind_diag.h"')
    def upload(body):
        body=once(body,'    if (unchanged) return Status::Ok();',
            '    if (unchanged) {\n      bind_diag::event(bind_diag::Event::IdsUnchanged);\n      return Status::Ok();\n    }\n'
            '    bind_diag::event(bind_diag::Event::IdsChanged);\n'
            '    bind_diag::event(bind_diag::Event::IdsBytes, count * sizeof(std::int32_t));')
        return once(body,'    const auto terminal = pending.wait();',
            '    const auto terminal = [&]() noexcept {\n'
            '      bind_diag::Frame bind_attribution_wait(bind_diag::context(), bind_diag::Bucket::IdsWait);\n'
            '      bind_diag::event(bind_diag::Event::IdsWaits);\n'
            '      return pending.wait();\n    }();')
    text=section(text,'  Status upload(', '\nstruct ControlGroup final',upload)
    def bind(body):
        body=frame(body,'SlotPreflight','bind_diag::Context::Slots',True)
        body=once(body,'  if (requests.empty()) return Status::Ok();',
            '  bind_diag::event(bind_diag::Event::SlotRequests, requests.size());\n'
            '  if (requests.empty()) return Status::Ok();')
        body=once(body,'    auto &s = *data; const auto &p = s.facts;',
            '    auto &s = *data; const auto &p = s.facts;\n'
            '    bind_diag::event(s.mode == SourceMode::kImported ? bind_diag::Event::ImportedRequests : bind_diag::Event::TransactionRequests);')
        body=once(body,'  // Reserve the complete actual footprint before installing any permission.',
            '  bind_attribution_scope.stage(bind_diag::Bucket::SlotConfigureInstall);\n'
            '  // Reserve the complete actual footprint before installing any permission.')
        body=once(body,'  for (auto &group : controls->groups) {\n    if (!group.participants) continue;\n    HYLE_RETURN_IF_ERROR(group.indices.upload(',
            '  bind_attribution_scope.stage(bind_diag::Bucket::SlotIds);\n'
            '  for (auto &group : controls->groups) {\n    if (!group.participants) continue;\n    HYLE_RETURN_IF_ERROR(group.indices.upload(')
        body=once(body,'  const auto install = [&]() noexcept -> Status {',
            '  bind_attribution_scope.stage(bind_diag::Bucket::SlotConfigureInstall);\n'
            '  const auto install = [&]() noexcept -> Status {')
        return body
    text=section(text,'Status bind(Invocation &invocation, const Graph &graph,\n    std::span<const BindRequest> requests)',
        'Result<SlotBindings> take(',bind)
    return text


def transform(name, original, output):
    original=Path(original);output=Path(output)
    raw=original.read_bytes();text=raw.decode('utf-8-sig');newline='\r\n' if b'\r\n' in raw else '\n'
    normalized=text.replace('\r\n','\n')
    result={'resources':resources,'slots':slots}[name](normalized)
    output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(result.replace('\n',newline).encode('utf-8'))
    patch=''.join(difflib.unified_diff(normalized.splitlines(True),result.splitlines(True),
        fromfile=str(original),tofile=str(output)))
    output.with_suffix('.patch').write_text(patch,encoding='utf-8',newline='\n')
    return dict(name=name,source=str(original),snapshot=str(output),patch=str(output.with_suffix('.patch')))
