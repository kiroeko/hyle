from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
build=module('bind_attribution_build',W/'build2.py');m,h=build.m,build.h
screen=module('bind_attribution_original_facts',R/'.scratch/inference-identical-capture-inputs-20261027/screen.py')


def prepare():
    ready=m.read(W/'ready.json')
    screen_summary=R/'.scratch/inference-identical-capture-inputs-20261027/screen-summary.json'
    rows=m.read(screen_summary)['runs'];runs=[]
    for mode in ['off','auto']:
        reference=next(row for row in rows if row['arm']=='candidate' and row['mode']==mode)
        command=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
            '--backend','cuda','--mtp','off','--capacity','256','--steps','97','--max-sessions','1','--active-sequences','1','--decode-overlap',mode]
        runs.append(dict(mode=mode,command=command,directory=str(W/('run-'+mode)),timeout_seconds=180,reference_report=reference['report']))
    m.save(W/'run-plan.json',dict(status='PREPARED_NOT_RUN',ready=m.pin(W/'ready.json'),runs=runs,
        facts_rule=m.pin(R/'.scratch/inference-identical-capture-inputs-20261027/screen.py'),screen_reference=m.pin(screen_summary),
        boundary='Exactly two ordinary CUDA R1 P154 +96 decode diagnostic processes, one per mode. Full per-mode non-time report equality uses the unchanged W7 facts predicate. Timers are host-call wall durations with nested exclusions, not CPU usage, net speed evidence or new formal TPS.'))
    print('PREPARED off/auto commands only; no GPU',flush=True)


def run(mode):
    plan=m.read(W/'run-plan.json');row=next(x for x in plan['runs'] if x['mode']==mode)
    ready=m.read(plan['ready']['path'])
    image_stat=Path(ready['image']['path']).stat()
    assert image_stat.st_size==ready['image']['bytes'] and image_stat.st_mtime_ns==plan['image_mtime_ns']
    # Object/source closure was already checked at link. No batch hashing or
    # build/compression is done in this mutually exclusive timing window.
    out=Path(row['directory']);assert not out.exists(),'No automatic retry'
    process=h.execute(row['command'],build.environment(),out,timeout=row['timeout_seconds'])
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    m.save(out/'report.json',report)
    reference=m.read(row['reference_report']['path'])
    assert screen.facts(report)==screen.facts(reference),'Complete per-mode non-time report changed'
    assert report['generated_tokens']==97 and report['generated_decode_tokens']==96 and report['live_committed_versions']==0
    assert report['overlap_successor_publications']==(44 if mode=='auto' else 0)
    assert report['overlap_successor_refusals']==report['overlap_successor_discards']==0
    lines=[line[len('BIND_DIAG '):] for line in (out/'stderr.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('BIND_DIAG ')]
    assert len(lines)==1,'Expected one final diagnostic JSON line'
    diagnostic=json.loads(lines[0]);assert diagnostic['schema']==1 and diagnostic['sum_exclusive_only']
    m.save(out/'bind-diag.json',diagnostic)
    summary=dict(status='PASS',mode=mode,process=process,image=ready['image'],report=m.pin(out/'report.json'),
        diagnostic=m.pin(out/'bind-diag.json'),reference=row['reference_report'],complete_non_time_facts_equal=True)
    m.save(out/'summary.json',summary)
    existing=[m.read(p) for p in sorted(W.glob('run-*/summary.json'))]
    m.save(W/'run-summary.json',dict(status='PASS' if len(existing)==2 else 'PARTIAL_PASS',successful_processes=len(existing),runs=existing,
        scope='Two diagnostic ordinary processes only; no new peer/MTP/memory/performance statistical window. Original clock endpoints and math/permission path unchanged.'))
    print('PASS '+mode+' PID'+str(process['pid']),flush=True)


def analyze():
    values={mode:m.read(W/('run-'+mode)/'bind-diag.json') for mode in ['off','auto']}
    contexts={}
    for context in values['off']['contexts']:
        old=values['off']['contexts'][context];new=values['auto']['contexts'][context]
        names=set(old['buckets'])|set(new['buckets']);buckets={}
        for name in sorted(names):
            a=old['buckets'].get(name,{});b=new['buckets'].get(name,{})
            buckets[name]=dict(off_ms=a.get('exclusive_ns',0)/1e6,auto_ms=b.get('exclusive_ns',0)/1e6,
                auto_minus_off_ms=(b.get('exclusive_ns',0)-a.get('exclusive_ns',0))/1e6,
                off_inclusive_ms=a.get('inclusive_ns',0)/1e6,auto_inclusive_ms=b.get('inclusive_ns',0)/1e6,
                off_segments=a.get('segments',0),auto_segments=b.get('segments',0))
        contexts[context]=dict(off_root_calls=old['root_calls'],auto_root_calls=new['root_calls'],buckets=buckets,
            off_events=old['events'],auto_events=new['events'],
            off_exclusive_ms=sum(x.get('exclusive_ns',0) for x in old['buckets'].values())/1e6,
            auto_exclusive_ms=sum(x.get('exclusive_ns',0) for x in new['buckets'].values())/1e6)
    m.save(W/'attribution-summary.json',dict(status='ANALYZED_SINGLE_PAIR',contexts=contexts,
        boundaries=['Only exclusive buckets may be added. Inclusive parent values are drill-down views, not additional cost.',
          'Other context includes cold setup and Source export/publication paths; never silently charge it to bind or replay.',
          'Metadata upload wait is elapsed blocking time, not host CPU consumption.',
          'This pair uses current frozen generic resources and original W7 Model/Graph. The historical 26ms from Model3 is not subtracted or assumed unchanged.',
          'Batch prepare/append descriptor work outside these observed Graph calls remains unmeasured residual. No first8/A43/B44 label is invented without a Model episode marker.',
          'Diagnostic clocks/counters perturb host work; these reports do not replace formal TPS or establish statistical gain.']))
    print('ANALYZED exclusive contexts; no timing values published as formal TPS',flush=True)

if __name__=='__main__':
    try:
        if sys.argv[1]=='prepare':prepare()
        elif sys.argv[1]=='run':run(sys.argv[2])
        elif sys.argv[1]=='analyze':analyze()
        else:raise ValueError(sys.argv[1])
    except BaseException:
        (W/('failure-'+'-'.join(sys.argv[1:])+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
