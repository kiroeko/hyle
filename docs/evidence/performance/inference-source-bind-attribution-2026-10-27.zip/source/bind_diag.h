#pragma once
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdio>

// Scratch-only diagnostic for one serialized R1 control thread. No work,
// permission, ownership or Completion is created or observed by this header.
namespace bind_diag {
using Clock = std::chrono::steady_clock;
enum class Context : std::size_t { Other, Bind, Slots, Prepare, Submit, Count };
enum class Bucket : std::size_t {
  BundleProof, BundleMetadata, BundleReady, InputAtomic, BundleCommit,
  ConsumerCheck, BorrowedCleanup, NativeInputScan, SlotPreflight,
  SourceProjection, SlotIds, IdsWait, SlotConfigureInstall, WriteEffect,
  WrittenProjection, PrepareResolve, PrepareReplay, SubmitResolve, SubmitNative, Count
};
enum class Event : std::size_t {
  Entries, IncomingInputs, Tickets, BindResourceRecords, SlotRequests,
  ImportedRequests, TransactionRequests, NativeStepsScanned, NativeInputsHit,
  NativeInvalidations, ExtrasScanned, IdsUnchanged, IdsChanged, IdsBytes,
  IdsWaits, AllReadyBundles, PendingBundles, Count
};
inline constexpr const char *context_names[]{"other", "bind_outputs", "slot_bind", "prepare_outputs", "submit_outputs"};
inline constexpr const char *bucket_names[]{
  "bundle_proof", "bundle_metadata", "bundle_ready_observation", "input_atomic_other", "bundle_commit",
  "consumer_check", "borrowed_cleanup_other", "native_input_scan", "slot_preflight",
  "source_projection", "slot_ids_other", "slot_ids_wait", "slot_configure_install", "write_effect",
  "written_projection", "prepare_resolve", "prepare_replay_other", "submit_resolve", "submit_native_other"};
inline constexpr const char *event_names[]{
  "entries", "incoming_inputs", "tickets", "bind_resource_records", "slot_requests", "imported_requests",
  "transaction_requests", "native_steps_scanned", "native_inputs_hit", "native_invalidations", "extras_scanned",
  "ids_unchanged", "ids_changed", "ids_bytes", "ids_waits", "all_ready_bundles", "pending_bundles"};
struct Counter { std::uint64_t segments = 0, exclusive_ns = 0, inclusive_ns = 0; };
struct EventCounter { std::uint64_t calls = 0, sum = 0, maximum = 0; };
struct Statistics {
  std::array<std::uint64_t, static_cast<std::size_t>(Context::Count)> roots{};
  std::array<std::array<Counter, static_cast<std::size_t>(Bucket::Count)>, static_cast<std::size_t>(Context::Count)> counters{};
  std::array<std::array<EventCounter, static_cast<std::size_t>(Event::Count)>, static_cast<std::size_t>(Context::Count)> events{};
};
inline Statistics statistics{};
struct Frame;
inline thread_local Frame *active = nullptr;
struct Frame {
  Frame *parent;
  Context context;
  Bucket bucket;
  Clock::time_point begin;
  std::uint64_t children = 0;
  Frame(Context c, Bucket b, bool root = false) noexcept
      : parent(active), context(c), bucket(b), begin(Clock::now()) {
    active = this;
    if (root) ++statistics.roots[static_cast<std::size_t>(c)];
  }
  Frame(const Frame &) = delete;
  Frame &operator=(const Frame &) = delete;
  ~Frame() { finish(); active = parent; }
  void finish() noexcept {
    const auto elapsed = static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - begin).count());
    auto &counter = statistics.counters[static_cast<std::size_t>(context)][static_cast<std::size_t>(bucket)];
    ++counter.segments; counter.inclusive_ns += elapsed;
    counter.exclusive_ns += elapsed >= children ? elapsed - children : 0;
    if (parent) parent->children += elapsed;
  }
  void stage(Bucket next) noexcept {
    finish(); bucket = next; children = 0; begin = Clock::now();
  }
};
inline Context context() noexcept { return active ? active->context : Context::Other; }
inline void event(Event which, std::uint64_t value = 1) noexcept {
  auto &counter = statistics.events[static_cast<std::size_t>(context())][static_cast<std::size_t>(which)];
  ++counter.calls; counter.sum += value;
  if (value > counter.maximum) counter.maximum = value;
}
inline void print() noexcept {
  std::fputs("BIND_DIAG {\"schema\":1,\"clock\":\"steady_wall_ns\",\"sum_exclusive_only\":true,\"single_serial_control_thread\":true,\"contexts\":{", stderr);
  for (std::size_t c = 0; c < static_cast<std::size_t>(Context::Count); ++c) {
    if (c) std::fputc(',', stderr);
    std::fprintf(stderr, "\"%s\":{\"root_calls\":%llu,\"buckets\":{", context_names[c],
        static_cast<unsigned long long>(statistics.roots[c]));
    bool comma = false;
    for (std::size_t b = 0; b < static_cast<std::size_t>(Bucket::Count); ++b) {
      const auto &v = statistics.counters[c][b]; if (!v.segments) continue;
      if (comma) std::fputc(',', stderr); comma = true;
      std::fprintf(stderr, "\"%s\":{\"segments\":%llu,\"exclusive_ns\":%llu,\"inclusive_ns\":%llu}", bucket_names[b],
          static_cast<unsigned long long>(v.segments), static_cast<unsigned long long>(v.exclusive_ns),
          static_cast<unsigned long long>(v.inclusive_ns));
    }
    std::fputs("},\"events\":{", stderr); comma = false;
    for (std::size_t e = 0; e < static_cast<std::size_t>(Event::Count); ++e) {
      const auto &v = statistics.events[c][e]; if (!v.calls) continue;
      if (comma) std::fputc(',', stderr); comma = true;
      std::fprintf(stderr, "\"%s\":{\"calls\":%llu,\"sum\":%llu,\"max\":%llu}", event_names[e],
          static_cast<unsigned long long>(v.calls), static_cast<unsigned long long>(v.sum), static_cast<unsigned long long>(v.maximum));
    }
    std::fputs("}}", stderr);
  }
  std::fputs("},\"boundary\":\"Inclusive parent/child values overlap. Sum only exclusive_ns; upload waits are wall waits, not CPU time. No per-event I/O.\"}\n", stderr);
}
} // namespace bind_diag
