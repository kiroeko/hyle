from pathlib import Path
import hashlib, importlib.util, json, subprocess, zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('bind_attribution_package_build',W/'build2.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
m=b.m

def main():
    result_path=W/'package-result.json';assert not result_path.exists(),'No repeat archive'
    summary=m.read(W/'run-summary.json');assert summary['status']=='PASS' and summary['successful_processes']==2
    ready=m.read(W/'ready.json');b.exact(ready['image'])
    plan=m.read(W/'source-freeze2.json');analysis=m.read(W/'attribution-summary.json')
    product=W/'source/product';product.mkdir(exist_ok=True)
    base_snapshots=[]
    for unit in plan['units']:
        target=product/Path(unit['original']['path']).name
        relative=Path(unit['original']['path']).resolve().relative_to(R).as_posix()
        raw=subprocess.check_output(['git','show','2fe2916cf:'+relative],cwd=R)
        assert len(raw)==unit['original']['bytes'] and hashlib.sha256(raw).hexdigest()==unit['original']['sha256']
        target.write_bytes(raw)
        base_snapshots.append(dict(commit='2fe2916cf',historical_original=unit['original'],snapshot=m.pin(target)))
    reference=W/'reference';reference.mkdir(exist_ok=True)
    runs=m.read(W/'run-plan.json')['runs'];refs=[]
    for row in runs:
        b.exact(row['reference_report']);target=reference/(row['mode']+'-original-report.json')
        target.write_bytes(Path(row['reference_report']['path']).read_bytes());refs.append(dict(mode=row['mode'],original=row['reference_report'],snapshot=m.pin(target)))
    facts=R/'.scratch/inference-identical-capture-inputs-20261027/screen.py'
    (reference/'original-screen-facts.py').write_bytes(facts.read_bytes())
    m.save(reference/'identity.json',dict(reports=refs,facts_original=m.pin(facts),facts_snapshot=m.pin(reference/'original-screen-facts.py')))
    attempts=[]
    for name in ['resources','resources2','slots']:
        process=m.read(W/'logs'/name/'process.json')
        unit=(m.read(W/'source-freeze.json') if name=='resources' else plan)['units'][0 if name.startswith('resources') else 1]
        attempts.append(dict(name=name,source=unit['source'],process=process,command=m.pin(W/'logs'/name/'command.json'),
            classification='diagnostic_instrumentation_compile_failure' if name=='resources' else 'CXX_PASS',
            compiled=m.pin(W/'compile'/name/'compiled.json') if (W/'compile'/name/'compiled.json').exists() else None))
    publications=[]
    for path in [R/'docs/evidence/performance/inference-identical-capture-inputs-2026-10-27.json',
                 R/'docs/evidence/correctness/inference-generic-output-source-2026-10-27.json']:
        publications.append(m.pin(path))
    allowed={'.py','.json','.log','.cc','.h','.patch','.txt','.xml'}
    excluded_names={'archive-manifest.json','package-result.json'}
    files=sorted(p for p in W.rglob('*') if p.is_file() and p.suffix.lower() in allowed
                 and p.name not in excluded_names and '__pycache__' not in p.parts)
    manifest=[dict(archive=str(p.relative_to(W)).replace('\\','/'),**m.pin(p)) for p in files]
    m.save(W/'archive-manifest.json',dict(files=manifest,boundary='Only local sources/scripts/recipes/dependency metadata/logs/reports. No binary, object, SDK or model payload.'))
    evidence=R/'docs/evidence/performance';evidence.mkdir(parents=True,exist_ok=True)
    archive=evidence/'inference-source-bind-attribution-2026-10-27.zip';receipt=evidence/'inference-source-bind-attribution-2026-10-27.json'
    assert not archive.exists() and not receipt.exists()
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for row in manifest:z.write(row['path'],row['archive'])
        z.write(W/'archive-manifest.json','archive-manifest.json')
    with zipfile.ZipFile(archive) as z:
        expected={row['archive']:row for row in manifest}
        assert set(z.namelist())==set(expected)|{'archive-manifest.json'}
        for name,row in expected.items():
            data=z.read(name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],name
        assert z.read('archive-manifest.json')==(W/'archive-manifest.json').read_bytes()
    payload=dict(
        schema=1,status='DIAGNOSTIC_COMPLETE',date='2026-10-27',scope='One ordinary CUDA R1 P154 +96 decode process per off/auto mode; host-call attribution only.',
        counts=dict(CXX_attempts=3,distinct_host_TUs=2,successful_CXX=2,diagnostic_CXX_failures=1,postcompile_metadata_corrections=1,archive_preparation_corrections=1,links=1,images=1,model_processes=2,SDK=0,NVCC=0,downloads=0,peer_runs=0,MTP_runs=0,performance_statistical_samples=0),
        base=dict(public_references=publications,baseline_inputs=plan['baseline_inputs'],baseline_ready=plan['baseline_ready'],
             product_resources=plan['units'][0]['original'],product_slots=plan['units'][1]['original'],historical_product_snapshots=base_snapshots,
             retained_Model_and_Graph=plan['retained'],comment_only_header_exception=plan['header_reuse']),
        image=ready['image'],actual_link_inputs=ready['inputs'],compiler_attempts=attempts,link=ready['link'],
        outcomes=summary['runs'],facts='97 generated IDs and all per-mode non-time result facts equal W7 reference under its unchanged facts predicate; decode96, final versions0, auto44 publications/no refusals/discards.',
        instrumentation=dict(header=plan['diag_header'],source_freeze=m.pin(W/'source-freeze2.json'),original_freeze=m.pin(W/'source-freeze.json'),
             counters='Fixed aggregate counters. Nested wall intervals are subtracted from parents; only exclusive_ns may be summed. One final stderr JSON per process. Original Model clocks, math, ownership and permission paths unchanged.'),
        failures=dict(first='Frame insertion mistook ValueId{} default argument for function body; scratch source/patch/command/compiler output/process preserved. No product source compilation failure.',
             retry='resources2 compiler exit0; postcompile path assertion expected source1 header instead of its byte-identical pre-pinned source2 copy. Finalized original successful OBJ from actual Includes without recompiling.',
             archive_preparation='First attempt rejected changed canonical source before ZIP creation. Read exact committed 2fe2916cf source bytes instead and verified frozen hashes; no model rerun.',
             paths=['failure-package-attempt1.log','logs/resources','source/resources.cc','instrument.py','failure-resources2-metadata.log','compile/resources2/compiled.json']),
        observations=analysis['interpretation'],full_exclusive_analysis=m.pin(W/'attribution-summary.json'),
        limits=['No exact first8/remaining88 or A/B episode labels without Model markers. The old Model3 26ms is not subtracted.',
             'Off ordinary prepare_replay is not wrapped by prepare_outputs; auto replay buckets are absolute observations, not added cost.',
             'Other context includes cold setup and Source export/publication and cannot be silently charged to binding.',
             'Wait durations are elapsed blocking walls, not CPU usage. Diagnostic instrumentation perturbs the measured work.',
             'No new formal TPS, net speed/statistical, peer, MTP, total VRAM peak, native-fault or model-quality conclusion.'],
        archive=m.pin(archive),archive_manifest=m.pin(W/'archive-manifest.json'),archive_readback='Every archived file size/SHA256 verified; no EXE/OBJ/PDB/LIB/DLL/SDK/model files.')
    lines=['{']
    for index,(key,value) in enumerate(payload.items()):
        lines.append('  '+json.dumps(key)+': '+json.dumps(value,ensure_ascii=False,separators=(',',':'))+(',' if index+1<len(payload) else ''))
    lines.append('}')
    receipt.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
    readback=m.read(receipt);assert readback['archive']==m.pin(archive) and readback['counts']['model_processes']==2
    result=dict(status='PACKAGED_READBACK_VERIFIED',receipt=m.pin(receipt),archive=m.pin(archive),files=len(manifest)+1,
       boundary='One archive creation/readback. No model, compiler or GPU invocation by package.py.')
    m.save(result_path,result);print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
