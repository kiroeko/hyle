from pathlib import Path
import importlib.util, json, os, re, subprocess, sys, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-identical-capture-inputs-20261027'

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
previous=module('bind_attribution_previous',B/'build.py')
m,h,exact=previous.m,previous.h,previous.exact
m.W=W
instrument=module('bind_attribution_instrument',W/'instrument.py')
HEADER=R/'include/hyle/graph/detail/output_source.h'


def environment():
    env=dict(os.environ);env.update(m.read(B/'environment.json'))
    env['PATH']=str(W/'bin')+';'+m.read(B/'runtime.json')['PATH']
    for name in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env[name]='1'
    return env


def tokens(raw):
    text=raw.decode('utf-8-sig')
    # Keep literals whole; discard comments and whitespace, preserving every
    # identifier/punctuator token. The specific header has no raw literals.
    expression=r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|[A-Za-z_]\w*|(?:\d[\w.]*)|::|->|\.\.\.|&&|\|\||==|!=|<=|>=|<<|>>|\S'
    return [x for x in re.findall(expression,text) if not x.startswith(('//','/*'))]


def header_exception():
    before=subprocess.check_output(['git','show','5582ed347:include/hyle/graph/detail/output_source.h'],cwd=R)
    after=HEADER.read_bytes();assert tokens(before)==tokens(after),'Header token/ABI change cannot use comment-only exception'
    root=W/'source/reuse';root.mkdir(parents=True,exist_ok=True)
    (root/'output_source-5582.h').write_bytes(before);(root/'output_source-current.h').write_bytes(after)
    result=dict(path=str(HEADER),old=m.pin(root/'output_source-5582.h'),new=m.pin(root/'output_source-current.h'),
        current=m.pin(HEADER),token_count=len(tokens(before)),tokens_equal=True,
        boundary='Only this header comment change is exempted from old actual-Include byte equality. No code/ABI token changes are permitted; newly compiled actual Includes pin the current bytes.')
    m.save(W/'header-reuse-exception.json',result);return result


def compatible(row,exception):
    if m.pin(row['path'])==row:return
    assert m.key(row['path'])==m.key(exception['path']),('Retained dependency changed',row['path'])
    assert row['sha256']==exception['old']['sha256'] and row['bytes']==exception['old']['bytes'],('Unknown previous header bytes',row)
    assert m.pin(row['path'])==exception['current'] and exception['tokens_equal']


def recipe(record):
    obj=Path(record['object']['path'])
    choices=[obj.parent/'command.json',obj.parent.parent.parent/'logs'/obj.parent.name/'command.json']
    return next(p for p in choices if p.exists())


def compile_command(template,source,original,out):
    argv=[]
    for i,arg in enumerate(template):
        if i and template[i-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(source)
        argv.append(arg)
    argv[1:1]=['/I'+str(source.parent),'/I'+str(original.parent)]
    assert m.build_contract(argv)==m.build_contract(template)
    for prefix in ['/Fo','/Fd']:
        values=[x[len(prefix):] for x in argv if x.lower().startswith(prefix.lower())]
        assert len(values)==1 and Path(values[0]).is_relative_to(W)
    return argv


def freeze(expected_resources):
    assert not (W/'source-freeze.json').exists()
    resources=m.pin(R/'src/graph/resources.cc')
    assert resources['sha256']==expected_resources,'Wait for exact SOURCE_FROZEN bytes'
    exception=header_exception()
    rows=m.read(B/'cli-link-inputs.json');assert len(rows)==224
    for row in rows:exact(row)
    index=m.index(rows);units=[];pre={}
    for name,relative in [('resources','src/graph/resources.cc'),('slots','src/graph/slots_region.cc')]:
        original=R/relative;record=index[m.key(original)];command_recipe=recipe(record)
        snapshot=W/'source'/(original.name)
        transformed=instrument.transform(name,original,snapshot)
        for path in [*record['data']['Includes'],str(original),str(snapshot),str(W/'source/bind_diag.h')]:
            pre[m.key(path)]=m.pin(path)
        units.append(dict(name=name,original=m.pin(original),source=m.pin(snapshot),patch=m.pin(transformed['patch']),
            baseline=record,recipe=m.pin(command_recipe),command=compile_command(m.read(command_recipe)['command'],snapshot,original,W/'compile'/name),
            object=str(W/'compile'/name/'unit.obj')))
    retained=[]
    retained_specs=[('graph',B/'compile/executable/compiled.json'),
        ('model',R/'.scratch/inference-generation-batch-continuation-20261027/compile/model1/compiled.json')]
    for name,path in retained_specs:
        data=m.read(path);exceptions=[]
        for row in m.read(data['actual_dependencies']['path']):
            compatible(row,exception)
            if m.pin(row['path'])!=row:exceptions.append(row)
        exact(data['object']);retained.append(dict(name=name,compiled=m.pin(path),object=data['object'],comment_only_exceptions=exceptions))
    consumers=[dict(source=d['data']['Source'],object=d['object'],compiler_dependencies=d['dependencies']) for d in index.values()
               if any(m.key(p)==m.key(HEADER) for p in d['data']['Includes'])]
    m.save(W/'precompile-dependencies.json',list(pre.values()))
    m.save(W/'environment.json',{k:environment().get(k,'') for k in ['PATH','INCLUDE','LIB','LIBPATH']})
    m.save(W/'runtime.json',dict(original=m.pin(B/'runtime.json'),original_runtime=m.read(B/'runtime.json'),PATH=environment()['PATH']))
    (W/'bin').mkdir(exist_ok=True)
    plan=dict(status='FROZEN_NOT_BUILT',baseline_ready=m.pin(B/'ready-cli.json'),baseline_inputs=m.pin(B/'cli-link-inputs.json'),
        units=units,retained=retained,header_reuse=m.pin(W/'header-reuse-exception.json'),header_consumers=consumers,
        dependencies=m.pin(W/'precompile-dependencies.json'),runtime=m.pin(W/'runtime.json'),instrument=m.pin(W/'instrument.py'),
        diag_header=m.pin(W/'source/bind_diag.h'),counts=dict(CXX=2,links=1,inputs=224,planned_processes=2,SDK=0,NVCC=0,downloads=0),
        boundary='Scratch-only exclusive context attribution. Current generic resources implementation plus instrumentation; slots implementation unchanged except counters. Graph/Model/weights/native objects retained. No original Model clock endpoint is edited. Old 26ms is motivation, not a value subtracted from this candidate.')
    m.save(W/'source-freeze.json',plan);m.save(W/'build-plan.json',plan)
    print('FROZEN 2 host CXX / 1 link; no build/run',flush=True)


def compile_unit(name):
    plan=m.read(W/'source-freeze.json');unit=next(x for x in plan['units'] if x['name']==name)
    for key in ['original','source','patch','recipe']:exact(unit[key])
    exact(plan['diag_header']);exact(plan['instrument'])
    before={m.key(x['path']):x for x in m.read(plan['dependencies']['path'])}
    for row in before.values():exact(row)
    out=Path(unit['object']).parent;out.mkdir(parents=True,exist_ok=False)
    process=h.execute(unit['command'],environment(),W/'logs'/name,timeout=240)
    data=m.read(out/'dependencies.json')['Data'];assert m.key(data['Source'])==m.key(unit['source']['path'])
    deps=[m.pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    assert m.key(plan['diag_header']['path']) in {m.key(x['path']) for x in deps}
    for row in deps:
        old=before.get(m.key(row['path']))
        if old:assert row==old,('Dependency changed during CXX',row['path'])
        else:assert not Path(row['path']).resolve().is_relative_to(R),('Unfrozen local Include',row['path'])
    for key in ['original','source']:exact(unit[key])
    m.save(out/'actual-dependencies.json',deps)
    result=dict(name=name,original_source=unit['original'],source=unit['source'],object=m.pin(unit['object']),process=process,
        command=m.pin(W/'logs'/name/'command.json'),compiler_dependencies=m.pin(out/'dependencies.json'),actual_dependencies=m.pin(out/'actual-dependencies.json'))
    m.save(out/'compiled.json',result);print('COMPILED '+name,flush=True)


def link():
    plan=m.read(W/'source-freeze.json');rows=m.read(plan['baseline_inputs']['path'])
    compiled={u['name']:m.read(W/'compile'/u['name']/'compiled.json') for u in plan['units']}
    replacements={m.key(u['baseline']['object']['path']):compiled[u['name']]['object'] for u in plan['units']}
    inputs=[replacements.get(m.key(row['path']),row) for row in rows];assert len(inputs)==224
    for row in inputs:exact(row)
    for unit in compiled.values():
        for key in ['original_source','source','object']:exact(unit[key])
        for row in m.read(unit['actual_dependencies']['path']):exact(row)
    for keep in plan['retained']:
        data=m.read(keep['compiled']['path']);exact(data['object'])
        for row in m.read(data['actual_dependencies']['path']):compatible(row,m.read(plan['header_reuse']['path']))
    image=W/'bin/hyle-bind-diag.exe'
    argv=m.link_command(m.read(B/'link-cli/command.json')['command'],{k:v['path'] for k,v in replacements.items()},[],image)
    m.save(W/'link-inputs.json',inputs)
    process=h.execute(argv,environment(),W/'link',timeout=180)
    result=dict(image=m.pin(image),link=process,inputs=m.pin(W/'link-inputs.json'),runtime=m.pin(W/'runtime.json'),
        freeze=m.pin(W/'source-freeze.json'),recipe=m.pin(W/'link/command.json'))
    m.save(W/'ready.json',result);print('DIAG_READY '+result['image']['sha256'],flush=True)

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='freeze':freeze(sys.argv[2])
        elif action=='compile':compile_unit(sys.argv[2])
        elif action=='link':link()
        else:raise ValueError(action)
    except BaseException:
        (W/('failure-'+'-'.join(sys.argv[1:2])+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
