"""One changed consumer, original227 SDK inputs, finite warm-policy screen."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('runner',R/'.scratch/inference-program-identity-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
OLD=R/'.scratch/inference-mtp-auto-capture-20261030'

def prepare():
    p=read(OLD/'delivery-plan.json')
    for item in [*p['retained'],p['runtime']]:exact(item)
    baseline=read(OLD/'product-compile/candidate/receipt.json')['object'];exact(baseline)
    source=W/'cli.cc';source.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    folder=W/'compile';folder.mkdir(exist_ok=True)
    recipe=p['units']['candidate']['compile'];args=[]
    for i,arg in enumerate(recipe):
        if i and recipe[i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
        elif arg.lower().endswith('.cc'):arg=str(source)
        args.append(arg)
    assert sum(key(x)==key(source) for x in args)==1
    (W/'bin').mkdir(exist_ok=True);shutil.copyfile(p['runtime']['path'],W/'bin'/Path(p['runtime']['path']).name)
    two=read(R/'.scratch/inference-paired-m2-20261030/model-plan.json')['speed']['two-turn-mtp']['args']
    two[two.index('--decode-overlap')+1]='auto'
    save(W/'plan.json',dict(base=pin(OLD/'delivery-plan.json'),retained=p['retained'],runtime=p['runtime'],
        original_link=p['link'],original_consumer=p['original_consumer'],baseline=baseline,
        compile=args,args=p['args'],two_turn_args=two,base_commit='3938f555f',source=pin(source),
        scope='Only same-cohort successful-discard warm hints retained; source/permissions/defaults unchanged. No SDK compilation or download.'))
    print('Prepared one CXX consumer and unchanged227 SDK inputs.')

def compile_unit(attempt):
    p=read(W/'plan.json');folder=W/'compile';b.execute(p['compile'],folder/attempt,600)
    d=read(folder/'dependencies.json')['Data']
    files=sorted({Path(x).resolve() for x in [d['Source'],*d['Includes']] if Path(x).is_relative_to(R)})
    save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),source_identities=[pin(x) for x in files],
        dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json')))

def link(name,attempt):
    p=read(W/'plan.json')
    for item in p['retained']:exact(item)
    obj=p['baseline'] if name=='control' else read(W/'compile/receipt.json')['object'];exact(obj)
    args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']):arg=obj['path']
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    assert sum(key(x)==key(obj['path']) for x in args)==1
    b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))

def run(name,attempt,scenario='single'):
    p=read(W/'plan.json');image=read(W/('ready-'+name+'.json'));exact(image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    args=p['two_turn_args'] if scenario=='two-turn' else p['args']
    folder=W/'runs'/name/attempt;b.execute([image['path'],*args],folder,600)
    report=read(folder/'stdout.log');assert report['generated_tokens']==(128 if scenario=='two-turn' else 64)
    assert report['draft_rounds']==(66 if scenario=='two-turn' else 34)
    save(folder/'report.json',report);print('PASS finite',report['generated_tokens'],'outputs',name)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':compile_unit(sys.argv[2])
    else:{'link':link,'run':run}[action](sys.argv[2],sys.argv[3])
