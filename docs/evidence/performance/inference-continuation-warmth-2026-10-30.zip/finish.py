"""Compact delivery index; raw finite/screen diagnostics stay in the archive."""
from pathlib import Path
import importlib.util
import statistics
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact

analysis=read(W/'delivery-analysis.json');finite=read(W/'finite-analysis.json')
assert analysis['frozen'] and analysis['all_processes_exit_zero']
assert analysis['strict_semantic_comparison']['all_other_non_time_fields_equal']
samples=[]
for name,attempt in [('control','abba-1'),('candidate','abba-2'),('candidate','abba-3'),('control','abba-4')]:
    folder=W/'runs'/name/attempt;r=read(folder/'report.json');p=read(folder/'process.json')
    assert p['exit']==0
    samples.append(dict(arm=name,attempt=attempt,process=p,report=pin(folder/'report.json'),
        command=pin(folder/'command.json'),stderr=pin(folder/'stderr.log'),
        prefill_TPS=r['prefill_tokens_per_second'],decode_TPS=r['decode_output_tokens_per_second'],
        combined_TPS=r['output_tokens_per_second'],decode_seconds=r['decode_seconds'],
        work={k:r[k] for k in ['generated_tokens','draft_rounds','actual_graph_calls','actual_target_rows',
            'actual_draft_rows','overlap_successor_submissions','overlap_successor_publications',
            'overlap_successor_discards','overlap_successor_refusals']},
        capture_recordings=sum('capture_recorded=1' in line for line in
            (folder/'stderr.log').read_text(encoding='utf-8').splitlines() if line.startswith('prepared '))))
metrics={name:{k:statistics.median(row[k] for row in samples if row['arm']==name)
    for k in ['prefill_TPS','decode_TPS','combined_TPS','decode_seconds']} for name in ['control','candidate']}
checks=[]
for name in ['natural','ordinary']:
    folder=W/'finite-runs'/name/'attempt1';r=read(folder/'report.json');assert r['status']=='PASS'
    facts=({k:r[k] for k in ['outputs','ledger_records','serial_submissions','auto_submissions',
        'successor_submissions','successor_publications','successor_discards','successor_refusals',
        'original_ledger_equal','generated_ids_equal','greedy_rng_unchanged','all_sources_expired','final_versions']}
        if name=='natural' else {k:r[k] for k in ['control_and_candidate_arms',
            'complete_prefix_state_epoch_rng_equal','actual_owner_credit_checked','all_source_session_page_owners_retired']})
    if name=='natural':facts['complete_state_payloads_byte_equal']=all(x['payloads_byte_equal'] for x in r['state_checks'])
    checks.append(dict(case=name,status=r['status'],facts=facts,report=pin(folder/'report.json'),process=pin(folder/'process.json')))
diff=subprocess.check_output(['git','diff','--','engine/models/qwen35/main.cc'],cwd=R)
(W/'product.diff').write_bytes(diff)
for name,receipt in [('cli',W/'compile/receipt.json'),('natural',W/'finite-compile/natural/receipt.json'),
        ('ordinary',W/'finite-compile/ordinary/receipt.json')]:
    unit=read(receipt);exact(unit['object'])
    for identity in unit['source_identities']:exact(identity)
for item in read(W/'plan.json')['retained']:exact(item)
value=dict(schema='hyle.performance.continuation-warmth.v1',date='2026-10-30',
    status='IMPLEMENTED_FINITE_CHECKS_AND_LIMITED_SCREEN',base_commit='3938f555f',
    implementation=dict(product_source=pin(R/'engine/models/qwen35/main.cc'),diff=pin(W/'product.diff'),
        code_change='On normal successful speculative discard, release old Source/ready-slot while preserving same-cohort warm hints. Reset hints before destructive fallback; existing failure, cohort/turn and permission checks remain.',
        unchanged_sdk_inputs=227,sdk_compiles=0,consumer_CXX_compiles=3,downloads=0,
        cli_receipt=pin(W/'compile/receipt.json')),
    screen=dict(order=['control','candidate','candidate','control'],samples_per_arm=2,
        samples=samples,medians=metrics,median_decode_change_percent=analysis['median_decode_TPS_change_percent'],
        semantic_comparison={k:analysis['strict_semantic_comparison'][k] for k in [
            'method','allowed_and_only_differing_paths','all_other_non_time_fields_equal','generated_ids','round_records']},
        original_full_analysis=pin(W/'delivery-analysis.json')),
    finite_checks=checks,two_turn_supplement=dict(
        scope='One process per version,128outputs; not a timing window or net-gain estimate.',
        control=pin(W/'runs/control/two-turn-once/report.json'),candidate=pin(W/'runs/candidate/two-turn-once/report.json'),
        offline_analysis=pin(W/'finite-analysis.json')),
    research=dict(warm_gate=pin(W/'analysis-initial.json'),draft_vocabulary=pin(W/'draft-vocab-research.json'),
        source_boundary=pin(W/'source-boundary-audit.json')),
    architecture='K1/recursive already share accepted-prefix, stop/quota and original state/publication/retirement mechanisms. Keep real fused/recursive math and RNG differences; complete cross-model stage assembly and broader device-successor coverage remain unfinished.',
    cleanup=dict(script=pin(R/'test.ps1'),manifest=pin(W/'cleanup-targets.json'),result=read(W/'cleanup-report.json')),
    limits=['Only a two-sample-per-arm screen; no stable hardware-wide performance claim.',
        'No new peer, independent memory, profiler or cross-platform processes; do not pool with earlier windows or recompute peer gap.',
        'Preserved warm hints authorize no Source/tuple/lease reuse. The actual next preparation still checks all original permissions.',
        'No change to cross-turn reset, warm threshold, numerical route, graph topology, output quota, cache capacity or public options.',
        'Discarded speculative work, initial captures, cross-turn warmth and the broader architecture/GPU scope remain open.',
        'Small draft vocabulary requires an independent model-tokenizer map and cold format-aware row import; no such current artifact was found and no download was started.'],
    evidence_archive='inference-continuation-warmth-2026-10-30.zip')
out=R/'docs/evidence/performance/inference-continuation-warmth-2026-10-30.json';save(out,value)
files=[]
for path in W.rglob('*'):
    if not path.is_file() or any(x in ('bin','tmp','__pycache__','ordinary-input') for x in path.relative_to(W).parts):continue
    if path.suffix in ('.json','.py','.diff','.log','.cc'):files.append(path)
with zipfile.ZipFile(out.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(files):z.write(path,path.relative_to(W).as_posix())
    z.write(R/'test.ps1','cleanup-script.ps1');z.write(out,'delivery.json')
print('Saved compact delivery',out.stat().st_size,'bytes; archive',out.with_suffix('.zip').stat().st_size,'bytes')
print('decode',metrics['control']['decode_TPS'],'->',metrics['candidate']['decode_TPS'],
    'percent',analysis['median_decode_TPS_change_percent'])
