"""Two existing finite consumers for actual state and common controls."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def prepare():
    plan=read(W/'plan.json'); prior=read(R/'.scratch/inference-source-preparation-20261030/plan.json')
    previous=read(R/'.scratch/inference-mtp-auto-capture-20261030/delivery-plan.json')
    units={}
    for name,unit in [('natural',prior['units']['model']),('ordinary',previous['units']['ordinary'])]:
        folder=W/'finite-compile'/name;folder.mkdir(parents=True,exist_ok=True);recipe=unit['compile'];args=[]
        for i,arg in enumerate(recipe):
            if i and recipe[i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            args.append(arg)
        units[name]=dict(source=unit['source'],compile=args)
    fixture=W/'ordinary-input';fixture.mkdir(exist_ok=True)
    for name in ('weights.tsv','prompt.ids'):
        shutil.copyfile(Path(previous['ordinary_args'][-1])/name,fixture/name)
    save(W/'finite-plan.json',dict(units=units,cases={
        'natural':prior['cases']['natural-cuda']['args'],
        'ordinary':[*previous['ordinary_args'][:-1],str(fixture)]},
        retained=plan['retained'],original_consumer=plan['original_consumer'],link=plan['original_link']))
    print('Prepared two existing finite consumers; no SDK or fixture payload copy.')

def compile_unit(name,attempt):
    p=read(W/'finite-plan.json');folder=W/'finite-compile'/name;b.b.execute(p['units'][name]['compile'],folder/attempt,600)
    d=read(folder/'dependencies.json')['Data']
    files=sorted({Path(x).resolve() for x in [d['Source'],*d['Includes']] if Path(x).is_relative_to(R)})
    save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),source_identities=[pin(x) for x in files],
        dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json')))

def link(name,attempt):
    p=read(W/'finite-plan.json');obj=read(W/'finite-compile'/name/'receipt.json')['object'];exact(obj)
    for x in p['retained']:exact(x)
    args=[]
    for arg in p['link']:
        if key(arg)==key(p['original_consumer']):arg=obj['path']
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    b.b.execute(args,W/'finite-link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))

def run(name,attempt):
    p=read(W/'finite-plan.json');image=read(W/('ready-'+name+'.json'));exact(image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    folder=W/'finite-runs'/name/attempt;b.b.execute([image['path'],*p['cases'][name]],folder,600)
    r=read(folder/'stdout.log');assert r['status']=='PASS';save(folder/'report.json',r)
    print('PASS existing finite',name)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:{'compile':compile_unit,'link':link,'run':run}[sys.argv[1]](sys.argv[2],sys.argv[3])
