"""Current cold selected-row consumer using retained same-layout SDK objects."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('source_build',R/'.scratch/inference-source-binding-20261030/build.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.W=s.b.W=W
read,save,pin,exact,key=s.read,s.save,s.pin,s.exact,s.key
BASE=R/'.scratch/inference-cross-turn-warmth-20261030/model-link-base.json'

def prepare():
    assert not (W/'plan.json').exists()
    base=read(BASE);sdk=read(base['sdk_engine_dependencies']['path'])
    changed={key(R/x) for x in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
    rows={key(x['object']):x for x in sdk['inspected']}
    rows.update({key(x['object']):x for x in sdk['engine_consumers'] if 'dependencies' in x})
    units={};actual=[];unavailable=[]
    for item in base['retained']:
        exact(item);obj=Path(item['path']);row=rows.get(key(item['path']))
        for adjacent in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
            if adjacent.is_file() and 'Data' in read(adjacent):row=dict(object=item['path'],dependencies=pin(adjacent));break
        if row is None:unavailable.append(item['path']);continue
        actual.append(row);d=read(row['dependencies']['path'])['Data']
        if not any(key(x) in changed for x in [d['Source'],*d['Includes']]):continue
        args,recipe=s.command_for(item['path'],d['Source'])
        name='sdk-'+Path(d['Source']).relative_to(R).as_posix().replace('/','__').replace('.','_')
        units[name]=dict(source=d['Source'],original=item,recipe=recipe,compile=s.relocated(args,name))
    assert any(Path(x['source'])==R/'engine/models/qwen35/weights.cc' for x in units.values())
    assert all(Path(x['source']).suffix=='.cc' for x in units.values())
    source=W/'cli.cc';source.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    consumers={}
    for name,path in [('cli',source),('rows',R/'tests/tools/qwen_draft_vocabulary_probe.cc'),('ids',R/'tests/tools/inference_draft_vocabulary_test.cc')]:
        consumers[name]=dict(source=str(path),compile=s.relocated(base['compile'],name,path))
    old=read(base['current_consumers']['cli']['receipt']['path'])
    old_args=read(R/'.scratch/inference-continuation-warmth-20261030/plan.json')
    (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    save(W/'plan.json',dict(base=pin(BASE),base_commit='fbbccb98e',retained=base['retained'],runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'],actual_dependency_rows=actual,unavailable_dependencies=unavailable,
        units=units,consumers=consumers,baseline=old['object'],original_consumer=old['object']['path'],
        original_link=base['link'],args=old_args['args'],two_turn_args=old_args['two_turn_args'],
        SDK_CXX=len(units),NVCC=0,downloads=0,
        ABI='Control retains its complete old SDK and CLI. Candidate rebuilds every affected weights-header consumer; no old/new PreparedWeightSource layout mix.'))
    print('Prepared',len(units),'affected SDK CXX;',227-len(units),'retained;3 current consumers; no download/NVCC.')

def compile_units(attempt,names):
    p=read(W/'plan.json');names=list(p['units']) if names==['sdk'] else names
    errors=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs={pool.submit(s.compile_one,name,attempt):name for name in names}
        for job in as_completed(jobs):
            try:job.result()
            except BaseException as error:errors.append(dict(name=jobs[job],error=str(error)))
    save(W/('compile-'+attempt+'-'+names[0]+'.json'),dict(units=names,errors=errors,max_concurrency=2))
    assert not errors,errors

def link(name,attempt):
    p=read(W/'plan.json');control=name=='control'
    retained=p['retained'] if control else p['candidate_retained']
    obj=p['baseline'] if control else read(W/'compile'/name/'receipt.json')['object']
    for item in [obj,*retained]:exact(item)
    replacements={} if control else {key(a['path']):c['path'] for a,c in zip(p['retained'],retained)}
    args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']):arg=obj['path']
        arg=replacements.get(key(arg),arg)
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))

def inputs():
    p=read(W/'plan.json');original=Path(p['args'][p['args'].index('--inputs')+1])
    first=(original/'weights.tsv').read_text().splitlines();identity=first[1]
    prior=read(R/'.scratch/inference-draft-vocab-map-20261030/attempt1/map_32768.json')
    for name in ('subset','full'):
        folder=W/'inputs'/name;folder.mkdir(parents=True,exist_ok=True)
        for file in ('weights.tsv','prompt.ids'):shutil.copyfile(original/file,folder/file)
        if name=='subset':
            (folder/'draft-vocabulary.ids').write_text('hyle-draft-vocabulary-v1\n'+identity+'\n248320\n'+' '.join(map(str,prior['token_ids']))+'\n')
    save(W/'input-identities.json',{name:{file:pin(W/'inputs'/name/file) for file in ('weights.tsv','prompt.ids')+ (('draft-vocabulary.ids',) if name=='subset' else ())} for name in ('subset','full')})

def run(name,attempt,scenario='single',selected='full'):
    p=read(W/'plan.json');image=read(W/('ready-'+name+'.json'));exact(image)
    args=[]
    if name=='rows':args=[scenario]
    elif name!='ids':
        args=list(p['two_turn_args'] if 'two' in scenario else p['args'])
        args[args.index('--inputs')+1]=str(W/'inputs'/selected)
        if 'k2' in scenario:args[args.index('--mtp-max-drafts')+1]='2'
        if 'threshold' in scenario:args.extend(['--mtp-min-probability','0.5'])
        if 'random' in scenario:
            args[args.index('--sampling')+1]='random';args.extend(['--temperature','0.8','--top-k','16','--top-p','0.9','--seed','73'])
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    folder=W/'runs'/scenario/selected/name/attempt;save(folder/'image.json',image)
    s.b.execute([image['path'],*args],folder,300)
    result=read(folder/'stdout.log')
    if name in ('control','cli'):
        assert result['generated_tokens']==(128 if 'two' in scenario else 64) and result['live_committed_versions']==0
    else:assert result['status']=='PASS'
    save(folder/'report.json',result);print('PASS',name,scenario,selected)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile':compile_units(sys.argv[2],sys.argv[3:])
    elif action=='seal':s.seal()
    elif action=='link':
        for name in sys.argv[3:]:link(name,sys.argv[2])
    elif action=='inputs':inputs()
    elif action=='run':run(sys.argv[2],sys.argv[3],sys.argv[4] if len(sys.argv)>4 else 'single',sys.argv[5] if len(sys.argv)>5 else 'full')
    else:raise ValueError(action)
