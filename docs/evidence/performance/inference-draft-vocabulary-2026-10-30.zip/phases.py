from pathlib import Path
import json,subprocess,sys
W=Path(__file__).resolve().parent
R=W.parents[1]
M=W/'measure.py'
def execute(args):
 print('EXPLICIT',*args,flush=True)
 subprocess.run([sys.executable,str(M),*map(str,args)],cwd=R,check=True)
def pair(scenario,attempt):
 for arm in ('full','subset'):execute(['run',arm,scenario,attempt])
 first=W/'measure-runs'/scenario/'full'/attempt/'report.json'
 second=W/'measure-runs'/scenario/'subset'/attempt/'report.json'
 execute(['compare',first,second,W/(scenario+'-'+attempt+'-compare.json'),'subset'])
action=sys.argv[1]
if action=='correctness':
 pair('two','correctness1')
 pair('k2','correctness1')
elif action=='trace':
 pair('state40','trace1')
 execute(['trace-compare',W/'measure-runs/state40/full/trace1/report.json',W/'measure-runs/state40/subset/trace1/report.json',W/'state40-trace-compare.json'])
elif action=='screen':
 for scenario in ('single','two'):
  for at,arm in enumerate(('full','subset','subset','full'),1):execute(['run',arm,scenario,'abba-'+str(at)])
else:raise ValueError(action)
