from pathlib import Path
import json,subprocess,hashlib,os,time
W=Path(__file__).resolve().parent
ready=json.loads((W/'ready-cli.json').read_text());image=Path(ready['path']);assert hashlib.sha256(image.read_bytes()).hexdigest()==ready['sha256']
root=W/'preflight-runs/attempt2';assert not root.exists()
cases={'mtp-off':['--mtp','off'],'zero-drafts':['--mtp','on','--mtp-max-drafts','0'],'random':['--mtp','on','--sampling','random'],'threshold':['--mtp','on','--mtp-min-probability','0.1']}
reports=[]
env=dict(os.environ)
env.update(json.loads((W.parents[1]/'.scratch/inference-natural-logits-control-20261029/environment.json').read_text(encoding='utf-8-sig')))
env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
for name,extra in cases.items():
 folder=root/name;folder.mkdir(parents=True)
 command=[str(image),'--inputs',str(W/'intentionally-missing-input'),'--mtp-draft-vocabulary',str(W/'intentionally-missing-map'),*extra]
 started=time.time();r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=30)
 (folder/'stdout.log').write_bytes(r.stdout);(folder/'stderr.log').write_bytes(r.stderr)
 stderr=r.stderr.decode('utf-8',errors='replace')
 assert r.returncode==1 and '--mtp-draft-vocabulary requires --mtp on' in stderr and 'CUDA' not in stderr,(name,r.returncode,stderr)
 report=dict(status='PASS_EXPECTED_REJECTION',command=command,exit=r.returncode,seconds=time.time()-started,before_input_or_map_open=True,no_backend_initializer_output=True,image=ready)
 (folder/'report.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());reports.append(dict(name=name,**report))
(root/'summary.json').write_bytes((json.dumps(dict(status='PASS',cases=reports),indent=2)+'\n').encode())
print('PASS4 incompatible explicit CLI requests rejected before nonexistent input/map or backend creation')
