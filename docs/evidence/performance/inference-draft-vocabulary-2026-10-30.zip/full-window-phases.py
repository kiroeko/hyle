"""Explicitly authorized32-process window; single GPU, no retries or tuning."""
from pathlib import Path
import datetime,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
def snapshot(group,when):
 command=['nvidia-smi','--query-gpu=name,uuid,driver_version,clocks.current.graphics,clocks.current.sm,clocks.current.memory,temperature.gpu,power.draw,power.limit,utilization.gpu,memory.used','--format=csv,noheader']
 result=subprocess.run(command,cwd=R,text=True,capture_output=True,check=False)
 folder=W/'peer-window/group-hardware';folder.mkdir(parents=True,exist_ok=True)
 path=folder/(group+'-'+when+'.json');assert not path.exists()
 path.write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,exit=result.returncode,stdout=result.stdout,stderr=result.stderr,read_only=True),indent=2)+'\n')
for scenario,mode in [('single','timing'),('single','memory'),('two-turn','timing'),('two-turn','memory')]:
 group=scenario+'-'+mode;snapshot(group,'before')
 subprocess.run([sys.executable,str(W/'window-current.py'),'run-one',scenario,mode],cwd=R,check=True)
 snapshot(group,'after')
subprocess.run([sys.executable,str(W/'window-current.py'),'summary'],cwd=R,check=True)
