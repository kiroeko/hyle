"""Seal source/build/correctness/performance evidence; never builds/runs/cleans."""
from pathlib import Path
import copy, hashlib, json, subprocess, zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def pin(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def exact(item):
    assert pin(item['path']) == item, item['path']
def norm(path): return str(Path(path)).lower()
def terminal(process):
    assert process['state'] == 'TERMINAL' and not process.get('timed_out'), process

plan = read(W/'plan.json'); baseline = read(W/'baseline-plan.json')
base = read(plan['base']['path'])
receipts = {}; current_sources = {}
for name in [*plan['units'], *plan['consumers']]:
    path = W/'compile'/name/'receipt.json'; receipt = read(path)
    for item in [receipt['object'], receipt['dependencies'], receipt['process'], *receipt['source_identities']]: exact(item)
    process = read(receipt['process']['path']); terminal(process); assert process['exit'] == 0
    receipts[name] = dict(receipt=pin(path), object=receipt['object'])
    current_sources.update({norm(item['path']):item for item in receipt['source_identities']})
assert len(plan['candidate_retained']) == len(plan['retained']) == 227
for item in plan['candidate_retained']: exact(item)
changed_sdk = [(before,after) for before,after in zip(plan['retained'],plan['candidate_retained']) if before!=after]
assert len(changed_sdk) == len(plan['units']) == 1
assert changed_sdk[0][1] == receipts['sdk-engine__models__qwen35__weights_cc']['object']
exact(plan['candidate_sdk']); exact(plan['runtime'])

# Current means every exact source pin is still current, not merely that a
# historic object can link. Old weights.h/main.cc consumers retain old receipts
# only as historical artifacts; a new PreparedWeightSource never crosses ABI.
next_base = copy.deepcopy(base)
historical = copy.deepcopy(base.get('historical_consumers', {}))
current = {}; stale = {}
for name,row in base.get('current_consumers', {}).items():
    receipt = read(row['receipt']['path'])
    mismatches = [item for item in receipt['source_identities']
                  if not Path(item['path']).is_file() or pin(item['path']) != item]
    if mismatches or name in plan['consumers']:
        stale[name] = dict(**row, status='HISTORICAL_NOT_CURRENT',
            reason='Replaced by current consumer' if name in plan['consumers'] else 'Exact source pins differ from current source',
            mismatched_source_pins=mismatches)
    else:
        exact(row['object']); exact(row['receipt']); current[name] = row
historical['before-draft-vocabulary-'+baseline['base_commit'][:9]] = stale
for name in plan['consumers']: current[name] = receipts[name]
links = [path for path in (W/'link/cli').glob('*/process.json') if read(path).get('exit') == 0]
assert links
link_process = max(links, key=lambda path:read(path)['started'])
terminal(read(link_process))
next_base.update(schema='hyle.current-model-link-base.v1', base=pin(W/'plan.json'),
    compile=plan['consumers']['cli']['compile'], link=read(link_process.parent/'command.json'),
    consumer_source=pin(W/'candidate-cli.cc'), previous_consumer=receipts['cli']['receipt'],
    retained=plan['candidate_retained'], runtime=plan['runtime'],
    sdk_engine_dependencies=plan['candidate_sdk'], current_consumers=current,
    historical_consumers=historical,
    note='227 exact SDK inputs: current weights.cc plus226 retained. Current cli/rows/ids use new PreparedWeightSource headers and weights object. Other consumers remain current only when all recorded source pins match; mismatching old-header/main consumers are historical and must not link against this new layout without recompilation.')
save(W/'model-link-base.json', next_base)

checks=[]; failures=[]; attempts=[]
for directory in ('compile','link','baseline-link','probe-runs','measure-runs','baseline-runs','k-width-runs'):
    for path in sorted((W/directory).rglob('process.json')):
        process = read(path)
        # Baseline link attempt1 is the real unobserved orchestration failure.
        if directory=='baseline-link' and path.parent.name=='attempt1':
            attempts.append(dict(name=path.parent.relative_to(W).as_posix(), process=pin(path),
                status='TERMINAL_EXIT_UNOBSERVED_NOT_PASS', actual=process)); continue
        terminal(process)
        row=dict(name=path.parent.relative_to(W).as_posix(), process=pin(path), actual=process,
            command=pin(path.parent/'command.json'))
        attempts.append(row)
        if process['exit']:
            failures.append(dict(**row, stdout=pin(path.parent/'stdout.log'), stderr=pin(path.parent/'stderr.log')))
        elif directory in ('probe-runs','measure-runs','baseline-runs','k-width-runs'):
            report=read(path.parent/'report.json'); assert report.get('status','PASS') == 'PASS'
            checks.append(dict(**row, report=pin(path.parent/'report.json')))

preflight=read(W/'preflight-runs/attempt2/summary.json')
assert preflight['status']=='PASS' and len(preflight['cases'])==4
assert all(case['status']=='PASS_EXPECTED_REJECTION' and case['exit']==1 and case['before_input_or_map_open'] for case in preflight['cases'])
loader_failure=read(W/'preflight-runs/setup-failure.json')
assert loader_failure['exit']==3221225781

peer=read(W/'peer-window/summary.json')
assert peer['status']=='COMPLETE32_FOUR_ARMS_STABLE' and peer['processes']==32
peer_processes=[]
for group in read(W/'peer-window/plan.json')['groups']:
    folder=W/'peer-window'/(group['scenario']+'-'+group['mode'])
    runs=read(folder/'runs.json'); assert len(runs)==group['processes']
    for row in runs:
        result=read(Path(row['folder'])/'result.json'); assert result['exit']==0 and result['finished_unix_ns']>result['started_unix_ns']
        peer_processes.append(dict(arm=row['arm'], scenario=group['scenario'], mode=group['mode'],
            result=pin(Path(row['folder'])/'result.json'), command=pin(Path(row['folder'])/'command.json')))
assert len(peer_processes)==32
width_screen=read(W/'k-width-summary.json')
assert width_screen['status']=='PASS_EXACT4_K1_K2_SCREEN' and width_screen['processes']==4

comparisons={name:pin(W/name) for name in (
    'default-compare.json','subset-compare.json','two-correctness1-compare.json',
    'k2-correctness1-compare.json','state40-trace1-compare.json','state40-trace-compare.json')}
for item in comparisons.values(): assert read(item['path'])['status']=='PASS'
trace_files=[]
for trace in sorted((W/'measure-runs').rglob('trace')):
    if not trace.is_dir(): continue
    for path in sorted(trace.rglob('*')):
        if path.is_file(): trace_files.append(dict(relative=path.relative_to(W).as_posix(),identity=pin(path),
            archived_metadata=path.name=='kv-layout.json'))
save(W/'trace-payload-pins.json',dict(files=trace_files,total_bytes=sum(row['identity']['bytes'] for row in trace_files),
    scope='All exported raw tensors and metadata hashed before cleanup. Only kv-layout metadata archived, no raw tensor payload. Common-prefix byte comparisons separately retained; no complete KV/draft-state export claim.'))
source_names=['engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h',
    'engine/models/qwen35/weights.cc','engine/models/qwen35/weights.h','engine/inference/draft_vocabulary.h',
    'tests/tools/inference_draft_vocabulary_test.cc','tests/tools/qwen_draft_vocabulary_probe.cc']
source_pins=[pin(R/name) for name in source_names]
for item in source_pins: assert norm(item['path']) in current_sources and current_sources[norm(item['path'])]==item
# Preserve the exact current repository inputs of these four compiled TUs.
snapshots=[]
for item in sorted(current_sources.values(),key=lambda item:item['path'].lower()):
    source=Path(item['path']); relative=source.relative_to(R)
    if str(relative).startswith('.scratch'):
        if source==W/'candidate-cli.cc': relative=Path('candidate-cli.cc')
        else: continue
    destination=W/'source-current'/relative
    destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(source.read_bytes())
    snapshots.append(dict(original=item,snapshot=pin(destination)))
save(W/'source-current-pins.json',snapshots)
patch=subprocess.check_output(['git','diff','--binary','--','engine','tests'],cwd=R)
(W/'source-change.patch').write_bytes(patch)

prior_map=R/'.scratch/inference-draft-vocab-map-20261030/attempt1/map_32768.json'
prior_evidence=R/'docs/evidence/research/inference-code-vocabulary-map-2026-10-30.json'
for path in (prior_map,prior_evidence):
    (W/'map-provenance').mkdir(exist_ok=True)
    (W/'map-provenance'/path.name).write_bytes(path.read_bytes())
code_map=read(prior_map); text=(W/'code-32768.ids').read_text().splitlines()
assert text[0]=='hyle-draft-vocabulary-v1' and int(text[2])==248320
assert set(map(int,' '.join(text[3:]).split()))==set(code_map['token_ids'])
assert len(code_map['token_ids'])==32768

summary=dict(schema='hyle.inference-draft-vocabulary.v1',date='2026-10-30',
    status='FINITE_SCREEN_AND_FULL32_WINDOW_COMPLETE',full_goal_complete=False,
    base_commit=baseline['base_commit'],sources=source_pins,source_snapshots=pin(W/'source-current-pins.json'),
    baseline_plan=pin(W/'baseline-plan.json'),baseline_ABI_scope=baseline['base'],
    candidate_plan=pin(W/'plan.json'),model_link_base=pin(W/'model-link-base.json'),
    current_consumer_receipts=receipts,retained_sdk_inputs=plan['candidate_retained'],
    stale_previous_consumers=stale,source_dependency_inventory=plan['candidate_sdk'],
    unavailable_sdk_dependency_records=len(plan['unavailable_dependencies']),
    unavailable_dependency_scope='Unchanged native kernel/library inputs; no complete source-dependency claim for their69 missing cached records.',
    map=dict(file=pin(W/'code-32768.ids'),prior=pin(prior_map),research_evidence=pin(prior_evidence),
        scope='Independent offline local reference-engine source corpus; no test prompt/output selected this map; not a general-language or universal acceptance claim.'),
    checks=checks,comparisons=comparisons,expected_CLI_rejections=preflight,
    trace_export_manifest=pin(W/'trace-payload-pins.json'),
    all_build_and_finite_native_attempts=attempts,failed_observed_attempts=failures,
    corrected_attempts=[
        dict(kind='baseline-link-wrapper',receipt=pin(W/'baseline-link-attempt1-orchestrator-failure.json'),
            scope='Linkattempt1 started but wrapper failed before terminal observation. Running process metadata is historical, not live proof; terminal exit unobserved, never counted PASS. Separate attempt2 exit0 observed.'),
        dict(kind='CLI-compile',attempt='attempt1',scope='MSVC/WX C4458: draft_scores hidden parameter shadowed Model::hidden; renamed selected_hidden; new attempt2 exit0.'),
        dict(kind='rows-CPU-native',attempt='attempt1',scope='Probe Recipe missed independent last_row binding. Probeonly bound actual last_row=1 for fixed2 rows; new rowscompileattempt3, CPUattempt2 and CUDAattempt1 passed without weakening assertions.'),
        dict(kind='CLI-native-loader-setup',receipt=pin(W/'preflight-runs/setup-failure.json'),actual=loader_failure,
            scope='Missing cached runtime PATH caused Windows DLL-not-found before entrypoint. Not a CLI policy pass. Four explicit incompatible requests separately passed expected rejection with correct environment.')],
    build=dict(SDK_CXX=1,SDK_unchanged_retained=226,total_SDK_inputs=227,current_consumers=3,
        CXX_actual_attempts=sum(row['name'].startswith('compile/') for row in attempts),
        NVCC=0,downloads=0,baseline_CXX=0,max_compiler_concurrency=2,ABI=plan['ABI']),
    screening=read(W/'screen-summary.json'),
    fair64_width_screen=dict(summary=pin(W/'k-width-summary.json'),data=width_screen,
        scope='Exactly4 new K1/K2/K2/K1 processes,64outputs each; not pooled with previous40output K2 correctness or32process peerwindow. No independent memory sampling for this screen.'),
    full_window=dict(summary=pin(W/'peer-window/summary.json'),data=peer,processes=peer_processes,
        hardware_snapshots=[pin(path) for path in sorted((W/'peer-window/group-hardware').glob('*.json'))]),
    explicit_memory_cost=dict(cold_weight_bytes=134217728,cold_weight_MiB=128,map_bytes=131072,map_KiB=128,
        original_weight_fields='Source-only original host/device/canonical weights; selected head/map are separately reported additional pools.',
        physical_memory='Independent PSAPI/PDH samples in full window; peaks are sampling lower bounds, ready unavailable for all8 memory processes; no precise phase increment claim.'),
    limits=[
        'Explicit opt-in dense BF16/F16/F32 draft head, unmodified greedy only. No-option default including stochastic/history/dynamic logits remains original; incompatible explicit random/modifier/threshold mode rejects.',
        'Default candidate versus exact cached baseline compares all non-timing fields with exactly6 new diagnostics excluded and defaults checked. Subset checks every output ID and committed RNG/scalars, with all other deltas retained.',
        'Real64 K1 single,128 two-turn and40 K2 outputs checked. K2 rejected proposal/verification IDs may differ; those differences remain in comparison reports.',
        '23 common state40 prefixes have exact exported tensor bytes/logical KV layouts; exports omit KV tensor payload and complete draft state, so not complete-state equality.',
        'Screening ABBA has2samples perarm/scenario and desktop variation; no pooling with correctness samples, prior windows or new peer window.',
        'Fresh32process window uses frozen peer executable SHA433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e; native core git revision unestablished, not latest upstream. Exact reference source/dependency and GGUF metadata receipts retained by linked provenance.',
        'Cross-engine outputs diverge from19th output and actual work differs. Explicit32K results do not close default full-vocabulary gap or generalize to other models/prompts.',
        'No new Apple/Vulkan/hybrid/multiGPU/multiMachine or model-quality claim; complete overall goal remains active.'])
save(W/'summary-draft.json',summary)

extensions={'.py','.json','.jsonl','.log','.xml','.csv','.txt','.md','.ids','.patch','.cc','.h','.ps1'}
selected=set()
for path in W.iterdir():
    if path.is_file() and path.suffix in extensions and path.name!='archive-draft.json': selected.add(path)
for directory in ('compile','link','baseline-link','probe-runs','measure-runs','baseline-runs','peer-window',
                  'baseline-source','source-current','preflight-runs','metadata-rows-cpu','metadata-rows-cuda','map-provenance','k-width-runs'):
    for path in (W/directory).rglob('*'):
        if path.is_file() and path.suffix in extensions and ('trace' not in path.relative_to(W).parts or path.name=='kv-layout.json'): selected.add(path)
manifest=[dict(member=path.relative_to(W).as_posix(),bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted(selected) if path.name!='retention-manifest.json']
save(W/'retention-manifest.json',dict(schema='hyle.evidence-retention.v1',members=manifest,
    excluded='EXE/OBJ/PDB/DLL/LIB/EXP, model weights, vendor SDK copies and raw trace/tensor payload. Source snapshots, exact object identities, commands, process statuses, hashes and memory samples retained.'))
selected.add(W/'retention-manifest.json')
archive=W/'evidence-draft.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as output:
    for path in sorted(selected): output.write(path,path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as sealed:
    assert sealed.testzip() is None
    for item in manifest:
        payload=sealed.read(item['member'])
        assert len(payload)==item['bytes'] and hashlib.sha256(payload).hexdigest()==item['sha256']
save(W/'archive-draft.json',dict(archive=pin(archive),members=len(selected),all_member_bytes_sha256_verified=True,
    summary=pin(W/'summary-draft.json'),model_link_base=pin(W/'model-link-base.json')))
print(json.dumps(dict(status=summary['status'],checks=len(checks),peer_processes=len(peer_processes),
    archived_files=len(selected),archive_bytes=archive.stat().st_size,current_consumers=list(current),
    stale_previous_consumers=list(stale),retained_sdk=len(plan['candidate_retained']))))
