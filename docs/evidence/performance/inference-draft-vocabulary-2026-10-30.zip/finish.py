from pathlib import Path
import json,hashlib,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
s=read(W/'summary-draft.json');assert s['status']=='FINITE_SCREEN_AND_FULL32_WINDOW_COMPLETE' and not s['full_goal_complete']
for item in s['sources']:
 p=Path(item['path']);data=p.read_bytes();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
s['full_window'].pop('data',None)
s['full_window']['compact_table']=read(W/'peer-window/table-compact.json')
s['full_window']['complete_raw_reports']='Included in the evidence archive and source-pinned full_window.summary; no sample or field is omitted from retained evidence.'
s['cleanup']=read(W/'cleanup-report.json')
s['steering']={'priority':'General/default full-vocabulary ordinary and MTP performance; optional vocabulary result does not replace this requirement.',
'K2_peer_supplement':'Not started or prepared; user steering prioritized default configuration. Existing4process width screen is retained, no cross-window >10percent singledecode claim.',
'next':'Profile current default full-vocabulary ordinary/MTP complete consumers and existing acceleration reuse; preserve original numerical/resource/retirement contracts.'}
s['limits'].append('Raw trace payload was removed only after all1810 hashes, exact23prefix comparisons and46layout metadata were verified in archive. It is no longer available for re-reading, but original commands/source/input identities reproduce it.')
payload=(json.dumps(s,indent=2,ensure_ascii=False)+'\n').encode()
(W/'summary.json').write_bytes(payload)
d=R/'docs/evidence/performance';(d/'inference-draft-vocabulary-2026-10-30.json').write_bytes(payload)
archive=d/'inference-draft-vocabulary-2026-10-30.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as out:
 with zipfile.ZipFile(W/'evidence-draft.zip') as prior:
  for item in prior.infolist():out.writestr(item,prior.read(item.filename))
 for name in ['summary.json','finish.py','cleanup.ps1','cleanup-targets.json','cleanup-report.json']:out.write(W/name,name)
with zipfile.ZipFile(archive) as check:assert check.testzip() is None and check.read('summary.json')==payload
print('Published finite checks+32process window+4width screen; goal active; zip',archive.stat().st_size)
