"""Exactly4 authorized fresh64-output explicit32K processes:K1,K2,K2,K1."""
from pathlib import Path
import importlib.util,json,os,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('width_measure',W/'measure.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
image=m.read(W/'ready-cli.json');m.exact(image)
assert not (W/'k-width-plan.json').exists(),'Preserve the original width plan and attempts'
rows=[]
for at,width in enumerate((1,2,2,1),1):
 args=m.arguments('single',True);args[args.index('--mtp-max-drafts')+1]=str(width)
 rows.append(dict(ordinal=at,width=width,folder=str(W/'k-width-runs'/(f'{at:02d}-k'+str(width))),command=[image['path'],*args]))
m.save(W/'k-width-plan.json',dict(status='PREPARED_EXACT4',order=[1,2,2,1],image=image,map=m.pin(W/'code-32768.ids'),
 workload='Same real prepared V2 input/P154/N1/R1/C1024/64 outputs/auto, unmodified greedy, explicit independent32K.',commands=rows,
 limits='2samples per width only; no stable performance or broad quality claim; no prior40-output samples pooled.'))
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
reports=[];first_result=None
for row in rows:
 folder=Path(row['folder']);m.save(folder/'image.json',image)
 m.b.b.execute(row['command'],folder,300)
 report=m.read(folder/'stdout.log')
 assert report['generated_tokens']==64 and report['live_committed_versions']==0
 m.save(folder/'report.json',report)
 result=report['sessions'][0]['result']
 exact_fields=['generated_ids','generated_tokens','sampling_seed','sampling_stream','sampling_draw_cursor','visible_tokens','emitted_pending']
 if first_result is None:first_result=result
 mismatch={key:dict(expected=first_result[key],actual=result[key]) for key in exact_fields if first_result[key]!=result[key]}
 m.save(folder/'cross-width-correctness.json',dict(status='PASS' if not mismatch else 'FAIL',compared_fields=exact_fields,mismatches=mismatch))
 assert not mismatch,mismatch
 reports.append((row,report))
 print('PASS64 width',row['width'],'ordinal',row['ordinal'],flush=True)
arms={}
metrics=['prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second']
work=['actual_graph_calls','actual_target_rows','verified_target_rows','actual_draft_rows','draft_rounds','agreements','consumed_drafts',
 'overlap_successor_submissions','overlap_successor_publications','overlap_successor_discards','overlap_successor_refusals']
for width in (1,2):
 values=[report for row,report in reports if row['width']==width]
 assert m.stable(values[0])==m.stable(values[1]),width
 arms[str(width)]=dict(metrics={key:dict(samples=[v[key] for v in values],median=statistics.median(v[key] for v in values),minimum=min(v[key] for v in values),maximum=max(v[key] for v in values)) for key in metrics},
  work={key:values[0][key] for key in work},full_non_timing_fields_stable=True,
  reports=[m.pin(Path(row['folder'])/'report.json') for row,report in reports if row['width']==width])
first=reports[0][1];second=reports[1][1]
summary=dict(status='PASS_EXACT4_K1_K2_SCREEN',processes=4,order=[1,2,2,1],outputs64_and_rng_scalars_equal=True,arms=arms,
 delta_K2_over_K1_percent={key:(arms['2']['metrics'][key]['median']/arms['1']['metrics'][key]['median']-1)*100 for key in metrics},
 all_non_timing_differences=m.differences(m.stable(first),m.stable(second)),
 scope='Fresh fair64-output explicit32K comparison,2samples per width only. Actual graph/draft/target/acceptance and every other non-timing delta retained; no prior40-output or other-window pooling. Physical memory not separately sampled in this width screen.')
m.save(W/'k-width-summary.json',summary)
print(json.dumps(dict(status=summary['status'],delta=summary['delta_K2_over_K1_percent'],work={width:arm['work'] for width,arm in arms.items()})))
