$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
if ([IO.Path]::GetFileName($PSScriptRoot) -eq 'hyle') { $workspace = [IO.Path]::GetFullPath($PSScriptRoot) }
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-draft-vocabulary-20261030'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
if ($manifest.workspace -cne $workspace -or $manifest.batch -cne $batch) { throw 'Unexpected cleanup boundary' }
$expectedRoots = @('baseline-bin','bin','measure-runs/state40/full/trace1/trace','measure-runs/state40/subset/trace1/trace')
$roots = @($manifest.roots)
if ($roots.Count -ne 4) { throw 'Unexpected root count' }
for ($i=0; $i -lt 4; $i++) {
  if ([IO.Path]::GetFullPath($roots[$i]) -cne [IO.Path]::GetFullPath((Join-Path $batch $expectedRoots[$i]))) { throw 'Unexpected exact root' }
}
$targets = @($manifest.targets)
if ($targets.Count -ne 1824) { throw 'Unexpected exact target count' }
$total = [long]0
foreach ($pin in $targets) {
  $target = [IO.Path]::GetFullPath($pin.path)
  $inScope = $false
  foreach ($root in $roots) { if ($target.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { $inScope = $true } }
  if (-not $inScope) { throw ('Target escaped exact image/trace roots: ' + $target) }
  $item = Get-Item -LiteralPath $target
  if ($item.PSIsContainer -or $item.Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.sha256) { throw ('Changed target: ' + $target) }
  $total += $item.Length
}
foreach ($pin in $targets) { Remove-Item -LiteralPath $pin.path -Force }
$report = @{status='REMOVED_EXACT_RECREATABLE_IMAGES_AND_TRACE';files=$targets.Count;bytes=$total;retained='Verified archive, trace digests and KV metadata; SDK/current consumer objects, cached weights, sources, commands, reports and samplers'}
$report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | ConvertTo-Json
