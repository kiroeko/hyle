"""Source/build/check/window evidence only; no builds, model runs or cleanup."""
from pathlib import Path
import importlib.util,json,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('vocabulary_collect_baseline',W/'baseline-current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
plan=read(W/'plan.json');baseline=read(W/'baseline-plan.json')
receipts={}
for name in [*plan['units'],*plan['consumers']]:
 path=W/'compile'/name/'receipt.json';receipt=read(path)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
 process=read(receipt['process']['path']);assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
 receipts[name]=dict(receipt=pin(path),object=receipt['object'])
for item in plan['candidate_retained']:exact(item)
checks=[];failed_native=[]
for root in ('probe-runs','measure-runs','baseline-runs'):
 for path in sorted((W/root).rglob('process.json')):
  process=read(path);assert process['state']=='TERMINAL'
  if process['exit']!=0:failed_native.append(dict(process=pin(path),actual=process,stderr=pin(path.parent/'stderr.log')));continue
  report_path=path.parent/'report.json';report=read(report_path)
  assert report.get('status','PASS')=='PASS'
  checks.append(dict(name=str(path.parent.relative_to(W)),report=pin(report_path),process=process,command=pin(path.parent/'command.json')))
sources=['engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h','engine/models/qwen35/weights.cc','engine/models/qwen35/weights.h',
 'engine/inference/draft_vocabulary.h','tests/tools/inference_draft_vocabulary_test.cc','tests/tools/qwen_draft_vocabulary_probe.cc']
window=W/'peer-window/summary.json'
summary=dict(schema='hyle.inference-draft-vocabulary.v1',date='2026-10-30',base_commit=baseline['base_commit'],
 status='FINITE_AND_SCREEN_CHECKS_PASSED_FULL_WINDOW_PENDING' if not window.exists() else 'FINITE_SCREEN_AND_FULL_WINDOW_COMPLETE',
 sources=[pin(R/path) for path in sources],baseline_plan=pin(W/'baseline-plan.json'),candidate_plan=pin(W/'plan.json'),
 map_file=pin(W/'code-32768.ids'),map_provenance=pin(R/'.scratch/inference-draft-vocab-map-20261030/attempt1/map_32768.json'),
 current_consumer_receipts=receipts,checks=checks,failed_native_attempts=failed_native,
 comparisons={name:pin(W/name) for name in ['default-compare.json','subset-compare.json','two-correctness1-compare.json','k2-correctness1-compare.json','state40-trace1-compare.json','state40-trace-compare.json']},
 screening=read(W/'screen-summary.json'),
 build=dict(SDK_CXX=len(plan['units']),retained_unchanged=len(plan['retained'])-len(plan['units']),candidate_consumers=len(plan['consumers']),
  max_compiler_concurrency=2,NVCC=0,downloads=0,
  exact_cached_weights_recipe=baseline['weights_recipe']['compile_command'],
  baseline_zero_compilers=True,baseline_head_source_proof='Exact f578 snapshots/HEAD proof and original cached CLI+227 SDK closure; never candidate source as baseline.'),
 explicit_memory_cost=dict(cold_weight_bytes=134217728,cold_weight_MiB=128,map_bytes=131072,map_KiB=128,
  warning='These new pools are explicit additional allocations; unchanged legacy requested-byte reports are not physical-memory delta evidence.'),
 corrected_attempts=[
  dict(kind='baseline-link-orchestration',attempt='attempt1',report=pin(W/'baseline-link-attempt1-orchestrator-failure.json'),
   reason='Link started but wrapper path-print failed before waiting; terminal status unobserved, never counted PASS; separate attempt2 observed exit0.'),
  dict(kind='compile',unit='cli',attempt='attempt1',reason='MSVC/WX rejected draft_scores hidden parameter shadowing Model::hidden; renamed selected_hidden, new attempt2 passed.'),
  dict(kind='native-probe',unit='rows-cpu',attempt='attempt1',reason='Finite Recipe projection probe omitted independent last_row shape binding; bound last_row=1 while preserving fixed2 input rows, rows recompiled and CPU attempt2/CUDA attempt1 passed.')],
 limits=[
  'Independent32K mapping is explicit opt-in for unmodified greedy drafting, not a universal/default quality or acceptance-rate claim. Random/modifier/threshold paths retain full policy and reject the incompatible explicit option.',
  'K1 finite64/128 outputs and all non-timing facts except5 duplicated new map diagnostics remain unchanged. K2 rejected speculative draft differs85475 to2880 in the second round; all40 emitted IDs/RNG and actual aggregate work match, all3 field changes are retained.',
  'All23 state40 common prefixes have exact matching exported tensor bytes and logical KV layouts; exports do not include KV tensor payload or complete draft state.',
  'ABBA screening has only2 samples per arm/scenario; single ranges overlap and desktop activity is present. Initial correctness samples and historical windows are not pooled.',
  'Complete peer comparison uses frozen433e7051 executable/native core, not latest upstream; core git revision is unestablished. Cross-engine output divergence and actual work differences remain explicit.',
  'Physical memory sampling is a lower bound with independently sampled processes; missing ready/boundary values stay unknown. No power limit or clock tuning was performed.',
  'Other artifacts/platforms, complete hybrid, multi-GPU and multi-machine were not run; these checks do not complete the full goal.'])
if window.exists():summary['full_window']=dict(summary=pin(window),data=read(window),group_hardware=[pin(path) for path in sorted((W/'peer-window/group-hardware').glob('*.json'))])
save(W/'summary-draft.json',summary)
(W/'source-change.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','engine','tests'],cwd=R))
with zipfile.ZipFile(W/'evidence-draft.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(W.iterdir()):
  if path.is_file() and path.suffix in ('.py','.json','.ids','.patch','.md'):
   archive.write(path,path.name)
 for directory in ('compile','link','baseline-link','probe-runs','measure-runs','baseline-runs','peer-window','baseline-source'):
  for path in sorted((W/directory).rglob('*')):
   if not path.is_file():continue
   if directory=='baseline-source' or path.suffix in ('.json','.jsonl','.log','.xml'):
    archive.write(path,str(path.relative_to(W)))
 for path in sources:archive.write(R/path,'sources/'+path)
print(json.dumps(dict(status=summary['status'],checks=len(checks),failed_native=len(failed_native),archive_bytes=(W/'evidence-draft.zip').stat().st_size)))
