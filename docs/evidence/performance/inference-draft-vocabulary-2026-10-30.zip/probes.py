"""Explicit bounded probe process with original command/process/image receipts."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('probe_baseline',W/'baseline-current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,exact=b.read,b.save,b.exact
name,attempt=sys.argv[1:]
assert name in ('ids','rows-cpu','rows-cuda')
consumer='ids' if name=='ids' else 'rows'
image=read(W/('ready-'+consumer+'.json'));exact(image)
args=[] if name=='ids' else [name.removeprefix('rows-'),str(R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input/weights.tsv'),str(W/('metadata-'+name))]
folder=W/'probe-runs'/name/attempt;save(folder/'image.json',image)
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
b.b.execute([image['path'],*args],folder,300)
result=read(folder/'stdout.log');assert result['status']=='PASS'
save(folder/'report.json',result);print('PASS',name)
