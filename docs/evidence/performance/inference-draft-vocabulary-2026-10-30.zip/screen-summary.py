"""Reduce fresh ABBA screening only; initial correctness samples are excluded."""
from pathlib import Path
import importlib.util,json,statistics
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('screen_measure',W/'measure.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
summary=dict(status='SCREEN_FINISHED',scope='Fresh same-image ABBA full/subset/subset/full, two samples per arm/scenario; initial correctness samples and other windows not pooled.',scenarios={})
for scenario in ['single','two']:
 arms={};paths_by_arm={}
 for arm,attempts in [('full',['abba-1','abba-4']),('subset',['abba-2','abba-3'])]:
  paths=[W/'measure-runs'/scenario/arm/attempt/'report.json' for attempt in attempts];values=[m.read(p) for p in paths]
  assert m.stable(values[0])==m.stable(values[1]),(scenario,arm)
  for path in paths:
   process=m.read(path.parent/'process.json');assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
  fields=['prefill_tokens_per_second','decode_output_tokens_per_second','output_tokens_per_second']
  arms[arm]=dict(reports=[m.pin(path) for path in paths],
   metrics={key:dict(samples=[v[key] for v in values],median=statistics.median(v[key] for v in values),minimum=min(v[key] for v in values),maximum=max(v[key] for v in values)) for key in fields},
   full_non_timing_fields_stable=True,work={key:values[0][key] for key in ['draft_rounds','agreements','consumed_drafts','actual_draft_rows','actual_target_rows']})
  paths_by_arm[arm]=paths
 for at,path in enumerate(paths_by_arm['subset']):m.compare(paths_by_arm['full'][0],path,W/('screen-'+scenario+'-subset'+str(at)+'.json'),'subset')
 summary['scenarios'][scenario]=dict(arms=arms,
  delta_percent={key:(arms['subset']['metrics'][key]['median']/arms['full']['metrics'][key]['median']-1)*100 for key in fields},
  extra_cold_weight_bytes=134217728,extra_map_bytes=131072,
  physical_memory='Not measured in screening; old budget/report equality is not a no-memory-delta claim.')
m.save(W/'screen-summary.json',summary)
print(json.dumps({name:value['delta_percent'] for name,value in summary['scenarios'].items()}))
