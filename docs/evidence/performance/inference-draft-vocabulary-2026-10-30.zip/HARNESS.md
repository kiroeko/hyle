# Current draft-vocabulary measurement harness

Baseline is the exact `f578049c546b55f1f05fbb72ff7036752b38e8a7` cached CLI with the same 227 SDK inputs. `baseline-plan.json` proves changed source files against exact committed snapshots, rather than treating the migrated candidate source as baseline. No baseline SDK or CLI compilation was performed. Link attempt1 lost its terminal observation due to a wrapper path error and is not counted as success; attempt2 was separately observed exiting0.

`candidate-current.py` preserves the old unexecuted `build.py`. It scans actual cached dependencies of all 227 retained inputs. The candidate rebuilds one affected SDK CXX TU (`weights.cc`) plus CLI/IDs/rows consumers; 226 SDK inputs are retained. Source/dependency/ABI checks occur before seal/link. The exact weights command is recorded in `baseline-plan.json` and comes from `inference-effect-domains-20261030/compile/sdk-engine__models__qwen35__weights_cc/node-storage-v1/command.json`.

No weights are copied or downloaded. `code-32768.ids` uses the original V2 source identity and the independent recorded 32K code-domain map. CLI selection is explicit through `--mtp-draft-vocabulary FILE`; the original prepared-input directory is reused.

Commands are explicit, preserve every attempt, and do not automatically retry:

```powershell
python .scratch/inference-draft-vocabulary-20261030/probes.py ids attempt1
python .scratch/inference-draft-vocabulary-20261030/probes.py rows-cpu attempt2
python .scratch/inference-draft-vocabulary-20261030/probes.py rows-cuda attempt1
python .scratch/inference-draft-vocabulary-20261030/measure.py run full single attempt1
python .scratch/inference-draft-vocabulary-20261030/measure.py run subset single attempt1
```

`measure.py compare OLD NEW OUTPUT full` compares the baseline against candidate default over every non-timing field, excluding exactly the six new diagnostic names. Their default values are also checked. `... subset` checks every generated token plus committed scalar/RNG facts, and records every other non-timing difference, including acceptance and actual work. It does not silently omit changed fields. Single/two-turn screening can run explicit `full/subset/subset/full` order with new attempt names after correctness passes.

`state40` is an independent diagnostic run exporting logits/hidden/GDN/conv and KV layout metadata. `trace-compare OLD_REPORT NEW_REPORT OUTPUT` aligns common session/turn/visible-prefix keys, ignores only physical page IDs as allocation facts, and compares exact tensor bytes where actual inputs and exported shapes match. Different speculative grouping/inputs are listed explicitly with both digests. These exports contain neither KV tensor payload nor complete draft state and cannot alone prove complete state equality.

After screening benefit, `window-current.py prepare` emits the retained 32-process four-case protocol (ordinary/MTP, single/two-turn; 24 timing plus eight independent memory processes). It keeps the existing timing endpoints and Windows PSAPI/PDH sampling, adds the explicit map only to Hyle MTP, and does not start model processes. `run-one` remains explicit and GPU concurrency is one.

The frozen reference executable is `.scratch/qwen-mtp-final-window-20261024/peer-link1/peer.exe`, SHA256 `433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e`. Its exact single/two-turn commands, source/dependency identity, runtime environment and cached GGUF metadata receipts are linked by `measure-plan.json`. The native core git revision is not established and this is not the latest-upstream claim. GGUF sizes/metadata are checked; no new multi-GB payload rehash is implied.
