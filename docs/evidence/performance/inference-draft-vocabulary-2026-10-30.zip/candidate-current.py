"""Current source-pinned candidate; rebuild every affected cached CXX consumer."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import importlib.util,shutil,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_vocabulary_build',R/'.scratch/inference-source-binding-20261030/build.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
s.W=s.b.W=W
read,save,pin,exact,key=s.read,s.save,s.pin,s.exact,s.key
BASE=R/'.scratch/inference-glm-candidate-failure-20261030/model-link-base.json'
def prepare():
 assert not (W/'plan.json').exists(),'Preserve plan/attempts'
 base=read(BASE);sdk=read(base['sdk_engine_dependencies']['path'])
 changed={key(R/x) for x in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
 rows={key(row['object']):row for row in sdk['inspected']}
 rows.update({key(row['object']):row for row in sdk['engine_consumers'] if 'dependencies' in row})
 units={};actual=[];unavailable=[]
 for item in base['retained']:
  exact(item);obj=Path(item['path']);row=rows.get(key(obj))
  for adjacent in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
   if adjacent.is_file() and 'Data' in read(adjacent):row=dict(object=str(obj),dependencies=pin(adjacent));break
  if row is None:unavailable.append(str(obj));continue
  actual.append(row);deps=read(row['dependencies']['path'])['Data']
  if not any(key(x) in changed for x in [deps['Source'],*deps['Includes']]):continue
  args,recipe=s.command_for(obj,deps['Source'])
  name='sdk-'+Path(deps['Source']).relative_to(R).as_posix().replace('/','__').replace('.','_')
  units[name]=dict(source=deps['Source'],original=item,recipe=recipe,old_dependencies=row['dependencies'],compile=s.relocated(args,name))
 assert any(key(unit['source'])==key(R/'engine/models/qwen35/weights.cc') for unit in units.values())
 assert all(Path(unit['source']).suffix=='.cc' for unit in units.values())
 wrapper=W/'candidate-cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 consumers={}
 for name,source in [('cli',wrapper),('rows',R/'tests/tools/qwen_draft_vocabulary_probe.cc'),('ids',R/'tests/tools/inference_draft_vocabulary_test.cc')]:
  if name!='rows':assert source.is_file(),source
  consumers[name]=dict(source=str(source),compile=s.relocated(base['compile'],name,source))
 old=read(base['current_consumers']['cli']['receipt']['path'])
 prior=read(R/'.scratch/inference-request-bridges-20261030/plan.json')
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 save(W/'plan.json',dict(base=pin(BASE),base_commit=read(W/'baseline-plan.json')['base_commit'],
  retained=base['retained'],runtime=base['runtime'],sdk=base['sdk_engine_dependencies'],
  actual_dependency_rows=actual,unavailable_dependencies=unavailable,changed_tracked_inputs=sorted(changed),
  units=units,consumers=consumers,original_link=base['link'],original_consumer=old['object']['path'],
  args=prior['args'],SDK_CXX=len(units),NVCC=0,downloads=0,max_compilers=2,
  ABI='Old-layout baseline remains separately pinned. Every retained CXX include consumer affected by weights.h is recompiled before candidate link; no mixed PreparedWeightSource layout.'))
 print('PREPARED',len(units),'SDK CXX,',len(consumers),'consumers; max2cl; no compile/native/download started.')
def compile_units(attempt,names):
 p=read(W/'plan.json');names=list(p['units']) if names==['sdk'] else names
 errors=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(s.compile_one,name,attempt):name for name in names}
  for job in as_completed(jobs):
   try:job.result()
   except BaseException as error:errors.append(dict(name=jobs[job],error=str(error)))
 save(W/('compile-'+attempt+'-'+names[0]+'.json'),dict(units=names,errors=errors,max_concurrency=2))
 assert not errors,errors
def link(name,attempt):
 p=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json')
 for item in [receipt['object'],*receipt['source_identities'],*p['candidate_retained']]:exact(item)
 replacements={key(before['path']):after['path'] for before,after in zip(p['retained'],p['candidate_retained'])}
 args=[];count=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']):arg=receipt['object']['path'];count+=1
  arg=replacements.get(key(arg),arg)
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='compile':compile_units(sys.argv[2],sys.argv[3:])
 elif action=='seal':s.seal()
 elif action=='link':link(sys.argv[2],sys.argv[3])
 else:raise ValueError(action)
