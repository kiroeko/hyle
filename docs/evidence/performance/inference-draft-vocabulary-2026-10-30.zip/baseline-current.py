"""Relink the f578 baseline CLI with its exact cached SDK; no compilation."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('baseline_runner',R/'.scratch/inference-program-identity-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
BASE=R/'.scratch/inference-glm-candidate-failure-20261030/model-link-base.json'
def source_baseline(item,commit):
 path=Path(item['path'])
 try:exact(item);return dict(identity=item,proof='current-exact')
 except AssertionError:pass
 relative=path.relative_to(R).as_posix();snapshot=W/'baseline-source'/relative
 assert snapshot.is_file(),relative
 data=snapshot.read_bytes()
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],relative
 committed=subprocess.check_output(['git','show',commit+':'+relative],cwd=R)
 assert committed==data,relative
 return dict(identity=item,proof='exact-committed-snapshot',snapshot=pin(snapshot),commit=commit)
def prepare():
 assert not (W/'baseline-plan.json').exists()
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert commit.startswith('f578049c'),commit
 base=read(BASE);cli=read(base['current_consumers']['cli']['receipt']['path'])
 for item in [cli['object'],*base['retained'],base['runtime']]:exact(item)
 proofs=[source_baseline(item,commit) for item in cli['source_identities']]
 sdk=read(base['sdk_engine_dependencies']['path']);weights=[]
 for row in sdk['engine_consumers']:
  if 'dependencies' not in row:continue
  deps=read(row['dependencies']['path'])['Data']
  if key(deps['Source'])!=key(R/'engine/models/qwen35/weights.cc'):continue
  receipt=read(row['original_receipt']['path'])
  for item in [receipt['object'],receipt['dependencies']]:exact(item)
  weights_proofs=[source_baseline(item,commit) for item in receipt['source_identities']]
  command=Path(receipt['process']['path']).parent/'command.json'
  assert command.is_file()
  weights.append(dict(object=receipt['object'],receipt=row['original_receipt'],dependencies=receipt['dependencies'],
   compile_command=pin(command),source_proofs=weights_proofs))
 assert len(weights)==1
 args=[]
 for arg in base['link']:
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'baseline-bin/control').with_suffix(suffix));break
  args.append(arg)
 assert sum(key(arg)==key(cli['object']['path']) for arg in args)==1
 old=read(R/'.scratch/inference-request-bridges-20261030/plan.json')
 (W/'baseline-bin').mkdir(exist_ok=True)
 shutil.copyfile(base['runtime']['path'],W/'baseline-bin'/Path(base['runtime']['path']).name)
 save(W/'baseline-plan.json',dict(status='PREPARED_BASELINE_NOT_RUN',base_commit=commit,base=pin(BASE),
  cli_receipt=base['current_consumers']['cli']['receipt'],cli_object=cli['object'],source_proofs=proofs,
  retained=base['retained'],runtime=base['runtime'],link=args,args=old['args'],weights_recipe=weights[0],
  SDK_CXX=0,NVCC=0,downloads=0,note='Original cached old-layout CLI+SDK closure; candidate sources are never treated as baseline.'))
 print('Prepared cached baseline and exact current weights compile/dependency recipe; no model or compiler started.')
def link(attempt):
 p=read(W/'baseline-plan.json')
 for item in [p['cli_object'],*p['retained'],p['runtime']]:exact(item)
 b.execute(p['link'],W/'baseline-link'/attempt,240)
 save(W/'ready-control.json',pin(W/'baseline-bin/control.exe'))
def run(attempt):
 p=read(W/'baseline-plan.json');image=read(W/'ready-control.json');exact(image)
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 folder=W/'baseline-runs'/attempt;save(folder/'image.json',image)
 b.execute([image['path'],*p['args']],folder,300)
 result=read(folder/'stdout.log')
 assert result['generated_tokens']==64 and result['live_committed_versions']==0
 save(folder/'report.json',result);print('PASS baseline64, no candidate execution.')
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='link':link(sys.argv[2])
 elif action=='run':run(sys.argv[2])
 else:raise ValueError(action)
