"""Explicit one-process screening, exact correctness reduction, prepared peer window."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('vocabulary_measure_baseline',W/'baseline-current.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
DIAGNOSTICS={'draft_vocabulary_requested_rows','draft_vocabulary_rows','draft_vocabulary_identity',
 'draft_vocabulary_weight_bytes','draft_vocabulary_map_bytes','draft_vocabulary_policy'}
def stable(x,drop_diagnostics=False):
 if isinstance(x,dict):return {k:stable(v,drop_diagnostics) for k,v in x.items()
  if not k.endswith('_seconds') and not k.endswith('_per_second') and not(drop_diagnostics and k in DIAGNOSTICS)}
 if isinstance(x,list):return [stable(v,drop_diagnostics) for v in x]
 return x
def differences(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  result=[]
  for key in sorted(a.keys()|b.keys()):result.extend(differences(a.get(key),b.get(key),path+'/'+key))
  return result
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [dict(path=path,previous_length=len(a),current_length=len(b))]
  return [row for at,(x,y) in enumerate(zip(a,b)) for row in differences(x,y,path+'/'+str(at))]
 return [] if a==b else [dict(path=path,previous=a,current=b)]
def arguments(scenario,subset=False,trace=None):
 args=list(read(W/'baseline-plan.json')['args'])
 if scenario=='two':
  at=args.index('--steps');del args[at:at+2]
  args.extend(['--schedule',str(R/'.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt')])
 elif scenario in ('state40','k2'):args[args.index('--steps')+1]='40'
 elif scenario!='single':raise ValueError(scenario)
 if scenario=='k2':args[args.index('--mtp-max-drafts')+1]='2'
 if subset:args.extend(['--mtp-draft-vocabulary',str(W/'code-32768.ids')])
 if trace:args.extend(['--trace',str(trace),'--trace-level','full'])
 return args
def prepare():
 assert not (W/'measure-plan.json').exists()
 peer_ready=R/'.scratch/inference-plan-cold-facts-20261030/peer-window/peer-ready.json'
 peer=read(peer_ready);exact(peer['image']);exact(peer['runtime_environment'])
 prior=R/'.scratch/inference-plan-cold-facts-20261030/peer-window'
 binding=read(prior/'binding.json')
 for item in [binding['prompt'],binding['input_manifest'],binding['schedule'],binding['GGUF_metadata_receipt']]:exact(item)
 for name in ('plain','full_mtp'):
  row=binding['GGUF_offline_metadata'][name];assert Path(row['path']).stat().st_size==row['bytes']
 cases={scenario:{arm:dict(image='ready-control.json' if arm=='baseline' else 'ready-cli.json',
  args=arguments(scenario,arm=='subset')) for arm in ('baseline','full','subset')} for scenario in ('single','two','state40','k2')}
 save(W/'measure-plan.json',dict(status='PREPARED_NOT_RUN',cases=cases,map=pin(W/'code-32768.ids'),
  current_base_commit=read(W/'baseline-plan.json')['base_commit'],peer=pin(peer_ready),
  full_window_retained_runner=pin(R/'.scratch/inference-plan-cold-facts-20261030/window.py'),
  reference_commands={scenario:pin(prior/(scenario+'-timing-plan.json')) for scenario in ('single','two-turn')},
  reference_note='Frozen llama executable433e7051 and native core; not latest upstream, exact core git revision not established. Same cached GGUF metadata/size, no new full payload rehash or download.',
  screening_order=['full','subset','subset','full'],timing='single and two-turn independent ABBA, candidate full vs explicit32K same image; root selects runs.',
  correctness='Baseline vs candidatefull: all non-timing fields exact after excluding only6 named new diagnostics. Subset vs full: every generated ID and committed scalar/RNG checked, all other non-timing deltas recorded explicitly; state40 independently exports logits/hidden/GDN/conv and KV layout metadata, not KV payload or complete draft state.',
  full_window='Only after screening benefit; window-current.py prepare emits existing32-process fourcase protocol with current explicit32K MTP; no automatic run.'))
 print('PREPARED screening and retained reference metadata; no model process started.')
def run(arm,scenario,attempt):
 assert arm in ('baseline','full','subset')
 row=read(W/'measure-plan.json')['cases'][scenario][arm];image=read(W/row['image']);exact(image)
 folder=W/'measure-runs'/scenario/arm/attempt
 args=arguments(scenario,arm=='subset',folder/'trace' if scenario=='state40' else None)
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 save(folder/'image.json',image);b.b.execute([image['path'],*args],folder,600)
 report=read(folder/'stdout.log');assert report['generated_tokens']==(128 if scenario=='two' else 40 if scenario in ('state40','k2') else 64)
 assert report['live_committed_versions']==0
 save(folder/'report.json',report);print('PASS',arm,scenario,attempt)
def compare(previous,current,destination,mode):
 a=read(previous);c=read(current)
 if mode=='full':
  delta=differences(stable(a,True),stable(c,True))
  diagnostics={k:c.get(k) for k in DIAGNOSTICS}
  assert diagnostics==dict(draft_vocabulary_requested_rows=0,draft_vocabulary_rows=0,draft_vocabulary_identity='',
   draft_vocabulary_weight_bytes=0,draft_vocabulary_map_bytes=0,draft_vocabulary_policy='greedy_unmodified_no_threshold')
  result=dict(status='PASS' if not delta else 'FAIL',mode=mode,all_non_timing_fields_equal=not delta,
   excluded_new_diagnostics=sorted(DIAGNOSTICS),new_diagnostics=diagnostics,differences=delta)
 else:
  assert mode=='subset';assert len(a['sessions'])==len(c['sessions'])
  exact_results=[]
  for first,second in zip(a['sessions'],c['sessions']):
   assert first['session_id']==second['session_id']
   old,new=first['result'],second['result']
   fields=['generated_ids','generated_tokens','sampling_seed','sampling_stream','sampling_draw_cursor','visible_tokens','emitted_pending']
   for field in fields:assert old[field]==new[field],field
   exact_results.append(dict(session=first['session_id'],fields=fields,generated_ids=new['generated_ids']))
  work_fields=['actual_graph_calls','actual_target_rows','verified_target_rows','committed_target_rows','actual_draft_rows',
   'draft_rounds','agreements','consumed_drafts','overlap_successor_submissions','overlap_successor_publications','overlap_successor_discards']
  result=dict(status='PASS',mode=mode,exact_output_and_rng=exact_results,
   work={k:dict(previous=a[k],current=c[k]) for k in work_fields},
   all_other_non_timing_deltas=differences(stable(a),stable(c)),
   scope='No arbitrary field omissions; acceptance/work/state-layout deltas remain explicit, not claimed identical.')
 save(destination,result);assert result['status']=='PASS',result.get('differences');print('PASS compare',mode)
def trace_compare(previous,current,destination):
 def inventory(report_path):
  report_path=Path(report_path);report=read(report_path);trace=report_path.parent/'trace';result={}
  layouts=list(trace.rglob('kv-layout.json'));assert layouts,trace
  for session in report['sessions']:
   for record in session['ledger']:
    matches=[path for path in layouts if path.parent.name==record['trace_name']]
    assert len(matches)==1,(record['trace_name'],len(matches))
    path=matches[0];layout=read(path);assert layout['visible_tokens']==record['after_length']
    key=(session['session_id'],record['turn'],layout['visible_tokens'])
    assert key not in result,key
    tensor_files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
     for p in sorted(path.parent.iterdir()) if p.is_file() and p.suffix in ('.f32','.f16','.bf16')}
    actual_input={k:record[k] for k in ('role','input_rows','verified_rows','before_length','input_hash','first_input','draft','verification_input_ids','committed_input_ids')}
    result[key]=dict(trace_name=record['trace_name'],layout=dict(visible_tokens=layout['visible_tokens'],page_rows=layout['page_rows'],page_count=len(layout['pages'])),
     physical_page_ids=layout['pages'],actual_input=actual_input,tensors=tensor_files)
  return result
 a=inventory(previous);c=inventory(current);common=sorted(a.keys()&c.keys());comparisons=[];mismatches=[]
 for key in common:
  first,second=a[key],c[key];layout_equal=first['layout']==second['layout']
  same_input=first['actual_input']==second['actual_input']
  same_shape={name:value['bytes'] for name,value in first['tensors'].items()}=={name:value['bytes'] for name,value in second['tensors'].items()}
  tensor_equal=first['tensors']==second['tensors'] if same_input and same_shape else None
  item=dict(prefix=list(key),layout_equal=layout_equal,same_actual_input=same_input,same_exported_shapes=same_shape,
   tensor_bytes_equal=tensor_equal,previous=first,current=second)
  if tensor_equal is None:item['not_compared_reason']='Actual speculative inputs or exported shapes differ; both complete digests are retained, no tolerance or equality claim.'
  if not layout_equal or tensor_equal is False:mismatches.append(list(key))
  comparisons.append(item)
 result=dict(status='PASS' if not mismatches else 'FAIL',common_prefixes=len(common),comparisons=comparisons,
  only_previous=[list(k) for k in sorted(a.keys()-c.keys())],only_current=[list(k) for k in sorted(c.keys()-a.keys())],mismatches=mismatches,
  ignored_allocation_fact='Physical page IDs only; logical page count/rows/visible prefix still compared.',
  scope='Exports cover logits, hidden, target GDN and conv plus KV layout metadata. KV tensor payload and complete draft state are not exported; no complete-state claim.')
 save(destination,result);assert result['status']=='PASS',mismatches;print('PASS exported trace compare',len(common))
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='run':run(*sys.argv[2:])
 elif action=='compare':compare(*sys.argv[2:])
 elif action=='trace-compare':trace_compare(*sys.argv[2:])
 else:raise ValueError(action)
