"""One independently frozen Model3 CXX/link; no inference or old-output overwrite."""
from pathlib import Path
import hashlib, importlib.util, json, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('model3_cached_tools', W / 'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
EXPECTED = 'b4e72daa77c9ad2f8690c3304f2fbd2ccae4af3b1b458b0dbcafc663afbbd351'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve(); sha = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): sha.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha.hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'],actual['sha256']) == (row['bytes'],row['sha256']), row['path']


def freeze():
    assert not (W / 'model3-plan.json').exists(), 'preserve prior model3 attempt'
    original = pin(R / 'engine/models/qwen35/main.cc'); assert original['sha256'] == EXPECTED
    baseline = read(W / 'ready-model2.json')
    assert baseline['compiled']['source']['sha256'] == '09f47468917ddc2c342a18df8490e7b2acfc993f049674e0a8ffb92ebed64260'
    reused = []
    for row in read(W / 'source-freeze-model2.json'):
        exact(row['snapshot'])
        if b.key(row['original']['path']) != b.key(original['path']):
            exact(row['original']); reused.append(row)
    source = W / 'source/model3/engine/models/qwen35/main.cc'
    source.parent.mkdir(parents=True,exist_ok=True); source.write_bytes(Path(original['path']).read_bytes())
    assert pin(source)['sha256'] == EXPECTED
    b.save(W / 'source-freeze-model3.json', dict(original=original,snapshot=pin(source),
        reused_project_headers=reused, policy='Only main changes; current headers exactly match the independently retained model2 snapshots. Reuse those fixed include roots without copying SDK or header trees.'))
    template_path = W / 'logs/model2/command.json'; template = read(template_path)['command']
    out = W / 'compile/model3'; command = []
    for index,arg in enumerate(template):
        if index and template[index-1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')): arg = str(source)
        command.append(arg)
    b.save(W / 'recipes/model3.json',dict(command=command,template=pin(template_path)))
    b.save(W / 'model3-plan.json',dict(status='FROZEN_NOT_BUILT',original=original,snapshot=pin(source),command=command,
        source_freeze=pin(W / 'source-freeze-model3.json'),baseline=baseline,old_object=baseline['compiled']['object'],
        counts=dict(CXX=1,links=1,inference=0,SDK=0,NVCC=0,downloads=0),
        correction='BatchFacts observer precedes finish_generation_call; prefill uses its real prefill_endpoint, decode its real endpoint. Reporting rejects executed phases without positive elapsed time.',
        preserves='Historical W15 Model1/Model2 sources, object/image hashes, all commands, readiness and public evidence are unchanged. Probe is not rebuilt.'))
    print('FROZEN model3 '+EXPECTED,flush=True)


def compile_unit():
    plan = read(W / 'model3-plan.json'); frozen = read(plan['source_freeze']['path'])
    exact(frozen['original']); exact(frozen['snapshot'])
    for row in frozen['reused_project_headers']: exact(row['original']); exact(row['snapshot'])
    out = W / 'compile/model3'; out.mkdir(parents=True,exist_ok=False)
    process = b.h.execute(plan['command'],b.environment(),W / 'logs/model3',timeout=240)
    data = read(out / 'dependencies.json')['Data']; assert b.key(data['Source']) == b.key(plan['snapshot']['path'])
    allowed = {b.key(row['snapshot']['path']):row['snapshot'] for row in frozen['reused_project_headers']}
    allowed[b.key(frozen['snapshot']['path'])] = frozen['snapshot']
    actual = []
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        row = pin(path); actual.append(row)
        if b.project(path): raise AssertionError(('live project header',path))
        if Path(path).is_relative_to(W / 'source'): assert row == allowed[b.key(path)]
    exact(plan['original']); exact(plan['snapshot'])
    b.save(out / 'actual-dependencies.json',actual)
    b.save(out / 'compiled.json',dict(source=plan['original'],snapshot=plan['snapshot'],object=pin(out / 'unit.obj'),
        process=process,command=pin(W / 'logs/model3/command.json'),compiler_dependencies=pin(out / 'dependencies.json'),
        actual_dependencies=pin(out / 'actual-dependencies.json')))
    print('CXX_PASS model3',flush=True)


def link():
    plan = read(W / 'model3-plan.json'); compiled = read(W / 'compile/model3/compiled.json')
    exact(compiled['object']); exact(plan['original']); exact(plan['snapshot'])
    base = plan['baseline']; exact(base['inputs']); exact(base['recipe'])
    old = read(base['inputs']['path']); assert len(old) == 224
    assert sum(b.key(row['path']) == b.key(plan['old_object']['path']) for row in old) == 1
    inputs = [compiled['object'] if b.key(row['path']) == b.key(plan['old_object']['path']) else row for row in old]
    for row in inputs: exact(row)
    image = W / 'bin/hyle-model3.exe'; command = []
    for arg in read(base['recipe']['path'])['command']:
        if b.key(arg) == b.key(plan['old_object']['path']): arg = compiled['object']['path']
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    b.save(W / 'model3-link-inputs.json',inputs)
    process = b.h.execute(command,b.environment(),W / 'link-model3',timeout=180)
    b.save(W / 'ready-model3.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,link=process,
        inputs=pin(W / 'model3-link-inputs.json'),recipe=pin(W / 'link-model3/command.json'),
        runtime=pin(W / 'runtime-plan.json'),plan=pin(W / 'model3-plan.json')))
    print('LINK_PASS model3 '+pin(image)['sha256'],flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'freeze': freeze()
        elif action == 'compile': compile_unit()
        elif action == 'link': link()
        elif action == 'build': compile_unit(); link()
        else: raise ValueError(action)
    except BaseException:
        (W / ('failure-model3-'+sys.argv[1]+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
