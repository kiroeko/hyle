"""Metadata-only extension of the 18:01 retained complete window to five arms."""
from pathlib import Path
from collections import Counter
import ast
import copy
import hashlib
import json

W=Path(__file__).resolve().parent
R=W.parent.parent
OLD=R/'.scratch/inference-generation-batch-continuation-20261027/full-window'
MODEL=R/'.scratch/inference-continuous-wave-20261027/ready-model2.json'
ARM_ORDER=('hyle_plain','hyle_auto','hyle_mtp','peer_plain','peer_mtp')
GROUPS=(('single','timing'),('single','memory'),('two-turn','timing'),('two-turn','memory'))

def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p);return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def exact(p):assert pin(p['path'])==p,p['path']

def main():
    assert not any((W/(a+'-'+b)).exists() for a,b in GROUPS),'Do not replace completed runs'
    for script in ('prepare.py','window.py'):ast.parse((W/script).read_text())
    current=read(MODEL);exact(current['image']);exact(current['runtime']);exact(current['inputs'])
    exact(current['compiled']['snapshot']);exact(current['compiled']['actual_dependencies'])
    assert current['image']['sha256']=='bbd55e8c683f4d985b4e07b3a55ebb6f7875aed703bd921320da20ad1872ce70'
    assert current['compiled']['snapshot']['sha256']=='09f47468917ddc2c342a18df8490e7b2acfc993f049674e0a8ffb92ebed64260'
    peer=read(OLD/'peer-ready.json');exact(peer['image']);exact(peer['runtime_environment'])
    assert peer['image']['sha256']=='433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    # Use the already successful ordinary/full GGUF mapping. Stat cached payloads
    # only; the receipt is explicit about historical hashes, not a new payload hash.
    gguf=read(R/'.scratch/inference-current-review-profile-20261027/peer-input-correction.json')
    for kind in ('plain','full_mtp'):
        g=gguf[kind];assert Path(g['path']).stat().st_size==g['bytes']
    assert gguf['plain']['tensors']==320 and gguf['full_mtp']['tensors']==335
    assert 'qwen35.nextn_predict_layers' not in gguf['plain']['metadata']
    assert gguf['full_mtp']['metadata']['qwen35.nextn_predict_layers']==1
    original_ready=copy.deepcopy(read(OLD/'ready.json'))
    original_ready.update(image=current['image'],canonical_main=current['compiled']['snapshot'],
        runtime_environment=current['runtime'],link_inputs=current['inputs'],build=pin(MODEL),
        actual_dependencies=current['compiled']['actual_dependencies'],instrumented=False)
    save(W/'ready.json',original_ready);save(W/'peer-ready.json',peer)
    arms=read(OLD/'arms.json')
    arms['arms']['hyle_auto']=copy.deepcopy(arms['arms']['hyle_plain'])
    for arm,row in arms['arms'].items():
        row['ready']=str(W/('ready.json' if arm.startswith('hyle') else 'peer-ready.json'))
        if arm.startswith('hyle'):
            row['command']+=['--decode-overlap','auto' if arm=='hyle_auto' else 'off']
    arms['note']='Five current arms; only ordinary-auto is added to the retained complete protocol. No pooled old samples.'
    save(W/'arms.json',arms)
    fixture=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
    inputs=R/'.scratch/qwen-mtp-window-20261022/inputs'
    schedule=R/'.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt'
    prompt=[int(x) for x in (inputs/'prompt.ids').read_text().split()]
    assert len(prompt)==154 and (fixture/'prompt.ids').read_text().split()==(inputs/'prompt.ids').read_text().split()
    binding=dict(status='PREPARED_ONLY_ROOT_REVIEW_REQUIRED_BEFORE_RUN',Hyle=current,
        peer=peer,GGUF_offline_metadata=gguf,GGUF_metadata_receipt=pin(R/'.scratch/inference-current-review-profile-20261027/peer-input-correction.json'),
        protocol=pin(R/'.scratch/mtp-performance-convergence-20261025/baseline/window.py'),
        previous_adapter=pin(R/'.scratch/inference-generation-batch-continuation-20261027/full-window.py'),
        previous_evidence=pin(R/'docs/evidence/performance/inference-batch-continuation-current-window-2026-10-27.json'),
        current_adapter=pin(W/'window.py'),prompt=pin(inputs/'prompt.ids'),input_manifest=pin(fixture/'weights.tsv'),schedule=pin(schedule),
        retained_peer_not_latest_upstream=True,full_model_payload_read_or_download=False,
        scope='N1/R1/C1024 greedy prefix-off, singleP154+64 or two real turns eachP154+64. Only ordinary-auto added; off/MTP explicit decode-overlap off, MTP K1. No trace, warmup or timing memory observer. No CXX/SDK/new peer.')
    save(W/'binding.json',binding)
    groups=[];global_ordinal=0
    for scenario,mode in GROUPS:
        previous=read(OLD/(scenario+'-'+mode+'-plan.json'))
        prototypes={a:next(x for x in previous['commands'] if x['arm']==a) for a in ('hyle_plain','hyle_mtp','peer_plain','peer_mtp')}
        order=list(ARM_ORDER) if mode=='memory' else [ARM_ORDER[(i+j)%5] for j in range(3) for i in range(5)]
        group=copy.deepcopy(previous);rows=[]
        for ordinal,arm in enumerate(order,1):
            proto=prototypes['hyle_plain' if arm=='hyle_auto' else arm]
            row=copy.deepcopy(proto);folder=W/(scenario+'-'+mode)/(f'{ordinal:02}-{arm}')
            row.update(ordinal=ordinal,arm=arm,folder=str(folder))
            command=row['command']
            if arm.startswith('hyle'):
                command[0]=current['image']['path'];row['image']=current['image'];row['environment']=current['runtime'];row['ready']=pin(W/'ready.json')
                assert '--decode-overlap' not in command
                command+=['--decode-overlap','auto' if arm=='hyle_auto' else 'off']
            else:
                command[0]=peer['image']['path'];row['image']=peer['image'];row['environment']=peer['runtime_environment'];row['ready']=pin(W/'peer-ready.json')
                command[command.index('--output')+1]=str(folder/'consumer-result.json')
                wanted=gguf['full_mtp' if arm=='peer_mtp' else 'plain']['path']
                assert command[command.index('--model')+1]==wanted
            assert command[command.index('--mtp')+1]==('on' if arm.endswith('_mtp') else 'off')
            if arm=='hyle_mtp':assert command[command.index('--mtp-max-drafts')+1]=='1'
            elif arm.startswith('hyle'):assert '--mtp-max-drafts' not in command
            if scenario=='single':assert command[command.index('--steps')+1]=='64'
            else:assert command[command.index('--schedule')+1]==str(schedule) and '--steps' not in command
            assert not any(f in command for f in ('--trace','--decode-ids','--ignore-eos','--layer0-probe'))
            assert command[command.index('--capacity')+1]=='1024'
            global_ordinal+=1;row['window_ordinal']=global_ordinal;rows.append(row)
        assert Counter(x['arm'] for x in rows)=={a:3 if mode=='timing' else 1 for a in ARM_ORDER}
        group.update(commands=rows,arm_order=order,workload=scenario,binding=pin(W/'binding.json'),configuration=pin(W/'arms.json'),
            canonical_main=current['compiled']['snapshot'],timing_processes=15 if mode=='timing' else 0,memory_processes=5 if mode=='memory' else 0,
            retained_plan=pin(OLD/(scenario+'-'+mode+'-plan.json')),plan_only=True)
        save(W/(scenario+'-'+mode+'-plan.json'),group)
        groups.append(dict(scenario=scenario,mode=mode,processes=len(rows),plan=pin(W/(scenario+'-'+mode+'-plan.json')),order=order))
    assert global_ordinal==40
    save(W/'plan.json',dict(status='PREPARED_NOT_RUN_NOT_COMPILED',processes=40,timing_processes=30,independent_memory_processes=10,
        groups=groups,ready=pin(MODEL),binding=pin(W/'binding.json'),adapter=pin(W/'window.py'),prepare_script=pin(Path(__file__)),
        scope=dict(N=1,R=1,capacity=1024,quota_per_turn=64,greedy=True,prefix_cache=False,MTP_K=1),
        metrics=dict(prefill='154/P single; two-turn309 actual target rows/P, also308 user rows. Original complete producer endpoint.',
            decode='actual returned IDs minus1 or2 prefill first IDs over original complete decode endpoint; MTP discarded work charged as cost.',
            RAM_and_VRAM='Separate PSAPI WS/private commit and PDH dedicated/shared/same-sample total; ready no sample =>unknown/null, never0; sampled peaks are lower bounds.',
            comprehensive='Actual all64/128 outputs over complete continuous session P+D; startup/load/first-token separately retained.'),
        repetition='Five-arm rotation predetermined above, three unmonitored timing processes per arm/scenario plus one independent monitored process. No replacement samples or pooled history.',
        future_commands=[['python',str(W/'window.py'),'run-one',s,m] for s,m in GROUPS],
        constraints=['Root review and scheduling precede execution; no inference/driver query/compiler started by this prepare action.',
            'Timing and memory processes never share timing medians. No profiler, SDK build, new peer, download, warmup or clock/cache manipulation.',
            'Full raw stdout/stderr/command/process/report preserved; stop on first genuine process/parser/semantic failure, no rerun. Offline parser repair may continue only unstarted arms.',
            'Across engines, natural IDs and MTP accepted work may differ. Describe actual work; no equal-continuation/quality/significance claim.',
            'Within-arm exact full non-time producer reports and original IDs/work/round decisions must be stable. Do not silently remove varying metadata.',
            'Ordinary-auto must actually report device relay publications; it cannot silently be an off arm. Off/MTP explicitly disable device relay.']))
    print('PREPARED_ONLY 40 commands; 30 timing +10 independent memory; no models/CXX/GPU')

if __name__=='__main__':main()
