"""Offline Model3/40-process receipt. Never builds, runs a consumer or downloads."""
from pathlib import Path
import hashlib
import json
import math
import statistics
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
A = W / 'attempt2'
B = R / '.scratch/inference-continuous-wave-20261027'
D = R / 'docs/evidence/performance'
STEM = 'inference-continuous-wave-current-window-2026-10-27'
MAIN = 'b4e72daa77c9ad2f8690c3304f2fbd2ccae4af3b1b458b0dbcafc663afbbd351'
IMAGE = 'fefa445f9cd5348114ee0981a6886c6027d7735298349080fcb2a1a7b148090e'
ARMS = ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = ('single-timing', 'single-memory', 'two-turn-timing', 'two-turn-memory')
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf',
             '.safetensors', '.pt', '.spv', '.db', '.sqlite', '.pyc', '.zip'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
    return actual


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')


def compact(path, value):
    lines = ['{']
    for i, (key, item) in enumerate(value.items()):
        prefix = '  ' + json.dumps(key) + ': '
        end = ',' if i + 1 < len(value) else ''
        if isinstance(item, list):
            lines.append(prefix + '[')
            for j, row in enumerate(item):
                lines.append('    ' + json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(',', ': ')) + (',' if j + 1 < len(item) else ''))
            lines.append('  ]' + end)
        else:
            lines.append(prefix + json.dumps(item, ensure_ascii=False, allow_nan=False, separators=(',', ': ')) + end)
    lines.append('}')
    Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def triple(item):
    return [round(item[k], 6) for k in ('median', 'min', 'max')]


def mib(value):
    return None if value is None else round(value / (1024 ** 2), 3)


def collect():
    summary = read(A / 'summary.json')
    assert summary['status'] == 'COMPLETE40_FIVE_ARMS_STABLE'
    assert (summary['processes'], summary['timing_processes'], summary['independent_memory_processes']) == (40, 30, 10)
    ready = read(B / 'ready-model3.json')
    assert ready['compiled']['source']['sha256'] == MAIN and ready['image']['sha256'] == IMAGE
    assert ready['compiled']['process']['exit'] == ready['link']['exit'] == 0
    frozen = read(B / 'source-freeze-model3.json')
    exact(frozen['original']); exact(frozen['snapshot']); exact(ready['image'])
    for field in ('inputs', 'recipe', 'runtime', 'plan'):
        exact(ready[field])
    for field in ('snapshot', 'command', 'compiler_dependencies', 'actual_dependencies'):
        exact(ready['compiled'][field])
    assert len(read(ready['inputs']['path'])) == 224
    for row in frozen['reused_project_headers']:
        exact(row['snapshot'])
    amendment = read(A / 'parser-amendment.json')
    assert amendment['status'] == 'PARSER_AMENDMENT_NO_MODEL_RUN' and amendment['GPU_runs'] == 0
    exact(amendment['original_adapter']); exact(amendment['amended_adapter'])
    for field in ('unchanged_plans_and_inputs', 'completed_original_process_files'):
        for row in amendment.get(field, []): exact(row)
    all_processes, groups = [], {}
    for group in GROUPS:
        directory = A / group
        result = read(directory / 'summary.json')
        rows = read(directory / 'runs.json')
        assert len(rows) == (15 if group.endswith('timing') else 5)
        assert result['within_arm_fixed_work_valid'] is True
        groups[group] = result
        for row in rows:
            folder = Path(row['folder'])
            process = read(folder / 'result.json')
            assert process == row['process']
            assert process['exit'] == 0 and not process.get('reader_errors') and not process.get('timed_out', False)
            assert process['memory_only'] == group.endswith('memory')
            if row['arm'].startswith('hyle'): assert process['image']['sha256'] == IMAGE
            assert read(folder / 'timing-partition-gate.json')['status'] == 'PASS'
            raw = read(folder / 'consumer-result.json')
            p, d, total = (raw[k] for k in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
            assert min(p, d, total) > 0 and math.isclose(p + d, total, rel_tol=1e-5, abs_tol=2e-6)
            assert row['observation']['actual_generated_tokens'] == (128 if group.startswith('two-turn') else 64)
            assert row['observation']['stopped_on_EOS'] is False
            if row['arm'].startswith('hyle'): assert raw['live_committed_versions'] == 0
            if row['arm'] == 'hyle_auto':
                expected = (59, 1, False) if group.startswith('two-turn') else (55, 0, True)
                assert (raw['overlap_successor_publications'], raw['overlap_successor_refusals'], raw['decode_overlap_available']) == expected
                assert raw['overlap_successor_submissions'] == expected[0] and raw['overlap_successor_discards'] == 0
            files = [pin(folder / name) for name in ('command.json', 'result.json', 'stdout.log', 'stderr.log')]
            all_processes.append(dict(group=group, arm=row['arm'], pid=process['pid'], exit=0,
                started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                image=process['image'], files=files))
    assert len(all_processes) == len({p['pid'] for p in all_processes}) == 40
    # Recompute the published finite timing reductions from the original parse records.
    for row in summary['table']:
        runs = read(A / (row['scenario'] + '-timing/runs.json'))
        for key, expected in row['timing'].items():
            values = [p['observation']['metrics'][key] for p in runs if p['arm'] == row['arm']]
            assert len(values) == expected['count'] == 3
            assert all(math.isclose(x, expected[k], rel_tol=1e-12) for x, k in
                       ((statistics.median(values), 'median'), (min(values), 'min'), (max(values), 'max')))
    return summary, ready, frozen, groups, all_processes


def receipt(summary, ready, frozen, groups):
    timing, cold, memory, ids, backing = [], [], [], [], []
    for row in summary['table']:
        scenario, arm, t, m = row['scenario'], row['arm'], row['timing'], row['independent_memory']
        timing.append(dict(scenario=scenario, arm=arm,
            prefill_tps=triple(t['prefill_tokens_per_second']), decode_tps=triple(t['full_decode_tokens_per_second']),
            session_output_tps=triple(t['session_output_tokens_per_second']), processed_tps=triple(t['session_processed_tokens_per_second'])))
        cold.append(dict(scenario=scenario, arm=arm, ready_s=triple(t['startup_to_ready_seconds']),
            weights_load_s=triple(t['weights_load_seconds']), first_token_s=triple(t['first_token_elapsed_seconds']),
            startup_endpoint_s=triple(t['startup_to_endpoint_seconds']), cold_output_tps=triple(t['cold_output_tokens_per_second'])))
        peaks = m['sampled_peaks']
        memory.append(dict(scenario=scenario, arm=arm, independent_processes=1,
            dedicated_MiB=mib(peaks['sampled_peak_gpu_dedicated_bytes']), shared_MiB=mib(peaks['sampled_peak_gpu_shared_bytes']),
            same_sample_gpu_total_MiB=mib(peaks['sampled_peak_gpu_total_bytes']),
            working_set_MiB=mib(peaks['sampled_max_working_set_bytes']), private_commit_MiB=mib(peaks['sampled_max_private_commit_bytes']),
            ready_unknown=m['ready_baseline']['unknown'], actual_gap_ms=[round(m['actual_sample_gaps_ms'][k], 3) for k in ('median', 'min', 'max')],
            running_samples=m['running_sample_count'], nulls=m['null_sample_counts']))
    for scenario in ('single', 'two-turn'):
        g = groups[scenario + '-timing']
        for pair, v in g['between_arm_first_process_outputs'].items():
            ids.append(dict(scenario=scenario, pair=pair, equal=v['equal'], first_divergence_zero_based=v['first_divergence'], lengths=[v['left_tokens'], v['right_tokens']]))
        for arm in ARMS[:3]:
            runs = read(A / (scenario + '-timing/runs.json'))
            raw = next(x['observation']['top_level_raw'] if 'top_level_raw' in x['observation'] else x['observation']['raw'] for x in runs if x['arm'] == arm)
            backing.append(dict(scenario=scenario, arm=arm,
                cache_shared_backing_bytes=raw['cache_shared_backing_bytes'], cache_peak_requested_bytes=raw['cache_peak_requested_bytes'],
                actual_graph_calls=raw['actual_graph_calls'], actual_target_rows=raw['actual_target_rows'],
                generated_decode_tokens=raw['generated_decode_tokens']))
    gains = []
    for scenario in ('single', 'two-turn'):
        rows = {r['arm']: r['timing'] for r in summary['table'] if r['scenario'] == scenario}
        gains.append(dict(scenario=scenario,
            auto_vs_off_decode_median_percent=round((rows['hyle_auto']['full_decode_tokens_per_second']['median'] / rows['hyle_plain']['full_decode_tokens_per_second']['median'] - 1) * 100, 3),
            auto_vs_off_session_median_percent=round((rows['hyle_auto']['session_output_tokens_per_second']['median'] / rows['hyle_plain']['session_output_tokens_per_second']['median'] - 1) * 100, 3),
            significance='Not established; three observations per arm, no confidence interval or causal attribution.'))
    old = R / 'docs/evidence/correctness/inference-continuous-wave-2026-10-27.zip'
    return dict(schema='hyle.performance.continuous-wave-window.v1', date='2026-10-27',
        status='COMPLETE40_FIVE_ARMS_STABLE',
        scope='Finite current uninstrumented CUDA Qwen3.5-2B natural generation; Model3 fixes phase reporting. No performance claim from Model1/Model2 timings.',
        counts=dict(build_cxx=1, links=1, timing_processes=30, separate_memory_processes=10, actual_model_processes=40, repetitions_per_timing_arm=3, old_samples_pooled=0),
        images=[dict(role='all current Hyle arms', **ready['image']),
                dict(role='retained local llama native consumer, not latest upstream', **read(A/'peer-ready.json')['image'])],
        source=dict(main_sha256=MAIN, main_snapshot=frozen['snapshot']['path'],
                    reused_project_header_receipts=len(frozen['reused_project_headers']), link_inputs=224,
                    compiler='MSVC 14.50.35717 x64 /O2 /MD /DNDEBUG /W4 /WX; original static closure and runtime aliases',
                    previous_correctness_archive=pin(old)),
        model3_fix=[
            'Batch facts precede finish_generation_call: prefill writes prefill_endpoint. Observer now chooses request.endpoint only for generation and prefill_endpoint otherwise (main:7294).',
            'Actual prefill/decode calls require positive phase elapsed; every process also passes original P+D=session check. These are host producer intervals, not GPU busy or CPU busy.',
            'One main CXX PID47276 exit0; one link PID42492 exit0. Full frozen header/dependency/224-input receipts retained; SDK, NVCC, weights and other objects reused unchanged.'
        ],
        workloads=[dict(scenario='single', user_prompt_tokens=154, target_prefill_rows=154, output_tokens=64, full_decode_outputs=63),
                   dict(scenario='two-turn', turns=2, user_prompt_tokens=308, pending_flush_tokens=1, target_prefill_rows=309, output_tokens=128, full_decode_outputs=126)],
        configuration='N1/R1/C1024, CUDA, greedy, prefix cache off, replay auto. Hyle off/auto are ordinary; MTP K1 explicitly overlap off. Original BF16 role/GGUF fixtures, no payload copied or downloaded.',
        metric_order='Each timing array is [median,min,max] from three unmonitored processes; TPS means tokens/second. Full precision and samples are in ZIP.',
        metric_definitions=[
            'Prefill TPS = actual target prefill rows / complete original prefill interval (two-turn includes one pending flush). New-user-only two-turn TPS is also in raw summary.',
            'Full decode TPS = (all emitted tokens - one prefill output per turn) / complete original decode interval, including draft/catchup and host costs.',
            'Session output TPS = all emitted tokens / (prefill+decode); processed TPS = committed context rows / that same interval.',
            'Cold output TPS = all emitted tokens / original startup-to-final endpoint. Ready and first-token are original producer startup endpoints; no warmup, page-cache flush or instrumented timing.'
        ],
        timing_table=timing, cold_ready_table=cold,
        memory_units='MiB (2^20 bytes); maxima from one independent monitored process per arm/scenario, never timing samples.',
        memory_table=memory,
        memory_limits=[
            'Original Windows PSAPI working set/private commit and PDH WDDM process GPU dedicated/shared counters; requested 10ms, actual gaps/nulls/sample costs and phase samples preserved in ZIP.',
            'Sampled maxima are lower bounds. Dedicated/shared peaks occur separately; same_sample_gpu_total alone sums simultaneous values. CPU/shared GPU observations overlap and must not be added as physical RAM.',
            'Ready baseline is the last sample in actual ready-to-prefill interval; missing stays unknown/null, never zero. No direct DXGI allocator or physical VRAM-limit proof.'
        ],
        relay_facts=[dict(scenario='single', all_auto_processes=4, submissions=55, publications=55, discards=0, refusals=0, final_available=True),
                     dict(scenario='two-turn', all_auto_processes=4, submissions=59, publications=59, discards=0, refusals=1, final_available=False)],
        relay_boundary='Two-turn auto includes later synchronous fallback. Existing logs place transition near visible length384/385; exact rejection status/tuple was not logged, so page/capture cause remains unproven (refusal-review archived).',
        backing_and_work=backing,
        stable_work='All timing repetitions have identical within-arm IDs, exported work and full non-time reports; ordinary off/auto IDs and required mathematical work agree. All 40 consume their quota without natural EOS; live committed versions end at zero.',
        natural_ID_comparisons=ids,
        interpretation=gains,
        interpretation_limits=[
            'Matching quotas do not imply identical natural token trajectories: matching-mode Hyle/peer paths diverge at output index18. Cross-engine and ordinary/MTP numbers are finite natural-workload observations, not equal-operator-work or model-quality proof.',
            'No statistical significance, generalized speedup, architecture-causal gain or new EOS/cancel/fault/multi-platform proof. GPU clocks, desktop/driver, thermal and OS page-cache variation remain uncontrolled; original outside-window snapshots retained.',
            'Existing local peer image/revision only; no assertion about latest llama.cpp, all hardware, or other prompt/output lengths.'
        ],
        parser_and_resume=[
            'Old parser incorrectly required final auto available=true. First two two-turn timing model processes exited0 before parse refusal; their commands/raw outputs/results and old parser are retained unchanged.',
            'Amendment preserves actual59 publications/refusal1/finalfalse rather than relabeling the process. Original first2 were verified offline, then resume ran only remaining13 in the same planned order. Measurement sequence therefore has an explicit pause.',
            'Single timing and memory groups were reanalyzed offline with amended parser, not rerun. Fixed plans, image, inputs, timing endpoints and memory sampler unchanged. No failed sample replacement or hidden rerun.',
            'Historical plan/ready labels describe their creation stage; final completion authority is attempt2/summary.json plus 40 original result records.'
        ],
        archive=dict(status='PENDING_OFFLINE_ZIP', filename=STEM+'.zip'))


def package():
    summary, ready, frozen, groups, processes = collect()
    result = receipt(summary, ready, frozen, groups)
    D.mkdir(parents=True, exist_ok=True)
    output = D / (STEM + '.json')
    compact(output, result)  # Ready for independent table review before ZIP work.
    if len(sys.argv) > 1 and sys.argv[1] == 'receipt':
        print(json.dumps(dict(status='RECEIPT_READY_ZIP_PENDING', json=pin(output))))
        return
    save(W / 'process-index.json', dict(actual_processes=40, processes=processes))
    reused = dict(previous_correctness_archive=result['source']['previous_correctness_archive'],
                  previous_receipt=pin(R/'docs/evidence/correctness/inference-continuous-wave-2026-10-27.json'),
                  policy='Reuse historical frozen bytes/224-input and runtime receipts, not old timings. The new ZIP contains Model3 main and complete header/dependency pins, not duplicated SDK/header payloads.',
                  original_header_snapshots=frozen['reused_project_headers'])
    save(W/'reuse-receipts.json', reused)
    selected = set()
    def add(path):
        p = Path(path).resolve()
        assert p.is_relative_to(R) and p.is_file(), str(p)
        assert p.suffix.lower() not in FORBIDDEN, str(p)
        selected.add(p)
    # Raw processes and sampler data; runs.json and observation.json duplicate
    # these records and are replaced by the independently pinned process index.
    for p in A.rglob('*'):
        if p.is_file() and p.name not in ('runs.json', 'observation.json') and p.suffix.lower() not in FORBIDDEN:
            add(p)
    for p in W.iterdir():
        if p.is_file() and p.name not in ('package-result.json',) and p.suffix.lower() not in FORBIDDEN:
            add(p)
    for name in ('model3.py', 'model3-plan.json', 'source-freeze-model3.json', 'ready-model3.json',
                 'model3-link-inputs.json', 'runtime-plan.json'):
        add(B/name)
    add(frozen['snapshot']['path'])
    for sub in ('compile/model3', 'logs/model3', 'link-model3'):
        for p in (B/sub).rglob('*'):
            if p.is_file() and p.suffix.lower() not in FORBIDDEN: add(p)
    binding = read(A/'binding.json')
    for field in ('protocol', 'previous_adapter', 'GGUF_metadata_receipt', 'prompt', 'input_manifest', 'schedule'):
        exact(binding[field]); add(binding[field]['path'])
    for field in ('source', 'compiled_identity', 'runtime_environment', 'link_plan', 'original_ready', 'current_entry'):
        row = binding['peer'][field]; exact(row); add(row['path'])
    helpers = (
        '.scratch/qwen-mtp-window-20261022/window.py', '.scratch/qwen-mtp-window-20261022/inputs/input.json',
        '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
        '.scratch/qwen-mtp-quality-20261022/run_quality.py',
        '.scratch/qwen-mtp-final-window-20261024/turns.py', '.scratch/qwen-mtp-final-window-20261024/current.py',
        '.scratch/qwen-mtp-final-window-20261024/smoke.py',
        '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
        '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
        '.scratch/shared-execution-20261021/observer.py',
        '.scratch/inference-current-review-profile-20261027/analyze.py',
        '.scratch/inference-continuation-refusal-review-20261027.json')
    for p in helpers: add(R/p)
    members = []
    for p in sorted(selected):
        v = pin(p)
        members.append(dict(member=p.relative_to(R).as_posix(), bytes=v['bytes'], sha256=v['sha256']))
    manifest = dict(schema='hyle.archive.manifest.v1', members=members,
                    omitted_duplicates=['*/runs.json', '*/observation.json'],
                    duplicate_reconstruction='Raw command/result/stdout/stderr, normalized result, fixed inputs, all sampler records and process-index retained; original parser regenerates redundant runs/observation files.',
                    reused_archive=reused['previous_correctness_archive'],
                    binary_payloads_included=False, model_payloads_included=False, external_SDK_sources_included=False)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    destination = D/(STEM+'.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in members:
            data = (R/row['member']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            z.writestr(row['member'], data)
        z.writestr('manifest.json', manifest_bytes)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and len(z.namelist()) == len(members) + 1
        assert z.read('manifest.json') == manifest_bytes
        for row in members:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert all(Path(p).suffix.lower() not in FORBIDDEN for p in z.namelist())
    result['archive'] = dict(**pin(destination), filename=destination.name, members=len(members)+1,
                            uncompressed_bytes=sum(x['bytes'] for x in members)+len(manifest_bytes),
                            all_member_bytes_and_sha256_read_back=True,
                            manifest_sha256=sha(manifest_bytes))
    compact(output, result)
    final = dict(status='PACKAGED_VERIFIED', json=pin(output), zip=pin(destination), members=len(members)+1,
                 actual_model_processes=40, timing_processes=30, independent_memory_processes=10)
    save(W/'package-result.json', final)
    print(json.dumps(final, ensure_ascii=False))


if __name__ == '__main__':
    package()
