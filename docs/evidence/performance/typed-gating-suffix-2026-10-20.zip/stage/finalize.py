"""Publish actual typed suffix implementation, math/lifetime and measured work."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('typed_gating_publish',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
build=S/'checks/native1'
assert c.read(build/'summary.json')['passed']
tests=c.read(S/'tests-complete/summary.json');numeric=c.read(S/'correctness/summary.json')
bench=c.read(S/'benchmark/summary.json');profile=c.read(S/'profile/summary.json')
rotation=c.read(S/'performance-rotation/summary.json')
assert tests['passed'] and tests['cases']==13 and tests['skipped']==0
assert numeric['passed'] and numeric['observation']['equal_vectors']==64
assert bench['passed'] and profile['passed'] and rotation['terminal_zero']==9 and rotation['same_baseline_predictions_all9']
for row in c.read(build/'plan.json')['frozen']:assert b.same(row),row['path']
for arm in ('tests','qwen'):
 assert b.same(c.read(build/(arm+'-image.json')))
 for row in c.read(build/(arm+'-link-plan.json'))['inputs']:assert b.same(row),row['path']
names=['src/graph_provider_ggml_cuda/ggml_cuda_region.cc','third_party/ggml_cuda_runtime/patches.json',
 'third_party/ggml_cuda_runtime/NOTICE.md','cmake/HyleDependencyLock.json',
 'tests/graph_provider_ggml_cuda/typed_gating_silu_test.cc','tests/graph_provider_ggml_cuda/CMakeLists.txt',
 'docs/architecture/compute-design.md','docs/implementation/model-operators.md','docs/developer/current-work.md',
 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']
c.execute('diff-check',['git','diff','--check','--',*names],dict(os.environ),S)
zone=dt.timezone(dt.timedelta(hours=8));first=c.read(S/'performance-rotation/01-baseline.result.json');last=c.read(S/'performance-rotation/09-baseline.result.json')
report=dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
 result='Original strict F32 stable SiLU/product now admits exact BF16 input loads and final BF16 stores as one closed4-node cold candidate. No projection, reduction or public API change.',
 scope='CUDA stable gating; Windows actual runtime. No model-name switch or new executor; other dtype/layout/escape cases keep original operations.',
 source=c.read(S/'product-source-freeze.json'),native=c.read(S/'native-source-freeze.json'),
 independent_review=c.read(S/'independent-review.json'),benchmark_review=c.read(S/'benchmark-review.json'),
 math='BF16->F32 exact load, original marked stable SiLU F32 result, original F32 product, final explicit BF16 RNE. Old all-BF16 round-unary and F32->BF16->SiLU are distinct unchanged contracts.',
 lifetime='All3 intermediate values private; original first/mul/store edges, CPY self refs, source/view readers and controls checked. Cold allocator keeps both actual readonly roots through final store; encode rechecks CUDA owner/device/capacity/offset/alignment and disjoint read/write ranges.',
 build=dict(product_CXX_owners=2,test_CXX_owners=2,native_owners=2,benchmark_CXX_owners=1,SDK_builds=0,
    current_images={arm:c.read(build/(arm+'-image.json')) for arm in ('tests','qwen')},
    main_object_reused=True,canonical_native_header_closure=c.read(S/'native-header-closure.json'),
    IQ1_composition='Manifest-target and actual compiled combined bytes separately recorded; before/after actual native includes the existing independent IQ1 three-case edit.',
    first_test_harness_attempt='GTest exited0 with8 passed, while harness expected13: accepted test link closure lacked oldCastStable TU. Added only that existing fixture TU, retained first XML/logs; final13 all run and pass.'),
 correctness=dict(tests=tests,full_model=numeric,
    independent_quality_acceptance=False,platform_matrix=False,
    nonfinite='New exhaustive65536 BF16 source patterns plus F32 operands compare finite/zero/Inf bits, NaNs class to old physical Cast+strictF32pair+Cast; no blanket bitwise NaN payload claim.'),
 physical=dict(current_profile=profile,extra=c.read(S/'profile-extra.json'),
    old_kernel_reference=650,current_kernel_count=614,old_cast_count=91,current_cast_count=55,
    typed_gating_per_decode=18,removed_cast_launches_per_decode=36,
    limit='Old650 is the retained historical trace, not this turn reprofiled. Current25 warm phases directly show614 kernels and18 mixed instances. GraphLaunch is not equivalent to kernel count; profiler times are not throughput.'),
 benchmark=bench,
 performance=dict(window_beijing=dict(start=dt.datetime.fromtimestamp(first['started'],zone).isoformat(),end=dt.datetime.fromtimestamp(last['finished'],zone).isoformat()),
    rotation=rotation,current_vs_old_stable_gain_established=False,
    observation='Warm+0.4702%, full31+1.5866%, firstprefill+4.2532%, process sample ranges overlap. Current below same-window peer warm2.8348%/full4.6918%; original BF16/F32 intermediate and load/prepare boundary differences remain explicit.',
    memory_sampling_this_batch=False),
 remaining='Selected model/quantization coverage, larger-shape fused carriers, remaining conversion/preparation/resource work and cross-platform journeys remain; no complete architecture/MTP/mmproj claim.')
files={}
allowed={'.py','.cc','.h','.cuh','.cu','.json','.diff','.log','.txt','.tsv','.xml','.csv','.sqlite','.nsys-rep','.ps1'}
for path in S.rglob('*'):
 if not path.is_file() or path.suffix not in allowed:continue
 rel=path.relative_to(S).as_posix()
 if rel in ('publication.json','archive-manifest.json','summary.json','cleanup-plan.json','cleanup-receipt.json'):continue
 if 'compiled-source' in path.parts:continue
 files['stage/'+rel]=path
for name in names:
 path=ROOT/name
 files['product/'+name]=path
manifest=[]
for name,path in sorted(files.items()):
 data=path.read_bytes();manifest.append(dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
public=ROOT/'docs/evidence/performance';archive=public/'typed-gating-suffix-2026-10-20.zip';report_path=archive.with_suffix('.json')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,path in sorted(files.items()):z.write(path,name)
 z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:
  data=z.read(row['name']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=dict(**b.identity(archive),payloads=len(manifest),crc_verified=True,payload_sha256_verified=True)
c.save(report_path,report);c.save(S/'summary.json',report);c.save(S/'archive-manifest.json',manifest)
c.save(S/'publication.json',dict(report=b.identity(report_path),archive=b.identity(archive),payloads=len(manifest),crc_verified=True,payload_sha256_verified=True))
print('TYPED_GATING_PUBLISHED',b.identity(archive)['bytes'],len(manifest),flush=True)
