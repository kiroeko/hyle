"""Compile one fixed chunk; link the same object to the accepted old/new closures."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('typed_bench_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'bench-build';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
old=Path(c.read(S.parent/'lease-read-filter/latest-plan.json')['plan']).parent/'qwen-link-plan.json'
new=S/'checks/native1/qwen-link-plan.json'
bases={arm:c.read(p) for arm,p in (('old',old),('new',new))}
meta=h.h.metadata(bases)
source=S/'bench.cc';frozen=c.read(S/'bench-source-freeze.json')
assert b.identity(source)['sha256']=='7b4aef3a30760325bc8238caa2e888ee2258efecd2f726b3346aee022c72bd5a'
recipe=c.read(S/'checks/native1/typed-gating-test-identity.json')['command']
command=b.host_command(recipe,source,'bench',out)
env,runtime=b.environment(bases['new']['command'],[r['path'] for r in bases['new']['inputs']],out)
c.execute('bench-compile',command,env,out)
data=c.read(out/'bench-deps.json')['Data']
obj=b.identity(out/'bench.obj')
c.save(out/'bench-identity.json',dict(command=command,source=b.identity(source),object=obj,
 dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]))
for arm,base in bases.items():
 main=[]
 for row in base['inputs']:
  owner=meta.get(c.key(row['path']))
  if owner and owner['source_path'].replace('\\','/').endswith('/tools/qwen35_text/main.cc'):main.append(row)
 assert len(main)==1,main
 command=[a for a in base['command'] if c.key(a)!=c.key(main[0]['path']) and not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command.insert(1,obj['path']);image=out/(arm+'.exe')
 command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 lookup={c.key(r['path']):r for r in base['inputs']};lookup[c.key(obj['path'])]=obj
 inputs=[lookup[c.key(a)] for a in command if Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
 for row in inputs:assert b.same(row),row['path']
 c.execute(arm+'-link',command,env,out)
 c.save(out/(arm+'-link-plan.json'),dict(command=command,inputs=inputs))
 c.save(out/(arm+'-image.json'),b.identity(image))
c.save(out/'summary.json',dict(passed=True,same_bench_object=obj,compile=1,links=2,SDK_build=False,main_removed=main))
print('TYPED_GATING_BENCH_BUILT',flush=True)
