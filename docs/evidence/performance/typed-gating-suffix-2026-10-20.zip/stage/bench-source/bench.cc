// Identical object, Graph and capture/submit->wait boundary in both images.
// The link selects the accepted old implementation or the typed suffix.
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#include "hyle/platform/thread.h"

#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
struct Drain final { c::Queue &queue; ~Drain() { (void)queue.drain(); } };
constexpr std::size_t kBranches = 18, kElements = 16 * 128;
constexpr std::uint64_t kHashSeed = 14695981039346656037ULL;
std::uint64_t hash_bytes(std::uint64_t hash, std::span<const std::byte> bytes) {
  for (const auto value : bytes) {
    hash ^= std::to_integer<unsigned char>(value);
    hash *= 1099511628211ULL;
  }
  return hash;
}
std::uint32_t random_word(std::uint32_t &state) {
  state ^= state << 13; state ^= state >> 17; state ^= state << 5;
  return state;
}
m::Buffer upload(m::MemoryResourceRef memory, std::span<const std::byte> bytes) {
  auto buffer = take(m::Buffer::create(memory, bytes.size(), 256));
  check(buffer.view().write(bytes));
  return buffer;
}
double median(std::vector<double> samples) {
  std::ranges::sort(samples);
  return (samples[(samples.size() - 1) / 2] + samples[samples.size() / 2]) / 2;
}

int main(int argc, char **argv) try {
  int iterations = 256, warmup = 64, cpu = -1;
  for (int i = 1; i < argc; i += 2) {
    if (i + 1 == argc) throw std::runtime_error("option requires a value");
    const std::string flag(argv[i]);
    const int value = std::stoi(argv[i + 1]);
    if (flag == "--iterations") iterations = value;
    else if (flag == "--warmup") warmup = value;
    else if (flag == "--cpu") cpu = value;
    else throw std::runtime_error("unknown option: " + flag);
  }
  if (iterations < 1 || warmup < 0 || cpu < -1)
    throw std::runtime_error("iterations must be positive, warmup nonnegative, cpu -1 or nonnegative");
  if (cpu >= 0) {
    check(hyle::platform::this_thread::set_affinity(
        hyle::platform::CpuAffinity(static_cast<unsigned>(cpu))));
    unsigned actual = 0;
    if (take(hyle::platform::this_thread::affinity(&actual, 1)) != 1 ||
        actual != static_cast<unsigned>(cpu))
      throw std::runtime_error("requested caller CPU affinity was not applied");
  }
  auto context = take(g::cuda::create_context());
  auto memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  auto queue = take(context.create_queue());
  check(queue.reserve_completions(4));
  const std::array<std::int64_t, 4> shape{1, 1, 16, 128};
  const auto bf16 = take(c::TensorDesc::dense(c::DataType::kBFloat16, shape));
  const auto f32 = take(c::TensorDesc::dense(c::DataType::kFloat32, shape));
  std::array<m::Buffer, kBranches> inputs, others, outputs;
  std::array<g::ValueId, kBranches> x, y, z;
  auto builder = take(g::GraphBuilder::create());
  std::uint32_t random = 0x36d05117U;
  std::uint64_t inputs_hash = kHashSeed;
  for (std::size_t branch = 0; branch < kBranches; ++branch) {
    std::vector<std::uint16_t> gate(kElements);
    std::vector<float> other(kElements);
    for (std::size_t i = 0; i < kElements; ++i) {
      const auto gx = random_word(random), gy = random_word(random);
      // Fixed normal finite activations spanning both signs and mantissas.
      // These are actual uploaded values; no weights, special-value fixture,
      // host SiLU approximation or forced synthetic zero work is timed.
      gate[i] = static_cast<std::uint16_t>((gx & 0x807fU) |
          ((125U + ((gx >> 8) % 4U)) << 7));
      other[i] = std::bit_cast<float>((gy & 0x807fffffU) |
          ((125U + ((gy >> 8) % 4U)) << 23));
    }
    const auto gate_bytes = std::as_bytes(std::span(gate));
    const auto other_bytes = std::as_bytes(std::span(other));
    inputs_hash = hash_bytes(hash_bytes(inputs_hash, gate_bytes), other_bytes);
    inputs[branch] = upload(memory.ref(), gate_bytes);
    others[branch] = upload(memory.ref(), other_bytes);
    outputs[branch] = take(m::Buffer::create(memory.ref(), take(bf16.required_bytes()), 256));
    x[branch] = take(builder.input(bf16));
    y[branch] = take(builder.input(f32));
    const auto wide = take(builder.add(c::Cast{c::DataType::kFloat32}, x[branch]));
    const auto silu = take(builder.add(c::Unary{c::UnaryKind::kSilu}, wide));
    const auto product = take(builder.add(c::Binary{c::BinaryKind::kMultiply}, silu, y[branch]));
    z[branch] = take(builder.add(c::Cast{c::DataType::kBFloat16}, product));
    // Publish only each final BF16 output, without elided-intermediate readers.
    check(builder.publish(z[branch]));
  }
  auto compiled = take(g::cuda::compile(take(std::move(builder).finish()), context, memory.ref()));
  std::size_t declared_dispatches = 0, step_workspace = 0;
  std::size_t four_node_regions = 0, two_node_regions = 0;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i) {
    const auto step = take(compiled.report.step(i));
    declared_dispatches += step.dispatch_count;
    step_workspace += step.workspace.size;
    if (step.kind == g::CompileStepKind::kProviderRegion && step.node_count == 4) ++four_node_regions;
    if (step.kind == g::CompileStepKind::kProviderRegion && step.node_count == 2) ++two_node_regions;
  }
  auto slot = take(compiled.executable.create_invocation());
  Drain drain{queue};
  for (std::size_t branch = 0; branch < kBranches; ++branch) {
    check(slot.bind(x[branch], take(c::ConstTensorView::create(bf16, inputs[branch].view()))));
    check(slot.bind(y[branch], take(c::ConstTensorView::create(f32, others[branch].view()))));
    check(slot.bind(z[branch], take(c::TensorView::create(bf16, outputs[branch].view()))));
  }
  check(g::cuda::prepare_replay(slot, queue,
      {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject}));
  if (slot.replay_route() != g::ReplayRoute::kCaptured)
    throw std::runtime_error("RequireCapture did not produce actual captured replay");
  const auto replay = take(slot.replay_report());
  const auto run = [&] { auto done = take(slot.submit(queue)); check(done.wait()); };
  for (int i = 0; i < warmup; ++i) run();
  std::vector<double> samples;
  samples.reserve(static_cast<std::size_t>(iterations));
  for (int i = 0; i < iterations; ++i) {
    const auto begin = std::chrono::steady_clock::now();
    run();
    samples.push_back(std::chrono::duration<double, std::micro>(
        std::chrono::steady_clock::now() - begin).count());
  }
  // D2H, finite checks and checksums are all outside submit->wait timing.
  std::array<std::uint64_t, kBranches> output_hashes{};
  std::uint64_t outputs_hash = kHashSeed;
  double output_sum = 0;
  for (std::size_t branch = 0; branch < kBranches; ++branch) {
    std::vector<std::uint16_t> result(kElements);
    check(outputs[branch].view().read(std::as_writable_bytes(std::span(result))));
    for (const auto bits : result) {
      if ((bits & 0x7f80U) == 0x7f80U) throw std::runtime_error("nonfinite BF16 result");
      output_sum += std::bit_cast<float>(static_cast<std::uint32_t>(bits) << 16);
    }
    const auto bytes = std::as_bytes(std::span(result));
    output_hashes[branch] = hash_bytes(kHashSeed, bytes);
    outputs_hash = hash_bytes(outputs_hash, bytes);
  }
  std::cout << std::setprecision(12)
      << "{\"completed\":true,\"branches\":18,\"shape\":[1,1,16,128],"
      << "\"source_dtype\":\"BF16\",\"other_dtype\":\"F32\",\"logical_unary_product_dtype\":\"F32\","
      << "\"output_dtype\":\"BF16\",\"corpus\":\"fixed-normal-finite-v1\","
      << "\"warmup\":" << warmup << ",\"iterations\":" << iterations << ",\"caller_cpu\":" << cpu
      << ",\"captured\":true,\"capture_ranges_recorded\":" << replay.recorded_capture_range_count
      << ",\"capture_ranges_reused\":" << replay.reused_capture_range_count
      << ",\"graph_steps\":" << compiled.report.step_count()
      << ",\"four_node_regions\":" << four_node_regions << ",\"two_node_regions\":" << two_node_regions
      << ",\"declared_dispatches\":" << declared_dispatches
      << ",\"graph_workspace_bytes\":" << compiled.report.workspace_bytes()
      << ",\"sum_step_workspace_bytes\":" << step_workspace
      << ",\"submit_wait_us_median\":" << median(samples)
      << ",\"output_sum\":" << output_sum << ",\"inputs_fnv1a64\":\"" << std::hex << inputs_hash
      << "\",\"outputs_fnv1a64\":\"" << outputs_hash << "\",\"output_fnv1a64\":[";
  for (std::size_t i = 0; i < output_hashes.size(); ++i)
    std::cout << (i ? ",\"" : "\"") << output_hashes[i] << '"';
  std::cout << std::dec << "],\"samples_us\":[";
  for (std::size_t i = 0; i < samples.size(); ++i) std::cout << (i ? "," : "") << samples[i];
  std::cout << "]}\n";
  return 0;
} catch (const std::exception &error) {
  std::cerr << "TYPED_GATING_BENCH_FAILURE " << error.what() << '\n';
  return 1;
}
