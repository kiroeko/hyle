"""One actual current-model Nsight trace; report physical work, never throughput."""
import collections
import csv
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);return r
h=load('typed_profile_build',S/'build.py');b,c=h.b,h.c
a=load('typed_profile_symbols',S.parent/'cuda-stable-silu/profile-analysis-stable.py')
out=S/'profile';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
link=c.read(S/'checks/native1/qwen-link-plan.json');image=c.read(S/'checks/native1/qwen-image.json');assert b.same(image)
assert c.read(S/'correctness/summary.json')['observation']['equal_vectors']==64
old=c.read(S.parent/'lease-read-filter/performance-prepared/plan.json')
command=next(r['command'].copy() for r in old['requests'] if r['arm']=='current');command[0]=image['path']
assert '--trace' not in command
env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
nsys=c.read(S.parent/'decode-critical-path/plan.json')['arms']['hyle']['commands']['profile'][0]
stem=out/'capture'
commands=dict(profile=[nsys,'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
 '--cuda-trace-all-apis=true','--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(stem),*command],
 export=[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],
 stats=[nsys,'stats','--report=cuda_gpu_kern_sum','--format=csv','--output='+str(stem),str(stem)+'.sqlite'])
c.save(out/'plan.json',dict(image=image,link=b.identity(S/'checks/native1/qwen-link-plan.json'),commands=commands,
 consumer_command=command,runtime=runtime,profiler=True,throughput_claim=False,fixed=old['fixed']))
for tag,argv in commands.items():c.execute(tag,argv,env,out)
con=sqlite3.connect('file:'+stem.with_suffix('.sqlite').resolve().as_posix()+'?mode=ro',uri=True);con.row_factory=sqlite3.Row
strings=dict(con.execute('select id,value from StringIds'))
tables={r[0] for r in con.execute("select name from sqlite_master where type='table'")}
kernels=[dict(r,name=strings[r['demangledName']]) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start')]
official=collections.Counter()
with (out/'capture_cuda_gpu_kern_sum.csv').open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):official[r['Name']]+=int(r['Instances'].replace(',',''))
assert official==collections.Counter(r['name'] for r in kernels)
copies=[dict(r) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY order by end')]
tokens=[r for r in copies if r['copyKind']==2 and r['bytes']==4];assert len(tokens)==32
def summarize(rows):
 casts=collections.Counter();typed=0
 for r in rows:
  args=a.template_arguments(r['name'],'cpy_scalar_contiguous')
  if len(args)==2:casts[a.dtype(args[0])+'->'+a.dtype(args[1])]+=1
  args=a.template_arguments(r['name'],'unary_gated_op_kernel')
  if len(args)==6 and [a.dtype(args[i]) for i in (1,3,4,5)]==['bf16','f32','bf16','f32']:typed+=1
 return dict(kernels=len(rows),casts=dict(casts),typed_stable_gating=typed)
phases=[]
for i in range(1,32):
 lo,hi=tokens[i-1]['end'],tokens[i]['end'];rows=[r for r in kernels if lo<r['start'] and r['end']<=hi]
 assert not any(r['start']<hi and r['end']>lo and not (lo<r['start'] and r['end']<=hi) for r in kernels)
 phases.append(dict(index=i,**summarize(rows)))
warm=phases[6:];assert len(warm)==25
observed=summarize([r for r in kernels if tokens[6]['end']<r['start'] and r['end']<=tokens[7]['end']])
diagnostics=[dict(r) for r in con.execute('select * from DIAGNOSTIC_EVENT')] if 'DIAGNOSTIC_EVENT' in tables else []
c.save(out/'diagnostics.json',diagnostics)
streams={}
if 'ProcessStreams' in tables:
 for row in con.execute('select * from ProcessStreams'):
  filename=strings[row['filenameId']]
  if '/streams/' in filename.replace('\\','/'):streams['stderr' if 'stderr_' in filename else 'stdout']=strings[row['contentId']]
elif 'ANALYSIS_FILE' in tables:
 for row in con.execute('select * from ANALYSIS_FILE'):
  if '/streams/' in row['filename'].replace('\\','/'):streams['stderr' if 'stderr_' in row['filename'] else 'stdout']=strings[row['contentId']]
for kind,value in streams.items():(out/('target.'+kind+'.log')).write_text(value,encoding='utf-8')
target=[json.loads(line) for line in streams.get('stdout','').splitlines() if line.startswith('{') and 'generated_ids' in line]
expected=c.read(S/'correctness/summary.json')['observation']['generated_ids']
assert len(target)==1 and target[0]['generated_ids']==expected and target[0]['decode_input_ids']==old['fixed']['decode_input_ids']
summary=dict(passed=all(r['kernels']==614 and r['typed_stable_gating']==18 for r in warm),decode7=observed,
 warm_phases=warm,all_phases=phases,official_CSV_SQLite_symbol_counts_equal=True,profiler_exit_zero=True,
 target_predictions_and_fixed_tape_equal=True,physical_old_reference_kernels=650,physical_new_kernels=observed['kernels'],
 actual_new_typed_symbols=dict(collections.Counter(r['name'] for r in kernels if len(a.template_arguments(r['name'],'unary_gated_op_kernel'))==6)),
 limits='One profiled current whole-model process; historical650 baseline, not a matched timing experiment. CUDA profiling perturbs latency. 32 actual4B D2H completions anchor phases; predictions/tape checked from retained Nsight target stream. No independent quality or peak-memory acceptance.')
c.save(out/'summary.json',summary)
assert summary['passed']
print('TYPED_GATING_PHYSICAL',observed,flush=True)
