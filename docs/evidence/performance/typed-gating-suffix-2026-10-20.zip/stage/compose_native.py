"""Keep manifest targets distinct from the existing CPU+CUDA+IQ1 build source."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
spec = importlib.util.spec_from_file_location('typed_gating_source_edit', STAGE / 'prepare_native.py')
n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(n)


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'src/compute_ggml_runtime' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    target_only_freeze = STAGE / 'native-source-freeze-manifest-only.json'
    freeze = STAGE / 'native-source-freeze.json'
    assert not target_only_freeze.exists(), 'Already composed'
    target_only_freeze.write_bytes(freeze.read_bytes())
    (STAGE / 'native-changes-manifest-only.diff').write_bytes((STAGE / 'native-changes.diff').read_bytes())
    original = json.loads(freeze.read_text(encoding='utf-8'))
    assert n.identity(n.PATCH) == original['product_after'], 'Product changed'
    mixed = STAGE / 'mixed-cpu-manifest.json'
    load('prepare_mixed_cpu_manifest').derive(n.UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json',
        ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    composer = load('prepare_cuda_iq1_manifest')
    iq1 = ROOT / 'third_party/ggml_cuda_runtime/iq1-patches.json'
    composed, target = {}, {}
    for side in ('before', 'source'):
        manifest = STAGE / ('native-' + side) / 'third_party/ggml_cuda_runtime/patches.json'
        output = STAGE / ('before-combined-manifest.json' if side == 'before' else 'combined-manifest.json')
        composer.derive(n.UPSTREAM, mixed, manifest, iq1, output)
        target[side] = {row['path']: n.replay(row) for row in json.loads(manifest.read_text())['files']
                        if row['path'] in n.NAMES}
        composed[side] = {row['path']: n.replay(row) for row in json.loads(output.read_text())['files']
                          if row['path'] in n.NAMES}
        for name in n.NAMES:
            prior = STAGE / ('native-' + side) / name
            assert prior.read_bytes() == target[side][name], name
            snapshot = STAGE / ('manifest-target-' + side) / name
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes(prior.read_bytes())
            prior.write_bytes(composed[side][name])
    rows = []
    diffs = []
    for old in original['files']:
        name = old['name']
        row = dict(old)
        row['before'] = n.identity(STAGE / 'native-before' / name)
        row['after'] = n.identity(STAGE / 'native-source' / name)
        row['manifest_target_before'] = n.identity(STAGE / 'manifest-target-before' / name)
        row['manifest_target_after'] = n.identity(STAGE / 'manifest-target-source' / name)
        row['extra_composed_edits'] = sum(len(entry['edits']) for entry in json.loads(iq1.read_text())['files']
                                          if entry['path'] == name)
        assert (target['before'][name] == composed['before'][name]) == (row['extra_composed_edits'] == 0)
        assert (target['source'][name] == composed['source'][name]) == (row['extra_composed_edits'] == 0)
        rows.append(row)
        diffs.extend(difflib.unified_diff(composed['before'][name].decode().splitlines(True),
                                         composed['source'][name].decode().splitlines(True),
                                         fromfile='before-composed/' + name, tofile='after-composed/' + name))
    (STAGE / 'native-changes.diff').write_text(''.join(diffs), encoding='utf-8', newline='\n')
    original.update(files=rows, diff=n.identity(STAGE / 'native-changes.diff'),
        composition='Existing prepare_mixed_cpu_manifest + prepare_cuda_iq1_manifest, with all original IQ1 cases retained',
        composition_driver=n.identity(Path(__file__)),
        composition_inputs=[n.identity(p) for p in [mixed, iq1, STAGE / 'before-combined-manifest.json',
                                                   STAGE / 'combined-manifest.json']],
        correction='The first source-only freeze represented owning CUDA manifest targets, not build-composed IQ1 source. Preserved separately; no product manifest edit was required.')
    n.save(freeze, original)
    print('COMPOSED')
    for row in rows:
        print(row['name'], 'before', row['before']['sha256'], 'after', row['after']['sha256'])


if __name__ == '__main__':
    main()
