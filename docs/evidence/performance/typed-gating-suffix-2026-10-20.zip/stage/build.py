"""Focused v31 refresh: two native owners, two C++ owners and two test TUs."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('typed_gating_build_helpers', S.parent / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c

def main():
    p = argparse.ArgumentParser(); p.add_argument('--build', action='store_true'); p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    out = S / 'checks/native1'; out.mkdir(parents=True,exist_ok=True); (out/'tmp').mkdir(exist_ok=True)
    latest = Path(c.read(S.parent/'lease-read-filter/latest-plan.json')['plan']).parent
    paths = dict(tests=S.parent/'fp8-shared-prologue/checks/host1/tests-link-plan.json', qwen=latest/'qwen-link-plan.json')
    bases = {arm:c.read(path) for arm,path in paths.items()}
    meta = h.metadata(bases)
    owners = {}
    for arm,base in bases.items():
        owners[arm] = {}
        for item in base['inputs']:
            row = meta.get(c.key(item['path']))
            if row: owners[arm][Path(row['source_path']).name] = dict(row, old_object=item)
    rows = []
    for name in ('ggml_cuda_region.cc','ggml_cuda_provider.cc'):
        owner = owners['qwen'][name]; source = Path(owner['source_path']); tag = source.stem
        command = b.host_command(owner['command'],source,tag,out)
        command = ['/FI'+str(S/'provider-version.h') if a.lower().startswith('/fi') and Path(a[3:]).name=='provider-version.h' else a for a in command]
        rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=command,object=str(out/(tag+'.obj')),source_name=name))
    for name in ('ggml-cuda.cu','unary.cu'):
        owner = owners['qwen'][name]; source = S/'native-source/src/ggml-cuda'/name; tag = source.stem
        recipe=[]; skip=False
        for a in owner['command']:
            if skip: skip=False
            elif a in ('-ccbin','--compiler-bindir'): skip=True
            elif not (a.startswith(('-ccbin=','--compiler-bindir=')) or a.startswith('-I') and ('.scratch' in a or 'reference-windows' in a)): recipe.append(a)
        command = b.native_command(recipe,source,tag,out)
        command[1:1] = ['-I'+str(S/'native-source'/rel) for rel in ('src/ggml-cuda','src','include')]
        rows.append(dict(tag=tag,kind='native',source=b.identity(source),command=command,object=str(out/(tag+'.obj')),source_name=name))
    recipe = c.read(S.parent/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command']
    source = ROOT/'tests/graph_provider_ggml_cuda/typed_gating_silu_test.cc'; tag='typed-gating-test'
    command = b.host_command(recipe,source,tag,out)
    rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=command,object=str(out/(tag+'.obj'))))
    source=ROOT/'tests/graph_provider_ggml_cuda/cast_stable_silu_test.cc';tag='cast-stable-test'
    command=b.host_command(recipe,source,tag,out)
    rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=command,object=str(out/(tag+'.obj'))))
    frozen = [b.identity(S/name) for name in ('native-source-freeze.json','native-header-closure.json','product-source-freeze.json','provider-version.h')]
    frozen += [item for row in c.read(S/'product-source-freeze.json')['files'] for item in (row['after'],row['snapshot'])]
    frozen += [row['source'] for row in rows]
    frozen += [{k:row[k] for k in ('path','bytes','sha256')} for row in c.read(S/'native-header-closure.json')['headers']]
    for arm,base in bases.items():
        for row in base['inputs']: assert b.same(row),row['path']
    plan=dict(compile=rows,base_paths={k:str(v) for k,v in paths.items()},frozen=frozen,
              host_TUs=4,native_TUs=2,SDK_rebuild=False,consumer_main_reused=True,links={})
    c.save(out/'plan.json',plan); c.save(S/'latest-plan.json',dict(plan=str(out/'plan.json')))
    print('TYPED_GATING_PLAN',len(rows),'owners',flush=True)
    if not args.build: return
    def check():
        for row in frozen: assert b.same(row),row['path']
    env,runtime=b.environment(bases['qwen']['command'],[r['path'] for r in bases['qwen']['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check(); receipt_path=out/(row['tag']+'-identity.json')
        if args.resume and receipt_path.exists():
            old=c.read(receipt_path)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(x) for x in old['dependencies']):
                print('REUSE',row['tag'],flush=True); return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out); check()
        if row['kind']=='host':
            data=c.read(out/(row['tag']+'-deps.json'))['Data']; deps=[data['Source'],*data['Includes']]
        else:
            deps=[row['source']['path']]
            for line in (out/(row['tag']+'.d')).read_text().splitlines()[1:]:
                value=line.strip().removesuffix('\\').strip().replace('\\ ',' ')
                if value: deps.append(value)
        receipt=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in dict.fromkeys(deps)])
        c.save(receipt_path,receipt); return row['tag'],receipt
    finished={}; errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,receipt=future.result(); finished[tag]=receipt
            except Exception as error: errors.append(repr(error))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors,owners=len(rows)))
    if errors: raise RuntimeError(errors)
    names={row['source_name']:finished[row['tag']]['object'] for row in rows if 'source_name' in row}
    for arm,base in bases.items():
        replacements={}
        for name,obj in names.items(): replacements[c.key(owners[arm][name]['old_object']['path'])]=obj
        if arm=='tests':
            for name in ('resources.cc','executable.cc'):
                replacements[c.key(owners[arm][name]['old_object']['path'])]=owners['qwen'][name]['old_object']
        lookup={c.key(r['path']):r for r in base['inputs']};lookup.update({c.key(r['path']):r for r in replacements.values()})
        command=[replacements.get(c.key(a),{}).get('path',a) for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if arm=='tests':
            obj=finished['typed-gating-test']['object']; command.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
            obj=finished['cast-stable-test']['object'];command.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
        image=out/(arm+'.exe');command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(a)] for a in command if Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len(set(c.key(r['path']) for r in inputs))
        for row in inputs: assert b.same(row),row['path']
        check();c.execute(arm+'-link',command,env,out);check()
        c.save(out/(arm+'-link-plan.json'),dict(command=command,inputs=inputs))
        c.save(out/(arm+'-image.json'),b.identity(image))
        plan['links'][arm]=dict(command=command,inputs=inputs,image=str(image))
    c.save(out/'plan.json',plan)
    c.save(out/'summary.json',dict(passed=True,host_TUs=4,native_TUs=2,SDK_rebuild=False,consumer_main_reused=True))
    print('TYPED_GATING_BUILT',out,flush=True)
if __name__ == '__main__':main()
