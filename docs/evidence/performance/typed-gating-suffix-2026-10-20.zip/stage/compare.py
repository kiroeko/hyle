"""Current and immediately preceding BF16 Hyle against the same retained peer."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('typed_gating_rotation',S.parent/'qwen-current-retest/compare.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.S=r.rotation.STAGE=S;r.r.PREPARED=S/'performance-prepared'
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');a=p.parse_args()
 if a.run:r.rotation.run(r.r.PREPARED/'plan.json',S/'performance-rotation')
 else:
  old=Path(r.c.read(S.parent/'lease-read-filter/latest-plan.json')['plan']).parent
  image=r.c.read(old/'qwen-image.json');assert r.b.same(image)
  peer=r.c.read(S.parent/'qwen-current-retest/retest-plan.json')['retained_llama_image']
  r.c.save(S/'retest-plan.json',dict(retained_old_image=image,retained_llama_image=peer))
  r.prepare(S/'checks/native1/plan.json')
  plan=r.c.read(r.r.PREPARED/'plan.json')
  plan['baseline']='Immediately preceding lease-read-filter e13cf0ab, same original BF16 main and model; only Graph fusion/native/provider identity refreshed.'
  plan['frozen'].append(r.b.identity(Path(__file__)));r.c.save(r.r.PREPARED/'plan.json',plan)
