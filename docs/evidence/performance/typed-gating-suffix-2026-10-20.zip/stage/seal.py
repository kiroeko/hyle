"""Record this focused increment and reuse the actual native header closure."""
import hashlib
import json
from pathlib import Path
import shutil

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda x: hashlib.sha256(x).hexdigest()
def save(p, x):
    p.write_text(json.dumps(x, indent=2) + '\n', encoding='utf-8')
def identity(p):
    d = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(d), sha256=sha(d))
def main():
    native = read(S / 'native-source-freeze.json')
    assert identity(ROOT / 'third_party/ggml_cuda_runtime/patches.json') == native['product_after']
    notice = ROOT / 'third_party/ggml_cuda_runtime/NOTICE.md'
    notice.write_text((S / 'product-before/third_party/ggml_cuda_runtime/NOTICE.md').read_text().rstrip() + '''

The existing marked stable F32 SiLU/product may consume an exact BF16 load
and store the original final BF16 result directly. Its closed private
BF16-to-F32 Cast / stable F32 SiLU / F32 Multiply / BF16 Cast retains both
F32 intermediate rounding boundaries and only the original final BF16 RNE.
The old same-type unary/product and F32-to-BF16 Cast/SiLU contracts remain
distinct. Cold allocation dependencies retain the actual BF16 source and
F32 multiplier through the final store; encode rechecks CUDA device, bounds
and disjointness. Escaping intermediates or unsupported layouts keep their
ordinary operations. No weight projection or reduction is changed.
''', encoding='utf-8', newline='\n')
    vendor = ROOT / 'third_party/ggml_cuda_runtime'
    lines = []
    for p in sorted(vendor.rglob('*'), key=lambda p:p.relative_to(vendor).as_posix()):
        if p.is_file():
            assert not p.is_symlink()
            d = p.read_bytes().replace(b'\r\n', b'\n').replace(b'\r', b'\n')
            lines.append(p.relative_to(vendor).as_posix() + '|' + sha(d) + '\n')
    tree = sha(''.join(lines).encode())
    lock_path = ROOT / 'cmake/HyleDependencyLock.json'
    lock = read(lock_path)
    entries = {row['name']:row for row in lock['dependencies']}
    entry = entries['ggml_cuda_runtime_patches']
    entry['version'] = 'hyle-ggml-cuda-resource-iq1-inference-v31'
    entry['vendored']['tree_sha256'] = tree
    for item in entry['license']['files']:
        if item['root'] == 'hyle' and item['path'] == 'third_party/ggml_cuda_runtime/NOTICE.md':
            item['sha256'] = sha(notice.read_bytes())
    save(lock_path, lock)
    sid = sha((entries['ggml_runtime_patches']['vendored']['tree_sha256'] +
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes()) +
        sha((ROOT / 'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes()) + tree).encode())[:16]
    (S / 'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-' + sid + '"\n')
    headers = []
    for row in read(S.parent / 'bf16-grouped-bank/native-header-closure.json')['headers']:
        source = Path(row['source']); assert identity(source)['sha256'] == row['sha256']
        out = S / 'native-source' / row['path']; out.parent.mkdir(parents=True, exist_ok=True)
        if not out.exists(): shutil.copyfile(source, out)
        elif row['path'] != 'src/ggml-cuda/unary.cuh': assert out.read_bytes() == source.read_bytes()
        headers.append(dict(name=row['path'], **identity(out)))
    save(S / 'native-header-closure.json', dict(headers=headers, header_count=len(headers)))
    names = ['src/graph_provider_ggml_cuda/ggml_cuda_region.cc', 'third_party/ggml_cuda_runtime/patches.json',
             'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json']
    rows = []
    for name in names:
        source = ROOT / name; target = S / 'product-source' / name
        target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, target)
        rows.append(dict(name=name, after=identity(source), snapshot=identity(target)))
    save(S / 'product-source-freeze.json',dict(files=rows, version=entry['version'], source_id=sid,
        public_API_changed=False, GEMV_or_reduction_changed=False))
    print('SEALED', entry['version'], sid, len(headers), 'headers', flush=True)
if __name__ == '__main__': main()
