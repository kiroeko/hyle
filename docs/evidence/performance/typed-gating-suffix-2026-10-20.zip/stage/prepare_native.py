"""One exact private typed-gating suffix; source edits only, never a build."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
PATCH = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
NAMES = ['src/ggml-cuda/unary.cu', 'src/ggml-cuda/unary.cuh', 'src/ggml-cuda/ggml-cuda.cu']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=sha(data))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def replay(row):
    data = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(data) == row['before_sha256'], row['path']
    for item in row['edits']:
        before, after = item['before'].encode(), item['after'].encode()
        assert data.count(before) == 1, (row['path'], before[:100])
        data = data.replace(before, after, 1)
    assert sha(data) == row['after_sha256'], row['path']
    return data


def main():
    assert not (STAGE / 'native-source-freeze.json').exists(), 'Already frozen'
    before_patch = STAGE / 'native-before/third_party/ggml_cuda_runtime/patches.json'
    if not before_patch.exists():
        before_patch.parent.mkdir(parents=True, exist_ok=True)
        before_patch.write_bytes(PATCH.read_bytes())
    assert PATCH.read_bytes() == before_patch.read_bytes(), 'Product changed since this batch started'
    manifest = json.loads(PATCH.read_text(encoding='utf-8'))
    rows = {row['path']: row for row in manifest['files']}
    original = {name: replay(rows[name]).decode() for name in NAMES}
    source = dict(original)
    changes = {name: [] for name in NAMES}

    def edit(name, old, new):
        assert source[name].count(old) == 1, (name, old[:120])
        source[name] = source[name].replace(old, new, 1)
        changes[name].append(dict(before=old, after=new))

    unary, header, host = NAMES
    old = '''template <float (*op)(float), typename T, bool round_unary = false>
static __global__ void unary_gated_op_kernel(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1) {'''
    new = '''template <float (*op)(float), typename T, bool round_unary = false,
          typename G = T, typename D = T, typename U = T>
static __global__ void unary_gated_op_kernel(const T * x, const G * g, D * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1) {'''
    edit(unary, old, new)
    old = '''        if constexpr (std::is_same<T, nv_bfloat16>::value) {
            value = __bfloat162float(__float2bfloat16_rn(value));
        } else {
            value = (float)(T)value;
        }
        dst[i] = (T)(value * (float)g[j1]);
    } else {
        dst[i] = (T)(op((float)x[j0]) * (float)g[j1]);'''
    new = '''        if constexpr (std::is_same<U, nv_bfloat16>::value) {
            value = __bfloat162float(__float2bfloat16_rn(value));
        } else {
            value = (float)(U)value;
        }
        if constexpr (std::is_same<T, nv_bfloat16>::value &&
                      std::is_same<G, float>::value && std::is_same<D, nv_bfloat16>::value &&
                      std::is_same<U, float>::value) {
            // The logical Unary and Mul are F32. Only the old terminal Cast
            // narrows the result; do not borrow the all-BF16 SiLU boundary.
            const float product = value * g[j1];
            dst[i] = __float2bfloat16_rn(product);
        } else {
            dst[i] = (D)(value * (float)g[j1]);
        }
    } else {
        dst[i] = (D)(op((float)x[j0]) * (float)g[j1]);'''
    edit(unary, old, new)
    old = '''template <float (*op)(float), typename T, bool round_unary = false>
static void unary_gated_cuda(const T * x, const T * g, T * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, cudaStream_t stream) {'''
    new = '''template <float (*op)(float), typename T, bool round_unary = false,
          typename G = T, typename D = T, typename U = T>
static void unary_gated_cuda(const T * x, const G * g, D * dst, const int64_t k, const int64_t n, const int64_t o0, const int64_t o1, cudaStream_t stream) {'''
    edit(unary, old, new)
    edit(unary, 'ggml_cuda_kernel_launch(unary_gated_op_kernel<op, T, round_unary>, launch_params, x, g, dst, k, n, o0, o1);',
         'ggml_cuda_kernel_launch(unary_gated_op_kernel<op, T, round_unary, G, D, U>, launch_params, x, g, dst, k, n, o0, o1);')

    carrier = '''// Exact mixed-port suffix: BF16 -> F32 Cast -> marked stable F32 SiLU
// -> F32 Mul -> BF16 Cast. This metadata predicate never reads addresses.
bool ggml_cuda_supports_cast_stable_silu_mul(const ggml_tensor * cast,
        const ggml_tensor * silu, const ggml_tensor * mul, const ggml_tensor * store) {
    if (!cast || !silu || !mul || !store ||
            cast->op != GGML_OP_CPY || cast->type != GGML_TYPE_F32 ||
            cast->src[1] != cast || cast->view_src ||
            silu->op != GGML_OP_UNARY || silu->type != GGML_TYPE_F32 ||
            silu->src[0] != cast || silu->view_src || !ggml_hyle_stable_silu(silu) ||
            mul->op != GGML_OP_MUL || mul->type != GGML_TYPE_F32 || mul->view_src ||
            (mul->src[0] == silu) == (mul->src[1] == silu) ||
            store->op != GGML_OP_CPY || store->type != GGML_TYPE_BF16 ||
            store->src[0] != mul || store->src[1] != store || store->view_src) return false;
    const ggml_tensor * const x = cast->src[0];
    const ggml_tensor * const other = mul->src[mul->src[0] == silu ? 1 : 0];
    if (!x || !other || x->type != GGML_TYPE_BF16 || other->type != GGML_TYPE_F32) return false;
    const ggml_tensor * const math[] = {cast, silu, mul, store};
    for (const auto * value : math) {
        if (x == value || other == value) return false;
    }
    for (int port = 2; port < GGML_MAX_SRC; ++port) {
        if (cast->src[port] || mul->src[port] || store->src[port]) return false;
    }
    for (int port = 1; port < GGML_MAX_SRC; ++port) {
        if (silu->src[port]) return false;
    }
    const ggml_tensor * const tensors[] = {x, cast, silu, other, mul, store};
    for (const auto * tensor : tensors) {
        uint64_t count = 1;
        for (int axis = 0; axis < GGML_MAX_DIMS; ++axis) {
            // Match the original ordinary dense unary count domain and bound
            // every size/index before ggml_nelements or launch arithmetic.
            if (tensor->ne[axis] <= 0 || uint64_t(tensor->ne[axis]) > uint64_t(INT32_MAX) / count ||
                    tensor->nb[axis] > uint64_t(INT64_MAX) ||
                    tensor->nb[axis] % ggml_type_size(tensor->type)) return false;
            count *= uint64_t(tensor->ne[axis]);
        }
        if (!ggml_is_contiguous(tensor) || !ggml_are_same_shape(tensor, cast)) return false;
    }
    return true;
}

void ggml_cuda_op_cast_stable_silu_mul(ggml_backend_cuda_context & ctx,
        const ggml_tensor * cast, const ggml_tensor * silu,
        const ggml_tensor * mul, ggml_tensor * store) {
    if (!ggml_cuda_supports_cast_stable_silu_mul(cast, silu, mul, store)) {
        hyle::compute::ggml_cuda::bridge::fail(cudaErrorInvalidValue, "invalid typed Cast/stable SiLU/Mul/Cast metadata");
    }
    const ggml_tensor * const x = cast->src[0];
    const ggml_tensor * const other = mul->src[mul->src[0] == silu ? 1 : 0];
    // The owning native encoder checked device limits and actual owner/range/
    // alignment/disjointness, and the allocator retained both original reads.
    unary_gated_cuda<op_hyle_stable_silu, nv_bfloat16, true, float, nv_bfloat16, float>(
        static_cast<const nv_bfloat16 *>(x->data), static_cast<const float *>(other->data),
        static_cast<nv_bfloat16 *>(store->data), ggml_nelements(store), x->ne[0],
        x->nb[1] / sizeof(nv_bfloat16), other->nb[1] / sizeof(float), ctx.stream());
}

'''
    edit(unary, '/* fused relu + sqr */\n', carrier + '/* fused relu + sqr */\n')
    declarations = '''// Private mixed-port stable SiLU*Mul; logical Unary and product stay F32.
// Closed graph/read-root/actual buffer checks belong to cold+encode matching.
bool ggml_cuda_supports_cast_stable_silu_mul(const ggml_tensor * cast,
    const ggml_tensor * silu, const ggml_tensor * mul, const ggml_tensor * store);
void ggml_cuda_op_cast_stable_silu_mul(ggml_backend_cuda_context & ctx,
    const ggml_tensor * cast, const ggml_tensor * silu,
    const ggml_tensor * mul, ggml_tensor * store);

'''
    edit(header, 'void ggml_cuda_op_silu_back(ggml_backend_cuda_context & ctx, ggml_tensor * dst);',
         declarations + 'void ggml_cuda_op_silu_back(ggml_backend_cuda_context & ctx, ggml_tensor * dst);')

    device = '''// The suffix reuses the precise unary object and original cached caps.
static bool ggml_cuda_cast_stable_silu_mul_device(const ggml_tensor * cast,
        const ggml_tensor * silu, const ggml_tensor * mul,
        const ggml_tensor * store, int device) {
    const auto & info = ggml_cuda_info();
    if (device < 0 || device >= info.device_count ||
            !GGML_CUDA_CC_IS_NVIDIA(info.devices[device].cc) ||
            !ggml_cuda_supports_cast_stable_silu_mul(cast, silu, mul, store)) return false;
    const int64_t blocks = (ggml_nelements(store) + CUDA_GLU_BLOCK_SIZE - 1) / CUDA_GLU_BLOCK_SIZE;
    const auto & limits = ggml_cuda_launch_limits[device];
    return blocks <= limits[0] && limits[2] >= CUDA_GLU_BLOCK_SIZE;
}

static bool ggml_cuda_cast_stable_silu_mul_bound(const ggml_tensor * cast,
        const ggml_tensor * silu, const ggml_tensor * mul,
        const ggml_tensor * store, int device) {
    if (!ggml_cuda_cast_stable_silu_mul_device(cast, silu, mul, store, device)) return false;
    const ggml_tensor * const other = mul->src[mul->src[0] == silu ? 1 : 0];
    const ggml_tensor * const tensors[] = {cast->src[0], other, store};
    uintptr_t begin[3] = {}, end[3] = {};
    for (int index = 0; index < 3; ++index) {
        const auto * tensor = tensors[index];
        if (!tensor->data || !tensor->buffer || !ggml_backend_buffer_is_cuda(tensor->buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(tensor->buffer->context);
        if (!owner || owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        begin[index] = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t bytes = ggml_nbytes(tensor);
        const size_t capacity = ggml_backend_buffer_get_size(tensor->buffer);
        if (begin[index] % ggml_type_size(tensor->type) || begin[index] < base ||
                begin[index] - base > capacity || bytes > capacity - (begin[index] - base) ||
                bytes > UINTPTR_MAX - begin[index]) return false;
        end[index] = begin[index] + bytes;
    }
    // Both reads have different element widths from at least one logical
    // boundary. Keep the old graph for every exact/partial output alias.
    for (int index = 0; index < 2; ++index) {
        if (begin[index] < end[2] && begin[2] < end[index]) return false;
    }
    // An explicit same-buffer reader can observe an elided intermediate store
    // without a view_src edge. Include OP_NONE operands, not only math nodes.
    const ggml_tensor * const intermediates[] = {cast, silu, mul};
    for (const auto * value : intermediates) {
        if (!value->data) return false;
        const uintptr_t vb = reinterpret_cast<uintptr_t>(value->data);
        const size_t bytes = ggml_nbytes(value);
        if (bytes > UINTPTR_MAX - vb) return false;
        for (int index = 0; index < 2; ++index) {
            if (begin[index] < vb + bytes && vb < end[index]) return false;
        }
    }
    return true;
}

'''
    anchor = '// New typed reads retain their actual original buffers. Cold supports never\n'
    edit(host, anchor, device + anchor)
    matcher = '''// No new view canonicalizer: admit the four actual adjacent math nodes.
// External dense metadata views stay actual read tensors and retain roots.
// Any internal View/CONT/CPY other than these casts keeps the ordinary path.
static bool ggml_cuda_match_cast_stable_silu_mul(const ggml_cgraph * graph, int begin,
        int device, bool require_bound) {
    if (!graph || begin < 0 || begin >= graph->n_nodes || graph->n_nodes - begin < 4) return false;
    const auto * cast = graph->nodes[begin];
    const auto * silu = graph->nodes[begin + 1];
    const auto * mul = graph->nodes[begin + 2];
    const auto * store = graph->nodes[begin + 3];
    return ggml_cuda_cast_stable_silu_mul_device(cast, silu, mul, store, device) &&
        ggml_cuda_private_fusion_closed(graph, begin, 4) &&
        !ggml_cuda_cast_has_escaping_view(graph, cast) &&
        !ggml_cuda_cast_has_escaping_view(graph, silu) &&
        !ggml_cuda_cast_has_escaping_view(graph, mul) &&
        (!require_bound || ggml_cuda_cast_stable_silu_mul_bound(cast, silu, mul, store, device));
}

'''
    anchor = '// The three intermediates are private BF16 values. A weight transpose is\n'
    edit(host, anchor, matcher + anchor)
    anchor = '''        // Refine exactly the same metadata/closed graph pattern used by
        // encode, and retain its actual F32 read through the terminal.'''
    addition = '''        // Retain actual BF16/F32 reads through the terminal mixed store.
        // This same address-free matcher later qualifies the bound encoder.
        if (ggml_cuda_match_cast_stable_silu_mul(cgraph, i, cuda_ctx->device, false)) {
            const auto * silu = cgraph->nodes[i + 1];
            const auto * mul = cgraph->nodes[i + 2];
            keep(cgraph->nodes[i]->src[0], i + 3);
            keep(mul->src[mul->src[0] == silu ? 1 : 0], i + 3);
            continue;
        }
'''
    edit(host, anchor, addition + anchor)
    anchor = '''    if (node->op == GGML_OP_CPY &&
        ggml_cuda_match_cast_stable_silu(cgraph, i, cuda_ctx->device, true)) {'''
    addition = '''    if (node->op == GGML_OP_CPY &&
        ggml_cuda_match_cast_stable_silu_mul(cgraph, i, cuda_ctx->device, true)) {
        ggml_cuda_op_cast_stable_silu_mul(*cuda_ctx, node, cgraph->nodes[i + 1],
                                        cgraph->nodes[i + 2], cgraph->nodes[i + 3]);
        return 3;
    }

'''
    edit(host, anchor, addition + anchor)

    diffs = []
    files = []
    for name in NAMES:
        before = STAGE / 'native-before' / name
        after = STAGE / 'native-source' / name
        before.parent.mkdir(parents=True, exist_ok=True)
        after.parent.mkdir(parents=True, exist_ok=True)
        before.write_text(original[name], encoding='utf-8', newline='\n')
        after.write_text(source[name], encoding='utf-8', newline='\n')
        rows[name]['edits'].extend(changes[name])
        rows[name]['after_sha256'] = sha(source[name].encode())
        assert replay(rows[name]).decode() == source[name], name
        diffs.extend(difflib.unified_diff(original[name].splitlines(True), source[name].splitlines(True),
                                        fromfile='before/' + name, tofile='after/' + name))
        files.append(dict(name=name, before=identity(before), after=identity(after),
                          edits_added=len(changes[name])))
    (STAGE / 'native-changes.diff').write_text(''.join(diffs), encoding='utf-8', newline='\n')
    PATCH.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8', newline='\n')
    snapshot = STAGE / 'native-source/third_party/ggml_cuda_runtime/patches.json'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(PATCH.read_bytes())
    save(STAGE / 'native-source-freeze.json', dict(
        scope='Source-only typed BF16/F32 stable gating suffix, no build/GPU/cache mutation',
        product_before=identity(before_patch), product_after=identity(PATCH),
        manifest_snapshot=identity(snapshot), files=files,
        driver=identity(Path(__file__)), diff=identity(STAGE / 'native-changes.diff'),
        required_owners=['src/ggml-cuda/unary.cu (precise-unary)', 'src/ggml-cuda/ggml-cuda.cu'],
        no_math_changes_to_default_unary_instances=True,
        compiled=False, executed=False))
    print('FROZEN', identity(PATCH)['sha256'])
    for row in files:
        print(row['name'], row['after']['sha256'], 'edits', row['edits_added'])


if __name__ == '__main__':
    main()
