"""Six serial, unprofiled processes on the same captured18-suffix chunk."""
import importlib.util
import json
from pathlib import Path
import statistics
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('typed_bench_run',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'benchmark';out.mkdir(exist_ok=False);rows=[]
for i,arm in enumerate(('old','new','new','old','old','new'),1):
 d=out/(str(i)+'-'+arm);d.mkdir();(d/'tmp').mkdir()
 image=c.read(S/'bench-build'/(arm+'-image.json'));assert b.same(image)
 link=c.read(S/'bench-build'/(arm+'-link-plan.json'))
 env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],d)
 argv=[image['path'],'--iterations','512','--warmup','128','--cpu','2']
 c.save(d/'inputs.json',dict(image=image,command=argv,runtime=runtime))
 c.execute('bench',argv,env,d)
 docs=[json.loads(line) for line in (d/'bench.stdout.log').read_text().splitlines() if line.startswith('{')]
 assert len(docs)==1 and docs[0]['completed'] and docs[0]['captured'] and len(docs[0]['samples_us'])==512
 result=docs[0];rows.append(dict(arm=arm,result=result,image=image))
 assert result['capture_ranges_recorded']==1 and result['four_node_regions']==(18 if arm=='new' else 0)
 c.save(d/'observation.json',rows[-1])
for row in rows:
 for key in ('inputs_fnv1a64','outputs_fnv1a64','output_fnv1a64','output_sum'):
  assert row['result'][key]==rows[0]['result'][key],key
med={a:statistics.median(r['result']['submit_wait_us_median'] for r in rows if r['arm']==a) for a in ('old','new')}
summary=dict(passed=True,processes=rows,medians_us=med,ratio_new_over_old=med['new']/med['old'],
   profiler=False,compile_during_run=False,output_checksums_equal=True,
   limits='Synthetic fixed-normal18-suffix captured chunk, same bench.obj and original math. submit-wait CPU+GPU latency, not kernel-only timing or full-model throughput; checksums match, raw benchmark vectors not serialized.')
c.save(out/'summary.json',summary)
print('TYPED_GATING_BENCH',med,summary['ratio_new_over_old'],flush=True)
