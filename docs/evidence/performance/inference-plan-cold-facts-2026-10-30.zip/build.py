"""Refresh every retained PlanState consumer; retain unrelated SDK/CLI objects."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('runner',R/'.scratch/inference-program-identity-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
PREV=R/'.scratch/inference-continuation-warmth-20261030'

def prepare():
    old=read(PREV/'plan.json')
    base_path=R/'.scratch/inference-paired-m2-20261030/model-link-base.json';base=read(base_path)
    sdk=read(base['sdk_engine_dependencies']['path'])
    for x in [*old['retained'],old['runtime']]:exact(x)
    expected={key(x['path']) for x in old['retained']};units={}
    for row in sdk['inspected']:
        deps=read(row['dependencies']['path'])['Data']
        if not any(key(x)==key(R/'src/graph/plan_state.h') for x in deps['Includes']):continue
        obj=Path(row['object']);assert key(obj) in expected
        name=obj.parent.name;recipe=obj.parents[2]/'logs'/name/'command.json'
        args=read(recipe)['command'];folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
        command=[]
        for i,arg in enumerate(args):
            if i and args[i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            command.append(arg)
        assert sum(key(x)==key(deps['Source']) for x in command)==1
        units[name]=dict(source=deps['Source'],original=pin(obj),old_dependencies=row['dependencies'],recipe=pin(recipe),compile=command)
    assert len(units)==9
    direct={key(p) for folder in ['src/graph','src/graph_progress','src/graph_batch']
        for p in (R/folder).rglob('*.cc') if '#include "plan_state.h"' in p.read_text(encoding='utf-8') or
        '#include "../graph/plan_state.h"' in p.read_text(encoding='utf-8')}
    assert direct=={key(u['source']) for u in units.values()}
    consumers={}
    for name,receipt in [('cli',PREV/'compile/receipt.json'),
        ('natural',PREV/'finite-compile/natural/receipt.json'),('ordinary',PREV/'finite-compile/ordinary/receipt.json')]:
        unit=read(receipt);exact(unit['object'])
        for x in unit['source_identities']:exact(x)
        assert not any(key(x['path'])==key(R/'src/graph/plan_state.h') for x in unit['source_identities'])
        consumers[name]=dict(receipt=pin(receipt),object=unit['object'])
    (W/'bin').mkdir(exist_ok=True);shutil.copyfile(old['runtime']['path'],W/'bin'/Path(old['runtime']['path']).name)
    fixture=W/'ordinary-input';fixture.mkdir(exist_ok=True)
    finite=read(PREV/'finite-plan.json')
    for file in ('weights.tsv','prompt.ids'):
        shutil.copyfile(Path(finite['cases']['ordinary'][-1])/file,fixture/file)
    save(W/'plan.json',dict(base=pin(base_path),sdk=pin(base['sdk_engine_dependencies']['path']),
        units=units,retained=old['retained'],runtime=old['runtime'],consumers=consumers,
        original_link=old['original_link'],original_consumer=old['original_consumer'],
        args=old['args'],two_turn_args=old['two_turn_args'],
        cases={'natural':finite['cases']['natural'],'ordinary':[*finite['cases']['ordinary'][:-1],str(fixture)]},
        base_commit='994e06ade',dependency_scope='All nine direct PlanState CXX consumers match the retained compiler dependency records; CLI/natural/ordinary do not include private PlanState.',
        sdk_compiles=9,retained_unchanged=218,nvcc_compiles=0,downloads=0))
    shutil.copyfile(PREV/'source-plan-cold-facts.diff',W/'product.diff')
    print('Prepared9 affected CXX SDK units;218 SDK objects and3 consumers retained.')

def compile_unit(name,attempt):
    p=read(W/'plan.json');folder=W/'compile'/name;b.execute(p['units'][name]['compile'],folder/attempt,600)
    deps=read(folder/'dependencies.json')['Data']
    files=sorted({Path(x).resolve() for x in [deps['Source'],*deps['Includes']] if Path(x).is_relative_to(R)})
    assert R/'src/graph/plan_state.h' in files
    save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),source_identities=[pin(x) for x in files],
        dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json')))

def compile_all(attempt):
    p=read(W/'plan.json');errors=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures={pool.submit(compile_unit,name,attempt):name for name in p['units']}
        for future in as_completed(futures):
            name=futures[future]
            try:future.result()
            except BaseException as error:errors.append(dict(unit=name,error=str(error)))
    save(W/('compile-summary-'+attempt+'.json'),dict(units=9,max_concurrency=2,errors=errors))
    if errors:raise RuntimeError(errors)

def seal():
    p=read(W/'plan.json');replacements={}
    for name,unit in p['units'].items():
        receipt=read(W/'compile'/name/'receipt.json');exact(receipt['object'])
        for x in receipt['source_identities']:exact(x)
        replacements[key(unit['original']['path'])]=receipt['object']
    p['candidate_retained']=[replacements.get(key(x['path']),x) for x in p['retained']]
    assert len(p['candidate_retained'])==227
    sdk=read(p['sdk']['path'])
    for row in sdk['inspected']:
        if key(row['object']) in replacements:
            obj=replacements[key(row['object'])];row.update(object=obj['path'],dependencies=pin(Path(obj['path']).parent/'dependencies.json'))
    save(W/'sdk-engine-dependencies.json',sdk);p['candidate_sdk']=pin(W/'sdk-engine-dependencies.json')
    save(W/'plan.json',p);print('Sealed9 refreshed SDK inputs,218 unchanged.')

def link(name,attempt):
    p=read(W/'plan.json');mode='control' if name=='control' else 'candidate'
    items=p['retained'] if mode=='control' else p['candidate_retained']
    for x in items:exact(x)
    obj=p['consumers'][name if name in ('natural','ordinary') else 'cli']['object'];exact(obj)
    replacements={key(a['path']):b['path'] for a,b in zip(p['retained'],items)};args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']):arg=obj['path']
        elif key(arg) in replacements:arg=replacements[key(arg)]
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    assert sum(key(x)==key(obj['path']) for x in args)==1
    b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))

def run(name,attempt,scenario='single'):
    p=read(W/'plan.json');image=read(W/('ready-'+name+'.json'));exact(image)
    args=p['cases'][name] if name in p['cases'] else p['two_turn_args'] if scenario=='two-turn' else p['args']
    folder=W/'runs'/name/attempt
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    b.execute([image['path'],*args],folder,600);r=read(folder/'stdout.log')
    if name in p['cases']:assert r['status']=='PASS'
    else:assert r['generated_tokens']==(128 if scenario=='two-turn' else 64)
    save(folder/'report.json',r);print('PASS current SDK consumer',name)

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='compile-all':compile_all(sys.argv[2])
    elif action=='seal':seal()
    elif action=='compile':compile_unit(sys.argv[2],sys.argv[3])
    else:{'link':link,'run':run}[action](sys.argv[2],sys.argv[3])
