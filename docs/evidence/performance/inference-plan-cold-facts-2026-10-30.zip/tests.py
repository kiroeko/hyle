"""Existing real Source and four finite/reordered-plan checks, one refreshed SDK."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key

def prepare():
    recipe_path=R/'.scratch/inference-source-spans-20261028/refinement/recipes/output-source-test.json'
    recipe=read(recipe_path)['command'];units={}
    for name,source in [('source',R/'tests/graph/output_source_cuda_test.cc'),('executable',R/'tests/graph/executable_test.cc')]:
        folder=W/'test-compile'/name;folder.mkdir(parents=True,exist_ok=True);args=[]
        for i,arg in enumerate(recipe):
            if i and recipe[i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif arg.lower().endswith('.cc'):arg=str(source)
            args.append(arg)
        assert sum(key(x)==key(source) for x in args)==1
        units[name]=dict(source=str(source),compile=args)
    save(W/'test-plan.json',dict(recipe=pin(recipe_path),units=units,
        filters={'source':dict(filter='GraphOutputSourceCuda.*',tests=16),
        'executable':dict(filter='GraphVariants.FiniteExactFamilyRunsOnlyItsPreparedPoints:GraphVariants.FiniteExactConstantsAndBudgetsBelongToActualChildren:GraphCompile.SchedulesInterleavedIndependentBranchesIntoTwoQueuePrefixes:GraphCompile.MakesWorkspaceSerializationAnExplicitBudgetTradeoff',tests=4)}))
    print('Prepared2 test TUs;16 Source cases and4 finite/reorder cases.')

def compile_unit(name,attempt):
    p=read(W/'test-plan.json');folder=W/'test-compile'/name;b.b.execute(p['units'][name]['compile'],folder/attempt,600)
    deps=read(folder/'dependencies.json')['Data']
    files=sorted({Path(x).resolve() for x in [deps['Source'],*deps['Includes']] if Path(x).is_relative_to(R)})
    save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),source_identities=[pin(x) for x in files],
        dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json')))

def link(attempt):
    p=read(W/'plan.json');test=read(W/'test-plan.json');objects=[]
    for name in test['units']:
        obj=read(W/'test-compile'/name/'receipt.json')['object'];exact(obj);objects.append(obj['path'])
    for x in p['candidate_retained']:exact(x)
    replacements={key(a['path']):c['path'] for a,c in zip(p['retained'],p['candidate_retained'])};args=[]
    for arg in p['original_link']:
        if key(arg)==key(p['original_consumer']):args.extend(objects);continue
        if key(arg) in replacements:arg=replacements[key(arg)]
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/gtest').with_suffix(suffix));break
        args.append(arg)
    for name in ['gtest_main.lib','gtest.lib']:args.append(str(R/'.scratch/build-compute-v2-dev/lib'/name))
    b.b.execute(args,W/'test-link'/attempt,240);save(W/'ready-gtest.json',pin(W/'bin/gtest.exe'))

def run(name,attempt):
    p=read(W/'test-plan.json')['filters'][name];image=read(W/'ready-gtest.json');exact(image)
    folder=W/'test-runs'/name/attempt
    args=[image['path'],'--gtest_color=no','--gtest_filter='+p['filter'],'--gtest_fail_fast',
        '--gtest_output=xml:'+str(folder/'results.xml')]
    b.b.execute(args,folder,240)
    result=ET.parse(folder/'results.xml').getroot()
    assert int(result.get('tests'))==p['tests'] and result.get('failures')=='0' and result.get('errors','0')=='0'
    assert not result.findall('.//skipped')
    save(folder/'report.json',dict(status='PASS',tests=p['tests'],failures=0,skipped=0,
        cases=[dict(name=t.get('classname')+'.'+t.get('name'),seconds=t.get('time')) for t in result.findall('.//testcase')]))
    print('PASS',name,p['tests'],'actual tests;0 skipped.')

if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='link':link(sys.argv[2])
    else:{'compile':compile_unit,'run':run}[action](sys.argv[2],sys.argv[3])
