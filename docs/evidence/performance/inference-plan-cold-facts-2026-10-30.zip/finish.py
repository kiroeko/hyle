"""Retain the current SDK link base and a compact index of sealed native results."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare_retention():
    p = read(W / 'plan.json')
    base = read(p['base']['path'])
    replacements = {key(a['path']): c['path'] for a, c in zip(p['retained'], p['candidate_retained'])}
    for item in p['candidate_retained']:
        exact(item)
    base['schema'] = 'hyle.plan-cold-facts.current-link-base.v1'
    base['base'] = p['base']
    base['retained'] = p['candidate_retained']
    base['link'] = [replacements.get(key(arg), arg) for arg in base['link']]
    assert len(base['retained']) == 227
    assert all(key(x['path']) in {key(a) for a in base['link']} for x in base['retained'])
    base['sdk_engine_dependencies'] = p['candidate_sdk']
    base['current_consumers'] = p['consumers']
    base['note'] = 'Current227 SDK inputs: nine refreshed PlanState consumers,218 unchanged. Replace the original consumer placeholder when linking; current CLI/natural/ordinary receipts are explicit.'
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    assert len(targets) == 16
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    print('Retained current227 SDK link inputs;16 exact reconstructable images/import artifacts for test.ps1 cleanup.')


def finish():
    a = read(W / 'analysis.json')
    window = read(W / 'peer-window/summary.json')
    assert a['frozen'] and a['non_time_comparison']['all_abba_and_correctness_equal_to_current_control_and_994e_warm_anchor']
    assert a['non_time_comparison']['all_finite_equal_to_994e_warm_baselines']
    assert a['gtests']['tests'] == 20 and a['gtests']['failures'] == 0 and a['gtests']['skipped'] == 0
    assert window['status'] == 'COMPLETE32_FOUR_ARMS_STABLE'
    process_files = [*W.glob('runs/*/*/process.json'), *W.glob('test-runs/*/*/process.json')]
    processes = [read(path) for path in process_files]
    assert len(processes) == 9, len(processes)
    assert all(p['state'] == 'TERMINAL' and p['exit'] == 0 and not p.get('timed_out') for p in processes)
    window_processes = [row['process'] for f in (W / 'peer-window').glob('*/runs.json') for row in read(f)]
    assert len(window_processes) == 32
    assert all(p['exit'] == 0 and not p['reader_errors'] for p in window_processes)
    starts = [p['started_unix_ns'] / 1e9 for p in window_processes]
    ends = [p['finished_unix_ns'] / 1e9 for p in window_processes]
    table = []
    for row in window['table']:
        t, m = row['timing'], row['independent_memory']
        table.append(dict(scenario=row['scenario'], arm=row['arm'],
            prefill_TPS=t['prefill_tokens_per_second'], decode_TPS=t['full_decode_tokens_per_second'],
            combined_output_TPS=t['session_output_tokens_per_second'],
            sampled_peaks=m['sampled_peaks']))
    finite = [dict(name=x['name'], status='PASS', work=x['work'],
        complete_report_equal_to_994e=x['all_recursive_non_time_fields_equal_to_994e_baseline'],
        report=x['artifacts']['report.json'], scope=x['scope']) for x in a['finite_consumers']]
    diff = subprocess.check_output(['git', 'diff', '--', 'src/graph/plan_state.h',
        'src/graph/executable.cc', 'src/graph/resources.cc', 'tests/graph/output_source_cuda_test.cc'], cwd=R)
    (W / 'delivery.diff').write_bytes(diff)
    p = read(W / 'plan.json')
    value = dict(schema='hyle.performance.plan-cold-facts.v1', date='2026-10-30',
        status='IMPLEMENTED_FINITE_CHECKS_AND_CURRENT32_WINDOW', base_commit=p['base_commit'],
        implementation=dict(description='Recompute two immutable selected-artifact facts on each successful cold build_segments; replace only repeated planned scans. Actual Source authority, Queue/bindings, captured ranges and native retirement remain dynamic.',
            sources=[pin(R / x) for x in ('src/graph/plan_state.h', 'src/graph/executable.cc',
                'src/graph/resources.cc', 'tests/graph/output_source_cuda_test.cc')],
            diff=pin(W / 'delivery.diff'), SDK_CXX_compiles=9, unchanged_SDK_objects=218,
            NVCC_compiles=0, test_CXX_compiles=2, retained_consumer_objects=3, downloads=0,
            current_link_base=pin(W / 'model-link-base.json'), compiler_dependency_inventory=p['candidate_sdk']),
        checks=dict(gtests=a['gtests'], finite_consumers=finite,
            complete_non_time_comparison=a['non_time_comparison'], original_analysis=pin(W / 'analysis.json'),
            scope='16 real CUDA Source cases and4 existing finite/reordered/workspace cases. Extended pending Managed Commands rejection and actual captured reuse; not an exhaustive cross-child cache flag test.'),
        direct_ABBA=dict(order=a['abba_order'], samples_per_arm=2,
            summaries=a['abba_summary'], interpretation=a['abba_interpretation'],
            original_samples_in_archive=True),
        current_peer_window=dict(processes=32, timing_processes=24, independent_memory_processes=8,
            started_unix=min(starts), ended_unix=max(ends), table=table,
            protocol=pin(W / 'peer-window/plan.json'), binding=pin(W / 'peer-window/binding.json'),
            full_summary=pin(W / 'peer-window/summary.json'), limits=window['limits'],
            independent_offline_review=pin(W / 'window-analysis.json'),
            frozen_peer_not_latest_upstream=True, first_cross_engine_output_difference_1based=19,
            actual_work_and_complete_outputs_in_archive=True,
            causal_scope='This refresh includes preceding994e warmth retention. Current SDK-only A/B is approximately+0.044% with overlapping ranges, so no current-slice speedup is established.'),
        research=dict(provider_naming_audit=pin(W / 'provider-naming-audit.json')),
        cleanup=dict(script=pin(R / 'test.ps1'), manifest=pin(W / 'cleanup-targets.json'), result=read(W / 'cleanup-report.json')),
        limits=['Only immutable plan topology is cached; no Source identity, live permission, lease generation or real capture success is cached.',
            'Not a complete constant-time prepare implementation and not a whole architecture/MTP completion claim.',
            'Finite natural consumer checks complete serial/auto state and ledger; ordinary fixture is synthetic, not trained-model EOS or injected native GPU failure.',
            'No new Nsight, CPU/Apple/Vulkan or larger-model native runs; no model/download traffic.',
            'The vendor provider name denotes implementation provenance. Admission is operation/format/device-based, not a model allowlist; no rename/provider-identity churn was made.'],
        evidence_archive='inference-plan-cold-facts-2026-10-30.zip')
    out = R / 'docs/evidence/performance/inference-plan-cold-facts-2026-10-30.json'
    save(out, value)
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix in ('.json', '.py', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
        z.write(R / 'test.ps1', 'cleanup-script.ps1')
        z.write(out, 'delivery.json')
    print('Saved compact index', out.stat().st_size, 'bytes; archive', out.with_suffix('.zip').stat().st_size, 'bytes')


if __name__ == '__main__':
    {'prepare-retention': prepare_retention, 'finish': finish}[sys.argv[1]]()
