"""Prepare a frozen one-Graph-TU diagnostic candidate; never compiles/runs it."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess
W=Path(__file__).resolve().parent
R=W.parent.parent.parent
P=R/'.scratch/inference-current-review-profile-20261027'
G=R/'.scratch/inference-identical-capture-inputs-20261027'

def read(p):return json.loads(p.read_bytes())
def save(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def one(text,old,new):
    assert text.count(old)==1,(old[:100],text.count(old))
    return text.replace(old,new,1)
def tokens(b):
    text=b.decode('utf-8-sig')
    pattern=r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
    text=re.sub(pattern,lambda m:' ' if m[0].startswith(('//','/*')) else m[0],text)
    return re.findall(r'[A-Za-z_]\w*|\d+|[^\s]',text)

def main():
    base=G/'source/src/graph/executable.cc'
    assert pin(base)['sha256']=='f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f'
    original=base.read_bytes();newline=b'\r\n' if b'\r\n' in original else b'\n'
    old=original.decode().replace('\r\n','\n');text=old
    text=one(text,'namespace hyle::graph {','''// Scratch diagnostic: exact external declaration of the W13 Model's inline
// unsigned long long. The retained Model OBJ defines this same MSVC symbol.
#include <cstdio>
namespace logical_trace { extern unsigned long long sequence; }
namespace hyle::graph {''')
    anchor='''  return port == variant.bindings.size();
}

void remember_capture_key'''
    text=one(text,anchor,'''  return port == variant.bindings.size();
}

#include "capture_mismatch_diag.h"

void remember_capture_key''')
    marker='''      selected_variant = saved->variants[0].key_valid
'''
    text=one(text,marker,'''      // Observe both immutable keys BEFORE selecting/evicting a variant.
      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);
'''+marker)
    marker='''    // Reuse-only must never reach a recording/fallback path, independently of
'''
    text=one(text,marker,'''    if (!reuse_only && (saved == nullptr || !saved->preserves_private_arguments))
      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);
'''+marker)
    begin=text.index('void invalidate_recording(detail::InvocationState &invocation,\n                          std::uint32_t selected_step,\n                          CaptureInvalidation mode) noexcept {')
    end=text.index('\n} // namespace\n\nvoid detail::invalidate_step_recording',begin)
    block=text[begin:end]
    marker='''  auto &binding = invocation.step_bindings[selected_step];
'''
    block=one(block,marker,marker+'''  const auto diag_revision = binding.revision;
  const auto diag_prepared_revision = binding.prepared_revision;
''')
    block=one(block,'        discard_capture_variants(saved);','''        capture_mismatch_diag::note_key_loss(invocation, selected_step,
            static_cast<unsigned>(mode), saved, diag_revision, diag_prepared_revision);
        discard_capture_variants(saved);''')
    block=one(block,'        discard_capture_variants(*saved);','''        capture_mismatch_diag::note_key_loss(invocation, selected_step,
            static_cast<unsigned>(mode), *saved, diag_revision, diag_prepared_revision);
        discard_capture_variants(*saved);''')
    text=text[:begin]+block+text[end:]
    # Deleting only the exact additions must mechanically recover all base code.
    inverse=text
    inverse=one(inverse,'''// Scratch diagnostic: exact external declaration of the W13 Model's inline
// unsigned long long. The retained Model OBJ defines this same MSVC symbol.
#include <cstdio>
namespace logical_trace { extern unsigned long long sequence; }
namespace hyle::graph {''','namespace hyle::graph {')
    for addition in ('#include "capture_mismatch_diag.h"\n\n',
        '''      // Observe both immutable keys BEFORE selecting/evicting a variant.
      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);
''',
        '''    if (!reuse_only && (saved == nullptr || !saved->preserves_private_arguments))
      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);
''',
        '''  const auto diag_revision = binding.revision;
  const auto diag_prepared_revision = binding.prepared_revision;
'''):
        inverse=one(inverse,addition,'')
    for ending in ('saved','*saved'):
        addition=f'''        capture_mismatch_diag::note_key_loss(invocation, selected_step,
            static_cast<unsigned>(mode), {ending}, diag_revision, diag_prepared_revision);
'''
        inverse=one(inverse,addition,'')
    assert inverse==old
    target=W/'source/src/graph/executable.cc';target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(text.replace('\n',newline.decode()).encode())
    header=W/'source/src/graph/capture_mismatch_diag.h';header.write_bytes((W/'capture_mismatch_diag.h').read_bytes())
    patch='\n'.join(difflib.unified_diff(old.splitlines(),text.splitlines(),fromfile='a/src/graph/executable.cc',tofile='b/src/graph/executable.cc',lineterm=''))+'\n'
    patch+='\n'.join(difflib.unified_diff([],header.read_text().splitlines(),fromfile='/dev/null',tofile='b/src/graph/capture_mismatch_diag.h',lineterm=''))+'\n'
    (W/'candidate.diff').write_bytes(patch.encode())
    # Freeze only actual project dependencies of this exact Graph object.
    dependencies=read(G/'compile/executable/actual-dependencies.json');project=[];exceptions=[]
    for dep in dependencies:
        source=Path(dep['path'])
        try:rel=source.relative_to(R)
        except ValueError:continue
        if not rel.parts or rel.parts[0] not in ('src','include','engine'):continue
        if rel.as_posix()=='src/graph/executable.cc':continue
        body=subprocess.check_output(['git','show','2fe2916cf:'+rel.as_posix()],cwd=R)
        actual=hashlib.sha256(body).hexdigest()
        if actual!=dep['sha256']:
            # Only this known comment-only change may reuse the old ABI.
            assert rel.as_posix()=='include/hyle/graph/detail/output_source.h',rel
            old_body=subprocess.check_output(['git','show','5582ed347:'+rel.as_posix()],cwd=R)
            assert hashlib.sha256(old_body).hexdigest()==dep['sha256']
            assert tokens(old_body)==tokens(body)
            exceptions.append(dict(path=str(rel),old=dep['sha256'],frozen=actual,proof='comment-stripped token sequence identical'))
        out=W/'source'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(body)
        project.append(dict(original=dep,frozen=pin(out)))
    # The sole extern declaration is byte/type checked against the frozen Model
    # header AND its actual retained object, not a guessed new main symbol.
    logical=P/'source/logical_trace.h'
    assert 'inline unsigned long long sequence = 0' in logical.read_text()
    compiler=Path(read(G/'logs/executable/command.json')['command'][0])
    dumpbin=compiler.with_name('dumpbin.exe')
    symbols=subprocess.check_output([str(dumpbin),'/symbols',str(P/'hyle/compile/unit.obj')],text=True)
    symbol=[line for line in symbols.splitlines() if '?sequence@logical_trace@@3_KA' in line]
    assert len(symbol)==1 and 'External' in symbol[0] and 'UNDEF' not in symbol[0]
    (W/'logical-sequence-symbol.txt').write_bytes(('\n'.join(symbol)+'\n').encode())
    compile_command=read(G/'logs/executable/command.json')['command']
    compile_command=[x.replace(str(base),str(target)) for x in compile_command]
    compile_out=W/'compile/executable';compile_out.mkdir(parents=True,exist_ok=True)
    for i,arg in enumerate(compile_command):
        if arg.lower()=='/sourcedependencies':compile_command[i+1]=str(compile_out/'dependencies.json')
        elif arg.startswith('/Fo'):compile_command[i]='/Fo'+str(compile_out/'unit.obj')
        elif arg.startswith('/Fd'):compile_command[i]='/Fd'+str(compile_out/'unit.pdb')
    compile_command[1:1]=['/I'+str(W/'source/include'),'/I'+str(W/'source/src/graph')]
    assert str(target) in compile_command
    link_command=read(P/'hyle/logs/link/command.json')['command']
    old_object=read(G/'compile/executable/compiled.json')['object']
    assert link_command.count(old_object['path'])==1
    link_command=[str(compile_out/'unit.obj') if x==old_object['path'] else x for x in link_command]
    image=W/'bin/hyle.exe';image.parent.mkdir(exist_ok=True)
    for i,arg in enumerate(link_command):
        if arg.upper().startswith('/OUT:'):link_command[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):link_command[i]='/PDB:'+str(W/'bin/hyle.pdb')
        elif arg.upper().startswith('/IMPLIB:'):link_command[i]='/IMPLIB:'+str(W/'bin/hyle.lib')
    argv=next(x['consumer'] for x in read(P/'run-plan2.json')['commands'] if x['name']=='mtp-hyle').copy();argv[0]=str(image)
    save(W/'plan.json',dict(status='PREPARED_NOT_COMPILED_NOT_RUN',base=pin(base),candidate=pin(target),diagnostic_header=pin(header),patch=pin(W/'candidate.diff'),
        compatible_Model=read(P/'ready-hyle.json')['object'],compatible_declaration='namespace logical_trace { extern unsigned long long sequence; }; exact frozen inline definition and defined External ?sequence@logical_trace@@3_KA verified by dumpbin',
        defined_symbol=pin(W/'logical-sequence-symbol.txt'),project_dependencies=project,comment_only_reuse_exceptions=exceptions,
        original_dependency_manifest=pin(G/'compile/executable/actual-dependencies.json'),
        original_Model_actual_dependencies=read(P/'ready-hyle.json')['actual_dependencies'],
        additional_standard_header='cstdio; resolve using the same locked MSVC includes; actualIncludes must be pre-pinned against the union of these two original manifests before any later compile',
        compile_command=compile_command,link_command=link_command,original_Graph_object=old_object,
        unchanged_closure=pin(P/'ready-hyle.json'),environment=pin(P/'build-plan.json'),
        costs=dict(CXX=1,link=1,SDK=0,NVCC=0,models=0),future_MTP_command=argv,
        oracle=dict(report=pin(P/'runs/mtp-hyle/report.json'),parser=pin(P/'analyze.py'),rule='Reuse original analyze.non_time over COMPLETE MTP report, excluding only original time keys; do not skip captures/metadata/IDs/ledger. Same arguments, runtime and frozen Model/remaining objects. Require no dropped diagnostics and one event per actual necessary recording decision.'),
        protocol=['Single control thread, R1 greedy MTP only; fixed64 record/16 range buffers, explicit overflow counters, no locks or ownership changes.',
            'At most two first-mismatch snapshots per necessary recording decision; no diagnostic scans on successful reuse and no per-kernel log.',
            'Key-loss hooks only record before original variant discard; they never preserve authority or change algorithm/status/branch decisions.',
            'Destructor emits one stderr JSON after the run; all stored facts are copied descriptors and numeric identities, no borrowed value/lease/producer references.',
            'Not yet compiled. Recheck actualIncludes against frozen header/toolchain manifests and reject byte drift except the recorded comment-only case. No automatic execution.']))
    print('PREPARED',pin(target),len(project),'project headers; no CXX/GPU')

if __name__=='__main__':main()
