"""Explicit one-CXX / one-link / one-model actions. Never retries."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys
import traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]

def read(path): return json.loads(Path(path).read_bytes())
def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as out: out.write(json.dumps(value, indent=2) + '\n')
def key(path): return str(path).replace('/', '\\').casefold()
def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while body := stream.read(1 << 20): digest.update(body)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value

def validate(plan):
    for name in ('W17_ready', 'W17_link_inputs', 'unchanged_runtime', 'candidate', 'diagnostic_header',
                 'prepare_script', 'offline_comparator', 'action_script', 'compile_environment', 'link_environment',
                 'expected_compile_dependencies', 'model_manifest', 'prompt_ids'):
        exact(plan[name])
    exact(plan['W17_Model']['snapshot'])
    ready = read(plan['W17_ready']['path'])
    assert ready['compiled'] == plan['W17_Model'] and ready['image'] == plan['W17_image']
    assert ready['inputs'] == plan['W17_link_inputs']
    return ready

def environment(plan):
    value = dict(os.environ)
    value.update(read(plan['compile_environment']['path']))
    value.update(read(plan['link_environment']['path']))
    runtime = read(plan['unchanged_runtime']['path'])
    value['PATH'] = str(W/'bin') + ';' + runtime['PATH']
    for name in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'): value[name] = '1'
    return value

def executor():
    # Existing locked runner writes raw command/process/stdout/stderr and raises
    # on the first actual timeout/nonzero exit. Import does not start a process.
    helper = module('current_diag_retained_w17_tools', R/'.scratch/inference-wave-recovery-final-20261027/check.py')
    return helper.b.h.execute

def compile_graph(plan):
    validate(plan)
    assert not (W/'compile/unit.obj').exists() and not (W/'logs/compile').exists(), 'Preserve the first CXX attempt'
    allowed = read(plan['expected_compile_dependencies']['path'])
    for row in allowed: exact(row)
    save(W/'compile-preflight.json', dict(status='FROZEN_DEPENDENCIES_VERIFIED', count=len(allowed),
        candidate=plan['candidate'], header=plan['diagnostic_header'], allowed_manifest=plan['expected_compile_dependencies']))
    process = executor()(plan['compile_command'], environment(plan), W/'logs/compile', timeout=240)
    data = read(W/'compile/dependencies.json')['Data']
    assert key(data['Source']) == key(plan['candidate']['path'])
    lookup = {key(x['path']): x for x in allowed}; actual = []
    for path in dict.fromkeys([data['Source'], *data['Includes']]):
        assert key(path) in lookup, ('Unexpected live-source or SDK include', path)
        row = pin(path); expected = lookup[key(path)]
        assert (row['bytes'], row['sha256']) == (expected['bytes'], expected['sha256']), path
        actual.append(row)
    save(W/'compile/actual-dependencies.json', actual)
    validate(plan)
    save(W/'compile/compiled.json', dict(source=plan['candidate'], diagnostic_header=plan['diagnostic_header'],
        object=pin(W/'compile/unit.obj'), process=process, command=pin(W/'logs/compile/command.json'),
        actual_dependencies=pin(W/'compile/actual-dependencies.json'), compiler_dependencies=pin(W/'compile/dependencies.json')))
    print('CXX_PASS one Graph TU; no Model or NVCC build')

def link_graph(plan):
    validate(plan); compiled = read(W/'compile/compiled.json')
    exact(compiled['object']); exact(compiled['actual_dependencies'])
    assert not (W/'link').exists() and not (W/'bin/hyle.exe').exists(), 'Preserve the first link attempt'
    old = plan['base_Graph']['object']; inputs = read(plan['W17_link_inputs']['path'])
    assert len(inputs) == 224 and inputs.count(old) == 1 and inputs.count(plan['W17_Model']['object']) == 1
    replacement = [compiled['object'] if x == old else x for x in inputs]
    assert len(replacement) == 224 and sum(x != y for x, y in zip(inputs, replacement)) == 1
    for row in replacement: exact(row)
    save(W/'link-inputs.json', replacement)
    process = executor()(plan['link_command'], environment(plan), W/'link', timeout=180)
    save(W/'ready.json', dict(status='LINKED_NOT_RUN', image=pin(W/'bin/hyle.exe'), compiled=compiled,
        unchanged_Model=plan['W17_Model']['object'], inputs=pin(W/'link-inputs.json'), runtime=plan['unchanged_runtime'],
        plan=pin(W/'plan.json'), link=process))
    print('LINK_PASS original224 with only Graph object replaced')

def run_model(plan):
    validate(plan); ready = read(W/'ready.json')
    exact(ready['image']); exact(ready['inputs']); exact(ready['plan'])
    runtime = read(plan['unchanged_runtime']['path'])
    if 'original_native_cpu' in runtime: exact(runtime['original_native_cpu'])
    assert not (W/'run').exists(), 'One diagnostic model process only; never retry'
    argv = plan['future_MTP_command']
    assert key(argv[0]) == key(ready['image']['path']) and argv[argv.index('--mtp')+1] == 'on'
    process = executor()(argv, environment(plan), W/'run', timeout=300)
    save(W/'model-process.json', process)
    offline = module('current_mtp_capture_offline_compare', plan['offline_comparator']['path'])
    offline.main(W/'run')
    save(W/'complete.json', dict(status='DIAGNOSTIC_COMPLETE', process=process,
        image=ready['image'], comparison=pin(W/'run/complete-non-time-differences.json'),
        capture_analysis=pin(W/'run/capture-analysis.json'), performance_claim=False))
    print('RUN_COMPLETE one current W17 MTP process; no timing claim')

if __name__ == '__main__':
    try:
        action = sys.argv[1]; plan = read(W/'plan.json')
        if action == 'compile': compile_graph(plan)
        elif action == 'link': link_graph(plan)
        elif action == 'run': run_model(plan)
        else: raise ValueError('Use compile | link | run; actions are explicit and separate')
    except BaseException as error:
        text = traceback.format_exc(); print(text, file=sys.stderr)
        path = W/((sys.argv[1] if len(sys.argv) > 1 else 'arguments')+'-action-error.json')
        if not path.exists(): save(path, dict(error_type=type(error).__name__, message=str(error), traceback=text,
            note='Original command/process/stdout/stderr are retained when a process started. No automatic retry.'))
        raise SystemExit(1)
