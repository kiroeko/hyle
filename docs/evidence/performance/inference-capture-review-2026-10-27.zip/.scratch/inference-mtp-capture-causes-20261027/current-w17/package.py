"""Offline evidence only. No compiler, linker, model, network or GPU action.

Reproduction uses the retained SDK/model and 224-input closure named by plan.
The package carries receipts rather than copying those dependencies/binaries.
Original compare.py intentionally still reproduces its schema-alias failure;
normalize-offline.py and attribute-offline.py are the additive correction.
"""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[2]
H = R / '.scratch/inference-continuous-wave-window-20261027'
O = R / 'docs/evidence/performance/inference-capture-review-2026-10-27'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def exact(row):
    value = pin(row['path'])
    assert value['bytes'] == row['bytes'] and value['sha256'] == row['sha256'], row['path']
    return value


def write(path, value):
    Path(path).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


def non_time(value):
    # Exact original W13 analyze.py predicate. No capture/work/metadata filter.
    if isinstance(value, list):
        return [non_time(item) for item in value]
    if isinstance(value, dict):
        return {key: non_time(item) for key, item in value.items() if not any(
            word in key for word in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value


def main():
    plan, ready = read(W / 'plan.json'), read(W / 'ready.json')
    compiled = read(W / 'compile/compiled.json')
    process = read(W / 'run/process.json')
    attributed = read(W / 'run/capture-attribution-offline.json')
    normalized = read(W / 'run/complete-non-time-normalized-offline.json')
    failed = read(W / 'run/complete-non-time-differences.json')
    review = read(H / 'recording-facts-review.json')
    assert compiled['process']['exit'] == ready['link']['exit'] == process['exit'] == 0
    assert process == read(W / 'model-process.json') == attributed['actual_process']
    assert process['pid'] == 53184
    amendment = read(W / 'metadata-amendment.json')
    original_plan = exact(amendment['reconstructed_original_plan'])
    assert original_plan['bytes'] == ready['plan']['bytes'] and original_plan['sha256'] == ready['plan']['sha256']
    exact(amendment['amended_plan']); exact(amendment['amended_comparator'])
    for row in [plan['candidate'], plan['diagnostic_header'], plan['patch'],
                compiled['command'], compiled['actual_dependencies'], compiled['compiler_dependencies'],
                plan['W17_Model']['snapshot'], plan['W17_ready'], plan['W17_link_inputs'],
                plan['unchanged_runtime'], plan['report_oracle']['report'],
                plan['report_oracle']['non_time_parser']]:
        exact(row)
    assert compiled == ready['compiled']
    assert ready['unchanged_Model'] == plan['W17_Model']['object']
    old, current = read(plan['W17_link_inputs']['path']), read(W / 'link-inputs.json')
    assert len(old) == len(current) == 224
    assert [(a, b) for a, b in zip(old, current) if a != b] == [
        (plan['base_Graph']['object'], compiled['object'])]
    exact(ready['inputs'])
    raw = read(W / 'run/consumer-result.json')
    final = read(W / 'run/consumer-result-normalized-offline.json')
    oracle = read(plan['report_oracle']['report']['path'])
    command = read(W / 'run/command.json')['command']
    assert len(raw['sessions']) == 1 and raw['mtp'] and raw['decode_overlap'] is False
    assert command[command.index('--decode-overlap') + 1] == 'off'
    assert final['generated_ids'] == raw['sessions'][0]['result']['generated_ids']
    assert len(final['generated_ids']) == 64 and len(final['rounds']) == 34
    assert non_time(final) == non_time(oracle)
    assert normalized['equal'] and not normalized['differences']
    assert not failed['equal'] and len(failed['differences']) == 14
    exact(normalized['original_failed_comparison'])
    exact(normalized['unchanged_raw_producer'])
    assert review['processes_checked'] == 40
    exact(review['input_archive'])
    counts = attributed['counts']
    assert counts['record_decisions'] == 11 and counts['cold_record_decisions'] == 2
    assert counts['mismatch_record_decisions'] == 9
    assert counts['prior_hidden_first_mismatches'] == 12 and counts['carry_hidden_first_mismatches'] == 4
    assert all(counts[k] == 0 for k in ('dropped_records', 'dropped_ranges',
        'unconfirmed_events', 'explicit_key_loss_events'))
    diagnostic_lines = [line.removeprefix('CAPTURE_MISMATCH_DIAG ') for line in
        (W / 'run/stderr.log').read_text(encoding='utf-8-sig').splitlines()
        if line.startswith('CAPTURE_MISMATCH_DIAG ')]
    assert len(diagnostic_lines) == 1
    assert json.loads(diagnostic_lines[0]) == read(W / 'run/capture-mismatch.json')

    # Only this finite diagnostic, its original receipts, and small offline
    # dependencies. SDK/model/binary contents and older trace databases stay out.
    allowed = {'.py', '.json', '.cc', '.h', '.diff', '.log'}
    excluded = {'package-manifest.json', 'package-result.json', 'evidence-summary.json'}
    paths = {p.resolve() for p in W.rglob('*') if p.is_file() and
        p.suffix.lower() in allowed and p.name not in excluded and '__pycache__' not in p.parts}
    extra = [H / 'recording-facts-review.json', H / 'review_recording_facts.py',
        H / 'plan.json', H / 'binding.json', H / 'ready.json', H / 'peer-ready.json',
        Path(plan['project_header_overlay_reused_from']['path']),
        W.parent / 'diagnostic/prepare.py', W.parent / 'diagnostic/capture_mismatch_diag.h',
        Path(plan['base_Graph']['snapshot']['path']), Path(plan['base_Graph']['command']['path']),
        Path(plan['base_Graph']['compiler_dependencies']['path']),
        Path(plan['base_Graph']['actual_dependencies']['path']),
        Path(plan['W17_Model']['snapshot']['path']), Path(plan['W17_Model']['command']['path']),
        Path(plan['W17_Model']['compiler_dependencies']['path']),
        Path(plan['W17_Model']['actual_dependencies']['path']),
        Path(plan['W17_ready']['path']), Path(plan['W17_link_inputs']['path']),
        Path(plan['unchanged_runtime']['path']), Path(plan['compile_environment']['path']),
        Path(plan['link_environment']['path']), Path(plan['model_manifest']['path']),
        Path(plan['prompt_ids']['path']), Path(plan['report_oracle']['report']['path']),
        Path(plan['report_oracle']['non_time_parser']['path']), Path(normalized['adapter_source']['path'])]
    paths.update(p.resolve() for p in extra)
    assert all(p.is_file() and p.is_relative_to(R) for p in paths)
    manifest = [dict(member=p.relative_to(R).as_posix(), **pin(p)) for p in sorted(paths)]
    write(W / 'package-manifest.json', dict(files=manifest,
        closure='224 inputs; only Graph OBJ replaced, all binary contents omitted',
        dependency_policy='Actual compiler dependency manifests retained. Existing project overlay, SDK, runtime and model are referenced by original pins, not duplicated.'))
    summary = dict(
        schema='hyle.inference.capture-review.v1',
        status='OFFLINE_REVIEW_AND_ONE_INSTRUMENTED_MTP_PROCESS',
        scope='Archived Model3 40-process review plus one later W17 Model diagnostic. Different historical scopes; no new controlled performance comparison.',
        costs=dict(Graph_CXX=1, links=1, model_processes=1, Model_CXX=0, NVCC=0,
            SDK_builds=0, downloads=0, model_retries=0),
        historical_40_process_archive=review['input_archive'],
        recording_review=pin(H / 'recording-facts-review.json'),
        frozen_diagnostic=dict(link_plan=original_plan, post_link_analysis_plan=pin(W / 'plan.json'),
            metadata_amendment=pin(W / 'metadata-amendment.json'), ready=pin(W / 'ready.json'),
            reused_Model_source=plan['W17_Model']['snapshot'],
            reused_Model_object=plan['W17_Model']['object'],
            Graph_source=compiled['source'], Graph_header=compiled['diagnostic_header'],
            image=ready['image'], retained_link_inputs=224, replacements='Only original Graph executable OBJ'),
        actual_process=dict(**process, prompt_rows=154, output_ids=64, decode_output_ids=63,
            target_rounds=34, capacity=1024, R=1, sampling='greedy', MTP_K=1, decode_overlap='off'),
        observed_capture_counts=counts,
        attribution=[
            'Two cold decisions and nine later record decisions. Every retained valid variant in those later decisions has a proven hidden-input physical-offset mismatch.',
            'Sixteen first mismatches: twelve prior_hidden, four carry_hidden; same resource/native backing, BF16 [1,2048] and 4096-byte extent, offsets differ.',
            'No explicit capture-key loss observed; zero dropped records/ranges and no unconfirmed role/prepare associations.',
            'Only the first mismatch per valid variant was recorded; other ports, including GDN/KV, may also differ and are not excluded.'],
        offline_comparator=dict(first_result='FAILED: 14 missing top-level schema aliases; original raw and traceback retained',
            normalized_result='PASS: complete original non-time predicate; zero remaining differences',
            normalization='Existing sole-session result adapter copies missing aliases; no extra field deletion or model retry',
            oracle_scope=plan['report_oracle']['source'],
            receipt=pin(W / 'run/complete-non-time-normalized-offline.json')),
        preparation_failure='First preparation assertion failed with 0 compiler/model processes; original script and receipt retained.',
        metadata_drift='After model launch, offline prepared-association comparison was tightened and its two plan pin fields updated. Exact original link-plan bytes are reconstructed and match the original ready SHA. Both versions, chronology and first packaging rejection are retained; compiled source/header pins are unchanged.',
        boundaries=[
            'Review count/role signatures are verified in all 40 archived reports. Warm-eight is not eight recordings; ordinary A/B step lifetimes overlap and their sum is not elapsed decode wall time.',
            'Removing recordings, multiplying count by average preparation time, or predicting peer parity remain unmeasured estimates.',
            'One instrumented MTP process has no uninstrumented control, speed, quality, or peer performance claim. Historical report equality is semantic reproduction only.',
            'This package supplies no numerical validation of the concurrent native graph-scheduler prototype; source review and compilation are not a numerical pass.',
            'No model, SDK, OBJ, EXE, DLL, PDB, LIB, EXP, trace database or historical 40-process ZIP is copied. Existing manifest pins identify retained dependencies.'])
    write(W / 'evidence-summary.json', summary)
    archive = O.with_suffix('.zip')
    assert not archive.exists() and not O.with_suffix('.json').exists(), 'Do not replace a prior evidence release'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in manifest:
            z.write(row['path'], row['member'])
        for p in (W / 'package-manifest.json', W / 'evidence-summary.json'):
            z.write(p, p.relative_to(R).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(manifest) + 2
        assert not any(Path(name).suffix.lower() in {'.obj', '.exe', '.dll', '.pdb', '.lib', '.exp', '.sqlite', '.nsys-rep'} for name in z.namelist())
        for row in manifest:
            body = z.read(row['member'])
            assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
        assert json.loads(z.read((W / 'evidence-summary.json').relative_to(R).as_posix())) == summary
    summary['archive'] = dict(**pin(archive), files=len(manifest) + 2,
        uncompressed_bytes=sum(row['bytes'] for row in manifest))
    summary['manifest'] = pin(W / 'package-manifest.json')
    write(O.with_suffix('.json'), summary)
    assert read(O.with_suffix('.json')) == summary
    result = dict(status='PACKED_AND_READ_BACK_VERIFIED', receipt=pin(O.with_suffix('.json')),
        archive=summary['archive'], new_compiler_or_model_processes=0)
    write(W / 'package-result.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
