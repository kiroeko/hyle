// Scratch-only. Included inside executable.cc's existing anonymous namespace,
// after capture_key_matches. No lease, payload, observer or execution changes.
namespace capture_mismatch_diag {
constexpr std::size_t kMaxRecords = 64, kMaxRanges = 16;
struct TensorFact final {
  bool exists = false, valid = false;
  compute::TensorDesc description{};
  std::uintptr_t resource = 0, native = 0;
  std::size_t offset = 0, extent = 0;
};
struct Difference final {
  // 0=no difference,1=no key,2=missing saved port,3=physical tuple differs,
  // 4=extra saved ports,5=commands absent. No capability is inferred here.
  unsigned reason = 0;
  std::size_t step = 0, port = 0, flat_port = 0;
  std::uint32_t instance = UINT32_MAX, logical_value = UINT32_MAX;
  bool output = false;
  unsigned field_mask = 0; // valid1,description2,resource4,native8,offset16,extent32
  TensorFact old_value{}, new_value{};
};
struct Invalidation final {
  unsigned long long seq = 0;
  std::size_t step = 0;
  unsigned mode = 0;
  std::uint64_t revision = 0, prepared_revision = 0;
  bool stable = false, native_inputs = false;
  bool qualification = false, preserves = false, active_commands = false;
  bool key0 = false, key1 = false;
  std::uint32_t failed_step = UINT32_MAX;
  unsigned stability_reason = 0; // 1=identity,2=native-input,3=region-ownership
};
struct RangeState final {
  const detail::InvocationState *invocation = nullptr;
  std::uint32_t begin = 0, count = 0;
  std::size_t key_losses = 0;
  Invalidation last_key_loss{};
};
struct Variant final {
  bool commands = false, key_valid = false;
  std::size_t saved_ports = 0;
  Difference first{};
};
struct Record final {
  unsigned long long seq = 0;
  const detail::InvocationState *invocation = nullptr;
  std::uint32_t begin = 0, count = 0;
  bool saved = false, qualification = false, preserves = false;
  unsigned active_variant = 2, last_used = 0;
  std::size_t key_losses_since_previous_record = 0;
  Invalidation last_key_loss{};
  Variant variants[2]{};
};
inline unsigned long long sequence = 0;
inline RangeState ranges[kMaxRanges]{};
inline Record records[kMaxRecords]{};
inline std::size_t range_count = 0, record_count = 0, dropped_ranges = 0,
                   dropped_records = 0;

RangeState *range_state(const detail::InvocationState &invocation,
                       std::uint32_t begin, std::uint32_t count) noexcept {
  for (std::size_t i = 0; i < range_count; ++i)
    if (ranges[i].invocation == &invocation && ranges[i].begin == begin &&
        ranges[i].count == count) return &ranges[i];
  if (range_count == kMaxRanges) { ++dropped_ranges; return nullptr; }
  auto &entry = ranges[range_count++];
  entry.invocation = &invocation; entry.begin = begin; entry.count = count;
  return &entry;
}

TensorFact snapshot(compute::ConstTensorView value, bool exists = true) noexcept {
  const auto storage = value.storage();
  const auto resource = storage.resource();
  return {exists, value.valid(), value.description(),
      reinterpret_cast<std::uintptr_t>(resource.valid() ? &resource.resource() : nullptr),
      reinterpret_cast<std::uintptr_t>(storage.native_handle()),
      storage.offset(), storage.size()};
}

void note_key_loss(const detail::InvocationState &invocation,
                   std::uint32_t step, unsigned mode,
                   const detail::CaptureRebuildRange &saved,
                   std::uint64_t previous_revision,
                   std::uint64_t previous_prepared_revision) noexcept {
  bool active_commands = false;
  for (const auto &range : invocation.captured_ranges)
    active_commands = active_commands || (range.step_begin == saved.step_begin &&
        range.step_count == saved.step_count && range.commands.valid());
  // Clearing an already empty key is not the cause of losing a real capture.
  if (!saved.variants[0].key_valid && !saved.variants[1].key_valid && !active_commands) return;
  auto *entry = range_state(invocation, saved.step_begin, saved.step_count);
  if (!entry) return;
  const auto &binding = invocation.step_bindings[step];
  // The same invalidation can visit dormant keys and the active range. Its
  // original bounded-run revision identifies one authority loss, not two.
  if (entry->key_losses && entry->last_key_loss.step == step && entry->last_key_loss.mode == mode &&
      entry->last_key_loss.revision == previous_revision &&
      entry->last_key_loss.prepared_revision == previous_prepared_revision) return;
  ++entry->key_losses;
  entry->last_key_loss = {++sequence, step, mode,
      previous_revision, previous_prepared_revision,
      binding.stable_binding_identity, binding.native_inputs};
  auto &loss = entry->last_key_loss;
  loss.qualification = saved.qualification_valid; loss.preserves = saved.preserves_private_arguments;
  loss.active_commands = active_commands; loss.key0 = saved.variants[0].key_valid; loss.key1 = saved.variants[1].key_valid;
  if (mode == 1) for (std::uint32_t at = saved.step_begin; at < saved.step_begin + saved.step_count; ++at) {
    const auto &planned = invocation.plan->steps[at];
    if (!planned.emits_command()) continue;
    const auto &cached = invocation.step_bindings[at];
    const unsigned reason = !cached.stable_binding_identity ? 1u : cached.native_inputs ? 2u :
        (planned.region.valid() && !detail::RegionAccess::borrows_tensor_views_only(planned.region)) ? 3u : 0u;
    if (reason) { loss.failed_step = at; loss.stability_reason = reason; break; }
  }
}

Difference first_difference(const detail::InvocationState &invocation,
                            const detail::CaptureRebuildRange &saved,
                            const detail::CaptureBindingVariant &variant) noexcept {
  Difference difference;
  if (!variant.key_valid) { difference.reason = 1; return difference; }
  std::size_t flat = 0;
  for (std::size_t index = saved.step_begin;
       index < std::size_t{saved.step_begin} + saved.step_count; ++index) {
    const auto &step = invocation.plan->steps[index];
    if (!step.emits_command()) continue;
    for (unsigned output = 0; output < 2; ++output) {
      const auto count = output ? step.output_count : step.input_count;
      for (std::size_t port = 0; port < count; ++port, ++flat) {
        const auto current = output
            ? invocation.submission_outputs[step.output_begin + port].as_const()
            : invocation.submission_inputs[step.input_begin + port];
        if (flat < variant.bindings.size() &&
            same_physical_tensor(variant.bindings[flat], current)) continue;
        difference.reason = flat == variant.bindings.size() ? 2u : 3u;
        difference.step = index; difference.port = port;
        difference.flat_port = flat; difference.output = output != 0;
        difference.instance = output
            ? invocation.plan->node_outputs[step.output_begin + port]
            : invocation.plan->node_inputs[step.input_begin + port];
        if (difference.instance < invocation.plan->instance_values.size())
          difference.logical_value = invocation.plan->instance_values[difference.instance];
        if (flat < variant.bindings.size())
          difference.old_value = snapshot(variant.bindings[flat]);
        difference.new_value = snapshot(current);
        const auto &a = difference.old_value; const auto &b = difference.new_value;
        difference.field_mask = (a.valid != b.valid ? 1u : 0u) | (a.description != b.description ? 2u : 0u) |
            (a.resource != b.resource ? 4u : 0u) | (a.native != b.native ? 8u : 0u) |
            (a.offset != b.offset ? 16u : 0u) | (a.extent != b.extent ? 32u : 0u);
        return difference;
      }
    }
  }
  if (flat != variant.bindings.size()) {
    difference.reason = 4; difference.flat_port = flat;
  } else if (!variant.commands.valid()) difference.reason = 5;
  return difference;
}

void note_record(const detail::InvocationState &invocation,
                 const detail::CaptureRebuildRange *saved,
                 std::uint32_t begin, std::uint32_t count) noexcept {
  if (record_count == kMaxRecords) { ++dropped_records; return; }
  auto &event = records[record_count++];
  event.seq = ++sequence; event.invocation = &invocation;
  event.begin = begin; event.count = count; event.saved = saved != nullptr;
  if (auto *state = range_state(invocation, begin, count)) {
    event.key_losses_since_previous_record = state->key_losses;
    event.last_key_loss = state->key_losses ? state->last_key_loss : Invalidation{}; state->key_losses = 0;
  }
  // The original single-owner Model already writes role/episode before prepare.
  // This finite marker associates the exit-only details with that exact call;
  // its sequence is diagnostic-local, never a claimed Model submission ordinal.
  std::fprintf(stderr, "CAPTURE_RECORD_EVENT seq=%llu invocation=%llu range=%u,%u\n",
      event.seq, static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(&invocation)), begin, count);
  if (!saved) return;
  event.qualification = saved->qualification_valid;
  event.preserves = saved->preserves_private_arguments;
  event.active_variant = saved->active_variant; event.last_used = saved->last_used;
  for (unsigned i = 0; i < 2; ++i) {
    const auto &value = saved->variants[i];
    event.variants[i] = {value.commands.valid(), value.key_valid,
        value.bindings.size(), first_difference(invocation, *saved, value)};
  }
}

void print_tensor(const TensorFact &value) noexcept {
  const auto &desc = value.description;
  const auto &format = desc.storage_format(); const auto id = format.id();
  std::fprintf(stderr, "{\"exists\":%u,\"valid\":%u,\"resource\":%llu,\"native\":%llu,\"offset\":%zu,\"extent\":%zu,\"desc\":{\"valid\":%u,\"type\":%u,\"rank\":%zu,\"block_axis\":",
      unsigned(value.exists), unsigned(value.valid),
      static_cast<unsigned long long>(value.resource),
      static_cast<unsigned long long>(value.native),value.offset,value.extent,
      unsigned(desc.valid()),unsigned(desc.data_type()),desc.rank());
  if (const auto axis=desc.block_axis()) std::fprintf(stderr,"%zu",*axis);
  else std::fputs("null",stderr);
  std::fprintf(stderr,",\"format\":[%u,%llu,%llu,%zu,%zu,%zu],\"dimensions\":[",
      unsigned(format.kind()),static_cast<unsigned long long>(id.namespace_id),
      static_cast<unsigned long long>(id.format_id),format.elements_per_block(),
      format.bytes_per_block(),format.required_alignment());
  for (std::size_t i=0;i<desc.rank();++i)
    std::fprintf(stderr,"%s%lld",i?",":"",static_cast<long long>(desc.dimensions()[i]));
  std::fputs("],\"strides\":[",stderr);
  const auto strides=desc.byte_strides();
  for (std::size_t i=0;i<strides.size();++i)
    std::fprintf(stderr,"%s%lld",i?",":"",static_cast<long long>(strides[i]));
  std::fputs("],\"required_bytes\":",stderr);
  const auto bytes=desc.required_bytes();
  if(bytes)std::fprintf(stderr,"%zu",*bytes);else std::fputs("null",stderr);
  // Object bytes preserve fields without public getters, including opaque
  // bytes. Padding is explicitly nonsemantic; never compare this hex as a key.
  std::fputs(",\"object_hex_padding_nonsemantic\":\"",stderr);
  const auto *raw=reinterpret_cast<const unsigned char *>(&desc);
  for(std::size_t i=0;i<sizeof(desc);++i)std::fprintf(stderr,"%02x",unsigned(raw[i]));
  std::fputs("\"}}",stderr);
}

void dump() noexcept {
  std::fprintf(stderr,"CAPTURE_MISMATCH_DIAG {\"records\":%zu,\"dropped_records\":%zu,\"dropped_ranges\":%zu,\"events\":[",record_count,dropped_records,dropped_ranges);
  for(std::size_t n=0;n<record_count;++n){
    const auto&e=records[n]; const auto&loss=e.last_key_loss;
    std::fprintf(stderr,"%s{\"seq\":%llu,\"invocation\":%llu,\"range\":[%u,%u],\"saved\":%u,\"qualification\":%u,\"preserves\":%u,\"active\":%u,\"last_used\":%u,\"key_losses\":%zu,\"last_key_loss\":{\"seq\":%llu,\"step\":%zu,\"mode\":%u,\"revision\":%llu,\"prepared_revision\":%llu,\"stable\":%u,\"native_inputs\":%u},",
        n?",":"",e.seq,static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(e.invocation)),e.begin,e.count,unsigned(e.saved),unsigned(e.qualification),unsigned(e.preserves),e.active_variant,e.last_used,e.key_losses_since_previous_record,
        loss.seq,loss.step,loss.mode,static_cast<unsigned long long>(loss.revision),static_cast<unsigned long long>(loss.prepared_revision),unsigned(loss.stable),unsigned(loss.native_inputs));
    constexpr const char *modes[]{"discard", "stable_bindings", "native_arguments", "keep_existing_seed"};
    std::fprintf(stderr,"\"invalidation_detail\":{\"mode_name\":\"%s\",\"qualification\":%u,\"preserves\":%u,\"active_commands\":%u,\"keys\":[%u,%u],\"failed_step\":%u,\"stability_reason\":%u},",
        loss.mode < 4 ? modes[loss.mode] : "unknown", unsigned(loss.qualification),unsigned(loss.preserves),unsigned(loss.active_commands),
        unsigned(loss.key0),unsigned(loss.key1),loss.failed_step,loss.stability_reason);
    std::fputs("\"variants\":[",stderr);
    for(unsigned i=0;i<2;++i){
      const auto&v=e.variants[i]; const auto&d=v.first;
      std::fprintf(stderr,"%s{\"index\":%u,\"commands\":%u,\"key_valid\":%u,\"ports\":%zu,\"reason\":%u,\"step\":%zu,\"port\":%zu,\"output\":%u,\"flat_port\":%zu,\"instance\":%u,\"logical_value\":%u,",
          i?",":"",i,unsigned(v.commands),unsigned(v.key_valid),v.saved_ports,d.reason,d.step,d.port,unsigned(d.output),d.flat_port,d.instance,d.logical_value);
      std::fprintf(stderr,"\"field_mask\":%u,\"has_port\":%u,\"old\":",d.field_mask,unsigned(d.reason==2 || d.reason==3));
      print_tensor(d.old_value);std::fputs(",\"new\":",stderr);print_tensor(d.new_value);std::fputc('}',stderr);
    }
    std::fputs("]}",stderr);
  }
  std::fputs("]}\n",stderr);
}
struct DumpAtExit final { ~DumpAtExit(){dump();} };
inline DumpAtExit dump_at_exit{};
} // namespace capture_mismatch_diag
