"""Offline schema correction only; retain the original failed comparison intact."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]

def read(p): return json.loads(Path(p).read_bytes())
def write(p, value): Path(p).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def pin(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())

plan = read(W / 'plan.json')
spec = importlib.util.spec_from_file_location('original_capture_comparison', W / 'compare.py')
original = importlib.util.module_from_spec(spec); spec.loader.exec_module(original)
spec = importlib.util.spec_from_file_location('retained_complete_non_time', plan['report_oracle']['non_time_parser']['path'])
oracle = importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
folder = W / 'run'
raw = read(folder / 'consumer-result.json')
assert len(raw['sessions']) == 1
# Identical statements to retained baseline/window.py:35-45 normalize().
detail = raw['sessions'][0]['result']; normalized = dict(raw)
for key, val in detail.items():
    if key not in normalized: normalized[key] = val
if 'consumed_drafts' in normalized: normalized['accepted_drafts'] = normalized['consumed_drafts']
if not normalized['mtp']:
    assert normalized['mtp_tensors'] == 0 and normalized['draft_program_graph_calls'] == 0
    normalized.setdefault('actual_draft_rows', 0)
    normalized.setdefault('draft_rows', 0)
    normalized.setdefault('prefill_draft_rows', 0)
write(folder / 'consumer-result-normalized-offline.json', normalized)
changes = original.differences(oracle.non_time(read(plan['report_oracle']['report']['path'])), oracle.non_time(normalized))
write(folder / 'complete-non-time-normalized-offline.json', dict(
    equal=not changes, differences=changes,
    original_failed_comparison=pin(folder / 'complete-non-time-differences.json'),
    unchanged_raw_producer=pin(folder / 'consumer-result.json'),
    normalized_producer=pin(folder / 'consumer-result-normalized-offline.json'),
    adapter_source=pin(R / '.scratch/mtp-performance-convergence-20261025/baseline/window.py'),
    copied_missing_top_level_keys=sorted(set(normalized) - set(raw)),
    oracle=plan['report_oracle'],
    schema_operations=['Copy missing top-level fields from original sole sessions[0].result',
        'Retained consumed_drafts to accepted_drafts spelling',
        'Retained ordinary-only absent draft row counters, not applicable for this MTP run'],
    ignored_fields='Exactly original retained non_time predicate; no additional field deletion',
    model_rerun=False, performance_claim=False, quality_claim=False))
print(json.dumps(dict(equal=not changes, differences=len(changes),
    original_differences=len(read(folder / 'complete-non-time-differences.json')['differences']),
    copied_keys=sorted(set(normalized) - set(raw)))))
assert not changes, 'Keep real remaining differences without rerunning a model'
