"""Read-only postprocessing of the one recorded MTP process; no model action."""
from pathlib import Path
from collections import Counter
import hashlib
import json
W = Path(__file__).resolve().parent
R = W.parents[2]
def read(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
analysis = read(W / 'run/capture-analysis.json')
raw = read(W / 'run/capture-mismatch.json')
normalized = read(W / 'run/complete-non-time-normalized-offline.json')
assert normalized['equal'] and not normalized['differences']
events = []
counts = Counter()
for event in analysis['events']:
    assert event['key_losses'] == 0
    assert event['qualification'] == event['preserves'] == 1
    assert event['association']['prepare_confirmed']
    source = event['association']
    item = dict(seq=event['seq'], role=source['batch']['role'],
        role_name={3:'kMtpRound', 4:'kMtpCatchupRound'}[source['batch']['role']],
        episode=source['batch']['episode'], visible=source['prepared']['visible'],
        invocation=event['invocation'], range=event['range'], key_losses=0,
        reason='Both cold variant slots have no key' if all(not v['key_valid'] for v in event['variants'])
            else 'Every retained valid variant fails physical tensor equality; other slots, if any, have no key',
        variants=[])
    for v in event['variants']:
        if not v['has_port']:
            assert v['reason'] == 1 and not v['key_valid']
            counts['missing_key_variants'] += 1
            item['variants'].append(dict(index=v['index'], reason='no_saved_key', port_unknown=True))
            continue
        assert v['reason'] == 3 and v['field_mask'] == 16 and not v['output']
        assert v['logical_value'] in (4, 5)
        before, after = v['old'], v['new']
        assert before['resource'] == after['resource'] == 4676951933056
        assert before['native'] == after['native'] == 85651850240
        assert before['extent'] == after['extent'] == 4096
        assert before['desc'] == after['desc']
        name = {4:'carry_hidden',5:'prior_hidden'}[v['logical_value']]
        counts[name+'_first_mismatches'] += 1
        item['variants'].append(dict(index=v['index'], reason='physical_offset_changed',
            step=v['step'], input_port=v['port'], logical_value=v['logical_value'],
            model_binding=name, resource=before['resource'], native=before['native'],
            old_offset=before['offset'], new_offset=after['offset'], extent=before['extent'],
            type='BF16', dimensions=[1,2048], field_mask=16))
    counts['cold_record_decisions' if all(not v['key_valid'] for v in event['variants']) else 'mismatch_record_decisions'] += 1
    events.append(item)
model = R / '.scratch/inference-wave-recovery-final-20261027/source/model/engine/models/qwen35/main.cc'
value = dict(
    status='ONE_ACTUAL_CURRENT_W17_MTP_PROCESS_OFFLINE_ATTRIBUTION',
    actual_process=read(W / 'run/process.json'),
    normalized_complete_historical_Model3_non_time_equal=True,
    normalization_receipt=pin(W / 'run/complete-non-time-normalized-offline.json'),
    original_raw_analysis_unchanged=pin(W / 'run/capture-analysis.json'),
    original_failed_comparison_unchanged=pin(W / 'run/complete-non-time-differences.json'),
    source_model=pin(model), source_graph_diagnostic=pin(W / 'source/src/graph/capture_mismatch_diag.h'),
    source_facts=[
        dict(path=str(model), lines=[2235,2238,2241,2246,2272,2275], fact='For these R1 greedy MTP families: token logical0, position1, metadata2, frequency constant3, carry input4, optional lagged prior input5. No batched last_ids or sampling identity input applies.'),
        dict(path=str(model), lines=[3898,3899,3900,3902], fact='prepare_draft_append binds logical4 from member.base->carry_hidden and logical5 from member.base->prior_hidden when draft_lag(role)=1.'),
        dict(path=str(model), lines=[4675,4677,4678], fact='Published hidden boundary retains last accepted row as carry; a multirow accepted verification also retains the preceding row as prior.'),
        dict(path=str(model), lines=[2140,2141,2143,2152], fact='Hidden canonical states have an original fixed backing LeasePool; identity and offset remain part of each actual read lease.'),
        dict(path=str(W / 'source/src/graph/capture_mismatch_diag.h'), lines=[115,119,133,153,166,167], fact='Diagnostic records only the first physical mismatch per valid variant; cold keys have no port, and last_key_loss is explicitly zeroed when no actual loss was observed.')],
    counts=dict(record_decisions=raw['records'], dropped_records=raw['dropped_records'],
        dropped_ranges=raw['dropped_ranges'], unconfirmed_events=len(analysis['unconfirmed_event_sequences']),
        explicit_key_loss_events=sum(e['key_losses'] for e in analysis['events']), **dict(counts)),
    events=events,
    conclusions=[
        'Two cold initial captures plus nine later necessary records are observed; every later record has a proven carry/prior physical-offset mismatch against every currently valid variant.',
        'The sixteen first mismatches are twelve prior_hidden and four carry_hidden. All retain identical resource, native backing, BF16 [1,2048] description and 4096-byte extent; only offsets 0/4096/8192/12288 vary.',
        'No explicit capture-key invalidation was observed between these records. last_key_loss seq0 and mode_name discard are empty default fields, not evidence of a discard invalidation.',
        'The first proven blocker is hidden boundary address selection, not a GDN or draft-KV append port. Since only first mismatch is retained, later mismatches in those or other ports are neither excluded nor proven.',
        'Identical full historical non-time facts establish semantic reproduction for this finite run after the existing schema adapter; historical oracle is not a current performance control.'],
    limits=[
        'One instrumented process; no speed, quality or current uninstrumented control claim.',
        'Two retained physical-key variants miss the observed tuples. Simply adding variants or fixing one port has no proven net speed/memory benefit and could uncover further port mismatches.',
        'Stable backing alone is insufficient for replay: current physical key correctly includes offset. Discarding offset/lease identity without equivalent native argument and retirement guarantees would be unsound.',
        'The original complete raw producer report and first failed comparison are retained; this is additive offline interpretation without a model rerun.'])
out = W / 'run/capture-attribution-offline.json'
out.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(counts=value['counts'], output=str(out))))
