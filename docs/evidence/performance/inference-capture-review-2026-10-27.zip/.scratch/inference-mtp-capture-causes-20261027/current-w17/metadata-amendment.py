"""Preserve both metadata versions without changing an original receipt/run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

W = Path(__file__).resolve().parent


def pin(path):
    path = Path(path).resolve(); body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    current_compare = (W / 'compare.py').read_bytes()
    new = b"prepare_confirmed=batch is not None and associations[seq]['batch'] == batch,"
    old = b'prepare_confirmed=batch is not None,'
    assert current_compare.count(new) == 1
    original_compare = current_compare.replace(new, old, 1)
    original_plan = json.loads((W / 'plan.json').read_bytes())
    original_plan['offline_comparator']['bytes'] = len(original_compare)
    original_plan['offline_comparator']['sha256'] = hashlib.sha256(original_compare).hexdigest()
    body = (json.dumps(original_plan, indent=2) + '\n').replace('\n', '\r\n').encode()
    ready = json.loads((W / 'ready.json').read_bytes())
    assert len(body) == ready['plan']['bytes']
    assert hashlib.sha256(body).hexdigest() == ready['plan']['sha256']
    for name, payload in [('compare-at-link.py', original_compare), ('plan-at-link.json', body)]:
        path = W / name
        assert not path.exists(), 'Never overwrite the original reconstruction'
        path.write_bytes(payload)
    receipt = dict(
        status='EXACT_ORIGINAL_PLAN_RECONSTRUCTED',
        original_link_plan=ready['plan'],
        reconstructed_original_plan=pin(W / 'plan-at-link.json'),
        reconstructed_original_comparator=pin(W / 'compare-at-link.py'),
        amended_plan=pin(W / 'plan.json'), amended_comparator=pin(W / 'compare.py'),
        exact_change=dict(old=old.decode(), new=new.decode(),
            plan_fields=['offline_comparator.bytes', 'offline_comparator.sha256']),
        ordering_evidence=[dict(path=str(W / name),
            file_mtime_utc=datetime.fromtimestamp((W / name).stat().st_mtime, timezone.utc).isoformat())
            for name in ['logs/compile/process.json', 'ready.json', 'run/running.json', 'compare.py', 'plan.json', 'run/process.json']],
        explanation='The comparator association check and its plan pin were tightened after linking and after model launch. Preserve this metadata drift; do not claim all metadata was frozen before execution.',
        source_status='Compiled Graph source/header and actual-dependency pins are unchanged; the comparator is not a compiler input. Full original plan hash is recovered exactly.',
        model_rerun=False, original_files_overwritten=False)
    path = W / 'metadata-amendment.json'
    assert not path.exists()
    path.write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
    print(json.dumps(dict(status=receipt['status'], original_plan=receipt['reconstructed_original_plan'])))


if __name__ == '__main__':
    main()
