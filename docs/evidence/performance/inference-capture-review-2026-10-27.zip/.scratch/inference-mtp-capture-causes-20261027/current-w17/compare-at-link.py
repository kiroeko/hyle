"""Offline only: complete producer facts plus bounded capture diagnostics."""
from pathlib import Path
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent

def read(path): return json.loads(Path(path).read_bytes())
def save(path, value): Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def differences(a, b, path='$'):
    if type(a) is not type(b): return [dict(path=path, expected=a, actual=b)]
    if isinstance(a, dict):
        out = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b: out.append(dict(path=path+'.'+key, expected=a.get(key), actual=b.get(key)))
            else: out += differences(a[key], b[key], path+'.'+key)
        return out
    if isinstance(a, list):
        if len(a) != len(b): return [dict(path=path, expected=a, actual=b)]
        return [d for n, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, f'{path}[{n}]')]
    return [] if a == b else [dict(path=path, expected=a, actual=b)]

def main(folder):
    folder = Path(folder).resolve(); plan = read(W / 'plan.json')
    process_path = folder / 'process.json'
    if not process_path.exists(): process_path = folder / 'result.json'
    process = read(process_path)
    code = process.get('exit', process.get('exit_code'))
    assert code == 0, 'Preserve the actual failed process; no model rerun'
    stdout = (folder / 'stdout.log').read_text(encoding='utf-8-sig')
    rows = [x for x in stdout.splitlines() if x.startswith('{"source_id":')]
    assert len(rows) == 1, 'Original stdout producer schema was lost or duplicated'
    report = json.loads(rows[0]); save(folder / 'consumer-result.json', report)
    spec = importlib.util.spec_from_file_location('retained_complete_non_time', plan['report_oracle']['non_time_parser']['path'])
    oracle = importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
    changes = differences(oracle.non_time(read(plan['report_oracle']['report']['path'])), oracle.non_time(report))
    save(folder / 'complete-non-time-differences.json', dict(equal=not changes, differences=changes,
        oracle=plan['report_oracle'], ignored_fields='Only the retained non_time time-key predicate; no additional ignored model/mode/capture facts.'))
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8-sig')
    dumps = [x.removeprefix('CAPTURE_MISMATCH_DIAG ') for x in stderr.splitlines() if x.startswith('CAPTURE_MISMATCH_DIAG ')]
    assert len(dumps) == 1, 'Missing/duplicate capture diagnostic dump; do not infer a port'
    diagnostic = json.loads(dumps[0]); save(folder / 'capture-mismatch.json', diagnostic)
    assert diagnostic['dropped_records'] == diagnostic['dropped_ranges'] == 0, 'Bounded diagnostics overflowed; facts remain incomplete'
    events = {x['seq']: x for x in diagnostic['events']}
    assert len(events) == diagnostic['records'] == len(diagnostic['events'])
    pending = []; associations = {}; batch = None; episode = None
    for line in stderr.splitlines():
        m = re.match(r'generation_session .* turn=(\d+) episode=(\d+)$', line)
        if m: episode = dict(turn=int(m[1]), episode=int(m[2]))
        m = re.match(r'generation_batch requests=(\d+) T=(\d+) role=(\d+) full_hit=(\d+)$', line)
        if m:
            batch = dict(requests=int(m[1]), rows=int(m[2]), role=int(m[3]), full_hit=int(m[4]), **(episode or {}))
        m = re.match(r'CAPTURE_RECORD_EVENT seq=(\d+) invocation=(\d+) range=(\d+),(\d+)$', line)
        if m:
            seq, invocation, begin, count = map(int, m.groups())
            assert seq in events and events[seq]['invocation'] == invocation and events[seq]['range'] == [begin, count]
            assert seq not in associations
            associations[seq] = dict(event_seq=seq, batch=batch, prepare_confirmed=False)
            pending.append(seq)
        m = re.match(r'prepared T=(\d+) visible=(\d+).*capture_recorded=(\d+) capture_reused=(\d+)$', line)
        if m:
            for seq in pending:
                associations[seq].update(prepare_confirmed=batch is not None,
                    prepared=dict(rows=int(m[1]), visible=int(m[2]), capture_recorded=int(m[3]), capture_reused=int(m[4])))
            pending.clear(); batch = None
    assert set(associations) == set(events), 'A necessary-record event lacks its exact stderr marker'
    missing_ports = []
    for event in diagnostic['events']:
        event['association'] = associations[event['seq']]
        for variant in event['variants']:
            if not variant['has_port']:
                missing_ports.append(dict(event_seq=event['seq'], variant=variant['index'], reason=variant['reason'],
                    explanation='No physical port mismatch is proven for a missing/invalid key, extra saved ports or absent commands. Preserve the explicit invalidation/private-qualification facts.'))
    save(folder / 'capture-analysis.json', dict(status='COMPLETE_FACTS_EQUAL' if not changes else 'COMPLETE_FACTS_DIFFER',
        historical_Model3_non_time_equal=not changes, current_W17_Model_unchanged=True, record_decisions=diagnostic['records'],
        events=diagnostic['events'], missing_port_facts=missing_ports,
        unconfirmed_event_sequences=[seq for seq, x in associations.items() if not x['prepare_confirmed']],
        field_mask=dict(valid=1, description=2, resource=4, native=8, offset=16, extent=32),
        invalidation_mode=dict(discard=0, stable_bindings=1, native_arguments=2, keep_existing_seed=3),
        stable_proof_reason=dict(identity_not_proven=1, native_input_arguments=2, region_owns_more_than_tensor_views=3),
        quality_claim=False, performance_claim=False,
        limits=['One instrumented current Model/Graph process, no current uninstrumented timing control.',
            'Only first differing physical port per retained variant is copied; no claim that it is the only changed port.',
            'Diagnostic-local event sequence is not a Model/native submission ordinal. Role mapping requires the retained original batch/prepare markers; unconfirmed mappings remain unknown.',
            'A cold/missing key has no proven first port; never infer port0/carry/prior/draftKV from default fields. Private proof flags are not a private-allocation identity dump.']))
    assert not changes, 'Preserved complete non-time producer-report differences; do not delete metadata or rerun'
    print('Complete historical non-time producer facts equal; bounded capture evidence retained; no speed/quality claim.')

if __name__ == '__main__': main(sys.argv[1])
