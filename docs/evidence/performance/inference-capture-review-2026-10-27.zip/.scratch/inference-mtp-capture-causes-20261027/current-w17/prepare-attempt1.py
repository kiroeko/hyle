"""One Graph-TU diagnostic preparation; no compiler/linker/model execution."""
from pathlib import Path
import difflib
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[2]
OLD = W.parent / 'diagnostic'
GRAPH = R / '.scratch/inference-identical-capture-inputs-20261027'
MODEL = R / '.scratch/inference-wave-recovery-final-20261027'

def read(path): return json.loads(Path(path).read_bytes())
def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def one(text, old, new):
    assert text.count(old) == 1, (old[:90], text.count(old))
    return text.replace(old, new, 1)

def main():
    assert not (W / 'plan.json').exists(), 'Preserve the previous preparation'
    old_plan = read(OLD / 'plan.json')
    ready = read(MODEL / 'ready-model.json')
    assert ready['image']['sha256'] == 'aa8647242ee68049e4bab0c4409638f11949c5f48de1c7b95b2ba1bd50f08983'
    assert ready['compiled']['snapshot']['sha256'] == '441ff48649cef90205d97f4fbbf71cdd73a4f06b1fdd9d85cbd4fd3ff64fffd3'
    graph = read(GRAPH / 'compile/executable/compiled.json')
    assert graph['source']['sha256'] == 'f160c92d3d369de9b469b0976ae4a42a1928f6c4265f13345c2cbff1d1010e6f'
    inputs = read(ready['inputs']['path'])
    assert inputs.count(graph['object']) == 1 and inputs.count(ready['compiled']['object']) == 1
    assert pin(old_plan['base']['path']) == old_plan['base']
    assert pin(old_plan['candidate']['path']) == old_plan['candidate']
    base = Path(old_plan['base']['path']).read_bytes()
    newline = '\r\n' if b'\r\n' in base else '\n'
    original = base.decode().replace('\r\n', '\n')
    candidate = Path(old_plan['candidate']['path']).read_text(encoding='utf-8')
    candidate = one(candidate, '''// Scratch diagnostic: exact external declaration of the W13 Model's inline
// unsigned long long. The retained Model OBJ defines this same MSVC symbol.
#include <cstdio>
namespace logical_trace { extern unsigned long long sequence; }
namespace hyle::graph {''', '''// Scratch-only diagnostics. No Model symbol, ABI or execution hook.
#include <cstdio>
namespace hyle::graph {''')
    assert 'logical_trace' not in candidate
    header = (OLD / 'capture_mismatch_diag.h').read_text(encoding='utf-8')
    header = header.replace('::logical_trace::sequence', '++sequence')
    header = one(header, 'inline RangeState ranges[kMaxRanges]{};',
        'inline unsigned long long sequence = 0;\ninline RangeState ranges[kMaxRanges]{};')
    header = one(header, '  TensorFact old_value{}, new_value{};',
        '  unsigned field_mask = 0; // valid1,description2,resource4,native8,offset16,extent32\n  TensorFact old_value{}, new_value{};')
    header = one(header, '  bool stable = false, native_inputs = false;', '''  bool stable = false, native_inputs = false;
  bool qualification = false, preserves = false, active_commands = false;
  bool key0 = false, key1 = false;
  std::uint32_t failed_step = UINT32_MAX;
  unsigned stability_reason = 0; // 1=identity,2=native-input,3=region-ownership''')
    header = one(header, '''  auto *entry = range_state(invocation, saved.step_begin, saved.step_count);
  if (!entry) return;
  const auto &binding = invocation.step_bindings[step];''', '''  bool active_commands = false;
  for (const auto &range : invocation.captured_ranges)
    active_commands = active_commands || (range.step_begin == saved.step_begin &&
        range.step_count == saved.step_count && range.commands.valid());
  // Clearing an already empty key is not the cause of losing a real capture.
  if (!saved.variants[0].key_valid && !saved.variants[1].key_valid && !active_commands) return;
  auto *entry = range_state(invocation, saved.step_begin, saved.step_count);
  if (!entry) return;
  const auto &binding = invocation.step_bindings[step];''')
    header = one(header, '''      binding.stable_binding_identity, binding.native_inputs};
}''', '''      binding.stable_binding_identity, binding.native_inputs};
  auto &loss = entry->last_key_loss;
  loss.qualification = saved.qualification_valid; loss.preserves = saved.preserves_private_arguments;
  loss.active_commands = active_commands; loss.key0 = saved.variants[0].key_valid; loss.key1 = saved.variants[1].key_valid;
  if (mode == 1) for (std::uint32_t at = saved.step_begin; at < saved.step_begin + saved.step_count; ++at) {
    const auto &planned = invocation.plan->steps[at];
    if (!planned.emits_command()) continue;
    const auto &cached = invocation.step_bindings[at];
    const unsigned reason = !cached.stable_binding_identity ? 1u : cached.native_inputs ? 2u :
        (planned.region.valid() && !detail::RegionAccess::borrows_tensor_views_only(planned.region)) ? 3u : 0u;
    if (reason) { loss.failed_step = at; loss.stability_reason = reason; break; }
  }
}''')
    header = one(header, '''        difference.new_value = snapshot(current);
        return difference;''', '''        difference.new_value = snapshot(current);
        const auto &a = difference.old_value; const auto &b = difference.new_value;
        difference.field_mask = (a.valid != b.valid ? 1u : 0u) | (a.description != b.description ? 2u : 0u) |
            (a.resource != b.resource ? 4u : 0u) | (a.native != b.native ? 8u : 0u) |
            (a.offset != b.offset ? 16u : 0u) | (a.extent != b.extent ? 32u : 0u);
        return difference;''')
    header = one(header, '''  if (!saved) return;
  event.qualification''', '''  // The original single-owner Model already writes role/episode before prepare.
  // This finite marker associates the exit-only details with that exact call;
  // its sequence is diagnostic-local, never a claimed Model submission ordinal.
  std::fprintf(stderr, "CAPTURE_RECORD_EVENT seq=%llu invocation=%llu range=%u,%u\\n",
      event.seq, static_cast<unsigned long long>(reinterpret_cast<std::uintptr_t>(&invocation)), begin, count);
  if (!saved) return;
  event.qualification''')
    marker = '    for(unsigned i=0;i<2;++i){\n'
    extra = '''    constexpr const char *modes[]{"discard", "stable_bindings", "native_arguments", "keep_existing_seed"};
    std::fprintf(stderr,"\\\"invalidation_detail\\\":{\\\"mode_name\\\":\\\"%s\\\",\\\"qualification\\\":%u,\\\"preserves\\\":%u,\\\"active_commands\\\":%u,\\\"keys\\\":[%u,%u],\\\"failed_step\\\":%u,\\\"stability_reason\\\":%u},",
        loss.mode < 4 ? modes[loss.mode] : "unknown", unsigned(loss.qualification),unsigned(loss.preserves),unsigned(loss.active_commands),
        unsigned(loss.key0),unsigned(loss.key1),loss.failed_step,loss.stability_reason);
'''
    # Original prefix ended with variants:[. Move the extra object before it.
    header = one(header, '\\"variants\\":[",', '",')
    header = one(header, marker, extra + '    std::fputs("\\\"variants\\\":[",stderr);\n' + marker)
    header = one(header, '      print_tensor(d.old_value);',
        '      std::fprintf(stderr,"\\\"field_mask\\\":%u,\\\"has_port\\\":%u,\\\"old\\\":",d.field_mask,unsigned(d.reason==2 || d.reason==3));\n      print_tensor(d.old_value);')
    header = one(header, '\\"old\\":",', '",')
    assert 'logical_trace' not in header
    target = W / 'source/src/graph/executable.cc'; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(candidate.replace('\n', newline).encode())
    diag_header = target.with_name('capture_mismatch_diag.h'); diag_header.write_text(header, encoding='utf-8')
    # Removing only diagnostics must recover every release statement exactly.
    inverse = candidate
    inverse = one(inverse, '''// Scratch-only diagnostics. No Model symbol, ABI or execution hook.
#include <cstdio>
namespace hyle::graph {''', 'namespace hyle::graph {')
    additions = ['#include "capture_mismatch_diag.h"\n\n',
        '      // Observe both immutable keys BEFORE selecting/evicting a variant.\n      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);\n',
        '    if (!reuse_only && (saved == nullptr || !saved->preserves_private_arguments))\n      capture_mismatch_diag::note_record(*state_, saved, range.step_begin, range.step_count);\n',
        '  const auto diag_revision = binding.revision;\n  const auto diag_prepared_revision = binding.prepared_revision;\n']
    additions += [f'        capture_mismatch_diag::note_key_loss(invocation, selected_step,\n            static_cast<unsigned>(mode), {saved}, diag_revision, diag_prepared_revision);\n' for saved in ('saved', '*saved')]
    for addition in additions: inverse = one(inverse, addition, '')
    assert inverse == original
    patch = '\n'.join(difflib.unified_diff(original.splitlines(), candidate.splitlines(), fromfile='release/executable.cc', tofile='diagnostic/executable.cc', lineterm='')) + '\n'
    (W / 'candidate.diff').write_text(patch, encoding='utf-8')
    # Reuse the already frozen exact Graph header overlay, not current product
    # headers or the W13 Model. No SDK, model or whole source copy is created.
    for dep in old_plan['project_dependencies']: assert pin(dep['frozen']['path']) == dep['frozen']
    command = old_plan['compile_command'].copy()
    for n, arg in enumerate(command):
        if arg == old_plan['candidate']['path']: command[n] = str(target)
        elif arg.lower() == '/sourcedependencies': command[n+1] = str(W / 'compile/dependencies.json')
        elif arg.startswith('/Fo'): command[n] = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.startswith('/Fd'): command[n] = '/Fd' + str(W / 'compile/unit.pdb')
    (W / 'compile').mkdir(exist_ok=True); (W / 'bin').mkdir(exist_ok=True)
    link = read(ready['recipe']['path'])['command'].copy()
    assert link.count(graph['object']['path']) == 1
    link = [str(W / 'compile/unit.obj') if x == graph['object']['path'] else x for x in link]
    for n, arg in enumerate(link):
        if arg.upper().startswith('/OUT:'): link[n] = '/OUT:' + str(W / 'bin/hyle.exe')
        elif arg.upper().startswith('/PDB:'): link[n] = '/PDB:' + str(W / 'bin/hyle.pdb')
        elif arg.upper().startswith('/IMPLIB:'): link[n] = '/IMPLIB:' + str(W / 'bin/hyle.lib')
    control = R / '.scratch/inference-continuous-wave-window-20261027/attempt2/single-timing/03-hyle_mtp'
    future = read(control / 'command.json')['command'].copy(); future[0] = str(W / 'bin/hyle.exe')
    save(W / 'plan.json', dict(status='PREPARED_NOT_COMPILED_NOT_LINKED_NOT_RUN',
        base_Graph=graph, W17_ready=pin(MODEL / 'ready-model.json'), W17_Model=ready['compiled'], W17_image=ready['image'],
        W17_link_inputs=ready['inputs'], unchanged_runtime=ready['runtime'], candidate=pin(target), diagnostic_header=pin(diag_header), patch=pin(W / 'candidate.diff'),
        inverse_release_bytes_identical=True, project_header_overlay_reused_from=pin(OLD / 'plan.json'), project_headers=old_plan['project_dependencies'],
        comment_only_overlay_exceptions=old_plan['comment_only_reuse_exceptions'], baseline_Graph_dependencies=graph['actual_dependencies'],
        baseline_toolchain_cstdio='Already present in Graph actual-dependencies; no new SDK header is introduced.',
        compile_command=command, link_command=link, future_MTP_command=future,
        costs=dict(host_Graph_CXX=1, link=1, Model_CXX=0, NVCC=0, SDK_builds=0, current_model_diagnostic_processes=1),
        report_oracle=dict(report=pin(control / 'consumer-result.json'), source='Historical Model3 complete producer report; NOT current W17 timing or a W17 rerun.',
            non_time_parser=pin(R / '.scratch/inference-current-review-profile-20261027/analyze.py'),
            rule='Compare the complete original non_time report. Preserve differences/failures; do not drop metadata, counters, IDs, work or ledger to make equality pass.'),
        protocol=['Single R1 greedy natural P154/max64/C1024 target+MTP K1, original BF16 roles and runtime, no trace/warmup/timing claim.',
            'Diagnostic-local sequence, no W13 Model external symbol. Record marker follows existing Model role/episode marker and precedes original prepared line; retain all raw stderr for exact mapping.',
            'At most64 necessary-record decisions and16 original invocation/range entries; explicit dropped counters must remain0. Both retained variants get at most one first-mismatch snapshot; never scan successful replay.',
            'old/new physical valid/description/resource/native/offset/extent and a complete field-change mask; no valid key is classified as missing-key and has_port false, never as a proven port0 mismatch.',
            'Key-loss event counts only an actual previously valid key/active command, records invalidation mode/revision/private qualification and first failing stable-binding proof step; clearing already-empty authority is excluded.',
            'No data/lease/source ownership, private proof, provider choice, capture selection, invalidation branch, allocation reuse or status is changed. Zero memory-payload reads by diagnostics.',
            'Compile and link require root scheduling. Check actual CXX dependency paths/bytes against this frozen overlay and recorded toolchain before admitting the candidate; no implicit header fallback.',
            'One diagnostic process only after root authorizes GPU. First real failure stops; no model retry or hidden control run. This preparation runs none.']))
    print('PREPARED_ONLY one host Graph CXX/link, current W17 Model unchanged; no CXX/GPU')

if __name__ == '__main__': main()
