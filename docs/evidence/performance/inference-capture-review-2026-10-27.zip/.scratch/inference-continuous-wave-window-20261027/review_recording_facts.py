"""Read only the retained ZIP in memory; write a small factual scratch review."""
from pathlib import Path
import collections
import hashlib
import io
import json
import re
import zipfile

W=Path(__file__).resolve().parent;R=W.parents[1]
archive=R/'docs/evidence/performance/inference-continuous-wave-current-window-2026-10-27.zip'
body=archive.read_bytes();z=zipfile.ZipFile(io.BytesIO(body))
prefix='.scratch/inference-continuous-wave-window-20261027/attempt2/'


def read(member):return json.loads(z.read(member))


def parse(member):
    turn=1;role=None;fresh=False;prepared=[]
    for line_no,line in enumerate(z.read(member).decode('utf-8-sig').splitlines(),1):
        found=re.match(r'generation_session .*?turn=(\d+)',line)
        if found:turn=int(found[1])
        found=re.match(r'generation_batch .*?role=(\d+)',line)
        if found:role=int(found[1]);fresh=True
        if line.startswith('prepared T='):
            values=dict(re.findall(r'([A-Za-z_]+)=([^\s]+)',line))
            prepared.append(dict(turn=turn,role=role,T=int(values['T']),visible=int(values['visible']),
                recorded=int(values['capture_recorded']),reused=int(values['capture_reused']),
                route=values['replay'],fresh_generation_dispatch=fresh,line=line_no))
            fresh=False
    return prepared


processes=[];patterns=collections.defaultdict(list)
for member in sorted(z.namelist()):
    if not member.startswith(prefix) or not member.endswith('/consumer-result.json'):continue
    relative=member[len(prefix):];group,folder,_=relative.split('/')
    raw=read(member);actual=read(member.replace('consumer-result.json','result.json'))
    scenario='two-turn' if group.startswith('two-turn') else 'single'
    arm=re.sub(r'^\d+-','',folder)
    assert actual['exit']==0
    row=dict(scenario=scenario,mode='memory' if group.endswith('memory') else 'timing',arm=arm,pid=actual['pid'],
        raw_report_member=member,actual_rounds=len(raw['rounds']),generated_decode_tokens=raw['generated_decode_tokens'],
        actual_target_rows=raw['actual_target_rows'],committed_target_rows=raw['committed_target_rows'],
        verified_target_rows=raw['verified_target_rows'],accepted_drafts=raw.get('accepted_drafts'),
        decode_seconds=raw['decode_seconds'],step_sum_seconds=raw.get('step_sum_seconds'),
        decode_step_sum_seconds=raw.get('decode_step_sum_seconds'))
    if arm.startswith('hyle'):
        prep=parse(member.replace('consumer-result.json','stderr.log'))
        target=[p for p in prep if p['T']==(2 if arm=='hyle_mtp' else 1)]
        recorded=[p for p in target if p['recorded']]
        shape_roles=collections.Counter((p['role'],p['T']) for p in target)
        row.update(prepared_steps=len(prep),decode_prepared_steps=len(target),recorded_ranges=sum(p['recorded'] for p in prep),
            recorded_events=len(recorded),recorded_positions=[dict(turn=p['turn'],visible=p['visible'],role=p['role'],T=p['T']) for p in recorded],
            role_shapes=[dict(role=k[0],T=k[1],calls=v) for k,v in sorted(shape_roles.items())],
            original_fresh_decode_dispatches=sum(p['fresh_generation_dispatch'] for p in target),
            no_fresh_dispatch_prepared_steps=[dict(turn=p['turn'],visible=p['visible']) for p in target if not p['fresh_generation_dispatch']],
            successor_publications=raw['overlap_successor_publications'],successor_submissions=raw['overlap_successor_submissions'],
            refusals=raw['overlap_successor_refusals'],final_available=raw['decode_overlap_available'])
        if arm=='hyle_plain':
            assert [p['visible'] for p in recorded]==([155] if scenario=='single' else [155,373,385])
        elif arm=='hyle_auto':
            assert [p['visible'] for p in recorded]==([155,156,157,158,159] if scenario=='single' else [155,156,157,158,159,373,374,375,376,377,385])
            assert row['successor_publications']==(55 if scenario=='single' else 59)
            assert row['refusals']==(0 if scenario=='single' else 1)
            assert row['original_fresh_decode_dispatches']==(8 if scenario=='single' else 67)
            expected=[dict(turn=1,visible=n) for n in range(163,218)]
            if scenario=='two-turn':expected += [dict(turn=2,visible=n) for n in range(381,385)]
            assert row['no_fresh_dispatch_prepared_steps']==expected
            row['direct_turn2_dispatch_positions']=[p['visible'] for p in target if p['turn']==2 and p['fresh_generation_dispatch']]
            if scenario=='two-turn':assert row['direct_turn2_dispatch_positions']==list(range(373,381))+list(range(385,436))
        else:
            assert row['actual_rounds']==(34 if scenario=='single' else 66)
            assert row['recorded_events']==(11 if scenario=='single' else 18)
            assert len(target)==row['actual_rounds']
        signature={k:row[k] for k in ('recorded_positions','role_shapes','original_fresh_decode_dispatches',
            'no_fresh_dispatch_prepared_steps','actual_rounds','generated_decode_tokens','actual_target_rows',
            'committed_target_rows','verified_target_rows','accepted_drafts','successor_publications','refusals','final_available')}
        patterns[(scenario,arm)].append(signature)
    processes.append(row)
assert len(processes)==40
assert all(len(p)==4 and all(x==p[0] for x in p) for p in patterns.values())
main_member=next(n for n in z.namelist() if n.endswith('/model3/engine/models/qwen35/main.cc'))
source=z.read(main_member).decode('utf-8-sig').splitlines()
anchors=[dict(member=main_member,line=n+1,text=line.strip()) for n,line in enumerate(source)
         if 'record.step_seconds = std::chrono::duration<double>(finished - step_start)' in line or
            'if (output.complete_seconds) *output.complete_seconds' in line or
            'second_start = b->step_start' in line or 'first_start = a.step_start' in line]
def spans(rows):
    result=[]
    for row in rows:
        if result and result[-1]['turn']==row['turn'] and result[-1]['last']+1==row['visible']:
            result[-1]['last']=row['visible']
        else:result.append(dict(turn=row['turn'],first=row['visible'],last=row['visible']))
    return result


signatures=[]
for k,v in sorted(patterns.items()):
    signature=dict(v[0]);signature['no_fresh_dispatch_prepared_intervals']=spans(signature.pop('no_fresh_dispatch_prepared_steps'))
    signatures.append(dict(scenario=k[0],arm=k[1],all_four_identical=True,signature=signature))
brief=[{k:v for k,v in row.items() if k not in ('recorded_positions','no_fresh_dispatch_prepared_steps','direct_turn2_dispatch_positions')} for row in processes]
value=dict(status='VERIFIED_ALL_40_RETAINED_PROCESS_REPORTS',input_archive=dict(path=str(archive),bytes=len(body),sha256=hashlib.sha256(body).hexdigest()),
    scope='ZIP-only, in-memory offline read. No live source, model, SDK, GPU, compiler or binary extraction.',
    processes_checked=40,Hyle_pattern_processes=24,pattern_timing_and_independent_memory_repetitions=4,
    confirmed=[
        'Ordinary off: single records visible155 once; two-turn records155/373/385. Pattern identical in all3 timing+1 memory processes per scenario.',
        'Single auto has63 decode steps,55 published successors and8 fresh ordinary dispatches. Warm8 is not8 recordings: actual recorded events are5 at155..159, then160..162 reuse before successor range163..217.',
        'Two-turn auto records5 at373..377, reuses378..380 with fresh dispatch, then no new generation dispatch at381..384 (4 steps), followed by new record385 and fresh synchronous dispatch through435. Whole counter59pub=55+4, refusal1, finalavailablefalse.',
        'MTP single34 target rounds and11 recording events; two-turn66 target rounds and18 recording events. All3 timing+1 memory repetitions have identical exact role/T/visible recording signatures.'
    ],not_exact_or_not_proven=[
        'A capture_recorded event reports captured range recording; it is not a kernel launch count or proof that the recording was avoidable. MTP contains distinct printed role3/4 artifacts and changing accepted-prefix/paged metadata.',
        'ZIP alone localizes old auto fallback but does not log its precise original refusal status or the failed physical tuple component. Sticky behavior is the archived Model3 behavior, not the later recovery product.',
        'Matched token quota is not identical accepted-row or natural-token work across all arms. Refer to each process actual rounds/rows/accepted drafts; do not replace34/66 by output counts or compare distinct roles as one fixed graph.'
    ],counterfactual_assumptions=[
        'Deleting excess recordings and reaching peer speed is an untested estimate, not a measured result. It requires a legal stable tuple/permissions/lifetime design, unchanged mathematical work and acceptance trajectory, and actual new complete endpoint measurements.',
        'cold_batch_seconds includes other prepare/metadata/resource work and is not isolated cudaGraph recording cost. A count of recordings times an average prepare time is not a proven wall-time saving.',
        'step_seconds spans each original step preparation-to-finish lifetime; A/B lifetimes overlap. Their sum (and MTP heterogeneous roles/proposals) is not elapsed decode wall time and cannot be subtracted from P+D/session to predict peer parity.'
    ],source_anchors=anchors,consistent_signatures=signatures,process_rows=brief)
destination=W/'recording-facts-review.json'
lines=['{']
for at,(key,item) in enumerate(value.items()):
    prefix='  '+json.dumps(key)+': ';end=',' if at+1<len(value) else ''
    if isinstance(item,list):
        lines.append(prefix+'[')
        lines.extend('    '+json.dumps(row,separators=(',',': '))+(',' if j+1<len(item) else '') for j,row in enumerate(item))
        lines.append('  ]'+end)
    else:lines.append(prefix+json.dumps(item,separators=(',',': '))+end)
lines.append('}');destination.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(dict(status=value['status'],summary=str(destination),processes=40,patterns=6,
    concise=[dict(scenario=k[0],arm=k[1],rounds=v[0]['actual_rounds'],recordings=len(v[0]['recorded_positions']),
                  shape_roles=v[0]['role_shapes'],actual_target_rows=v[0]['actual_target_rows'],accepted_drafts=v[0]['accepted_drafts']) for k,v in sorted(patterns.items())])))
