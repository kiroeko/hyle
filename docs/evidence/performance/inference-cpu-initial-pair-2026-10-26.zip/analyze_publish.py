"""Offline checks/package for the sole retained CPU pair. Never runs a model."""
from pathlib import Path
import datetime, hashlib, json, re, zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
PUBLIC = R / 'docs/evidence/performance/inference-cpu-initial-pair-2026-10-26.json'
ARCHIVE = PUBLIC.with_suffix('.zip')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p = Path(p).resolve(); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(x, ensure_ascii=False, indent=2) + '\n').encode())

h = read(W / 'run/hyle/stdout.log')
p = read(W / 'future-run/peer-result.json')
assert p == read(W / 'run/peer/stdout.log')
request = h['sessions'][0]
hr, ledger = request['result'], request['ledger']
prompt = [int(x) for x in (R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/prompt.ids').read_text().split()]
assert len(prompt) == 154 and prompt == p['prompt_ids'] == hr['turns'][0]['input_ids']
ids = hr['generated_ids']; assert len(ids) == 16 and ids == p['generated_ids']
assert h['backend'] == p['backend'] == 'cpu' and not h['mtp'] and not p['mtp']
assert h['generated_tokens'] == p['generated_tokens'] == h['requested_output_tokens'] == p['requested_steps'] == 16
assert h['prefill_target_rows'] == p['prefill_target_rows'] == 154
assert h['actual_target_rows'] == p['actual_target_rows'] == hr['visible_tokens'] == p['visible_tokens'] == 169
assert h['decode_graph_calls'] == p['target_decode_calls'] == h['generated_decode_tokens'] == p['generated_decode_tokens'] == 15
assert h['actual_graph_calls'] == p['target_compute_calls'] == 16
assert h['active_sequences'] == h['session_count'] == h['turn_count'] == p['session_count'] == p['turn_count'] == 1
assert all(x['requests'] == 1 for x in h['batches']) and not p['stopped_on_EOS']
assert not h['prefix_cache'] and h['restore_count'] == 0
assert len(ledger) == 16 and ledger[0]['input_rows'] == 154 and ledger[0]['after_length'] == 154
assert [x['after_length'] for x in ledger] == list(range(154, 170))
assert all(x['sampling_draw_before'] == x['sampling_draw_after'] == 0 for x in ledger)
assert [x['first_input'] for x in ledger[1:]] == [x['pending'] for x in p['rounds']] == ids[:-1]
assert [x['next_id'] for x in ledger[1:]] == [x['target_ids'][0] for x in p['rounds']] == ids[1:]
assert [x['target_after'] for x in p['rounds']] == list(range(155, 170))
assert all(x['native_target_pos_max'] == x['target_after'] - 1 and x['verified_target_rows'] == x['committed_target_rows'] == 1 for x in p['rounds'])
assert p['actual_draft_rows'] == p['draft_compute_calls'] == 0
assert p['selected_device_type_cpu'] and p['target_actual_threads'] == p['target_actual_batch_threads'] == 4
assert p['requested_gpu_layers'] == 0 and not p['offload_kqv'] and not p['op_offload']
assert p['configured_type_k'] == p['configured_type_v'] == 'bf16'
assert p['target_sampling'] == 'original native CPU greedy'
hs = (W / 'run/hyle/stderr.log').read_text(errors='replace')
ps = (W / 'run/peer/stderr.log').read_text(errors='replace')
assert 'cpu_representative native_threads=4 executor_concurrency=4 aten_intra_op_requested=4' in hs
assert 'weight_loader backend=cpu' in hs and 'cpu_plan known_workspace_host=' in hs
assert 'CPU_Mapped model buffer' in ps and 'CPU KV buffer' in ps and 'CPU compute buffer' in ps
assert h['original_device_weight_bytes'] == 0 and h['cpu_ffn_layers'] == 0
for result in [h, p]:
    assert abs(result['prefill_seconds'] + result['decode_seconds'] - result['session_seconds']) < 1e-9
    assert abs(154 / result['prefill_seconds'] - result['prefill_tokens_per_second']) < 1e-9
    assert abs(15 / result['decode_seconds'] - result['decode_output_tokens_per_second']) < 1e-9
    assert abs(16 / result['session_seconds'] - result['output_tokens_per_second']) < 1e-9
run = read(W / 'run/summary.json')
assert all(x['process']['exit'] == 0 for x in run['results']) and len(run['results']) == 2
assert run['model_retries'] == run['warmups'] == run['sidecars'] == 0

cache = R / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
all_commands = read(cache / 'compile_commands.json')
cpu_commands = [x for x in all_commands if 'ggml-cpu.dir' in x['command']]
assert len(cpu_commands) == 15
isa_tokens = ['/arch:avx', 'ggml_avx2', 'ggml_fma', 'ggml_f16c', '-mavx', '-mfma', '-mf16c']
assert all(not any(t in x['command'].lower() for t in isa_tokens) for x in cpu_commands)
extract = {'origin': pin(cache / 'compile_commands.json'), 'ggml_cpu_TUs': 15,
           'entries': cpu_commands, 'no_explicit_avx_fma_f16c_options': True,
           'archive_definition': next(x for x in (cache / 'build.ninja').read_text().splitlines() if x.startswith('build bin\\ggml-cpu.lib:')),
           'build_ninja': pin(cache / 'build.ninja'),
           'boundary': 'Retained same-cache build commands, not fresh disassembly or a new build. Historical C-root paths are read-only provenance, not paths created by this task.'}
save(W / 'analysis/peer-cpu-compile-extract.json', extract)

def metric(j):
    return {k: j[k] for k in ['prefill_seconds', 'decode_seconds', 'session_seconds', 'prefill_tokens_per_second',
                              'decode_output_tokens_per_second', 'output_tokens_per_second',
                              'startup_to_ready_seconds', 'startup_to_endpoint_seconds']}

facts = {
 'status': 'FINITE_CPU_INITIAL_PAIR_COMPLETE_NOT_A_FAIR_OR_STABLE_CPU_RANKING',
 'generated_UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope': 'One serial Hyle then peer CPU execution each, ordinary greedy P154/requested16/C256/N1/R1, T4, no warmup/retry/sidecar. Private consumer-only injection; product defaults unchanged. Offline analysis only after Root ran the pair.',
 'processes': run['results'],
 'work': {'checks_passed': True, 'prompt_rows': 154, 'requested_outputs': 16, 'emitted_outputs_each': 16,
          'decode_calls_each': 15, 'target_calls_each': 16, 'target_rows_each': 169, 'draft_rows_each': 0,
          'sessions': 1, 'turns': 1, 'requests_per_batch': 1, 'context_capacity': 256,
          'prefix_cache': False, 'restore_count': 0, 'sampling': 'greedy', 'EOS_early_stop': False,
          'identical_prompt_ids': True, 'identical_generated_ids': True, 'generated_ids': ids,
          'identical_all_15_pending_inputs_and_selected_next_ids': True,
          'hyle_ledger_records': 16, 'hyle_commit_lengths': list(range(154,170)),
          'hyle_sampling_draws': 0, 'hyle_final_live_committed_versions': h['live_committed_versions'],
          'boundary': '16 matching greedy IDs are observed, not intermediate-bit equality, a quality score, or a general precision equivalence proof.'},
 'single_observation': {'sample_count_per_arm': 1, 'hyle': metric(h), 'peer': metric(p),
          'metrics': 'Prefill154/time; decode15/time excludes the first prefill-produced output; combined16/session time. No averaging, selection of best samples, or cross-window normalization.'},
 'CPU_and_threads': {
   'hardware': 'Existing local inventory: Intel Core i9-13900K,24 cores/32 logical processors; no per-run CPUID/affinity/module sample.',
   'hyle': {'reported_backend': h['backend'], 'host_weight_bytes': h['original_host_weight_bytes'],
            'device_weight_bytes': h['original_device_weight_bytes'], 'cpu_ffn_layers': h['cpu_ffn_layers'],
            'entry_config': 'native_threads4; original borrowed Scheduler/bulk executor concurrency4; startup configure_runtime_threads(4) succeeds only after ATen setter/getter agreement. Entry logs the requested budget.',
            'actual_scope': 'Single CPU execution source/domain, finite original workspace admission, actual CPU loader/plan logs. No per-op provider census in this run.'},
   'peer': {k: p[k] for k in ['backend','selected_device','selected_device_type_cpu','requested_gpu_layers','offload_kqv','op_offload','target_actual_threads','target_actual_batch_threads','configured_type_k','configured_type_v','target_sampling']},
   'not_a_process_thread_cap': True,
   'GPU_boundary': 'CPU-only model placement is supported by actual fields and CPU model/KV/recurrent/compute buffer logs. Peer stderr still enumerates the linked CUDA registry/RTX4070 at startup. No profiler or GPU-memory sidecar was taken: do not claim zero CUDA API calls or zero GPU runtime initialization.'},
 'fairness_and_precision': {
   'fair_CPU_victory_claim': False,
   'matched': ['same original154 prompt IDs','same requested16/actual16 outputs','same169target rows/16target calls','same explicit CPU T4 configurations','no offload in either model'],
   'ISA_mismatch': 'Peer links the retained generic ggml-cpu.lib528f3921; all15 corresponding cached CPU TU commands lack AVX/AVX2,FMA,F16C options. Hyle has a feature-gated AVX2/FMA/F16C optimized GDN-v3 program with corrected AVX2 objects, plus CPU routes that can use ATen/oneDNN. Therefore this is not an ISA-matched peer baseline.',
   'hardware_and_route_limit': 'This run did not capture CPUID bits, the selected optimized module, per-operation routes or sampled kernel symbols. Source eligibility and cached build flags do not prove that every Hyle operation used that AVX2 program or quantify its contribution.',
   'peer_BF16_support': 'Existing BF16 CPU trait points to ggml_vec_dot_bf16. Its AVX/AVX2 branches are compile-conditional; the generic x64 fallback widens BF16 to F32 products, accumulates ggml_float(double), then stores F32. This is supported scalar math, not an absent BF16 reader. No kernel sampling proves how much of the observed run used that function.',
   'hyle_precision': {'score_dtype': h['score_dtype'], 'score_policy': h['score_policy'], 'source': 'Original selected HF BF16 source; source-defined BF16 activation/store points and F32 operations remain unchanged.'},
   'peer_precision': p['precision_note'],
   'peer_actual_loaded_types': 'Original loader log:187 BF16 tensors,133 F32 tensors. Configured K/V BF16; recurrent state F32.',
   'timing_limit': 'Only one short pair; no distribution, temperature/affinity sweep, repeatability or stable throughput claim. Large observed differences may reflect implementation/ISA/precision/provider differences. No allocation/thread-default/team-owner changes follow from these data.',
   'startup_not_comparable': 'Hyle configures ATen and constructs its borrowed Scheduler before entering qwen35::run startup clock; peer startup is inside its original run(). Startup/process-wall values are listed only, never a fair cold-start ranking.',
   'pool_fact_not_bug': 'Source shows persistent ggml native pools per prepared Invocation. No per-step pool rebuild, oversubscription fault, or attributable pool performance bug was observed or established.'},
 'identities': {'source': read(W/'source-pins.json'), 'hyle_ready': read(W/'hyle/ready.json'), 'peer_ready': read(W/'peer3/ready.json'),
                'compile_scope': 'Hyle Model/weights/private entry only; peer consumer TU only. CPU core/providers/native archives/SDKs and both local weight files reused. Model runs2, warmups0, retries0, native builds0, SDK builds0.',
                'existing_current_core_reference': 'docs/evidence/research/inference-current-source-build-2026-10-26.json'},
 'failures_and_bridges': [
   'Peer first compile failed on the removed tools/qwen35_text/mtp_schedule.h include. Exact5486B/b4323081 header restored from local git c950466ec^, with current actual parser dependencies recorded; no download or model run in that failure.',
   'Offline metadata initially assumed current schedule.h was byte-identical to the historical tools header; assertion failed, recorded separately, and metadata was corrected. The actual unscheduled P154 branch reads prompt.ids in peer_multiturn.cc and does not invoke that schedule parser.',
   'Peer2 built but retained old GPU text in target/draft sampling labels. Peer3 changes only report labels and adds existing actual thread getters, selected CPU and no-offload/configured BF16 facts after the original endpoint. Only peer3 was run. Historical peer2 source/builds and first failure remain in scratch.'
 ],
 'reproduce': {'build_script': '.scratch/inference-cpu-representative-20261026/build.py',
               'run_script': '.scratch/inference-cpu-representative-20261026/run.py', 'commands': read(W/'commands.json'),
               'requirements': 'Same retained local source/header/object/native/SDK/weight cache identities. Archive contains no executable, object, SDK or model payload. No automatic acquisition or extra run is performed by this analysis script.'},
 'raw_identity': {name: pin(W/name) for name in ['run/hyle/stdout.log','run/hyle/stderr.log','run/peer/stdout.log','run/peer/stderr.log','future-run/peer-result.json']},
 'limits': ['No CPU/hybrid scaling or MTP performance result.','No memory-peak sample; requested-byte accounting is not physical RAM/VRAM.','No precision-quality or cross-dtype bit-equivalence claim.','No product source/default change or extra run during analysis/publication.']
}
save(W/'analysis/summary.json',facts)

files = {}
def add(name, path):
    path = Path(path); assert path.is_file(), path
    assert path.suffix.lower() in {'.json','.log','.py','.patch','.h','.cc','.txt'}, path
    assert name not in files; files[name] = path
for name in ['analysis/summary.json','analysis/peer-cpu-compile-extract.json','analyze_publish.py','build.py','run.py','cpu_entry.cc','source.patch','source-pins.json','commands.json','source/mtp_schedule.h']:
    add(name,W/name)
for name in ['hyle','peer']:
    for leaf in ['command.json','stdout.log','stderr.log','process.json']:
        add('run/'+name+'/'+leaf,W/'run'/name/leaf)
add('run/summary.json',W/'run/summary.json')
add('run/peer/consumer-result.json',W/'future-run/peer-result.json')
for name in ['hyle','peer3']:
    for leaf in ['ready.json','runtime.json','link-inputs.json','link/command.json','link/process.json','link/stdout.log','link/stderr.log']:
        add(name+'/'+leaf,W/name/leaf)
for name in ['model','weights','entry','peer3']:
    for leaf in ['command.json','process.json','stdout.log','stderr.log','actual-self-dependencies.json']:
        add('compile/'+name+'/'+leaf,W/'compile'/name/leaf)
for name in ['failed-source.cc','command.json','stdout.log','stderr.log','process.json','first-failure.json','offline-metadata-first-assertion.txt']:
    add('first-failure/peer/'+name,W/'compile/peer'/name)
for name in ['peer_multiturn.cc','ready.json','source-pins.json']:
    add('history/peer2/'+name,W/'history/peer2'/name)
for name in ['session_schedule.h','schedule.h','token_ids.h']:
    add('support/engine/models/qwen35/'+name,R/'engine/models/qwen35'/name)
for name,path in [
 ('isa/hyle-native-ops-command.json',R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-ops/command.json'),
 ('isa/hyle-native-link-command.json',R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/command.json'),
 ('isa/hyle-avx2-vec-record.json',R/'.scratch/glm-gguf-selected-20261023/B10/cpu-native-avx2-corrected1/11-vec-cpp-record.json'),
 ('isa/hyle-avx2-verification.json',R/'.scratch/glm-gguf-selected-20261023/B10/cpu-native-avx2-corrected1/verification.json')]:add(name,path)
manifest = [{'name':name,'bytes':path.stat().st_size,'sha256':pin(path)['sha256']} for name,path in sorted(files.items())]
save(W/'analysis/archive-manifest.json',manifest)
add('archive-manifest.json',W/'analysis/archive-manifest.json')
ARCHIVE.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(files.items()):z.writestr(name,path.read_bytes())
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None and len(z.namelist())==len(files)
    for row in manifest:
        data=z.read(row['name']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
facts['archive']={**pin(ARCHIVE),'path':ARCHIVE.relative_to(R).as_posix(),'members':len(files),'CRC_PASS':True,'member_SHA256_PASS':True,'excluded':'Binaries,objects,SDKs,model payloads,full source/dependency trees.'}
save(PUBLIC,facts)
print(json.dumps({'report':pin(PUBLIC),'archive':facts['archive'],'generated_ids':ids,'ISA_matched':False},indent=2))
