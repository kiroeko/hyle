"""Consumer-only CPU build. Deliberately contains no model execution action."""
from pathlib import Path
import argparse, difflib, hashlib, importlib.util, json, os, subprocess, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
C = R / '.scratch/inference-current-control-b346-20261026'
B = R / '.scratch/inference-current-closure-20261026'
P = R / '.scratch/qwen-mtp-final-window-20261024'
spec = importlib.util.spec_from_file_location('cpu_representative_host', R / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p = Path(p).resolve(); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes((json.dumps(x, indent=2) + '\n').encode())
def key(p): return os.path.normcase(str(Path(p).resolve()))
def environment(command):
    return h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':command[0], 'CMAKE_CXX_COMPILER':command[0], 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
def prepare():
    assert not (W/'source-pins.json').exists()
    main = R/'engine/models/qwen35/main.cc'; assert pin(main)['sha256'] == 'b346d408cdf8226b2df464f757483cc3aecd5b7c2f2d7f290751c7115d3cc44c'
    records = []; patch = []
    def source(original, relative, transform):
        before = original.read_bytes(); after = transform(before)
        target = W/'source'/relative; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(after)
        records.append(dict(path=relative, before=pin(original), after=pin(target)))
        patch.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/'+relative, tofile='b/'+relative))
    def model(b):
        old = b'Backend create_execution(const ModelGeometry &geometry, const cache::Plan &plan,'
        assert b.count(old)==1
        b = b.replace(old, b'const c::cpu::DefaultContextOptions &representative_cpu_options() noexcept;\n'+old)
        old = b'  selection = select_execution(selection, cpu_layers);\n'
        assert b.count(old)==1
        return b.replace(old, old+b'  if (!cpu_options && (selection.primary == BackendKind::kCpu || cpu_layers))\n    cpu_options = &representative_cpu_options(); // Private fixed T4 consumer only.\n')
    source(main, 'engine/models/qwen35/main.cc', model)
    source(R/'engine/models/qwen35/weights.cc', 'engine/models/qwen35/weights.cc', lambda b:b)
    def peer(b):
        pairs = [
          (b'"../../../tools/qwen35_text/mtp_schedule.h"', b'"mtp_schedule.h"'),
          (b'ggml_backend_dev_by_name("CUDA0")', b'ggml_backend_dev_by_type(GGML_BACKEND_DEVICE_TYPE_CPU)'),
          (b'ggml_backend_dev_type(device) == GGML_BACKEND_DEVICE_TYPE_GPU, "CUDA0 GPU required"', b'ggml_backend_dev_type(device) == GGML_BACKEND_DEVICE_TYPE_CPU, "CPU device required"'),
          (b'ggml_backend_dev_t devices[]{device, nullptr};', b'ggml_backend_dev_t devices[]{nullptr};'),
          (b'mp.n_gpu_layers = 999;', b'mp.n_gpu_layers = 0;'),
          (b'{"^token_embd\\\\.weight$", ggml_backend_dev_buffer_type(device)}, {nullptr, nullptr}', b'{nullptr, nullptr}'),
          (b'cp.n_threads = 24; cp.n_threads_batch = 24; cp.kv_unified = true;', b'cp.n_threads = 4; cp.n_threads_batch = 4; cp.kv_unified = true;\n    cp.offload_kqv = false; cp.op_offload = false;')]
        for old,new in pairs:
            assert b.count(old)==1, old
            b=b.replace(old,new)
        b=b.replace(b'original native GPU greedy',b'original native CPU greedy')
        old=b'{"target_sampling", "original native CPU greedy"}'
        facts=b'{"backend", "cpu"}, {"selected_device", ggml_backend_dev_name(device)}, {"selected_device_type_cpu", ggml_backend_dev_type(device) == GGML_BACKEND_DEVICE_TYPE_CPU}, {"requested_gpu_layers", mp.n_gpu_layers}, {"offload_kqv", cp.offload_kqv}, {"op_offload", cp.op_offload}, {"target_actual_threads", llama_n_threads(target.get())}, {"target_actual_batch_threads", llama_n_threads_batch(target.get())}, {"configured_type_k", ggml_type_name(cp.type_k)}, {"configured_type_v", ggml_type_name(cp.type_v)}, '
        assert b.count(old)==1
        b=b.replace(old,facts+old)
        return b
    source(P/'source/peer_multiturn.cc', 'peer_multiturn.cc', peer)
    header = subprocess.check_output(['git','show','c950466ec^:tools/qwen35_text/mtp_schedule.h'], cwd=R)
    assert hashlib.sha256(header).hexdigest() == 'b4323081d2b8defc71cb40fe5b183411adc993df0172f44aaa80505811b99f5c'
    (W/'source/mtp_schedule.h').write_bytes(header)
    (W/'source.patch').write_bytes(''.join(patch).encode())
    save(W/'source-pins.json',dict(files=records,entry=pin(W/'cpu_entry.cc'),support=[pin(W/'source/mtp_schedule.h')],patch=pin(W/'source.patch'),private_only=True))
    print('PREPARED', flush=True)
def compile_one(name, recipe, source, cpu=False):
    old = read(recipe)['command']; out = W/'compile'/name
    command=[]; skip=False
    for arg in old:
        if skip: skip=False; continue
        if arg.lower()=='/sourcedependencies': skip=True; continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')): continue
        command.append(arg)
    if cpu:
        command += ['/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_COMPUTE_ONEDNN=1','/DHYLE_GRAPH_ONEDNN=1']
    command += ['/I'+str(R/'engine/models/qwen35'),str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
    result=h.execute(command,environment(command),out,timeout=120)
    d=read(out/'dependencies.json')['Data']; deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
    save(out/'actual-dependencies.json',deps)
    own=[x for x in deps if key(x['path']).startswith(key(R)+os.sep)];save(out/'actual-self-dependencies.json',own)
    return dict(result=result,object=pin(out/'unit.obj'),source=pin(source),command=pin(out/'command.json'),actual_dependencies=pin(out/'actual-dependencies.json'))
def hyle():
    results={}
    for name,recipe,source in [('model',C/'compile/command.json',W/'source/engine/models/qwen35/main.cc'),('weights',B/'engine/weights/command.json',W/'source/engine/models/qwen35/weights.cc'),('entry',B/'engine/entry/command.json',W/'cpu_entry.cc')]:
        results[name]=compile_one(name,recipe,source,True)
        save(W/'hyle-compile-summary.json',results)
    # Same conditional Backend definition in both actual consumers.
    for name in ['model','weights','entry']:
        args=read(W/'compile'/name/'command.json')['command']; assert '/DHYLE_COMPUTE_CPU=1' in args and '/DHYLE_COMPUTE_CUDA=1' in args
    main_deps=read(W/'compile/model/actual-dependencies.json'); assert any(x['path']==str(R/'engine/inference/backend.h') for x in main_deps)
    old_inputs=read(C/'link-inputs.json')
    old={ 'model':read(C/'ready.json')['app']['path'], 'weights':str(B/'engine/weights/unit.obj'), 'entry':str(B/'engine/entry/unit.obj') }
    replacements={key(v):results[k]['object'] for k,v in old.items()}
    return link('hyle',read(C/'link/process/command.json')['command'],old_inputs,replacements,results,read(C/'runtime.json'))
def peer():
    result=compile_one('peer3',P/'compile1/peer/identity.json',W/'source/peer_multiturn.cc')
    plan=read(P/'peer-link1/link-plan.json'); replacements={key(plan['inputs'][0]['path']):result['object']}
    return link('peer3',plan['command'],plan['inputs'],replacements,{'peer':result},read(P/'peer-link1/runtime-environment.json'))
def link(name,old,inputs,replacements,results,runtime):
    out=W/name/'link'; image=out/(name+'.exe'); command=[]; seen=[]
    for arg in old:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if key(arg) in replacements: seen.append(key(arg));arg=replacements[key(arg)]['path']
        command.append(arg)
    assert set(seen)==set(replacements) and len(seen)==len(replacements)
    mapped=[replacements.get(key(x['path']),x) for x in inputs]
    for x in mapped: assert pin(x['path'])==x, x['path']
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    save(W/name/'link-inputs.json',mapped)
    linked=h.execute(command,environment(command),out,timeout=120)
    if name=='hyle':
        native=Path(runtime['native']['path']); target=out/Path(runtime['native_hardlink']['path']).name
        os.link(native,target);runtime['native_hardlink']=pin(target)
    save(W/name/'runtime.json',runtime)
    value=dict(status='BUILT_NOT_RUN',image=pin(image),compile=results,link=linked,link_inputs=pin(W/name/'link-inputs.json'),runtime=pin(W/name/'runtime.json'),source_pins=pin(W/'source-pins.json'),threads=4,model_runs=0,GPU_runs=0,SDK_builds=0,native_builds=0,limits='Private CPU/nooffload consumer only; compilation/linking do not prove CPU route completion, performance or a global thread cap. Original endpoints unchanged; Hyle outer ATen/Scheduler startup lies before qwen35::run startup clock.')
    save(W/name/'ready.json',value);print('READY',name,json.dumps(value['image']),flush=True)
if __name__=='__main__':
    action=argparse.ArgumentParser();action.add_argument('action',choices=['prepare','hyle','peer']);a=action.parse_args()
    {'prepare':prepare,'hyle':hyle,'peer':peer}[a.action]()
