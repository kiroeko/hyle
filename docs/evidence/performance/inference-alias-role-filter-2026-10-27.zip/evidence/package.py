from pathlib import Path
import hashlib
import json
import statistics
import zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/performance/inference-alias-role-filter-2026-10-27.json'
CACHE = {}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve()
    key = str(path).casefold()
    if key not in CACHE:
        data = path.read_bytes()
        CACHE[key] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return dict(CACHE[key])


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), (row, actual)
    return actual


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def facts(value):
    # Exactly the screen.py predicate: no additional post-hoc ignored keys.
    if isinstance(value, list):
        return [facts(x) for x in value]
    if isinstance(value, dict):
        return {key: facts(item) for key, item in value.items()
                if not any(x in key for x in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value


def verify_unit(unit, dependency_key):
    assert unit['process']['exit'] == 0
    assert unit['source']['sha256'] == unit['snapshot']['sha256']
    exact(unit['snapshot'])
    exact(unit['object'])
    exact(unit[dependency_key])
    rows = read(unit[dependency_key]['path'])
    for row in rows:
        if str(row['path']).casefold() == str(unit['source']['path']).casefold():
            # Historical source identity is proved by its exact compiled snapshot,
            # not by a later checkout HEAD.
            assert (row['bytes'], row['sha256']) == (unit['snapshot']['bytes'], unit['snapshot']['sha256'])
        else:
            exact(row)
    return len(rows)


def main():
    summary_path = W / 'screen-summary.json'
    if not summary_path.exists():
        raise SystemExit('screen-summary.json is absent; no waiting and no archive generated')
    assert not DEST.exists() and not DEST.with_suffix('.zip').exists(), 'Do not overwrite published evidence'
    plan, tests, screen = (read(W / name) for name in ['build-plan.json', 'summary.json', 'screen-summary.json'])
    assert screen['status'] == tests['status'] == 'PASS'
    exact(tests['plan'])
    exact(plan['candidate'])
    for key in ['cli_baseline', 'cli_ready', 'test_baseline', 'test_ready', 'precompile_dependencies']:
        exact(plan[key])
    original_cli = read(plan['cli_ready']['path'])
    original_model = next(x for x in original_cli['compiled'] if x['name'] == 'model1')
    model_dependencies = verify_unit(original_model, 'dependencies')
    compiled = [read(W / 'compile' / unit['name'] / 'compiled.json') for unit in plan['units']]
    for unit in compiled:
        unit['verified_dependency_count'] = verify_unit(unit, 'actual_dependencies')
        exact(unit['command'])
        exact(unit['compiler_dependencies'])
    assert len(compiled) == 3
    assert plan['test_registration_review']['existing_test_TUs'] == 17
    assert not plan['test_registration_review']['collision']
    ready = {kind: read(W / ('ready-' + kind + '.json')) for kind in ['cli', 'test']}
    old_graph = plan['original_executable']['object']
    new_graph = compiled[0]['object']
    exact(old_graph)
    for kind, baseline_key, count in [('cli', 'cli_baseline', 224), ('test', 'test_baseline', 241)]:
        record = ready[kind]
        for key in ['image', 'inputs', 'recipe', 'runtime']:
            exact(record[key])
        assert record['link']['exit'] == 0
        before, after = read(plan[baseline_key]['path']), read(record['inputs']['path'])
        expected = [new_graph if row == old_graph else row for row in before]
        if kind == 'test':
            expected.extend(x['object'] for x in compiled[1:])
        assert after == expected and len(after) == count
        assert sum(row == old_graph for row in before) == 1
        for row in after:
            exact(row)
        outputs = [arg for arg in read(record['recipe']['path'])['command']
                   if arg.lower().startswith(('/out:', '/pdb:', '/implib:'))]
        assert len(outputs) == 3
        assert all(Path(arg.split(':', 1)[1]).resolve().is_relative_to(W) for arg in outputs)
    runtime = read(W / 'runtime.json')
    for key in ['original', 'original_native_cpu', 'alias']:
        exact(runtime[key])
    baseline_image = next(x['image'] for x in original_cli['artifacts'] if x['name'] == 'cli')
    assert screen['images'] == dict(baseline=baseline_image, candidate=ready['cli']['image'])
    for image in screen['images'].values():
        exact(image)
    test_xml = ET.parse(tests['xml']['path']).getroot().findall('./testsuite/testcase')
    assert tests['process']['exit'] == 0 and len(test_xml) == 5
    assert sorted(x.attrib['classname'] + '.' + x.attrib['name'] for x in test_xml) == sorted(plan['tests'])
    assert all(not any(x.find(k) is not None for k in ['failure', 'error', 'skipped']) for x in test_xml)
    exact(tests['xml'])
    assert read(W / 'run/process.json')['exit'] == 0
    order = [('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto'),
             ('baseline', 'auto'), ('candidate', 'auto'), ('candidate', 'off'), ('baseline', 'off'),
             ('baseline', 'off'), ('candidate', 'off'), ('candidate', 'auto'), ('baseline', 'auto')]
    assert len(screen['runs']) == 12
    oracles, process_review = {}, []
    for index, (row, expected) in enumerate(zip(screen['runs'], order), 1):
        assert (row['arm'], row['mode']) == expected and row['process']['exit'] == 0
        out = W / 'screen' / row['name']
        report = read(out / 'report.json')
        exact(row['report'])
        assert report == read(out / 'stdout.log')
        assert read(out / 'process.json') == row['process']
        command = read(out / 'command.json')['command']
        assert command[0] == screen['images'][row['arm']]['path']
        assert command[command.index('--decode-overlap') + 1] == row['mode']
        assert report['generated_tokens'] == 97 and report['generated_decode_tokens'] == 96
        assert report['live_committed_versions'] == 0
        assert report['overlap_successor_publications'] == (44 if row['mode'] == 'auto' else 0)
        assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
        selected = facts(report)
        if row['mode'] not in oracles:
            oracles[row['mode']] = selected
        assert selected == oracles[row['mode']]
        process_review.append(dict(name=row['name'], arm=row['arm'], mode=row['mode'],
                                   process=row['process'], report=row['report']))
    for arm in ['baseline', 'candidate']:
        for mode in ['off', 'auto']:
            rows = [x for x in screen['runs'] if (x['arm'], x['mode']) == (arm, mode)]
            assert len(rows) == 3
            for metric in ['prefill', 'decode', 'total', 'ready_seconds', 'shared_backing_bytes']:
                assert statistics.median(x[metric] for x in rows) == screen['medians'][arm][mode][metric]
            for metric in ['prefill', 'decode', 'total']:
                assert [min(x[metric] for x in rows), max(x[metric] for x in rows)] == screen['ranges'][arm][mode][metric]
                gain = 100 * (screen['medians']['candidate'][mode][metric] / screen['medians']['baseline'][mode][metric] - 1)
                assert gain == screen['candidate_gain_percent'][mode][metric]
    assert screen['complete_non_time_reports_equal_per_mode']
    assert not screen['memory_peak_sampled'] and not screen['peer_run'] and not screen['mtp_run']
    files = []
    for path in W.rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(W)
        if path.name in ['archive-manifest.json', 'package-result.json'] or '__pycache__' in relative.parts:
            continue
        if path.suffix.lower() not in ['.py', '.json', '.diff', '.cc', '.h', '.log', '.txt', '.xml']:
            continue
        if relative.parts[0] not in ['source', 'compile', 'logs', 'link-cli', 'link-test', 'run', 'screen'] and len(relative.parts) != 1:
            continue
        files.append(path)
    manifest = [dict(archive_path='evidence/' + p.relative_to(W).as_posix(), **pin(p)) for p in sorted(files)]
    save(W / 'archive-manifest.json', manifest)
    files.append(W / 'archive-manifest.json')
    fact_pins = {mode: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                 for mode, value in oracles.items()}
    receipt = dict(
        schema_version=1, date='2026-10-27', status='PASS', scope='Finite alias-role lookup candidate A/B',
        change='Only move original self/no-workspace and pure input/input Ok gates before replacement lookup; no authorization or payload change.',
        complexity='Source-level incoming lookup bound decreases O(M^3) to O(M^2) only for ordinary pure-input bundles. Compiler elimination may already remove work; no measured complexity claim.',
        counts=dict(CXX=3, distinct_TU=3, links=2, component_processes=1, tests=5, skipped=0,
                    screen_processes=12, new_peer_processes=0, new_MTP_processes=0, SDK=0, NVCC=0, downloads=0),
        baseline=dict(ready=plan['cli_ready'], closure=plan['cli_baseline'], inputs=224,
                      model_source=original_model['source'], model_snapshot=original_model['snapshot'],
                      model_object=original_model['object'], model_actual_dependencies=original_model['dependencies'],
                      verified_dependency_count=model_dependencies,
                      model_public_evidence='docs/evidence/correctness/inference-generation-batch-facts-2026-10-27.json'),
        candidate=dict(source=compiled[0]['source'], snapshot=compiled[0]['snapshot'],
                       patch=plan['candidate'], image=ready['cli']['image'], graph_object=new_graph,
                       sole_CLI_replacement=dict(original=old_graph, replacement=new_graph)),
        build=dict(plan=pin(W / 'build-plan.json'), units=compiled, CLI=ready['cli'], component=ready['test'],
                   retained_component_test_TUs=17, added_test_TUs=2, original_test_objects_rejected_changed_dependencies=[len(x['changed_dependencies']) for x in plan['old_test_objects']],
                   outputs_isolated=True, original_freeze_recipe_failure='0 compiler/link/test launches; slash-key detection and error-log Path expression; original recipe and failure note preserved.'),
        correctness=dict(process=tests['process'], cases=tests['tests'], XML=tests['xml']),
        performance=dict(plan=pin(W / 'screen-plan.json'), summary=pin(summary_path), runs=process_review,
                         medians=screen['medians'], ranges=screen['ranges'], candidate_gain_percent=screen['candidate_gain_percent'],
                         complete_non_time_report_equality_per_mode=True, original_fact_predicate='screen.py facts; no additional ignored keys',
                         complete_fact_sha256_per_mode=fact_pins,
                         conclusion='No net speedup evidence: off decode about -0.1605%, auto about +0.1383%; prefill about -2.6%, observed ranges overlap. Retained as deterministic removal of unnecessary lookup, not a fix for binding/replay host cost.'),
        limits=['Ordinary CUDA R1 P154 +96 decode only; no new peer or MTP performance comparison.',
                'Shared backing bytes are cache backing, not a sampled full VRAM peak.',
                'Three observations per image/mode; no significance claim or universal hardware conclusion.'],
        runtime=pin(W / 'runtime.json'), archive_manifest=pin(W / 'archive-manifest.json'),
        archive=dict(path=str(DEST.with_suffix('.zip')), files=len(files) + 1, binaries_SDK_models=False))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    save(DEST, receipt)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(DEST, 'receipt.json')
        for path in sorted(files):
            archive.write(path, 'evidence/' + path.relative_to(W).as_posix())
    assert read(DEST) == receipt
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None
        assert json.loads(archive.read('receipt.json')) == receipt
        assert len(archive.namelist()) == receipt['archive']['files']
        for row in manifest:
            data = archive.read(row['archive_path'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        assert all(Path(name).suffix.lower() not in ['.obj', '.exe', '.pdb', '.lib', '.exp', '.dll', '.metallib', '.gguf']
                   for name in archive.namelist())
    result = dict(status='ARCHIVED_AND_READ_BACK', receipt=pin(DEST), archive=pin(DEST.with_suffix('.zip')),
                  files=receipt['archive']['files'], new_model_or_test_processes=0)
    save(W / 'package-result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
