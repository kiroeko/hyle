from pathlib import Path
import importlib.util, json, os, re, sys, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
def module(name,path):
    s=importlib.util.spec_from_file_location(name,path); x=importlib.util.module_from_spec(s);s.loader.exec_module(x);return x
prior=module('alias_previous',R/'.scratch/inference-deferred-source-bind-20261027/build.py')
m,h,exact=prior.m,prior.h,prior.exact
m.W=W
CLI=R/'.scratch/inference-generation-batch-facts-20261027'
TEST=R/'.scratch/inference-generation-continuation-20261027/component-written-prefix'
EXE=R/'.scratch/inference-model-submission-source-20261027'
OLD_TEST=R/'.scratch/graph-system-constant-lease-20261024/test-executable'
OLD_FRONT=R/'.scratch/architecture-refactor-2026-10-18/expert-working-set-2026-10-21/common/checks/frontier3/graph--input_source_frontier_test-e67b3a'
CASES=['InputSourceBundle.InvalidLastTensorPreservesOriginalPreparedBindings',
'InputSourceBundle.SameProducerReplacesBothInputsAndDeduplicatesReadiness',
'InputSourceBundle.FuturePublishedInputAliasAndDuplicatesRejectAsOneTransaction',
'Invocation.AllowsOnlyLifetimeSafeExactExternalInPlaceAlias',
'Invocation.RepeatedOutputBindingKeepsAliasChecksForChangedInputsAndRanges']
def environment():
    env=dict(os.environ);env.update(m.read(TEST/'environment.json'))
    paths=[str(W/'bin'),*m.read(CLI/'runtime.json')['PATH'].split(';'),*m.read(TEST/'runtime.json')['PATH'].split(';')]
    seen=set();env['PATH']=';'.join(x for x in paths if x and not (x.casefold() in seen or seen.add(x.casefold())))
    for k in ['HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE']:env[k]='1'
    return env

def command(template,source,out):
    result=[]
    for i,arg in enumerate(template):
        if i and template[i-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(source)
        result.append(arg)
    assert m.build_contract(template)==m.build_contract(result)
    return result

def tests_in(source):
    text=Path(source).read_text(encoding='utf-8')
    return {a+'.'+b for a,b in re.findall(r'\bTEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',text)}

def freeze():
    assert not (W/'build-plan.json').exists()
    cli=m.read(CLI/'cli-link-inputs-facts1.json');test=m.read(TEST/'test-link-inputs.json')
    assert len(cli)==224 and len(test)==239
    unique={m.key(x['path']):x for x in cli+test}
    for row in unique.values():exact(row)
    ci,ti=m.index(cli),m.index(test)
    original=ci[m.key(R/'src/graph/executable.cc')]
    assert original['object']==ti[m.key(R/'src/graph/executable.cc')]['object']
    specs=[('executable','src/graph/executable.cc',EXE/'logs/executable/command.json'),
           ('input-source-test','tests/graph/input_source_frontier_test.cc',OLD_TEST/'command.json'),
           ('executable-test','tests/graph/executable_test.cc',OLD_TEST/'command.json')]
    units=[];old_reuse=[];pre={}
    for ident in [OLD_TEST/'identity.json',OLD_FRONT/'identity.json']:
        d=m.read(ident);changes=[]
        for old in d['dependencies']:
            path=Path(old['path'])
            if not path.exists() or m.pin(path)!=old:changes.append(dict(old=old,current=m.pin(path) if path.exists() else None))
        old_reuse.append(dict(identity=m.pin(ident),object=d['object'],reusable=not changes,changed_dependencies=changes))
        assert changes, 'Expected old cache to be rejected only by actual dependencies'
        for row in d['dependencies']:
            if Path(row['path']).exists():pre[m.key(row['path'])]=m.pin(row['path'])
    for row in m.read(EXE/'compile/executable/actual-dependencies.json'):
        pre[m.key(row['path'])]=m.pin(row['path'])
    for root in [R/'include',R/'src/graph',R/'src/compute',R/'tests/graph',R/'tests/compute']:
        for path in root.rglob('*.h'):pre[m.key(path)]=m.pin(path)
    for name,relative,recipe in specs:
        src=R/relative;pin=m.pin(src);out=W/'compile'/name
        snapshot=W/'source'/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(src.read_bytes())
        units.append(dict(name=name,source=pin,snapshot=m.pin(snapshot),recipe=m.pin(recipe),
                          command=command(m.read(recipe)['command'],src,out),object=str(out/'unit.obj')))
        pre[m.key(src)]=pin
    source_tests=[];current=set()
    for key,record in ti.items():
        if '/tests/' in key.replace('\\','/'):
            names=tests_in(record['data']['Source']);current|=names
            source_tests.append(dict(source=record['data']['Source'],object=record['object'],cases=sorted(names)))
    assert len(source_tests)==17
    added=set()
    for unit in units[1:]:
        names=tests_in(unit['source']['path']);assert not names&current,(names&current)
        assert not names&added;added|=names
    assert set(CASES)<=added
    assert not any(m.key(R/u['source']['path']) in ti for u in units[1:])
    env=environment();(W/'bin').mkdir(exist_ok=True)
    runtime=m.read(CLI/'runtime.json');cpu=runtime.get('native_cpu') or runtime.get('original_native_cpu')
    assert cpu;exact(cpu);alias=W/'bin'/Path(cpu['path']).name
    if not alias.exists():os.link(cpu['path'],alias)
    m.save(W/'environment.json',{k:env.get(k,'') for k in ('PATH','INCLUDE','LIB','LIBPATH')})
    m.save(W/'runtime.json',dict(original=m.pin(CLI/'runtime.json'),original_native_cpu=cpu,alias=m.pin(alias),PATH=env['PATH']))
    m.save(W/'precompile-dependencies.json',list(pre.values()))
    m.save(W/'build-plan.json',dict(status='FROZEN_NOT_BUILT',candidate=m.pin(W/'candidate.diff'),
        cli_baseline=m.pin(CLI/'cli-link-inputs-facts1.json'),cli_ready=m.pin(CLI/'ready-facts1.json'),
        test_baseline=m.pin(TEST/'test-link-inputs.json'),test_ready=m.pin(TEST/'ready.json'),
        original_executable=original,units=units,old_test_objects=old_reuse,
        test_registration_review=dict(existing_test_TUs=17,existing_source_cases=source_tests,added_cases=sorted(added),collision=[]),
        tests=CASES,precompile_dependencies=m.pin(W/'precompile-dependencies.json'),runtime=m.pin(W/'runtime.json'),
        counts=dict(CXX=3,links=2,cli_inputs=224,test_inputs=241,test_processes=1,selected_cases=5,SDK=0,NVCC=0,downloads=0),
        source_scope='Only product executable.cc changed; two old test objects rejected for 12/13 changed source/header pins. New tests use existing CPU+CUDA test compile contract.'))
    print('FROZEN 3 CXX, 2 links, 224 CLI / 241 component inputs; no duplicate selected names',flush=True)

def compile_unit(unit):
    exact(unit['source']);exact(unit['snapshot']);exact(unit['recipe'])
    out=Path(unit['object']).parent;out.mkdir(parents=True,exist_ok=False)
    pre={m.key(x['path']):x for x in m.read(W/'precompile-dependencies.json')}
    process=h.execute(unit['command'],environment(),W/'logs'/unit['name'],timeout=240)
    raw=m.read(out/'dependencies.json')['Data'];assert m.key(raw['Source'])==m.key(unit['source']['path'])
    deps=[m.pin(x) for x in dict.fromkeys([raw['Source'],*raw['Includes']])]
    for row in deps:
        before=pre.get(m.key(row['path']))
        if before:assert row==before,('dependency changed during compilation',row['path'])
        else:assert not Path(row['path']).resolve().is_relative_to(R),('unfrozen local dependency',row['path'])
    exact(unit['source']);m.save(out/'actual-dependencies.json',deps)
    result=dict(name=unit['name'],source=unit['source'],snapshot=unit['snapshot'],object=m.pin(unit['object']),
                command=m.pin(W/'logs'/unit['name']/'command.json'),compiler_dependencies=m.pin(out/'dependencies.json'),
                actual_dependencies=m.pin(out/'actual-dependencies.json'),process=process)
    m.save(out/'compiled.json',result);print('COMPILED '+unit['name'],flush=True);return result

def link(kind,compiled):
    plan=m.read(W/'build-plan.json')
    baseline=CLI/'cli-link-inputs-facts1.json' if kind=='cli' else TEST/'test-link-inputs.json'
    recipe=CLI/'link-cli-facts1/command.json' if kind=='cli' else TEST/'link/command.json'
    rows=m.read(baseline);old=plan['original_executable']['object']
    replacement={m.key(old['path']):compiled[0]['object']['path']}
    added=[x['object']['path'] for x in compiled[1:]]
    image=W/'bin'/('hyle.exe' if kind=='cli' else 'alias-component-test.exe')
    cmd=m.link_command(m.read(recipe)['command'],replacement,added,image)
    inputs=[compiled[0]['object'] if m.key(x['path']) in replacement else x for x in rows]+[x['object'] for x in compiled[1:]]
    assert len(inputs)==(224 if kind=='cli' else 241)
    for row in inputs:exact(row)
    for unit in compiled:
        exact(unit['source']);exact(unit['object'])
        for row in m.read(unit['actual_dependencies']['path']):exact(row)
    m.save(W/(kind+'-link-inputs.json'),inputs)
    process=h.execute(cmd,environment(),W/('link-'+kind),timeout=180)
    for row in inputs:exact(row)
    result=dict(image=m.pin(image),link=process,inputs=m.pin(W/(kind+'-link-inputs.json')),
                recipe=m.pin(W/('link-'+kind)/'command.json'),runtime=m.pin(W/'runtime.json'))
    m.save(W/('ready-'+kind+'.json'),result);print(kind.upper()+'_READY '+str(image)+' '+result['image']['sha256'],flush=True)

def graph():
    plan=m.read(W/'build-plan.json');unit=compile_unit(plan['units'][0]);link('cli',[unit])
def tests():
    plan=m.read(W/'build-plan.json');units=[m.read(W/'compile/executable/compiled.json')]
    units.extend(compile_unit(u) for u in plan['units'][1:]);link('test',units)
def run():
    ready=m.read(W/'ready-test.json');exact(ready['image'])
    for row in m.read(ready['inputs']['path']):exact(row)
    command=[ready['image']['path'],'--gtest_color=no','--gtest_filter='+':'.join(CASES),
             '--gtest_output=xml:'+str(W/'run/results.xml')]
    process=h.execute(command,environment(),W/'run',timeout=180)
    xml=W/'run/results.xml';root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
    actual=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    assert sorted(actual)==sorted(CASES) and len(cases)==5
    assert all(x.find('failure') is None and x.find('error') is None and x.find('skipped') is None for x in cases)
    m.save(W/'summary.json',dict(status='PASS',process=process,tests=actual,xml=m.pin(xml),
           CLI=m.pin(W/'ready-cli.json'),component=m.pin(W/'ready-test.json'),plan=m.pin(W/'build-plan.json'),
           counts=dict(CXX=3,links=2,test_processes=1,passed=5,skip=0,SDK=0,NVCC=0,model_processes=0),
           boundary='Only five directed host Graph cases; no GPU inference or performance run.'))
    print('PASS 5/5, 0 skip',flush=True)
if __name__=='__main__':
    try:{'freeze':freeze,'graph':graph,'tests':tests,'run':run}[sys.argv[1]]()
    except BaseException:
        (W/('failure-'+sys.argv[1]+'.log')).write_text(traceback.format_exc());raise
