"""Publish the completed bounded diagnostics; does not run a model."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

D = Path(__file__).resolve().parent
R = D.parents[1]
assert R.name == 'hyle'
P = R / 'docs/evidence/performance'
name = 'mtp-current-cost-attribution-2026-10-25'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    raw = p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

out, archive = P / (name + '.json'), P / (name + '.zip')
assert not out.exists() and not archive.exists()
structure = read(D / 'current-structure/analysis.json')
io = read(D / 'current-io/summary.json')
assert structure['status'] == 'completed' and io['state'] == 'two_formatter_diagnostic_processes_complete'
files = [Path(__file__), D / 'baseline/root-check.py', D / 'baseline/root-check.json']
for part in ('current-structure', 'current-io'):
    for p in (D / part).rglob('*'):
        if not p.is_file() or p.suffix in ('.exe', '.dll', '.obj', '.lib', '.exp', '.pdb', '.pyc', '.nsys-rep'):
            continue
        if p.name in ('live.json',) or '__pycache__' in p.parts:
            continue
        files.append(p)
reviews = [D / 'current-cuda' / p for p in ('candidate-review.md', 'replay-source-review.md', 'first-use-source-review.md')]
files += reviews
files = sorted(set(files))
cleanup = []
for part in ('current-cuda', 'current-io'):
    for suffix in ('hyle.exe', 'hyle.exp', 'hyle.lib', 'hyle_ggml_cpu_gdn_scale_v3.dll'):
        cleanup.append(pin(D / part / 'link' / suffix))
for arm in ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp'):
    for suffix in ('trace.nsys-rep', 'trace.sqlite'):
        cleanup.append(pin(D / 'current-structure' / arm / suffix))
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files:
        z.write(p, p.relative_to(R).as_posix())
record = dict(schema='hyle.performance.current-cost-attribution.v1',
    created_at=datetime.now(timezone.utc).isoformat(), date='2026-10-25',
    status='bounded_diagnostics_completed_with_profiler_limitations',
    baseline=pin(P / 'mtp-current-single-and-multiturn-2026-10-25.json'),
    throughput_evidence=False, memory_evidence=False, causal_speedup_claim=False,
    product_changes=0, HTTP=0, GPU_profiler_processes=4, formatter_diagnostic_processes=2,
    GPU_analysis=structure, formatter_diagnostic=io,
    root_review=[
        'Independent read-only check of all32 baseline process facts and published rate arithmetic passed. No reruns.',
        'First24 captured-target envelopes are not aligned to the same logical decode start. Peer early eager calls are explicitly retained, including1 target/2 draft before its first captured MTP target. Do not infer equal-start cold-engine latency from that table.',
        'Warm24 target envelopes both include24 target/23 draft for MTP, still different natural continuations and mathematical work. GPU activity unions are neither SM utilization nor directly recoverable time.',
        'Nsight reports driver13.4/tool13.3 mismatch and original graph identity query errors (MTP Hyle250,peer692). Activity/runtime correlations are readable but absolute event completeness and graph lineage are not certified. These limits do not affect the separate clean32-process TPS baseline.',
        'The13ms-class first Hyle target intervals include real draft activity; alloc API time is small, and nested driver/runtime times must not be added. Capture binding/permission/retirement checks remain necessary.',
        'Default step formatter alone costs about0.13ms/call in its private two-process check. This excludes entry logs and is not all host gap or a proof of attainable gain. Same text/order/work and original CLI object are retained.',
        'Source-only first-use and replay reviews identify conditional candidates, not measured attribution to individual allocators. No candidate is accepted merely for moving work from decode to ready.',
    ],
    next_bounded_work=[
        'Check actual source/follower metadata ownership before eliminating unused follower upload allocations; retain independent workspace, permission, budget and failure semantics.',
        'Inspect early capture-key misses against actual retired state-pool addresses. Do not increase caches, pin old authority or reopen rejected algorithms without new facts.',
        'Use current BF16 body shapes for further physical-work attribution; head is not established as the additional MTP gap in these traces.',
    ],
    source_reviews=[pin(p) for p in reviews], files=[pin(p) for p in files], archive=pin(archive),
    cleanup=dict(performed=False, files=cleanup, logical_bytes=sum(p['bytes'] for p in cleanup),
        retained='Canonical sources, raw diagnostics/SQLite in archive, cached weights/dependencies, current clean CLI/app OBJ and4 Graph objects retained. Nsight raw reports are converted duplicate artifacts.',
        requirement='Exact files only through repository test.ps1, preview before apply.'))
out.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=pin(out), archive=pin(archive), cleanup_files=len(cleanup), cleanup_bytes=record['cleanup']['logical_bytes'])))
