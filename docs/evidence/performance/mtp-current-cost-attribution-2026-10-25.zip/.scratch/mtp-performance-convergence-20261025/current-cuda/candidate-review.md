# 窄范围性能候选（只读；未编译／运行）

基于 current-cuda/summary.json 的原两条 greedy、N1/R1、prefix-off、同两轮输入诊断；源码 main SHA `9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9`。正在进行的无插桩32进程基线未被本检查触碰。

最后24次：ordinary prepare＋submit 10.0892ms/240.7286ms＝4.191%；MTP 14.4080ms/339.9769ms＝4.238%。finish 包含原 GPU Completion 等待、结果读回、状态完成和日志，绝不能把 finish 当 host 或用两个墙钟简单相减推 kernel 时间。私有诊断也不是 TPS 证据。

## 1. 优先拆“共同 target 工作”与 K1 真正新增工作

- 锚点：main `prepare_family:2197` 的 prefix_rows；`:2319` 的真实 NextN full_head、`:2512` 的 target scores；`mtp_graph.h::full_head:250–294` 的 draft scores；`finish_mtp_rounds:4268` 的实际接受边界。
- 已有工作量：ordinary 126 decode calls／126 verified target rows／126 decode 输出；K1 为66 calls／132 verified target rows／124 decode NextN rows／60 consumed drafts，同样126输出。接受60/66，不是“只跑了半个 target”。每交付输出的 target 验证行约1.048，另有约0.984 NextN行。
- 两者共用完整 target body 和原 head 精度。此源 V=248320、H=2048，原 BF16 tied head 为1,017,118,720B；每 head 输出行约0.993MB F32。ordinary 每次一行 head；K1 每次 target 两行＋draft 一行，decode head 行总数198对126。它是行／FLOP工作差异，不能按行数假定W重复读取三次或线性耗时。
- K1还必须保留两种合法 GDN／carry 前缀（而非ordinary一份），并维护真实draft KV/lag；这是当前算法的增量，不得删掉拒绝状态或改精度冒充优化。
- 后续区分方式：在现同一 baseline 的选中原生计划／GPU时间中，分别归 target body、target head、NextN body/head 和前缀状态输出；按实际verified/NextN/head行及实际交付输出归一。ordinary 同样慢是共同target/后端问题；MTP超出同target成本的部分才归增量。当前诊断不能证明某个kernel已是瓶颈。

## 2. 真实默认逐 episode stderr 观察，先量 flush 而非预设收益

- 锚点：main `run_generation_sessions:5474/5493` 的 generation_session/batch；`finish_selected_evaluations:4057` 先确定所有participant endpoint，随后 `observe_completed_evaluation:4346` 默认调用 formatter；`engine/reporting/execution_report.cc:10–27` 连续 ostream 插入。std::cerr 默认 unitbuf，存在逐字段同步 flush 的候选；formatter本轮只是移出，没有改变旧IO策略。
- 当前两诊断实际默认调用数：ordinary128、K1 68（分别含2prefill）；每次2条entry线＋2条step线，因此decode为504/264条默认线，不含最后统一输出的private_preparation。每call约45个 ostream 插入表达式，但实际底层write/flush次数和耗时未测，不能把表达式数等同系统调用数。
- entry线在当前prepare之前；step线在本次模型endpoint之后，除最后一个外落入下一连续endpoint间隔。故prepare＋submit的4.2%不能覆盖这部分，step_seconds也排除其自身的postcommitIO。
- peer不是静默对照：baseline/peer-ready.json固定同一 peer_multiturn.cc/image；旧同输入日志decode区间ordinary252条（124 graph reuse＋126 sampler debug等），K1 321条（116 graph reuse＋193 sampler debug等）。peer consumer本身只在turn边界打marker，后端内部也有逐调用日志；不能仅拿Hyle条数减peer条数估慢差。现32进程基线还未作为本报告结果读取。
- 有限私有诊断建议：基线全部结束后，只在同一输出接收方式下测这几个现有observer/entry写入区间及实际write/flush计数；可用保持相同文本、提交后顺序与错误传播的line-buffered诊断对照，不能靠禁日志直接宣称模型提速。ordinary每输出一次与K1每实际episode一次分别归一，避免把少打日志当作MTP数学收益。

## 3. 共同准备／完成中的同步小工作（明确上限与MTP增量）

- 锚点：main `prepare_evaluations:3690–3789` 每轮layout/append/state绑定、batch prepare、prepare_replay；MTP另走 `prepare_draft_append:3480`。最后24次 replay_prepare 累计ordinary3.8178ms、MTP5.5428ms，是现有准备子桶最大项；capture reused24与reused47/recorded1，绝大部分不是首次图编译。
- 同时 `finish_selected_evaluations:3851–3880` 先wait，再读原draft_id（仅K1）和next_id/prefix_candidates；`inference/readback.h:42` 到 `compute_backend_cuda/cuda_memory.cc:109–122` 为同步cuMemcpyDtoH。当前greedy每decode ordinary1次I32读回、K1 2次，即126次/504B对132次/792B；含prefill128次对134次。数据量很小，待量的是调用延迟，不是带宽，不能将整个finish算为这部分。
- 后续只分清原prepare_replay的CPU metadata／权限维护与driver等待，并分开completion.wait、scalar-read、状态提交：共同的一次read和target布局属于基础慢，K1多一次read、draft布局和双prefix绑定属于增量。不得跳过COW、alias、rearm、退休或接受前缀；当前主K1臂不执行 execute_draft/repair_recursive_draft，不能用递归K路径解释其慢。
- prepare＋submit当前仅约4.2%调用墙钟，不能单靠优化该桶解释大幅差距；也不能据此宣称其余95.8%全是GPU。只在以上真实边界量到成本后，才评估冷预留元数据或同权限小输出聚合，保持数学／dtype／额度／错误发布不变。

本检查只给以上3个可证伪候选。未改产品、日志策略或计时点；未运行GPU／编译／新增矩阵；未推出 llama.cpp 慢差的最终归因或任何可回收加速比例。
