# Current CUDA replay source review

Read-only finite pass, 2026-10-25. No product edits, compilation, GPU, model, profiler, HTTP or new validation matrix. Reviewed current `src/graph/executable.cc` SHA256 `8652cbd963069623860074e3bf874bb8574a31e27b1f3f6a945f7b37484b95bc`, with original resource/input-source helpers.

**Conclusion: no sufficiently supported, currently triggered replay deletion/optimization candidate found.** The measured153.45us ordinary /203.95us MTP medians are for the entire prepare_replay call, not any one source loop. They do not establish reclaimable CPU work or explain total decode differences. MTP/ordinary calls do different actual work; medians of sub-buckets cannot be added.

Actual warm work and why it remains:
- `executable.cc:9448-9572`: preparation admission, current Queue validity/open/context ownership and completion endpoints are checked before changing the usable route. A previously retained Queue/capture does not authorize a newly supplied Queue or an already closed endpoint.
- `:1455-1505`, called at`:9573`: bindings_prepared already avoids rebuilding spans; positive configuration_spans skips stable proven provider hooks. Remaining changed/unproven bindings preserve exact new ownership/configuration revisions. Replacing this with raw-address equality would reopen already resolved lifetime failures.
- `:1328-1339`: sealing the selected managed-slot regions is necessary even for unchanged TensorViews. A readonly native owner may escape without any address change; seal preserves the original retirement/held-reader gate. No unconditional seal skip is justified by capture reuse.
- `:1613-1663`, called at`:9577`: copy-route checks concern current source/destination ranges/resources, overlap/no-op and actual immediate/queued behavior. Current binding changes can alter those facts. A single-GPU label is not a transfer-route proof.
- `:1667-1750`, called at`:9581`, plus`:9584` and`:9595-9623`: actual dependency routing, input readiness and Queue completion-ring capacity remain distinct contracts. Reusing an old route would need current producer/Queue/policy and failure validation; no simple deletion preserves all of them.
- `:1135-1176` and`:9628-9641`: capture qualification is already cached by qualification_valid; warm preparations do not repeat the full qualification/port-reserve walk.
- `:9709-9757`: an already retained matching range skips recording. Dormant two-variant reuse checks the actual current physical tuple through`:1178-1201`. This is not evidence of per-call native graph instantiation or device recording. The tail counts ordinary0recorded/24reused, MTP1recorded/47reused are consistent with the existing bounded reuse path.
- `:9660-9675` and`:9854`: dependency/endpoint facts and capture spans are published only after preparation succeeds. Failure cannot expose an old recording with new or unproven bindings. Clearing/copying these small transaction records is not a proved dominant cost.

One genuine but unselected conditional redundancy:
- `input_sources.cc:238-338`: if an InputSourcesState was previously attached but now every source binding is empty, candidate.sources becomes empty; the code still scans all graph steps/input roots and outputs against empty roots. It could mark a valid empty candidate after the required zero ranges are initialized, preserving commit_input_sources/prepared_for semantics.
- The current Qwen BF16 consumer uses ordinary Tensor/ReadLease bindings and has no InputAccess::bind path that attaches InputSourcesState. Therefore`:243` already returns immediately here. This does not explain this window, and no implementation work is recommended for it now.

Stop point: no constant-view expansion, new cache/registry, permission/retirement weakening, or reopening historical AV/capture/Top1/MMVF/Lt/copy candidates. Root will first use the already planned four-arm current host/device traces to distinguish dominant work before selecting any code change.
