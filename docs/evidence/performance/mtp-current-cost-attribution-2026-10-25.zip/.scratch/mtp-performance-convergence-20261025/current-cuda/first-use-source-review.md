# K1 首次 decode：两项有界源码候选（只读）

依据现4条 trace/analysis 和原 hyle_mtp/native-stderr.log；未执行case、编译或修改产品。main仍为9b73fe9a…。

## 先排除错误路径

- 这条greedy K1主臂不是 execute_draft/repair_recursive_draft；输出记录 draft_program_graph_calls=0、prefix_decision_graph_calls=0、cold_exact_admissions=0。
- main:1085/1788 固定一个执行槽。prepare_child:3293 有按(R,T,role)缓存；initialize_slot:3258 已有效即返回；run_generation_sessions:5393–5398 在ready前已建立prefill和两种T2 K1角色的Phase/slot。实际stderr:18–25与此相符。不能把首3次13.964/11.274/8.682ms cold_batch归为第二slot创建或target重编译。
- 原Graph create_invocation（graph/executable.cc:8861–9140）已经实例化workspace、provider invocation与ggml native graph（ggml_cuda_provider.cc:915–941/1001）。首次真实布局前尚不能合法固化页绑定、原native attention计划和相应capture。
- root trace结果明确：warm MTP envelope空洞没有更大；问题集中早期。下面仅是减少实际创建/重录的候选，不主张单纯把成本挪到ready之前。

## 1. 首次真实地址/计划的capture，以及早期重录

**当前真选中。** 原日志mtp1/2/3均 hybrid、recorded2/reused0，mtp4录1复用1；mtp7/后续还有重录。图中两种K1 role均已准备，真实binding tuple和native batch计划才在main:3733–3771确定。

- Graph prepare_replay（executable.cc:9448、9553–9585）先证明绑定、transfer/dependency与input source；:9698–9825按range保留/匹配最多两个真实tuple；首次miss才encode/end。CUDA end_capture（compute_backend_cuda/cuda_backend.cc:1280–1348）先尝试退休seed的GraphExecUpdate，只有初次或结构不兼容才Instantiate。不是每次无条件实例化；现已有复用机制，不能把“加缓存”当新方案。
- ggml原native Invocation独立保backend、graph、workspace和pool（ggml_cuda_provider.cc:626–675/915）；bridge::initialize_backend只创建缓存pool对象，native stream/handle/临时buffer仍lazy（native_bridge_impl.h:23–32、AdmittedStreamScope）。record_on_admitted_stream:257借原queue且保捕获pool，首次encode确可分配/建立native状态；没有调用栈不能把trace每个Malloc都归给它。
- **有意义的最小减少路径**：只核早期miss的具体range与key究竟因真实页/plan拓扑变化，还是同一串行state池在空闲候选间挑了更多可等价复用的地址。若是后者，沿原pool的已退休空闲块优先复用既有两套合法tuple，可减少重录/instantiate和native暂存增长；不能固定写正在被base/旧reader/未接受prefix持有的块，也不能让不同role借同一个mutable Invocation。
- Program/静态常量已经被prepared executable共享；单纯重建同一invocation或提前空跑不减少工作。跨role强共享workspace/recording目前没有权限证明，不能直接做。trace只有alloc/instantiate时间关联，尚未证明key变化原因；先用现有binding/capture事实对齐早期事件即可，不需新模型矩阵。

## 2. 首次layout触发的原Batch程序/存储：共享已存在，仍有可消除的未用metadata分配

**实际 g::batch::prepare 路径真执行；每个trace分配的具体归属尚未逐个证明。** main:3749–3760将六target attention及一draft attention真实layout交同一准备。graph_batch/batch.cc:518–543在对应slot首次!reuse才创建BatchProgram/BatchInvocation，后续核schema/queue/options再复用；不是每step新建。compute_batch/batch_execution.cc:430–535首次实际layout才query/grow float/int/host workspace、上传元数据和原native plan；后续已有high-water与合法update（flashinfer_provider.cc:257–309/420），不能跳过真实拓扑变化。

- 同一target layout/metadata-port/resource的各层已经由batch.cc:470–482/538选metadata_source并prepare_shared，复用一次已准备的metadata lease；不是重新提议一个模型层“所有层共享计划”。draft layout可不同，不能一起混用。
- **具体冗余候选**：BatchInvocation::create（batch_execution.cc:400–418）在是否使用prepare_shared尚未知时，为每slot都建立自己的mirror/staging池和初始化；prepare_shared:430–444随后实际借source metadata，不使用follower自己的上传mirror/staging。若本次选中确为这些同metadata target slots，按既有source/follower事实延迟创建follower未使用的上传存储，必要转为独立source时再受原预算/失败门禁创建，可真正减少首次分配和初始化，而不是只挪计时。
- 不建议本轮合并每层独立float/int workspace或native plan：这些是capture稳定地址及可能在途资源，BatchProgram可共享不等于mutable workspace可任意alias。可先保全部原invocation/plan/计算，最小只消除明确未用的metadata上传backing。当前未取得逐slot原report或分配调用栈，故该减少量仍是条件性候选，不写成已测主因/已支持优化。

本审查不更改状态权限、精度、已选原kernel、实际页/接受/RNG、退休或预算。ready前追加空跑只改变计时归属，不作为上述两项的收益证明；也不把warm差异误归本次first-use。
