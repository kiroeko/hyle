from pathlib import Path
import json,re,statistics,importlib.util,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=R/'.scratch/mtp-performance-convergence-20261025/current-io';B=D.parent/'baseline'
spec=importlib.util.spec_from_file_location('formatter_helpers',R/'.scratch/inference-batch-indices-20261024/regression/check.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
results={}
def stable(v):
 if isinstance(v,dict):return{k:stable(x)for k,x in v.items()if k!='seconds'and not k.endswith('_seconds')and'tokens_per_second'not in k}
 if isinstance(v,list):return[stable(x)for x in v]
 return v
for arm,previous in [('hyle_plain','01-hyle_plain'),('hyle_mtp','02-hyle_mtp')]:
 folder=D/arm;prior=B/'two-turn-timing'/previous
 raw=json.loads(next(s for s in(folder/'stdout.log').read_text().splitlines()if s.startswith('{')));old=json.loads(next(s for s in(prior/'stdout.log').read_text().splitlines()if s.startswith('{')))
 assert raw['generated_tokens']==128 and raw['prefill_target_rows']==309 and stable(old)==stable(raw)
 stderr=(folder/'stderr.log').read_text();lines=stderr.splitlines();header=next(s for s in lines if s.startswith('private_step_io '));facts={k:int(v)for k,v in(w.split('=',1)for w in header.split()[1:])}
 samples=[{k:int(v)for k,v in(w.split('=',1)for w in s.split()[1:])}for s in lines if s.startswith('private_step_io_sample ')];assert facts['overflow']==0 and len(samples)==facts['count']and sum(s['ns']for s in samples)==facts['total_ns']
 assert facts['count']==(128 if arm=='hyle_plain'else 68)
 assert [s['index']for s in samples]==list(range(len(samples)))
 prefix=stderr.split('private_step_io ',1)[0];(folder/'original-IO.stderr.log').write_text(prefix,encoding='utf-8')
 assert f.formatters(folder/'original-IO.stderr.log')==f.formatters(prior/'stderr.log')
 durations=[s['ns']for s in samples];tail=durations[-24:]
 def stat(v):return dict(count=len(v),total_ns=sum(v),median_ns=statistics.median(v),min_ns=min(v),max_ns=max(v),values_ns=v)
 result=dict(process=json.loads((folder/'process.json').read_text()),all=stat(durations),last24=stat(tail),samples=samples,original_stderr_format_and_non_time_field_order_equal=True,all_non_time_report_fields_and_IDs_work_equal=True,measured_scope='Only complete original write_step_observation body + two clock calls/guard envelope. End timestamp precedes POD append; private fprintf records happen after CLI returns. Does not count all driver/report/queue gaps or actual OS write/flush invocations.',actual_OS_write_calls=None,actual_flush_calls=None)
 results[arm]=result
summary=dict(state='two_formatter_diagnostic_processes_complete',image=json.loads((D/'ready.json').read_text()),source=json.loads((D/'source-pins.json').read_text()),arms=results,model_or_math_changes=0,product_changes=0,SDK_builds=0,HTTP=0,throughput_evidence=False,limits=['Only one two-turn process per Hyle mode. No new formal TPS window, statistical speedup or GPU profile.','Default stream policy/body/order/flags preserved. OS write/flush counts not instrumented.','Do not subtract this duration from finish or interpret it as total host gap; original per-step IO endpoint accounting remains.'])
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps({arm:{k:{f:v for f,v in row[k].items()if f!='values_ns'}for k in ['all','last24']}for arm,row in results.items()},indent=2))
