#include "execution_report.h"

#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <iomanip>
#include <ostream>

#include "../inference/execution_observation.h"

namespace hyle::engine::reporting {

namespace {
struct PrivateIoSample { std::uint64_t nanoseconds=0; std::size_t input_tokens=0,visible=0; };
struct PrivateIoSamples {
  std::array<PrivateIoSample,1024> values{};
  std::size_t count=0,overflow=0;
  std::uint64_t total_nanoseconds=0;
  ~PrivateIoSamples() noexcept {
    std::fprintf(stderr,"private_step_io count=%zu overflow=%zu total_ns=%llu after_cli_return=1 throughput_evidence=0\n",count,overflow,static_cast<unsigned long long>(total_nanoseconds));
    const auto size=count<values.size()?count:values.size();
    for(std::size_t i=0;i<size;++i){const auto &sample=values[i];
      std::fprintf(stderr,"private_step_io_sample index=%zu ns=%llu input_tokens=%zu visible=%zu\n",i,static_cast<unsigned long long>(sample.nanoseconds),sample.input_tokens,sample.visible);
    }
  }
};
PrivateIoSamples private_io_samples;
struct PrivateIoGuard {
  std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
  std::size_t input_tokens=0,visible=0;
  ~PrivateIoGuard() noexcept {
    const auto elapsed=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count());
    private_io_samples.total_nanoseconds+=elapsed;
    const auto index=private_io_samples.count++;
    if(index<private_io_samples.values.size())private_io_samples.values[index]={elapsed,input_tokens,visible};
    else ++private_io_samples.overflow;
  }
};
} // namespace

void write_step_observation(std::ostream &output, const inference::StepObservation &step) {
  PrivateIoGuard private_guard{std::chrono::steady_clock::now(),step.input_tokens,step.visible};
  if (step.prefix_hit)
    output << "prefix_hit name=" << step.name << " reused_tokens=" << step.reused_tokens
              << " graph_calls=" << step.graph_executed << " visible=" << step.visible << '\n';
  if (step.graph_executed) output << "prepared T=" << (step.graph_input_tokens ? step.graph_input_tokens : step.input_tokens) << " visible=" << step.visible
            << " replay=" << (step.replay_route == graph::ReplayRoute::kCaptured ? "captured"
                : step.replay_route == graph::ReplayRoute::kHybrid ? "hybrid" : "commands")
            << " cold_batch_seconds=" << step.cold_batch_seconds
            << " capture_recorded=" << step.capture_recorded
            << " capture_reused=" << step.capture_reused << '\n';
  output << step.name << " tokens=" << step.input_tokens << " visible=" << step.visible
            << " seconds=" << step.seconds << " submit_seconds=" << step.submit_seconds
            << " step_seconds=" << step.step_seconds
            << " progress=" << (step.scheduled_progress ? "scheduler" : "direct")
            << " next=" << step.next << '\n';
}
void write_preparation_observation(std::ostream &output, const inference::StepObservation &step,
                                   const inference::PreparationObservation &preparation) {
  const auto precision = output.precision();
  output << std::setprecision(17)
            << "preparation name=" << step.name << " tokens=" << step.input_tokens
            << " visible=" << step.visible << " slot=" << preparation.slot
            << " phase_slot_prior_uses=" << preparation.phase_slot_prior_uses
            << " native_plan_first_use=" << (preparation.phase_slot_prior_uses == 0)
            << " layout_seconds=" << preparation.layout_seconds
            << " batch_prepare_seconds=" << preparation.batch_prepare_seconds
            << " replay_prepare_seconds=" << preparation.replay_prepare_seconds
            << " report_snapshot_seconds=" << preparation.report_snapshot_seconds
            << " snapshot_after_host_endpoint=1\n";
  for (std::size_t i = 0; i < preparation.reports.size(); ++i) {
    const auto &report = preparation.reports[i];
    const auto &upload = report.metadata_upload;
    output << "batch_plan name=" << step.name << " attention_index=" << i
              << " node=" << preparation.nodes[i].ordinal() << " slot=" << preparation.slot
              << " layout_generation=" << report.layout_generation
              << " metadata_staging_bytes=" << report.metadata_staging_bytes
              << " float_workspace_bytes=" << report.float_workspace_bytes
              << " int_workspace_bytes=" << report.int_workspace_bytes
              << " cta_tile_q=" << report.cta_tile_q
              << " padded_batch_size=" << report.padded_batch_size
              << " split_kv=" << report.split_kv
              << " native_metadata_unknown=" << report.native_metadata_unknown
              << " capture_compatible=" << report.capture_compatible
              << " bf16_partials=" << report.bf16_partials
              << " reused_native_plan=" << report.reused_native_plan
              << " host_waits=" << report.host_waits
              << " upload_resources=" << upload.resources << " upload_copies=" << upload.copies
              << " upload_active_copies=" << upload.active_copies << " upload_phases=" << upload.phases
              << " upload_no_op_copies=" << upload.no_op_copies
              << " upload_logical_bytes=" << upload.logical_bytes
              << " upload_physical_bytes=" << upload.physical_bytes
              << " upload_staging_bytes=" << upload.staging_bytes
              << " upload_metadata_bytes=" << upload.metadata_bytes
              << " upload_native_calls=" << upload.native_calls
              << " upload_native_waits=" << upload.native_waits
              << " upload_phase_completions=" << upload.phase_completions
              << " upload_host_waits=" << upload.host_waits
              << " upload_native_metadata_unknown=" << upload.native_metadata_unknown << '\n';
  }
  output.precision(precision);
}

} // namespace hyle::engine::reporting
