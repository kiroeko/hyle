from pathlib import Path
import importlib.util,json,os,sys,difflib
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2];B=D.parent/'baseline';C=D.parent/'current-cuda'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def args(p):
 j=b.read(p);return j.get('command',j)if isinstance(j,dict)else j

def prepare():
 src=R/'engine/reporting/execution_report.cc';original=src.read_text();include='#include <array>\n#include <chrono>\n#include <cstdint>\n#include <cstdio>\n'
 observer='''
namespace {
struct PrivateIoSample { std::uint64_t nanoseconds=0; std::size_t input_tokens=0,visible=0; };
struct PrivateIoSamples {
  std::array<PrivateIoSample,1024> values{};
  std::size_t count=0,overflow=0;
  std::uint64_t total_nanoseconds=0;
  ~PrivateIoSamples() noexcept {
    std::fprintf(stderr,"private_step_io count=%zu overflow=%zu total_ns=%llu after_cli_return=1 throughput_evidence=0\\n",count,overflow,static_cast<unsigned long long>(total_nanoseconds));
    const auto size=count<values.size()?count:values.size();
    for(std::size_t i=0;i<size;++i){const auto &sample=values[i];
      std::fprintf(stderr,"private_step_io_sample index=%zu ns=%llu input_tokens=%zu visible=%zu\\n",i,static_cast<unsigned long long>(sample.nanoseconds),sample.input_tokens,sample.visible);
    }
  }
};
PrivateIoSamples private_io_samples;
struct PrivateIoGuard {
  std::chrono::steady_clock::time_point start=std::chrono::steady_clock::now();
  std::size_t input_tokens=0,visible=0;
  ~PrivateIoGuard() noexcept {
    const auto elapsed=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-start).count());
    private_io_samples.total_nanoseconds+=elapsed;
    const auto index=private_io_samples.count++;
    if(index<private_io_samples.values.size())private_io_samples.values[index]={elapsed,input_tokens,visible};
    else ++private_io_samples.overflow;
  }
};
} // namespace
'''
 anchor='namespace hyle::engine::reporting {\n';assert original.count(anchor)==1
 text=original.replace('#include <iomanip>\n',include+'#include <iomanip>\n',1).replace(anchor,anchor+observer,1)
 fn='void write_step_observation(std::ostream &output, const inference::StepObservation &step) {\n';guard='  PrivateIoGuard private_guard{std::chrono::steady_clock::now(),step.input_tokens,step.visible};\n';assert text.count(fn)==1;text=text.replace(fn,fn+guard,1)
 restored=text.replace(include,'',1).replace(observer,'',1).replace(guard,'',1);assert restored==original
 (D/'execution_report.cc').write_text(text,encoding='utf-8');(D/'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='canonical/execution_report.cc',tofile='private/execution_report.cc')),encoding='utf-8')
 b.save(D/'source-pins.json',dict(canonical=b.pin(src),overlay=b.pin(D/'execution_report.cc'),patch=b.pin(D/'source.patch'),original_body_and_order_identical_after_removing_private_hook=True,capacity=1024,hot_allocation=False,IO_policy_changed=False,scope='Only original write_step_observation scope timed; original insertion/flags/order unchanged. POD sample writes follow end timestamp; destructor fprintf after main/CLI return. No actual OS write/flush instrumentation or TPS claim.'))

def build():
 original=args(B/'compile/command.json');cmd=[original[0]];skip=False
 for w in original[1:]:
  if skip:skip=False;continue
  if w=='/sourceDependencies':skip=True;continue
  low=w.lower().replace('\\','/')
  if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
  cmd.append(w)
 cmd+=['/I'+str(R/'engine/reporting'),str(D/'execution_report.cc'),'/sourceDependencies',str(D/'compile/dependencies.json'),'/Fo'+str(D/'compile/unit.obj')]
 assert all(len(w)>1 for w in cmd);assert[w for w in cmd if w.lower().endswith(('.cc','.cpp'))]==[str(D/'execution_report.cc')]
 b.execute(cmd,D/'compile',b.environment(cmd[0]),120)
 deps=[Path(p).resolve()for p in b.read(D/'compile/dependencies.json')['Data']['Includes']];b.save(D/'compile/source-pins.json',[b.pin(p)for p in deps if p.is_relative_to(R)])
 old=str(C/'report/unit.obj');link=args(B/'link/command.json');assert link.count(old)==1
 link=[str(D/'compile/unit.obj')if w==old else w for w in link if not w.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))];link+=['/OUT:'+str(D/'link/hyle.exe')]
 b.execute(link,D/'link',b.environment(link[0]),120);os.link(B/'link/hyle_ggml_cpu_gdn_scale_v3.dll',D/'link/hyle_ggml_cpu_gdn_scale_v3.dll')
 b.save(D/'ready.json',dict(image=b.pin(D/'link/hyle.exe'),reused_clean_application_object=b.pin(B/'compile/unit.obj'),changed_TUs=1,source=b.read(D/'source-pins.json'),clean_baseline=b.pin(B/'ready.json'),runtime=b.read(B/'ready.json')['runtime_environment'],SDK_builds=0,HTTP=0))

def run(mode):
 assert mode in('plain','mtp');name='hyle_'+mode;previous='01-hyle_plain'if mode=='plain'else'02-hyle_mtp';ready=b.read(D/'ready.json');baseline=b.read(B/'two-turn-timing'/previous/'command.json');cmd=baseline['command'][:];cmd[0]=ready['image']['path'];assert not(D/name).exists()
 env=dict(os.environ,PATH=str(D/'link')+';'+b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 b.execute(cmd,D/name,env,180)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='run':run(sys.argv[2])
 else:globals()[action]()
