from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,os,subprocess,time
S=Path(__file__).resolve().parent;B=S.parent/'baseline';R=S.parents[2]
NSYS=Path('C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):
 with p.open('x',encoding='utf-8')as f:json.dump(x,f,indent=2);f.write('\n')
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def main():
 assert NSYS.is_file();save(S/'batch.json',dict(started_at=datetime.now(timezone.utc).isoformat(),script=pin(Path(__file__).resolve()),profiler=pin(NSYS),baseline=pin(B/'publication.json'),arms=['hyle_plain','hyle_mtp','peer_plain','peer_mtp'],throughput_evidence=False,memory_evidence=False,background_model_downloads=False,SDK_builds=0,HTTP=0))
 for arm,previous in [('hyle_plain','01-hyle_plain'),('hyle_mtp','02-hyle_mtp'),('peer_plain','03-peer_plain'),('peer_mtp','04-peer_mtp')]:
  out=S/arm;out.mkdir(exist_ok=False)
  record=B/'two-turn-timing'/previous/'command.json';original=read(record);native=original['command'][:];image=Path(native[0]);actual=pin(image)
  assert all(actual[k]==original['image'][k]for k in('bytes','sha256'))
  if'--output'in native:native[native.index('--output')+1]=str(out/'consumer-result.json')
  ready=read(B/('ready.json'if arm.startswith('hyle')else'peer-ready.json'));runtime=Path(ready['runtime_environment']['path']);assert pin(runtime)==ready['runtime_environment']
  env=dict(os.environ,PATH=read(runtime)['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
  cmd=[str(NSYS),'profile','--trace=cuda,cublas','--cuda-graph-trace=node','--sample=none','--cpuctxsw=none','--discard-environment=true','--duration=20','--stats=false','--export=sqlite','--output='+str(out/'trace'),*native]
  plan=dict(command=cmd,cwd=str(R),source_command=str(record),source_command_pin=pin(record),image=original['image'],runtime=ready['runtime_environment'],profiler=True,throughput_evidence=False,memory_evidence=False,background_model_downloads=False,purpose='Current four-arm actual two-turn node structure only. Captured and eager activities must both be counted; profile wall times are not TPS.')
  save(out/'command.json',plan);start=time.time();utc=datetime.now(timezone.utc).isoformat();print('PROFILE_BEGIN',arm,utc,flush=True);timed_out=False
  with(out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
   process=subprocess.Popen(cmd,cwd=R,env=env,stdout=stdout,stderr=stderr);save(out/'live.json',dict(pid=process.pid,started=start,started_at=utc,**plan))
   try:status=process.wait(timeout=120)
   except subprocess.TimeoutExpired:
    timed_out=True;subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);status=process.wait(timeout=15)
  save(out/'process.json',dict(exit=status,timed_out=timed_out,started=start,started_at=utc,elapsed=time.time()-start,finished_at=datetime.now(timezone.utc).isoformat(),**plan));print('PROFILE_END',arm,status,timed_out,flush=True)
  if status or timed_out:raise SystemExit(status or 1)
if __name__=='__main__':main()
