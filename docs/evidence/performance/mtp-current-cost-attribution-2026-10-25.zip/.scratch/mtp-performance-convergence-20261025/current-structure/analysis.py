"""Bounded read-only four-arm analysis, adapted from current-structure1/analyze.py.

No execution, export, trace mutation, publication, or cross-process clock arithmetic.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics

S = Path(__file__).resolve().parent
R = S.parents[2]
ARMS = ('hyle_plain', 'hyle_mtp', 'peer_plain', 'peer_mtp')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pin(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def merged(intervals):
    out = []
    for start, end in sorted(intervals):
        if end < start:
            raise ValueError('Negative interval')
        if out and start <= out[-1][1]:
            out[-1][1] = max(out[-1][1], end)
        else:
            out.append([start, end])
    return out


def interval_summary(intervals, window=None):
    if window is None:
        if not intervals:
            return dict(events=0, activity_ns=0, busy_union_ns=0)
        window = (min(a for a, b in intervals), max(b for a, b in intervals))
    start, end = window
    clipped = [(max(a, start), min(b, end)) for a, b in intervals if a < end and b > start]
    union = merged(clipped)
    gaps = []
    cursor = start
    for a, b in union:
        if a > cursor:
            gaps.append((cursor, a))
        cursor = max(cursor, b)
    if cursor < end:
        gaps.append((cursor, end))
    busy = sum(b-a for a, b in union)
    return dict(events=len(clipped), window_start_ns=start, window_end_ns=end,
                span_ns=end-start, activity_ns=sum(b-a for a, b in clipped),
                busy_union_ns=busy, unoccupied_ns=end-start-busy,
                busy_fraction=busy/(end-start) if end > start else None,
                merged_intervals=len(union), gap_count=len(gaps),
                largest_gaps=[dict(begin_from_window_ns=a-start, duration_ns=b-a)
                              for a, b in sorted(gaps, key=lambda pair: pair[1]-pair[0], reverse=True)[:8]])


def kernel_class(name):
    if any(key in name for key in ('mul_mat', 'gemv', 'gemm', 'cutlass::Kernel')):
        return 'matrix_contraction'
    if any(key in name for key in ('gated_delta', 'conv_')):
        return 'recurrent_convolution'
    if any(key in name for key in ('cub::', 'top_k', 'argmax')):
        return 'selection_reduction'
    if any(key in name for key in ('convert_', 'cpy_', 'copy_', 'concat_')):
        return 'conversion_layout_copy_kernel'
    if any(key in name for key in ('norm_', 'rms_norm')):
        return 'normalization'
    return 'other'


def kernel_groups(rows, names, limit=8):
    groups = defaultdict(lambda: [0, 0])
    for row in rows:
        key = (names[row[4]], row[5], row[6], row[7])
        groups[key][0] += 1
        groups[key][1] += row[1]-row[0]
    return [dict(kernel=key[0], grid=list(key[1:]), count=value[0], activity_ns=value[1],
                 class_name=kernel_class(key[0]))
            for key, value in sorted(groups.items(), key=lambda item: item[1][1], reverse=True)[:limit]]


def classified(rows, names):
    out = defaultdict(lambda: dict(count=0, activity_ns=0))
    for row in rows:
        value = out[kernel_class(names[row[4]])]
        value['count'] += 1
        value['activity_ns'] += row[1]-row[0]
    return dict(out)


def copy_summary(rows, copy_names):
    groups = defaultdict(lambda: dict(count=0, bytes=0, activity_ns=0))
    for start, end, cid, kind, size, node in rows:
        item = groups[copy_names[kind]]
        item['count'] += 1
        item['bytes'] += size
        item['activity_ns'] += end-start
    return dict(groups)


def role_for(arm, count):
    allowed = {'hyle_plain': {591: 'target'}, 'hyle_mtp': {738: 'target', 37: 'draft', 41: 'draft'},
               'peer_plain': {558: 'target', 564: 'target'}, 'peer_mtp': {727: 'target', 34: 'draft'}}
    if count not in allowed[arm]:
        raise ValueError(f'Unexpected graph signature {arm}/{count}; do not silently classify')
    return allowed[arm][count]


def one(arm):
    folder = S / arm
    if not (folder / 'process.json').is_file():
        return dict(status='pending')
    process = read(folder / 'process.json')
    if process['exit'] or process['timed_out']:
        raise ValueError(f'{arm}: non-success terminal process')
    raw = (json.loads(next(line for line in (folder / 'native-stdout.log').read_text(encoding='utf-8').splitlines()
                           if line.startswith('{'))) if arm.startswith('hyle') else read(folder / 'consumer-result.json'))
    db = sqlite3.connect('file:' + (folder / 'trace.sqlite').as_posix() + '?mode=ro', uri=True)
    names = dict(db.execute('SELECT id,value FROM StringIds'))
    copy_names = {row[0]: row[2] for row in db.execute('SELECT * FROM ENUM_CUDA_MEMCPY_OPER')}
    # Eager kernels are NULL graphId in these exports; COALESCE is essential.
    kernels = db.execute('SELECT start,end,correlationId,COALESCE(graphId,0),demangledName,gridX,gridY,gridZ '
                         'FROM CUPTI_ACTIVITY_KIND_KERNEL ORDER BY start').fetchall()
    copies = db.execute('SELECT start,end,correlationId,copyKind,bytes,graphNodeId '
                        'FROM CUPTI_ACTIVITY_KIND_MEMCPY ORDER BY start').fetchall()
    memsets = db.execute('SELECT start,end,correlationId,bytes,graphNodeId '
                         'FROM CUPTI_ACTIVITY_KIND_MEMSET ORDER BY start').fetchall()
    calls = db.execute('SELECT r.start,r.end,r.correlationId,s.value,r.returnValue '
                       'FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId ORDER BY r.start').fetchall()
    launch_calls = [row for row in calls if row[3].startswith('cudaGraphLaunch')]
    by_cid = defaultdict(list)
    copies_by_cid = defaultdict(list)
    memset_by_cid = defaultdict(list)
    for row in kernels:
        by_cid[row[2]].append(row)
    for row in copies:
        copies_by_cid[row[2]].append(row)
    for row in memsets:
        memset_by_cid[row[2]].append(row)
    launch_rows = []
    role_rows = defaultdict(list)
    for start, end, cid, api, returned in launch_calls:
        kr = by_cid[cid]
        if returned or not kr or any(row[3] == 0 for row in kr):
            raise ValueError('Unresolved/failed captured graph launch')
        role = role_for(arm, len(kr))
        role_rows[role].extend(kr)
        cr, mr = copies_by_cid[cid], memset_by_cid[cid]
        intervals = [(row[0], row[1]) for row in kr+cr+mr]
        first, last = min(a for a, b in intervals), max(b for a, b in intervals)
        launch_rows.append(dict(role=role, kernel_count=len(kr), correlation_id=cid,
                               api_start_ns=start, api_end_ns=end, first_activity_ns=first, last_activity_ns=last,
                               kernel_activity_ns=sum(row[1]-row[0] for row in kr),
                               activity=interval_summary(intervals), copies=copy_summary(cr, copy_names),
                               gpu_after_api_end_ns=first-end))
    buckets = []
    for role, count in sorted({(row['role'], row['kernel_count']) for row in launch_rows}):
        rows = [row for row in launch_rows if row['role'] == role and row['kernel_count'] == count]
        kinds = sorted({kind for row in rows for kind in row['copies']})
        buckets.append(dict(role=role, kernels=count, launches=len(rows),
                            median_kernel_activity_ns=statistics.median(row['kernel_activity_ns'] for row in rows),
                            median_gpu_span_ns=statistics.median(row['activity']['span_ns'] for row in rows),
                            median_gpu_busy_union_ns=statistics.median(row['activity']['busy_union_ns'] for row in rows),
                            median_within_graph_unoccupied_ns=statistics.median(row['activity']['unoccupied_ns'] for row in rows),
                            copies={kind: {metric: statistics.median(row['copies'].get(kind, {}).get(metric, 0) for row in rows)
                                           for metric in ('count', 'bytes', 'activity_ns')} for kind in kinds}))
    all_intervals = [(row[0], row[1]) for row in kernels+copies+memsets]
    captured = [row for row in kernels if row[3]]
    eager = [row for row in kernels if not row[3]]
    target_launches = [row for row in launch_rows if row['role'] == 'target']
    first_target_kernel = min(row[0] for row in role_rows['target'])
    before_kernels = [row for row in kernels if row[1] <= first_target_kernel]
    before_calls = [row for row in calls if row[1] <= first_target_kernel]
    before_target = dict(boundary='first captured target kernel start, own process clock',
                         boundary_ns=first_target_kernel,
                         eager_kernel_count=sum(row[3] == 0 for row in before_kernels),
                         captured_kernel_count=sum(row[3] != 0 for row in before_kernels),
                         completed_runtime_api_count=len(before_calls),
                         runtime_api_counts=dict(Counter(row[3] for row in before_calls)),
                         crossing_runtime_api_count=sum(row[0] < first_target_kernel < row[1] for row in calls),
                         observed_eager_head_signatures=kernel_groups(
                             [row for row in before_kernels if not row[3]
                              and (row[5] in (62080, 248320, 7760) or row[6] == 1940)], names),
                         observed_eager_head_sequence=[dict(start_ns=start, end_ns=end, stream=stream,
                                                            grid=[x, y, z], kernel=name)
                             for start, end, stream, x, y, z, name in db.execute(
                                 'SELECT k.start,k.end,k.streamId,k.gridX,k.gridY,k.gridZ,s.value '
                                 'FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName '
                                 'WHERE COALESCE(k.graphId,0)=0 AND k.end<=? '
                                 'AND (k.gridX IN (62080,248320,7760) OR k.gridY=1940) ORDER BY k.start',
                                 (first_target_kernel,))],
                         note='Includes load/preparation/prefill; API count includes any first-target launch API already returned. Not assigned a synthetic logical decode-start timestamp.')
    if arm.startswith('peer'):
        before_target['consumer_source'] = pin(R/'.scratch/qwen-mtp-final-window-20261024/source/peer_multiturn.cc')
        before_target['source_order_interpretation'] = (
            '1 of3 uncaptured target decode calls and2 of11 uncaptured draft decode calls precede the first captured target. '
            'Observed head sequence: target stream14 T1 prefill, draft stream15 T1, target stream14 T2, draft stream15 T1. '
            'Frozen consumer draft prefill has no output/head and each decode round runs draft before target; no exact call timestamps are fabricated.'
            if arm == 'peer_mtp' else
            '1 of2 uncaptured target decode calls precedes first captured target, in addition to prefill. Two eager T1 head kernels are observed before this boundary.')
    warm_start = target_launches[-24]['first_activity_ns']
    warm_end = target_launches[-1]['last_activity_ns']
    warm_window = warm_start, warm_end
    warm_launches = [row for row in launch_rows if row['first_activity_ns'] >= warm_start and row['last_activity_ns'] <= warm_end]
    kernel_window = min(row[0] for row in kernels), max(row[1] for row in kernels)
    # Whole first/last-kernel envelope includes cold preparation and second prefill.
    # It is deliberately not called the decode endpoint interval.
    warm = interval_summary(all_intervals, warm_window)
    warm['label'] = 'last24_captured_target_launch_envelope_not_equal_complete_decode_calls'
    warm['captured_roles'] = dict(Counter(row['role'] for row in warm_launches))
    warm['kernels'] = dict(Counter('captured' if row[3] else 'eager' for row in kernels if warm_start <= row[0] and row[1] <= warm_end))
    warm['copies'] = copy_summary([row for row in copies if warm_start <= row[0] and row[1] <= warm_end], copy_names)
    warm['runtime_api_counts'] = dict(Counter(row[3] for row in calls if warm_start <= row[0] < warm_end))
    warm['target_top_kernels'] = kernel_groups([row for row in role_rows['target'] if warm_start <= row[0] and row[1] <= warm_end], names)
    warm['gaps_between_target_activity_envelopes_ns'] = [right['first_activity_ns']-left['last_activity_ns']
                                                       for left, right in zip(target_launches[-24:], target_launches[-23:])]
    early_window = target_launches[0]['first_activity_ns'], target_launches[23]['last_activity_ns']
    early = interval_summary(all_intervals, early_window)
    early['label'] = 'first24_captured_target_launch_envelope_includes_first_use_not_entire_decode'
    early['captured_roles'] = dict(Counter(row['role'] for row in launch_rows
                                          if early_window[0] <= row['first_activity_ns'] and row['last_activity_ns'] <= early_window[1]))
    early['first10_target_gaps'] = [dict(after_target=i+1, duration_ns=right['first_activity_ns']-left['last_activity_ns'],
                                    first_use_api_counts=dict(Counter(row[3] for row in calls
                                        if left['last_activity_ns'] <= row[0] < right['first_activity_ns']
                                        and ('Alloc' in row[3] or 'Instantiate' in row[3]))))
                                  for i, (left, right) in enumerate(zip(target_launches[:10], target_launches[1:11]))]
    early['largest2_inter_target_gaps'] = []
    for ordinal, left, right in sorted(((i+1, left, right) for i, (left, right) in
                                        enumerate(zip(target_launches[:23], target_launches[1:24]))),
                                       key=lambda item: item[2]['first_activity_ns']-item[1]['last_activity_ns'], reverse=True)[:2]:
        gap = left['last_activity_ns'], right['first_activity_ns']
        api_groups = defaultdict(list)
        for start, end, cid, api, returned in calls:
            if start < gap[1] and end > gap[0]:
                api_groups[api].append((max(start, gap[0]), min(end, gap[1])))
        ordered = sorted(api_groups, key=lambda api: sum(b-a for a, b in api_groups[api]), reverse=True)
        selected = set(ordered[:12]) | {api for api in ordered if 'Alloc' in api or 'Instantiate' in api}
        early['largest2_inter_target_gaps'].append(dict(
            after_target_ordinal=ordinal, before_target_ordinal=ordinal+1,
            activity=interval_summary(all_intervals, gap),
            cuda_api_union_ns=sum(b-a for a, b in merged([pair for pairs in api_groups.values() for pair in pairs])),
            api_categories=[dict(api=api, calls=len(api_groups[api]),
                                 clipped_activity_ns=sum(b-a for a, b in api_groups[api]),
                                 clipped_union_ns=sum(b-a for a, b in merged(api_groups[api])))
                            for api in ordered if api in selected],
            note='Runtime and driver API intervals can nest. Per-category sums must not be added; GPU activity can overlap API time. This inter-target window includes the intervening real draft.'))
    totals = dict(kernel_count=len(kernels), captured_kernel_count=len(captured), eager_kernel_count=len(eager),
                  kernel_activity_ns=sum(row[1]-row[0] for row in kernels),
                  captured_kernel_activity_ns=sum(row[1]-row[0] for row in captured),
                  eager_kernel_activity_ns=sum(row[1]-row[0] for row in eager),
                  all_gpu_activity=interval_summary(all_intervals),
                  first_to_last_kernel_envelope=interval_summary(all_intervals, kernel_window),
                  copies=copy_summary(copies, copy_names), memset_count=len(memsets))
    counts = dict(Counter(row['role'] for row in launch_rows))
    logical_target = raw['decode_graph_calls'] if arm.startswith('hyle') else raw['target_decode_calls']
    logical_draft = raw.get('draft_rounds', 0) if arm.startswith('hyle') else raw['draft_decode_calls']
    work_keys = ('generated_tokens', 'generated_decode_tokens', 'turn_count', 'prefill_target_rows', 'prefill_draft_rows',
                 'verified_target_rows', 'actual_target_rows', 'actual_draft_rows', 'committed_target_rows',
                 'draft_rows', 'draft_decode_rows', 'draft_rounds', 'agreements', 'consumed_drafts', 'accepted_drafts',
                 'proposals', 'target_decode_calls', 'draft_decode_calls')
    allocation_names = ('cuMemAlloc_v2', 'cudaMalloc_v', 'cudaGraphInstantiate')
    allocation_positions = defaultdict(Counter)
    for start, end, cid, api, returned in calls:
        if api.startswith(allocation_names):
            allocation_positions[api][sum(row[0] < start for row in launch_calls)] += 1
    diagnostics = [dict(severity=severity, text=text, count=count, first_timestamp=first, last_timestamp=last)
                   for severity, text, count, first, last in db.execute(
                       'SELECT severity,text,count(*),min(timestamp),max(timestamp) '
                       'FROM DIAGNOSTIC_EVENT GROUP BY severity,text ORDER BY severity DESC,text')]
    db.close()
    return dict(status='completed', process=pin(folder/'process.json'), image=process['image'],
                input_files=[pin(folder/name) for name in ('command.json', 'trace.sqlite', 'native-stdout.log', 'native-stderr.log')],
                actual_work={key: raw.get(key) for key in work_keys}, logical_decode_calls=dict(target=logical_target, draft=logical_draft),
                captured_decode_launches=counts,
                logical_decode_calls_not_represented_by_captured_launches=dict(target=logical_target-counts.get('target', 0),
                                                                              draft=logical_draft-counts.get('draft', 0)),
                totals=totals, captured_kernel_buckets=buckets,
                role_kernel_classes={role: classified(rows, names) for role, rows in role_rows.items()},
                role_top_kernels={role: kernel_groups(rows, names) for role, rows in role_rows.items()},
                eager_kernel_classes=classified(eager, names), eager_top_kernels=kernel_groups(eager, names),
                warm_window=warm, early_window=early, pre_first_captured_target=before_target,
                allocation_counts_by_prior_graph_launch={name: dict(counts) for name, counts in allocation_positions.items()},
                diagnostic_events=diagnostics)


def main():
    arms = {arm: one(arm) for arm in ARMS}
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), analysis_source=pin(Path(__file__)),
                  reused_reader=pin(R/'.scratch/qwen-mtp-final-window-20261024/current-structure1/analyze.py'),
                  status='completed' if all(arm['status'] == 'completed' for arm in arms.values()) else 'partial',
                  throughput_evidence=False, memory_evidence=False, product_changes=0,
                  scope='One existing current-clean Nsight node-level process per arm; all captured/eager kernels, copies and memsets included.',
                  methods=['SQLite readonly; graph roles matched only to the four explicitly observed kernel signatures and native call counts.',
                           'All unions use timestamps within their own process/device trace. NULL graphId and0 are both eager.',
                           'Graph medians and last24-target envelopes retain target/draft work distinctions; no claim of equal token continuation or numerical tree.',
                           'The first24 captured-target windows do not align the true logical decode start: peer already executed eager target/draft work before its first capture. Compare Hyle early-to-late descriptively; Hyle/peer first24 cold-cost difference is not an aligned causal contrast.',
                           'All-GPU intervals include loading. First-to-last-kernel includes cold prep/prefills. Warm envelope includes24 captured targets and any intervening draft/eager/copies, not entire decode.',
                           'Sum of durations and unoccupied intervals are descriptive, not promised recoverable wall time. No cross-process clocks are subtracted.'],
                  arms=arms,
                  candidates=[
                      dict(name='Host submission/first-use boundary bubbles',
                           evidence='Ordinary last24 target GPU activity is similar but Hyle has more unoccupied envelope time. MTP last24 does not show larger unoccupied time. Hyle own first24 is more unoccupied than its last24; early long gaps include capture instantiation and first-use allocation APIs. Peer first24 starts after eager decode work and is not an aligned cold comparison.',
                           next_question='Locate first-use preparation versus ready boundary and ordinary warm completion-to-next-submit path. Preserve ownership/retirement checks; no replay deletion is justified from this trace alone.',
                           limit='No CPU scheduling trace was collected. Unoccupied GPU intervals include dependencies, OS/profiler effects and work admission; they are not measured recoverable CPU cost.'),
                      dict(name='MTP T2 body projection implementation',
                           evidence='Two largest non-head target contraction shapes take about6.734ms per Hyle captured target versus6.387ms per peer target by activity/count. Target total busy medians10.876ms versus10.426ms; vocabulary head per-call activity is similar, as is draft head.',
                           next_question='Examine the current T2 body physical contraction route under its actual BF16 contract; target the measured shape groups before adding generic fusion or changing precision.',
                           limit='Different numerical trees and grids; kernel duration averages from one trace do not prove an alternative kernel wins. This does not reopen closed row-split/Top1/MMVF/Lt/shared-GDN-copy experiments.')],
                  limits=['Single instrumented process per arm; cuda,cublas,node tracing changes timing and host launch behavior. No TPS verdict is derived from this trace.',
                          'All traces warn that driver13.4 is unsupported by this Nsight build and collection uses13.3 libraries. MTP graph originalGraph/originalNode identity queries report CUPTI_ERROR_INVALID_PARAMETER:250+250 Hyle,692+692 peer. Actual activity/launch correlation is retained; original graph lineage and completeness cannot be certified from these traces alone.',
                          'No model download or SDK build was active per the frozen batch. This does not remove profiler, WDDM scheduling, clock, cache or thermal effects.',
                          'Native reports give complete logical work; CUDA correlation gives captured role boundaries only. Uncaptured prefill, first-use decode and selection are counted but not arbitrarily assigned to target/draft without an explicit marker.',
                          'Peer MTP first capture occurs after1 eager T2 target decode and2 eager draft decodes, established only from observed head signatures and frozen consumer order. No logical-call timestamps or aligned cold-start interval are manufactured. Last24 remains within each trace and natural continuation differs.',
                          'Hyle BF16 intermediate and peer F32 paths differ; natural outputs/acceptance differ. Contraction names/grids are evidence of implementation, not permission to change precision.',
                          'Copy activity/bytes are actual work, not proof of redundancy. Private snapshot/caller lease and checked/output publication contracts remain constraints.',
                          'Runtime allocations can nest driver APIs; their counts are not additive physical allocation counts.'])
    with (S/'analysis.json').open('w', encoding='utf-8') as out:
        json.dump(record, out, ensure_ascii=False, indent=2, allow_nan=False)
        out.write('\n')
    lines = ['# 四臂 CUDA 结构诊断', '',
             '只读复用已完成的4个 Nsight 进程；无新采样、模型运行、编译或下载。每臂1次，以下时长仅用于结构诊断。', '',
             '| arm | captured target/draft | eager kernels | 全部kernel累计ms |',
             '|---|---:|---:|---:|']
    for name, arm in arms.items():
        total = arm['totals']; count = arm['captured_decode_launches']
        lines.append(f"| {name} | {count.get('target',0)}/{count.get('draft',0)} | {total['eager_kernel_count']} | {total['kernel_activity_ns']/1e6:.3f} |")
    lines += ['', '普通两者都生成128、prefill309、decode target126行。MTP Hyle为66轮、验证132行、consumed60，peer为65次target/65次draft、验证129行、accepted61（proposals64）；实际draft总行434/435。两者生成128、提交435 target行。不能把捕获数当逻辑调用数；peer普通2次target、MTP3次target和11次draft未表现为captured launch，其eager活动已全部计入。', '',
              '| captured graph | kernels/次 | 次数 | GPU busy union中位ms | GPU span中位ms |',
              '|---|---:|---:|---:|---:|']
    for name, arm in arms.items():
        for bucket in arm['captured_kernel_buckets']:
            lines.append(f"| {name}/{bucket['role']} | {bucket['kernels']} | {bucket['launches']} | {bucket['median_gpu_busy_union_ns']/1e6:.3f} | {bucket['median_gpu_span_ns']/1e6:.3f} |")
    lines += ['', '首个captured target之前，已经发生以下实际活动（边界是各进程首个captured target kernel起点；API数为边界前完整返回的事件，包含加载、准备和prefill，也可能包含已返回的首target launch API）：', '',
              '| arm | eager kernels | captured kernels | 完整API事件 |',
              '|---|---:|---:|---:|']
    for name, arm in arms.items():
        before = arm['pre_first_captured_target']
        lines.append(f"| {name} | {before['eager_kernel_count']} | {before['captured_kernel_count']} | {before['completed_runtime_api_count']} |")
    lines += ['', 'peer MTP首capture之前的head顺序是target流14的T1 prefill、draft流15的T1、target流14的T2、draft流15的T1。结合冻结consumer的draft prefill无输出、每轮先draft后target，能确认：3次未捕获target中1次、11次未捕获draft中2次已经在此前发生。peer普通此前也已做1次未捕获decode（另1个head属于prefill）。因此**H/P首24的真实decode起点未对齐，不能表示相同冷启动区间**；保留Hyle自身首→末和明确gap/API事实，不补造逻辑调用时间。', '',
              '按各自进程内部的首／末24个captured target区间计算全部kernel+copy+memset的区间并集；MTP末24区间两边均为24 target+23 draft。末24仍来自各自本进程、不同自然续文。不是完整decode计时，也不是SM利用率。', '',
              '| arm | 首24 span / busy / 空档 ms | 末24 span / busy / 空档 ms |',
              '|---|---:|---:|']
    for name, arm in arms.items():
        columns = [' / '.join(f"{arm[key][metric]/1e6:.3f}" for metric in ('span_ns','busy_union_ns','unoccupied_ns')) for key in ('early_window','warm_window')]
        lines.append(f'| {name} | {columns[0]} | {columns[1]} |')
    lines += ['', '## 两个优先候选', '',
              '1. **提交边界和首用阶段空档。** 普通末24的GPU busy相近，Hyle空档33.011ms、peer19.511ms；MTP末24则Hyle30.285ms、peer32.728ms，没有更大的稳定主机空洞。Hyle自身MTP首24空档72.922ms、末24为30.285ms；前两个及第6个target间隔出现新instantiate，首个间隔还出现分配API。H/P首24起点未对齐，其差不能证明Hyle首用更慢。应分别查普通稳定提交边界和MTP首用准备时点；本trace不能把所有空档归因分配，也不能承诺全部回收。不支持先删prepare_replay的权限／退休校验。',
              '2. **MTP双行target正文投影。** Hyle两个主要非head形状（grid8×48、8×16）累计除以target次数约6.734ms，peer相应主要形状（192、64）约6.387ms；这是约0.347ms/target的活动差。target整体busy中位差约0.451ms。head约2.331/2.346ms，draft head约2.307/2.326ms，并未显示head是当前额外差距主因。下一步只针对实际BF16正文形状核物理实现；不能由kernel名直接决定换算法或改变精度。', '',
              '## Hyle MTP首24的两个最大target间隔', '',
              '这里从一个target最后GPU活动到下一target第一GPU活动，包含其间真实draft，绝非纯CPU时间。API时长为区间内裁切值，runtime/driver存在嵌套，各行不可相加；同步API也可与GPU执行重叠。', '',
              '| target序号 | 区间 / GPU busy / 无GPU活动 ms | instantiate | event synchronize | kernel记录API | alloc |',
              '|---|---:|---:|---:|---:|---:|']
    for gap in arms['hyle_mtp']['early_window']['largest2_inter_target_gaps']:
        api = {row['api']: row for row in gap['api_categories']}
        def value(name):
            row = api.get(name, {})
            return f"{row.get('calls',0)}次/{row.get('clipped_activity_ns',0)/1e6:.3f}ms"
        activity = gap['activity']
        lines.append(f"| {gap['after_target_ordinal']}→{gap['before_target_ordinal']} | "
                     + ' / '.join(f"{activity[metric]/1e6:.3f}" for metric in ('span_ns','busy_union_ns','unoccupied_ns'))
                     + f" | {value('cudaGraphInstantiateWithFlags_v11040')} | {value('cudaEventSynchronize_v3020')} | "
                     + f"cudaLaunchKernel {value('cudaLaunchKernel_v7000')}；嵌套cuLaunchKernel {value('cuLaunchKernel')} | "
                     + f"cuMemAlloc {value('cuMemAlloc_v2')}；cuMemHostAlloc {value('cuMemHostAlloc')}；cudaHostAlloc {value('cudaHostAlloc_v3020')} |")
    lines += ['',
              '## 已量化的次要边界', '',
              'Hyle MTP每target捕获135次D2D、payload中位39,731,200B、copy活动中位0.137ms；普通55次、888,832B、0.042ms。peer捕获图内无D2D，但末24区间仍有D2H约68.9MB（MTP）／22.8MB（普通），已计入busy。因此不能把捕获内copy数视为完整传输对比，也不能将135次copy都标为冗余；本批不重开已关闭的GDN共享copy候选。四臂末24均无新alloc/instantiate API。', '',
              'NULL graphId和0均计为eager。全进程累计包括加载、prefill和first-use，不能当decode成本；累计kernel时长、区间空档和不同进程的时钟不能拼成可回收时间。CUDA/cuBLAS/node tracing、WDDM调度、时钟和cache均可能影响单次时长。没有CPU调度、硬件带宽/SM计数器；不作质量一致、显存峰值、吞吐胜负或因果加速比例结论。数学路径和自然续文／接受率本来不同，所有target/draft工作必须继续计账。', '',
              '仪器有明确限制：四臂都提示driver13.4超出此Nsight支持范围、改用13.3库；MTP两臂GetGraphId/GetGraphNodeId原图身份查询报CUPTI_ERROR_INVALID_PARAMETER，各Hyle250／peer692次。现有活动与运行时launch关联可读，但不能据此认证原图谱系或绝对完整性，尤其不能直接推导因果收益。原诊断按文本聚合保留在JSON。', '',
              '复算：`python .scratch/mtp-performance-convergence-20261025/current-structure/analysis.py`；原trace只读，详细数值及source/input SHA见 `analysis.json`。']
    (S/'analysis.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps(dict(status=record['status'], arms={name: dict(graphs=arm.get('captured_decode_launches'),
                           warm=arm.get('warm_window', {}).get('busy_fraction')) for name, arm in arms.items()})))


if __name__ == '__main__':
    main()
