# 四臂 CUDA 结构诊断

只读复用已完成的4个 Nsight 进程；无新采样、模型运行、编译或下载。每臂1次，以下时长仅用于结构诊断。

| arm | captured target/draft | eager kernels | 全部kernel累计ms |
|---|---:|---:|---:|
| hyle_plain | 126/0 | 2212 | 1247.870 |
| hyle_mtp | 66/66 | 3006 | 937.553 |
| peer_plain | 124/0 | 2970 | 1255.901 |
| peer_mtp | 62/54 | 4336 | 898.407 |

普通两者都生成128、prefill309、decode target126行。MTP Hyle为66轮、验证132行、consumed60，peer为65次target/65次draft、验证129行、accepted61（proposals64）；实际draft总行434/435。两者生成128、提交435 target行。不能把捕获数当逻辑调用数；peer普通2次target、MTP3次target和11次draft未表现为captured launch，其eager活动已全部计入。

| captured graph | kernels/次 | 次数 | GPU busy union中位ms | GPU span中位ms |
|---|---:|---:|---:|---:|
| hyle_plain/target | 591 | 126 | 9.510 | 9.575 |
| hyle_mtp/draft | 37 | 8 | 2.658 | 2.661 |
| hyle_mtp/draft | 41 | 58 | 2.482 | 2.484 |
| hyle_mtp/target | 738 | 66 | 10.876 | 11.023 |
| peer_plain/target | 558 | 62 | 9.498 | 9.518 |
| peer_plain/target | 564 | 62 | 9.513 | 9.561 |
| peer_mtp/draft | 34 | 54 | 2.598 | 2.599 |
| peer_mtp/target | 727 | 62 | 10.425 | 10.454 |

首个captured target之前，已经发生以下实际活动（边界是各进程首个captured target kernel起点；API数为边界前完整返回的事件，包含加载、准备和prefill，也可能包含已返回的首target launch API）：

| arm | eager kernels | captured kernels | 完整API事件 |
|---|---:|---:|---:|
| hyle_plain | 951 | 0 | 11564 |
| hyle_mtp | 1968 | 37 | 21749 |
| peer_plain | 1500 | 0 | 6071 |
| peer_mtp | 1788 | 0 | 7478 |

peer MTP首capture之前的head顺序是target流14的T1 prefill、draft流15的T1、target流14的T2、draft流15的T1。结合冻结consumer的draft prefill无输出、每轮先draft后target，能确认：3次未捕获target中1次、11次未捕获draft中2次已经在此前发生。peer普通此前也已做1次未捕获decode（另1个head属于prefill）。因此**H/P首24的真实decode起点未对齐，不能表示相同冷启动区间**；保留Hyle自身首→末和明确gap/API事实，不补造逻辑调用时间。

按各自进程内部的首／末24个captured target区间计算全部kernel+copy+memset的区间并集；MTP末24区间两边均为24 target+23 draft。末24仍来自各自本进程、不同自然续文。不是完整decode计时，也不是SM利用率。

| arm | 首24 span / busy / 空档 ms | 末24 span / busy / 空档 ms |
|---|---:|---:|
| hyle_plain | 273.988 / 230.928 / 43.060 | 262.288 / 229.277 / 33.011 |
| hyle_mtp | 399.974 / 327.052 / 72.922 | 352.917 / 322.632 / 30.285 |
| peer_plain | 253.065 / 233.378 / 19.686 | 251.519 / 232.008 / 19.511 |
| peer_mtp | 349.421 / 316.967 / 32.453 | 348.897 / 316.169 / 32.728 |

## 两个优先候选

1. **提交边界和首用阶段空档。** 普通末24的GPU busy相近，Hyle空档33.011ms、peer19.511ms；MTP末24则Hyle30.285ms、peer32.728ms，没有更大的稳定主机空洞。Hyle自身MTP首24空档72.922ms、末24为30.285ms；前两个及第6个target间隔出现新instantiate，首个间隔还出现分配API。H/P首24起点未对齐，其差不能证明Hyle首用更慢。应分别查普通稳定提交边界和MTP首用准备时点；本trace不能把所有空档归因分配，也不能承诺全部回收。不支持先删prepare_replay的权限／退休校验。
2. **MTP双行target正文投影。** Hyle两个主要非head形状（grid8×48、8×16）累计除以target次数约6.734ms，peer相应主要形状（192、64）约6.387ms；这是约0.347ms/target的活动差。target整体busy中位差约0.451ms。head约2.331/2.346ms，draft head约2.307/2.326ms，并未显示head是当前额外差距主因。下一步只针对实际BF16正文形状核物理实现；不能由kernel名直接决定换算法或改变精度。

## Hyle MTP首24的两个最大target间隔

这里从一个target最后GPU活动到下一target第一GPU活动，包含其间真实draft，绝非纯CPU时间。API时长为区间内裁切值，runtime/driver存在嵌套，各行不可相加；同步API也可与GPU执行重叠。

| target序号 | 区间 / GPU busy / 无GPU活动 ms | instantiate | event synchronize | kernel记录API | alloc |
|---|---:|---:|---:|---:|---:|
| 1→2 | 14.511 / 2.492 / 12.019 | 2次/3.236ms | 15次/1.952ms | cudaLaunchKernel 574次/0.723ms；嵌套cuLaunchKernel 195次/0.219ms | cuMemAlloc 23次/0.255ms；cuMemHostAlloc 16次/0.079ms；cudaHostAlloc 7次/0.032ms |
| 2→3 | 12.070 / 2.496 / 9.574 | 2次/3.094ms | 8次/1.846ms | cudaLaunchKernel 574次/0.760ms；嵌套cuLaunchKernel 195次/0.243ms | cuMemAlloc 0次/0.000ms；cuMemHostAlloc 0次/0.000ms；cudaHostAlloc 0次/0.000ms |

## 已量化的次要边界

Hyle MTP每target捕获135次D2D、payload中位39,731,200B、copy活动中位0.137ms；普通55次、888,832B、0.042ms。peer捕获图内无D2D，但末24区间仍有D2H约68.9MB（MTP）／22.8MB（普通），已计入busy。因此不能把捕获内copy数视为完整传输对比，也不能将135次copy都标为冗余；本批不重开已关闭的GDN共享copy候选。四臂末24均无新alloc/instantiate API。

NULL graphId和0均计为eager。全进程累计包括加载、prefill和first-use，不能当decode成本；累计kernel时长、区间空档和不同进程的时钟不能拼成可回收时间。CUDA/cuBLAS/node tracing、WDDM调度、时钟和cache均可能影响单次时长。没有CPU调度、硬件带宽/SM计数器；不作质量一致、显存峰值、吞吐胜负或因果加速比例结论。数学路径和自然续文／接受率本来不同，所有target/draft工作必须继续计账。

仪器有明确限制：四臂都提示driver13.4超出此Nsight支持范围、改用13.3库；MTP两臂GetGraphId/GetGraphNodeId原图身份查询报CUPTI_ERROR_INVALID_PARAMETER，各Hyle250／peer692次。现有活动与运行时launch关联可读，但不能据此认证原图谱系或绝对完整性，尤其不能直接推导因果收益。原诊断按文本聚合保留在JSON。

复算：`python .scratch/mtp-performance-convergence-20261025/current-structure/analysis.py`；原trace只读，详细数值及source/input SHA见 `analysis.json`。
