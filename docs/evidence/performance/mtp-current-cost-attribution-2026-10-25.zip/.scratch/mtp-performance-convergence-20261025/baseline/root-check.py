"""Read only: independently check completed process counts and published rates."""
from pathlib import Path
import hashlib
import json
import math
import statistics

D = Path(__file__).resolve().parent
R = D.parents[2]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
public = read(R / 'docs/evidence/performance/mtp-current-single-and-multiturn-2026-10-25.json')
checks = []
for workload in ('single', 'two-turn'):
    for mode, count in (('timing', 12), ('memory', 4)):
        runs = read(D / (workload + '-' + mode) / 'runs.json')
        assert len(runs) == count
        for row in runs:
            p = row['process']
            assert p['exit'] == 0 and not p['reader_errors']
            assert p['profiler'] is False and p['memory_only'] == (mode == 'memory')
            assert p['throughput_evidence'] == (mode == 'timing')
        if mode == 'timing':
            for arm, published in public['windows'][workload]['arms'].items():
                selected = [row['observation'] for row in runs if row['arm'] == arm]
                assert len(selected) == 3
                for row in selected:
                    m = row['metrics']
                    assert row['actual_generated_tokens'] == (64 if workload == 'single' else 128)
                    assert math.isclose(m['full_decode_tokens_per_second'],
                        (63 if workload == 'single' else 126) / m['decode_seconds'], rel_tol=1e-12)
                    assert math.isclose(m['session_output_tokens_per_second'],
                        row['actual_generated_tokens'] / m['session_seconds'], rel_tol=1e-12)
                for metric in ('full_decode_tokens_per_second', 'session_output_tokens_per_second',
                               'prefill_tokens_per_second'):
                    actual = statistics.median(row['metrics'][metric] for row in selected)
                    assert actual == published['metrics'][metric]['median']
        checks.append(dict(workload=workload, mode=mode, processes=count, status='passed'))
main = R / 'engine/models/qwen35/main.cc'
assert hashlib.sha256(main.read_bytes()).hexdigest() == public['image']['canonical_main']['sha256']
result = dict(status='passed', read_only=True, GPU=0, HTTP=0, model_reruns=0,
    checks=checks, canonical_source_unchanged=True,
    limits='Recomputes rates and process facts from retained runs, not independent model quality or hardware-memory measurement.')
(D / 'root-check.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
