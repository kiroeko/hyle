"""Offline reduction of the already completed, bounded Graph diagnostic log."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
LOG = ROOT / "runs/diagnostic/attempt1/stderr.log"
OLD = REPO / ".scratch/inference-paired-m2-20261030/auto-diagnostic.json"
NONE = 2**64 - 1


def pin(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(REPO)), "bytes": len(data), "sha256": sha256(data).hexdigest()}


def parse(prefix):
    result = []
    for number, line in enumerate(LOG.read_text(encoding="utf-8").splitlines(), 1):
        if line.startswith(prefix):
            fields = dict(re.findall(r"(\w+)=([^\s]+)", line))
            fields["line"] = number
            result.append(fields)
    return result


def number(event, key):
    value = int(event[key])
    return None if value == NONE else value


def fact(event):
    fields = {"line": event["line"], "seq": number(event, "seq"), "event": event["event"],
              "reason": event.get("reason"), "wrapper": event.get("wrapper"),
              "state": event.get("state"), "plan": event.get("plan")}
    for key in ("range", "begin", "count", "variant", "step", "first_node", "port", "instance", "value",
                "closed", "live_ranges", "saved_ranges", "active", "last_used", "qualification", "private",
                "key0", "command0", "key1", "command1", "seed", "revision", "prepared_revision", "stable", "native_inputs"):
        if key in event:
            fields[key] = number(event, key)
    return fields


def mismatch(event):
    result = fact(event)
    result["same_address"] = bool(int(event["same_address"]))
    result["same_description"] = bool(int(event["same_description"]))
    for prefix in ("old", "new"):
        result[prefix] = {
            "valid": bool(int(event[prefix + "_valid"])),
            "resource": event[prefix + "_resource"], "handle": event[prefix + "_handle"],
            "offset": int(event[prefix + "_offset"]), "extent": int(event[prefix + "_extent"]),
            "type": int(event[prefix + "_type"]), "rank": int(event[prefix + "_rank"]),
            "dims": json.loads(event[prefix + "_dims"]), "byte_strides": json.loads(event[prefix + "_strides"]),
        }
    result["changed_tuple_fields"] = [key for key in result["old"] if result["old"][key] != result["new"][key]]
    return result


graph = parse("AUTO_CAPTURE ")
engine = parse("engine_auto ")
entries = [e for e in graph if e["event"] == "entry"]
begins = [e for e in graph if e["event"] == "record_begin"]
ends = [e for e in graph if e["event"] == "record_end"]
misses = [e for e in graph if e["event"] == "key_miss"]
clears = [e for e in graph if e["event"] in ("clear", "clear_all")]
releases = [e for e in graph if e["event"] == "release_wrapper"]
aliases = [e for e in graph if e["event"] == "alias_reject"]
assert len(begins) == len(ends) == 10
assert not any(e["event"] in ("event_limit", "miss_limit") for e in graph)

first_entry = {}
states_by_wrapper = defaultdict(list)
for entry in entries:
    first_entry.setdefault(entry["state"], entry)
    if entry["state"] not in states_by_wrapper[entry["wrapper"]]:
        states_by_wrapper[entry["wrapper"]].append(entry["state"])

records = []
record_miss_sequences = set()
state_records = Counter()
for ordinal, begin in enumerate(begins, 1):
    end = next(e for e in ends if int(e["seq"]) > int(begin["seq"]) and e["state"] == begin["state"])
    entry = max((e for e in entries if e["state"] == begin["state"] and e["line"] < begin["line"]), key=lambda e: e["line"])
    wrapper = entry["wrapper"]
    prep = max((e for e in engine if e["event"] == "prepare_begin" and e["inv"] == wrapper and e["line"] < begin["line"]), key=lambda e: e["line"])
    prep_end = next(e for e in engine if e["event"] == "prepare_end" and e["inv"] == wrapper
                    and e["step"] == prep["step"] and e["step_clock_ns"] == prep["step_clock_ns"] and e["line"] > begin["line"])
    call = next(e for e in engine if e["event"].startswith("call_a_") and e["inv"] == wrapper
                and e["step"] == prep["step"] and e["step_clock_ns"] == prep["step_clock_ns"] and e["line"] > prep_end["line"])
    in_prepare = [e for e in misses if e["state"] == begin["state"] and prep["line"] < e["line"] < begin["line"]]
    state_ordinal = state_records[begin["state"]]
    previous_states = states_by_wrapper[wrapper][:states_by_wrapper[wrapper].index(begin["state"])]
    replacement = None
    if state_ordinal == 0 and previous_states:
        old_state = previous_states[-1]
        clear = next(e for e in clears if e["state"] == old_state)
        release = next(e for e in releases if e["state"] == old_state)
        replacement = {"old_state": old_state, "new_state": begin["state"], "same_original_wrapper": wrapper,
                       "clear": fact(clear), "release": fact(release), "new_state_first_entry": fact(first_entry[begin["state"]])}
        category = "first_record_after_closed_invocation_replacement"
    elif state_ordinal == 0:
        category = "natural_first_cold_preparation"
    else:
        category = "new_physical_tuple_second_variant"
        assert len(in_prepare) == 1 and int(begin["variant"]) == 1
    if state_ordinal == 0:
        assert not in_prepare and begin["key0"] == begin["key1"] == "0"
    state_records[begin["state"]] += 1
    record_miss_sequences.update(int(e["seq"]) for e in in_prepare)
    records.append({
        "ordinal": ordinal, "category": category,
        "published_call": {"name": call["name"], "line": call["line"], "event": call["event"],
                           "slot": int(call["slot"]), "role": int(call["role"]), "T": int(call["T"])},
        "original_identity": {"wrapper": wrapper, "state": begin["state"], "plan": begin["plan"],
                              "entry_line": entry["line"], "entry_reason": entry["reason"]},
        "prepare_interval": {"begin_line": prep["line"], "end_line": prep_end["line"],
                             "step": prep["step"], "step_clock_ns": prep["step_clock_ns"]},
        "record_begin": fact(begin), "record_end": fact(end),
        "first_mismatches_in_this_prepare": [mismatch(e) for e in in_prepare],
        "alias_rejections_in_this_prepare": [fact(e) for e in aliases if prep["line"] < e["line"] < begin["line"] and e["state"] == begin["state"]],
        "closed_invocation_replacement": replacement,
    })

old = json.loads(OLD.read_text(encoding="utf-8"))["sources"]["auto"]
new_command = json.loads((ROOT / "runs/diagnostic/attempt1/command.json").read_text(encoding="utf-8"))
current_rounds = [int(r["published_call"]["name"].removeprefix("mtp")) for r in records]
assert current_rounds == old["published_T2_prepare"]["recorded_rounds"]
assert new_command[1:] == old["command"][1:]
other_misses = [e for e in misses if int(e["seq"]) not in record_miss_sequences]
grouped_misses = {}
for event in other_misses:
    m = mismatch(event)
    key = json.dumps({k: m[k] for k in ("state", "step", "first_node", "port", "instance", "value", "old", "new")}, sort_keys=True)
    grouped_misses.setdefault(key, {"first_mismatch": m, "observations": []})["observations"].append({"line": event["line"], "seq": int(event["seq"]), "reason": event["reason"]})

analysis = {
    "status": "COMPLETED_NATIVE_LOG_OFFLINE_ANALYSIS_ONLY",
    "log": pin(LOG), "graph_instrumentation": pin(ROOT / "instrumentation.json"),
    "summary": {"record_begin": len(begins), "record_end": len(ends),
                "record_categories": dict(Counter(r["category"] for r in records)),
                "key_miss_observations": len(misses), "record_causing_first_mismatches": len(record_miss_sequences),
                "other_variant_mismatch_observations": len(other_misses),
                "clear": sum(e["event"] == "clear" for e in graph), "clear_all": sum(e["event"] == "clear_all" for e in graph),
                "evict": sum(e["event"] == "evict" for e in graph), "alias_reject": len(aliases),
                "reuse": dict(Counter(e["reason"] for e in graph if e["event"] == "reuse")),
                "reset_begin": sum(e["event"] == "reset_begin" for e in graph),
                "reset_end": sum(e["event"] == "reset_end" for e in graph),
                "log_limits_reached": False},
    "prior_record10_alignment": {"source": pin(OLD), "same_argv_after_executable": True,
                                 "prior_recorded_rounds": old["published_T2_prepare"]["recorded_rounds"],
                                 "diagnostic_recorded_rounds": current_rounds, "same_round_sequence": True,
                                 "boundary": "Old raw log has no wrapper/state/slot identity. Current identities are facts from the diagnostic run only; they are not retroactively attributed to the old process."},
    "records": records,
    "clear_events": [fact(e) for e in clears],
    "evict_events": [fact(e) for e in graph if e["event"] == "evict"],
    "new_invocation_positions": [r["closed_invocation_replacement"] for r in records if r["closed_invocation_replacement"]],
    "wrapper_releases": [fact(e) for e in releases],
    "non_recording_variant_mismatches": list(grouped_misses.values()),
    "alias_facts": {"observed_rejections": [fact(e) for e in aliases],
                    "boundary": "No alias_reject event occurred. This observes absence of a failed original replacement/full-view proof; it does not claim that no aliases exist or that all binding arguments are identical."},
    "interpretation_boundaries": [
        "Each key_miss reports only the first different port in an original variant comparison, not an exhaustive list of differing tensors.",
        "Four record-causing comparisons all first differ at step0/first_node0/input_port1/instance5/value6: I32[2], byte_stride4, extent8. Descriptions/resources match and handles differ; two pairs also differ in offset. No model port name is inferred from rank alone.",
        "Five additional mismatch observations do not cause recordings: another retained variant subsequently matches. They must not be counted as five more captures or alias/permission failures.",
        "Clear step221/first_node405 is the original invalidation trigger while closed=1, not a recorded physical key mismatch at that node.",
        "Two post-close recordings have no old key in their new InvocationState. They arise after original wrapper state replacement, not variant eviction.",
        "The completed instrumented process passed according to root; instrumentation timing is not an unprofiled performance measurement.",
    ],
}
(ROOT / "graph-analysis.json").write_text(json.dumps(analysis, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"output": str(ROOT / "graph-analysis.json"), "summary": analysis["summary"], "recorded_rounds": current_rounds}, indent=2))
