"""Save finite current evidence; no build, native process or download."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('delivery', W/'delivery.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact

analysis = read(W/'delivery-analysis.json')
summary = read(W/'peer-window/summary.json')
assert summary['status'] == 'COMPLETE32_FOUR_ARMS_STABLE'
relay = read(W/'product-runs/relay/attempt3/report.json')
ordinary = read(W/'product-runs/ordinary/attempt2/report.json')
assert relay['status'] == ordinary['status'] == 'PASS'
assert relay['arms'] == 5 and relay['native_submissions'] == 58
processes = []
for scenario in ('single', 'two-turn'):
    for mode in ('timing', 'memory'):
        for row in read(W/'peer-window'/(scenario+'-'+mode)/'runs.json'):
            folder = Path(row['folder']); result = read(folder/'result.json')
            assert result['exit'] == 0
            processes.append(dict(scenario=scenario, mode=mode, arm=row['arm'], pid=result['pid'],
                started_unix_ns=result['started_unix_ns'], finished_unix_ns=result['finished_unix_ns'],
                process=pin(folder/'result.json'), producer=pin(folder/'consumer-result.json')))
assert len(processes) == 32
tz = timezone(timedelta(hours=8))
fmt = lambda v: datetime.fromtimestamp(v/1e9, tz).isoformat(timespec='seconds')
metrics = [dict(scenario=row['scenario'], arm=row['arm'], timing=row['timing'],
    independent_memory=dict(sample_count=row['independent_memory']['sample_count'],
        sampled_peaks=row['independent_memory']['sampled_peaks'])) for row in summary['table']]
work = []
for row in summary['cross_engine_work']:
    work.append(dict(scenario=row['scenario'], role=row['role'], common_output_prefix=row['common_output_prefix'],
        first_differing_output_1based=row['first_differing_output_1based'],
        arms={arm:{k:report.get(k) for k in ['generated_tokens','actual_graph_calls','actual_target_rows',
            'actual_draft_rows','draft_rounds','agreements','overlap_successor_submissions',
            'overlap_successor_publications','overlap_successor_discards','overlap_successor_refusals']}
            for arm,report in row['complete_non_time_reports'].items()}))
window = dict(status=summary['status'], time_window=dict(
    started_china=fmt(min(p['started_unix_ns'] for p in processes)),
    finished_china=fmt(max(p['finished_unix_ns'] for p in processes))),
    counts=dict(actual_processes=32, timing=24, independent_memory=8,
        timing_samples_per_arm_scenario=3, memory_processes_per_arm_scenario=1),
    current_candidate=read(W/'peer-window/ready.json'), peer=read(W/'peer-window/peer-ready.json'),
    metrics=metrics, cross_engine_actual_work=work, process_index=processes,
    protocol=pin(W/'peer-window/plan.json'), summary=pin(W/'peer-window/summary.json'))
diff = subprocess.check_output(['git','diff','--','engine/inference/execution_episode.h',
    'engine/models/qwen35/main.cc','tests/tools/qwen_submission_source_probe.cc'],cwd=R)
(W/'product.diff').write_bytes(diff)
value = dict(schema='hyle.performance.successful-discard.v1', date='2026-10-30',
    status='IMPLEMENTED_FINITE_CHECKS_AND_COMPLETE_WINDOW', base_commit='0d1ef9a87',
    implementation=dict(sources=[pin(R/p) for p in ['engine/inference/execution_episode.h',
        'engine/models/qwen35/main.cc','tests/tools/qwen_submission_source_probe.cc']],
        product_diff=pin(W/'product.diff'), unchanged_sdk_inputs=227, sdk_cxx_compiles=0, sdk_nvcc_compiles=0,
        semantics=['Use the original actual whole-Graph success and native/retention retirement before preserving an unpublished carrier.',
            'Recover original Source, Store, Append and page transactions; keep fixed IO and dormant captures without weakening future tuple/permission checks.',
            'Unknown/error/real Session stop retains the original destructive retirement path; preserve original Status and committed A state.',
            'No change to warm/reset policy, graph-variant cap, numerical routing, defaults or user options.']),
    diagnosis=dict(graph=read(W/'graph-analysis.json'), engine=read(W/'engine-analysis.json'),
        conclusion='Normal discarded speculative B used destructive recovery, closing/recreating carriers and losing captures. No variant eviction was observed.'),
    delivery_analysis=analysis, finite_checks=dict(relay=relay, ordinary=ordinary,
        probe_first_failure=read(W/'probe-attempt1-analysis.json'),
        probe_second_failure=read(W/'probe-attempt2-analysis.json'),
        ordinary_first_failure='Reused input directory already contained the consumer-generated stop fixture. Preserved the failure and copied only two metadata files into this batch input directory.'),
    complete_window=window, downloads=0,
    limits=[*summary['limits'],
        'Each final direct A/B arm has only two samples; do not promise a stable hardware-wide gain or pool earlier screening samples.',
        'Diagnostic timing is not throughput evidence. Preparation elapsed is not CPU self time and overlapping stage durations are not independently additive.',
        'Frozen peer433e is not latest upstream; generated IDs and actual verification work differ across engines and are retained.',
        'Extra speculative submissions, reset/warm costs, other MTP modes, broader architecture and GPU hotspots remain unfinished.',
        'No GPU native-fault injection, multi-GPU execution, general model quality or cross-platform performance claim.'],
    cleanup=dict(script=pin(R/'test.ps1'), manifest=pin(W/'cleanup-targets.json'), result=read(W/'cleanup-report.json')),
    evidence_archive='inference-successful-discard-2026-10-30.zip')
out = R/'docs/evidence/performance/inference-successful-discard-2026-10-30.json'
save(out, value)
files = []
for path in W.rglob('*'):
    if not path.is_file(): continue
    relative = path.relative_to(W)
    if any(part in ('bin','tmp','__pycache__','ordinary-input') for part in relative.parts): continue
    if path.suffix in ('.obj','.pdb','.lib','.exp','.exe','.dll','.map','.ilk'): continue
    if path.suffix not in ('.json','.py','.diff','.log','.cc'): continue
    files.append(path)
archive = out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(files): z.write(path,path.relative_to(W).as_posix())
    z.write(R/'test.ps1','cleanup-script.ps1')
    z.write(out,'delivery.json')
print('Saved',out.relative_to(R),'archive_bytes',archive.stat().st_size,'files',len(files))
for scenario in ('single','two-turn'):
    for role,left,right in [('ordinary','hyle_auto','peer_plain'),('mtp','hyle_mtp','peer_mtp')]:
        pair=[next(r for r in metrics if r['scenario']==scenario and r['arm']==arm) for arm in (left,right)]
        print(scenario,role,' '.join('/'.join(f'{r["timing"][k]["median"]:.2f}' for r in pair) for k in
            ('prefill_tokens_per_second','full_decode_tokens_per_second','session_output_tokens_per_second')),
            '/'.join(f'{r["independent_memory"]["sampled_peaks"]["sampled_peak_gpu_dedicated_bytes"]/2**30:.3f}' for r in pair))
