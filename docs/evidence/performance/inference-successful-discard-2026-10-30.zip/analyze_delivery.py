"""Offline delivery evidence only. Never imports the build/native runners."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import statistics
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
TIME_KEYS = ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def non_time(value):
    # Exactly the original recursive predicate; retain all embedded sessions.
    if isinstance(value, list):
        return [non_time(v) for v in value]
    if isinstance(value, dict):
        return {k: non_time(v) for k, v in value.items()
                if not any(s in k for s in TIME_KEYS)}
    return value


def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, reason='type', old=a, new=b)]
    if isinstance(a, dict):
        out = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b:
                out.append(dict(path=path + '.' + key, reason='missing field',
                                old=a.get(key), new=b.get(key)))
            else:
                out.extend(differences(a[key], b[key], path + '.' + key))
        return out
    if isinstance(a, list):
        if len(a) != len(b):
            return [dict(path=path, reason='list length', old=len(a), new=len(b))]
        return [d for i, (x, y) in enumerate(zip(a, b))
                for d in differences(x, y, f'{path}[{i}]')]
    return [] if a == b else [dict(path=path, reason='value', old=a, new=b)]


def prepared(path):
    rows = []
    pending = None
    for line_no, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
        if line.startswith('prepared T='):
            fields = dict(re.findall(r'([A-Za-z_][A-Za-z0-9_]*)=([^\s]+)', line))
            pending = dict(stderr_line=line_no, T=int(fields['T']),
                           visible=int(fields['visible']), replay=fields['replay'],
                           capture_recorded=int(fields['capture_recorded']),
                           capture_reused=int(fields['capture_reused']),
                           cold_batch_seconds=float(fields['cold_batch_seconds']),
                           round=None, observation_name=None)
            rows.append(pending)
        elif pending is not None:
            match = re.match(r'((?:round\d+_)?mtp(\d+))\s', line)
            if match:
                pending.update(round=int(match[2]), observation_name=match[1])
                pending = None
            elif re.match(r'prefill\s', line):
                pending['observation_name'] = 'prefill'
                pending = None
    return dict(published_prepared_count=len(rows),
                capture_recorded=sum(x['capture_recorded'] for x in rows),
                capture_reused=sum(x['capture_reused'] for x in rows),
                cold_batch_seconds_sum=sum(x['cold_batch_seconds'] for x in rows),
                recorded_positions=[x for x in rows if x['capture_recorded']],
                published_prepared_rows=rows,
                scope='Published prepared stderr lines only; cancelled successors may be absent. Elapsed preparation is not CPU self-time or GPU event time.')


def sample(folder, arm, phase, anchor, errors):
    row = dict(arm=arm, phase=phase, attempt=folder.name, directory=str(folder))
    required = ['stdout.log', 'stderr.log', 'process.json']
    if any(not (folder / x).exists() for x in required):
        return dict(**row, state='incomplete', missing=[x for x in required if not (folder / x).exists()])
    try:
        process = read(folder / 'process.json')
        if process.get('state') != 'TERMINAL':
            return dict(**row, state='incomplete', process=process)
        if process.get('exit') != 0 or process.get('timed_out'):
            row.update(state='failed', process=process,
                       artifacts={x: pin(folder / x) for x in required},
                       stderr_tail=(folder / 'stderr.log').read_text(encoding='utf-8-sig').splitlines()[-12:])
            errors.append(dict(directory=str(folder), reason='process failed', process=process))
            return row
        raw = read(folder / 'stdout.log')
        row.update(state='terminal', process=process,
                   artifacts={x: pin(folder / x) for x in required},
                   preparation=prepared(folder / 'stderr.log'))
        if (folder / 'command.json').exists():
            row['command'] = read(folder / 'command.json')
        if (folder / 'report.json').exists():
            report_diff = differences(raw, read(folder / 'report.json'))
            row['report_file_equals_raw_stdout'] = not report_diff
            if report_diff:
                errors.append(dict(directory=str(folder), reason='report.json differs from raw stdout', differences=report_diff))
        if arm in ('relay', 'ordinary'):
            row['functional_report'] = raw  # Keep all actual fields, including new cases.
            row['pass'] = process.get('exit') == 0 and not process.get('timed_out') and raw.get('status') == 'PASS'
            if not row['pass']:
                errors.append(dict(directory=str(folder), reason='finite functional report did not pass'))
            return row
        normalized = non_time(raw)
        comparison = differences(non_time(anchor), normalized)
        detail = raw['sessions'][0]['result']
        anchor_detail = anchor['sessions'][0]['result']
        row.update(non_time=dict(equal=not comparison, sha256=digest(normalized), differences=comparison),
                   generated_ids=dict(equal=not differences(anchor_detail['generated_ids'], detail['generated_ids']),
                                      count=len(detail['generated_ids']), sha256=digest(detail['generated_ids'])),
                   round_records=dict(equal=not differences(anchor_detail['rounds'], detail['rounds']),
                                      count=len(detail['rounds']), sha256=digest(detail['rounds'])),
                   metrics={k: raw[k] for k in ('decode_seconds', 'decode_output_tokens_per_second',
                                                'prefill_seconds', 'session_seconds', 'actual_graph_calls',
                                                'actual_target_rows', 'draft_rounds', 'agreements',
                                                'overlap_successor_submissions', 'overlap_successor_publications',
                                                'overlap_successor_discards', 'overlap_successor_refusals')})
        expected = 5 if arm == 'candidate' else 10
        row['capture_expectation'] = dict(expected=expected, actual=row['preparation']['capture_recorded'],
                                          equal=row['preparation']['capture_recorded'] == expected)
        if comparison or not row['generated_ids']['equal'] or not row['round_records']['equal']:
            errors.append(dict(directory=str(folder), reason='strict workload/result difference'))
        if not row['capture_expectation']['equal']:
            errors.append(dict(directory=str(folder), reason='unexpected published capture recording count',
                               details=row['capture_expectation']))
        return row
    except (ValueError, KeyError, TypeError, OSError) as error:
        errors.append(dict(directory=str(folder), reason='unreadable/malformed evidence', error=str(error)))
        return {**row, 'state': 'invalid', 'error': str(error)}


def median_group(rows):
    valid = [x for x in rows if x.get('state') == 'terminal' and 'metrics' in x
             and x['process'].get('exit') == 0 and not x['process'].get('timed_out')]
    if not valid:
        return dict(count=0, samples=[])
    return dict(count=len(valid), samples=[dict(directory=x['directory'], attempt=x['attempt'],
                process_started=x['process'].get('started'), process_elapsed_seconds=x['process'].get('seconds'),
                decode_seconds=x['metrics']['decode_seconds'],
                decode_output_tokens_per_second=x['metrics']['decode_output_tokens_per_second']) for x in valid],
                median_decode_seconds=statistics.median(x['metrics']['decode_seconds'] for x in valid),
                median_decode_output_tokens_per_second=statistics.median(x['metrics']['decode_output_tokens_per_second'] for x in valid),
                median_process_elapsed_seconds=statistics.median(x['process']['seconds'] for x in valid))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--final', action='store_true',
                        help='Use only after root confirms all final runs completed; never starts a run.')
    options = parser.parse_args()
    errors = []
    anchor_path = W / 'runs/diagnostic/attempt1/stdout.log'
    anchor = read(anchor_path)
    runs = []
    for arm in ('control', 'candidate'):
        parent = W / 'product-runs' / arm
        if parent.exists():
            for folder in sorted((p for p in parent.iterdir() if p.is_dir()), key=lambda p: p.name):
                name = folder.name
                phase = 'screen' if name.startswith('screen-abba-') else 'final' if name.startswith('final-abba-') else 'correctness'
                if phase != 'correctness' or name.startswith('correctness'):
                    runs.append(sample(folder, arm, phase, anchor, errors))
    finite = []
    finite_latest = {}
    for arm in ('relay', 'ordinary'):
        parent = W / 'product-runs' / arm
        folders = sorted((p for p in parent.iterdir() if p.is_dir()), key=lambda p: p.name) if parent.exists() else []
        attempts = []
        for folder in folders:
            attempt_errors = []
            row = sample(folder, arm, 'finite_validation', anchor, attempt_errors)
            row['attempt_validation_errors'] = attempt_errors
            attempts.append(row)
        if attempts:
            latest = max(attempts, key=lambda x: x.get('process', {}).get('started', float('inf')))
            finite_latest[arm] = latest['directory']
            for row in attempts:
                row['selected_for_delivery'] = row is latest
                row['superseded_attempt'] = row is not latest
                if row is latest:
                    errors.extend(row['attempt_validation_errors'])
                    if not row.get('pass', False):
                        errors.append(dict(directory=row['directory'], reason='latest finite attempt did not pass'))
                    else:
                        facts = row['functional_report']
                        required_guards = ('successful_unpublished_discard_preserved_carrier',
                            'unobserved_completion_discard_refused', 'pending_completion_discard_deferred',
                            'retained_source_defers_successful_discard', 'source_withdrawal_not_repeated',
                            'failed_episode_destructive_recovery', 'session_closed_successful_discard_refused',
                            'session_closed_graph_destructively_recovered',
                            'failure_head_checkpoint_epoch_rng_ledger_unpublished',
                            'same_session_retry_matches_serial', 'old_checkpoint_unchanged',
                            'rng_cursor_unchanged', 'all_source_generations_released') if arm == 'relay' else (
                            'same_original_executor', 'complete_prefix_state_epoch_rng_equal',
                            'actual_owner_credit_checked', 'all_source_session_page_owners_retired')
                        row['delivery_guards'] = {k: facts.get(k) is True for k in required_guards}
                        row['delivery_counts'] = (dict(arms=facts.get('arms'), native_submissions=facts.get('native_submissions'),
                            final_live_versions=facts.get('final_live_versions')) if arm == 'relay' else
                            dict(control_and_candidate_arms=facts.get('control_and_candidate_arms')))
                        counts_ok = (facts.get('arms') == 5 and facts.get('native_submissions') == 58 and
                            facts.get('final_live_versions') == 0) if arm == 'relay' else facts.get('control_and_candidate_arms') == 16
                        if not all(row['delivery_guards'].values()) or not counts_ok:
                            errors.append(dict(directory=row['directory'], reason='latest finite guard/count mismatch',
                                               guards=row['delivery_guards'], counts=row['delivery_counts']))
            finite.extend(attempts)
        if not folders:
            finite.append(dict(arm=arm, phase='finite_validation', state='not_run', directory=str(parent)))
    diagnostic = sample(anchor_path.parent, 'diagnostic', 'diagnostic', anchor, errors)
    phases = {}
    for phase in ('screen', 'final'):
        groups = {arm: median_group(x for x in runs if x['phase'] == phase and x['arm'] == arm)
                  for arm in ('control', 'candidate')}
        if all(groups[x]['count'] for x in groups):
            groups['candidate_vs_control_median_tps_change_percent'] = 100 * (
                groups['candidate']['median_decode_output_tokens_per_second'] /
                groups['control']['median_decode_output_tokens_per_second'] - 1)
        phases[phase] = groups
    incomplete = [x['directory'] for x in runs + finite if x['state'] in ('incomplete', 'not_run')]
    final_ready = (all(phases['final'][arm]['count'] for arm in ('control', 'candidate')) and not incomplete
                   and all(arm in finite_latest for arm in ('relay', 'ordinary')))
    if options.final and not final_ready:
        errors.append(dict(reason='final run set or finite validation remains incomplete', directories=incomplete))
    ready_pins = {arm: read(W / f'product-ready-{arm}.json') for arm in ('control', 'candidate', 'relay', 'ordinary')
                  if (W / f'product-ready-{arm}.json').exists()}
    historical_analyses = {p.name: dict(artifact=pin(p), analysis=read(p))
                          for p in (W / 'probe-attempt1-analysis.json', W / 'probe-attempt2-analysis.json') if p.exists()}
    peer_summary = W / 'peer-window/summary.json'
    peer = None
    if peer_summary.exists():
        summary = read(peer_summary)
        peer = dict(artifact=pin(peer_summary),
                    completion={k: summary.get(k) for k in ('status', 'processes', 'timing_processes', 'independent_memory_processes')},
                    scope='Current independent 32-process window completion only. Its timing/memory tables remain in this pinned summary; no pooling with ABBA and no old peer performance is substituted.')
        if summary.get('status') != 'COMPLETE32_FOUR_ARMS_STABLE' or summary.get('processes') != 32:
            errors.append(dict(reason='current peer-window completion mismatch', details=peer['completion']))
    result = dict(frozen=bool(options.final and final_ready and not errors), final_requested=options.final,
                  scope='This batch control/candidate only; screen and final windows are separate. Diagnostic and finite consumers are excluded from throughput medians. No peer comparison.',
                  method=dict(non_time_predicate_source='.scratch/inference-current-review-profile-20261027/analyze.py:29',
                              excluded_key_substrings=TIME_KEYS, strict='All retained keys, value types, nested sessions, list lengths/order and values compared recursively.',
                              medians='Median of every retained per-process TPS/elapsed sample in that phase/arm; no outlier exclusion or pooling between screen and final.',
                              preparation='Published prepared-line elapsed times only; not CPU self-time, GPU time or the total cost of cancelled successors.',
                              image_identity='Current ready pins are context only; they are not retroactive proof of the binary bytes used by older screen processes.',
                              finite_history='Retain every failed attempt as failed with its original exit/stderr and any existing analysis. Select the latest actual process per finite arm for delivery; only that attempt contributes the current guard result.'),
                  anchor=dict(artifact=pin(anchor_path), non_time_sha256=digest(non_time(anchor)),
                              generated_ids=anchor['sessions'][0]['result']['generated_ids'],
                              round_records=anchor['sessions'][0]['result']['rounds']),
                  diagnostic=diagnostic, cli_runs=runs, throughput_windows=phases, finite_validations=finite,
                  finite_latest=finite_latest, historical_fixture_analyses=historical_analyses,
                  independent_current_peer_window=peer,
                  current_ready_pins=ready_pins, validation_errors=errors, incomplete=incomplete,
                  expected_capture_change=dict(control=10, candidate=5, matched=all(x.get('capture_expectation', {}).get('equal', False)
                      for x in runs if x['state'] == 'terminal')))
    output = W / 'delivery-analysis.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(output=str(output), frozen=result['frozen'], cli_samples=len(runs),
                         finite_samples=len(finite), errors=len(errors), incomplete=incomplete,
                         throughput_windows=phases), ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
