"""Generate one current Graph TU with bounded stderr-only diagnostics."""
from pathlib import Path
import difflib
import hashlib
import json
import re

W = Path(__file__).resolve().parent
R = W.parents[1]
source = R / 'src/graph/executable.cc'
raw = source.read_bytes()
original = raw.decode('utf-8').replace('\r\n', '\n')
text = original
changes = []


def pin(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def one(old, new, label):
    global text
    assert text.count(old) == 1, (label, text.count(old))
    changes.append((old, new, label))
    text = text.replace(old, new, 1)


helper = r'''
// AUTO_CAPTURE: scratch-only bounded observations; no retained Graph handles.
namespace auto_capture_diag {
constexpr std::size_t none = SIZE_MAX;
std::atomic<unsigned> events{0}, misses{0};
template<class... A> void add(char *line, std::size_t cap, std::size_t &used,
    const char *format, A... args) noexcept {
  if (used >= cap - 1) return;
  const int n = std::snprintf(line + used, cap - used, format, args...);
  if (n > 0) used += (std::min)(std::size_t(n), cap - used - 1);
}
void tensor(char *line, std::size_t cap, std::size_t &used, const char *label,
    compute::ConstTensorView value) noexcept {
  const auto storage = value.storage(); const auto &desc = value.description();
  add(line, cap, used, " %s_valid=%u %s_resource=%p %s_handle=%p %s_offset=%zu %s_extent=%zu %s_type=%u %s_rank=%zu %s_dims=[",
      label, unsigned(value.valid()), label,
      storage.resource() ? static_cast<const void *>(&storage.resource().resource()) : nullptr,
      label, storage.native_handle(), label, storage.offset(), label, storage.size(),
      label, unsigned(desc.data_type()), label, std::size_t(desc.rank()), label);
  for (std::size_t i = 0; i < desc.rank(); ++i)
    add(line, cap, used, "%s%lld", i ? "," : "", static_cast<long long>(desc.dimensions()[i]));
  add(line, cap, used, "] %s_strides=[", label);
  for (std::size_t i = 0; i < desc.rank(); ++i)
    add(line, cap, used, "%s%lld", i ? "," : "", static_cast<long long>(desc.byte_strides()[i]));
  add(line, cap, used, "]");
}
void note(const detail::InvocationState *state, const detail::CaptureRebuildRange *saved,
    const char *event, const char *reason, std::size_t variant = none,
    std::size_t step = none, std::size_t port = none, std::size_t instance = none,
    const void *wrapper = nullptr, bool difference = false,
    compute::ConstTensorView before = {}, compute::ConstTensorView after = {},
    std::size_t begin = none, std::size_t count = 0) noexcept {
  if (difference) {
    const auto n = misses.fetch_add(1, std::memory_order_relaxed);
    if (n >= 512) {
      if (n == 512) std::fputs("AUTO_CAPTURE event=miss_limit limit=512\n", stderr);
      return;
    }
  }
  const auto seq = events.fetch_add(1, std::memory_order_relaxed);
  if (seq >= 8192) {
    if (seq == 8192) std::fputs("AUTO_CAPTURE event=event_limit limit=8192\n", stderr);
    return;
  }
  const auto *plan = state ? state->plan : nullptr;
  std::size_t value = none, node = none, range = none;
  if (saved && state) {
    range = std::size_t(saved - state->capture_rebuilds.data());
    begin = saved->step_begin; count = saved->step_count;
  }
  if (plan && instance < plan->instance_values.size()) value = plan->instance_values[instance];
  if (plan && step < plan->steps.size()) {
    const auto &selected = plan->steps[step];
    if (selected.node_count && selected.node_set_begin < plan->step_nodes.size())
      node = plan->step_nodes[selected.node_set_begin];
  }
  char line[4096]{}; std::size_t used = 0;
  add(line, sizeof(line), used,
      "AUTO_CAPTURE event=%s seq=%u reason=%s wrapper=%p state=%p plan=%p range=%zu begin=%zu count=%zu variant=%zu step=%zu first_node=%zu port=%zu instance=%zu value=%zu closed=%u",
      event, seq, reason, wrapper, static_cast<const void *>(state), static_cast<const void *>(plan),
      range, begin, count, variant, step, node, port, instance, value, unsigned(state && state->closed));
  if (state) add(line, sizeof(line), used, " live_ranges=%zu saved_ranges=%zu", state->captured_ranges.size(), state->capture_rebuilds.size());
  if (saved) add(line, sizeof(line), used,
      " active=%u last_used=%u qualification=%u private=%u key0=%u command0=%u key1=%u command1=%u seed=%u",
      unsigned(saved->active_variant), unsigned(saved->last_used), unsigned(saved->qualification_valid),
      unsigned(saved->preserves_private_arguments), unsigned(saved->variants[0].key_valid),
      unsigned(saved->variants[0].commands.valid()), unsigned(saved->variants[1].key_valid),
      unsigned(saved->variants[1].commands.valid()), unsigned(saved->storage.valid()));
  if (state && step < state->step_bindings.size()) {
    const auto &binding = state->step_bindings[step];
    add(line, sizeof(line), used, " revision=%llu prepared_revision=%llu stable=%u native_inputs=%u",
        static_cast<unsigned long long>(binding.revision), static_cast<unsigned long long>(binding.prepared_revision),
        unsigned(binding.stable_binding_identity), unsigned(binding.native_inputs));
  }
  if (difference) {
    const auto a = before.storage(), b = after.storage();
    add(line, sizeof(line), used, " same_address=%u same_description=%u",
        unsigned(a.resource() == b.resource() && a.native_handle() == b.native_handle() && a.offset() == b.offset() && a.size() == b.size()),
        unsigned(before.description() == after.description()));
    tensor(line, sizeof(line), used, "old", before); tensor(line, sizeof(line), used, "new", after);
  }
  std::fprintf(stderr, "%s\n", line);
}
void clear(const detail::InvocationState &state, const detail::CaptureRebuildRange &saved,
    const char *reason, std::size_t step = none) noexcept {
  if (saved.storage.valid() || saved.active_variant < 2 || saved.variants[0].key_valid ||
      saved.variants[1].key_valid || saved.variants[0].commands.valid() || saved.variants[1].commands.valid())
    note(&state, &saved, "clear", reason, none, step);
}
ReplayRoute reject(const detail::InvocationState &state, const char *reason) noexcept {
  note(&state, nullptr, "reuse_reject", reason); return ReplayRoute::kUnprepared;
}
} // namespace auto_capture_diag

'''
one('#include <array>\n', '#include <array>\n#include <atomic>\n#include <cstdio>\n', 'standard diagnostic headers')
one('void reset_capture_cache(detail::InvocationState &invocation) noexcept {', helper +
    'void reset_capture_cache(detail::InvocationState &invocation) noexcept {\n'
    '  if (!invocation.captured_ranges.empty() || !invocation.capture_rebuilds.empty())\n'
    '    auto_capture_diag::note(&invocation, nullptr, "clear_all", "reset_capture_cache");', 'bounded helper and complete cache clear')

# Preserve every original condition, short circuit and port++ evaluation.
one('''  if (!variant.key_valid)
    return false;
  std::size_t port = 0;''', '''  if (!variant.key_valid) {
    auto_capture_diag::note(&invocation, &saved, "key_invalid", "prepare_key", std::size_t(&variant - saved.variants.data()));
    return false;
  }
  std::size_t port = 0;''', 'prepare invalid key')
one('''    for (std::size_t input = 0; input < step.input_count; ++input)
      if (port == variant.bindings.size() ||
          !same_physical_tensor(variant.bindings[port++],
              invocation.submission_inputs[step.input_begin + input]))
        return false;
    for (std::size_t output = 0; output < step.output_count; ++output)
      if (port == variant.bindings.size() ||
          !same_physical_tensor(variant.bindings[port++],
              invocation.submission_outputs[step.output_begin + output].as_const()))
        return false;''', '''    for (std::size_t input = 0; input < step.input_count; ++input) {
      const auto diagnostic_port = port;
      if (port == variant.bindings.size() ||
          !same_physical_tensor(variant.bindings[port++],
              invocation.submission_inputs[step.input_begin + input])) {
        auto_capture_diag::note(&invocation, &saved, "key_miss", "prepare_first_input", std::size_t(&variant - saved.variants.data()),
            index, input, invocation.plan->node_inputs[step.input_begin + input], nullptr, true,
            diagnostic_port < variant.bindings.size() ? variant.bindings[diagnostic_port] : compute::ConstTensorView{},
            invocation.submission_inputs[step.input_begin + input]);
        return false;
      }
    }
    for (std::size_t output = 0; output < step.output_count; ++output) {
      const auto diagnostic_port = port;
      if (port == variant.bindings.size() ||
          !same_physical_tensor(variant.bindings[port++],
              invocation.submission_outputs[step.output_begin + output].as_const())) {
        auto_capture_diag::note(&invocation, &saved, "key_miss", "prepare_first_output", std::size_t(&variant - saved.variants.data()),
            index, output, invocation.plan->node_outputs[step.output_begin + output], nullptr, true,
            diagnostic_port < variant.bindings.size() ? variant.bindings[diagnostic_port] : compute::ConstTensorView{},
            invocation.submission_outputs[step.output_begin + output].as_const());
        return false;
      }
    }''', 'prepare first different input or output')

start = text.index('Result<ReplayRoute> reusable_capture_tuple(')
end = text.index('\nStatus prepare_replay_impl(', start)
old = text[start:end]
new = old
reasons = ['topology_or_empty_commands', 'actual_queue', 'capture_coverage', 'unstable_or_native_inputs',
    'region_private_contract', 'operation_private_contract', 'unsupported_step_kind',
    'missing_or_unqualified_saved_range', 'no_matching_live_recording']
assert new.count('return ReplayRoute::kUnprepared;') == len(reasons)
for reason in reasons:
    new = new.replace('return ReplayRoute::kUnprepared;', 'return auto_capture_diag::reject(state, "' + reason + '");', 1)
new = new.replace('''      if (!variant.key_valid) return false;''', '''      if (!variant.key_valid) {
        auto_capture_diag::note(&state, &*saved, "key_invalid", "reuse_key", std::size_t(&variant - saved->variants.data()));
        return false;
      }''')
for kind in ('input', 'output'):
    actual = 'tensor' if kind == 'input' else 'tensor.as_const()'
    old_check = '''          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], ''' + actual + '''))
            return false;'''
    new_check = '''          const auto diagnostic_port = port;
          if (port == variant.bindings.size() || !tensor.valid() ||
              !same_physical_tensor(variant.bindings[port++], ''' + actual + ''')) {
            auto_capture_diag::note(&state, &*saved, "key_miss", "reuse_first_''' + kind + '''", std::size_t(&variant - saved->variants.data()),
                index, ''' + kind + ', ' + ('instance' if kind == 'input' else 'plan.node_outputs[step.output_begin + output]') + ''', nullptr, true,
                diagnostic_port < variant.bindings.size() ? variant.bindings[diagnostic_port] : compute::ConstTensorView{}, ''' + actual + ''');
            return false;
          }'''
    assert new.count(old_check) == 1
    new = new.replace(old_check, new_check)
one(old, new, 'reuse-only route reasons and first different port in each compared variant')

# The alias proof's original early exits distinguish raw address changes from
# same-address refusal by its existing layout/materialization/availability gates.
one('''      if (!unchanged) return false;
    }
    const auto instance = plan.external_instances[input.ordinal()];''', '''      if (!unchanged) {
        const auto root = plan.external_instances[input.ordinal()];
        const auto before = root < state->readable.size() ? state->readable[root] : compute::ConstTensorView{};
        auto_capture_diag::note(state, nullptr, "alias_reject",
            same_physical_tensor(before, replacement.tensor) ? "same_physical_root_full_view_proof_refused" : "physical_root_changed",
            auto_capture_diag::none, auto_capture_diag::none, i, root, &invocation, true, before, replacement.tensor);
        return false;
      }
    }
    const auto instance = plan.external_instances[input.ordinal()];''', 'alias replacement denial, same root versus physical change')

# Diagnostic identity maps use only existing public/private entry arguments.
one('''                                  ReplayOptions options) noexcept {
  return prepare_replay_impl(state_, queues, options, false);''', '''                                  ReplayOptions options) noexcept {
  auto_capture_diag::note(state_, nullptr, "entry", "prepare_replay", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, this);
  return prepare_replay_impl(state_, queues, options, false);''', 'public Invocation wrapper to state mapping')
one('''  const auto *state = InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  const auto &plan = *state->plan;
  bool identical_replacements = true;''', '''  const auto *state = InvocationAccess::state(invocation);
  auto_capture_diag::note(state, nullptr, "entry", "can_reuse_capture", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, &invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  const auto &plan = *state->plan;
  bool identical_replacements = true;''', 'Source probe wrapper to state mapping')
one('''Status detail::ReplayAccess::prepare_reuse(Invocation &invocation,
    std::span<const QueueBinding> queues) noexcept {
  auto *state = InvocationAccess::state(invocation);''', '''Status detail::ReplayAccess::prepare_reuse(Invocation &invocation,
    std::span<const QueueBinding> queues) noexcept {
  auto *state = InvocationAccess::state(invocation);
  auto_capture_diag::note(state, nullptr, "entry", "prepare_reuse", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, &invocation);''', 'Source preparation wrapper to state mapping')

one('''Status Invocation::reset() noexcept {
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));''', '''Status Invocation::reset() noexcept {
  auto_capture_diag::note(state_, nullptr, "reset_begin", "original_reset", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, this);
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));''', 'original reset entry identity')
one('''  detail::reset_resource_bindings(*state_);
  rebuild_external_alias_index(*state_);
  return Status::Ok();''', '''  detail::reset_resource_bindings(*state_);
  rebuild_external_alias_index(*state_);
  auto_capture_diag::note(state_, nullptr, "reset_end", "original_reset_success", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, this);
  return Status::Ok();''', 'original reset success')
one('''Invocation::~Invocation() {
  // The observation''', '''Invocation::~Invocation() {
  if (state_) auto_capture_diag::note(state_, nullptr, "destroy_wrapper", "original_destructor", auto_capture_diag::none,
      auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, this);
  // The observation''', 'original wrapper destruction identity')
one('''Invocation &Invocation::operator=(Invocation &&other) noexcept {
  if (this != &other) {''', '''Invocation &Invocation::operator=(Invocation &&other) noexcept {
  if (this != &other) {
    if (state_) auto_capture_diag::note(state_, nullptr, "release_wrapper", "original_move_assignment", auto_capture_diag::none,
        auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, this);''', 'original wrapper root release identity')

start = text.index('void invalidate_recording(detail::InvocationState &invocation,\n                          std::uint32_t selected_step,\n                          CaptureInvalidation mode) noexcept {')
end = text.index('\n} // namespace\n\nvoid detail::invalidate_step_recording', start)
old = text[start:end]
new = old.replace('''        discard_capture_variants(saved);''', '''        auto_capture_diag::clear(invocation, saved, "invalidation_discard", selected_step);
        discard_capture_variants(saved);''').replace('''        discard_capture_variants(*saved);''', '''        auto_capture_diag::clear(invocation, *saved, "captured_range_discard", selected_step);
        discard_capture_variants(*saved);''')
new = new.replace('''        variant.commands = std::move(invocation.captured_ranges[index].commands);''', '''        auto_capture_diag::note(&invocation, saved, "dormant", "stable_bindings", saved->active_variant, selected_step);
        variant.commands = std::move(invocation.captured_ranges[index].commands);''')
new = new.replace('''      } else if (ordinary) {
        saved->storage''', '''      } else if (ordinary) {
        auto_capture_diag::note(&invocation, saved, "seed", "ordinary_without_key", saved->active_variant, selected_step);
        saved->storage''')
one(old, new, 'original invalidation clear, dormant and seed events')

start = text.index('Status prepare_replay_impl(detail::InvocationState *state_,')
end = text.index('\n} // namespace\n\nStatus Invocation::prepare_replay', start)
old = text[start:end]
new = re.sub(r'(?m)^([ \t]*)discard_capture_variants\((\*?saved)\);',
    lambda m: m[1] + '{\n' + m[1] + '  auto_capture_diag::clear(*state_, ' + m[2] + ', "prepare_discard");\n'
        + m[1] + '  ' + m[0].lstrip() + '\n' + m[1] + '}', old)
new = new.replace('''      ++reused_range_count;
      captured_command_count += candidate.command_count;
      continue;''', '''      auto_capture_diag::note(state_, nullptr, "reuse", "live_range", auto_capture_diag::none,
          auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, nullptr, false, {}, {}, range.step_begin, range.step_count);
      ++reused_range_count;
      captured_command_count += candidate.command_count;
      continue;''')
new = new.replace('''      if (selected_variant < 2) {
        ++reused_range_count;''', '''      if (selected_variant < 2) {
        auto_capture_diag::note(state_, saved, "reuse", "dormant_variant", selected_variant);
        ++reused_range_count;''')
new = new.replace('''      auto &evicted = saved->variants[selected_variant];''', '''      auto &evicted = saved->variants[selected_variant];
      if (evicted.key_valid || evicted.commands.valid())
        auto_capture_diag::note(state_, saved, "evict", "replace_selected_variant", selected_variant);''')
new = new.replace('''    compute::Queue *queue = candidate_queue(queues, segment.lane);''', '''    auto_capture_diag::note(state_, saved, "record_begin",
        saved == nullptr ? "missing_saved_range" : saved->preserves_private_arguments ? "no_matching_key" : "private_arguments_not_preserved",
        selected_variant, auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none,
        nullptr, false, {}, {}, range.step_begin, range.step_count);
    compute::Queue *queue = candidate_queue(queues, segment.lane);''')
new = new.replace('''    ++recorded_range_count;''', '''    auto_capture_diag::note(state_, saved, "record_end", stable_identity ? "stable_identity" : "unstable_identity", selected_variant,
        auto_capture_diag::none, auto_capture_diag::none, auto_capture_diag::none, nullptr, false, {}, {}, range.step_begin, range.step_count);
    ++recorded_range_count;''')
one(old, new, 'original prepare branch clear, reuse, eviction, record begin and success')

# Reverse every exact substitution to prove all original algorithms/returns
# survived. Diagnostics only observe existing decisions; no callback is stored.
inverse = text
for old, new, label in reversed(changes):
    assert inverse.count(new) == 1, ('inverse', label, inverse.count(new))
    inverse = inverse.replace(new, old, 1)
assert inverse == original
target = W / 'source/src/graph/executable.cc'
target.parent.mkdir(parents=True, exist_ok=True)
if target.exists():
    prior = json.loads((W / 'instrumentation.json').read_bytes())
    assert pin(target) == prior['generated'] and pin(source) == prior['product'], 'Do not replace untracked bytes'
target.write_bytes(text.encode('utf-8'))
patch = W / 'graph-diagnostic.diff'
patch.write_text(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
    fromfile='product/src/graph/executable.cc', tofile='scratch/src/graph/executable.cc')), encoding='utf-8')
manifest = dict(status='SCRATCH_GRAPH_DIAGNOSTICS_PREPARED_NOT_COMPILED_NOT_RUN',
    product=pin(source), generated=pin(target), generator=pin(Path(__file__)), patch=pin(patch),
    inverse_exactly_recovers_normalized_product=True,
    replacements=[dict(name=label, original_line=(original[:original.index(old)].count('\n') + 1) if old in original else None,
        original_occurrences=original.count(old)) for old, new, label in changes],
    identity='wrapper is original graph::Invocation address; state is original InvocationState*. Entry lines map them. plan/value/step/node are original Graph facts; no diagnostic ID is an owner.',
    bounds=dict(total_lines=8192, tensor_mismatch_lines=512, overflow_line='AUTO_CAPTURE event=event_limit or miss_limit'),
    scope=['One copied executable.cc, no SDK/source-tree copy or new product header.',
        'Original short circuits, port increments, branches, statuses, permission and retirement calls retained.',
        'Only the first differing port of each already performed variant comparison is printed; no added tensor/key scan.',
        'Tensor data is never read. Fixed stack formatting reports borrowed descriptor/address facts only.',
        'Alias refusal distinguishes same physical root with failed original full-view proof from actual root change; neither implies permission.',
        'No compiler, inference, profiler, git or download is launched. Root owns one64-output auto run.'])
(W / 'instrumentation.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(manifest['generated']))
