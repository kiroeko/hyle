"""One current MTP-auto diagnostic process; reuse the existing227-input SDK."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('process',R/'.scratch/inference-program-identity-20261029/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
OLD=R/'.scratch/inference-paired-m2-20261030'


def prepare():
    base_path=OLD/'model-link-base.json';base=read(base_path)
    assert len(base['retained'])==227
    for item in [*base['retained'],base['runtime'],base['sdk_engine_dependencies']]:exact(item)
    graph_recipe=read(R/'.scratch/inference-view-spans-20261028/validation/logs/executable/command.json')['command']
    cli_recipe=read(OLD/'model-plan.json')['cli']['compile']
    units={}
    for name,recipe,source in [('graph',graph_recipe,W/'source/src/graph/executable.cc'),('cli',cli_recipe,W/'cli.cc')]:
        folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
        if name=='cli':source.write_text('#include "source/engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
        args=[]
        for i,arg in enumerate(recipe):
            if i and recipe[i-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif arg.lower().endswith('.cc'):arg=str(source)
            args.append(arg)
        assert sum(key(x)==key(source) for x in args)==1
        units[name]=dict(source=str(source),compile=args)
    (W/'bin').mkdir(exist_ok=True);exact(base['runtime'])
    shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
    args=read(OLD/'model-plan.json')['speed']['single-mtp-auto']['args']
    assert args[args.index('--decode-overlap')+1]=='auto'
    save(W/'plan.json',dict(base=pin(base_path),retained=base['retained'],runtime=base['runtime'],
        original_link=base['link'],original_consumer=base['previous_consumer'],units=units,args=args,
        graph_original=pin(R/'.scratch/inference-view-spans-20261028/validation/compile/executable/unit.obj'),
        baseline_cli=read(OLD/'compile/cli/receipt.json')['object'],
        source_base_commit='0d1ef9a87',previous_goal_turn='PROGRESS: product implementation, finite checks, fresh32process comparison and pushed commit.'))
    print('Prepared two finite diagnostic TUs, one link/run;227 original SDK inputs retained.')


def compile_unit(name,attempt):
    plan=read(W/'plan.json');unit=plan['units'][name];folder=W/'compile'/name
    b.execute(unit['compile'],folder/attempt,600)
    deps=read(folder/'dependencies.json')['Data']
    files=sorted({Path(p).resolve() for p in [deps['Source'],*deps['Includes']] if Path(p).is_relative_to(R)})
    save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),source_identities=[pin(p) for p in files],
        dependencies=pin(folder/'dependencies.json'),process=pin(folder/attempt/'process.json')))


def link(name,attempt):
    assert name in ('diagnostic','control')
    plan=read(W/'plan.json')
    for p in plan['retained']:exact(p)
    old=read(plan['original_consumer']['path'])['object']['path']
    cli=read(W/'compile/cli/receipt.json')['object'] if name=='diagnostic' else plan['baseline_cli']
    exact(cli)
    graph=read(W/'compile/graph/receipt.json')['object'] if name=='diagnostic' else plan['graph_original']
    exact(graph)
    args=[]
    for arg in plan['original_link']:
        if key(arg)==key(old):arg=cli['path']
        elif key(arg)==key(plan['graph_original']['path']):arg=graph['path']
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
        args.append(arg)
    b.execute(args,W/'link'/name/attempt,240)
    save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))


def run(name,attempt):
    plan=read(W/'plan.json');image=read(W/('ready-'+name+'.json'));exact(image)
    folder=W/'runs'/name/attempt
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    b.execute([image['path'],*plan['args']],folder,600)
    report=read(folder/'stdout.log')
    assert report['generated_tokens']==64 and report['draft_rounds']==34
    save(folder/'consumer-result.json',report)
    print('Recorded',name,'64 outputs; diagnostic times are not TPS evidence.')


if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:
        action,name=sys.argv[1:3];attempt=sys.argv[3] if len(sys.argv)>3 else 'attempt1'
        {'compile':compile_unit,'link':link,'run':run}[action](name,attempt)
