"""Product CLI and finite Source consumer; retain the original 227 SDK inputs."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('diagnostic_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    prior = read(W / 'plan.json')
    base = read(prior['base']['path'])
    for item in [*prior['retained'], prior['runtime'], prior['baseline_cli']]: exact(item)
    sdk = read(base['sdk_engine_dependencies']['path'])
    for unit in sdk['engine_consumers']:
        for item in unit['source_identities']: exact(item)
        assert not any('execution_episode.h' in x['path'] for x in unit['source_identities'])
    wrapper = W / 'product-cli.cc'
    wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    recipes = read(R / '.scratch/inference-source-preparation-20261030/plan.json')
    units = {}
    for name, source, recipe in [
        ('candidate', wrapper, read(R / '.scratch/inference-paired-m2-20261030/model-plan.json')['cli']['compile']),
        ('relay', R / 'tests/tools/qwen_submission_source_probe.cc', recipes['units']['relay']['compile']),
        ('ordinary', R / 'tests/tools/qwen_generation_batch_relay_probe.cc', recipes['units']['ordinary']['compile'])]:
        folder = W / 'product-compile' / name; folder.mkdir(parents=True, exist_ok=True)
        args = []
        for i, arg in enumerate(recipe):
            if i and recipe[i-1].lower() == '/sourcedependencies': arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
            elif arg.lower().endswith('.cc'): arg = str(source)
            args.append(arg)
        assert sum(key(x) == key(source) for x in args) == 1
        units[name] = dict(source=str(source), compile=args)
    old = read(prior['original_consumer']['path'])['object']['path']
    assert sum(key(x) == key(old) for x in prior['original_link']) == 1
    ordinary = W / 'ordinary-input'; ordinary.mkdir(exist_ok=True)
    for file in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(Path(recipes['cases']['continuous-cuda']['args'][-1]) / file, ordinary / file)
    ordinary_args = [*recipes['cases']['continuous-cuda']['args'][:-1], str(ordinary)]
    save(W / 'delivery-plan.json', dict(units=units, retained=prior['retained'], runtime=prior['runtime'],
        link=prior['original_link'], original_consumer=old, baseline_cli=prior['baseline_cli'], args=prior['args'],
        relay_args=recipes['cases']['relay-cuda']['args'],
        ordinary_args=ordinary_args,
        base_commit='0d1ef9a87', sdk=pin(base['sdk_engine_dependencies']['path'])))
    print('Prepared product consumers; 227 original SDK inputs unchanged; no diagnostic Graph.')

def compile_unit(name, attempt):
    p = read(W / 'delivery-plan.json'); folder = W / 'product-compile' / name
    b.b.execute(p['units'][name]['compile'], folder / attempt, 600)
    deps = read(folder / 'dependencies.json')['Data']
    files = sorted({Path(x).resolve() for x in [deps['Source'], *deps['Includes']] if Path(x).is_relative_to(R)})
    save(folder / 'receipt.json', dict(object=pin(folder/'unit.obj'), source_identities=[pin(x) for x in files],
        dependencies=pin(folder/'dependencies.json'), process=pin(folder/attempt/'process.json')))

def link(name, attempt):
    p = read(W / 'delivery-plan.json')
    for item in p['retained']: exact(item)
    obj = p['baseline_cli'] if name == 'control' else read(W/'product-compile'/name/'receipt.json')['object']
    exact(obj); args = []
    for arg in p['link']:
        if key(arg) == key(p['original_consumer']): arg = obj['path']
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix): arg = prefix + str((W/'bin'/name).with_suffix(suffix)); break
        args.append(arg)
    assert sum(key(x) == key(obj['path']) for x in args) == 1
    b.b.execute(args, W/'product-link'/name/attempt, 240)
    save(W/('product-ready-'+name+'.json'), pin(W/'bin'/(name+'.exe')))

def run(name, attempt):
    p = read(W/'delivery-plan.json'); image = read(W/('product-ready-'+name+'.json')); exact(image)
    args = p['relay_args'] if name == 'relay' else p['ordinary_args'] if name == 'ordinary' else p['args']
    folder = W/'product-runs'/name/attempt
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    b.b.execute([image['path'], *args], folder, 600)
    report = read(folder/'stdout.log')
    if name in ('relay', 'ordinary'): assert report['status'] == 'PASS'
    else: assert report['generated_tokens'] == 64 and report['draft_rounds'] == 34
    save(folder/'report.json', report)
    print('PASS bounded current product', name)

if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare()
    else:
        action, name = sys.argv[1:3]; attempt = sys.argv[3] if len(sys.argv)>3 else 'attempt1'
        {'compile': compile_unit, 'link': link, 'run': run}[action](name, attempt)
