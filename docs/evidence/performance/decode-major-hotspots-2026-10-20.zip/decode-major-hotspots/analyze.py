from pathlib import Path
import sqlite3,collections,json,statistics,re,hashlib
B=Path('.scratch/architecture-refactor-2026-10-18');S=B/'decode-major-hotspots';S.mkdir(exist_ok=True)
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dist(a):return dict(mean=statistics.mean(a),median=statistics.median(a),min=min(a),max=max(a),samples=a)
def merged(a):
 z=[]
 for x,y in sorted(a):
  if not z or x>z[-1][1]:z.append([x,y])
  else:z[-1][1]=max(z[-1][1],y)
 return z
def union(a):return sum(y-x for x,y in merged(a))
def family(n):
 if 'internal::gemvx::kernel<'in n:return 'projection_cublas'
 if 'mul_mat_vec_f<'in n:return 'projection_FFN_dual'if'hyle_bf16_dual_matvec_silu_epilogue'in n else'projection_paired'if'void, (bool)0, (bool)1>'in n else'projection_peer_MMVF'
 if 'gated_delta_net' in n:return 'GDN_core'
 if 'ssm_conv' in n:return 'causal_conv'
 if 'flashinfer::'in n or'flash_attn_ext_vec<'in n:return 'dense_attention'
 if 'hyle_bf16_l2_core'in n:return 'GDN_L2'
 if 'cpy_scalar_contiguous'in n:return 'copy_cast_contiguous'
 if 'cpy_scalar'in n:return 'layout_copy'
 if 'rms_norm'in n:return 'RMSNorm'
 if 'concat'in n:return 'concat'
 if 'set_rows'in n or'single_update'in n:return 'KV_update'
 if 'rope'in n:return 'RoPE'
 if 'GatherOutput'in n or'get_rows'in n:return 'gather'
 if any(x in n for x in ['ArgPair','ArgValue','ArgIndex','argmax_f32']):return 'argmax'
 return 'elementwise_other'
w={}
for line in (B/'qwen-gpu-comparison/128-prefill/inputs/weights.tsv').read_text().splitlines()[3:]:
 f=line.split();n,d,r=f[:3];r=int(r);w[n.removeprefix('model.language_model.')]=dict(name=n,dtype=d,shape=list(map(int,f[3:r+3])),bytes=int(f[-1]))
def roles(arm):
 z=[]
 for l in range(24):
  pre='layers.'+str(l)+'.'; p=[]
  if l%4!=3:
   p=[('GDN_qkv',['linear_attn.in_proj_qkv.weight'])]
   p += [('GDN_ab_pair',['linear_attn.in_proj_a.weight','linear_attn.in_proj_b.weight'])]if arm=='hyle'else[('GDN_ab',['linear_attn.in_proj_a.weight']),('GDN_ab',['linear_attn.in_proj_b.weight'])]
   p += [('GDN_z',['linear_attn.in_proj_z.weight']),('GDN_output',['linear_attn.out_proj.weight'])]
  else:p=[('dense_Q',['self_attn.q_proj.weight']),('dense_KV',['self_attn.k_proj.weight']),('dense_KV',['self_attn.v_proj.weight']),('dense_output',['self_attn.o_proj.weight'])]
  p += [('FFN_gate_up',['mlp.gate_proj.weight','mlp.up_proj.weight']),('FFN_down',['mlp.down_proj.weight'])]
  for role,names in p:
   mats=[w[pre+n]for n in names];z.append(dict(role=role,layer=l,weights=mats,logical_weight_bytes=sum(v['bytes']for v in mats)))
 z.append(dict(role='LM_head',layer=None,weights=[w['embed_tokens.weight']],logical_weight_bytes=w['embed_tokens.weight']['bytes']))
 return z
out={}
for arm,name in [('hyle','paired-projection-route/profile/capture.sqlite'),('peer','decode-critical-path/peer/decode.sqlite')]:
 p=B/name;c=sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row;strings=dict(c.execute('select id,value from StringIds'));tables={v[0]for v in c.execute("select name from sqlite_master where type='table'")}
 k=[dict(v,name=strings[v['demangledName']])for v in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL order by start')];cp=[dict(v)for v in c.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY order by start')];rt=[dict(v,name=re.sub(r'_v[0-9]+$','',strings[v['nameId']]))for v in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME order by start')];ms=[dict(v)for v in c.execute('select * from CUPTI_ACTIVITY_KIND_MEMSET order by start')]if'CUPTI_ACTIVITY_KIND_MEMSET'in tables else[];c.close()
 tok=sorted([v for v in cp if v['copyKind']==2 and v['bytes']==4],key=lambda v:v['end']);logits=sorted([v for v in cp if v['copyKind']==2 and v['bytes']==993280],key=lambda v:v['end']);assert len(tok)==32;assert len(logits)==(32 if arm=='peer' else 0)
 plan=roles(arm);fam=collections.defaultdict(list);role=collections.defaultdict(list);api=collections.defaultdict(list);symbols=collections.defaultdict(list);ph=[];mapped=[];copygroups=collections.defaultdict(list);apicounts=collections.defaultdict(list)
 for i in range(7,32):
  lo,hi=tok[i-1]['end'],tok[i]['end'];corelo=logits[i-1]['end']if arm=='peer'else lo
  a=[v for v in k if lo<v['start']and v['end']<=hi];b=[v for v in cp if lo<v['start']and v['end']<=hi];r=[v for v in rt if lo<v['start']and v['end']<=hi];m=[v for v in ms if lo<v['start']and v['end']<=hi];act=[(v['start'],v['end'])for v in a+b+m];first=a[0]['start'];last=a[-1]['end'];allunion=union(act);kernunion=union((v['start'],v['end'])for v in a);proj=[v for v in a if family(v['name']).startswith('projection_')];assert len(proj)==len(plan),(arm,i,len(proj),len(plan))
  ph.append(dict(index=i,total_kernels=len(a),projection_kernels=len(proj),nonprojection_kernels=len(a)-len(proj),readback_interval_us=(hi-lo)/1000,core_window_excluding_peer_extra_previous_logits_us=(hi-corelo)/1000,kernel_sum_us=sum(v['end']-v['start']for v in a)/1000,kernel_union_us=kernunion/1000,device_union_us=allunion/1000,no_traced_device_activity_us=(hi-lo-allunion)/1000,prefix_before_first_kernel_us=(first-lo)/1000,core_prefix_before_first_kernel_us=(first-corelo)/1000,internal_no_device_activity_us=((last-first)-union((max(first,x),min(last,y))for x,y in act if max(first,x)<min(last,y)))/1000,tail_after_last_kernel_us=(hi-last)/1000,graph_launches=sum(v['name']=='cudaGraphLaunch'for v in r),D2H_bytes=sum(v['bytes']for v in b if v['copyKind']==2),D2D_bytes=sum(v['bytes']for v in b if v['copyKind']==8),H2D_bytes=sum(v['bytes']for v in b if v['copyKind']==1)))
  for f in set(family(v['name'])for v in a):fam[f].append(dict(count=sum(family(v['name'])==f for v in a),us=sum(v['end']-v['start']for v in a if family(v['name'])==f)/1000))
  for nm in set(v['name']for v in r):api[nm].append(sum(v['end']-v['start']for v in r if v['name']==nm)/1000);apicounts[nm].append(sum(v['name']==nm for v in r))
  for nm in set(v['name']for v in a):symbols[nm].append(dict(count=sum(v['name']==nm for v in a),us=sum(v['end']-v['start']for v in a if v['name']==nm)/1000))
  for label in set((v['copyKind'],v['bytes'])for v in b):copygroups[str(label)].append(dict(count=sum((v['copyKind'],v['bytes'])==label for v in b),us=sum(v['end']-v['start']for v in b if(v['copyKind'],v['bytes'])==label)/1000))
  perrole=collections.defaultdict(float)
  for idx,(v,t)in enumerate(zip(proj,plan)):
   perrole[t['role']]+=(v['end']-v['start'])/1000
   n=t['weights'][0]['shape'][0];expected=(n if arm=='peer'or family(v['name'])!='projection_cublas'else(n+3)//4);assert v['gridX']==expected,(arm,i,idx,v['gridX'],expected,t['role'])
   if i==7:mapped.append(dict(t,projection_index=idx,kernel_ordinal=a.index(v),symbol=v['name'],grid=[v['gridX'],v['gridY'],v['gridZ']],block=[v['blockX'],v['blockY'],v['blockZ']]))
  for nm,x in perrole.items():role[nm].append(x)
 out[arm]=dict(sqlite=ident(p),phase_definition='decode7..31, previous4B tokenD2H end through current4B tokenD2H end. Peer core prefix separately begins after previous993280B logits D2H.',phases=ph,phase_stats={key:dist([x[key]for x in ph])for key in ph[0]if key!='index'},families={key:dict(count=dist([x['count']for x in v]),us=dist([x['us']for x in v]))for key,v in fam.items()},projection_roles={key:dict(us=dist(v),logical_weight_bytes=sum(x['logical_weight_bytes']for x in plan if x['role']==key),count=sum(x['role']==key for x in plan))for key,v in role.items()},apis={key:dict(us=dist(v),counts=dist(apicounts[key]))for key,v in api.items()},symbols={key:dict(count=dist([x['count']for x in v]),us=dist([x['us']for x in v]))for key,v in symbols.items()},copy_groups={key:dict(count=dist([x['count']for x in v]),us=dist([x['us']for x in v]))for key,v in copygroups.items()},mapped_decode7=mapped,logical_projection_weight_bytes=sum(v['logical_weight_bytes']for v in plan))
(S/'trace-analysis.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
for arm,d in out.items():
 print('\nARM',arm)
 print('phase_stats',{k:{a:round(v[a],3)for a in ['mean','median','min','max']}for k,v in d['phase_stats'].items()})
 print('families',[(k,round(v['us']['median'],3),v['count']['median'])for k,v in sorted(d['families'].items(),key=lambda x:-x[1]['us']['median'])]);print('roles',[(k,round(v['us']['median'],3),v['logical_weight_bytes'])for k,v in sorted(d['projection_roles'].items(),key=lambda x:-x[1]['us']['median'])]);print('apis',[(k,round(v['us']['median'],3),v['counts']['median'])for k,v in sorted(d['apis'].items(),key=lambda x:-x[1]['us']['median'])[:14]]);print('copies',[(k,v['count']['median'],round(v['us']['median'],3))for k,v in d['copy_groups'].items()]);print('topnonMMsymbols',[(k,round(v['us']['median'],3),v['count']['median'])for k,v in sorted(d['symbols'].items(),key=lambda x:-x[1]['us']['median'])if not family(k).startswith('projection_')][:12])

# Runtime waits can straddle a token-copy endpoint. Keep clipped intersections
# separately from the above fully-contained API statistics; neither is a CPU
# work attribution and neither may be added to the GPU duration sums.
intersections = {}
for arm, analyzed in out.items():
 p = Path(analyzed['sqlite']['path'])
 c = sqlite3.connect(p.resolve().as_uri() + '?mode=ro', uri=True)
 c.row_factory = sqlite3.Row
 strings = dict(c.execute('select id,value from StringIds'))
 tokens = list(c.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY where copyKind=2 and bytes=4 order by end'))
 kernels = [dict(v) for v in c.execute('select * from CUPTI_ACTIVITY_KIND_KERNEL')]
 copies = [dict(v) for v in c.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY')]
 runtime = [dict(v, name=re.sub(r'_v[0-9]+$', '', strings[v['nameId']]))
            for v in c.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME')]
 c.close()
 phases = []
 watched = ['cudaGraphLaunch', 'cudaEventSynchronize', 'cudaStreamSynchronize',
            'cuStreamSynchronize', 'cuMemcpyDtoH']
 for i in range(7, 32):
  lo, hi = tokens[i-1]['end'], tokens[i]['end']
  device = [(max(lo, v['start']), min(hi, v['end'])) for v in kernels + copies
            if v['start'] < hi and v['end'] > lo]
  calls = [v for v in runtime if v['start'] < hi and v['end'] > lo]
  apis = {}
  for name in watched:
   matching = [v for v in calls if v['name'] == name]
   clipped = [(max(lo, v['start']), min(hi, v['end'])) for v in matching]
   covered = union((max(a, x), min(b, y)) for a, b in clipped for x, y in device
                   if max(a, x) < min(b, y))
   apis[name] = dict(calls_intersecting=len(matching),
       clipped_duration_us=union(clipped)/1000,
       clipped_overlap_device_activity_us=covered/1000,
       clipped_outside_device_activity_us=(union(clipped)-covered)/1000,
       straddling_count=sum(v['start'] < lo or v['end'] > hi for v in matching))
  phases.append(dict(index=i, APIs=apis))
 intersections[arm] = dict(phases=phases,
     median={name: {field: statistics.median(v['APIs'][name][field] for v in phases)
                    for field in phases[0]['APIs'][name]} for name in watched},
     limit='Clipped CUDA API intervals overlap GPU work and each other; waits are largely actual GPU retirement. No untraced C++ attribution or recoverable wall estimate.')
(S/'api-intersections.json').write_text(json.dumps(intersections, indent=2)+'\n', encoding='utf-8')
