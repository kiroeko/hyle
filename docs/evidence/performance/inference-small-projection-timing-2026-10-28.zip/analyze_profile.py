"""Offline only: six measured NVTX roots, actual native correlation ownership.

Warmup/cold activity is excluded. Do not assign kernels from wall overlap.
"""
from pathlib import Path
from collections import Counter, defaultdict
import json
import re
import sqlite3
import sys
sys.dont_write_bytecode = True


def union_ns(intervals):
    out = []
    for a, b in sorted(intervals):
        if b <= a: continue
        if out and a <= out[-1][1]: out[-1][1] = max(out[-1][1], b)
        else: out.append([a, b])
    return sum(b-a for a, b in out)


def parse(path):
    path = Path(path).resolve()
    con = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {'NVTX_EVENTS', 'StringIds', 'CUPTI_ACTIVITY_KIND_KERNEL'} <= tables
    strings = {r['id']: r['value'] for r in con.execute('SELECT id,value FROM StringIds')}
    native_stdout = ''
    if 'ProcessStreams' in tables:
        parts = [r['body'] for r in con.execute('SELECT f.value filename,c.value body FROM ProcessStreams p JOIN StringIds f ON f.id=p.filenameId JOIN StringIds c ON c.id=p.contentId') if 'stdout_' in r['filename']]
        native_stdout = ''.join(parts)
    roots = [dict(r) for r in con.execute('SELECT n.*,COALESCE(n.text,s.value) label FROM NVTX_EVENTS n LEFT JOIN StringIds s ON s.id=n.textId ORDER BY n.start') if r['label'] and r['label'].startswith('small_projection rows=')]
    assert len(roots) == 6 and all(r['end'] is not None for r in roots)
    actual = {(int(re.search(r'rows=(\d+)', r['label'])[1]), int(re.search(r'packed=(\d+)', r['label'])[1])) for r in roots}
    assert actual == {(m, a) for m in (1, 2, 154) for a in (0, 1)}
    api = []
    for kind in ('RUNTIME', 'DRIVER'):
        table = 'CUPTI_ACTIVITY_KIND_' + kind
        if table in tables:
            api.extend(dict(r, table=kind, api=strings[r['nameId']]) for r in con.execute('SELECT * FROM ' + table))
    gpu = []
    for kind in ('KERNEL', 'MEMCPY', 'MEMSET'):
        table = 'CUPTI_ACTIVITY_KIND_' + kind
        if table in tables:
            gpu.extend(dict(r, kind=kind) for r in con.execute('SELECT * FROM ' + table))
    process = roots[0]['globalTid'] & ~((1 << 24)-1)
    assert all(r['globalTid'] & ~((1 << 24)-1) == process for r in roots)
    gpu = [r for r in gpu if r['globalPid'] == process]
    owners, records = {}, []
    for index, root in enumerate(roots):
        calls = [r for r in api if root['start'] <= r['start'] and r['end'] <= root['end'] and r['globalTid'] == root['globalTid']]
        for row in calls:
            cid = row['correlationId']
            if cid:
                assert cid not in owners or owners[cid] == index, ('Ambiguous native correlation', cid)
                owners[cid] = index
        launches = [r for r in calls if 'GraphLaunch' in r['api']]
        assert launches, ('No actual native GraphLaunch in measured root', root['label'])
        recording = dict(Counter(r['api'] for r in calls if any(x in r['api'] for x in ('BeginCapture', 'EndCapture', 'GraphInstantiate', 'GraphExecUpdate'))))
        assert not recording, ('Unexpected recording during measured replay', recording)
        records.append(dict(label=root['label'], rows=int(re.search(r'rows=(\d+)', root['label'])[1]),
            packed=int(re.search(r'packed=(\d+)', root['label'])[1]),
            start_ns=root['start'], end_ns=root['end'], root_wall_ns=root['end']-root['start'],
            native_graph_launch_APIs=[dict(api=r['api'], table=r['table'], correlationId=r['correlationId']) for r in launches],
            recording_APIs=recording))
    unassigned = [r for r in gpu if r['correlationId'] not in owners and any(q['start'] <= r['start'] and r['end'] <= q['end'] for q in roots)]
    assert not unassigned, ('Native activity inside measured roots lacks actual API identity; offline parser repair only', unassigned[:4])
    for index, record in enumerate(records):
        ys = sorted((r for r in gpu if owners.get(r['correlationId']) == index), key=lambda r:r['start'])
        kernels = [r for r in ys if r['kind'] == 'KERNEL']; copies = [r for r in ys if r['kind'] == 'MEMCPY']
        assert kernels, record['label']
        names, ordered = defaultdict(lambda:dict(count=0, sum_ns=0)), []
        for r in kernels:
            name = strings.get(r.get('demangledName'), strings.get(r.get('shortName'), str(r.get('name', 'unknown'))))
            names[name]['count'] += 1; names[name]['sum_ns'] += r['end']-r['start']
            ordered.append(dict(name=name, duration_ns=r['end']-r['start'], correlationId=r['correlationId'],
                                graphId=r.get('graphId'), graphNodeId=r.get('graphNodeId'), streamId=r.get('streamId')))
        record.update(gpu_union_ns=union_ns((r['start'], r['end']) for r in ys),
            kernel_count=len(kernels), kernel_union_ns=union_ns((r['start'], r['end']) for r in kernels),
            kernels_by_native_name=dict(names), ordered_kernels=ordered,
            memcpy={str(k):dict(count=sum(r['copyKind']==k for r in copies),
                               bytes=sum(r['bytes'] for r in copies if r['copyKind']==k),
                               sum_ns=sum(r['end']-r['start'] for r in copies if r['copyKind']==k)) for k in sorted({r['copyKind'] for r in copies})},
            memset_count=sum(r['kind']=='MEMSET' for r in ys))
    con.close()
    return dict(status='SIX_ACTUAL_NATIVE_ROOTS_MAPPED', roots=records, root_count=6,
                unmapped_in_measured_roots=0,
                limits=['Profiled structural kernel/copy durations are not the unprofiled event samples.',
                        'GPU events bracket Queue payload/status work; root wall also includes host gate/thread/Completion observation.',
                        'Kernel names are raw native evidence; copy-like names alone do not identify a mathematical node or private materialization.',
                        'Warmup/cold activity excluded; no Model bandwidth/TPS or significance claim.']), native_stdout


if __name__ == '__main__':
    result, _ = parse(sys.argv[1])
    print(json.dumps(result, indent=2))
