"""Metadata-only recovery for successful CXX PID17280. Never invokes a tool.

Keep the original plan, helper, compiler process, failure and object unchanged.
All owned source/header and pre-existing dependency pins remain strict. Newly
observed SDK identities are explicitly post-compile observations, not pre-pins.
"""
from pathlib import Path
from collections import Counter
import datetime
import importlib.util
import json
import time

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_timing_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def main():
    plan = b.validate()  # Includes unchanged original harness/plan source pins.
    output = W / 'compile/candidate'
    assert not (output / 'compiled.json').exists() and not (output / 'actual-dependencies.json').exists(), 'No metadata overwrite'
    process = b.read(W / 'logs/compile/process.json')
    assert process['pid'] == 17280 and process['exit'] == 0 and not process['timed_out']
    assert process['state'] == 'TERMINAL'
    command = b.read(W / 'logs/compile/command.json')
    recipe = b.read(plan['compile']['path'])
    assert command['command'] == recipe['command'] and command['cwd'] == recipe['cwd']
    failures = sorted(W.glob('failure-compile-*.log'))
    assert len(failures) == 1 and 'Missing prepin after successful compiler' in failures[0].read_text()
    dependency_file = output / 'dependencies.json'
    data = b.read(dependency_file)['Data']
    assert b.key(data['Source']) == b.key(plan['source']['path'])
    known = {b.key(row['path']): row for row in b.read(plan['dependencies']['path'])}
    roots = {
        'WindowsSDK': Path('C:/Program Files (x86)/Windows Kits/10/Include/10.0.26100.0').resolve(),
        'MSVC': Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include').resolve(),
        'NVTX': Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include/nvtx3').resolve(),
    }
    actual, additional, checked = [], [], []
    # Inspect all includes in one pass; no first-unknown iterative amendments.
    for name in dict.fromkeys([data['Source'], *data['Includes']]):
        identity = b.pin(name)
        lookup = known.get(b.key(name))
        if lookup:
            assert (identity['bytes'], identity['sha256']) == (lookup['bytes'], lookup['sha256']), ('Frozen dependency changed', name)
            checked.append(identity)
        else:
            path = Path(name).resolve()
            assert not path.is_relative_to(b.R), ('Unpinned owned source/header cannot be repaired as SDK metadata', name)
            category = next((label for label, root in roots.items() if path.is_relative_to(root)), None)
            assert category, ('Unexpected non-SDK dependency; stop without recompiling', name)
            additional.append(dict(identity=identity, category=category,
                identity_stage='observed_after_successful_CXX; not hashed before compile',
                file_mtime_ns=path.stat().st_mtime_ns))
        actual.append(identity)
    assert len(actual) == 456 and len(additional) == 140
    assert Counter(row['category'] for row in additional) == {'WindowsSDK': 138, 'MSVC': 2}
    nvtx = [row for row in actual if '/nvtx3/' in row['path'].replace('\\', '/').lower()]
    assert len(nvtx) == 8 and all(b.key(row['path']) in known for row in nvtx)
    # Existing source and the helper copied into the compiler's include root
    # must agree with their original owned drafts/frozen recipe as well.
    b.exact(plan['source']); b.exact(plan['helper'])
    assert (W / 'timing_support.h').read_bytes() == Path(plan['helper']['path']).read_bytes()
    object_identity = b.pin(output / 'unit.obj')
    recorded_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    b.save(output / 'postcompile-sdk-dependencies.json', dict(recorded_at_UTC=recorded_at,
        reason='NVTX Windows implementation adds windows.h transitive SDK includes; original precompile manifest omitted them.',
        precompile_claim=False, compiler_process=process, entries=additional,
        known_NVTX_headers_checked=nvtx, SDK_files_copied=0, new_compiler_invocations=0))
    b.save(output / 'actual-dependencies.json', actual)
    b.save(output / 'compiled.json', dict(source=plan['source'], object=object_identity,
        process=process, command=b.pin(W / 'logs/compile/command.json'),
        dependencies=b.pin(dependency_file), actual_dependencies=b.pin(output / 'actual-dependencies.json'),
        metadata_amendment=dict(stage='postcompile', original_CXX_succeeded=True, new_CXX=0,
            SDK_additions=b.pin(output / 'postcompile-sdk-dependencies.json'),
            original_failure=b.pin(failures[0]))))
    receipt = dict(status='SUCCESSFUL_ORIGINAL_CXX_METADATA_RECOVERED', recorded_at_UTC=recorded_at,
        original_plan=b.pin(W / 'plan.json'), unchanged_original_harness=b.pin(W / 'build.py'),
        repair_script=b.pin(__file__), original_compiler_process=process,
        original_failure=b.pin(failures[0]), source=plan['source'], helper=plan['helper'], object=object_identity,
        actual_dependency_count=len(actual), original_pre_pins_matched=len(checked),
        postcompile_SDK_counts=dict(Counter(row['category'] for row in additional)),
        NVTX_pre_pins_matched=len(nvtx), all_owned_sources_and_headers_pre_pinned_and_unchanged=True,
        compiler_or_linker_or_GPU_invocations_by_repair=0, compiled=b.pin(output / 'compiled.json'),
        next_action='Parent runs unchanged build.py link; it uses the same successful original OBJ, never compile again.')
    b.save(W / 'postcompile-metadata-amendment.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException:
        import traceback
        (W / ('failure-parse-compile-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
