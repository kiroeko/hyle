"""Package existing finite timing/profile evidence only; parent executes quiet.

No compiler, linker or GPU invocation. No inherited SDK/model/OBJ/image copies
or binary hashing. Read back every small archive member once after writing.
"""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
B = W.parent
R = B.parents[1]
DEST = R / 'docs/evidence/performance'
NAME = 'inference-small-projection-timing-2026-10-28'
TEXT = {'.py', '.json', '.cc', '.h', '.log', '.xml'}
TRACE = {'.sqlite', '.nsys-rep'}
FORBIDDEN = {'.obj', '.exe', '.pdb', '.lib', '.exp', '.dll', '.bf16', '.gguf', '.safetensors', '.bin'}


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p = Path(p).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def exact_small(row):
    p = Path(row['path']); assert p.suffix.lower() not in FORBIDDEN, p
    actual = pin(p)
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), p
    return actual
def key(p): return str(p).replace('/', '\\').casefold()
def same(a, b): return key(a['path']) == key(b['path']) and (a['bytes'],a['sha256']) == (b['bytes'],b['sha256'])
def save_new(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')


def main():
    out_json, out_zip = DEST / (NAME + '.json'), DEST / (NAME + '.zip')
    assert not out_json.exists() and not out_zip.exists(), 'Never overwrite an evidence attempt'
    plan, ready = read(W / 'plan.json'), read(W / 'ready.json')
    analysis = read(W / 'offline-analysis.json')
    timing_path = next((W / 'run-timing').glob('summary-*.json'))
    profile_path = next((W / 'run-profile').glob('summary-*.json'))
    timing, profile = read(timing_path), read(profile_path)
    amendment = read(W / 'postcompile-metadata-amendment.json')
    assert analysis['status'] == 'OFFLINE_FINITE_COMPONENT_ATTRIBUTION_COMPLETE'
    assert timing['image'] == profile['image'] == analysis['image'] == ready['image']
    assert ready['image']['sha256'] == 'd1326570c5abf5c60d8dcef07081d3f90c1f2744c0e055440a3ce021d931b296'
    for row in (ready['plan'], ready['command'], ready['inputs'], ready['compiled']['source'],
                ready['compiled']['command'], ready['compiled']['dependencies'], ready['compiled']['actual_dependencies'],
                plan['source'], plan['helper'], plan['harness'], plan['parser'], plan['dependencies'], plan['baseline_inputs'],
                amendment['compiled'], amendment['original_plan'], amendment['unchanged_original_harness'], amendment['original_failure']):
        exact_small(row)
    # Only W-owned source files are rehashed. SDK identities remain the original
    # precise pre-/post-compile observations, not a fabricated prior freeze.
    actual = read(ready['compiled']['actual_dependencies']['path'])
    for row in actual:
        if Path(row['path']).is_relative_to(W): exact_small(row)
    assert amendment['actual_dependency_count'] == len(actual) == 456
    assert amendment['original_pre_pins_matched'] == 316 and amendment['postcompile_SDK_counts'] == {'WindowsSDK':138,'MSVC':2}
    assert amendment['NVTX_pre_pins_matched'] == 8 and amendment['compiler_or_linker_or_GPU_invocations_by_repair'] == 0
    old_inputs, inputs = read(plan['baseline_inputs']['path']), read(ready['inputs']['path'])
    assert len(old_inputs) == len(inputs) == 229
    deltas = [(a,b) for a,b in zip(old_inputs,inputs) if not same(a,b)]
    assert len(deltas) == 1 and same(deltas[0][0], plan['replaced_object']) and same(deltas[0][1], ready['compiled']['object'])
    assert ready['compiled']['process']['pid'] == 17280 and ready['compiled']['process']['exit'] == 0
    assert ready['process']['pid'] == 38096 and ready['process']['exit'] == 0
    for item, folder, pid in [(timing,'run-timing',49684),(profile,'run-profile',5824)]:
        assert item['process']['pid'] == pid and item['process']['exit'] == 0 and not item['process']['timed_out']
        xml = ET.parse(W / folder / 'results.xml').getroot()
        assert int(xml.attrib['tests']) == 3 and int(xml.attrib['failures']) == 0 and not xml.findall('.//skipped')
        assert all(x['raw_bf16_differences'] == 0 for x in item['comparisons'])
    assert profile['native_structure']['root_count'] == 6 and profile['native_structure']['unmapped_in_measured_roots'] == 0
    assert all(not x['recording_APIs'] for x in profile['native_structure']['roots'])
    candidate_json = DEST / 'inference-small-projection-candidate-2026-10-28.json'
    candidate = read(candidate_json)
    prior_archive = candidate['archive']
    assert prior_archive['sha256'] == pin(prior_archive['path'])['sha256']
    brief = dict(status='MEASURED_FINITE_LEAF_CANDIDATE_NO_DEFAULT_PRODUCT_CHANGE', date='2026-10-28',
        scope='Original/cold-packed a+b projections with original Cast/Sigmoid suffix; deterministic BF16 X and cached layer0 weights, retained L2-sized data. No Model/TPS/bandwidth claim.',
        source=plan['source'], helper=plan['helper'], image=ready['image'], ready=pin(W / 'ready.json'),
        original_candidate=dict(json=pin(candidate_json), archive=prior_archive, reference_only_not_pooled=True),
        retained_closure=dict(original=plan['baseline_inputs'], actual=ready['inputs'], objects=229,
            delta='Replace exactly candidate3 test OBJ; retain228 frozen product inputs/headers. Unrelated current885ed changes not used.'),
        actual_counts=dict(host_CXX=1, compiler_exit=0, links=1, GPU_processes=2,
            GTests_per_process=3, successful_Graph_submissions_from_completed_loops=246,
            profile_actual_native_GraphLaunches=24, measured_profile_roots=6,
            compiler_reruns=0, GPU_reruns=0, SDK_builds=0, NVCC=0, downloads=0),
        metadata_failure=dict(kind='Original CXX exit0; helper then rejected missing WindowsSDK prepin. No CXX rerun.',
            receipt=pin(W / 'postcompile-metadata-amendment.json'), actual_dependencies=456,
            prior_pins_matched=316, postcompile_only_SDK_pins=140, original_NVTX_pins_matched=8,
            precompile_claim_for_new_SDK=False),
        numerical=analysis['numerical_status'],
        timing_rows=[dict(rows=r['rows'], original_us=r['event_us_original'], candidate_us=r['event_us_candidate'],
            candidate_median_change_percent=r['candidate_median_change_percent'], discarded_samples=0,
            native_kernels_original_candidate=r['profile_kernel_count_original_candidate'],
            profile_GPU_union_us_original_candidate=r['profile_GPU_union_us_original_candidate'],
            native_memcpy_original_candidate=r['profile_memcpy_original_candidate']) for r in analysis['rows']],
        measured_routes=['M1 original uses ggml paired mul_mat_vec_f; candidate uses cublasLt GEMV, both3 kernels.',
            'M2 original has2 WMMA GEMMs; candidate1 WMMA GEMM plus64B captured D2D,4→3 kernels.',
            'T154 original has2 GEMMs+2 splitK reductions; candidate1+1 plus4928B captured D2D,6→4 kernels.',
            'Cast ggml BF16→F32 remains; candidate Sigmoid changes from ggml unary to Hyle strided tensor kernel.'],
        private_copy_proof='Both captured copy graphNodeIds map through originalGraphNodeId to original cudaMemcpy2DAsync calls. Exact64/4928B equals rows*16*BF16; consistent with selected Cast matrix_form/ggml_cont for strided a. Trace has no source/destination addresses.',
        helper_semantics=analysis['helper_semantics'], decision=analysis['decision'],
        limits=analysis['scope'], detailed_analysis=pin(W / 'offline-analysis.json'))
    files = {}
    def add(p, name=None):
        p = Path(p); suffix=p.suffix.lower()
        assert p.is_file() and suffix not in FORBIDDEN and suffix in (TEXT | TRACE), p
        if suffix in TRACE: assert p.parent == W / 'run-profile', p
        name = name or str(p.relative_to(W)).replace('\\','/')
        assert '..' not in Path(name).parts and name not in files, name
        files[name] = p
    for p in W.iterdir():
        if p.is_file() and p.suffix.lower() in TEXT and p.name != 'package-receipt.json': add(p)
    for name in ('source','prepared1','preparation1-source','compile','logs','link','run-timing','run-profile'):
        directory=W/name
        if directory.exists():
            for p in sorted(directory.rglob('*')):
                if p.is_file() and (p.suffix.lower() in TEXT or (p.parent == W/'run-profile' and p.suffix.lower() in TRACE)): add(p)
    add(candidate_json,'reference/prior-candidate.json')
    add(B/'fixture-manifest.json','reference/original-fixture-manifest.json')
    add(B/'ready3.json','reference/original-candidate-ready.json')
    manifest=[]; DEST.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out_zip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in sorted(files.items()):
            data=p.read_bytes();z.writestr(name,data)
            manifest.append(dict(member=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        data=(json.dumps(brief,indent=2)+'\n').encode();z.writestr('package-result.json',data)
        manifest.append(dict(member='package-result.json',bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        z.writestr('archive-members.json',(json.dumps(manifest,indent=2)+'\n').encode())
    with zipfile.ZipFile(out_zip) as z:
        assert len(z.namelist()) == len(manifest)+1
        for row in manifest:
            data=z.read(row['member'])
            assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['member']
        assert z.testzip() is None
    brief['archive']={**pin(out_zip),'members':len(manifest)+1,'readback':'All member bytes/SHA256 and ZIP CRC verified.'}
    save_new(out_json,brief)
    receipt=dict(status='PACKAGED_READBACK_VERIFIED',json=pin(out_json),zip=pin(out_zip),members=len(manifest)+1,
        new_compiler_linker_or_GPU_processes=0)
    save_new(W/'package-receipt.json',receipt)
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__': main()
