#pragma once
namespace small_projection_fixture {
inline constexpr char kAPath[] = R"(C:\public\project-hyle\hyle\.scratch\inference-small-projection-20261028\payload\a.bf16)";
inline constexpr char kBPath[] = R"(C:\public\project-hyle\hyle\.scratch\inference-small-projection-20261028\payload\b.bf16)";
}
