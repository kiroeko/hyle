"""Explicit one-TU followup. prepare is metadata-only; parent schedules actions.

No automatic retries. A parser failure is repaired offline, never by rerunning a
completed GPU process. Frozen candidate3 headers/229-input closure are retained.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
B = W.parent
R = B.parents[1]
FILTER = 'SmallProjectionCuda.*'


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, value):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')
def pin(p):
    p = Path(p).resolve(); h = hashlib.sha256()
    with p.open('rb') as f:
        while part := f.read(1 << 20): h.update(part)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())
def key(p): return str(p).replace('/', '\\').casefold()
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def prepare():
    prior = read(B / 'ready3.json')
    assert prior['image']['sha256'] == '81780cf13c33ce5419e150e905cd488f163869720e945459e302f248fa6594a0'
    exact(prior['compiled']['source']); exact(prior['inputs']); exact(prior['compiled']['command'])
    source = Path(prior['compiled']['source']['path']).read_text(encoding='utf-8-sig')
    assert hashlib.sha256(Path(prior['compiled']['source']['path']).read_bytes()).hexdigest() == '98548156fc371d583bc949858f08d957202e29d854f36cdd3f5b096926753147'
    def replace_once(old, new):
        nonlocal source
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    replace_once('#include <gtest/gtest.h>', '#include <gtest/gtest.h>\n#include "timing_support.h"')
    replace_once('  auto queue = take(context.create_queue(), "original queue");',
                 '  auto queue = take(context.create_queue(), "original queue");\n'
                 '  check(queue.reserve_completions(16), "cold marker and Graph completion capacity");')
    anchor = '  EXPECT_EQ(second.recorded_capture_range_count, 0U); EXPECT_GE(second.reused_capture_range_count, 1U);'
    replace_once(anchor, anchor + '\n'
      '  EXPECT_EQ(invocation.replay_route(), g::ReplayRoute::kCaptured);\n'
      '  small_projection_timing::measure(invocation, queue, rows, math.packed);\n'
      '  // Every timing iteration used the real Invocation/full-writer lifecycle.\n'
      '  // Recheck actual final payloads, with all GraphOutput handles scoped.\n'
      '  for (std::size_t part = 0; part < 2; ++part) {\n'
      '    auto observed = take(invocation.result(math.projection[part]), "post-timing BF16 result");\n'
      '    EXPECT_EQ(read_values<std::uint16_t>(take(observed.tensor(), "post-timing BF16 tensor")), result.raw[part]);\n'
      '  }\n'
      '  { auto observed = take(invocation.result(math.suffix[0]), "post-timing a result");\n'
      '    EXPECT_EQ(read_values<float>(take(observed.tensor(), "post-timing a tensor")), result.a); }\n'
      '  { auto observed = take(invocation.result(math.suffix[1]), "post-timing b result");\n'
      '    EXPECT_EQ(read_values<std::uint16_t>(take(observed.tensor(), "post-timing b tensor")), result.beta); }')
    src = W / 'source'; src.mkdir(exist_ok=False)
    (src / 'small_projection_test.cc').write_bytes(source.encode())
    old_actual = read(prior['compiled']['actual_dependencies']['path'])
    fixture_header = next(row for row in old_actual if Path(row['path']).name == 'fixture_paths.h')
    exact(fixture_header)
    for name, original in [('timing_support.h', W / 'timing_support.h'),
                           ('fixture_paths.h', Path(fixture_header['path']))]:
        (src / name).write_bytes(original.read_bytes())
    recipe = read(prior['compiled']['command']['path'])['command']
    command = [recipe[0], '/I' + str(src)]
    for i, arg in enumerate(recipe[1:], 1):
        if recipe[i-1].lower() == '/sourcedependencies': arg = str(W / 'compile/candidate/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/candidate/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/candidate/unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(src / 'small_projection_test.cc')
        command.append(arg)
    save(W / 'compile-command.json', dict(command=command, cwd=str(R), timeout_seconds=240))
    image = W / 'bin/small-projection-timing.exe'
    link = []
    old_object = prior['compiled']['object']
    old_link = read(prior['command']['path'])['command']
    assert sum(key(x) == key(old_object['path']) for x in old_link) == 1
    for arg in old_link:
        if key(arg) == key(old_object['path']): arg = str(W / 'compile/candidate/unit.obj')
        for option, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(option): arg = option + str(image.with_suffix(suffix)); break
        link.append(arg)
    save(W / 'link-command.json', dict(command=link, cwd=str(R), timeout_seconds=240))
    # Retained actual dependency pins plus the new, bounded SDK header closure.
    # Project headers still resolve from candidate3's immutable overlay only.
    known = {key(r['path']): r for r in read(prior['compiled']['actual_dependencies']['path'])}
    for p in src.iterdir(): known[key(p)] = pin(p)
    nvtx_rows = [r for r in read(R / '.scratch/inference-current-review-profile-20261027/precompile-identity.json') if 'nvtx3' in r['path'].lower()]
    assert len(nvtx_rows) == 8
    for row in nvtx_rows: exact(row); known[key(row['path'])] = row
    env = read(B / 'environment.json')
    roots = [Path(p) for p in env['INCLUDE'].split(';') if p]
    roots += [Path(x[len('/external:I'):]) for x in command if x.lower().startswith('/external:i')]
    roots += [Path(x[len('/I'):]) for x in command if x.lower().startswith('/i') and not x.lower().startswith('/interface')]
    todo = []
    for name in ('atomic', 'chrono', 'condition_variable', 'mutex', 'thread', 'utility', 'cstdio', 'cstdlib'):
        found = next((p / name for p in roots if (p / name).is_file()), None)
        assert found, name
        if key(found) not in known: todo.append(found)
    while todo:
        p = todo.pop()
        if key(p) in known: continue
        known[key(p)] = pin(p)
        for name in re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]', p.read_text(encoding='utf-8-sig', errors='replace'), re.M):
            found = next((root / name for root in [p.parent, *roots] if (root / name).is_file()), None)
            if found and key(found) not in known: todo.append(found)
    save(W / 'precompile-dependencies.json', list(known.values()))
    save(W / 'environment.json', env)
    fixture = read(B / 'fixture-manifest.json')
    for role in fixture['roles']: exact(role['snapshot'])
    save(W / 'fixture-reference.json', fixture)
    profiler = read(R / '.scratch/inference-current-review-profile-20261027/plan.json')['profiler']
    assert Path(profiler['path']).is_file()
    run_args = [str(image), '--gtest_filter=' + FILTER, '--gtest_fail_fast']
    profile = [profiler['path'], 'profile', '--trace=cuda,cublas,nvtx', '--cuda-graph-trace=node',
               '--sample=none', '--cpuctxsw=none', '--discard-environment=true',
               '--nvtx-domain-include=HyleSmallProjection', '--duration=90', '--kill=true',
               '--wait=all', '--stats=false', '--export=sqlite',
               '--output=' + str(W / 'run-profile/trace'), *run_args,
               '--gtest_output=xml:' + str(W / 'run-profile/results.xml')]
    save(W / 'plan.json', dict(status='PREPARED_NOT_BUILT_NOT_RUN', source=pin(src / 'small_projection_test.cc'),
        helper=pin(src / 'timing_support.h'), baseline_ready=pin(B / 'ready3.json'), baseline_image=prior['image'],
        baseline_inputs=prior['inputs'], replaced_object=old_object, input_count=229,
        compile=pin(W / 'compile-command.json'), link=pin(W / 'link-command.json'),
        harness=pin(W / 'build.py'), parser=pin(W / 'analyze_profile.py'),
        dependencies=pin(W / 'precompile-dependencies.json'), fixture=pin(W / 'fixture-reference.json'),
        source_git_context='Parent current885ed730a; this component intentionally retains the prior candidate3 frozen 228 production objects and old headers. It is not a verification of unrelated885ed product changes.',
        budget=dict(host_CXX=1, component_link=1, SDK=0, NVCC=0, downloads=0, scheduled_GPU_processes=2),
        timing=dict(warmups_per_arm=5, samples_per_arm=31, arms=6, Graph_submissions=222,
                    device_clock='cudaEventElapsedTime on actual admitted Queue markers',
                    includes='Captured payload plus original Queue/status commands between markers; not pure kernel or host CPU time.',
                    host_gate='Original host callback gate; 10-second watchdog; fail if it fires; every failure releases before draining original Completions.',
                    weights='Only128KiB original weights plus128KiB packed bank; fits GPU L2. Hot retained component data, not full Model streaming bandwidth/TPS.',
                    order='Original then candidate within each M1/M2/T154; retained-cache finite characterization, no significance or general speed claim.'),
        structural=dict(warmups_per_arm=2, measured_per_arm=1, measured_NVTX_ranges=6, Graph_submissions=24,
                        profile_is_separate_from_unprofiled_event_samples=True,
                        native_attribution='Actual API correlation per measured NVTX range, not root wall overlap; kernel names/copy bytes retained, no name-only assertion of mathematical node.'),
        commands={'timing': run_args + ['--gtest_output=xml:' + str(W / 'run-timing/results.xml')], 'profile': profile},
        profiler=profiler, termination='Each output directory exclusive. First actual failure stops; no automatic retry or successful rerun. Parser-only repair never runs GPU.',
        lifecycle_review=['candidate3 factory.resources/true constants/full writers unchanged',
            'All GraphOutput scopes finish before reprepare/timing; final payload reread after timing',
            'resources.cc begin_submission upgrades exclusive ready lease via original try_write; no external result ref remains',
            'Complete Captured path uses original captured range enqueue; queue completion capacity reserved cold before gate',
            'No raw cudaGraphLaunch/lease bypass in test; cuda::submit used only for host gate/event metadata']))
    print('PREPARED_ONLY one host TU, one229-input replacement link, two parent-scheduled GPU actions')


def validate():
    p = read(W / 'plan.json')
    for field in ('source', 'helper', 'baseline_ready', 'baseline_inputs', 'compile', 'link', 'dependencies', 'fixture', 'harness', 'parser'): exact(p[field])
    return p


def execute(command, folder, timeout, env_extra=None):
    folder.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy(); env.update(read(W / 'environment.json')); env.update(env_extra or {})
    save(folder / 'command.json', dict(command=command, cwd=str(R), timeout_seconds=timeout, environment_overrides=env_extra or {}))
    start = time.time()
    with (folder / 'stdout.log').open('xb') as out, (folder / 'stderr.log').open('xb') as err:
        proc = subprocess.Popen(command, cwd=R, env=env, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder / 'live.json', dict(pid=proc.pid, started=start))
        timed_out = False
        try: code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            killed = subprocess.run(['C:/Windows/System32/taskkill.exe', '/PID', str(proc.pid), '/T', '/F'], capture_output=True)
            (folder / 'timeout-kill.stdout.log').write_bytes(killed.stdout)
            (folder / 'timeout-kill.stderr.log').write_bytes(killed.stderr)
            proc.wait(timeout=30); code = proc.returncode
    process = dict(pid=proc.pid, exit=code, timed_out=timed_out, started=start, seconds=time.time()-start, state='TERMINAL')
    save(folder / 'process.json', process)
    assert code == 0 and not timed_out, process
    return process


def compile_one():
    p = validate()
    expected = {key(x['path']): x for x in read(p['dependencies']['path'])}
    for row in expected.values(): exact(row)
    (W / 'compile/candidate').mkdir(parents=True, exist_ok=False)
    command = read(p['compile']['path'])
    process = execute(command['command'], W / 'logs/compile', command['timeout_seconds'])
    dep = read(W / 'compile/candidate/dependencies.json')['Data']; actual = []
    for name in dict.fromkeys([dep['Source'], *dep['Includes']]):
        row = pin(name)
        assert key(name) in expected, ('Missing prepin after successful compiler; metadata error, do not recompile', name)
        assert row == expected[key(name)], ('actual dependency drift', name)
        actual.append(row)
    save(W / 'compile/candidate/actual-dependencies.json', actual)
    save(W / 'compile/candidate/compiled.json', dict(source=p['source'], object=pin(W / 'compile/candidate/unit.obj'),
        process=process, command=pin(W / 'logs/compile/command.json'),
        dependencies=pin(W / 'compile/candidate/dependencies.json'), actual_dependencies=pin(W / 'compile/candidate/actual-dependencies.json')))


def link_one():
    p = validate(); compiled = read(W / 'compile/candidate/compiled.json'); exact(compiled['object'])
    rows = read(p['baseline_inputs']['path'])
    assert len(rows) == 229 and sum(key(x['path']) == key(p['replaced_object']['path']) for x in rows) == 1
    rows = [compiled['object'] if key(x['path']) == key(p['replaced_object']['path']) else x for x in rows]
    assert len({key(x['path']) for x in rows}) == 229
    for row in rows: exact(row)
    save(W / 'link-inputs.json', rows)
    (W / 'bin').mkdir(exist_ok=True)
    image = W / 'bin/small-projection-timing.exe'; assert not image.exists()
    command = read(p['link']['path']); process = execute(command['command'], W / 'link', command['timeout_seconds'])
    save(W / 'ready.json', dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled, process=process,
        inputs=pin(W / 'link-inputs.json'), command=pin(W / 'link/command.json'), plan=pin(W / 'plan.json')))


def parse(kind):
    assert kind in ('timing', 'profile')
    folder = W / ('run-' + kind); process = read(folder / 'process.json'); assert process['exit'] == 0 and not process['timed_out']
    root = ET.parse(folder / 'results.xml').getroot()
    assert int(root.attrib['tests']) == 3 and int(root.attrib['failures']) == 0 and not root.findall('.//skipped')
    stdout = (folder / 'stdout.log').read_text(encoding='utf-8-sig')
    structural = None
    if kind == 'profile':
        import importlib.util
        spec = importlib.util.spec_from_file_location('small_projection_native_analysis', W / 'analyze_profile.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        structural, native_stdout = module.parse(folder / 'trace.sqlite')
        if 'SMALL_PROJECTION_TIMING ' not in stdout: stdout = native_stdout
    rows = [json.loads(x) for x in re.findall(r'^SMALL_PROJECTION_TIMING (\{.*\})$', stdout, re.M)]
    facts = [json.loads(x) for x in re.findall(r'^SMALL_PROJECTION (\{.*\})$', stdout, re.M)]
    comparisons = [json.loads(x) for x in re.findall(r'^SMALL_PROJECTION_COMPARE (\{.*\})$', stdout, re.M)]
    assert len(rows) == len(facts) == 6 and len(comparisons) == 3
    expected_samples = 31 if kind == 'timing' else 1
    assert {(x['rows'], x['packed']) for x in rows} == {(m, a) for m in (1, 2, 154) for a in (0, 1)}
    import statistics
    for row in rows:
        assert row['profiled'] == (kind == 'profile') and row['samples'] == expected_samples
        assert len(row['queue_device_us']) == expected_samples and min(row['queue_device_us']) > 0
        assert not row['host_gate_watchdog_fired'] and not row['raw_graph_launch_bypass']
        row['device_us_median'] = statistics.median(row['queue_device_us'])
        row['device_us_range'] = [min(row['queue_device_us']), max(row['queue_device_us'])]
    assert all(x['raw_bf16_differences'] == 0 for x in comparisons)
    save(folder / ('summary-' + str(time.time_ns()) + '.json'), dict(status='FINITE_EVENT_AND_NUMERIC_PASS', kind=kind,
        process=process, image=read(W / 'ready.json')['image'], rows=rows, facts=facts, comparisons=comparisons,
        native_structure=structural, not_host_CPU_or_pure_kernel_time=True, no_Model_performance_claim=True))


def run(kind):
    p = validate(); ready = read(W / 'ready.json'); exact(ready['image'])
    assert kind in ('timing', 'profile')
    if kind == 'profile':
        # The first unprofiled process must already be complete and valid.
        assert list((W / 'run-timing').glob('summary-*.json'))
        assert Path(p['profiler']['path']).stat().st_size == p['profiler']['bytes']
    execute(p['commands'][kind], W / ('run-' + kind), 180,
            {'HYLE_SMALL_PROJECTION_PROFILE': '1' if kind == 'profile' else '0'})
    parse(kind)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'compile': compile_one()
        elif action == 'link': link_one()
        elif action.startswith('run-'): run(action.removeprefix('run-'))
        elif action.startswith('parse-'): parse(action.removeprefix('parse-'))
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W / ('failure-' + sys.argv[1] + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
