"""Offline followup attribution only; never launches a compiler or GPU process."""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import re
import sqlite3
import statistics

W = Path(__file__).resolve().parent


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, value):
    with Path(p).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2); f.write('\n')


def main():
    timing = read(next((W / 'run-timing').glob('summary-*.json')))
    profile = read(next((W / 'run-profile').glob('summary-*.json')))
    assert timing['status'] == profile['status'] == 'FINITE_EVENT_AND_NUMERIC_PASS'
    assert timing['image'] == profile['image'] == read(W / 'ready.json')['image']
    spec = importlib.util.spec_from_file_location('frozen_profile_parser', W / 'analyze_profile.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    native, _ = parser.parse(W / 'run-profile/trace.sqlite')
    assert native == profile['native_structure']
    assert timing['process']['pid'] == 49684 and profile['process']['pid'] == 5824
    for item in (timing, profile):
        assert item['process']['exit'] == 0 and not item['process']['timed_out']
        assert all(x['raw_bf16_differences'] == 0 and x['max_abs_difference'] == 0 for x in item['comparisons'])
        assert all(not x['host_gate_watchdog_fired'] and not x['raw_graph_launch_bypass'] for x in item['rows'])
        assert all(x['recorded'] == 1 and x['reused_on_reprepare'] == 1 for x in item['facts'])
    rows = []
    for m in (1, 2, 154):
        old, new = [x for x in timing['rows'] if x['rows'] == m]
        old_ns, new_ns = [x for x in native['roots'] if x['rows'] == m]
        assert old['packed'] == old_ns['packed'] == 0 and new['packed'] == new_ns['packed'] == 1
        a, b = old['queue_device_us'], new['queue_device_us']
        assert len(a) == len(b) == 31
        original, candidate = statistics.median(a), statistics.median(b)
        rows.append(dict(rows=m, event_us_original=dict(median=original, mean=statistics.mean(a), range=[min(a), max(a)]),
            event_us_candidate=dict(median=candidate, mean=statistics.mean(b), range=[min(b), max(b)]),
            candidate_median_change_percent=(candidate / original - 1) * 100,
            candidate_median_delta_us=candidate-original,
            samples_per_arm=31, warmups_per_arm=5, discarded_samples=0,
            long_samples_over_100us=[dict(index=i, microseconds=x) for i,x in enumerate(b) if x > 100],
            profile_kernel_count_original_candidate=[old_ns['kernel_count'], new_ns['kernel_count']],
            profile_kernel_union_us_original_candidate=[old_ns['kernel_union_ns']/1000, new_ns['kernel_union_ns']/1000],
            profile_GPU_union_us_original_candidate=[old_ns['gpu_union_ns']/1000, new_ns['gpu_union_ns']/1000],
            profile_memcpy_original_candidate=[old_ns['memcpy'], new_ns['memcpy']]))
    path = (W / 'run-profile/trace.sqlite').resolve()
    con = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True); con.row_factory=sqlite3.Row
    strings = {r['id']:r['value'] for r in con.execute('select id,value from StringIds')}
    tables = {r[0] for r in con.execute("select name from sqlite_master where type='table'")}
    enums = {r['id']:r['label'] for r in con.execute('select * from ENUM_CUDA_MEMCPY_OPER')}
    runtime = [dict(r, api=strings[r['nameId']]) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_RUNTIME')]
    copies = []
    for root in native['roots']:
        launch_ids = {r['correlationId'] for r in root['native_graph_launch_APIs']}
        matched = [dict(r) for r in con.execute('select * from CUPTI_ACTIVITY_KIND_MEMCPY') if r['correlationId'] in launch_ids]
        for cp in matched:
            lineage = []
            gid = cp['graphNodeId']; visited = set()
            while gid is not None:
                assert gid not in visited; visited.add(gid)
                nodes = [dict(r) for r in con.execute('select * from CUDA_GRAPH_NODE_EVENTS where graphNodeId=?',(gid,))]
                original = None
                for node in nodes:
                    calls = []
                    for table in ('RUNTIME','DRIVER'):
                        if 'CUPTI_ACTIVITY_KIND_' + table not in tables: continue
                        for r in con.execute('select * from CUPTI_ACTIVITY_KIND_' + table + ' where globalTid=? and start<=? and end>=?',(node['globalTid'],node['start'],node['end'])):
                            calls.append(dict(api=strings[r['nameId']], correlationId=r['correlationId'], table=table))
                    lineage.append(dict(node=node, enclosing_native_APIs=calls))
                    if node['originalGraphNodeId'] is not None: original = node['originalGraphNodeId']
                gid = original
            creation = [call for entry in lineage for call in entry['enclosing_native_APIs'] if 'Memcpy2DAsync' in call['api']]
            assert root['packed'] == 1 and root['rows'] in (2,154)
            assert cp['copyKind'] == 8 and cp['bytes'] == root['rows'] * 16 * 2 and creation
            copies.append(dict(rows=root['rows'], packed=root['packed'], copy=cp, copy_kind=enums[cp['copyKind']],
                original_capture_API=creation, graph_node_lineage=lineage,
                explanation='Source matrix_form for the selected ggml Cast inserts ggml_cont for the strided a-half; actual copy is a captured2D D2D with exactly rows*16*BF16 bytes. The b Sigmoid uses native strided tensor kernel. Trace has no source/destination address arguments; the source-level attribution is based on this exact graph/route/geometry, not kernel name alone.'))
    assert {x['rows'] for x in copies} == {2,154}
    global_API_counts = dict(Counter(r['api'] for r in runtime if any(s in r['api'] for s in ('GraphLaunch','BeginCapture','EndCapture','GraphInstantiate','GraphExecUpdate'))))
    assert sum(v for k,v in global_API_counts.items() if 'GraphLaunch' in k) == 24
    con.close()
    result = dict(status='OFFLINE_FINITE_COMPONENT_ATTRIBUTION_COMPLETE', image=timing['image'], rows=rows,
        measured_native_ranges=6, measured_native_attribution='Actual GraphLaunch correlation and GraphNode original lineage; zero unmatched GPU activity inside measured roots.',
        native_copy_lineage=copies, profile_global_API_counts=global_API_counts,
        numerical_status=dict(timing_GTests=3, profile_GTests=3, all_whole_status_and_actual_retirement_checks=True,
            raw_BF16_differences_all_shapes_both_processes=0, post_loop_same_capture_payload_checks=True,
            FP64_F32_reduction_bound=True, a_cast_exact=True, finite_b_sigmoid_abs_tolerance=0.004),
        helper_semantics=[
            'Each event interval starts only after the original host gate is released with both markers and the real Invocation submission already queued; no raw cudaGraphLaunch or permission bypass.',
            'The interval is Queue device elapsed time, including gaps/preemption and any status work; it is not host CPU time or summed kernel busy time. Root NVTX walls include host gating/thread/retirement overhead and are not a benchmark.',
            'Both profile and timing use the same numerical graph/full writer/leases; profile uses2warm+1measured while timing uses5warm+31measured. These samples are not pooled.',
            'Every gate watchdog flag is false; public Graph Completions are waited before another episode. The final payloads are reread after all repeats.',
            'Captured D2D64/4928B are real payload copies, not4B Queue status; no other measured memcpy is reported in these six roots.',
            'Unprofiled T154 candidate has one562.176us sample. It is retained and its cause is unresolved without that same native trace; do not discard it or claim a mean improvement.',
            '31 consecutive retained-cache samples per arm in original-then-candidate order within one process; no independent randomized/statistical speed claim.'
        ],
        scope=['Original a/b each64KiB, packed bank128KiB, deterministic X; weights fit L2. No full-model streaming, latency/TPS/quality/VRAM-peak claim.',
               'Frozen candidate3 component closure and headers, one test OBJ replaced; unrelated current885ed product changes are not component inputs.',
               'Original weights remain; extra packed logical payload128KiB per family/layer, family-local sharing only. Reported workspace0→128B atM2 and78848→157696B atT154 remains a cost.'],
        decision=dict(default_product_change=False, M1='Reject unconditional grouping: observed paired baseline is faster than N32 in this finite control.',
            M2='Positive finite component signal, even after actual private materialization; warrants only a separately approved actual Model candidate if pursued.',
            T154='Lower median but retained severe tail makes mean worse in this one process; no general prefill claim.',
            next_action='Close this leaf investigation as measured/conditional. Do not add an M>=2 whitelist or a new runtime knob. Any next Model experiment must preserve current M1 paired choice/rounding and assess complete finite-family route, suffix/materialization and retained storage before a performance window.'))
    save(W / 'offline-analysis.json', result)
    print(json.dumps(dict(status=result['status'], rows=rows, copy_lineage_records=len(copies), decision=result['decision']),indent=2))


if __name__ == '__main__': main()
