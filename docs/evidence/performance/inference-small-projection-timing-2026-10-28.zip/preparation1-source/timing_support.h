#pragma once
// Scratch timing only: all payload work remains original Invocation::submit.
#pragma push_macro("interface")
#pragma push_macro("min")
#pragma push_macro("max")
#include <nvtx3/nvToolsExt.h>
#pragma pop_macro("max")
#pragma pop_macro("min")
#pragma pop_macro("interface")

#include "hyle/compute/backends/cuda.h"
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace small_projection_timing {
namespace c = hyle::compute;

inline void require(hyle::Status status, const char *label) {
  if (!status.ok()) throw std::runtime_error(std::string(label) + ": " + std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result, const char *label) {
  if (!result) require(result.error(), label);
  return static_cast<T &&>(*result);
}

inline bool profile_mode() noexcept {
  // _dupenv_s avoids MSVC's deprecated getenv warning under the retained /WX.
  char *value = nullptr;
  std::size_t length = 0;
  if (_dupenv_s(&value, &length, "HYLE_SMALL_PROJECTION_PROFILE") != 0) return false;
  const bool enabled = value && length == 2 && value[0] == '1';
  std::free(value);
  return enabled;
}

class Range final {
  nvtxDomainHandle_t domain_ = nullptr;
  nvtxRangeId_t id_ = 0;
public:
  Range(bool enabled, std::int64_t rows, bool packed) noexcept {
    if (!enabled) return;
    static const auto domain = nvtxDomainCreateA("HyleSmallProjection");
    domain_ = domain;
    char label[128]{};
    std::snprintf(label, sizeof(label), "small_projection rows=%lld packed=%u sample=0",
                  static_cast<long long>(rows), unsigned(packed));
    nvtxEventAttributes_t event{};
    event.version = NVTX_VERSION; event.size = NVTX_EVENT_ATTRIB_STRUCT_SIZE;
    event.messageType = NVTX_MESSAGE_TYPE_ASCII; event.message.ascii = label;
    event.payloadType = NVTX_PAYLOAD_TYPE_UNSIGNED_INT64;
    event.payload.ullValue = static_cast<std::uint64_t>(rows * 2 + (packed ? 1 : 0));
    id_ = nvtxDomainRangeStartEx(domain_, &event);
  }
  ~Range() { if (domain_) nvtxDomainRangeEnd(domain_, id_); }
  Range(const Range &) = delete;
  Range &operator=(const Range &) = delete;
};

// Same host-gate mechanism as tests/graph/output_source_cuda_test.cc: never a
// device spin. Every exit releases before waiting/destroying retained commands.
class Gate final {
  std::atomic<bool> released_{false};
  std::mutex lock_;
  std::condition_variable changed_;
  std::thread watchdog_;
public:
  std::atomic<bool> timed_out{false};
  static void CUDART_CB wait(void *opaque) {
    auto &gate = *static_cast<Gate *>(opaque);
    gate.released_.wait(false, std::memory_order_acquire);
  }
  void arm() {
    watchdog_ = std::thread([this] {
      std::unique_lock guard(lock_);
      if (!changed_.wait_for(guard, std::chrono::seconds(10),
            [this] { return released_.load(std::memory_order_acquire); })) {
        timed_out.store(true, std::memory_order_release);
        release();
      }
    });
  }
  void release() noexcept {
    released_.store(true, std::memory_order_release);
    released_.notify_all(); changed_.notify_all();
  }
  ~Gate() { release(); if (watchdog_.joinable()) watchdog_.join(); }
  Gate(const Gate &) = delete;
  Gate &operator=(const Gate &) = delete;
  Gate() = default;
};

class Events final {
public:
  cudaEvent_t start = nullptr, end = nullptr;
  explicit Events(c::Queue &queue) {
    try {
      auto setup = take(c::cuda::submit(queue, [this](cudaStream_t) noexcept -> cudaError_t {
        const auto first = cudaEventCreate(&start);
        return first == cudaSuccess ? cudaEventCreate(&end) : first;
      }), "event creation on original Queue");
      require(setup.wait(), "event setup retirement");
    } catch (...) {
      if (end) (void)cudaEventDestroy(std::exchange(end, nullptr));
      if (start) (void)cudaEventDestroy(std::exchange(start, nullptr));
      throw;
    }
  }
  void close() {
    if (end) require(c::cuda::status(cudaEventDestroy(std::exchange(end, nullptr))), "destroy end event");
    if (start) require(c::cuda::status(cudaEventDestroy(std::exchange(start, nullptr))), "destroy start event");
  }
  ~Events() { if (end) (void)cudaEventDestroy(end); if (start) (void)cudaEventDestroy(start); }
  Events(const Events &) = delete;
  Events &operator=(const Events &) = delete;
};

template<class Invocation>
void measure(Invocation &invocation, c::Queue &queue, std::int64_t rows, bool packed) {
  const bool profiled = profile_mode();
  const int warmups = profiled ? 2 : 5, samples = profiled ? 1 : 31;
  Events events(queue); // Cold, outside every gate and measured range.
  std::vector<double> microseconds;
  microseconds.reserve(static_cast<std::size_t>(samples));
  for (int iteration = 0; iteration < warmups + samples; ++iteration) {
    Gate gate;
    std::array<c::Completion, 4> pending;
    gate.arm();
    Range range(profiled && iteration >= warmups, rows, packed);
    try {
      pending[0] = take(c::cuda::submit(queue, [&gate](cudaStream_t stream) noexcept -> cudaError_t {
        return cudaLaunchHostFunc(stream, &Gate::wait, &gate);
      }), "admitted host gate");
      pending[1] = take(c::cuda::submit(queue, [&events](cudaStream_t stream) noexcept -> cudaError_t {
        return cudaEventRecord(events.start, stream);
      }), "admitted start event");
      // Fully Captured Graph route: metadata/permissions are already prepared.
      // All native commands must enqueue before the test gate is released.
      pending[2] = take(invocation.submit(queue), "timed original Graph submit");
      pending[3] = take(c::cuda::submit(queue, [&events](cudaStream_t stream) noexcept -> cudaError_t {
        return cudaEventRecord(events.end, stream);
      }), "admitted end event");
      gate.release();
      require(pending[3].wait(), "end-marker actual retirement");
      require(pending[2].wait(), "Graph whole status and actual retirement");
      require(pending[1].wait(), "start-marker actual retirement");
      require(pending[0].wait(), "gate actual retirement");
      if (gate.timed_out.load(std::memory_order_acquire))
        throw std::runtime_error("host gate watchdog released before complete enqueue; timing invalid");
      float milliseconds = 0;
      require(c::cuda::status(cudaEventElapsedTime(&milliseconds, events.start, events.end)), "device event interval");
      if (!(milliseconds > 0)) throw std::runtime_error("nonpositive device event interval");
      if (iteration >= warmups) microseconds.push_back(double(milliseconds) * 1000.);
    } catch (...) {
      gate.release(); // Must precede every potentially waiting cleanup path.
      for (auto &done : pending) if (done.valid()) (void)done.wait();
      throw; // Preserve original failure; cleanup never converts it to success.
    }
  }
  events.close();
  std::cout << "SMALL_PROJECTION_TIMING {\"rows\":" << rows << ",\"packed\":" << packed
            << ",\"profiled\":" << profiled << ",\"warmups\":" << warmups
            << ",\"samples\":" << samples << ",\"queue_device_us\":[";
  for (std::size_t i = 0; i < microseconds.size(); ++i) {
    if (i) std::cout << ',';
    std::cout << microseconds[i];
  }
  std::cout << "],\"host_gate_watchdog_fired\":false,\"raw_graph_launch_bypass\":false}\n";
}
} // namespace small_projection_timing
