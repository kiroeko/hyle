"""Counter-only single-resources-object diagnostic. Root alone invokes --build/--run."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import shutil
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('lease_probe_existing_builder', S.parent / 'build.py')
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
b, c = parent.b, parent.c
OUT = S / 'checks/one-object'


def validate(plan):
    frozen = c.read(S / 'source-freeze.json')
    for item in [frozen['product_source'], frozen['before'], frozen['after'], frozen['diff'],
                 frozen['base_link_plan'], frozen['old_resources_recipe'],
                 frozen['old_resources_object'], frozen['unchanged_main_object'],
                 plan['unchanged_main']['source'], *frozen['current_product_dependencies']]:
        if not b.same(item):
            raise ValueError('Frozen diagnostic input changed: ' + item['path'])
    # Exact identities come from the newly accepted main1 closure. Do not hash
    # giant SDK libraries again merely to create this one-owner diagnostic.
    for item in plan['retained_inputs']:
        if not Path(item['path']).is_file():
            raise ValueError('Retained absolute link input missing: ' + item['path'])


def execute(tag, command, env, out, resume=False):
    result = out / (tag + '.result.json')
    if result.exists():
        old = c.read(result)
        if not resume:
            raise ValueError('Existing result requires explicit --resume: ' + str(result))
        if old['command'] != command:
            raise ValueError('Resume command differs; preserve a separate attempt')
        if old['exit'] == 0:
            return
        attempt = out / ('failed-' + tag + '-' + str(len(list(out.glob('failed-' + tag + '-*'))) + 1))
        attempt.mkdir()
        for suffix in ('.result.json', '.command.json', '.stdout.log', '.stderr.log'):
            path = out / (tag + suffix)
            if path.exists():
                shutil.copyfile(path, attempt / path.name)
    c.execute(tag, command, env, out)


def build(plan, resume):
    OUT.mkdir(parents=True, exist_ok=resume)
    (OUT / 'tmp').mkdir(exist_ok=True)
    validate(plan)
    link = plan['links']['qwen']
    env, runtime = b.environment(link['command'], link['inputs'], OUT)
    c.save(OUT / 'runtime-environment.json', {'runtime': runtime, 'same_accepted_main1_closure': True})
    execute('resources-compile', plan['compile'][0]['command'], env, OUT, resume)
    dep = c.read(OUT / 'resources-deps.json')['Data']
    obj = b.identity(OUT / 'resources.obj')
    c.save(OUT / 'resources-identity.json', {'command': plan['compile'][0]['command'],
        'source': plan['compile'][0]['source'], 'object': obj,
        'dependencies': [b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]})
    validate(plan)
    execute('qwen-link', link['command'], env, OUT, resume)
    lookup = {c.key(x['path']): x for x in [*plan['retained_inputs'], obj]}
    c.save(OUT / 'qwen-link-plan.json', {'command': link['command'],
        'inputs': [lookup[c.key(p)] for p in link['inputs']]})
    c.save(OUT / 'qwen-image.json', b.identity(link['image']))
    c.save(OUT / 'summary.json', {'passed': True, 'host_TUs': 1, 'native_TUs': 0,
        'SDK_rebuild': False, 'main_recompiled': False, 'main_instrumented': False,
        'only_object_replaced': plan['replacement'], 'same_main_object': plan['unchanged_main']['object'],
        'counter_only': True, 'product_changed': False, 'GPU_run': False,
        'source_freeze': b.identity(S / 'source-freeze.json'), 'driver': b.identity(Path(__file__))})
    print('LEASE_PROBE_BUILT', OUT / 'qwen-link-plan.json', flush=True)


def parse_counts(path):
    groups, overflow = [], None
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        if line.startswith('lease_lookup_probe invocation='):
            pairs = dict(re.findall(r'(\w+)=([^\s]+)', line))
            row = {'invocation': pairs.pop('invocation')}
            row.update({k: int(v) for k, v in pairs.items()})
            calls = row['calls'] - row['early']
            row['original_visits_per_non_early_call'] = row['visited'] / calls if calls else None
            row['full_R_over_B_weighted'] = row['full_R_sum'] / row['full_B_sum'] if row['full_B_sum'] else None
            groups.append(row)
        elif line.startswith('lease_lookup_probe_overflow '):
            overflow = int(dict(re.findall(r'(\w+)=(\d+)', line))['calls'])
    return groups, overflow


def run(plan, destination):
    validate(plan)
    if not c.read(OUT / 'summary.json')['passed']:
        raise ValueError('Successful diagnostic compile/link required first')
    image = c.read(OUT / 'qwen-image.json')
    if not b.same(image):
        raise ValueError('Diagnostic image changed')
    if not re.fullmatch(r'[A-Za-z0-9_-]+', destination):
        raise ValueError('A single local run-directory name is required')
    out = S / 'runs' / destination
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = c.read(plan['model_command_base'])['command'].copy()
    original = command.copy()
    command[0] = image['path']
    command[command.index('--trace') + 1] = str(out / 'trace')
    baseline = c.read(plan['model_inputs_base'])
    for name in ('manifest', 'prompt', 'decode'):
        if not b.same(baseline[name]):
            raise ValueError('Accepted model input differs: ' + name)
    if Path(baseline['model']['path']).stat().st_size != baseline['model']['bytes']:
        raise ValueError('Accepted model size differs')
    c.save(out / 'inputs.json', {'image': image, 'source_freeze': b.identity(S / 'source-freeze.json'),
        'accepted_inputs': b.identity(plan['model_inputs_base']), 'unchanged_original_command': original,
        'command': command, 'only_arguments_changed': ['executable', '--trace destination'],
        'model_payload_rehashed': False, 'model_identity_from_accepted_receipt': baseline['model'],
        'main_object': plan['unchanged_main']['object'], 'throughput_claim': False})
    link = plan['links']['qwen']
    env, runtime = b.environment(link['command'], link['inputs'], out)
    c.save(out / 'runtime-environment.json', {'runtime': runtime, 'same_accepted_link_input_paths': True})
    c.execute('qwen', command, env, out)
    groups, overflow = parse_counts(out / 'qwen.stderr.log')
    reference = Path(plan['reference_trace'])
    expected = {p.relative_to(reference): p for p in reference.rglob('*') if p.suffix in ('.bf16', '.f32')}
    actual = {p.relative_to(out / 'trace'): p for p in (out / 'trace').rglob('*') if p.suffix in ('.bf16', '.f32')}
    equal = [str(rel) for rel, path in expected.items() if rel in actual and
        hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(actual[rel].read_bytes()).digest()]
    complete = len(expected) == len(actual) == len(equal) == 64
    passed = complete and bool(groups) and overflow == 0 and all(
        g['visited'] <= g['full_B_sum'] and g['eligible_visited'] <= g['visited'] and
        g['eligible_visited'] <= g['full_R_sum'] <= g['full_B_sum'] and
        g['hits'] <= g['calls'] and g['max_R'] <= g['max_B'] for g in groups)
    c.save(out / 'summary.json', {'passed': passed, 'groups': groups, 'overflow_calls': overflow,
        'equal_vectors_to_accepted_current': len(equal), 'reference_vectors': len(expected),
        'observed_vectors': len(actual), 'counter_only': True, 'throughput_claim': False,
        'limits': ['No clocks/printf per lookup; extra tail membership counts and atomic updates perturb runtime.',
            'All phases aggregate by Invocation address; addresses may be reused; not per-phase warm timing.',
            'Original same main/inputs/native closure, only one scratch resources object replaced.',
            'Original model payload hash retained from accepted receipt, not rehashed for this diagnostic.']})
    if not passed:
        raise ValueError('Counter completeness/invariants or64-vector comparison failed; preserve raw logs')
    print('LEASE_PROBE_COUNTS', out / 'summary.json', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--destination', default='run1')
    args = parser.parse_args()
    plan = c.read(S / 'plan.json')
    if args.build:
        build(plan, args.resume)
    if args.run:
        run(plan, args.destination)
    if not args.build and not args.run:
        print('PREPARED_NO_BUILD_GPU', S / 'plan.json')


if __name__ == '__main__':
    main()
