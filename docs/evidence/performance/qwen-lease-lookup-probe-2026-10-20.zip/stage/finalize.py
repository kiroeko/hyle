"""Publish one isolated, counter-only runtime observation; this is not a product patch."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
spec = importlib.util.spec_from_file_location("lease_probe_publication", S / "driver.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
run = c.read(S / "runs/run1/summary.json")
assert run["passed"] and run["equal_vectors_to_accepted_current"] == 64 and not run["overflow_calls"]
assert not run["throughput_claim"]
groups = run["groups"]
totals = {key: sum(row[key] for row in groups) for key in ("calls", "visited", "eligible_visited", "hits")}
assert all(row["max_B"] == 102 and row["max_R"] == 1 for row in groups)
assert totals == dict(calls=21736, visited=2217072, eligible_visited=21736, hits=0)
frozen = c.read(S / "source-freeze.json")
for item in (frozen["product_source"], frozen["before"], frozen["after"], frozen["diff"]):
    assert b.same(item), item["path"]
report = dict(scope="Counter-only same-Qwen-main diagnostic; one scratch resources.cc object replaces one accepted product object. No product algorithm change or speed claim.",
    result="Actual ready-region input lease lookup visits102 binding records per call although only1 has an eligible nonexclusive ReadLease; no match occurs in this fixed dense Qwen journey.",
    actual_build=dict(CXX_owners=1, CUDA_owners=0, SDK_builds=0, same_main_object=True),
    observation=run, totals=totals,
    decode_structure="Two observed decode Invocation addresses aggregate10880 and10200 calls:16*680 and15*680. Each decode step traverses69360 binding records for680 lookup calls; this does not assign a time to those checks.",
    next_design="Investigate an original-order eligible-record filter scoped to the same uncached preparation pass, preserving current lease/view/range checks and owner/permission lifecycle. Confirm membership cannot change during the scope before implementing.",
    limits=["Counts include both preparation passes and aggregate by address; an address is not a globally unique request or phase ID.",
        "Extra atomic counters/tail membership checks perturb runtime. No per-call clocks or prints, and no timing from this diagnostic is used for throughput.",
        "This fixed recipe has R=1 and no matches; it does not prove a safe optimization for projected page guards, covering overlaps, exclusive writers or every native hook.",
        "All64 retained hidden/logits comparisons are equal; this is not independent model quality or cross-platform coverage."],
    source_freeze=frozen, evidence=dict(stage=str(S), archive="qwen-lease-lookup-probe-2026-10-20.zip"),
    goal="Active; use observed work as the next implementation decision, not as completed architecture work")
c.save(S / "summary.json", report)
public = ROOT / "docs/evidence/performance/qwen-lease-lookup-probe-2026-10-20.json"
archive = public.with_suffix(".zip")
assert not archive.exists()
ignored = {".exe", ".obj", ".lib", ".exp", ".pdb", ".map", ".pyc", ".bf16", ".f32"}
files = {"stage/" + path.relative_to(S).as_posix(): path for path in S.rglob("*")
    if path.is_file() and path.suffix.lower() not in ignored and
    "tmp" not in path.relative_to(S).parts and path.name not in {"publication.json", "archive-manifest.json"}}
manifest = [dict(name=name, bytes=path.stat().st_size,
    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name, path in sorted(files.items())]
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        z.write(path, name)
    z.writestr("manifest.json", json.dumps(dict(payloads=manifest,
        excluded="Rebuildable images/objects/maps, SDK/model files and duplicate bit-identical observations"), ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        raw = z.read(row["name"])
        assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
receipt = dict(archive=b.identity(archive), payload_count=len(manifest), CRC_checked=True, all_payload_SHA256_checked=True)
report["evidence"].update(receipt)
c.save(public, report)
c.save(S / "archive-manifest.json", dict(payloads=manifest, receipt=receipt))
c.save(S / "publication.json", dict(report=b.identity(public), **receipt))
print("QWEN_LEASE_PROBE_PUBLISHED", receipt["archive"]["bytes"], "bytes", len(manifest), "payloads", flush=True)
