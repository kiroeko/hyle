#include "hyle/graph/executable.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/graph/result.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdio>
#include <mutex>
#include <new>
#include <utility>
#include <vector>

#include "hyle/compute/detail/completion_access.h"
#include "hyle/core/assert.h"
#include "hyle/mem/std_allocator.h"
#include "hyle/util/spin_lock.h"
#include "plan_state.h"
#include "resource_episode.h"
#include "submission_internal.h"
#include "submission_lifetime.h"
#include "../compute/provider_internal.h"

namespace hyle::graph {
namespace detail {
struct LeaseBinding final {
  ValueId value{};
  ValueId projection{};
  compute::TensorDesc description{};
  compute::ReadLease read{};
  compute::WriteLease write{};
  bool exclusive = false;
  bool input = false;
  bool permissionless = false;
  bool borrowed = true;
  bool configuration = false;
};

struct ResourceEpisode final {
  explicit ResourceEpisode(mem::AllocatorRef selected) noexcept
      : allocator(selected), bindings(mem::StdAllocator<LeaseBinding>(selected)),
        binding_slots(mem::StdAllocator<std::uint32_t>(selected)),
        permissions(selected) {}
  ~ResourceEpisode() {
    if (payload) payload_table->destroy(payload);
  }
  mem::AllocatorRef allocator;
  std::vector<LeaseBinding, mem::StdAllocator<LeaseBinding>> bindings;
  // The external ValueId records form an immutable prefix. Only anonymous
  // projected-page guards are appended/erased after it. Slots index identity,
  // never permissions, leases, addresses or readiness from an old episode.
  std::vector<std::uint32_t, mem::StdAllocator<std::uint32_t>> binding_slots;
  std::size_t fixed_binding_count = 0;
  LeasePermissionSet permissions;
  compute::LeaseUsePool uses;
  compute::LeaseUseBatch batch;
  std::uint32_t reserved_reads = 0;
  const ResourcePayloadVTable *payload_table = nullptr;
  void *payload = nullptr;
};

// Scratch-only counter probe. No clocks, ownership changes or lookup shortcut.
// Fixed address groups may merge reused Invocation addresses; no serial-ID claim.
namespace {
struct LeaseLoopProbeGroup final {
  std::atomic<const void *> invocation{nullptr};
  std::atomic<unsigned long long> calls{0}, visited{0}, eligible_visited{0}, hits{0};
  std::atomic<unsigned long long> full_b_sum{0}, full_r_sum{0}, max_b{0}, max_r{0};
  std::atomic<unsigned long long> tail_counted{0}, early{0}, steps_max{0};
};
void lease_loop_probe_max(std::atomic<unsigned long long> &counter,
                          unsigned long long value) noexcept {
  auto previous = counter.load(std::memory_order_relaxed);
  while (previous < value && !counter.compare_exchange_weak(
      previous, value, std::memory_order_relaxed, std::memory_order_relaxed)) {}
}
struct LeaseLoopProbeTable final {
  std::array<LeaseLoopProbeGroup, 32> groups{};
  std::atomic<unsigned long long> overflow_calls{0};
  ~LeaseLoopProbeTable() {
    for (auto &group : groups) {
      const auto key = group.invocation.load(std::memory_order_relaxed);
      if (!key) continue;
      std::fprintf(stderr,
          "lease_lookup_probe invocation=%p calls=%llu visited=%llu eligible_visited=%llu hits=%llu full_B_sum=%llu full_R_sum=%llu max_B=%llu max_R=%llu tail_counted=%llu early=%llu steps_max=%llu\n",
          key, group.calls.load(std::memory_order_relaxed),
          group.visited.load(std::memory_order_relaxed),
          group.eligible_visited.load(std::memory_order_relaxed),
          group.hits.load(std::memory_order_relaxed),
          group.full_b_sum.load(std::memory_order_relaxed),
          group.full_r_sum.load(std::memory_order_relaxed),
          group.max_b.load(std::memory_order_relaxed),
          group.max_r.load(std::memory_order_relaxed),
          group.tail_counted.load(std::memory_order_relaxed),
          group.early.load(std::memory_order_relaxed),
          group.steps_max.load(std::memory_order_relaxed));
    }
    std::fprintf(stderr, "lease_lookup_probe_overflow calls=%llu slots=32\n",
        overflow_calls.load(std::memory_order_relaxed));
  }
};
LeaseLoopProbeTable lease_loop_probe_table;
LeaseLoopProbeGroup *lease_loop_probe_group(const InvocationState &invocation) noexcept {
  const void *key = &invocation;
  for (auto &group : lease_loop_probe_table.groups) {
    auto previous = group.invocation.load(std::memory_order_relaxed);
    if (previous == key) return &group;
    if (!previous && group.invocation.compare_exchange_strong(
        previous, key, std::memory_order_relaxed, std::memory_order_relaxed))
      return &group;
    if (previous == key) return &group;
  }
  lease_loop_probe_table.overflow_calls.fetch_add(1, std::memory_order_relaxed);
  return nullptr;
}
struct LeaseLoopProbeCall final {
  LeaseLoopProbeGroup *group;
  const ResourceEpisode *episode = nullptr;
  unsigned long long visited = 0, eligible = 0, hits = 0, early = 0;
  unsigned long long steps;
  explicit LeaseLoopProbeCall(const InvocationState &invocation) noexcept
      : group(lease_loop_probe_group(invocation)),
        steps(static_cast<unsigned long long>(invocation.plan->steps.size())) {}
  ~LeaseLoopProbeCall() {
    if (!group) return;
    const auto b = episode ? static_cast<unsigned long long>(episode->bindings.size()) : 0;
    auto r = eligible;
    // On a hit the original loop stops early. Count only cheap membership in
    // the remaining tail to obtain TRUE R/B; never call view()/admit/read a
    // lease there. This diagnostic-only tail work is separately disclosed.
    if (episode)
      for (std::size_t i = static_cast<std::size_t>(visited); i < episode->bindings.size(); ++i)
        if (!episode->bindings[i].exclusive && episode->bindings[i].read.valid()) ++r;
    group->calls.fetch_add(1, std::memory_order_relaxed);
    group->visited.fetch_add(visited, std::memory_order_relaxed);
    group->eligible_visited.fetch_add(eligible, std::memory_order_relaxed);
    group->hits.fetch_add(hits, std::memory_order_relaxed);
    group->full_b_sum.fetch_add(b, std::memory_order_relaxed);
    group->full_r_sum.fetch_add(r, std::memory_order_relaxed);
    group->tail_counted.fetch_add(b - visited, std::memory_order_relaxed);
    group->early.fetch_add(early, std::memory_order_relaxed);
    lease_loop_probe_max(group->max_b, b);
    lease_loop_probe_max(group->max_r, r);
    lease_loop_probe_max(group->steps_max, steps);
  }
};
} // namespace

struct SubmissionLifetime final {
  explicit SubmissionLifetime(mem::AllocatorRef selected) noexcept
      : allocator(selected),
        retentions(mem::StdAllocator<compute::detail::CompletionRetention>(selected)) {}

  mem::AllocatorRef allocator;
  std::vector<compute::detail::CompletionRetention,
              mem::StdAllocator<compute::detail::CompletionRetention>> retentions;
  compute::detail::CompletionLifetime observation_retirement{};
  util::SpinLock lock;
  Status first_error;
  std::atomic<std::size_t> remaining{0};
  bool accepted = false;
  OrderedGraphSubmission ordered{};
};

SubmissionLifetimeOwner::SubmissionLifetimeOwner(SubmissionLifetimeOwner &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)) {}
SubmissionLifetimeOwner &SubmissionLifetimeOwner::operator=(SubmissionLifetimeOwner &&other) noexcept {
  if (this != &other) { reset(); state_ = std::exchange(other.state_, nullptr); }
  return *this;
}
SubmissionLifetimeOwner::~SubmissionLifetimeOwner() { reset(); }
void SubmissionLifetimeOwner::reset() noexcept {
  if (auto *lifetime = std::exchange(state_, nullptr)) {
    const auto allocator = lifetime->allocator;
    allocator.destroy(lifetime);
  }
}

ResourceEpisodeOwner::ResourceEpisodeOwner(ResourceEpisodeOwner &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)) {}
ResourceEpisodeOwner &ResourceEpisodeOwner::operator=(ResourceEpisodeOwner &&other) noexcept {
  if (this != &other) { reset(); state_ = std::exchange(other.state_, nullptr); }
  return *this;
}
ResourceEpisodeOwner::~ResourceEpisodeOwner() { reset(); }
void ResourceEpisodeOwner::reset() noexcept {
  if (auto *episode = std::exchange(state_, nullptr)) {
    const auto allocator = episode->allocator;
    allocator.destroy(episode);
  }
}

Status resource_control_ready(const InvocationState *state) noexcept {
  if (!state) return Status::FailedPrecondition("graph invocation is empty");
  if (state->closed) return Status::FailedPrecondition("graph invocation is closed");
  const auto phase = state->phase.load(std::memory_order_acquire);
  if (phase == InvocationPhase::kRunning)
    return Status::Unavailable("graph invocation is in flight");
  if (phase == InvocationPhase::kFailed)
    return Status::FailedPrecondition("failed graph invocation must be recreated");
  if (state->preparation_uses.load(std::memory_order_acquire) != 0)
    return Status::Unavailable("graph invocation bindings are being prepared");
  if (state->results.load(std::memory_order_acquire))
    return Status::Unavailable("graph results still retain this invocation");
  if (!state->observation.available())
    return Status::Unavailable("old graph completion retains its observation slot");
  return Status::Ok();
}

Status reset_resource_payload(Invocation &invocation) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (!state->resources || !state->resources.get()->payload) return Status::Ok();
  auto &episode = *state->resources.get();
  return episode.payload_table->reset(episode.payload, invocation);
}

Result<void *> RegionAccess::resource_payload(Invocation &invocation,
    const ResourcePayloadVTable *table) noexcept {
  auto *state = InvocationAccess::state(invocation);
  if (!state)
    return std::unexpected(Status::FailedPrecondition("graph invocation is empty"));
  if (!table || !table->reset || !table->destroy)
    return std::unexpected(Status::InvalidArgument("resource payload implementation is incomplete"));
  if (!state->resources || !state->resources.get()->payload) return nullptr;
  auto &episode = *state->resources.get();
  if (episode.payload_table != table)
    return std::unexpected(Status::InvalidArgument("resource payload belongs to another implementation"));
  return episode.payload;
}

Result<ResourceEpisode *> require_resources(InvocationState *state) noexcept {
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (!state->resources)
    return std::unexpected(Status::FailedPrecondition(
        "owned bindings require prepare_resources or factory.resources"));
  return state->resources.get();
}
Status RegionAccess::attach_resource_payload(Invocation &invocation,
    const ResourcePayloadVTable *table, void *payload) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  if (!table || !table->reset || !table->destroy || !payload)
    return Status::InvalidArgument("resource payload requires an implementation and owner");
  if (episode->payload)
    return Status::FailedPrecondition("graph invocation already owns a resource payload");
  episode->payload_table = table;
  episode->payload = payload;
  return Status::Ok();
}
const LeaseBinding *find_binding(const InvocationState *state, ValueId value) noexcept {
  if (!state || !state->resources || !value.valid()) return nullptr;
  const auto &episode = *state->resources.get();
  if (value.ordinal() >= episode.binding_slots.size()) return nullptr;
  const auto slot = episode.binding_slots[value.ordinal()];
  if (slot >= episode.fixed_binding_count) return nullptr;
  const auto &binding = episode.bindings[slot];
  // Equal ordinals from a different Graph/generation never name this record.
  return binding.value == value ? &binding : nullptr;
}
LeaseBinding *find_binding(InvocationState *state, ValueId value) noexcept {
  return const_cast<LeaseBinding *>(find_binding(
      static_cast<const InvocationState *>(state), value));
}
Status check_binding_replacement(const InvocationState &state, ValueId value) noexcept {
  const auto *binding = find_binding(&state, value);
  if (binding && binding->configuration)
    return Status::FailedPrecondition(
        "graph input belongs to its cold configuration; reset before ordinary rebinding");
  return Status::Ok();
}
void invalidate_native_input_bindings(InvocationState &state,
                                      ValueId value = {}) noexcept {
  const auto &plan = *state.plan;
  const auto origin = [&](std::uint32_t input) noexcept {
    while (plan.alias_sources[input] != kNoInPlaceSource)
      input = plan.alias_sources[input];
    return input;
  };
  const auto root = value.valid()
      ? origin(plan.external_instances[value.ordinal()]) : kNoWorkspaceRequest;
  for (std::size_t index = 0; index < state.step_bindings.size(); ++index) {
    if (!state.step_bindings[index].native_inputs)
      continue;
    const auto &step = plan.steps[index];
    bool affected = !value.valid();
    for (std::size_t port = 0; !affected && port < step.input_count; ++port)
      affected = origin(plan.node_inputs[step.input_begin + port]) == root;
    if (affected)
      invalidate_step_recording(state, static_cast<std::uint32_t>(index));
  }
}
void reset_resource_bindings(InvocationState &state) noexcept {
  // Native imports can own carriers/arrays independently of their raw address.
  // Release their recording before withdrawing the old source or lease owner.
  invalidate_native_input_bindings(state);
  reset_input_source_bindings(state);
  if (!state.resources) return;
  auto &bindings = state.resources.get()->bindings;
  // All extra records are anonymous page guards; fixed ValueId slots never
  // move. Shrinking releases exactly the old projected permission suffix.
  bindings.resize(state.resources.get()->fixed_binding_count);
  for (auto &binding : bindings) {
    binding.read.reset(); binding.write.reset(); binding.description = {};
    binding.projection = {};
    binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;
    binding.configuration = false;
  }
}
void note_borrowed_binding(InvocationState &state, ValueId value) noexcept {
  const auto *previous = find_binding(&state, value);
  if (state.input_sources || (previous &&
      (previous->read.valid() || previous->write.valid() || previous->configuration)))
    invalidate_native_input_bindings(state, value);
  note_borrowed_input_source(state, value);
  if (!state.resources) return;
  auto &bindings = state.resources.get()->bindings;
  const auto extras = bindings.begin() + state.resources.get()->fixed_binding_count;
  bindings.erase(std::remove_if(extras, bindings.end(), [&](const auto &binding) {
    return binding.projection == value;
  }), bindings.end());
  if (auto *binding = find_binding(&state, value)) {
    binding->read.reset(); binding->write.reset(); binding->description = {};
    binding->projection = {};
    binding->exclusive = false; binding->permissionless = false; binding->borrowed = true;
    binding->configuration = false;
  }
}

Status RegionAccess::bind_configuration(Invocation &invocation, ValueId value,
    compute::TensorDesc description, compute::ReadLease lease) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  (void)episode;
  auto *binding = find_binding(state, value);
  if (!binding || !binding->input)
    return Status::InvalidArgument("cold configuration must bind a graph input");
  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));
  // Reuse the original binding validation/commit. Only this synchronized cold
  // call suspends the replacement guard; a rejecting bind has not invalidated
  // replay or released the old resource owner.
  const bool previous = std::exchange(binding->configuration, false);
  const auto status = invocation.bind(value, tensor);
  binding = find_binding(state, value);
  if (!status.ok()) {
    binding->configuration = previous;
    return status;
  }
  binding->read = std::move(lease); binding->description = description;
  binding->exclusive = false; binding->permissionless = false; binding->borrowed = false;
  binding->configuration = true;
  return Status::Ok();
}

Status RegionAccess::reserve_reads(Invocation &invocation, std::uint32_t extra,
                                 ResourceOptions options) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto *episode, require_resources(state));
  // Repeated layout preparation reuses the same fixed permission/use storage.
  // Only actual capacity growth needs an unbound cold slot.
  if (extra <= episode->reserved_reads) return Status::Ok();
  for (const auto &binding : episode->bindings)
    if (binding.read.valid() || binding.write.valid())
      return Status::FailedPrecondition("reserve page permissions before owned bindings");
  if (extra > UINT32_MAX - 1 || episode->bindings.size() > UINT32_MAX - 1 - extra)
    return Status::ResourceExhausted("graph permission capacity overflow");
  HYLE_ASSIGN_OR_RETURN(auto uses, compute::LeaseUsePool::create({.max_batches = 1,
      .max_resources_per_batch = std::uint32_t(episode->bindings.size() + extra + 1),
      .allocator = options.allocator, .resource_budget = options.resource_budget}));
  try { episode->bindings.reserve(episode->bindings.size() + extra); }
  catch (...) { return Status::ResourceExhausted("graph fixed permission metadata"); }
  if (extra) HYLE_RETURN_IF_ERROR(episode->permissions.reserve(episode->bindings.size() + extra));
  episode->uses = std::move(uses);
  episode->reserved_reads = extra;
  return Status::Ok();
}
Status RegionAccess::bind_projected_impl(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease> pages,
    std::span<const ProjectedReader> readers,
    bool pending)noexcept{
  auto*state=InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto*episode, require_resources(state));
  auto*binding=find_binding(state,value);
  if(!binding || !binding->input || !tensor.valid() || readers.empty())
    return Status::InvalidArgument("projected graph requires an input and actual page permissions");
  const bool replacing = !pending && !binding->borrowed && binding->projection == value;
  if(!binding->borrowed && !replacing)
    return Status::FailedPrecondition("projected graph input needs an explicit reset before rebinding");
  const auto&plan=*state->plan;
  const auto logical=value.ordinal();const auto physical=plan.external_instances[logical];
  if((plan.binding_roles[logical]&kExternalOutput)!=0)
    return Status::InvalidArgument("projected capacity cannot be a graph output");
  for(std::size_t i=0;i<plan.alias_sources.size();++i){
    // Every descendant chain must contain a direct child of this root.
    if(i!=physical && plan.alias_sources[i]==physical)
      return Status::InvalidArgument("projected capacity cannot have a physical alias descendant");
  }
  for(std::size_t i=0;i<readers.size();++i){
    const auto&proof=readers[i];
    if(proof.step>=plan.steps.size())
      return Status::InvalidArgument("projected reader step is foreign");
    const auto&step=plan.steps[proof.step];
    if(step.kind!=PlanStepKind::kRegion || proof.input_port>=step.input_count ||
       !step.region.matches_artifact(proof.implementation,proof.prepared) ||
       plan.node_inputs[step.input_begin+proof.input_port]!=physical)
      return Status::InvalidArgument("projected reader differs from its selected artifact/port");
    for(std::size_t j=0;j<i;++j)
      if(readers[j].step==proof.step && readers[j].input_port==proof.input_port)
        return Status::InvalidArgument("projected reader physical port is duplicated");
    if(!pending && pages.empty()){
      const auto&prepared=step.region.prepared_;
      const auto*interface=prepared.vtable->query_extension ?
          static_cast<const RegionProjectedReadVTable*>(prepared.vtable->query_extension(
              prepared.state,kRegionProjectedReadExtensionId)) : nullptr;
      if(!interface || !interface->inspect)
        return Status::Unimplemented("selected reader cannot prove an empty input footprint");
      compute::detail::OperationPreparedAccess access;
      HYLE_RETURN_IF_ERROR(interface->inspect(prepared,
          state->invocations[proof.step].region.state_,proof.input_port,&access));
      if(access.projected_input!=proof.input_port || !access.allows_empty_footprint)
        return Status::InvalidArgument("selected reader still requires actual input permissions");
    }
  }
  bool consumed=false;
  for(std::size_t i=0;i<plan.steps.size();++i){const auto&step=plan.steps[i];
    for(std::size_t port=0;port<step.input_count;++port){
      const auto input=plan.node_inputs[step.input_begin+port];
      if(plan.instance_values[input]!=logical)continue;
      consumed=true;
      if(input!=physical || step.kind!=PlanStepKind::kRegion ||
         std::none_of(readers.begin(),readers.end(),[&](const auto&proof)noexcept{
           return proof.step==i && proof.input_port==port;
         }))
        return Status::InvalidArgument("projected capacity has an unqualified physical reader");
    }
  }
  if(!consumed)return Status::InvalidArgument("projected capacity has no qualified reader");
  const auto old_extra = std::count_if(episode->bindings.begin(), episode->bindings.end(),
      [&](const auto &entry) { return !entry.value.valid() && entry.projection == value; });
  if(!pages.empty() && pages.size()-1>episode->bindings.capacity()-(episode->bindings.size()-old_extra))
    return Status::ResourceExhausted("projected graph permission capacity exhausted");
  const auto storage=tensor.storage();
  for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() ||
       view.offset()<storage.offset() || view.offset()-storage.offset()>storage.size() ||
       view.size()>storage.size()-(view.offset()-storage.offset()))
      return Status::InvalidArgument("projected page permission is outside its native capacity");
  }
  HYLE_RETURN_IF_ERROR(invocation.bind(value,tensor));
  // The ordinary bind has now invalidated replay and removed the old page
  // permissions. Every rejecting check preceded it; this commit cannot grow
  // the fixed permission table or disturb an old binding on failure.
  binding=find_binding(state,value);
  if(!pages.empty())binding->read=pages.front();
  binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;
  binding->permissionless=pages.empty()&&!pending;
  binding->projection=pending?ValueId{}:value;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=value,.read=pages[i],.borrowed=false});
  return Status::Ok();
}
Status RegionAccess::bind_projected(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease> pages,
    std::span<const ProjectedReader> readers)noexcept{
  return bind_projected_impl(invocation,value,tensor,pages,readers,false);
}
Status RegionAccess::bind_pending_projected(Invocation&invocation,ValueId value,
    compute::ConstTensorView tensor,std::span<const ProjectedReader> readers)noexcept{
  return bind_projected_impl(invocation,value,tensor,{},readers,true);
}
bool RegionAccess::outcome_available(const Invocation&invocation)noexcept{
  const auto*state=InvocationAccess::state(invocation);
  return state && state->phase.load(std::memory_order_acquire)!=InvocationPhase::kRunning &&
      !state->results.load(std::memory_order_acquire) && state->observation.available();
}
Status RegionAccess::bind_read_projection(Invocation&invocation,ReadProjection projection,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease> pages)noexcept{
  auto*state=InvocationAccess::state(invocation);HYLE_ASSIGN_OR_RETURN(auto*episode,require_resources(state));
  const auto&plan=*state->plan;const auto capacity=projection.capacity;
  if(GraphIdentity::generation(capacity)!=plan.generation || capacity.kind()!=ValueKind::kInput ||
      capacity.ordinal()>=plan.external_instances.size() || projection.readers.empty() || !tensor.valid() || pages.empty())
    return Status::InvalidArgument("read projection requires its exact plan/input/footprint");
  auto*binding=find_binding(state,capacity);
  if(!binding || !binding->input)return Status::InvalidArgument("read projection is not a plan input");
  if(binding->read.valid() || binding->write.valid() || binding->permissionless)
    return Status::FailedPrecondition("read projection needs reset before rebinding");
  const auto root=plan.external_instances[capacity.ordinal()];
  const auto allowed=[&](std::uint32_t value)noexcept{
    return value==capacity.ordinal() || std::ranges::any_of(projection.aliases,[&](ValueId alias){return alias.ordinal()==value;});
  };
  const auto origin=[&](std::uint32_t input)noexcept{
    while(plan.alias_sources[input]!=kNoInPlaceSource)input=plan.alias_sources[input];
    return input;
  };
  for(std::size_t i=0;i<projection.aliases.size();++i){const auto alias=projection.aliases[i];
    if(GraphIdentity::generation(alias)!=plan.generation || alias==capacity || alias.ordinal()>=plan.binding_roles.size() ||
        (plan.binding_roles[alias.ordinal()]&kExternalOutput))return Status::InvalidArgument("read projection alias is foreign or published");
    for(std::size_t j=0;j<i;++j)if(alias==projection.aliases[j])return Status::InvalidArgument("read projection alias is duplicated");
  }
  if(plan.binding_roles[capacity.ordinal()]&kExternalOutput)return Status::InvalidArgument("projected capacity is published");
  for(std::size_t i=0;i<plan.alias_sources.size();++i){
    if(origin(std::uint32_t(i))!=root)continue;
    if(!allowed(plan.instance_values[i]))return Status::InvalidArgument("projected capacity has an undeclared physical alias");
    std::size_t offset=0;auto current=std::uint32_t(i);
    while(current!=root){if(plan.alias_offsets[current]>SIZE_MAX-offset)return Status::InvalidArgument("projection alias byte offset overflow");
      offset+=plan.alias_offsets[current];current=plan.alias_sources[current];}
    HYLE_ASSIGN_OR_RETURN(auto bytes,plan.instance_descriptions[i].required_bytes());
    if(offset>tensor.storage().size() || bytes>tensor.storage().size()-offset)
      return Status::InvalidArgument("projected alias bytes exceed the original capacity");
  }
  for(std::size_t i=0;i<projection.readers.size();++i){const auto reader=projection.readers[i];
    if(GraphIdentity::generation(reader)!=plan.generation || reader.ordinal()>=plan.node_steps.size())
      return Status::InvalidArgument("projected reader is foreign");
    const auto step=plan.node_steps[reader.ordinal()];
    if(step>=plan.steps.size() || (plan.steps[step].kind!=PlanStepKind::kOperation && plan.steps[step].kind!=PlanStepKind::kRegion))
      return Status::InvalidArgument("projected reader has no selected prepared implementation");
    bool reads=false;for(std::size_t port=0;port<plan.steps[step].input_count;++port)
      reads|=origin(plan.node_inputs[plan.steps[step].input_begin+port])==root;
    if(!reads)return Status::InvalidArgument("projected reader does not consume this physical root");
    for(std::size_t j=0;j<i;++j)if(reader==projection.readers[j])return Status::InvalidArgument("projected reader is duplicated");
  }
  bool consumed=false;
  for(std::size_t i=0;i<plan.steps.size();++i){const auto&step=plan.steps[i];
    const bool declared=std::ranges::any_of(projection.readers,[&](NodeId reader){return plan.node_steps[reader.ordinal()]==i;});
    for(std::size_t port=0;port<step.input_count;++port){const auto input=plan.node_inputs[step.input_begin+port];if(origin(input)!=root)continue;
      if(!allowed(plan.instance_values[input]))return Status::InvalidArgument("projection physical input is not a declared alias");
      if(step.kind==PlanStepKind::kView && !step.materializes){
        for(std::size_t out=0;out<step.output_count;++out){const auto value=plan.node_outputs[step.output_begin+out];
          if(origin(value)!=root || !allowed(plan.instance_values[value]))return Status::InvalidArgument("projection view escapes its declared aliases");}
        continue;
      }
      if(!declared)return Status::InvalidArgument("projected root has an unqualified physical consumer");
      compute::detail::OperationPreparedAccess access;
      if(step.kind==PlanStepKind::kOperation){
        HYLE_ASSIGN_OR_RETURN(access,compute::detail::OperationPreparationAccess::inspect_access(step.operation,compute::detail::kProjectedInputReadExtensionId));
      }else if(step.kind==PlanStepKind::kRegion){
        const auto&prepared=step.region.prepared_;
        const auto*interface=prepared.vtable->query_extension ?
            static_cast<const RegionProjectedReadVTable*>(prepared.vtable->query_extension(
                prepared.state,kRegionProjectedReadExtensionId)) : nullptr;
        if(!interface || !interface->inspect)
          return Status::Unimplemented("selected region has no projected input inspector");
        HYLE_RETURN_IF_ERROR(interface->inspect(prepared,
            state->invocations[i].region.state_,std::uint32_t(port),&access));
      }else return Status::InvalidArgument("projected root has a materializing/copy consumer");
      if(access.projected_input!=port)return Status::Unimplemented("selected implementation does not project this physical input port");
      consumed=true;
    }
  }
  if(!consumed)return Status::InvalidArgument("projected root has no selected checked reader");
  if(pages.size()-1>episode->bindings.capacity()-episode->bindings.size())return Status::ResourceExhausted("read projection guard capacity exhausted");
  const auto storage=tensor.storage();for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() || view.offset()<storage.offset() ||
        view.offset()-storage.offset()>storage.size() || view.size()>storage.size()-(view.offset()-storage.offset()))
      return Status::InvalidArgument("projected page guard outside original capacity");}
  HYLE_RETURN_IF_ERROR(invocation.bind(capacity,tensor));
  binding->read=pages.front();binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false});
  return Status::Ok();
}
Result<compute::WriteLease> RegionAccess::take_write(Invocation&invocation,ValueId value)noexcept{
  auto*state=InvocationAccess::state(invocation);
  HYLE_ASSIGN_OR_RETURN(auto*episode,require_resources(state));
  (void)episode;
  if(state->phase.load(std::memory_order_acquire)!=InvocationPhase::kIdle)
    return std::unexpected(Status::FailedPrecondition("failed graph output cannot be reclaimed"));
  auto*binding=find_binding(state,value);if(!binding || binding->input)
    return std::unexpected(Status::InvalidArgument("only caller output writer can be reclaimed"));
  return std::move(binding->write);
}
Result<RegionNodeAccess> RegionAccess::projection_access(
    const PlanState &plan, const InvocationState *invocation,
    ResourceProjection projection) noexcept {
  if (!projection.capability.valid() || projection.access_nodes.empty())
    return std::unexpected(Status::InvalidArgument("projection needs its selected access implementations"));
  RegionNodeAccess reader_access;
  bool found = false;
  for (const auto node : projection.access_nodes) {
    if (GraphIdentity::generation(node) != plan.generation || node.ordinal() >= plan.node_steps.size())
      return std::unexpected(Status::InvalidArgument("projection access node is foreign"));
    HYLE_ASSIGN_OR_RETURN(auto access,
        inspect_projection_node(plan, invocation, node, projection.capability));
    if (node == projection.reader) { reader_access = access; found = true; }
  }
  if (!found || reader_access.access.projected_input == compute::detail::OperationPreparedAccess::kNoInput)
    return std::unexpected(Status::Unimplemented("selected reader does not project a physical input"));
  const auto &reader = plan.steps[plan.node_steps[projection.reader.ordinal()]];
  if (reader_access.access.projected_input >= reader.input_count)
    return std::unexpected(Status::InvalidArgument("projection prepared input port is outside its selected step"));
  const auto physical = plan.node_inputs[reader.input_begin + reader_access.access.projected_input];
  if (plan.instance_values[physical] != projection.capacity.ordinal())
    return std::unexpected(Status::InvalidArgument("projection capacity differs from selected prepared input"));
  return reader_access;
}
Result<mem::MemoryResourceRef> RegionAccess::projection_resource(const Executable&executable,
    ResourceProjection projection,ExecutionLaneId*reader_lane)noexcept{
  const auto*plan=ExecutableAccess::state(executable);
  const auto capacity=projection.capacity,metadata=projection.metadata;
  const auto decoder=projection.reader;
  if(!plan || capacity==metadata ||
      capacity.kind()!=ValueKind::kInput || metadata.kind()!=ValueKind::kInput ||
      GraphIdentity::generation(capacity)!=plan->generation || GraphIdentity::generation(metadata)!=plan->generation ||
      capacity.ordinal()>=plan->external_instances.size() || metadata.ordinal()>=plan->external_instances.size() ||
      !(plan->binding_roles[capacity.ordinal()]&kExternalInput) ||
      !(plan->binding_roles[metadata.ordinal()]&kExternalInput))
    return std::unexpected(Status::InvalidArgument("projection needs its exact plan and input identities"));
  HYLE_ASSIGN_OR_RETURN(auto access,projection_access(*plan,nullptr,projection));
  const auto bank_port=access.access.projected_input;
  const auto root=plan->external_instances[capacity.ordinal()];
  for(std::size_t i=0;i<plan->alias_sources.size();++i)if(i!=root && plan->alias_sources[i]==root)
    return std::unexpected(Status::InvalidArgument("row capacity cannot have a physical alias descendant"));
  bool consumed=false;
  for(std::size_t i=0;i<plan->steps.size();++i){const auto&step=plan->steps[i];
    for(std::size_t port=0;port<step.input_count;++port){const auto input=plan->node_inputs[step.input_begin+port];
      if(plan->instance_values[input]!=capacity.ordinal())continue;
      if(input!=root || i!=plan->node_steps[decoder.ordinal()] ||
          (step.kind!=PlanStepKind::kOperation && step.kind!=PlanStepKind::kRegion) || port!=bank_port)
        return std::unexpected(Status::InvalidArgument("row capacity has a copy or unrelated physical reader"));
      consumed=true;
    }}
  if(!consumed || (plan->binding_roles[capacity.ordinal()]&kExternalOutput)!=0)
    return std::unexpected(Status::InvalidArgument("row capacity is published or has no checked reader"));
  const auto a=plan->external_storage[capacity.ordinal()],b=plan->external_storage[metadata.ordinal()];
  if(a>=plan->storage_domains.size() || b>=plan->storage_domains.size() ||
      plan->storage_domains[a].resource!=plan->storage_domains[b].resource)
    return std::unexpected(Status::Unimplemented("row capacity and metadata require the same native resource"));
  if(reader_lane)*reader_lane=plan->steps[plan->node_steps[decoder.ordinal()]].lane;
  return plan->storage_domains[a].resource;
}
Status RegionAccess::bind_projection(Invocation&invocation,ResourceProjection projection,
    compute::ConstTensorView tensor,std::span<const compute::ReadLease>pages,bool pending)noexcept{
  auto*state=InvocationAccess::state(invocation);HYLE_ASSIGN_OR_RETURN(auto*episode, require_resources(state));
  HYLE_ASSIGN_OR_RETURN(auto resource,projection_resource(invocation.executable(),projection));
  HYLE_ASSIGN_OR_RETURN(auto access,projection_access(*state->plan,state,projection));
  if(pending && !access.allows_pending)
    return Status::Unimplemented("selected projected reader has no pending source admission");
  const auto capacity=projection.capacity;
  auto*binding=find_binding(state,capacity);
  const auto&description=state->plan->domain_graph.valid()?state->concrete_descriptions[capacity.ordinal()]:state->plan->descriptions[capacity.ordinal()];
  if(!binding || !binding->input || !tensor.valid() || tensor.description()!=description || tensor.storage().resource()!=resource ||
      (pages.empty() && !pending && !access.access.allows_empty_footprint) || (pending && !pages.empty()))
    return Status::InvalidArgument("row projection needs its native capacity and exact page guards");
  if(binding->read.valid() || binding->write.valid() || binding->permissionless)return Status::FailedPrecondition("row projection needs reset before rebinding");
  if(!pages.empty() && pages.size()-1>episode->bindings.capacity()-episode->bindings.size())return Status::ResourceExhausted("row projection page guard capacity");
  const auto storage=tensor.storage();for(const auto&page:pages){HYLE_ASSIGN_OR_RETURN(auto view,page.view());
    if(view.resource()!=storage.resource() || view.native_handle()!=storage.native_handle() || view.offset()<storage.offset() ||
        view.offset()-storage.offset()>storage.size() || view.size()>storage.size()-(view.offset()-storage.offset()))
      return Status::InvalidArgument("row page guard outside original capacity");}
  HYLE_RETURN_IF_ERROR(invocation.bind(capacity,tensor));
  binding=find_binding(state,capacity);
  if(!pages.empty())binding->read=pages.front();
  binding->description=description;binding->exclusive=false;binding->borrowed=false;binding->permissionless=pages.empty()&&!pending;
  for(std::size_t i=1;i<pages.size();++i)episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false});
  return Status::Ok();
}
Status prepare_submission_lifetime(InvocationState &state,
                                   mem::AllocatorRef allocator) noexcept {
  HYLE_RETURN_IF_ERROR(resource_control_ready(&state));
  if (!allocator.valid())
    return Status::InvalidArgument("graph submission allocator is invalid");
  if (state.submission_lifetime) return Status::Ok();
  if (state.plan->segments.size() == SIZE_MAX)
    return Status::ResourceExhausted("graph submission retention capacity overflow");
  auto *lifetime = allocator.construct<SubmissionLifetime>(allocator);
  if (!lifetime)
    return Status::ResourceExhausted("graph submission lifetime metadata");
  SubmissionLifetimeOwner candidate(lifetime);
  try { lifetime->retentions.resize(state.plan->segments.size() + 1); }
  catch (...) { return Status::ResourceExhausted("graph fixed submission metadata"); }
  state.submission_lifetime = std::move(candidate);
  return Status::Ok();
}

Status begin_submission_lifetime(InvocationState &state,
                                 OrderedGraphSubmission ordered) noexcept {
  if (!state.submission_lifetime)
    return Status::FailedPrecondition("graph submission lifetime is not prepared");
  auto &lifetime = *state.submission_lifetime.get();
  if (state.phase.load(std::memory_order_acquire) != InvocationPhase::kRunning ||
      lifetime.remaining.load(std::memory_order_acquire) != 0)
    return Status::FailedPrecondition("graph submission lifetime requires an admitted cursor");
  if (!ordered.valid())
    return Status::InvalidArgument("ordered graph submission requires source owner, input qualification and mapping");
  if (ordered.map && !state.resources)
    return Status::FailedPrecondition("ordered graph submission requires prepared resources");
  if (!state.observation.available())
    return Status::Unavailable("old graph completion retains its observation slot");
  lifetime.observation_retirement = state.observation.reserve_retirement();
  {
    std::lock_guard guard(lifetime.lock);
    lifetime.first_error = Status::Ok();
    lifetime.accepted = false;
    lifetime.ordered = ordered;
    lifetime.remaining.store(1, std::memory_order_relaxed);
    retain(&state);
  }
  return Status::Ok();
}

void record_submission_error(InvocationState &state, const Status &error) noexcept {
  if (!error.ok()) {
    HYLE_FATAL_ASSERT(state.submission_lifetime);
    auto &lifetime = *state.submission_lifetime.get();
    std::lock_guard guard(lifetime.lock);
    lifetime.first_error.Update(error);
  }
}

Status submission_lifetime_status(const InvocationState &state) noexcept {
  if (!state.submission_lifetime) return Status::Ok();
  auto &lifetime = *state.submission_lifetime.get();
  std::lock_guard guard(lifetime.lock);
  return lifetime.first_error;
}

void child_terminal(void *opaque, const Status &terminal) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  record_submission_error(state, terminal);
}
void release_submission_lifetime(void *opaque) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  auto &lifetime = *state.submission_lifetime.get();
  if (lifetime.remaining.fetch_sub(1, std::memory_order_acq_rel) != 1) return;
  Status terminal;
  {
    std::lock_guard guard(lifetime.lock);
    terminal = lifetime.first_error;
  }
  // Successful ordered consumers prove their immutable producers were reached.
  // Reconcile their original cached diagnostics before publishing this slot.
  auto source_terminal = reconcile_input_sources(state, terminal);
  if (!source_terminal.ok()) {
    record_submission_error(state, source_terminal);
    terminal.Update(source_terminal);
  }
  const bool accepted = lifetime.accepted;
  lifetime.ordered = {};
  // All accepted children have actually released their guards. Finish every
  // resource mutation before making the original invocation idle/failed.
  if (state.resources) {
    auto &episode = *state.resources.get();
    if (accepted && episode.batch.valid()) {
      auto retired = compute::Completion::completed(terminal);
      HYLE_FATAL_ASSERT(episode.batch.attach(retired).ok());
    } else {
      episode.batch = {};
    }
    episode.permissions.reset();
  }
  const auto observation = std::exchange(lifetime.observation_retirement, {});
  InvocationAccess::retire(state, terminal, accepted);
  state.progress.notify();
  observation.terminal(observation.state, terminal);
  observation.release(observation.state);
  // No lifetime/resource access after publication: another cold call may reuse
  // them immediately. Only the original owner's final reference remains.
  release(&state);
}
void retain_submission_completion(void *opaque, std::size_t segment,
                                  compute::Completion &completion) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  auto &lifetime = *state.submission_lifetime.get();
  HYLE_FATAL_ASSERT(lifetime.remaining.load(std::memory_order_relaxed) != 0);
  HYLE_FATAL_ASSERT(segment < lifetime.retentions.size());
  auto &node = lifetime.retentions[segment];
  HYLE_FATAL_ASSERT(!node.own.valid());
  // The final observation guard is not another accepted native command.
  // Preserve zero-command rejection/retry even when an ordered mapper owns
  // a real external prefix that still needs retirement.
  if (segment < state.plan->segments.size()) lifetime.accepted = true;
  lifetime.remaining.fetch_add(1, std::memory_order_relaxed);
  node.own = {&state, &child_terminal, &release_submission_lifetime};
  HYLE_FATAL_ASSERT(compute::detail::CompletionAccess::attach_retention(completion, node).ok());
}

Status admit_submission_sequence(void *opaque, ExecutionLaneId lane,
                                  compute::detail::QueueSequence &sequence) noexcept {
  auto &state = *static_cast<InvocationState *>(opaque);
  const auto &ordered = state.submission_lifetime.get()->ordered;
  if (!ordered.admit) return Status::Ok();
  return ordered.admit(ordered.owner, lane, sequence, state.resources.get()->batch);
}

void finish_submission_lifetime(InvocationState &state, const Status &terminal) noexcept {
  HYLE_FATAL_ASSERT(state.submission_lifetime &&
      state.submission_lifetime.get()->remaining.load(std::memory_order_relaxed) != 0);
  record_submission_error(state, terminal);
  release_submission_lifetime(&state);
}

bool submission_admission_enabled(const InvocationState &state) noexcept {
  return state.submission_lifetime && state.submission_lifetime.get()->ordered.admit;
}

Result<compute::ReadLease> output_storage(InvocationState &state,
    compute::ConstTensorView tensor) noexcept {
  if (state.resources) {
    const auto wanted = tensor.storage();
    HYLE_ASSIGN_OR_RETURN(const auto bytes, tensor.description().required_bytes());
    for (auto &binding : state.resources.get()->bindings) {
      if (!binding.read.valid()) continue;
      HYLE_ASSIGN_OR_RETURN(auto source, binding.read.view());
      if (source.resource() != wanted.resource() || source.native_handle() != wanted.native_handle() ||
          wanted.offset() < source.offset()) continue;
      const auto offset = wanted.offset() - source.offset();
      if (offset <= source.size() && bytes <= source.size() - offset)
        return binding.read.subview(offset, bytes);
    }
  }
  return std::unexpected(Status::FailedPrecondition(
      "graph-owned or borrowed output has no independent storage lease"));
}

const compute::TensorDesc &output_description(const InvocationState &state,
    std::uint32_t instance) noexcept {
  return state.plan->domain_graph.valid()
      ? state.concrete_descriptions[state.plan->instance_values[instance]]
      : state.plan->instance_descriptions[instance];
}

const compute::ReadLease *input_lease(const InvocationState &invocation,
    compute::ConstTensorView tensor) noexcept {
  LeaseLoopProbeCall probe{invocation};
  if (!invocation.resources || !tensor.valid()) { probe.early = 1; return nullptr; }
  probe.episode = invocation.resources.get();
  const auto wanted = tensor.storage();
  for (const auto &binding : invocation.resources.get()->bindings) {
    ++probe.visited;
    // Exclusive bindings publish a read after success, but submit upgrades it
    // back to the original writer. A captured native read would prevent that
    // upgrade on a later cold rebind; the episode's write use owns this input.
    if (binding.exclusive || !binding.read.valid()) continue;
    ++probe.eligible;
    const auto view = binding.read.view();
    if (!view || view->resource() != wanted.resource() ||
        view->native_handle() != wanted.native_handle() || wanted.offset() < view->offset())
      continue;
    const auto offset = wanted.offset() - view->offset();
    if (offset <= view->size() && wanted.size() <= view->size() - offset) {
      ++probe.hits;
      return &binding.read;
    }
  }
  return nullptr;
}

Result<compute::ConstTensorView> output_tensor(const InvocationState &state,
    std::uint32_t instance) noexcept {
  if (instance >= state.readable.size())
    return std::unexpected(Status::Internal("graph output instance is invalid"));
  if (state.readable[instance].valid()) return state.readable[instance];
  const auto &plan = *state.plan;
  auto root = instance;
  std::size_t offset = 0;
  while (plan.alias_sources[root] != kNoInPlaceSource) {
    if (plan.domain_graph.valid())
      return std::unexpected(Status::Unimplemented("native alias has no resolved byte offset"));
    if (plan.alias_offsets[root] > SIZE_MAX - offset)
      return std::unexpected(Status::Internal("native output alias byte offset overflow"));
    offset += plan.alias_offsets[root];
    root = plan.alias_sources[root];
  }
  for (std::size_t index = 0; index < plan.steps.size(); ++index) {
    const auto &step = plan.steps[index];
    if (step.kind != PlanStepKind::kRegion) continue;
    for (std::size_t port = 0; port < step.output_count; ++port) {
      if (plan.node_outputs[step.output_begin + port] != root) continue;
      HYLE_ASSIGN_OR_RETURN(auto value, state.invocations[index].region.output_value(port));
      if (value.description != output_description(state, root) || value.reference.valid())
        return std::unexpected(Status::Internal("native output projection description differs"));
      if (!value.tensor.valid()) {
        if (step.region.output_contract(port).projection == RegionOutputProjection::kTensorView)
          return std::unexpected(Status::Internal("native graph output violated its memory projection contract"));
        return std::unexpected(Status::Unimplemented("native graph output has no memory view projection"));
      }
      const auto actual = value.tensor.storage().resource();
      const auto nominated = plan.storage_domains[plan.instance_storage[root]].resource;
      const auto &source = plan.targets[step.target.ordinal()].source;
      // Only the actual source can authorize a readonly export's distinct
      // owning resource. Coherence alone does not prove the storage family.
      if (value.tensor.description() != value.description ||
          !ExecutionSourceAccess::matches_read_resource(source, nominated, actual))
        return std::unexpected(Status::Internal("native output projection storage differs"));
      HYLE_RETURN_IF_ERROR(source.validate_resource(actual));
      HYLE_ASSIGN_OR_RETURN(auto bytes, output_description(state, instance).required_bytes());
      HYLE_ASSIGN_OR_RETURN(auto view, value.tensor.storage().subview(offset, bytes));
      return compute::ConstTensorView::create(output_description(state, instance), view);
    }
  }
  return std::unexpected(Status::Unimplemented("graph output has no memory storage projection"));
}

Result<compute::ReadLease> output_storage(InvocationState &state,
    std::uint32_t instance) noexcept {
  const auto &plan = *state.plan;
  auto root = instance;
  std::size_t offset = 0;
  while (plan.alias_sources[root] != kNoInPlaceSource) {
    const auto parent = plan.alias_sources[root];
    // Resolved memory views carry the actual specialized slice offset. Exact
    // plans may also project native-only aliases using their fixed offsets.
    std::size_t relative = plan.alias_offsets[root];
    if (state.readable[root].valid() && state.readable[parent].valid()) {
      const auto child_storage = state.readable[root].storage();
      const auto parent_storage = state.readable[parent].storage();
      if (child_storage.resource() != parent_storage.resource() ||
          child_storage.native_handle() != parent_storage.native_handle() ||
          child_storage.offset() < parent_storage.offset())
        return std::unexpected(Status::Internal("graph output alias has inconsistent storage"));
      relative = child_storage.offset() - parent_storage.offset();
    } else if (plan.domain_graph.valid()) {
      return std::unexpected(Status::Unimplemented(
          "native output alias has no resolved byte offset"));
    }
    if (relative > SIZE_MAX - offset)
      return std::unexpected(Status::Internal("graph output alias byte offset overflow"));
    offset += relative;
    root = parent;
  }
  if ((plan.instance_roles[root] & kGeneratedOutput) == 0) {
    if (!state.readable[instance].valid())
      return std::unexpected(Status::Unimplemented("graph output has no memory storage projection"));
    return output_storage(state, state.readable[instance]);
  }
  HYLE_ASSIGN_OR_RETURN(const auto bytes, output_description(state, instance).required_bytes());
  for (std::size_t index = 0; index < plan.steps.size(); ++index) {
    const auto &step = plan.steps[index];
    if (step.kind != PlanStepKind::kRegion) continue;
    for (std::size_t port = 0; port < step.output_count; ++port) {
      if (plan.node_outputs[step.output_begin + port] != root) continue;
      // This readonly projection borrows the original native slot retained by
      // GraphOutput. It performs no new admission, including after close.
      HYLE_ASSIGN_OR_RETURN(auto lease, state.invocations[index].region.output_lease(port));
      HYLE_ASSIGN_OR_RETURN(auto storage, lease.view());
      const auto nominated = plan.storage_domains[plan.instance_storage[root]].resource;
      const auto &source = plan.targets[step.target.ordinal()].source;
      if (!ExecutionSourceAccess::matches_read_resource(source, nominated, storage.resource()))
        return std::unexpected(Status::Internal("native output lease storage differs from its admitted source"));
      HYLE_RETURN_IF_ERROR(source.validate_resource(storage.resource()));
      return lease.subview(offset, bytes);
    }
  }
  return std::unexpected(Status::Internal("generated graph output has no native producer"));
}
} // namespace detail

GraphOutput::GraphOutput(detail::InvocationState *state,
    std::uint32_t instance) noexcept : state_(state), instance_(instance) {
  detail::retain(state_);
  state_->results.fetch_add(1, std::memory_order_relaxed);
}
GraphOutput::GraphOutput(const GraphOutput &other) noexcept
    : state_(other.state_), instance_(other.instance_) {
  if (state_) { detail::retain(state_); state_->results.fetch_add(1, std::memory_order_relaxed); }
}
GraphOutput &GraphOutput::operator=(const GraphOutput &other) noexcept {
  if (this != &other) { GraphOutput copy(other); *this = std::move(copy); }
  return *this;
}
GraphOutput::GraphOutput(GraphOutput &&other) noexcept
    : state_(std::exchange(other.state_, nullptr)),
      instance_(std::exchange(other.instance_, UINT32_MAX)) {}
GraphOutput &GraphOutput::operator=(GraphOutput &&other) noexcept {
  if (this != &other) {
    reset(); state_ = std::exchange(other.state_, nullptr);
    instance_ = std::exchange(other.instance_, UINT32_MAX);
  }
  return *this;
}
GraphOutput::~GraphOutput() { reset(); }
void GraphOutput::reset() noexcept {
  if (auto *state = std::exchange(state_, nullptr)) {
    state->results.fetch_sub(1, std::memory_order_release);
    detail::release(state);
  }
  instance_ = UINT32_MAX;
}
Result<compute::TensorDesc> GraphOutput::description() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph output is empty"));
  return detail::output_description(*state_, instance_);
}
Result<compute::ConstTensorView> GraphOutput::tensor() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph output is empty"));
  return detail::output_tensor(*state_, instance_);
}
Result<compute::ReadLease> GraphOutput::storage_lease() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph output is empty"));
  return detail::output_storage(*state_, instance_);
}

Status Invocation::prepare_resources(ResourceOptions options) noexcept {
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));
  if (!options.allocator.valid()) return Status::InvalidArgument("graph resource allocator is invalid");
  if (state_->resources) return Status::Ok();
  const auto actual = executable();
  const auto inputs = actual.input_count(), outputs = actual.output_count();
  if (inputs > UINT32_MAX - 1 || outputs > UINT32_MAX - 1 - inputs)
    return Status::ResourceExhausted("graph resource binding capacity");
  auto allocator = options.allocator;
  if (options.resource_budget.valid()) {
    HYLE_ASSIGN_OR_RETURN(allocator, options.resource_budget.metadata_allocator());
  }
  HYLE_ASSIGN_OR_RETURN(auto uses, compute::LeaseUsePool::create({.max_batches = 1,
      .max_resources_per_batch = static_cast<std::uint32_t>(inputs + outputs + 1),
      .allocator = allocator, .resource_budget = options.resource_budget}));
  auto *episode = allocator.construct<detail::ResourceEpisode>(allocator);
  if (!episode) return Status::ResourceExhausted("graph resource episode metadata");
  detail::ResourceEpisodeOwner candidate(episode);
  episode->uses = std::move(uses);
  try {
    episode->bindings.resize(inputs);
    episode->bindings.reserve(inputs + outputs);
    for (std::size_t i = 0; i < inputs; ++i) {
      HYLE_ASSIGN_OR_RETURN(episode->bindings[i].value, actual.input_id(i));
      episode->bindings[i].input = true;
    }
    for (std::size_t i = 0; i < outputs; ++i) {
      HYLE_ASSIGN_OR_RETURN(auto ownership, actual.output_ownership(i));
      if (ownership != OutputOwnership::kCaller) continue;
      HYLE_ASSIGN_OR_RETURN(auto value, actual.output_id(i));
      if (std::none_of(episode->bindings.begin(), episode->bindings.end(),
                       [&](const auto &binding) { return binding.value == value; }))
        episode->bindings.push_back({.value = value});
    }
    episode->fixed_binding_count = episode->bindings.size();
    if (episode->fixed_binding_count != 0) {
      episode->binding_slots.assign(state_->plan->descriptions.size(), UINT32_MAX);
      for (std::size_t slot = 0; slot < episode->fixed_binding_count; ++slot)
        episode->binding_slots[episode->bindings[slot].value.ordinal()] =
            static_cast<std::uint32_t>(slot);
    }
  } catch (...) { return Status::ResourceExhausted("graph fixed resource metadata"); }
  HYLE_RETURN_IF_ERROR(detail::prepare_submission_lifetime(*state_, allocator));
  state_->resources = std::move(candidate);
  return Status::Ok();
}
Status Invocation::bind(ValueId value, compute::TensorDesc description,
                        compute::ReadLease lease) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto *episode, detail::require_resources(state_));
  (void)episode;
  HYLE_RETURN_IF_ERROR(detail::check_binding_replacement(*state_, value));
  auto *binding = detail::find_binding(state_, value);
  if (!binding || !binding->input) return Status::InvalidArgument("read lease must bind a graph input");
  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));
  HYLE_RETURN_IF_ERROR(bind(value, tensor));
  binding = detail::find_binding(state_, value);
  binding->read = std::move(lease); binding->description = description;
  binding->exclusive = false; binding->permissionless = false; binding->borrowed = false;
  return Status::Ok();
}
Status Invocation::bind(ValueId value, compute::TensorDesc description,
                        compute::WriteLease &&lease) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto *episode, detail::require_resources(state_));
  (void)episode;
  HYLE_RETURN_IF_ERROR(detail::check_binding_replacement(*state_, value));
  auto *binding = detail::find_binding(state_, value);
  if (!binding) return Status::InvalidArgument("write lease must bind an external graph value");
  HYLE_ASSIGN_OR_RETURN(auto tensor, lease.tensor(description));
  HYLE_RETURN_IF_ERROR(bind(value, tensor));
  binding = detail::find_binding(state_, value);
  binding->write = std::move(lease); binding->description = description;
  binding->exclusive = true; binding->permissionless = false; binding->borrowed = false;
  return Status::Ok();
}
Result<detail::SubmissionCursor> detail::begin_submission(Invocation &invocation,
    std::span<const QueueBinding> queues, OrderedGraphSubmission ordered) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (!state->submission_lifetime)
    return std::unexpected(Status::FailedPrecondition("graph submission lifetime is not prepared"));
  auto *episode = state->resources.get();
  if (!ordered.valid())
    return std::unexpected(Status::InvalidArgument("ordered graph submission requires source owner, input qualification and mapping"));
  if (ordered.map && !episode)
    return std::unexpected(Status::FailedPrecondition("ordered graph submission requires prepared resources"));
  compute::LeaseUseBatch batch;
  if (episode) {
    for (auto &binding : episode->bindings) {
      if (binding.exclusive && binding.read.valid()) {
        HYLE_ASSIGN_OR_RETURN(binding.write, binding.read.try_write());
      }
    }
    HYLE_ASSIGN_OR_RETURN(auto admitted_batch, episode->uses.begin());
    batch = std::move(admitted_batch);
    auto &permissions = episode->permissions;
    permissions.reset();
    for (const auto &binding : episode->bindings) {
      if (binding.borrowed || binding.permissionless) continue;
      if (!binding.exclusive && !binding.read.valid() && binding.input &&
          ordered.pending_input && ordered.pending_input(ordered.owner, binding.value)) continue;
      if (permissions.enabled()) {
        HYLE_RETURN_IF_ERROR(binding.exclusive ? permissions.add(binding.write) : permissions.add(binding.read));
      } else {
        HYLE_RETURN_IF_ERROR(binding.exclusive ? batch.write(binding.write) : batch.read(binding.read));
      }
    }
    if (permissions.enabled()) HYLE_RETURN_IF_ERROR(permissions.admit(batch));
  }
  HYLE_ASSIGN_OR_RETURN(auto cursor, SubmissionCursor::begin(invocation, queues, false));
  if (episode) episode->batch = std::move(batch);
  const auto begun = begin_submission_lifetime(*state, ordered);
  if (!begun.ok()) {
    if (episode) { episode->batch = {}; episode->permissions.reset(); }
    cursor.reject_successors(begun);
    // No lifetime or native command was admitted. Close the cursor's original
    // phase/exclusion gate without entering its emergency abandonment path.
    auto rejected = cursor.finish();
    (void)rejected;
    return std::unexpected(begun);
  }
  begin_input_sources(*state);
  return cursor;
}

Result<compute::Completion> detail::finish_submission(InvocationState &state,
    SubmissionCursor &cursor) noexcept {
  record_submission_error(state, cursor.submission_error());
  auto completion = cursor.finish(true);
  const auto ordered = state.submission_lifetime.get()->ordered;
  if (!completion && ordered.map) {
    const auto error = completion.error();
    completion = ordered.map(ordered.owner, compute::Completion::completed(error));
    retain_submission_completion(&state, state.plan->segments.size(), *completion);
    return completion;
  }
  if (completion) {
    if (ordered.map) *completion = ordered.map(ordered.owner, std::move(*completion));
    retain_submission_completion(&state, state.plan->segments.size(), *completion);
  } else {
    record_submission_error(state, completion.error());
  }
  return completion;
}

Result<compute::Completion> detail::RegionAccess::submit(Invocation &invocation,
    std::span<const QueueBinding> queues, OrderedGraphSubmission ordered) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (state->progress) return state->progress.submit(invocation, queues, ordered);
  HYLE_ASSIGN_OR_RETURN(auto cursor, begin_submission(invocation, queues, ordered));
  const SharedSequenceFn before = ordered.admit ? &admit_submission_sequence : nullptr;
  while (!cursor.done()) {
    auto advanced = cursor.advance(true, &retain_submission_completion, state, before, state);
    if (!advanced) cursor.reject_successors(std::move(advanced).error());
  }
  if (cursor.submission_error().ok()) {
    const auto ready = wait_input_results(*state);
    if (!ready.ok()) cursor.reject_successors(ready);
  }
  auto completion = finish_submission(*state, cursor);
  finish_submission_lifetime(*state,
      completion ? Status::Ok() : Status{completion.error()});
  if (!completion) return std::unexpected(std::move(completion).error());
  return state->observation.publish(std::move(*completion), true);
}

Result<GraphOutput> Invocation::result(ValueId value) noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("graph invocation is empty"));
  if (state_->phase.load(std::memory_order_acquire) != detail::InvocationPhase::kIdle ||
      !state_->outputs_ready.load(std::memory_order_acquire))
    return std::unexpected(Status::FailedPrecondition(
        "graph outputs require a successful completed submission"));
  const auto &plan = *state_->plan;
  if (!value.valid() || detail::GraphIdentity::generation(value) != plan.generation ||
      value.ordinal() >= plan.descriptions.size())
    return std::unexpected(Status::InvalidArgument("value does not belong to this executable"));
  const auto role = plan.binding_roles[value.ordinal()];
  const auto expected = (role & detail::kExternalInput) != 0 ? ValueKind::kInput
      : ((role & detail::kConstant) != 0 ? ValueKind::kConstant : ValueKind::kNodeOutput);
  if (value.kind() != expected)
    return std::unexpected(Status::InvalidArgument("value does not belong to this executable"));
  if ((role & detail::kExternalOutput) == 0)
    return std::unexpected(Status::InvalidArgument("value is not a published graph output"));
  const auto instance = plan.external_instances[value.ordinal()];
  if (instance == detail::kNoWorkspaceRequest || instance >= plan.instance_values.size())
    return std::unexpected(Status::Internal("published graph output has no physical instance"));
  if (state_->resources) {
    for (auto &binding : state_->resources.get()->bindings) {
      if (binding.write.valid()) {
        HYLE_ASSIGN_OR_RETURN(binding.read, binding.write.publish());
      }
    }
  }
  return GraphOutput(state_, instance);
}
Status Invocation::close() noexcept {
  if (!state_) return Status::Ok();
  state_->closed = true;
  return in_flight() ? Status::Unavailable("graph invocation still has native work") : Status::Ok();
}
Status Invocation::drain() noexcept {
  if (!state_) return Status::Ok();
  close().IgnoreError();
  Status terminal;
  if (state_->progress) terminal = state_->progress.wait(*state_);
  // The slot's actual native guards can retire before the public observation's
  // callback tail returns. Joining progress alone must not publish drain early.
  terminal.Update(state_->observation.wait());
  auto phase = state_->phase.load(std::memory_order_acquire);
  while (phase == detail::InvocationPhase::kRunning) {
    state_->phase.wait(phase, std::memory_order_acquire);
    phase = state_->phase.load(std::memory_order_acquire);
  }
  terminal.Update(detail::submission_lifetime_status(*state_));
  return terminal;
}
} // namespace hyle::graph
