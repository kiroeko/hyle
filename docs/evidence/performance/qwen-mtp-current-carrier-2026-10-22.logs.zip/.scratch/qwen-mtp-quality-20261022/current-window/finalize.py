"""Add the final current-plan snapshot without replacing existing ZIP entries."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[2]
P=R/'docs/evidence/performance/qwen-mtp-current-carrier-2026-10-22.json'
Z=P.with_suffix('.logs.zip')
def ident(p):
    raw=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
d=json.loads(P.read_text(encoding='utf-8'))
assert 'final_document'not in d
final=S/'after-final/current-work.md';final.parent.mkdir()
final.write_bytes((R/'docs/developer/current-work.md').read_bytes())
with zipfile.ZipFile(Z,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
    for p in [final,Path(__file__).resolve()]:
        entry=str(p.relative_to(R)).replace('\\','/')
        assert entry not in archive.namelist()
        archive.write(p,entry);d['archive_files'].append(dict(**ident(p),entry=entry))
d['final_document']=ident(final)
d['images']={x:json.loads((S/f'{x}-ready.json').read_text())for x in ['hyle','peer']}
d['archive']=ident(Z)
d['publication_note']='Initial before/after snapshots remain intact. Final current-priority/table synchronization is a separately named archived document.'
P.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(manifest=ident(P),archive=ident(Z))))
