"""Publish the completed current four-arm window; never run inference."""
from pathlib import Path
import hashlib,json,re,zipfile
S=Path(__file__).resolve().parent;R=S.parents[2]
OLD=R/'.scratch/qwen-mtp-steady-profile-20261022/current-window'
DOC=R/'docs/developer/current-work.md'
OUT=R/'docs/evidence/performance/qwen-mtp-current-carrier-2026-10-22.json'
ZIP=OUT.with_suffix('.logs.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ident(p):
    p=p.resolve();raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert not OUT.exists()and not ZIP.exists()
t,m=read(S/'timing/summary.json'),read(S/'memory/summary.json')
assert t['processes']==12 and m['processes']==4
assert t['within_arm_fixed_work_valid']and m['within_arm_fixed_work_valid']
n,o=read(S/'timing/runs.json'),read(OLD/'timing/runs.json')
names={'hyle_plain':'Hyle普通','hyle_mtp':'Hyle MTP K1','peer_plain':'llama.cpp普通','peer_mtp':'llama.cpp MTP K1'}
capture={};comparison={}
for arm in names:
    old=next(x for x in o if x['arm']==arm)
    current=[x for x in n if x['arm']==arm]
    comparison[arm]=dict(all_current_IDs_equal_old=all(x['observation']['generated_ids']==old['observation']['generated_ids']for x in current),
        common_work_fields_equal=all(all(v==old['observation']['work'][k]for k,v in x['observation']['work'].items()
             if k in old['observation']['work'])for x in current))
    if arm.startswith('hyle'):
        rows=[]
        for x in [old,*current]:
            text=(Path(x['folder'])/'stderr.log').read_text(encoding='utf-8')
            rows.append(dict(source=ident(Path(x['folder'])/'stderr.log'),
                recorded=sum(map(int,re.findall(r'capture_recorded=(\d+)',text))),
                reused=sum(map(int,re.findall(r'capture_reused=(\d+)',text)))))
        capture[arm]=dict(old_first_process=rows[0],current_three_processes=rows[1:])
save(S/'capture-observation.json',dict(status='ACTUAL_LOG_COUNTS_NO_NEW_TRACE',capture=capture,
    old_to_current=comparison,limits=['Counts alone do not quantify exclusive re-recording cost or prove all wall-time loss is caused by it.']))
before=DOC.read_text(encoding='utf-8');(S/'before').mkdir(exist_ok=True)
(S/'before/current-work.md').write_text(before,encoding='utf-8')
G=t['groups'];B=m['groups']
def med(a,k):return G[a][k]['median']
def pct(a,b,k):return 100*(med(a,k)/med(b,k)-1)
def span(a,k):v=G[a][k];return f"{v['min']:.2f}～{v['max']:.2f}"
tail=['## 最新完整性能对比','',
 '**2026-10-22，当前串行单槽实现的完整四臂窗口。** Qwen3.5-2B、RTX 4070、全CUDA、BF16权重；相同P154提示词，自然greedy输出64枚、C1024／N1／R1，前缀缓存关闭。每臂3个新进程交错测速，另各1个独立进程旁采内存。当前Hyle及peer host镜像均重新冻结；不与旧窗口合并。','',
 '| 当前模式 | prefill tok/s | 完整decode tok/s | 综合输出 tok/s |','| --- | ---: | ---: | ---: |']
for a,name in names.items():tail.append(f"| {name} | {med(a,'prefill_tokens_per_second'):.2f} | {med(a,'full_decode_tokens_per_second'):.2f} | {med(a,'session_output_tokens_per_second'):.2f} |")
tail+=['',f"普通版Hyle相对参考prefill {pct('hyle_plain','peer_plain','prefill_tokens_per_second'):+.2f}%，decode {pct('hyle_plain','peer_plain','full_decode_tokens_per_second'):+.2f}%，综合 {pct('hyle_plain','peer_plain','session_output_tokens_per_second'):+.2f}%；MTP分别 {pct('hyle_mtp','peer_mtp','prefill_tokens_per_second'):+.2f}%／{pct('hyle_mtp','peer_mtp','full_decode_tokens_per_second'):+.2f}%／{pct('hyle_mtp','peer_mtp','session_output_tokens_per_second'):+.2f}%。综合为64输出／（完整prefill＋decode），不含加载；此窗是单轮，不冒充多轮或多人吞吐。",'',
 '| 当前模式 | prefill范围 tok/s | decode范围 tok/s | 加载s | 入口至ready s | 入口至末输出s |','| --- | ---: | ---: | ---: | ---: | ---: |']
for a,name in names.items():tail.append(f"| {name} | {span(a,'prefill_tokens_per_second')} | {span(a,'full_decode_tokens_per_second')} | {med(a,'weights_load_seconds'):.3f} | {med(a,'startup_to_ready_seconds'):.3f} | {med(a,'startup_to_endpoint_seconds'):.3f} |")
tail+=['','速度为3个独立进程比率的中位数，范围一并保留。decode计prefill后63枚新输出的完整host端点，不删准备／重录／等待。加载边界依消费者实现；入口不含OS装载DLL，末输出不含后续销毁，不将其称为同一加载算法的胜负。','',
 '| 当前模式 | GPU dedicated峰 GiB | GPU shared峰 MiB | 同采样GPU总峰 GiB | CPU WS峰 GiB | CPU private commit峰 GiB |','| --- | ---: | ---: | ---: | ---: | ---: |']
for a,name in names.items():
    p=B[a]['sampled_peaks'];tail.append(f"| {name} | {p['sampled_peak_gpu_dedicated_bytes']/2**30:.3f} | {p['sampled_peak_gpu_shared_bytes']/2**20:.2f} | {p['sampled_peak_gpu_total_bytes']/2**30:.3f} | {p['sampled_max_working_set_bytes']/2**30:.3f} | {p['sampled_max_private_commit_bytes']/2**30:.3f} |")
tail+=['','内存是独立Windows PSAPI／PDH旁采的观测峰，不是精确物理分配。dedicated与shared分列峰不可直接相加，总峰仅在同一有效采样点相加；CPU WS／commit／GPU shared也非互斥量。请求间隔10ms，实际间隔、阶段样本和基线是否可用逐臂保留在证据中；空值不填0。','',
 '**可比边界：** 各臂3次输出ID、实际工作及去计时后的轮次决策稳定；跨引擎普通／MTP两对仍从第19枚起分歧。Hyle中间BF16、末分数F32，peer原生中间算术／状态／草拟prefill及接受工作量仍不同，报告自然性能而非同token数学完全一致的胜负。两种MTP接受率不可假定相同。','',
 '**当前明确待修热点：频繁CUDA Graph重录。** 相比单槽前窗口，普通record／reuse由2／61变为63／0，MTP由18／50变为60／8，当前3次计时均重复该计数；四臂64ID及共同逻辑工作字段仍与旧窗一致。当前普通／MTP decode为72.57／96.90，旧窗90.95／112.27，而peer本窗95.71／126.59接近旧窗96.03／126.18。将这一回退与重录增多列为下一实际性能问题，不据计数宣称已证明全部耗时归因；不通过恢复Model双Invocation或放宽身份／寿命检查来掩盖问题。','',
 '[本轮12次计时、4次独立内存旁采、镜像／命令／原始数据及重录计数](../evidence/performance/qwen-mtp-current-carrier-2026-10-22.json)。此前[单槽前四臂窗口](../evidence/performance/qwen-mtp-steady-profile-2026-10-22.json)与[三轮共享缓存窗口](../evidence/performance/qwen-multiturn-current-2026-10-21.json)保留原工作量和边界，不混算。','']
after=before.split('## 最新完整性能对比')[0]+'\n'.join(tail)
overview=f"**最近完整四臂对照见[页末](#最新完整性能对比)**：当前普通版Hyle／llama.cpp prefill为{med('hyle_plain','prefill_tokens_per_second'):.2f}／{med('peer_plain','prefill_tokens_per_second'):.2f}tok/s，decode{med('hyle_plain','full_decode_tokens_per_second'):.2f}／{med('peer_plain','full_decode_tokens_per_second'):.2f}；MTP为{med('hyle_mtp','prefill_tokens_per_second'):.2f}／{med('peer_mtp','prefill_tokens_per_second'):.2f}、{med('hyle_mtp','full_decode_tokens_per_second'):.2f}／{med('peer_mtp','full_decode_tokens_per_second'):.2f}。各3次中位数，独立内存旁采另列。prefill仍领先，当前decode回退且Graph重录明显增多，下一步先修该热点；两对续文从第19枚起不同，不称同token严格差距。"
after=re.sub(r'\*\*最近完整四臂对照见.*?(?=\n)',lambda _:overview,after,count=1)
after=after.replace('单槽最终实现后做一次普通／MTP四臂完整速度与独立内存旁采。页末仍为改动前窗口，不以旧速度签当前版本。','当前单槽四臂完整速度及独立内存旁采已更新页末；频繁重录及decode回退是下一待修问题，修后再复测。')
DOC.write_text(after,encoding='utf-8')
(S/'after').mkdir(exist_ok=True);(S/'after/current-work.md').write_text(after,encoding='utf-8')
files=[]
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for p in sorted(S.rglob('*')):
        if p.is_file()and p.suffix.lower()in{'.json','.py','.log','.md','.csv'}:
            entry=str(p.relative_to(R)).replace('\\','/');z.write(p,entry);files.append(dict(**ident(p),entry=entry))
report=dict(date='2026-10-22',status='CURRENT_FOUR_ARM_TIMING_AND_SEPARATE_MEMORY_COMPLETE',
    full_goal_complete=False,timing=t,memory=m,capture_observation=read(S/'capture-observation.json'),
    current_vs_old_window=comparison,images={x:read(S/f'ready-{x}.json')for x in []},
    builds_in_this_window=0,native_timing_processes=12,independent_memory_processes=4,
    before_document=ident(S/'before/current-work.md'),after_document=ident(S/'after/current-work.md'),
    archive=ident(ZIP),archive_files=files,
    next_action='Fix frequent capture invalidation/re-recording while retaining serial carrier, actual range identity and native retirement; do not force bit equality for the separately classified8 QKV values.')
save(OUT,report)
print(json.dumps(dict(manifest=ident(OUT),archive=ident(ZIP)),ensure_ascii=False))
