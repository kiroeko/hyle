"""One reversed-order check of the small warm-decode difference."""
import importlib.util
from pathlib import Path
import statistics
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('finite_followup_rotation',S/'compare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,r=h.b,h.c,h.r
plan=c.read(S/'performance-prepared/plan.json')
for row in plan['frozen']+plan['peer_inputs']+list(plan['images'].values()):r.require_same(row)
out=S/'decode-followup';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
env,runtime=r.runtime_environment(c.read(plan['build_plan']['path']),c.read(r.PEER_PLAN),out)
c.save(out/'inputs.json',dict(plan=b.identity(S/'performance-prepared/plan.json'),
    reason='Nine-process window showed full31 +0.23% and warm -1.72%; check one reversed balanced order before adoption.',
    images=plan['images'],order=['current','baseline','baseline','current'],runtime=runtime,
    profiler=False,external_memory_monitor=False,compiles=0,links=0))
runs=[]
for index,arm in enumerate(('current','baseline','baseline','current'),10):
    original=next(row for row in plan['requests'] if row['arm']==arm)
    request=dict(arm=arm,tag=f'{index:02d}-{arm}',command=original['command'])
    process=r.execute(request['tag'],request['command'],env,out)
    observed=r.hyle_result(out,request,plan)
    runs.append(dict(arm=arm,tag=request['tag'],pid=process['pid'],exit=process['exit'],**observed))
    c.save(out/'runs.json',runs)
groups={arm:{key:dict(samples=[row['metrics'][key] for row in runs if row['arm']==arm],
    median=statistics.median(row['metrics'][key] for row in runs if row['arm']==arm)) for key in r.COMMON_METRICS} for arm in ('baseline','current')}
c.save(out/'summary.json',dict(executed=True,terminal_zero=len(runs),groups=groups,
    current_over_baseline={key:groups['current'][key]['median']/groups['baseline'][key]['median'] for key in r.COMMON_METRICS},
    same_predictions=all(row['same_baseline_predictions'] for row in runs),statistical_significance=False,
    scope='Separate four-process follow-up; retain the nine-process window unchanged, do not pool or replace samples.'))
print('FINITE_DECODE_FOLLOWUP_COMPLETE',flush=True)
