"""Archive the adopted family source, exact checks and separate timing windows."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(path):
    path=path.resolve();data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(row):return identity(Path(row['path']))==row
def interval(folder,first,last):
    zone=dt.timezone(dt.timedelta(hours=8))
    return dict(start=dt.datetime.fromtimestamp(read(folder/first)['started'],zone).isoformat(),
        finish=dt.datetime.fromtimestamp(read(folder/last)['finished'],zone).isoformat(),timezone='Asia/Shanghai')
def payload(path):
    rel=path.relative_to(S)
    if set(rel.parts)&{'tmp','__pycache__','documentation'}:return False
    if 'cleanup' in path.name or path.name in {'publication.json','payload-sha256.json'}:return False
    return path.suffix.lower() in {'.cc','.h','.py','.json','.diff','.log','.xml','.tsv','.ids','.md','.txt'}
def main():
    adopted=read(S/'adoption.json');assert adopted['compiled_product'] and exact(adopted['product']) and exact(adopted['candidate'])
    assert (ROOT/'tools/qwen35_text/main.cc').read_bytes()==(S/'candidate/main.cc').read_bytes()
    product=read(S/'product-checks/summary.json');assert product['passed'] and product['source_byte_identical_to_measured_candidate']
    numerical=read(S/'correctness/summary.json');continuation=read(S/'continuation-fixed/summary.json')
    assert numerical['passed'] and numerical['observation']['equal_vectors']==64 and numerical['single_outer_range_32_phases']
    assert continuation['passed'] and continuation['exact_vectors']==6 and continuation['no_hot_compile']
    rotation=read(S/'performance-rotation/summary.json');follow=read(S/'decode-followup/summary.json')
    assert rotation['terminal_zero']==9 and rotation['same_baseline_predictions_all9'] and not rotation['profiler']
    assert follow['terminal_zero']==4 and follow['same_predictions']
    for folder in ('checks','product-checks'):
        source=read(S/folder/'main-identity.json')
        for row in [source['source'],source['object'],*source['dependencies']]:assert exact(row),row['path']
        for row in read(S/folder/'qwen-link-plan.json')['inputs']:assert exact(row),row['path']
    for row in [adopted['product_image'],rotation['images']['baseline'],rotation['images']['current'],rotation['images']['llama']]:assert exact(row)
    docs=[]
    for rel in ('tools/qwen35_text/README.md','docs/developer/current-work.md'):
        path=ROOT/rel;snapshot=S/'documentation'/rel;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(path.read_bytes())
        docs.append(dict(relative=rel,current=identity(path),snapshot=identity(snapshot)))
    save(S/'documentation-freeze.json',docs)
    save(S/'adopted-source-review.json',dict(product=adopted['product'],candidate=adopted['candidate'],
        final_source_byte_identical=True,source_only_review='One Recipe/GraphBuilder and one finite compile site. prepare_child obtains public exact children/reports and original two slots. prepare performs lookup only. No repeated old concrete graph path or compatibility entry.',
        route_diagnostic='Only symbolic View uses OperationKind name; non-View preserves Operation descriptor names including custom operations.',
        original_independent_review=identity(S/'independent-review.json'),
        subsequent_name_preservation='The independent review first covered operation-kind-only source; the later final source restores descriptor names and was actually compiled and trace-run.'))
    dest=ROOT/'docs/evidence/performance/qwen-finite-family-2026-10-20.zip'
    files=sorted({*[p for p in S.rglob('*') if p.is_file() and payload(p)],*[Path(row['snapshot']['path']) for row in docs]},key=lambda p:p.relative_to(S).as_posix())
    rows=[]
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in files:
            row=dict(**identity(path),member=path.relative_to(S).as_posix());rows.append(row);archive.writestr(row['member'],path.read_bytes())
        archive.writestr('payload-sha256.json',json.dumps(rows,indent=2,ensure_ascii=False).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        for row in rows:assert hashlib.sha256(archive.read(row['member'])).hexdigest()==row['sha256']
    result=dict(date='2026-10-20',status='finite_family_consumer_adopted_and_executed',
        architecture='One model semantic Graph/schema, cold finite-exact family, actual immutable child/report, two original Invocation slots per child. L is bound; T=L+1 and convolution sample rows=T+3 derive in the shape program. No hot graph construction/padding/JIT/new executor/global cache.',
        adopted=adopted,exact_checks=dict(original_fixed128_plus31=numerical,continuation_scheduler23_4_1=continuation,
            original_unforced_EOS=read(S/'continuation/summary.json')),
        rotation_window=interval(S/'performance-rotation','01-baseline.result.json','09-baseline.result.json'),
        original_nine_process_window=rotation,
        followup_window=interval(S/'decode-followup','10-current.result.json','13-current.result.json'),separate_four_process_followup=follow,
        conclusion=dict(shape_prepare='Median0.335098→0.269408s (-19.60%); separate reversed-order0.347729→0.262430s (-24.53%).',
            TTFT='Median1.41675→1.35481s (-4.37%); separate1.448185→1.359485s (-6.12%).',
            decode='Full31 +0.23% / warm -1.72% in first window; reversed-order +0.88% / +2.49%. Small warm difference reverses; no stable decode gain or significance claimed.',
            peer='First-window finite Hyle/llama full31 91.11/95.35; warm93.92/97.00; prefill2016.14/1249.90 tokens/s. Do not pool with earlier windows.'),
        limits=['Windows RTX4070 only; no new Linux/macOS full-model run.',
            'No profiler or memory side sampling in timing windows; no new physical kernel count or full-model memory peak.',
            'Matching fixed tokens/hidden/logits are regression evidence, not independent model-quality acceptance.',
            'Hyle BF16/peer F32 intermediates and engine load/prepare sub-boundaries still differ. Full startup/TTFT is reported; OS file cache was not cleared.',
            'Finite-family compiled known storage retains unknown-provider counts; it is not total VRAM or evidence every native cold artifact was shared.',
            'No claim that one consumer completes eight-model/quant/provider coverage or the overall refactor.'],
        product_check=product,documentation=docs,
        archive=dict(**identity(dest),payloads=len(rows),CRC_checked=True,all_payload_SHA256_checked=True,
            vectors='Exact identity/metric records retained; duplicate raw vectors intentionally excluded. Canonical original64 and unique short baseline6 remain in the workspace.'))
    report=dest.with_suffix('.json');save(report,result)
    save(S/'publication.json',dict(report=identity(report),archive=identity(dest),payloads=len(rows),passed=True))
    print('FINITE_FAMILY_EVIDENCE_PUBLISHED',len(rows),dest.stat().st_size,flush=True)
if __name__=='__main__':main()
