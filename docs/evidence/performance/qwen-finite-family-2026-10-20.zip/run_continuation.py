"""Fresh old/new CUDA scheduler journey with original23/4/1 startup shapes."""
import importlib.util
import json
from pathlib import Path
import re
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('finite_continuation_helpers',A/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
def main():
    out=S/'continuation-fixed';out.mkdir(exist_ok=False)
    prior=S/'continuation/baseline'
    stopped=json.loads((prior/'qwen.stdout.log').read_text().splitlines()[-1])
    assert stopped['generated_ids']==[248046] and stopped['visible_tokens']==27
    c.save(S/'continuation/summary.json',dict(process_exit=0,checker_passed=False,
        reason='The existing consumer correctly stopped at EOS after continuation; the checker expected a decode step. Subsequent fixed-token test explicitly consumes the same EOS ID to exercise T1.',
        result=stopped,product_changed=False))
    forced=out/'decode.ids';forced.write_text(str(stopped['generated_ids'][0])+'\n')
    inputs=ROOT/'.scratch/inference-execution-refactor-2026-10-18/qwen35-text/inputs-v2'
    assert len((inputs/'prompt.ids').read_text().split())==23
    assert len((inputs/'continuation.ids').read_text().split())==4
    arms={
        'baseline':dict(image=c.read(A/'qwen-pinned-weight-load/product-checks/qwen-image.json'),
            link=c.read(A/'qwen-pinned-weight-load/product-checks/qwen-link-plan.json')),
        'current':dict(image=c.read(S/'checks/summary.json')['image'],link=c.read(S/'checks/qwen-link-plan.json'))}
    summaries={}
    for arm,data in arms.items():
        run=out/arm;run.mkdir();(run/'tmp').mkdir()
        assert b.same(data['image'])
        for row in data['link']['inputs']:assert b.same(row),row['path']
        command=[data['image']['path'],'--inputs',str(inputs),'--continuation',str(inputs/'continuation.ids'),
            '--steps','2','--decode-ids',str(forced),'--capacity','32','--progress','scheduler','--replay','prefer-capture',
            '--trace',str(run/'trace'),'--trace-level','decisions']
        c.save(run/'inputs.json',dict(image=data['image'],command=command,
            prompt=b.identity(inputs/'prompt.ids'),continuation=b.identity(inputs/'continuation.ids'),manifest=b.identity(inputs/'weights.tsv'),decode=b.identity(forced),
            throughput_claim=False,quality_acceptance=False))
        env,runtime=b.environment(data['link']['command'],[r['path'] for r in data['link']['inputs']],run)
        c.execute('qwen',command,env,run)
        result=json.loads((run/'qwen.stdout.log').read_text().splitlines()[-1])
        stderr=(run/'qwen.stderr.log').read_text()
        prepared=re.findall(r'^prepared T=(\d+) visible=(\d+) replay=(\w+).*?capture_recorded=(\d+) capture_reused=(\d+)$',stderr,re.M)
        vectors={p.relative_to(run/'trace').as_posix():b.identity(p) for p in sorted((run/'trace').rglob('*')) if p.suffix in ('.bf16','.f32')}
        assert len(vectors)==6,(arm,len(vectors))
        assert [int(r[0]) for r in prepared]==[23,4,1],prepared
        assert all(r[2]=='hybrid' and int(r[3])+int(r[4])==1 for r in prepared),prepared
        assert result['visible_tokens']==28 and len(result['generated_ids'])==2,result
        assert result['fixed_decode'] and result['decode_input_ids']==[248046],result
        assert 'progress=scheduler' in stderr
        if arm=='current':
            assert stderr.count('compile full text finite family variants=3')==1
            assert 'compile full text' not in stderr.split('initialized model_seconds=',1)[1]
        summaries[arm]=dict(result=result,prepared=prepared,vectors=vectors)
    old,new=summaries['baseline'],summaries['current']
    assert old['result']==new['result'],(old['result'],new['result'])
    assert old['vectors'].keys()==new['vectors'].keys()
    comparisons=[dict(path=path,baseline=old['vectors'][path],current=new['vectors'][path],
        equal=old['vectors'][path]['sha256']==new['vectors'][path]['sha256'] and old['vectors'][path]['bytes']==new['vectors'][path]['bytes']) for path in old['vectors']]
    assert all(row['equal'] for row in comparisons)
    c.save(out/'summary.json',dict(passed=True,actual_arms=summaries,comparisons=comparisons,exact_vectors=6,
        original_chunks=[23,4,1],progress='scheduler',replay='hybrid',no_hot_compile=True,
        candidate_one_finite_family_three_variants=True,throughput_claim=False,quality_acceptance=False))
    print('FINITE_CONTINUATION_SCHEDULER_EXACT6_GREEN',flush=True)
if __name__=='__main__':main()
