"""Adopt the measured finite-family consumer and check the actual product TU."""
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('finite_adoption_helpers',S.parent/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
def main():
    assert c.read(S/'correctness/summary.json')['passed'] and c.read(S/'continuation-fixed/summary.json')['passed']
    perf=c.read(S/'performance-rotation/summary.json');follow=c.read(S/'decode-followup/summary.json')
    assert perf['terminal_zero']==9 and perf['same_baseline_predictions_all9']
    assert follow['terminal_zero']==4 and follow['same_predictions']
    source=ROOT/'tools/qwen35_text/main.cc';candidate=S/'candidate/main.cc'
    assert source.read_bytes()==(S/'before/main.cc').read_bytes()
    built=c.read(S/'checks/summary.json');assert b.same(built['candidate']) and b.same(built['image'])
    assert built['candidate']==b.identity(candidate)
    source.write_bytes(candidate.read_bytes())
    assert source.read_bytes()==candidate.read_bytes()
    adoption=dict(before=b.identity(S/'before/main.cc'),candidate=b.identity(candidate),product=b.identity(source),
        source_byte_identical_to_measured_candidate=True,compiled_product=False,
        full64= b.identity(S/'correctness/summary.json'),continuation6=b.identity(S/'continuation-fixed/summary.json'),
        original_rotation=b.identity(S/'performance-rotation/summary.json'),separate_followup=b.identity(S/'decode-followup/summary.json'))
    c.save(S/'adoption.json',adoption)
    out=S/'product-checks';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    base=c.read(S/'checks/qwen-link-plan.json');recipe=c.read(S/'checks/main-identity.json')
    for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
    command=b.host_command(recipe['command'],source,'main',out)
    c.execute('main-compile',command,env,out)
    data=c.read(out/'main-deps.json')['Data'];obj=b.identity(out/'main.obj')
    c.save(out/'main-identity.json',dict(command=command,source=b.identity(source),object=obj,
        dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]))
    lookup={c.key(row['path']):row for row in base['inputs']};lookup[c.key(obj['path'])]=obj
    old=c.key(recipe['object']['path'])
    link=[obj['path'] if c.key(arg)==old else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    image=out/'qwen.exe';link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[lookup[c.key(arg)] for arg in link if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    for row in inputs:assert b.same(row)
    c.save(out/'qwen-link-plan.json',dict(command=link,inputs=inputs))
    c.execute('qwen-link',link,env,out);c.save(out/'qwen-image.json',b.identity(image))
    prepared=c.read(S/'performance-prepared/plan.json')
    run=next(row['command'] for row in prepared['requests'] if row['arm']=='current').copy();run[0]=str(image)
    c.execute('qwen',run,env,out)
    observed=json.loads((out/'qwen.stdout.log').read_text().splitlines()[-1])
    assert observed['generated_ids']==prepared['expected_baseline_ids']
    assert observed['decode_input_ids']==prepared['fixed']['decode_input_ids']
    assert observed['source_id']==prepared['source_id'] and source.read_bytes()==candidate.read_bytes()
    summary=dict(passed=True,host_TUs=1,native_TUs=0,SDK_rebuild=False,
        executed_product_source=b.identity(source),image=b.identity(image),fixed128_plus31=True,
        unchanged_predictions=True,source_byte_identical_to_measured_candidate=True,
        limits='Actual adopted-source build and one fixed128+31 smoke. Exact64/scheduler continuation and separate timing windows belong to the byte-identical scratch candidate; this smoke is not pooled into timing medians.')
    c.save(out/'summary.json',summary)
    adoption.update(compiled_product=True,product_check=b.identity(out/'summary.json'),product_image=b.identity(image))
    c.save(S/'adoption.json',adoption)
    print('FINITE_FAMILY_ADOPTED_AND_CHECKED',flush=True)
if __name__=='__main__':main()
