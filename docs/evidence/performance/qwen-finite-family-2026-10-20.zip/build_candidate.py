"""Compile only the scratch candidate main; relink certified retained owners. No GPU."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('qwen_finite_host_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'checks'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
paths = {
    'base':A/'qwen-pinned-weight-load/product-checks/qwen-link-plan.json',
    'batch':A/'batch-query-extent/checks/cuda-link-plan.json',
    'tail':A/'batch-output-tail/checks/cuda-link-plan.json',
}
plans = {kind:c.read(path) for kind,path in paths.items()}
metadata = h.metadata(plans)
recipe_path = A/'qwen-pinned-weight-load/product-checks/main-identity.json'
recipe = c.read(recipe_path)
freeze = c.read(S/'source-freeze.json')
candidate = S/'candidate/main.cc'
expected = next(row for row in freeze['files'] if row['path']=='candidate/main.cc')
assert h.same_identity(dict(expected,path=str(candidate))), 'Candidate differs from source freeze'
source = b.identity(candidate)
source_freeze = b.identity(S/'source-freeze.json')
main_command = b.host_command(recipe['command'], candidate, 'main', out)
source_owners = [
    ROOT/'src/compute_batch/batch_layout.cc',
    ROOT/'src/compute_batch/batch_execution.cc',
    ROOT/'src/graph_batch/native_batch_regions.cc',
    ROOT/'src/graph_batch/batch.cc',
    ROOT/'src/compute_provider_flashinfer/flashinfer_provider.cc',
]
replacements = {}
replacement_records = []
for selected_source in source_owners:
    arm = 'tail' if selected_source.name=='flashinfer_provider.cc' else 'batch'
    def matches(plan):
        return [row for row in plan['inputs'] if
            (record:=metadata.get(c.key(row['path']))) and
            c.key(record['source_path'])==c.key(selected_source)]
    old, fresh = matches(plans['base']), matches(plans[arm])
    assert len(old)==len(fresh)==1, (str(selected_source),old,fresh)
    record = metadata[c.key(fresh[0]['path'])]
    assert h.same_identity(record['source']), record['source']
    assert record['dependencies'], ('Missing retained dependencies',str(selected_source))
    assert all(h.same_identity(dep) for dep in record['dependencies']), str(selected_source)
    assert h.same_identity(fresh[0]), fresh[0]
    replacements[c.key(old[0]['path'])] = fresh[0]
    replacement_records.append(dict(source=b.identity(selected_source), old_object=old[0],
        actual_object=fresh[0], recipe=record['recipe'], command=record['command'],
        dependencies=record['dependencies']))
old_main = recipe['object']
assert sum(c.key(row['path'])==c.key(old_main['path']) for row in plans['base']['inputs'])==1
main_object_path = str(out/'main.obj')
for row in plans['base']['inputs']:
    assert h.same_identity(row), ('Base link input hash changed',row['path'])
for selected in replacement_records:
    assert h.same_identity(selected['actual_object'])
# Only old main and the five explicitly identified source owners change.
command = []
for arg in plans['base']['command']:
    if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):
        continue
    if c.key(arg)==c.key(old_main['path']):
        command.append(main_object_path)
    elif c.key(arg) in replacements:
        command.append(replacements[c.key(arg)]['path'])
    else:
        command.append(arg)
image = out/'qwen-finite-family.exe'
command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
lookup={c.key(row['path']):row for row in plans['base']['inputs']}
lookup.update({c.key(row['path']):row for row in replacements.values()})
base_inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and
    Path(arg).suffix.lower() in ('.obj','.lib') and c.key(arg)!=c.key(main_object_path)]
assert len(base_inputs)==len(plans['base']['inputs'])-1
for row in base_inputs:
    assert h.same_identity(row), ('Selected link input hash changed',row['path'])
plan = dict(candidate=source, source_freeze=source_freeze, main_recipe=str(recipe_path),
    base_plans={kind:dict(path=str(path),identity=b.identity(path)) for kind,path in paths.items()},
    compile=[dict(command=main_command, source=source, object=main_object_path)],
    retained_inputs=base_inputs, replacements=replacement_records,
    link_command=command, image=str(image), host_TUs=1, native_TUs=0, SDK_rebuild=False,
    product_consumer_changed=False, GPU_run=False,
    input_freshness='Every retained base and chosen replacement input hash checked. Five selected source owners also verified source plus complete retained dependency identities. Other cached native/SDK owners are reused as requested; not recompiled.')
c.save(out/'plan.json',plan)
print('PLAN',out/'plan.json','host_TUs=1 replacements=5 retained_inputs='+str(len(base_inputs)),flush=True)
if '--build' not in sys.argv:
    raise SystemExit(0)
env,runtime=b.environment(main_command,[row['path'] for row in base_inputs],out)
env['PYTHONDONTWRITEBYTECODE']='1'
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],LIB=env.get('LIB'),INCLUDE=env.get('INCLUDE'),runtime=runtime))
# Resolve the original unqualified Windows system link libraries against actual
# retained LIB search paths, recording hashes without changing link semantics.
relative=[]
for arg in command:
    if arg.lower().endswith('.lib') and not arg.startswith('/') and not Path(arg).is_absolute():
        found=next((Path(folder)/arg for folder in env.get('LIB','').split(';') if (Path(folder)/arg).is_file()),None)
        if found is None:
            raise RuntimeError('Original system link library not found in LIB: '+arg)
        relative.append(dict(argument=arg,identity=b.identity(found)))
c.save(out/'system-link-libraries.json',relative)
def frozen():
    assert h.same_identity(source)
    assert h.same_identity(source_freeze)
    for row in base_inputs:
        assert h.same_identity(row),row['path']
    for row in relative:
        assert h.same_identity(row['identity']),row['argument']
try:
    frozen()
    result=c.execute('main-compile',main_command,env,out)
    frozen()
    deps=c.read(out/'main-deps.json')['Data']
    identities=[b.identity(path) for path in dict.fromkeys([deps['Source'],*deps['Includes']])]
    main_object=b.identity(main_object_path)
    receipt=dict(command=main_command,source=source,object=main_object,
        dependencies=identities,source_dependencies=b.identity(out/'main-deps.json'),
        recipe=str(recipe_path),result=result)
    c.save(out/'main-identity.json',receipt)
    lookup[c.key(main_object_path)]=main_object
    inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
    for row in inputs:assert h.same_identity(row),row['path']
    c.save(out/'qwen-link-plan.json',dict(command=command,inputs=inputs))
    result=c.execute('qwen-link',command,env,out)
    frozen()
    assert all(h.same_identity(row) for row in identities)
    c.save(out/'qwen-image.json',dict(**b.identity(image),link_result=result,candidate=source))
    c.save(out/'summary.json',dict(passed=True,host_TUs=1,native_TUs=0,links=1,
        GPU_run=False,SDK_rebuild=False,product_consumer_changed=False,candidate=source,image=b.identity(image)))
    print('QWEN_FINITE_FAMILY_HOST_BUILT',image,flush=True)
except Exception as error:
    c.save(out/'summary.json',dict(passed=False,error=repr(error),host_TUs=1,native_TUs=0,
        GPU_run=False,SDK_rebuild=False,product_consumer_changed=False,candidate=source))
    raise
