// Independent text consumer. All candidate tensor mathematics uses public
// Compute/Graph operations; no native API, provider choice or oracle feedback.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <initializer_list>
#include <limits>
#include <map>
#include <memory>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/cuda_file_stream.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/cuda.h"
#include "hyle/graph/progress.h"
#include "hyle/mem/buffer.h"
#include "hyle/io/file.h"
#include "hyle/io/io_context.h"
#include "hyle/sched/join.h"
#include "hyle/sched/blocking.h"
#include "hyle/sched/scheduler.h"

namespace qwen35 {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace mem = hyle::mem;
using V = g::ValueId;
using D = g::Dimension;
constexpr D f(std::int64_t value) noexcept { return D::fixed(value); }
using Type = c::DataType;
constexpr std::int64_t hidden = 2048, intermediate = 6144, vocabulary = 248320;
constexpr char source_id[] = "4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155";
using Clock = std::chrono::steady_clock;
constexpr bool is_end_of_generation(std::int32_t token) noexcept {
  return token == 248044 || token == 248046; // Original endoftext and tokenizer im_end.
}
constexpr std::array<const char *, 9> layer0_probe_names{
    "01-gdn-output", "02-out-proj-input", "03-out-proj-output",
    "04-down-proj-input", "05-layer-output", "06-post-attn-residual",
    "07-post-attn-norm", "08-gate-proj-output", "09-up-proj-output"};

void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
c::TensorDesc dense(Type type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, std::span(shape.begin(), shape.size())));
}
struct Tensor final {
  c::TensorDesc description;
  mem::Buffer buffer;
  c::ReadLease ready;
  Tensor() = default;
  Tensor(mem::MemoryResourceRef resource, c::TensorDesc desc)
      : description(desc), buffer(take(mem::Buffer::create(resource,
            take(desc.required_bytes()), 256))) {}
  c::TensorView view() { return take(c::TensorView::create(description, buffer.view())); }
  c::ConstTensorView read() {
    return ready ? take(ready.tensor(description)) : view().as_const();
  }
  void freeze(const c::StorageOwner &owner) {
    if (!ready) ready = take(owner.adopt_buffer(std::move(buffer)));
  }
  void zero() { check(buffer.view().fill(std::byte{})); }
  template<class T> void write(std::span<const T> values) {
    check(buffer.view().write(std::as_bytes(values)));
  }
  void dump(const std::filesystem::path &path) {
    std::vector<std::byte> bytes(buffer.size());
    check(buffer.view().read(bytes));
    std::ofstream output(path, std::ios::binary);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!output) throw std::runtime_error("cannot write trace: " + path.string());
  }
};
struct State final {
  std::array<Tensor, 2> history, recurrent;
  Tensor key, value;
};
struct Recipe final {
  g::GraphBuilder builder = take(g::GraphBuilder::create());
  std::vector<g::TensorSpec> specs;
  std::vector<g::ConstantBinding> constants;
  std::map<std::string, V> weights;
  std::map<std::string, Tensor> &bank;
  std::vector<Tensor> literals;
  mem::MemoryResourceRef resource;
  c::StorageOwner owner;
  g::DimensionId last_row;
  D token_rows, sample_rows;
  Recipe(std::map<std::string, Tensor> &selected, c::StorageOwner r,
         std::size_t max_query_rows)
      : bank(selected), resource(r.ref()), owner(std::move(r)) {
    // L is a zero-based last-token position, independently bound at startup.
    // T=L+1 avoids subtraction or a second independent (possibly inconsistent)
    // shape binding. All other numeric axes remain fixed model dimensions.
    last_row = take(builder.dimension({0, static_cast<std::int64_t>(max_query_rows - 1), 1}));
    token_rows = D(take(builder.dimension_sum(D(last_row), f(1))));
    sample_rows = D(take(builder.dimension_sum(token_rows, f(3))));
  }
  static g::TensorSpec dense_spec(Type type, std::span<const D> dimensions) {
    return take(g::TensorSpec::dense(type, dimensions));
  }
  static g::TensorSpec dense_spec(Type type, std::initializer_list<D> dimensions) {
    return dense_spec(type, std::span(dimensions.begin(), dimensions.size()));
  }
  const g::TensorSpec &spec(V value) const { return specs.at(value.ordinal()); }
  V remember(V value, g::TensorSpec description) {
    if (specs.size() <= value.ordinal()) specs.resize(value.ordinal() + 1);
    specs[value.ordinal()] = description;
    return value;
  }
  V input(g::TensorSpec description) { return remember(take(builder.input(description)), description); }
  V input(c::TensorDesc description) { return input(take(g::TensorSpec::concrete(description))); }
  V constant(Tensor &tensor) {
    const auto value = remember(take(builder.constant(tensor.description)),
                                take(g::TensorSpec::concrete(tensor.description)));
    tensor.freeze(owner);
    constants.push_back({value, tensor.read(), g::ConstantPolicy::kBorrow,
                         owner, tensor.ready});
    return value;
  }
  V weight(const std::string &name) {
    auto found = weights.find(name);
    if (found != weights.end()) return found->second;
    const auto value = constant(bank.at("model.language_model." + name));
    weights.emplace(name, value);
    return value;
  }
  V scalar(float value, Type type = Type::kFloat32) {
    literals.emplace_back(resource, dense(type, {1}));
    if (type == Type::kFloat32) literals.back().write<float>(std::span(&value, 1));
    else {
      auto bits = std::bit_cast<std::uint32_t>(value);
      bits += 0x7fffU + ((bits >> 16) & 1U);
      const auto bf16 = static_cast<std::uint16_t>(bits >> 16);
      literals.back().write<std::uint16_t>(std::span(&bf16, 1));
    }
    return constant(literals.back());
  }
  std::vector<V> op(c::Operation operation, std::initializer_list<V> arguments,
                    std::initializer_list<g::TensorSpec> outputs,
                    g::NodeId *node_id = nullptr) {
    const auto node = take(builder.add_node(operation,
        std::span(arguments.begin(), arguments.size()),
        std::span(outputs.begin(), outputs.size())));
    if (node_id) *node_id = node;
    std::vector<V> result;
    std::size_t index = 0;
    for (const auto &output : outputs)
      result.push_back(remember(take(builder.result(node, index++)), output));
    return result;
  }
  // Only concrete constant transforms use the Compute-only inference shortcut.
  // Symbolic operations declare their real logical outputs; each exact child
  // still runs the authoritative Compute inference during Graph compilation.
  std::vector<V> op(c::Operation operation, std::initializer_list<V> arguments) {
    std::vector<c::TensorDesc> in;
    for (auto value : arguments) in.push_back(take(spec(value).concrete_description()));
    std::vector<c::TensorDesc> out(c::operation_traits(operation).outputs);
    check(c::infer_output_descriptions(operation, in, out));
    const auto node = take(builder.add_node(operation, std::span(arguments.begin(), arguments.size())));
    std::vector<V> result;
    for (std::size_t i = 0; i < out.size(); ++i)
      result.push_back(remember(take(builder.result(node, i)), take(g::TensorSpec::concrete(out[i]))));
    return result;
  }
  template<class O> V one(O operation, std::initializer_list<V> arguments) {
    return op(c::Operation(operation), arguments).at(0);
  }
  template<class O> V one(O operation, std::initializer_list<V> arguments,
                          g::TensorSpec output, g::NodeId *node_id = nullptr) {
    return op(c::Operation(operation), arguments, {output}, node_id).at(0);
  }
  template<class O> V same(O operation, std::initializer_list<V> arguments, V source) {
    return one(operation, arguments, dense_spec(spec(source).data_type(), spec(source).dimensions()));
  }
  V cast(V x, Type type) {
    return spec(x).data_type() == type ? x :
        one(c::Cast{type}, {x}, dense_spec(type, spec(x).dimensions()));
  }
  V unary(c::UnaryKind kind, V x) { return same(c::Unary{kind}, {x}, x); }
  V binary(c::BinaryKind kind, V x, V y) {
    const auto left = spec(x), right = spec(y);
    if (left.data_type() != right.data_type()) throw std::runtime_error("binary dtype mismatch");
    const auto rank = std::max(left.rank(), right.rank());
    std::vector<D> dimensions(rank, f(1));
    for (std::size_t axis = 0; axis < rank; ++axis) {
      const auto a = axis + left.rank() < rank ? f(1) : left.dimensions()[axis + left.rank() - rank];
      const auto b = axis + right.rank() < rank ? f(1) : right.dimensions()[axis + right.rank() - rank];
      if (a == b || b == f(1)) dimensions[axis] = a;
      else if (a == f(1)) dimensions[axis] = b;
      else dimensions[axis] = D(take(builder.dimension_broadcast(a, b)));
    }
    return one(c::Binary{kind}, {x, y}, dense_spec(left.data_type(), dimensions));
  }
  V reshape(V x, std::initializer_list<D> dimensions) {
    // A fixed constant may still need the original stride-chunk Copy. Dynamic
    // views preserve inference and receive explicit Copy only where the actual
    // model layout requires it (the self-attention interleaved gate below).
    bool fixed = true;
    std::vector<std::int64_t> concrete;
    for (auto dimension : dimensions) {
      fixed = fixed && dimension.is_fixed();
      concrete.push_back(dimension.fixed_value());
    }
    if (auto input = spec(x).concrete_description(); input && fixed) {
      auto view = take(c::View::reshape(take(c::TensorShape::create(concrete))));
      auto inferred = c::infer_single_output(c::Operation(view), std::array{*input});
      if (!inferred && inferred.error().IsUnimplemented()) x = copy(x);
    }
    const auto view = take(g::ViewSpec::reshape(std::span(dimensions.begin(), dimensions.size())));
    const auto output = take(builder.add(view, x));
    return remember(output, take(g::TensorSpec::inferred(spec(x).data_type(),
        std::span(dimensions.begin(), dimensions.size()), spec(x).storage_format())));
  }
  V copy(V x) { return same(c::Copy{}, {x}, x); }
  V slice(V x, int axis, D first, D count) {
    const auto source = spec(x);
    std::vector<D> dimensions(source.dimensions().begin(), source.dimensions().end());
    dimensions.at(static_cast<std::size_t>(axis)) = count;
    const auto output = take(builder.add(take(g::ViewSpec::slice(axis, first, count)), x));
    return remember(output, take(g::TensorSpec::inferred(source.data_type(), dimensions,
                                                       source.storage_format())));
  }
  V linear(V x, const std::string &name) {
    constexpr std::array<std::int32_t, 2> axes{1, 0};
    const auto original = weight(name);
    auto dimensions = std::vector<D>(spec(x).dimensions().begin(), spec(x).dimensions().end());
    dimensions.back() = spec(original).dimensions()[0];
    auto w = one(take(c::View::permute(axes)), {original});
    return one(c::MatMul{}, {x, w}, dense_spec(spec(x).data_type(), dimensions));
  }
  V norm(V x, const std::string &name) {
    const auto type = spec(x).data_type();
    auto scale = binary(c::BinaryKind::kAdd, cast(weight(name), Type::kFloat32), scalar(1));
    const auto converted = cast(x, Type::kFloat32);
    return cast(same(c::RmsNorm{.epsilon = 1.e-6F}, {converted, scale}, converted), type);
  }
  // Literal BF16 boundaries from the independent local reference, including
  // BF16 square/sum/epsilon/rsqrt. GDN applies its own 1/sqrt(128) exactly once.
  V l2(V x) {
    const auto square = binary(c::BinaryKind::kMultiply, x, x);
    const std::array<std::int32_t, 1> axes{-1};
    auto dimensions = std::vector<D>(spec(square).dimensions().begin(), spec(square).dimensions().end());
    dimensions.back() = f(1);
    auto sum = one(c::Reduce{.kind = c::ReductionKind::kSum,
        .axes = take(c::Axes::from(axes)), .keep_dimensions = true,
        .accumulation_type = Type::kFloat32}, {square}, dense_spec(spec(square).data_type(), dimensions));
    sum = binary(c::BinaryKind::kAdd, sum, scalar(1.e-6F, Type::kBFloat16));
    return binary(c::BinaryKind::kMultiply, x, unary(c::UnaryKind::kRsqrt, sum));
  }
  V ffn(V x, const std::string &prefix, std::span<V> probes = {}) {
    auto normalized = norm(x, prefix + "post_attention_layernorm.weight");
    auto projected_gate = linear(normalized, prefix + "mlp.gate_proj.weight");
    auto gate = unary(c::UnaryKind::kSilu, projected_gate);
    auto up = linear(normalized, prefix + "mlp.up_proj.weight");
    auto product = binary(c::BinaryKind::kMultiply, gate, up);
    if (!probes.empty()) {
      probes[3] = product; probes[5] = x; probes[6] = normalized;
      probes[7] = projected_gate; probes[8] = up;
    }
    auto result = linear(product, prefix + "mlp.down_proj.weight");
    return binary(c::BinaryKind::kAdd, x, result);
  }
  void publish(V value) { check(builder.publish(value)); }
};

struct Ports final {
  V history, recurrent, next_history, next_recurrent, key, value, next_key, next_value;
};
struct FamilyPorts {
  V token_port, position_port, metadata_port, logits_port, id_port, hidden_port;
  std::array<g::NodeId, 6> attention_nodes;
  std::array<V, 9> probe_ports;
  std::array<Ports, 24> layers;
};
struct Family final : FamilyPorts {
  std::vector<Tensor> literals; // Backing survives every child and its slots.
  std::vector<g::TensorSpec> specs;
  c::BatchSchema attention_schema;
  g::Graph graph;
  g::CompiledGraph compiled;
  g::DimensionId last_row;
  std::vector<std::size_t> chunks;
};
struct Phase final : FamilyPorts {
  c::BatchSchema attention_schema;
  c::BatchLayoutVersion attention_layout;
  // These are owning handles to the actual selected finite child, never the
  // parent's empty route. They expose its true output/resource contracts.
  g::CompiledGraph compiled;
  std::array<g::Invocation, 2> slots;
  Tensor tokens, positions, logits, next_id, final_hidden;
  std::array<Tensor, 9> probe_outputs;
  std::array<bool, 9> probe_caller{};
};

// Each original device allocation becomes one retained lease pool;
// bounded pinned staging is the only extra payload storage.
struct WeightSourceFile final {
  hyle::io::File file;
  std::uint64_t capacity = 0;
};
hyle::sched::Task<hyle::Result<WeightSourceFile>> open_weight_source(
    mem::AllocatorRef, hyle::io::IoContext *io, std::string path) {
  auto opened = co_await hyle::io::open_file(*io, 0, path,
      {.access = hyle::io::FileAccess::kRead});
  if (!opened) co_return std::unexpected(std::move(opened).error());
  auto file = std::move(*opened);
  auto information = co_await file.info();
  if (!information) co_return std::unexpected(std::move(information).error());
  if (!information->is_regular())
    co_return std::unexpected(hyle::Status::InvalidArgument("checkpoint is not a regular file"));
  co_return WeightSourceFile{std::move(file), information->size};
}
hyle::sched::Task<hyle::Status> close_weight_source(
    mem::AllocatorRef, hyle::io::File *file) {
  co_return co_await file->close();
}
struct WeightLoadReport final {
  std::size_t bytes = 0;
  c::FileStreamReport stream;
};
WeightLoadReport load_weight_bank(const std::filesystem::path &manifest,
    const c::StorageOwner &memory, mem::MemoryResourceRef staging, c::Queue &queue,
    const c::Context &context, std::map<std::string, Tensor> &weights,
    std::vector<c::LeasePool> &weight_pools) {
  std::ifstream input(manifest);
  std::string signature, shard, identity;
  std::getline(input, signature); std::getline(input, shard); std::getline(input, identity);
  if (signature != "HYLE_QWEN35_TEXT_V1" || identity != source_id)
    throw std::runtime_error("unidentified local weight manifest");

  auto scheduler_status = hyle::Status::Ok();
  hyle::sched::Scheduler loader_scheduler(2, mem::system_allocator(), 256,
                                        &scheduler_status);
  check(scheduler_status);
  hyle::io::IoContext io(loader_scheduler, {.max_blocking_threads = 2});
  struct Shutdown final {
    hyle::sched::Scheduler &scheduler;
    ~Shutdown() { scheduler.shutdown(); }
  } shutdown{loader_scheduler}; // IO's hooks outlive the stopped workers.
  check(io.status());
  auto open_task = open_weight_source(mem::system_allocator(), &io, shard);
  if (!open_task.valid()) throw std::runtime_error("cannot allocate weight open task");
  auto source_file = take(take(hyle::sched::spawn_task_on(loader_scheduler, 0,
      mem::system_allocator(), std::move(open_task)).join()));
  // Borrow this stable File so the actual async close can be observed explicitly
  // after pipeline retirement, before any loader runtime leaves this function.
  auto source = take(c::StreamFile::borrow(source_file.file, source_file.capacity));
  std::vector<c::StreamReadRange> ranges;
  std::vector<std::string> names;
  ranges.reserve(320); names.reserve(320); weight_pools.reserve(320);
  std::size_t bytes = 0, largest = 0;
  std::string line;
  while (std::getline(input, line)) {
    std::istringstream fields(line);
    std::string name, type; std::size_t rank = 0, offset = 0, count = 0;
    fields >> name >> type >> rank;
    if (rank == 0 || rank > c::kMaxTensorRank || (type != "BF16" && type != "F32"))
      throw std::runtime_error("invalid manifest tensor");
    std::vector<std::int64_t> dimensions(rank);
    for (auto &dimension : dimensions) fields >> dimension;
    fields >> offset >> count;
    auto desc = take(c::TensorDesc::dense(type == "BF16" ? Type::kBFloat16 : Type::kFloat32, dimensions));
    if (!fields || take(desc.required_bytes()) != count)
      throw std::runtime_error("manifest tensor extent differs");
    if (offset > source_file.capacity || count > source_file.capacity - offset)
      throw std::runtime_error("short checkpoint tensor: " + name);
    if (count > (std::numeric_limits<std::size_t>::max)() - bytes)
      throw std::runtime_error("text weight byte inventory overflows");
    Tensor tensor(memory.ref(), desc); // Same320 original device allocations.
    auto pool = take(c::LeasePool::adopt(std::move(tensor.buffer), {.max_blocks = 1}));
    auto writer = take(pool.allocate(count));
    ranges.push_back({.file_offset = offset, .destination = std::move(writer),
        .bytes = count, .description = desc});
    weight_pools.push_back(std::move(pool)); // Admission stays open for Graph reads.
    if (!weights.emplace(name, std::move(tensor)).second)
      throw std::runtime_error("duplicate weight");
    names.push_back(std::move(name)); bytes += count; largest = (std::max)(largest, count);
  }
  if (weights.size() != 320 || bytes != 3763655360ULL)
    throw std::runtime_error("text weight inventory differs");
  std::vector<c::StreamReadGroup> groups;
  groups.reserve(ranges.size());
  for (std::size_t i = 0; i < ranges.size(); ++i)
    groups.push_back({i, std::span(ranges).subspan(i, 1)});
  constexpr std::size_t staging_per_slot = 8u * 1024u * 1024u;
  constexpr std::uint32_t slots = 2;
  if (bytes > (std::numeric_limits<std::size_t>::max)() - slots * staging_per_slot)
    throw std::runtime_error("weight loader backing capacity overflows");
  const std::array targets{c::CopyResourceSpec{memory.ref(), largest}};
  auto pipeline = take(c::cuda::create_file_pipeline(io, context, queue, staging, targets,
      {.max_requests = 1, .max_groups_per_request = 320, .max_ranges_per_group = 1,
       .in_flight_slots = slots, .staging_bytes_per_slot = staging_per_slot,
       .max_active_backing_bytes = bytes + slots * staging_per_slot}));
  struct Drain final {
    c::FileResourcePipeline &pipeline;
    ~Drain() { pipeline.drain().IgnoreError(); }
  } drain{pipeline};
  auto ticket = take(pipeline.read(c::StreamSource::file(source), groups));
  std::vector<bool> delivered(groups.size(), false);
  for (std::size_t count = 0; count < groups.size(); ++count) {
    auto group = take(ticket.wait_next_ready());
    if (group.tag() >= names.size() || group.range_count() != 1)
      throw std::runtime_error("weight stream returned an unexpected group");
    const auto index = static_cast<std::size_t>(group.tag());
    if (delivered[index]) throw std::runtime_error("weight stream returned a duplicate group");
    auto ready = take(group.output(0));
    if (ready.size() != ranges[index].bytes)
      throw std::runtime_error("weight stream returned an incomplete tensor");
    weights.at(names[index]).ready = std::move(ready);
    delivered[index] = true;
  }
  const auto result = ticket.wait();
  check(result.status);
  if (!result.complete || !result.retirement_proven || result.read_bytes != bytes ||
      result.copied_bytes != bytes || result.ready_groups != groups.size())
    throw std::runtime_error("weight stream byte inventory or retirement differs");
  ticket = {};
  check(pipeline.drain());
  const auto report = pipeline.report();
  pipeline = {}; // Drop fixed staging, native slots and internal source owners now.
  source.reset();
  auto close_task = close_weight_source(mem::system_allocator(), &source_file.file);
  if (!close_task.valid()) throw std::runtime_error("cannot allocate weight close task");
  check(take(hyle::sched::spawn_task_on(loader_scheduler, 0,
      mem::system_allocator(), std::move(close_task)).join()));
  input.close();
  // Returning destroys the temporary Scheduler/IoContext and joins their actual
  // workers. The constructor's original weight/TTFT timers still surround all of it.
  return {bytes, report};
}

class Model final {
public:
  c::Context context = take(g::cuda::create_context());
  c::StorageOwner memory = take(c::StorageOwner::adopt(context,
      take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice))));
  c::cuda::MemoryResource planning_memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  c::Queue queue = take(context.create_queue());
  // These original runtimes outlive every phase/slot and its native retirement.
  std::unique_ptr<hyle::sched::Scheduler> scheduler;
  std::unique_ptr<hyle::sched::BlockingPool> workers;
  std::vector<c::LeasePool> weight_pools; // Retain original allocations through all Graph uses.
  std::map<std::string, Tensor> weights;
  std::array<State, 24> state;
  // Family owners precede slots: slots and child handles die before literals.
  std::unique_ptr<Family> family, probe_family;
  std::map<std::size_t, std::unique_ptr<Phase>> phases;
  std::map<std::size_t, std::unique_ptr<Phase>> probe_phases;
  std::size_t capacity, length = 0, parity = 0;
  g::ReplayMode replay_mode = g::ReplayMode::kCommands;
  bool failed = false;
  std::filesystem::path layer0_probe, trace_routes;
  explicit Model(const std::filesystem::path &manifest, std::size_t selected_capacity,
                 std::filesystem::path probe = {}, bool progress = false,
                 g::ReplayMode replay = g::ReplayMode::kCommands)
      : capacity(selected_capacity), replay_mode(replay), layer0_probe(std::move(probe)) {
    if (capacity == 0 || capacity > 262144) throw std::runtime_error("capacity outside model context limit");
    if (progress) {
      auto status = hyle::Status::Ok();
      scheduler = std::make_unique<hyle::sched::Scheduler>(1, mem::system_allocator(), 64, &status);
      check(status);
      workers = std::make_unique<hyle::sched::BlockingPool>(mem::system_allocator(), 1,
                                                          std::chrono::seconds(10), &status);
      check(status);
    }
    const auto weight_load_start = Clock::now();
    const auto loading = load_weight_bank(manifest, memory, planning_memory.ref(), queue,
                                         context, weights, weight_pools);
    const auto weight_load_seconds = std::chrono::duration<double>(Clock::now() - weight_load_start).count();
    std::cerr << "resident text weights: " << weights.size() << " tensors, " << loading.bytes << " bytes\n";
    std::cerr << "weights_load_seconds=" << weight_load_seconds << '\n';
    std::cerr << "pinned_weight_loader staging_bytes=" << loading.stream.staging_bytes
              << " io_calls=" << loading.stream.io_calls
              << " native_calls=" << loading.stream.native_calls
              << " native_waits=" << loading.stream.native_waits
              << " host_waits=" << loading.stream.host_waits
              << " phase_completions=" << loading.stream.phase_completions
              << " copied_physical_bytes=" << loading.stream.copied_physical_bytes
              << " peak_backing_bytes=" << loading.stream.peak_backing_bytes << '\n';
    for (std::size_t i = 0; i < state.size(); ++i) {
      auto &layer = state[i];
      if (i % 4 == 3) {
        layer.key = Tensor(memory.ref(), dense(Type::kBFloat16, {static_cast<std::int64_t>(capacity), 512}));
        layer.value = Tensor(memory.ref(), layer.key.description);
        layer.key.zero(); layer.value.zero();
      } else {
        for (std::size_t slot = 0; slot < 2; ++slot) {
          layer.history[slot] = Tensor(memory.ref(), dense(Type::kBFloat16, {1, 3, 6144}));
          layer.recurrent[slot] = Tensor(memory.ref(), dense(Type::kFloat32, {1, 16, 128, 128}));
          layer.history[slot].zero(); layer.recurrent[slot].zero();
        }
      }
    }
  }

  ~Model() {
    // Success and exception teardown join actual slots before releasing either
    // the runtimes or the borrowed model/state buffers. Scheduler idleness alone
    // does not establish native retirement or completion-observer return.
    for (auto *cache : {&phases, &probe_phases})
      for (auto &[tokens, phase] : *cache) {
        (void)tokens;
        for (auto &run : phase->slots) run.drain().IgnoreError();
      }
    if (workers) workers->shutdown();
    if (scheduler) scheduler->drain();
  }

  static c::TensorDesc output_description(const g::CompileReport &report, V value) {
    c::TensorDesc description;
    bool found = false;
    for (std::size_t index = 0; index < report.physical_value_count(); ++index) {
      const auto physical = take(report.physical_value(index));
      if (physical.value != value || !physical.external_output) continue;
      if (found && description != physical.description)
        throw std::runtime_error("output has incompatible physical domain descriptions");
      description = physical.description;
      found = true;
    }
    if (!found) throw std::runtime_error("compiled child has no physical output description");
    return description;
  }

  void prepare_family(std::span<const std::size_t> known_chunks, bool diagnostic = false) {
    auto &selected = diagnostic ? probe_family : family;
    if (selected) throw std::runtime_error("text finite family was already prepared");
    if (known_chunks.empty()) throw std::runtime_error("text finite family requires known nonempty chunks");
    auto result = std::make_unique<Family>();
    auto &definition = *result;
    for (const auto tokens : known_chunks) {
      if (tokens == 0 || tokens > capacity)
        throw std::runtime_error("finite text chunk outside nonempty context capacity");
      if (std::find(definition.chunks.begin(), definition.chunks.end(), tokens) == definition.chunks.end())
        definition.chunks.push_back(tokens);
    }
    const auto start = Clock::now();
    const auto max_query_rows = *std::max_element(definition.chunks.begin(), definition.chunks.end());
    const auto cap = static_cast<std::int64_t>(capacity);
    Recipe r(weights, memory, max_query_rows);
    const auto t = r.token_rows;
    definition.last_row = r.last_row;
    const auto cache_storage = take(c::CacheStorage::plain(Type::kBFloat16));
    definition.attention_schema = take(c::BatchSchema::create({
        .storage = c::BatchStorage::kRagged, .query_type = Type::kBFloat16,
        .output_type = Type::kBFloat16, .key_storage = cache_storage, .value_storage = cache_storage,
        .max_requests = 1, .max_query_rows = static_cast<std::uint32_t>(max_query_rows),
        .max_kv_rows = static_cast<std::uint32_t>(capacity), .max_pages = 0, .max_page_refs = 0,
        .query_heads = 8, .kv_heads = 2, .qk_head_dim = 256, .value_head_dim = 256, .page_size = 1}));
    definition.token_port = r.input(r.dense_spec(Type::kInt32, {t}));
    definition.position_port = r.input(r.dense_spec(Type::kInt32, {t}));
    definition.metadata_port = r.input(take(definition.attention_schema.metadata_description()));
    auto x = r.one(c::Gather{.bounds = c::IndexBoundsPolicy::kUnchecked},
        {r.weight("embed_tokens.weight"), definition.token_port}, r.dense_spec(Type::kBFloat16, {t, f(hidden)}));
    std::array<float, 32> frequency{};
    for (std::size_t i = 0; i < frequency.size(); ++i) frequency[i] = 1.F / std::pow(10000000.F, float(i) / 32.F);
    r.literals.emplace_back(memory.ref(), dense(Type::kFloat32, {32}));
    r.literals.back().write<float>(frequency);
    const auto frequencies = r.constant(r.literals.back());
    for (std::size_t i = 0; i < state.size(); ++i) {
      const auto prefix = "layers." + std::to_string(i) + ".";
      auto normalized = r.norm(x, prefix + "input_layernorm.weight");
      auto &ports = definition.layers[i];
      V mixed;
      if (i % 4 != 3) {
        ports.history = r.input(state[i].history[0].description);
        ports.recurrent = r.input(state[i].recurrent[0].description);
        auto qkv = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_qkv.weight"), {f(1), t, f(6144)});
        auto samples = r.one(c::Concat{.axis = 1}, {ports.history, qkv},
            r.dense_spec(Type::kBFloat16, {f(1), r.sample_rows, f(6144)}));
        // Published state uses caller-owned ping-pong storage.
        ports.next_history = r.copy(r.slice(samples, 1, t, f(3)));
        auto convolution = r.one(c::model_ops::causal_conv1d(), {r.cast(samples, Type::kFloat32),
            r.cast(r.reshape(r.weight(prefix + "linear_attn.conv1d.weight"), {f(6144), f(4)}), Type::kFloat32)},
            r.dense_spec(Type::kFloat32, {f(1), t, f(6144)}));
        auto activated = r.unary(c::UnaryKind::kSilu, r.cast(convolution, Type::kBFloat16));
        auto q = r.reshape(r.slice(activated, 2, f(0), f(2048)), {f(1), t, f(16), f(128)});
        auto k = r.reshape(r.slice(activated, 2, f(2048), f(2048)), {f(1), t, f(16), f(128)});
        auto v = r.reshape(r.slice(activated, 2, f(4096), f(2048)), {f(1), t, f(16), f(128)});
        auto a = r.reshape(r.cast(r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32), {f(1), t, f(16), f(1)});
        auto b = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"), {f(1), t, f(16), f(1)});
        auto dt = r.reshape(r.cast(r.weight(prefix + "linear_attn.dt_bias"), Type::kFloat32), {f(1), f(1), f(16), f(1)});
        auto decay = r.reshape(r.unary(c::UnaryKind::kNeg,
            r.unary(c::UnaryKind::kExp, r.weight(prefix + "linear_attn.A_log"))), {f(1), f(1), f(16), f(1)});
        auto g = r.binary(c::BinaryKind::kMultiply, decay,
            r.unary(c::UnaryKind::kSoftplus, r.binary(c::BinaryKind::kAdd, a, dt)));
        auto beta = r.cast(r.unary(c::UnaryKind::kSigmoid, b), Type::kFloat32);
        auto recurrent = r.op(c::Operation(c::GatedDeltaNet{}),
            {r.cast(r.l2(q), Type::kFloat32), r.cast(r.l2(k), Type::kFloat32),
             r.cast(v, Type::kFloat32), g, beta, ports.recurrent},
            {r.dense_spec(Type::kFloat32, {f(1), t, f(16), f(128)}),
             take(g::TensorSpec::concrete(state[i].recurrent[0].description))});
        ports.next_recurrent = recurrent[1];
        auto y = r.cast(recurrent[0], Type::kBFloat16);
        if (i == 0) definition.probe_ports[0] = y;
        const auto y_f32 = r.cast(y, Type::kFloat32);
        y = r.cast(r.same(c::RmsNorm{.epsilon = 1.e-6F}, {y_f32}, y_f32), Type::kBFloat16);
        // The original checkpoint keeps this scale F32. Torch promotes the
        // rounded BF16 normalized value before multiplying it by that scale.
        y = r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32), r.weight(prefix + "linear_attn.norm.weight"));
        auto z = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_z.weight"), {f(1), t, f(16), f(128)});
        y = r.cast(r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32),
            r.unary(c::UnaryKind::kSilu, r.cast(z, Type::kFloat32))), Type::kBFloat16);
        auto projection_input = r.reshape(y, {t, f(hidden)});
        if (i == 0) definition.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.
        mixed = r.linear(projection_input, prefix + "linear_attn.out_proj.weight");
        if (i == 0) definition.probe_ports[2] = mixed;
        r.publish(ports.next_history); r.publish(ports.next_recurrent);
      } else {
        ports.key = r.input(state[i].key.description);
        ports.value = r.input(state[i].value.description);
        auto projected = r.reshape(r.linear(normalized, prefix + "self_attn.q_proj.weight"), {f(1), t, f(8), f(512)});
        auto q = r.norm(r.slice(projected, 3, f(0), f(256)), prefix + "self_attn.q_norm.weight");
        auto gate = r.reshape(r.copy(r.slice(projected, 3, f(256), f(256))), {t, f(hidden)});
        auto k = r.norm(r.reshape(r.linear(normalized, prefix + "self_attn.k_proj.weight"), {f(1), t, f(2), f(256)}), prefix + "self_attn.k_norm.weight");
        auto v = r.linear(normalized, prefix + "self_attn.v_proj.weight");
        const c::RoPE rope{.rotary_dimensions = 64, .sequence_axis = 1, .layout = c::RopeLayout::kHalfSplit};
        q = r.same(rope, {q, definition.position_port, frequencies}, q);
        k = r.same(rope, {k, definition.position_port, frequencies}, k);
        ports.next_key = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.key, definition.position_port, r.reshape(k, {t, f(512)})},
            take(g::TensorSpec::concrete(state[i].key.description)));
        ports.next_value = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.value, definition.position_port, v},
            take(g::TensorSpec::concrete(state[i].value.description)));
        auto attention = r.one(c::Operation::custom(c::RaggedAttention{
            .capacity = definition.attention_schema.capacity(), .scale = 0.0625F, .causal = true}),
            {r.reshape(q, {t, f(8), f(256)}), r.reshape(ports.next_key, {f(cap), f(2), f(256)}),
             r.reshape(ports.next_value, {f(cap), f(2), f(256)}), definition.metadata_port},
            r.dense_spec(Type::kBFloat16, {t, f(8), f(256)}), &definition.attention_nodes[i / 4]);
        auto gated = r.binary(c::BinaryKind::kMultiply, r.reshape(attention, {t, f(hidden)}), r.unary(c::UnaryKind::kSigmoid, gate));
        mixed = r.linear(gated, prefix + "self_attn.o_proj.weight");
        r.publish(ports.next_key); r.publish(ports.next_value);
      }
      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix,
                i == 0 ? std::span<V>(definition.probe_ports) : std::span<V>{});
      if (i == 0) definition.probe_ports[4] = x;
    }
    if (diagnostic) for (std::size_t i = 0; i < definition.probe_ports.size(); ++i) {
      r.publish(definition.probe_ports[i]);
      auto description = r.spec(definition.probe_ports[i]);
      if (description.data_type() != Type::kBFloat16) throw std::runtime_error("layer0 diagnostic boundary is not BF16");
    }
    // This published result is bound to the caller's fixed final_hidden buffer.
    auto last = r.copy(r.slice(r.norm(x, "norm.weight"), 0, D(r.last_row), f(1)));
    definition.hidden_port = last;
    definition.logits_port = r.cast(r.linear(last, "embed_tokens.weight"), Type::kFloat32);
    definition.id_port = r.op(c::Operation(c::TopK{.count = 1}), {definition.logits_port},
        {r.dense_spec(Type::kFloat32, {f(1), f(1)}), r.dense_spec(Type::kInt32, {f(1), f(1)})})[1];
    for (auto value : {definition.hidden_port, definition.logits_port, definition.id_port}) r.publish(value);
    definition.graph = take(std::move(r.builder).finish());
    definition.literals = std::move(r.literals);
    definition.specs = std::move(r.specs);
    std::vector<std::array<g::ShapeBinding, 1>> bindings;
    bindings.reserve(definition.chunks.size());
    for (const auto tokens : definition.chunks)
      bindings.push_back({g::ShapeBinding{definition.last_row, static_cast<std::int64_t>(tokens - 1)}});
    std::vector<g::ExactShapeVariant> variants;
    variants.reserve(bindings.size());
    for (const auto &point : bindings) variants.push_back({point});
    std::cerr << "compile full text finite family variants=" << variants.size()
              << " max_query_rows=" << max_query_rows << " nodes=" << definition.graph.node_count() << '\n';
    definition.compiled = take(g::cuda::compile(definition.graph, context, memory,
        {.shape_policy = g::CompileShapePolicy::kFiniteExact,
         .exact_variants = variants, .constants = r.constants}));
    const auto storage = definition.compiled.report.total_compiled_storage();
    std::cerr << "compiled text finite family variants=" << definition.compiled.report.exact_variant_count()
              << " compiled_known_bytes=" << storage.known_bytes()
              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " cold_seconds=" << std::chrono::duration<double>(Clock::now() - start).count() << '\n';
    selected = std::move(result);
    // Materialize each requested child's original two slots before inference.
    // Probe-only route comparison retains the original compile-only behavior.
    for (const auto tokens : selected->chunks) prepare_child(tokens, diagnostic);
  }

  Phase &prepare_child(std::size_t tokens, bool diagnostic) {
    auto &cache = diagnostic ? probe_phases : phases;
    const auto found = cache.find(tokens);
    if (found != cache.end()) return *found->second;
    auto &selected = diagnostic ? probe_family : family;
    if (!selected) throw std::runtime_error("text finite family has not been prepared");
    auto &definition = *selected;
    const auto point = std::find(definition.chunks.begin(), definition.chunks.end(), tokens);
    if (point == definition.chunks.end()) throw std::runtime_error("unlisted text chunk has no prepared exact child");
    const auto start = Clock::now();
    const auto index = static_cast<std::size_t>(point - definition.chunks.begin());
    auto result = std::make_unique<Phase>();
    auto &phase = *result;
    static_cast<FamilyPorts &>(phase) = static_cast<const FamilyPorts &>(definition);
    phase.attention_schema = definition.attention_schema;
    phase.compiled.executable = take(definition.compiled.executable.exact_variant(index));
    phase.compiled.report = take(definition.compiled.report.exact_variant(index));
    const auto t = static_cast<std::int64_t>(tokens);
    phase.tokens = Tensor(memory.ref(), dense(Type::kInt32, {t}));
    phase.positions = Tensor(memory.ref(), phase.tokens.description);
    phase.logits = Tensor(memory.ref(), output_description(phase.compiled.report, phase.logits_port));
    phase.next_id = Tensor(memory.ref(), output_description(phase.compiled.report, phase.id_port));
    phase.final_hidden = Tensor(memory.ref(), output_description(phase.compiled.report, phase.hidden_port));
    if (diagnostic) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
      for (std::size_t output = 0; output < phase.compiled.executable.output_count(); ++output) {
        if (take(phase.compiled.executable.output_id(output)) != phase.probe_ports[i]) continue;
        phase.probe_caller[i] = take(phase.compiled.executable.output_ownership(output)) == g::OutputOwnership::kCaller;
        if (phase.probe_caller[i]) phase.probe_outputs[i] =
            Tensor(memory.ref(), output_description(phase.compiled.report, phase.probe_ports[i]));
      }
    }
    const auto &route_directory = layer0_probe.empty() ? trace_routes : layer0_probe;
    if (!route_directory.empty()) {
      std::filesystem::create_directories(route_directory);
      const auto label = diagnostic ? "published" : "default";
      std::ofstream route(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".route.tsv"));
      route << "step\tkind\tprovider\timplementation\tnodes\n";
      for (std::size_t step = 0; step < phase.compiled.report.step_count(); ++step) {
        const auto detail = take(phase.compiled.report.step(step));
        route << step << '\t' << static_cast<unsigned>(detail.kind) << '\t' << detail.provider.name
              << '\t' << detail.implementation.value() << '\t';
        for (std::size_t n = 0; n < detail.node_count; ++n) {
          const auto node = take(phase.compiled.report.step_node(step, n));
          route << (n ? "," : "") << node.ordinal() << ':'
                << c::operation_name(take(definition.graph.operation(node)));
        }
        route << '\n';
      }
      std::ofstream boundaries(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".boundaries.tsv"));
      boundaries << "point\tvalue\tproducer\tshape\n";
      const auto signature = phase.compiled.executable.specialization();
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        const auto value = phase.probe_ports[i];
        boundaries << layer0_probe_names[i] << '\t' << value.ordinal() << '\t'
                   << take(definition.graph.producer(value)).ordinal() << '\t';
        for (const auto dimension : definition.specs.at(value.ordinal()).dimensions()) {
          if (dimension.is_fixed()) { boundaries << dimension.fixed_value() << ','; continue; }
          bool resolved = false;
          for (std::size_t binding = 0; binding < signature.binding_count(); ++binding) {
            const auto entry = take(signature.binding(binding));
            if (entry.dimension != dimension.symbol()) continue;
            boundaries << entry.value << ',';
            resolved = true;
            break;
          }
          if (!resolved) throw std::runtime_error("exact child diagnostic dimension is unresolved");
        }
        boundaries << '\n';
      }
      if (!route || !boundaries) throw std::runtime_error("cannot write layer0 route diagnostics");
    }
    if (layer0_probe.empty() || diagnostic) for (std::size_t slot = 0; slot < 2; ++slot) {
      // Bind through the family to retain the actual public finite-selection
      // path. The returned slot's executable/report is the exact child above.
      const std::array shape{g::ShapeBinding{definition.last_row, static_cast<std::int64_t>(tokens - 1)}};
      phase.slots[slot] = take(definition.compiled.executable.create_invocation({.shape = shape}));
      if (phase.slots[slot].exact_variant_index() != index)
        throw std::runtime_error("finite family selected an unexpected exact child");
      if (scheduler) check(g::prepare_progress(phase.slots[slot], *scheduler, *workers));
    }
    const auto storage = phase.compiled.report.compiled_storage();
    std::cerr << "compiled T=" << tokens << " steps=" << phase.compiled.report.step_count()
              << " workspace/slot=" << phase.compiled.executable.workspace_bytes()
              << " compiled_known_bytes=" << storage.known_bytes()
              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " child_prepare_seconds=" << std::chrono::duration<double>(Clock::now() - start).count() << '\n';
    auto *address = result.get(); cache.emplace(tokens, std::move(result)); return *address;
  }

  Phase &prepare(std::size_t tokens, bool diagnostic = false) {
    // Inference only selects precompiled, eagerly prepared finite children.
    // No provider search, graph rebuilding, padding or lazy slot/JIT cache.
    auto &cache = diagnostic ? probe_phases : phases;
    const auto found = cache.find(tokens);
    if (found == cache.end()) throw std::runtime_error("unlisted text chunk has no prepared exact child");
    return *found->second;
  }

  std::int32_t evaluate(std::span<const std::int32_t> ids, const std::string &name,
                        const std::filesystem::path &trace = {}, bool trace_states = true) {
    if (failed) throw std::runtime_error("request state was invalidated by a previous failure");
    if (ids.empty() || ids.size() > capacity - length) throw std::runtime_error("nonempty block exceeds remaining context capacity");
    for (auto id : ids) if (id < 0 || id >= vocabulary) throw std::runtime_error("token ID outside vocabulary");
    if (!layer0_probe.empty()) prepare(ids.size()); // Compile-only route comparison; never execute the default graph here.
    auto &phase = prepare(ids.size(), !layer0_probe.empty());
    const auto step_start = Clock::now();
    std::vector<std::int32_t> positions(ids.size());
    for (std::size_t row = 0; row < ids.size(); ++row) {
      positions[row] = static_cast<std::int32_t>(length + row);
    }
    phase.tokens.write<std::int32_t>(ids); phase.positions.write<std::int32_t>(positions);
    const auto cold_start = Clock::now();
    Clock::time_point start;
    double submit_seconds = 0;
    double cold_batch_seconds = 0;
    g::ReplayRoute replay_route = g::ReplayRoute::kUnprepared;
    std::size_t capture_recorded = 0, capture_reused = 0;
    try {
      const std::array<std::int32_t, 2> query_indptr{0, static_cast<std::int32_t>(ids.size())};
      const std::array<std::int32_t, 2> kv_indptr{0, static_cast<std::int32_t>(length + ids.size())};
      phase.attention_layout = take(phase.attention_schema.version({query_indptr, kv_indptr, {}, {}}));
      std::array<g::batch::NodeLayout, 6> layouts;
      for (std::size_t i = 0; i < layouts.size(); ++i) layouts[i] = {phase.attention_nodes[i], phase.attention_layout};
      const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};
      auto &run = phase.slots[parity];
      check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));
      check(run.bind(phase.token_port, phase.tokens.read()));
      check(run.bind(phase.position_port, phase.positions.read()));
      check(run.bind(phase.logits_port, phase.logits.view()));
      check(run.bind(phase.id_port, phase.next_id.view()));
      check(run.bind(phase.hidden_port, phase.final_hidden.view()));
      if (!layer0_probe.empty()) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i)
        if (phase.probe_caller[i]) check(run.bind(phase.probe_ports[i], phase.probe_outputs[i].view()));
      for (std::size_t i = 0; i < state.size(); ++i) {
        auto &p = phase.layers[i]; auto &s = state[i];
        if (i % 4 == 3) {
          check(run.bind(p.key, s.key.read())); check(run.bind(p.value, s.value.read()));
          check(run.bind(p.next_key, s.key.view())); check(run.bind(p.next_value, s.value.view()));
        } else {
          check(run.bind(p.history, s.history[parity].read()));
          check(run.bind(p.recurrent, s.recurrent[parity].read()));
          check(run.bind(p.next_history, s.history[1 - parity].view()));
          check(run.bind(p.next_recurrent, s.recurrent[1 - parity].view()));
        }
      }
      check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));
      replay_route = run.replay_route();
      const auto replay_report = take(run.replay_report());
      capture_recorded = replay_report.recorded_capture_range_count;
      capture_reused = replay_report.reused_capture_range_count;
      cold_batch_seconds = std::chrono::duration<double>(Clock::now() - cold_start).count();
      start = Clock::now();
      auto done = take(run.submit(queues));
      submit_seconds = std::chrono::duration<double>(Clock::now() - start).count();
      check(done.wait());
    } catch (...) { failed = true; throw; }
    length += ids.size(); parity = 1 - parity;
    std::int32_t next = 0;
    check(phase.next_id.buffer.view().read(std::as_writable_bytes(std::span(&next, 1))));
    const auto finished = Clock::now();
    std::cerr << "prepared T=" << ids.size() << " visible=" << length
              << " replay=" << (replay_route == g::ReplayRoute::kCaptured ? "captured"
                  : replay_route == g::ReplayRoute::kHybrid ? "hybrid" : "commands")
              << " cold_batch_seconds=" << cold_batch_seconds
              << " capture_recorded=" << capture_recorded
              << " capture_reused=" << capture_reused << '\n';
    std::cerr << name << " tokens=" << ids.size() << " visible=" << length
              << " seconds=" << std::chrono::duration<double>(finished - start).count()
              << " submit_seconds=" << submit_seconds
              << " step_seconds=" << std::chrono::duration<double>(finished - step_start).count()
              << " progress=" << (scheduler ? "scheduler" : "direct")
              << " next=" << next << '\n';
    if (!trace.empty()) {
      std::filesystem::create_directories(trace / name);
      phase.logits.dump(trace / name / "logits.f32"); phase.final_hidden.dump(trace / name / "hidden.bf16");
      if (trace_states) for (std::size_t layer = 0; layer < state.size(); ++layer) {
        auto &s = state[layer]; const auto prefix = "layer" + std::to_string(layer);
        if (layer % 4 == 3) {
          s.key.dump(trace / name / (prefix + ".key.bf16")); s.value.dump(trace / name / (prefix + ".value.bf16"));
        } else {
          s.history[parity].dump(trace / name / (prefix + ".conv.bf16"));
          s.recurrent[parity].dump(trace / name / (prefix + ".gdn.f32"));
        }
      }
    }
    if (!layer0_probe.empty()) {
      std::filesystem::create_directories(layer0_probe / name);
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        auto output = take(phase.slots[1 - parity].output(phase.probe_ports[i]));
        std::vector<std::byte> bytes(take(output.description().required_bytes()));
        check(output.storage().read(bytes));
        std::ofstream stream(layer0_probe / name / (std::string(layer0_probe_names[i]) + ".bf16"), std::ios::binary);
        stream.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!stream) throw std::runtime_error("cannot write layer0 probe output");
      }
    }
    return next;
  }
};

std::vector<std::int32_t> read_ids(const std::filesystem::path &path) {
  std::ifstream stream(path); if (!stream) throw std::runtime_error("cannot open token IDs");
  std::vector<std::int32_t> ids; std::int64_t value = 0;
  while (stream >> value) {
    if (value < 0 || value >= vocabulary) throw std::runtime_error("input token outside vocabulary");
    ids.push_back(static_cast<std::int32_t>(value));
  }
  if (!stream.eof()) throw std::runtime_error("malformed input IDs");
  return ids;
}
} // namespace qwen35

int main(int argc, char **argv) {
  const auto startup = qwen35::Clock::now();
  try {
    std::filesystem::path input, continuation, trace, layer0_probe, decode_ids;
    std::size_t steps = 4, capacity = 128;
    bool progress = false, trace_states = true, explicit_steps = false;
    auto replay = qwen35::g::ReplayMode::kCommands;
    for (int i = 1; i < argc; ++i) {
      const std::string option = argv[i];
      if (i + 1 >= argc) throw std::runtime_error("option needs a value");
      const std::string value = argv[++i];
      if (option == "--inputs") input = value;
      else if (option == "--continuation") continuation = value;
      else if (option == "--trace") trace = value;
      else if (option == "--trace-level") {
        if (value != "full" && value != "decisions")
          throw std::runtime_error("--trace-level requires full or decisions");
        trace_states = value == "full";
      }
      else if (option == "--decode-ids") decode_ids = value;
      else if (option == "--layer0-probe") layer0_probe = value;
      else if (option == "--steps") { steps = std::stoull(value); explicit_steps = true; }
      else if (option == "--capacity") capacity = std::stoull(value);
      else if (option == "--progress") {
        if (value != "direct" && value != "scheduler")
          throw std::runtime_error("--progress requires direct or scheduler");
        progress = value == "scheduler";
      }
      else if (option == "--replay") {
        if (value != "commands" && value != "prefer-capture")
          throw std::runtime_error("--replay requires commands or prefer-capture");
        replay = value == "prefer-capture" ? qwen35::g::ReplayMode::kPreferCapture
                                           : qwen35::g::ReplayMode::kCommands;
      }
      else throw std::runtime_error("unknown option: " + option);
    }
    const auto forced = decode_ids.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(decode_ids);
    if (!decode_ids.empty()) {
      if (forced.empty()) throw std::runtime_error("--decode-ids requires a nonempty token tape");
      if (explicit_steps && steps != forced.size() + 1)
        throw std::runtime_error("--steps must equal decode input count plus one");
      steps = forced.size() + 1;
    }
    if (input.empty() || steps == 0 || steps > 128)
      throw std::runtime_error("usage: hyle_qwen35_text --inputs DIR [--continuation IDS] [--steps 4 | --decode-ids IDS] [--capacity 128] [--progress direct|scheduler] [--replay commands|prefer-capture] [--trace DIR] [--trace-level full|decisions] [--layer0-probe DIR]");
    const auto prompt = qwen35::read_ids(input / "prompt.ids");
    const auto extra = continuation.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(continuation);
    if (prompt.size() + extra.size() + steps - 1 > capacity) throw std::runtime_error("capacity is smaller than requested complete journey");
    const auto model_start = qwen35::Clock::now();
    qwen35::Model model(input / "weights.tsv", capacity, layer0_probe, progress, replay);
    const auto constructed = qwen35::Clock::now();
    if (!trace.empty()) model.trace_routes = trace / "routes";
    std::vector<std::size_t> known_chunks{prompt.size()};
    if (!extra.empty()) known_chunks.push_back(extra.size());
    if (steps > 1) known_chunks.push_back(1);
    model.prepare_family(known_chunks);
    if (!layer0_probe.empty()) model.prepare_family(known_chunks, true);
    const auto ready = qwen35::Clock::now();
    std::cerr << "initialized model_seconds=" << std::chrono::duration<double>(constructed - model_start).count()
              << " shape_prepare_seconds=" << std::chrono::duration<double>(ready - constructed).count()
              << " startup_to_ready_seconds=" << std::chrono::duration<double>(ready - startup).count() << '\n';
    auto next = model.evaluate(prompt, "prefill", trace, trace_states);
    std::cerr << "first_token_elapsed_seconds=" << std::chrono::duration<double>(qwen35::Clock::now() - startup).count() << '\n';
    if (!extra.empty()) next = model.evaluate(extra, "continuation", trace, trace_states);
    std::vector<std::int32_t> generated{next};
    std::vector<std::int32_t> consumed;
    for (std::size_t step = 1; step < steps && (!forced.empty() || !qwen35::is_end_of_generation(next)); ++step) {
      const auto previous = forced.empty() ? next : forced[step - 1];
      next = model.evaluate(std::span(&previous, 1), "decode" + std::to_string(step), trace, trace_states);
      consumed.push_back(previous);
      generated.push_back(next);
    }
    std::cout << "{\"source_id\":\"" << qwen35::source_id << "\",\"text_tensors\":320,\"visible_tokens\":"
              << model.length << ",\"generated_ids\":[";
    for (std::size_t i = 0; i < generated.size(); ++i) std::cout << (i ? "," : "") << generated[i];
    std::cout << "],\"fixed_decode\":" << (forced.empty() ? "false" : "true") << ",\"decode_input_ids\":[";
    for (std::size_t i = 0; i < consumed.size(); ++i) std::cout << (i ? "," : "") << consumed[i];
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Qwen3.5 text consumer: " << error.what() << '\n'; return 1;
  }
}
