"""Retained nine-process old/family/llama rotation, after exact model checks."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
spec=importlib.util.spec_from_file_location('finite_rotation_helpers',A/'qwen-current-retest/compare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,r=h.b,h.c,h.r
h.rotation.STAGE=S;r.PREPARED=S/'performance-prepared'
def runtime_environment(build,peer,out):
    link=c.read(S/'checks/qwen-link-plan.json')
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']]+[row['path'] for row in peer['inputs']],out)
    for key in r.FORBIDDEN_ENV:
        if key in env:raise ValueError('Unexpected experiment environment: '+key)
    return env,runtime
r.runtime_environment=runtime_environment
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');args=parser.parse_args()
    if args.run:
        h.rotation.run(r.PREPARED/'plan.json',S/'performance-rotation');return
    built=c.read(S/'checks/summary.json');assert built['passed']
    assert c.read(S/'correctness/summary.json')['passed'] and c.read(S/'continuation-fixed/summary.json')['passed']
    retained=c.read(A/'qwen-pinned-weight-load/performance-prepared/plan.json')
    images=dict(baseline=c.read(A/'qwen-pinned-weight-load/product-checks/qwen-image.json'),
        current=built['image'],llama=retained['images']['llama'])
    for row in images.values():r.require_same(row)
    requests=[]
    for old in retained['requests']:
        command=old['command'].copy();command[0]=images[old['arm']]['path'];assert '--trace' not in command
        requests.append(dict(**{k:v for k,v in old.items() if k!='command'},command=command))
    hc=next(row['command'] for row in requests if row['arm']=='current');lc=next(row['command'] for row in requests if row['arm']=='llama')
    inputs=Path(hc[hc.index('--inputs')+1]);manifest=inputs/'weights.tsv'
    wanted={c.key(p) for p in (manifest,inputs/'prompt.ids',Path(hc[hc.index('--decode-ids')+1]),
        Path(lc[2]),Path(manifest.read_text().splitlines()[1]),Path(lc[1]))}
    frozen=[row for row in retained['frozen'] if c.key(row['path']) in wanted]
    assert {c.key(row['path']) for row in frozen}==wanted
    frozen += [b.identity(p) for p in (Path(__file__),S/'checks/plan.json',S/'checks/qwen-link-plan.json',
        S/'correctness/summary.json',S/'continuation-fixed/summary.json',S/'candidate/main.cc',S/'source-freeze.json',r.PEER_PLAN)]
    plan={key:retained[key] for key in ('schema_version','status','fixed','source_id','expected_baseline_ids','order','metric_contract')}
    plan.update(build_plan=b.identity(S/'checks/plan.json'),images=images,peer_inputs=retained['peer_inputs'],frozen=frozen,
        requests=requests,profiler=False,external_memory_monitor=False,source_or_SDK_compilations_during_rotation=0,
        links_during_rotation=0,baseline='Current adopted pinned320-weight loader with separate concrete phase graphs; exact retained executable.',
        precision_limit=retained['precision_limit'],
        loading_subtimer_limit='Both Hyle arms retain identical pinned loader and full startup/TTFT boundaries. Peer intermediate precision and load/prepare sub-boundaries differ. OS file cache is not cleared.')
    r.PREPARED.mkdir(exist_ok=False);c.save(r.PREPARED/'plan.json',plan)
    print('FINITE_ROTATION_PREPARED_NO_GPU',flush=True)
if __name__=='__main__':main()
