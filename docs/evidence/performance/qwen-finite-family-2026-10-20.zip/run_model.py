"""Execute the finite-family consumer on the original fixed64 observations."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=load('finite_model_helpers',A/'projected-bind-cold-index/build.py');b,c=h.b,h.c
n=load('finite_model_numerics',A/'cuda-bf16-dual-projection/compare_numerics.py')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='correctness');args=parser.parse_args()
    out=S/args.out;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    built=c.read(S/'checks/summary.json');assert built['passed'] and b.same(built['candidate']) and b.same(built['image'])
    recipe=c.read(S/'checks/main-identity.json')
    for row in [recipe['object'],recipe['source'],*recipe['dependencies']]:assert b.same(row),row['path']
    link=c.read(S/'checks/qwen-link-plan.json')
    for row in link['inputs']:assert b.same(row),row['path']
    reference=A/'batch-graph-capture/correctness-final'
    vectors={p.relative_to(reference/'trace'):n.identity(p) for p in sorted((reference/'trace').rglob('*')) if p.suffix in ('.bf16','.f32')}
    assert len(vectors)==64
    command=c.read(reference/'qwen.command.json')['command'].copy();command[0]=built['image']['path']
    command[command.index('--trace')+1]=str(out/'trace')
    inputs=Path(command[command.index('--inputs')+1]);manifest=inputs/'weights.tsv';model=Path(manifest.read_text().splitlines()[1])
    c.save(out/'inputs.json',dict(candidate=built['candidate'],image=built['image'],source_freeze=b.identity(S/'source-freeze.json'),
        command=command,manifest=b.identity(manifest),model=b.identity(model),prompt=b.identity(inputs/'prompt.ids'),
        decode=b.identity(command[command.index('--decode-ids')+1]),reference_vectors=list(vectors.values()),
        fresh_model_processes=1,throughput_claim=False,quality_acceptance=False))
    env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    c.execute('qwen',command,env,out)
    observed=n.analyze_arm('finite-family',built['image'],out,vectors,n.final_json(reference/'qwen.stdout.log'))
    single_range=len(observed['capture_counts'])==32 and all(r['recorded']+r['reused']==1 and r['replay']=='hybrid' for r in observed['capture_counts'])
    passed=observed['equal_vectors']==64 and observed['all_outputs_finite'] and single_range and observed['same_greedy_ids_as_reference'] and observed['same_fixed_decode_inputs']
    c.save(out/'summary.json',dict(passed=passed,observation=observed,single_outer_range_32_phases=single_range,
        fresh_model_processes=1,throughput_claim=False,quality_acceptance=False,
        limits='Original fixed128+31 CUDA journey. Exact hidden/logits equality is a regression comparison, not independent model-quality acceptance.'))
    assert passed,dict(equal_vectors=observed['equal_vectors'],same_ids=observed['same_greedy_ids_as_reference'],single_range=single_range)
    print('FINITE_MODEL_EXACT64_GREEN',flush=True)
if __name__=='__main__':main()
