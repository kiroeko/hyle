"""Keep the consumer guide current and link detailed experimental evidence."""
from pathlib import Path
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
readme=ROOT/'tools/qwen35_text/README.md'
(S/'before/README.md').write_bytes(readme.read_bytes())
readme.write_text('''# Qwen3.5-2B 推理架构实验消费者

这是检验 Compute/Graph 架构的独立测试产物，不是已交付的推理引擎。使用本地官方权重运行完整24层CUDA纯文本计算，关闭MTP和视觉。
消费者只调用公共接口，模型格式、tokenizer和生成策略仍由消费者负责。

`prepare.py` 校验原输入清单的13个文件，输出权重偏移和token IDs；Python只做输入准备与独立参考。
`main.cc` 用一份模型语义图表达prefill、带状态的多token continuation和decode，在启动时预列本次需要的token数，
以有限shape图族一次冷编译。每个实际child有两个Invocation槽；运行时只查找已准备入口，不临时建图、编译或padding。
conv/GDN状态真实反馈，KV使用固定容量且只更新新增行；失败使当前请求失效。

六个BF16 GQA attention共用一份BatchSchema，每次执行共享同一owned layout与metadata输入。
schema容量为最大预列chunk，具体Q/output行数等于当前chunk，KV可见长度由layout和positions表达。
例如23-token prefill→4-token continuation→单token decode使用同图族的23/4/1三个child；head深度等模型常数保持固定。
每步沿原Invocation执行`graph::batch::prepare`→bind→`prepare_replay`→submit→Completion，再反馈状态和读取token。
两个槽不授权并发覆盖同一个Model的tokens、KV或状态；`evaluate`须顺序调用。退出先drain槽，再结束运行时和释放数据。

构建消费者的已安装SDK须包含CUDA `compute;graph;graph_progress;compute_stream;mem` 产品。
CMake只查包和链接，不构建原生依赖。`--inputs DIR` 指向准备后的输入；可用选项：

- `--continuation IDS`：prefill后追加多token输入；`--steps N`指定生成阶段数。
- `--progress direct|scheduler`：默认direct；scheduler在原槽上准备进度驱动，复用同一提交机制。
- `--replay commands|prefer-capture`：默认commands；后者使用公共Graph分段录制，日志区分实际录制与复用。
- `--decode-ids FILE`：固定单token输入带，允许跨过预测EOS；若同时给steps，须等于输入数加一。正常生成遇到endoftext或im_end停止。
- `--trace DIR --trace-level decisions`：仅导出logits与最后hidden；默认full还导出状态。路由写入DIR/routes，不增加图输出。
- `--layer0-probe DIR`：诊断时另行发布layer0边界并比较实际路由；诊断图会影响合法融合，因此与普通图分别冷准备，均计入启动时间。

加载沿现有FileResourcePipeline，用两个8MiB pinned暂存读取原权重范围并上传，保留320个device分配和持久目标租约。
完整Model／ready／首token计时包含文件关闭、管线退休和临时运行时销毁。新进程未清OS页缓存，不能称冷盘加载。
`step_seconds`包含输入上传、layout准备、绑定、replay准备、提交、等待及token读回；首次shape编译在启动时完成，trace导出不在step内。
`seconds`和`submit_seconds`是更窄子段，不可直接与另一引擎的完整decode相比；完整启动至首token看`first_token_elapsed_seconds`。

本次有限图族已完成原128+31旅程的64份hidden/logits逐byte对照，以及23/4/1 scheduler＋capture旅程的6份对照。
两组独立性能窗口确认准备开销减少；decode小差异反向，未证明稳定提速。详见[有限图族实测](../../docs/evidence/performance/qwen-finite-family-2026-10-20.json)，
最新同窗指标见[当前工作](../../docs/developer/current-work.md)。报告中的compiled storage保留unknown计数，不等于完整显存峰值。

`reference.py`是独立Torch参考，候选不会读取参考状态或结果。固定输入与向量相同属于回归检查，独立质量验收仍未完成；
BF16舍入、归约和RoPE诊断见[底座审查证据](../../docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md)。
原输入位于仓库`.scratch/inference-execution-refactor-2026-10-18/qwen35-text/`，不复制权重或SDK。
''',encoding='utf-8',newline='\n')
path=ROOT/'docs/developer/current-work.md';old=path.read_text(encoding='utf-8')
old=old.replace('后续将Qwen消费者迁到单一有限图族，按实际常量命中和完整计时判断收益；现有[设计审查](../evidence/correctness/batch-query-extent-2026-10-20.json)\n不代表已改消费者。随后独立修复CPU/CUDA的R>A输出尾部：',
'''Qwen消费者现已迁到一份symbolic Graph/schema/finite family，启动预列实际chunk，每child保留原两个Invocation；
六个reader每步共享同一layout，Q/output为实际T行，无热建图或padding。公共child report提供实际资源描述，
family compiled storage按去重汇总并保留unknown计数；没有全局缓存或新executor。
原128+31的64份hidden/logits逐byte同；23/4/1的scheduler＋capture旅程与fresh前版6份向量逐byte同。
首次普通23/4续算正确在EOS停止，随后固定消费同一EOS ID才覆盖T1，原观察与检查脚本修正均保留。
产品main与被测候选逐byte同，另1个产品CXX增量构建和完整128+31 smoke通过。
两组独立窗口中shape准备0.335→0.269s（-19.60%）、0.348→0.262s（-24.53%），
TTFT分别-4.37%／-6.12%。首窗完整decode+0.23%／warm-1.72%，反向C/B/B/C复核+0.88%／+2.49%，
小差异反向，未证明稳定decode收益。13进程均exit0且预测一致，不合并两窗；
[源码、红绿与实测](../evidence/performance/qwen-finite-family-2026-10-20.json)未新测整模型峰值、物理kernel或独立质量。
此前[有限图设计审查](../evidence/correctness/batch-query-extent-2026-10-20.json)保留当时边界。随后独立修复CPU/CUDA的R>A输出尾部：''')
start=old.index('最新三方同窗为2026-10-20北京时间11:17:36')
end=old.index('此前10:36:07',start)
new='''最新三方同窗为2026-10-20北京时间12:16:58–12:17:22，前版／有限图族／llama各3个新进程交错；
9进程均exit0、预测相同，无profiler或内存旁采，计时内不编译／链接。以下中位只描述这一窗：

| 指标 | 有限图族Hyle | 同窗llama.cpp | 边界 |
| --- | --- | --- | --- |
| 完整31步decode tokens/s | 91.11 | 95.35 | 本窗中位低4.45% |
| warm第7–31步 tokens/s | 93.92 | 97.00 | 本窗中位低3.17% |
| 首次prefill tokens/s | 2016.14 | 1249.90 | 本窗高61.30%，含各自首次step工作 |
| 首token秒 | 1.355 | 1.983 | 完整启动至首个host token |

前版Hyle的完整／warm为90.90／95.56 tokens/s；12:18:27–12:18:37独立C/B/B/C复核的有限图族／前版
完整为91.62／90.82、warm为95.24／92.93，不能据此替换首窗或证明稳定反超。BF16/F32中间计算、
引擎加载／准备子边界仍不同，未新测整模型峰值或独立质量。[本批原始对照](../evidence/performance/qwen-finite-family-2026-10-20.json)。

'''
old=old[:start]+new+old[end:]
path.write_text(old,encoding='utf-8',newline='\n')
print('FINITE_FAMILY_DOCS_CURRENT',flush=True)
