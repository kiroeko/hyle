from pathlib import Path
import subprocess, os, json, time, hashlib
canonical=Path.cwd();repo=Path('C:/h7/g01-cpu-p1-source-2');out=canonical/'.scratch/inference-gaps/g01';source=repo/'bench/inference_resident_sdpa/cpu_p1'
candidate='d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f'
for name in ('src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_ggml_runtime/cpu_execution.cc'):
 frozen=subprocess.check_output(['git','-C',str(repo),'show',candidate+':'+name]);assert frozen==(repo/name).read_bytes(),name
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip(),'qualified source must be immutable and clean'
build=Path('C:/h7/g01-cpu-p1-fresh-3');evidence=out/'cpu-p1-qualification-3'
assert not build.exists() and not evidence.exists(),'preserve all prior attempts'
batch=out/'cpu-formal-vs-env.cmd';batch.write_text('@echo off\ncall "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b 1\nset\n')
captured=subprocess.check_output(['cmd','/d','/c',str(batch)],text=True);env=os.environ.copy()
for line in captured.splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
peer=out/'original-ggml-cpu-peer'
args=['python',str(repo/'scripts/hyle-perf.py'),'qualify-platform','--contract',str(source/'contract.json'),'--source',str(source),'--machine','W1-WIN','--peer','original-ggml-cpu-flash='+str(peer),'--build',str(build),'--output',str(evidence)]
log=out/'cpu-p1-qualification-3.log';started=time.monotonic()
with log.open('w',encoding='utf-8') as f:
 process=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 status={'pid':process.pid,'command':args,'state':'RUNNING','cpu_product_candidate':candidate,'source_commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'log':str(log)}
 (out/'cpu-p1-job-3.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
 code=process.wait()
status.update(state='TERMINAL',exit_code=code,elapsed_seconds=time.monotonic()-started)
(out/'cpu-p1-job-3.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
raise SystemExit(code)
