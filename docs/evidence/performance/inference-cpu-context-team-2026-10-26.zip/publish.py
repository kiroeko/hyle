"""Publish retained shared-Context team facts. No builds or model runs."""
from pathlib import Path
import datetime,hashlib,json,statistics,subprocess,xml.etree.ElementTree as ET,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
PUBLIC=R/'docs/evidence/performance/inference-cpu-context-team-2026-10-26.json';ZIP=PUBLIC.with_suffix('.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
def stats(xs):return dict(count=len(xs),median=statistics.median(xs),min=min(xs),max=max(xs),samples=xs)
screen=read(W/'screen3/final-summary.json');runs=read(W/'screen3/runs.json');ready=read(W/'build1/ready.json')
assert screen['status']=='FRESH_CPU3_NINE_TIMING_THREE_INDEPENDENT_MEMORY_PASS'
assert len(runs)==12 and all(x['process']['exit']==0 for x in runs)
assert screen['work']['all12_complete_within_arm_non_time_equal_initial_reference']
sources=read(W/'source-pins.json')
for x in sources['files']:
 p=pin(W/'source'/x['path']);assert {k:v for k,v in p.items() if k!='path'}==x['after']
unit=read(W/'build1/unit-summary.json');assert unit['tests']==9 and unit['failed']==unit['skipped']==0
test_source=Path(unit['source']['path']);assert pin(test_source)==unit['source']
xml=ET.parse(W/'build1/unit-run1/results.xml').getroot()
test_names=[x.attrib['name'] for x in xml.iter('testcase')]
assert len(test_names)==9
behavior=read(W/'behavior1/summary.json');assert behavior['nontime_equal'] and behavior['process']['exit']==0
first_memory=read(W/'memory-initial1/summary.json');assert first_memory['process']['exit']==0
files={}
def add(name,path):
 p=Path(path);assert p.is_file(),p
 assert p.suffix.lower() in {'.json','.py','.patch','.h','.cc','.log','.xml','.txt'},p
 assert name not in files;files[name]=p
for name in ['source.patch','source-pins.json','independent-review-performance.json','check_build.py','check_unit.py',
 'check_memory.py','screen3.py','analyze_screen3.py','publish.py']:
 add(name,W/name)
for name in ['bench.patch','bench-pins.json','bench-review.json','check_bench.py','check_bench_retry.py']:
 add('bench-followup/'+name,W/name)
for directory in ['bench-r1','bench-compile1','bench-compile2']:
 for p in (W/directory).rglob('*'):
  if p.is_file() and (p.name in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json','summary.json'] or p.suffix in ['.patch'] or p.name.endswith('pins.json')):
   add('bench-followup/'+p.relative_to(W).as_posix(),p)
cmake_manifest=R/'cmake/HyleComponents.cmake'
cmake_diff=subprocess.check_output(['git','diff','--','cmake/HyleComponents.cmake'],cwd=R)
assert b'PRIVATE_DEPS core error mem platform util_core' in cmake_diff
(W/'cmake-check/source.patch').write_bytes(cmake_diff)
save(W/'cmake-check/source-pin.json',dict(path='cmake/HyleComponents.cmake',after=pin(cmake_manifest),
 scope='Root explicitutil_core private dependency for existingRefCounted header;singlemanifest line;LANGUAGESNONE closurecheck only.'))
for name in ['CMakeLists.txt','command.json','result.json','stdout.txt','stderr.txt','source.patch','source-pin.json']:
 add('cmake-check/'+name,W/'cmake-check'/name)
add('runtime-test/execution_test.cc',test_source)
for folder in ['runtime','provider','unit','link','unit-link','unit-link2','unit-run1']:
 for leaf in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json','results.xml']:
  p=W/'build1'/folder/leaf
  if p.is_file():add('build1/'+folder+'/'+leaf,p)
for name in ['ready.json','runtime.json','compile-summary.json','link-inputs.json','unit-link2-inputs.json','unit-summary.json']:
 add('build1/'+name,W/'build1'/name)
for name in ['command.json','process.json','stdout.log','stderr.log','nontime-diff.json','summary.json']:
 add('behavior1/'+name,W/'behavior1'/name)
for name in ['command.json','result.json','live.json','stdout.log','stderr.log','memory.json','memory-summary.json','threads.json','summary.json']:
 add('initial-resource-observation/'+name,W/'memory-initial1'/name)
for row in runs:
 folder=Path(row['folder'])
 for leaf in ['command.json','result.json','live.json','stdout.log','stderr.log','checks.json']:
  add('fresh-window/'+folder.name+'/'+leaf,folder/leaf)
 if row['arm']=='P':add('fresh-window/'+folder.name+'/consumer-result.json',folder/'consumer-result.json')
 if row['mode']=='memory':
  for leaf in ['memory.json','memory-summary.json','threads.json']:
   add('fresh-window/'+folder.name+'/'+leaf,folder/leaf)
for name in ['final-summary.json','runs.json','plan.json','offline-first-failure.py','offline-first-failure.json']:
 add('fresh-window/'+name,W/'screen3'/name)
adapter=R/'.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py'
add('retained-observer/screen.py',adapter)
protocol=read(R/'.scratch/inference-cpu-representative-20261026/peer-avx2/screen/plan.json')
for key in ['runner','observer','sampler']:add('retained-observer/'+key+'.py',protocol[key]['path'])
for rel in ['.scratch/mtp-performance-convergence-20261025/baseline/window.py','.scratch/qwen-mtp-window-20261022/window.py']:
 add('retained-observer/'+Path(rel).parent.name+'-'+Path(rel).name,R/rel)
startup={a:{key:stats([x['metrics'][key] for x in runs[:9] if x['arm']==a]) for key in ['startup_to_ready_seconds','startup_to_endpoint_seconds']} for a in ['H','C','P']}
report=dict(schema='hyle.inference-cpu-context-team.v1',status='WINDOWS_CPU_SHARED_CONTEXT_TEAM_FINITE_CHECKS_AND_FRESH3ARM_WINDOW_PASS',
 generated_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Windows i9-13900K ordinary P154/16/C256/N1/R1 greedy naturalEOS;CPUonly model placement. Private candidate shared native pool versus originalHyle and same-source AVX2 peer. No macOS/Linux runtime or GPU inference claim.',
 results=dict(timing=screen['timing'],comparisons=screen['comparisons'],
  fourth_timing_metric_startup_diagnostic_seconds=startup,
  main_timing_definition='Prefill154/prefill_seconds;decode15/decode_seconds;combined16/session_seconds. The fourth category lists original startup clocks only,not a fair Hyle/peer coldstart ranking. Each has3fresh timing samples/ranges.',
  memory=screen['memory'],interleaved_triplets=screen['interleaved_triplets']),
 work=screen['work'],protocol=screen['protocol'],
 fresh_window_reference=pin(W/'screen3/final-summary.json'),
 cold_source=dict(product_paths=sources['files'],patch=pin(W/'source.patch'),independent_review=read(W/'independent-review-performance.json'),
  mechanism='One CpuTeam per ggml providerContext lazily owns the native pool;Program andCpuExecution retain it. Each slot keeps privategraph/cplan/workspace/abort. Original executor callback serializes complete nativecompute under same-team mutex;TLS chain rejects same-thread reentry. CpuProgram ABI/nativecode/thread4/defaults unchanged.',
  close_boundary='Public Context.close still forbids newsubmissions. Internal CpuExecution/team ownership canretain alreadyderivednative work;facade release is not publicclose bypass.'),
 build=dict(ready=ready,private_product_TUs=2,SDK_or_native_rebuilds=0,
  changes='Only CpuExecution runtime and ggmlCPU provider objects replace originals in frozenfa7link. Runtime test1TU+finite link separately. Images,SDK,nativeprograms,weights are identified but excluded fromZIP.',
  image_scope='Original fa7CPU Model image predates currentR>1 batchedsampling changes;this frozen N1greedy path is unchanged. Candidate56303f18 uses exactlisted4path privatepatch and samefa7otherinputs,not an assertion of allcurrentcanonical combinations.'),
 followup_compilation=dict(benchmark_review=read(W/'bench-review.json'),
  first_benchmark_failure='Raggedreference stillused removedlayout.schema();firstC2039raw andr1patch preserved. Mechanical origin_schema() migration corrected existingAPI use;2TU strictcompilePASS,no link/run.',
  cmake=read(W/'cmake-check/result.json'),cmake_source=read(W/'cmake-check/source-pin.json'),
  scope='These2benchmarkAPI migrations andexplicitCMakeheaderdependency close consumers/buildmetadata. They do not change the4runtimeproductpins,563image,9runtimechecks or12Modelprocess facts.'),
 runtime_unit=dict(summary=unit,test_names=test_names,
  passed_contracts=['Same-team two independent slots fromtwohostthreads;internal teamhandle dropped while slots retainowner;finalquota0',
   'Synthetic nativeith0 abortcallback same-teamrun reentry rejects FailedPrecondition andlatercompute succeeds',
   'Cancellation joinsworkers and allowsreuse;metadata/workspaceOOM;existingnumerical/IQ1/prerequisite tests'],
  not_tested='No arbitrary secondary-worker callback,cross-team lockcycle or modified publicContext.close behavior. Same-teamprepare reentry is source-guarded but not a separate runtime assertion.',
  first_link_failure=dict(process=read(W/'build1/unit-link/process.json'),
   cause='Missing existingcpu-baseline GDNcontract symbol object andWindowsadvapi32 system imports;no test orModelrun atthatfailedlink.',
   correction='Reuse existingcpu-baseline.obj andlink advapi32.lib;sametestobject/native/source,secondlinkPASS,one9testprocessPASS. Rawfirststdout retainedbyteexact.')),
 behavior_gate=dict(summary=behavior,pooled_into_timing=False),
 initial_resource_gate=dict(summary=first_memory,pooled_into_timing_or_memory_window=False,
  observed='Candidateinitialmemory OSthreadpeak17 versus earliercontrol3428;independent early gate only. Allfreshwindow RAM/thread comparisons below use onlynew3memoryprocesses.'),
 prior_evidence=dict(CPU_AVX2_window=pin(R/'docs/evidence/performance/inference-cpu-avx2-window-2026-10-26.json'),
  old_samples_pooled=False,matched_ISA_peer='Peer27a49a links same4e1a15CPU TUs built AVX2/FMA/F16C. NoHyleother-version nativeobjects used forpeer.'),
 resource_boundary='Fresh OSthreadpeaks H/C/P3428/17/16;totalthreads,notbusythreads. WS/privatecommit are separatelysampled;filebackedmapping differences affect crossengineprivatecommit. No allocator-total/physicalmemoryhardlimit claim.',
 failures=dict(model_or_observer_failures_in_fresh_window=0,offline_summary_failure=screen['offline_summary_failure']),
 precision_and_limits=screen['limits'],
 reproducibility=dict(script=pin(W/'screen3.py'),offline_parser=pin(W/'analyze_screen3.py'),
  requirements='RetainedlocalexactHF/GGUF2Bweights,fa7app/SDK/core/native/librarycaches andruntimePATH. Noautomaticacquisition;no model/build launched bypublication.',
  no_rerun_during_publication=True))
save(W/'screen3/public-summary.json',report);add('summary.json',W/'screen3/public-summary.json')
manifest=[dict(name=n,bytes=p.stat().st_size,sha256=pin(p)['sha256']) for n,p in sorted(files.items())]
save(W/'screen3/archive-manifest.json',manifest);add('archive-manifest.json',W/'screen3/archive-manifest.json')
ZIP.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(files.items()):z.writestr(n,p.read_bytes())
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)
 for x in manifest:
  b=z.read(x['name']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
report['archive']=dict(**pin(ZIP),members=len(files),CRC_PASS=True,member_SHA256_PASS=True,
 exclusions='Noobjects,executables,libraries,DLLs,SDKs,modelpayloads orfullsource/vendor trees.')
report['archive']['path']=ZIP.relative_to(R).as_posix();save(PUBLIC,report)
print(json.dumps(dict(report=pin(PUBLIC),archive=report['archive']),indent=2))
