from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('team_build',W/'check_build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
R=b.R
recipe=R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_ggml--ggml_cpu_provider_cc/command.json'
source=W/'test-source/tests/compute_ggml_runtime/execution_test.cc'
compiled=dict(result=b.read(W/'build1/unit/process.json'),object=b.pin(W/'build1/unit/unit.obj'),source=b.pin(source),command=b.pin(W/'build1/unit/command.json'),actual_dependencies=b.pin(W/'build1/unit/actual-dependencies.json'))
control=b.read(b.CONTROL/'link/command.json')['command']
select=[
 str(W/'build1/unit/unit.obj'),str(W/'build1/runtime/unit.obj'),
 str(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/foundation1/metadata-arena.obj'),
 str(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/foundation1/cpu-hadamard.obj'),
 str(R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/host1/compute_ggml_runtime--cpu_program.obj')]
names={'ggml-cpu.lib','ggml.lib','ggml-base.lib','hyle_mem.lib','mimalloc_static.lib','hyle_error.lib','hyle_platform.lib','hyle_platform_thread.lib','gtest.lib','gtest_main.lib'}
select += [p for p in control if Path(p).name in names]
assert len(select)==15,select
select += [p for p in control if Path(p).name=='cpu-baseline.obj']
assert len(select)==16
select += ['advapi32.lib']
out=W/'build1/unit-link2';image=out/'runtime-test.exe'
command=[control[0],*control[2:9],*select,'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
b.save(W/'build1/unit-link2-inputs.json',[b.pin(p) for p in select if Path(p).is_file()])
linked=b.h.execute(command,b.env(command),out,timeout=120)
runtime=b.read(b.CONTROL/'runtime.json');native=Path(runtime['native']['path']);target=out/Path(runtime['native_hardlink']['path']).name
os.link(native,target)
env=b.env(command);env['PATH']=str(out)+os.pathsep+runtime['PATH']
run=W/'build1/unit-run1'
ran=b.h.execute([str(image),'--gtest_filter=GgmlCpuExecution.*','--gtest_output=xml:'+str(run/'results.xml')],env,run,timeout=60)
x=ET.parse(run/'results.xml').getroot();assert int(x.attrib['tests'])==9 and int(x.attrib['failures'])==0 and int(x.attrib.get('disabled',0))==0
assert not any(t.find('skipped') is not None for t in x.iter('testcase'))
summary=dict(status='PASS',compile=compiled,link=linked,run=ran,tests=9,failed=0,skipped=0,IQ1_enabled='/DHYLE_GGML_CPU_IQ1_EXTENSIONS=1' in b.read(W/'build1/unit/command.json')['command'],source=b.pin(source),image=b.pin(image),runtime_native=b.pin(native),native_alias=b.pin(target),source_pins=b.pin(W/'source-pins.json'),tests_xml=b.pin(run/'results.xml'),model_runs=0,GPU_runs=0)
b.save(W/'build1/unit-summary.json',summary)
print('UNIT PASS',json.dumps(summary['run']),flush=True)
