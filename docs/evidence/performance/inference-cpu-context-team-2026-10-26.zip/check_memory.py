"""Exactly one candidate memory-only CPU process; retained observer/argv."""
from pathlib import Path
import importlib.util, json, os, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
p=R/'.scratch/inference-cpu-representative-20261026/peer-avx2/screen.py'
s=importlib.util.spec_from_file_location('retained_cpu_screen',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
ready=m.read(W/'build1/ready.json'); runtime=m.read(W/'build1/runtime.json')
assert m.pin(ready['image']['path'])==ready['image']
assert ready['image']['sha256']=='56303f189ee8b9833231c1e0b3166ff9d81908516c815fa7b5eadceb914acb62'
folder=W/'memory-initial1';assert not folder.exists(),'Refuse overwrite/retry'
command=list(m.read(m.W/'commands.json')['hyle']['command'])
command[0]=ready['image']['path']
env=os.environ.copy();env['PATH']=runtime['PATH'];env.update(runtime.get('configured_flags',{}))
env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
m.current_folder=folder
process=m.runner.execute(folder,'hyle',command,env,True)
j=m.raw(folder,'hyle');work=m.check(j,'hyle')
memory=m.read(folder/'memory-summary.json');threads=m.read(folder/'threads.json')
summary=dict(status='ONE_CANDIDATE_MEMORY_WORK_PASS',process=process,work=work,
    ready=m.pin(W/'build1/ready.json'),image=ready['image'],runtime=m.pin(W/'build1/runtime.json'),
    script=m.pin(__file__),retained_observer_adapter=m.pin(p),memory_sampled_peaks=memory['sampled_peaks'],
    OS_threads=dict(samples=threads['count'],peak=threads['peak'],range={k:v for k,v in threads['values'].items() if k!='samples'}),
    setup_error=memory['setup_error'],thread_error=memory['thread_error'],
    GPU_unavailable_reasons=memory['unavailable_reasons'],
    throughput_evidence=False,model_processes=1,retries=0,
    limits=['Independent memory process only;its TPS is not a speed sample.',
        'OS thread count is not busy threads;sampled memory/thread peaks are lower bounds.',
        'Complete within-arm non-time report matches originalfa7 initialpair;all16IDs/169target/15decode unchanged.',
        'No newbaseline,peer,model retry,SDK rebuild or product modification.'])
m.save(folder/'summary.json',summary)
print(json.dumps(dict(summary=m.pin(folder/'summary.json'),OS_threads=summary['OS_threads'],
    sampled_peaks=summary['memory_sampled_peaks'],work_PASS=True,CPU_WINDOW='RELEASED'),indent=2),flush=True)
