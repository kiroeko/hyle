"""Offline final summary for the sole fresh12process CPU window."""
from pathlib import Path
import hashlib,json,statistics
W=Path(__file__).resolve().parent;S=W/'screen3'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stats(xs):return dict(count=len(xs),min=min(xs) if xs else None,median=statistics.median(xs) if xs else None,max=max(xs) if xs else None)
s=read(S/'summary.json');rows=read(S/'runs.json')
assert s['status']=='COMPLETE' and len(rows)==12 and s['work_all_passed']
assert all(x['process']['exit']==0 for x in rows)
assert [x['arm'] for x in rows]==['H','C','P','P','C','H','C','H','P','H','C','P']
triples=[]
for i in range(0,9,3):
 group=rows[i:i+3];byarm={x['arm']:x for x in group}
 triples.append(dict(triplet=i//3+1,order=[x['arm'] for x in group],
  C_vs_H_tps_percent={k:(byarm['C']['metrics'][k]/byarm['H']['metrics'][k]-1)*100 for k in s['timing']['H']}))
memory={}
for x in rows[9:]:
 f=Path(x['folder']);m=read(f/'memory-summary.json');t=read(f/'threads.json')
 assert m['setup_error'] is None and m['thread_error'] is None
 phases={}
 for name,v in m['phase_windows'].items():
  assert not v['missing_boundary'] and not v['ambiguous_boundary'] and not v['invalid_boundary_order']
  ts=[y['threads'] for y in t['samples'] if 'threads' in y and v['begin_ns']<=y['timestamp_ns']<=v['end_ns']]
  phases[name]=dict(memory_samples=v['sample_count'],OS_threads=stats(ts),
   sampled_phase_peaks={k:y['max'] for k,y in v['values'].items()})
 memory[x['arm']]=dict(pid=x['process']['pid'],sampled_peaks=m['sampled_peaks'],
  memory_samples=m['sample_count'],running_memory_samples=m['running_sample_count'],
  OS_threads=dict(samples=t['count'],peak=t['peak'],range={k:y for k,y in t['values'].items() if k!='samples'},
   requested_interval_seconds=.1,actual_gaps_ms=stats([(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(t['samples'],t['samples'][1:])])),
  phases=phases,setup_error=m['setup_error'],thread_error=m['thread_error'],
  GPU_unavailable_reasons=m['unavailable_reasons'],ready_baseline_unknown=m['ready_baseline']['unknown'],
  raw=dict(memory=pin(f/'memory.json'),threads=pin(f/'threads.json')))
out=dict(status='FRESH_CPU3_NINE_TIMING_THREE_INDEPENDENT_MEMORY_PASS',
 timing=s['timing'],comparisons=s['comparisons'],interleaved_triplets=triples,memory=memory,
 work=dict(all12_complete_within_arm_non_time_equal_initial_reference=True,
  H_and_C_reference='fa7 original Hyle initialpair',P_reference='peerAVX2 own initialpair',
  same154prompt_ids=True,same16generated_ids=True,generated_ids=rows[0]['work']['generated_ids'],
  target_rows_each=169,target_calls_each=16,decode_calls_each=15,draft_rows_each=0,
  greedy=True,natural_EOS_honored=True,early_EOS=False,capacity=256,N=1,R=1,
  original_Hyle_ledgers_unchanged=True,original_Hyle_final_live_committed_versions=0),
 processes=[dict(index=x['index'],arm=x['arm'],mode=x['mode'],pid=x['process']['pid'],exit=x['process']['exit'],
  process_wall_seconds=x['process']['process_wall_seconds'],folder=x['folder']) for x in rows],
 protocol=dict(timing_order='H,C,P,P,C,H,C,H,P',memory_order='H,C,P',
  timing_samples_each=3,memory_samples_each=1,prior_samples_pooled=False,warmups=0,retries=0,
  watchdog_seconds=180,prefill='154/prefill_seconds',decode='15/decode_seconds',combined='16/session_seconds',
  timing_processes_unmonitored=True,memory_TPS_not_speed_sample=True),
 identities=dict(plan=read(S/'plan.json'),script=pin(W/'screen3.py'),offline_analyzer=pin(__file__)),
 offline_summary_failure=read(S/'offline-first-failure.json'),
 limits=[
  'Only this fresh9timing+3memory window. Prior generic/AVX2 pairs,old8screen,behavior1 andcandidate initialmemory are excluded from every statistic.',
  'CandidatevsHyle medians+1.35%prefill,+2.60%decode,+1.91%combined;this shortsample positive signal is not broad/scaling/deployment throughput or a cross-window speed claim.',
  'Native4+borrowedScheduler4+ATenintraop4 for bothHyle;peer actual decode/batch4. T4 is not processwide quota. OSthread peak3428/17/16 is totalthreads,not busythreads.',
  'Same16greedy IDs do not establish intermediatebit/precision/quality equivalence. Hyle BF16 storepoints/F32 operations differ frompeer187BF16+133F32source tensors,F32recurrent,K/VBF16.',
  'Peer now uses AVX2/FMA/F16C same-versionCPU archive. Routes/accumulation/ISA use are not per-op profiled or proven identical.',
  'Hyle ATen/Scheduler startup is outside originalqwen startupclock;startup/processwall not fairHyle-vspeer coldstart ranking.',
  'Independentmemory observations are sampled lowerbounds. Working set includes residentmappedpages;privatecommit excludes filebacked/sharedmapping. Missing GPUcounterinstances remainnull,notzero. Peer24KiB dedicated0shared canreflectlinkedCUDAregistry despite noGPUmodel.',
  'Resource metadata was not normalized away:complete semantic reports matched. No SDK/native rebuild,newweights,extra experiment,product/default/threadbudget change during this window.'
 ])
p=S/'final-summary.json';p.write_bytes((json.dumps(out,indent=2,allow_nan=False)+'\n').encode())
print(json.dumps(dict(summary=pin(p),interleaved_triplets=triples),indent=2))
