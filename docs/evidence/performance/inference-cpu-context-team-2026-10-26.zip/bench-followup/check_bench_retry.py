from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('team_bench_tools',W/'check_build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=W/'bench-compile1/cpu_ragged_reference';out=W/'bench-compile2/cpu_ragged_reference'
command=b.read(old/'command.json')['command'];command=[a.replace(str(old),str(out)) for a in command]
result=b.h.execute(command,b.env(command),out,timeout=120)
d=b.read(out/'dependencies.json')['Data'];deps=[b.pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])];b.save(out/'actual-dependencies.json',deps)
summary=b.read(W/'bench-compile1/summary.json');summary['compiled']['bench/inference_resident_sdpa/cpu_ragged_reference.cc']={'result':result,'source':b.pin(b.R/'bench/inference_resident_sdpa/cpu_ragged_reference.cc'),'object':b.pin(out/'unit.obj'),'command':b.pin(out/'command.json'),'actual_dependencies':b.pin(out/'actual-dependencies.json')};summary['status']='TWO_TRANSLATION_UNITS_STRICT_COMPILE_PASS_NOT_LINKED_OR_RUN';summary['revision']=2;summary['first_failure']={'stage':str(old),'exit':b.read(old/'process.json')['exit'],'kind':'OLD_BENCH_API_SCHEMA_TO_ORIGIN_SCHEMA','fix':'The identical root-domain owns(next) check now calls current origin_schema(); no numerical or permissions change.'};summary['pins']=b.pin(W/'bench-pins.json');summary['patch']=b.pin(W/'bench.patch');b.save(W/'bench-compile2/summary.json',summary);print('PASS TWO CURRENT BENCH TUS /c ONLY')
