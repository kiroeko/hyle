"""Compile only the two existing CPU reference adapters against current headers."""
from pathlib import Path
import hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('bench_host',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
recipe=R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_ggml--ggml_cpu_provider_cc/command.json'
old=read(recipe)['command'];base=[];skip=False
for a in old:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 base.append(a)
env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':base[0],'CMAKE_CXX_COMPILER':base[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
summary={'status':'COMPILE_IN_PROGRESS','recipe':pin(recipe),'scope':'Minimal strict current-CPU recipe from the already-used provider command; bench CMake requires C++23/static and the same runtime/ggml includes. No original bench recipe found in the specifically checked reused build compile_commands.','compiled':{},'links':0,'runs':0,'SDK_builds':0}
for row in read(W/'bench-pins.json')['files']:
 rel=row['path'];source=R/rel;assert {k:v for k,v in pin(source).items() if k!='path'}==row['after']
 name=source.stem;out=W/'bench-compile1'/name
 command=base+[str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
 result=h.execute(command,env,out,timeout=120)
 d=read(out/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
 assert any(p['path']==str(R/'src/compute_ggml_runtime/cpu_execution.h') for p in deps)
 assert not any('inference-cpu-shared-pool-20261026/source' in p['path'].replace('\\','/') for p in deps)
 save(out/'actual-dependencies.json',deps)
 summary['compiled'][rel]={'result':result,'source':pin(source),'object':pin(out/'unit.obj'),'command':pin(out/'command.json'),'actual_dependencies':pin(out/'actual-dependencies.json')}
 save(W/'bench-compile1/summary.json',summary)
summary['status']='TWO_TRANSLATION_UNITS_STRICT_COMPILE_PASS_NOT_LINKED_OR_RUN';summary['pins']=pin(W/'bench-pins.json');summary['patch']=pin(W/'bench.patch');save(W/'bench-compile1/summary.json',summary)
print('PASS TWO TU ONLY',flush=True)
