from pathlib import Path
import json,os,subprocess
D=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
out=D/'limits-explicit';out.mkdir(exist_ok=False)
ready=read(D/'qwen-ready-attempt3.json');old=read(D/'budget-pressure-run1/command.json')['command']
command=old[:old.index('--trace')];command[command.index('--cache-bytes')+1]='84836399'
command[command.index('--active-sequences')+1]='2'
env=os.environ.copy();env['PATH']=read(ready['runtime_environment']['path'])['PATH']
p=subprocess.run(command,cwd=D.parents[1],env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=15)
(out/'stdout.log').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr)
(out/'process.json').write_text(json.dumps(dict(command=command,image=ready['image'],exit=p.returncode),indent=2)+'\n')
stderr=p.stderr.decode();assert p.returncode==1 and 'requires 84836400 shared KV/RNN backing bytes'in stderr
assert 'ggml_cuda_init'not in stderr and 'resident text weights'not in stderr
budget=read(D/'budget-pressure-run1/output.json');pressure=read(D/'pressure-run2/output.json')
assert budget['effective_cache_sessions']==2 and budget['active_sequences']==2 and budget['cache_shared_backing_bytes']==84836400 and budget['cache_requested_byte_limit']==84836400
for a,b in zip(budget['sessions'],pressure['sessions']):
    for key in ('generated_ids','decode_input_ids','visible_tokens','restored_calls','restored_tokens','recomputed_decision_changes'):assert a[key]==b[key]
(out/'result.json').write_text(json.dumps(dict(command=command,image=ready['image'],exit=p.returncode,rejected_before_CUDA_context_and_weight_load=True,auto_budget_selected_N=2,auto_budget_selected_R=2,backing_bytes=84836400,auto_budget_pressure_same_ids_and_restore_ledger_as_explicit_N2R2=True,throughput_evidence=False),indent=2)+'\n')
print('PASS minimum-byte refusal before Model load; auto N/R budget matches explicit pressure inputs/outputs')
