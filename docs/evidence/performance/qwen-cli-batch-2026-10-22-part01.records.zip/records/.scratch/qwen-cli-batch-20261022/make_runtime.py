from pathlib import Path
D=Path(__file__).resolve().parent
s=(D/'before/tools/qwen35_text/main.cc').read_text()
a=s.index('        if (prefix_enabled && is_prompt) {',s.index('      for (std::size_t d ='))
b=s.index('        double complete_seconds = 0;',a)
prefix=s[a:b]
prefix=prefix.replace('            make_advance_room(*run.session);','            const auto restore_start = qwen35::Clock::now();\n            make_advance_room(*run.session);')
prefix=prefix.replace('            ++run.actual_graph_calls; run.actual_graph_tokens += restored_ids.size();',
'''            ++run.actual_graph_calls; run.actual_graph_tokens += restored_ids.size();
            const std::array members{s};
            record_batch(phase.kind, restored_ids.size(), members, true,
                std::chrono::duration<double>(qwen35::Clock::now() - restore_start).count());''')
a=s.index('        if (prefix_enabled) {\n          complete_seconds = ',b)
b=s.index('      for (std::size_t s = 0; s < runs.size(); ++s) {',a)
complete=s[a:b]
# Each completion operates on the stored prepared result.
complete=complete.replace('        endpoint = run.endpoint;','        endpoint = (std::max)(endpoint, run.endpoint);')
pub='''          if (prefix_enabled) {
            const qwen35::cache::ReplayPrefix history{run.history, run.history->chunks.size(), run.history->length};
            (void)prefix_cache->publish(token_plans[s], run.session->head, history);
          }
'''
assert pub in complete
complete=complete.replace(pub,'')
# Trim the original outer for closing brace, then append wave publication.
assert complete.endswith('      }\n')
complete=complete[:-8]
runtime='''      struct PreparedCall {
        std::span<const std::int32_t> ids, logical_ids;
        std::size_t before = 0, reused = 0;
        bool used_prefix = false;
        qwen35::Clock::time_point call_start{};
        double complete_seconds = 0;
        std::int32_t next = -1;
      };
      std::vector<PreparedCall> prepared;
      std::vector<std::size_t> actual_rows, members;
      std::vector<qwen35::Session *> owners;
      std::vector<qwen35::EvaluationRequest> requests;
      std::vector<qwen35::EvaluationOutput> outputs;
      std::vector<std::int32_t> next_ids;
      prepared.reserve(active_slots); actual_rows.reserve(active_slots); members.reserve(active_slots);
      owners.reserve(active_slots); requests.reserve(active_slots); outputs.reserve(active_slots); next_ids.reserve(active_slots);
      for (const auto &wave : waves) {
        const auto wave_start = qwen35::Clock::now();
        if (journey_start == qwen35::Clock::time_point{}) journey_start = wave_start;
        const auto graphs_before = executed_graph_calls, tokens_before = executed_graph_tokens;
        WaveObservation wave_observation{wave.calls.front().kind == qwen35::benchmark::PhaseKind::kPrompt ? 0 : 1};
        prepared.clear(); prepared.resize(wave.calls.size()); actual_rows.clear();
        // Resolve the whole wave against PREVIOUS publications. A full hit
        // stays pinned and charged while the other members are evaluated.
        for (std::size_t j = 0; j < wave.calls.size(); ++j) {
          const auto &scheduled_call = wave.calls[j];
          const auto s = scheduled_call.session, index = scheduled_call.call;
          auto &run = runs[s];
          const auto call = run.calls[index];
          const auto &phase = schedules[s].phases[call.phase];
          auto &summary = run.summaries[call.phase];
          if (call.local == 0) {
            summary.context_before = run.visible_tokens;
            std::cerr << "memory_phase=" << summary.memory_name << "_begin\\n";
            summary.start = qwen35::Clock::now();
            if (index == 0) run.start = summary.start;
          }
          const bool is_prompt = phase.kind == qwen35::benchmark::PhaseKind::kPrompt;
          auto &work = prepared[j];
          work.call_start = qwen35::Clock::now();
          if (is_prompt) ensure_resident(s, prefix_enabled);
          const auto logical_ids = is_prompt ? std::span<const std::int32_t>(phase.ids)
              : std::span<const std::int32_t>(&phase.ids[call.local], 1);
          auto ids = logical_ids;
          const auto before = run.visible_tokens;
          const auto target = before + logical_ids.size();
          std::size_t reused = 0;
          bool used_prefix = false;
'''+prefix+'''          work.ids = ids; work.logical_ids = logical_ids;
          work.before = before; work.reused = reused; work.used_prefix = used_prefix;
          actual_rows.push_back(ids.size());
          wave_observation.logical_tokens += logical_ids.size();
          if (wave_observation.kind != (is_prompt ? 0 : 1)) wave_observation.kind = -1;
          if (ids.empty()) {
            work.next = run.session->head->next_id;
            run.endpoint = qwen35::Clock::now();
            auto &observation = run.observations[index];
            observation.graph_executed = false; observation.graph_input_tokens = 0;
            observation.visible = run.session->length(); observation.next = work.next;
            observation.scheduled_progress = progress;
          }
        }
        for (const auto &bucket : qwen35::benchmark::bucket_schedule_wave(wave, actual_rows)) {
          requests.clear(); outputs.clear(); owners.clear(); members.clear(); next_ids.resize(bucket.calls.size());
          for (const auto j : bucket.calls) {
            const auto &call = wave.calls[j]; auto &run = runs[call.session]; auto &work = prepared[j];
            requests.push_back({run.session, work.ids});
            owners.push_back(run.session.get()); members.push_back(call.session);
            outputs.push_back({run.session, run.observations[call.call].name, &run.trace, trace_states,
                &work.complete_seconds, &run.endpoint, &run.observations[call.call],
                preparation_diagnostics ? &run.preparation[call.call] : nullptr,
                multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{}});
          }
          const auto batch_start = qwen35::Clock::now();
          make_batch_room(owners);
          qwen35::PreparationObservation preparation;
          model.prepare_evaluations(requests, preparation_diagnostics ? &preparation : nullptr);
          if (preparation_diagnostics) for (const auto j : bucket.calls)
            runs[wave.calls[j].session].preparation[wave.calls[j].call] = preparation;
          model.submit_evaluations();
          model.finish_evaluations(outputs, next_ids);
          const auto batch_endpoint = runs[members.front()].endpoint;
          record_batch(bucket.kind, bucket.query_rows, members, false,
              std::chrono::duration<double>(batch_endpoint - batch_start).count());
          for (std::size_t at = 0; at < bucket.calls.size(); ++at) {
            const auto j = bucket.calls[at]; const auto &call = wave.calls[j];
            auto &run = runs[call.session]; auto &work = prepared[j]; work.next = next_ids[at];
            ++run.actual_graph_calls; run.actual_graph_tokens += work.ids.size();
            if (prefix_enabled) run.history->append(token_plans[call.session], work.before + work.reused, work.ids.size(), work.next);
          }
          // No temporary strong Session owner may retain an old head across
          // next-wave adoption or eviction outside the charged directory.
          requests.clear(); outputs.clear();
          if (model.snapshot_versions.live > cache_slots)
            throw std::runtime_error("committed batch versions exceed the finite cache budget");
          note_committed_versions();
        }
        for (std::size_t j = 0; j < wave.calls.size(); ++j) {
          const auto &scheduled_call = wave.calls[j];
          const auto s = scheduled_call.session, index = scheduled_call.call;
          auto &run = runs[s]; const auto call = run.calls[index];
          const auto &phase = schedules[s].phases[call.phase]; auto &summary = run.summaries[call.phase];
          const bool is_prompt = phase.kind == qwen35::benchmark::PhaseKind::kPrompt;
          auto &work = prepared[j]; auto &observation = run.observations[index];
          const auto logical_ids = work.logical_ids;
          const auto call_start = work.call_start;
          const auto next = work.next; const auto reused = work.reused; const auto used_prefix = work.used_prefix;
          // Per-session latency includes time waiting for its batch. Aggregate
          // throughput uses the wave wall once, never the sum of these spans.
          auto complete_seconds = std::chrono::duration<double>(run.endpoint - call_start).count();
'''+complete+'''        }
        // Publication is a wave boundary. Same-wave calls never consume each
        // other's new checkpoint, matching the dependency and cold shape plan.
        if (prefix_enabled) for (const auto &call : wave.calls) {
          const auto &phase = schedules[call.session].phases[call.phase];
          const auto count = phase.kind == qwen35::benchmark::PhaseKind::kPrompt ? std::size_t{1} : phase.ids.size();
          if (call.local + 1 != count) continue;
          auto &run = runs[call.session];
          const qwen35::cache::ReplayPrefix history{run.history, run.history->chunks.size(), run.history->length};
          (void)prefix_cache->publish(token_plans[call.session], run.session->head, history);
        }
        wave_observation.outputs = wave.calls.size();
        wave_observation.actual_tokens = executed_graph_tokens - tokens_before;
        wave_observation.graph_calls = executed_graph_calls - graphs_before;
        wave_observation.seconds = std::chrono::duration<double>(endpoint - wave_start).count();
        wave_observations.push_back(wave_observation);
      }
'''
(D/'runtime.inc').write_text(runtime)
print('runtime',len(runtime))
