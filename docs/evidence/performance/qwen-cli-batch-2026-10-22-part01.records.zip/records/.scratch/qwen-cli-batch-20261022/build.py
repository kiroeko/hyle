"""Rebuild only changed host TU; retain the proven native object closure."""
from pathlib import Path
import argparse,importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('batch_build',D.parent/'qwen-multisequence-20261021/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
h.Q=D
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=('qwen','prefix-tests'))
    p.add_argument('--attempt',type=int,default=1);p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--link',action='store_true')
    a=p.parse_args()
    if a.link:h.link(a.mode,a.attempt,a.owner_attempt)
    else:h.compile_owner(a.mode,a.attempt)
