from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('helpers',D/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.h.b,h.h.c
plan=c.read(D/'peer-build-plan.json');out=Path(plan['output_directory']);out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
source=D/'peer-batch.cc';frozen=b.identity(source)
for row in plan['retained_library_input_records']:assert b.identity(row['path'])==row
c.save(out/'plan.json',plan)
env,_=b.environment(plan['compile'],[],out);c.execute('compile',plan['compile'],env,out)
deps=c.read(out/'peer-deps.json')['Data'];record=dict(source=frozen,object=b.identity(out/'peer.obj'),command=plan['compile'],dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
assert b.identity(source)==frozen and all(b.identity(x['path'])==x for x in record['dependencies']);c.save(out/'identity.json',record)
inputs=[record['object'],*plan['retained_library_input_records']];c.save(out/'link-plan.json',dict(command=plan['link'],inputs=inputs,SDK_builds=0,NVCC=0))
env,_=b.environment(plan['link'],[x['path']for x in inputs],out);c.execute('link',plan['link'],env,out)
runtime=c.read(plan['runtime_environment_reference']);runtime['PATH']=env['PATH']
for dll in Path(plan['runtime_environment_reference']).parent.glob('*.dll'):os.link(dll,out/dll.name)
runtime['staged_dlls']=[b.identity(p)for p in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
c.save(D/'peer-ready.json',dict(image=b.identity(out/'peer.exe'),source=frozen,compile_identity=b.identity(out/'identity.json'),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),SDK_builds=0,NVCC=0,CXX=1,links=1))
print('PEER READY')
