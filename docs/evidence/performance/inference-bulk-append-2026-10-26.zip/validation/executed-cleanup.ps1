param([switch]$Delete)
$ErrorActionPreference = 'Stop'
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-reusable-state-20261026/case2/link/host-image-test.exe'; bytes=69577216; sha256='f2691dc6535855cbc84f58c6b283e0f747443412cbefbdcf23cbc11978c894f3' },
  @{ path='.scratch/inference-reusable-state-20261026/cuda2/link/host-image-test.exe'; bytes=141269504; sha256='1108b5715af8dae693810562cbd9a810a10dd0932c78f0693fcc1d2ec422cb97' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository scratch' }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
$current = @('inference-bulk-append-20261026/test/link/append-test.exe','inference-bulk-append-20261026/cpu-vulkan/link/host-image-test.exe','inference-bulk-append-20261026/cuda/link/host-image-test.exe','inference-bulk-append-20261026/formal/link/hyle.exe','inference-b2-reusable-state-20261026/link/hyle.exe')
foreach ($name in $current) {
  if (-not (Test-Path -LiteralPath (Join-Path $scope $name) -PathType Leaf)) { throw ('Current or control image missing: ' + $name) }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
$scriptHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
$receipt = [ordered]@{ status='REMOVED_TWO_SUPERSEDED_MODEL_TEST_IMAGES'; command='& .\test.ps1 -Delete'; executed_script_sha256=$scriptHash; logical_bytes=[Int64](($targets | Measure-Object -Property bytes -Sum).Sum); targets=$targets; current_and_AB_control_images_present=$true; all_objects_libraries_models_and_logs_retained=$true }
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $scope 'inference-bulk-append-20261026/cleanup-result.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 5
