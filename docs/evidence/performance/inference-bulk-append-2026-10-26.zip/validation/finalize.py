from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / 'docs/evidence/performance'
name = 'inference-bulk-append-2026-10-26'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

sources = ['include/hyle/graph/batch.h', 'include/hyle/graph/detail/region_access.h',
    'src/graph/resources.cc', 'src/graph_batch/paged_append.cc',
    'engine/models/qwen35/main.cc', 'tests/graph_batch/paged_append_graph_test.cc']
build = read(W / 'ready.json')
functions = read(W / 'run-summary.json')
speed = read(W / 'performance/summary.json')
assert len(build['compiled']) == 6 and len(build['artifacts']) == 4
assert all(x['process']['exit'] == 0 for x in build['compiled'])
assert all(x['link']['exit'] == 0 for x in build['artifacts'].values())
assert functions['status'] == 'SEVEN_FINITE_FUNCTION_PROCESSES_PASS'
assert all(x['process']['exit'] == 0 for x in functions['processes'])
assert speed['status'] == 'COMPLETE_8_DIRECT_AB_EXACT_WORK_AND_NONTIME_STABLE'
assert speed['cross_arm_complete_nontime_differences'] == speed['cross_arm_returned_ID_differences'] == 0
assert all(x['process']['exit'] == 0 for x in speed['runs'])
subprocess.run(['git', 'diff', '--', *sources], cwd=R, check=True,
    stdout=(W / 'applied-product-and-tests.diff').open('wb'))
report = dict(date='2026-10-26', status='FINITE_FUNCTION_PASS_DIRECT_AB_NO_SPEEDUP_PROVEN',
    git_before_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    sources=[pin(R / p) for p in sources],
    implementation=[
        'Generic Graph batch take_appends validates original transactions before consuming any reservation.',
        'One permission-suffix compaction uses existing cold scratch; original retirement, reader/writer recording qualification and successful whole-Graph latch remain.',
        'Ordinary/MTP target and independent NextN paths use the same bulk interface; no new executor, payload pool, native kernel or numeric operation.',
    ],
    function_checks=functions, compile_TUs=6, linked_images=4,
    targeted_contracts=['count/duplicate/foreign-tail/nonempty-destination rejection without consuming original transactions',
        'bulk subset followed by original single take, including failed whole-Graph work',
        'actual live Result observation rejects withdrawal, then original full bulk succeeds',
        'retained snapshot bytes, exact ready prefix, COW/tail and failure recovery in original append test',
        'tiny CPU/Vulkan/CUDA ordinary+MTP and lag1 host-state roundtrip'],
    direct_AB=dict(metrics=speed['metrics'], comparisons=speed['comparisons'],
        memory={arm:{k:record[k] for k in ['sampled_peaks', 'sample_count',
            'running_sample_count', 'actual_sample_gaps_ms', 'null_sample_counts',
            'ready_baseline', 'setup_error', 'thread_error', 'limits']}
            for arm,record in speed['memory'].items()},
        processes=8, fresh_timing_samples_per_arm=3,
        fresh_independent_memory_processes_per_arm=1, all_exit_zero=True,
        complete_nontime_reports_equal=True, returned_198_IDs_equal=True,
        fixed_input_rows=1728, physical_episodes=99, unchanged_link_inputs=221,
        changed_direct_objects=3, old_or_peer_samples_pooled=False),
    decision='Keep the common bulk ownership interface and remove repeated suffix compaction; no measured speedup claim. No additional samples or follow-up microexperiment.',
    retained_review_correction='Initial scratch helper had private-field access outside RegionAccess; fixed to a private member before the first compile. It was not a build failure.',
    limits=['No new llama.cpp comparison: this is retained-current Hyle versus candidate Hyle.',
        'Ordinary fixed equal-T B2 speed only; MTP functional checks do not establish MTP throughput.',
        'Three timing samples and one sampled memory run per arm are finite; all three speed ranges overlap.',
        'Apple and device-pending/driver-fault injection not run in this batch.',
        'Current KV frames still materialize/merge/reframe each step; immutable snapshots and per-step permissions remain.',
        'Control state-protocol and candidate state-protocol still have other costs; no new profiler or host-time attribution.'])
if (W / 'cleanup-result.json').exists():
    report['cleanup'] = read(W / 'cleanup-result.json')
archive = D / (name + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(W.rglob('*')):
        if not p.is_file() or 'candidate' in p.relative_to(W).parts:
            continue
        if p.suffix.lower() in {'.json', '.log', '.py', '.patch', '.diff', '.ps1'}:
            z.write(p, 'validation/' + p.relative_to(W).as_posix())
    for p in sources:
        z.write(R / p, 'source/' + p)
report['archive'] = pin(archive)
target = D / (name + '.json')
target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=report['status'], archive=report['archive'], report=pin(target)), ensure_ascii=False))
