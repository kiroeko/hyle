from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / "candidate"
changes = {}


def source(path):
    data = (ROOT / path).read_bytes()
    changes[path] = [data, data.decode("utf-8").replace("\r\n", "\n")]
    return changes[path][1]


def put(path, text):
    changes[path][1] = text


path = "include/hyle/graph/batch.h"
text = source(path)
old = "HYLE_GRAPH_BATCH_API Result<PagedAppendPages> take_append(Invocation&,NodeId)noexcept;"
new = old + """
// Atomically withdraw these original append transactions after actual whole-
// Graph retirement. Both spans have equal length and destinations are empty.
// Every node/owner is checked before any transaction is consumed. Failure or
// cancellation returns original reservations but never grants ready pages.
// Revokes replay/output observation exactly as take_append; no implicit wait.
HYLE_GRAPH_BATCH_API Status take_appends(Invocation&,std::span<const NodeId>,
    std::span<PagedAppendPages>)noexcept;"""
assert text.count(old) == 1
put(path, text.replace(old, new))

path = "include/hyle/graph/detail/region_access.h"
text = source(path)
old = "  HYLE_GRAPH_API static Status release_write_effect(Invocation&,NodeId) noexcept;"
new = old + """
  // One retired permission withdrawal for original projected writes and
  // writer-only effects. Nodes must be distinct, selected original writers.
  // Validate all before revoking preparation, then compact anonymous guards
  // once. Uses the existing cold ResourceEpisode scratch; no caller cache.
  HYLE_GRAPH_API static Status release_projected_writes(Invocation&,
      std::span<const NodeId>) noexcept;"""
assert text.count(old) == 1
text = text.replace(old, new)
old = "  static Status release_writer_preparation(Invocation&,std::uint32_t) noexcept;"
new = """  static bool writer_preserves_commands(const InvocationState&,std::uint32_t) noexcept;
""" + old
assert text.count(old) == 1
put(path, text.replace(old, new))

path = "src/graph/resources.cc"
text = source(path)
old = """  const auto&writer=state->plan->steps[writer_index];
  bool preserve_writer=false;
  if(!state->closed && state->phase.load(std::memory_order_acquire)==InvocationPhase::kIdle &&
      state->step_bindings[writer_index].stable_binding_identity && writer.kind==PlanStepKind::kRegion){
    const auto&prepared=writer.region.prepared_;
    const auto*table=prepared.vtable->query_extension?
        static_cast<const RegionProjectedWriteVTable*>(prepared.vtable->query_extension(
            prepared.state,kRegionProjectedWriteExtensionId)):nullptr;
    preserve_writer=table && table->preserves_commands &&
        table->preserves_commands(prepared,state->invocations[writer_index].region.state_);
  }
  if(preserve_writer)HYLE_RETURN_IF_ERROR(revoke_preparation(invocation));"""
new = "  if(writer_preserves_commands(*state,writer_index))HYLE_RETURN_IF_ERROR(revoke_preparation(invocation));"
assert text.count(old) == 1
text = text.replace(old, new)
anchor = "Status RegionAccess::release_writer_preparation(Invocation&invocation,std::uint32_t writer_index)noexcept{"
helper = """bool RegionAccess::writer_preserves_commands(const InvocationState&state,std::uint32_t writer_index)noexcept{
  const auto&writer=state.plan->steps[writer_index];
  if(state.closed || state.phase.load(std::memory_order_acquire)!=InvocationPhase::kIdle ||
      !state.step_bindings[writer_index].stable_binding_identity || writer.kind!=PlanStepKind::kRegion)
    return false;
  const auto&prepared=writer.region.prepared_;
  const auto*table=prepared.vtable->query_extension?
      static_cast<const RegionProjectedWriteVTable*>(prepared.vtable->query_extension(
          prepared.state,kRegionProjectedWriteExtensionId)):nullptr;
  return table && table->preserves_commands &&
      table->preserves_commands(prepared,state.invocations[writer_index].region.state_);
}
"""
assert text.count(anchor) == 1
text = text.replace(anchor, helper + anchor)
anchor = "bool RegionAccess::outcome_available(const Invocation&invocation)noexcept{"
addition = """Status RegionAccess::release_projected_writes(Invocation&invocation,
    std::span<const NodeId>nodes)noexcept{
  auto*state=InvocationAccess::state(invocation);
  if(!outcome_available(invocation))
    return Status::Unavailable("projected writes still have native work/results/observations");
  if(nodes.empty())return Status::Ok();
  if(!state->resources)return Status::InvalidArgument("projected writes have no original resource episode");
  const auto&plan=*state->plan;auto&episode=*state->resources.get();
  auto&marks=episode.unbind_steps;
  HYLE_FATAL_ASSERT(marks.size()==plan.steps.size());
  constexpr std::uint8_t selected=1,bound=2,invalidate=4;
  std::fill(marks.begin(),marks.end(),std::uint8_t{});
  // Scratch marks index original selected steps, never addresses or retained
  // authorities. Reject the complete list before touching native preparation.
  for(const auto node:nodes){
    if(GraphIdentity::generation(node)!=plan.generation || node.ordinal()>=plan.node_steps.size())
      return Status::InvalidArgument("projected writer belongs to another Graph/plan");
    const auto step=plan.node_steps[node.ordinal()];
    if(step>=marks.size() || step>=state->invocations.size() || step>=state->step_bindings.size() ||
        plan.steps[step].kind!=PlanStepKind::kRegion || !plan.steps[step].region.valid())
      return Status::InvalidArgument("projected writer has no original selected region");
    const auto&writer=plan.steps[step];
    if(writer.node_count!=1 || writer.node_set_begin>=plan.step_nodes.size() ||
        plan.step_nodes[writer.node_set_begin]!=node.ordinal())
      return Status::InvalidArgument("projected writer is not its original singleton node");
    if(marks[step]&selected)return Status::InvalidArgument("projected writer is duplicated");
    marks[step]|=selected;
  }
  for(const auto&entry:episode.bindings)
    if((entry.scope==BindingScope::kWrittenProjection && entry.value.valid()) ||
        entry.scope==BindingScope::kWriteEffect)
      if(entry.writer_step<marks.size() && (marks[entry.writer_step]&selected))
        marks[entry.writer_step]|=bound;
  bool revoke=false;
  for(const auto node:nodes){
    const auto step=plan.node_steps[node.ordinal()];
    if(!(marks[step]&bound))return Status::InvalidArgument("node has no original projected write binding");
    // Qualify before invalidation through the same helper as single release.
    if(writer_preserves_commands(*state,step))revoke=true;else marks[step]|=invalidate;
  }
  for(std::size_t i=0;i<episode.fixed_binding_count;++i){
    const auto&entry=episode.bindings[i];
    if(entry.scope!=BindingScope::kWrittenProjection || entry.writer_step>=marks.size() ||
        !(marks[entry.writer_step]&selected))continue;
    for(const auto&consumer:projected_input_consumers(plan,entry.value.ordinal()))
      if(!entry.permission_changes_preserve_commands ||
          !state->step_bindings[consumer.step].stable_binding_identity)
        marks[consumer.step]|=invalidate;
  }
  if(revoke)HYLE_RETURN_IF_ERROR(revoke_preparation(invocation));
  // No rejecting operation remains. Preserve only recordings qualified by
  // the original writer/reader and actual capture backend, as in single take.
  for(std::size_t i=0;i<marks.size();++i)
    if(marks[i]&invalidate)invalidate_step_recording(*state,static_cast<std::uint32_t>(i));
  episode.input_lease_candidates.clear();
  const auto first=episode.bindings.begin()+episode.fixed_binding_count;
  episode.bindings.erase(std::remove_if(first,episode.bindings.end(),[&](const auto&entry){
    if(entry.scope==BindingScope::kWriteEffect)
      return entry.writer_step<marks.size() && (marks[entry.writer_step]&selected);
    if(!entry.projection.valid())return false;
    const auto*owner=find_binding(state,entry.projection);
    return owner && owner->scope==BindingScope::kWrittenProjection &&
        owner->writer_step<marks.size() && (marks[owner->writer_step]&selected);
  }),episode.bindings.end());
  for(std::size_t i=0;i<episode.fixed_binding_count;++i){
    auto&entry=episode.bindings[i];
    if(entry.scope!=BindingScope::kWrittenProjection || entry.writer_step>=marks.size() ||
        !(marks[entry.writer_step]&selected))continue;
    const auto physical=plan.external_instances[entry.value.ordinal()];
    state->readable[physical]={};state->bound[physical]=0;clear_binding_owner(entry);
  }
  return Status::Ok();
}
"""
assert text.count(anchor) == 1
put(path, text.replace(anchor, addition + anchor))

path = "src/graph_batch/paged_append.cc"
text = source(path)
anchor = "Status PagedAppendAccess::reset(Invocation&invocation)noexcept{"
addition = """struct TakeSelection final {NodeId node;PagedAppendPages*pages=nullptr;Slot*slot=nullptr;};
Status inspect_take(void*opaque,const gd::RegionAccessView&view)noexcept{
  auto&selected=*static_cast<TakeSelection*>(opaque);
  NativeFind native{selected.node};HYLE_RETURN_IF_ERROR(find_native(&native,view));
  if(native.region.table){
    selected.pages=native.region.table->pages(native.region.invocation);
  }else{
    Find shared{selected.node};HYLE_RETURN_IF_ERROR(find(&shared,view));
    if(!shared.slot || !shared.slot->selected_first)
      return Status::InvalidArgument("paged append has no original selected-slot owner");
    selected.slot=shared.slot;selected.pages=&shared.slot->pages;
  }
  if(!selected.pages || !selected.pages->valid())
    return Status::InvalidArgument("paged append has no retained original transaction");
  return Status::Ok();
}
Status take_many(Invocation&invocation,std::span<const NodeId>nodes,
    std::span<PagedAppendPages>outputs)noexcept{
  if(nodes.size()!=outputs.size())return Status::InvalidArgument("append node and output counts differ");
  if(nodes.empty())return gd::RegionAccess::release_projected_writes(invocation,nodes);
  // Each selected region is directly indexed by its full original NodeId. The
  // second lookup below observes the same idle owner; no temporary cache or
  // allocation is needed to remember transaction addresses across withdrawal.
  for(std::size_t i=0;i<nodes.size();++i){
    if(outputs[i].valid())return Status::InvalidArgument("append destination already owns a transaction");
    TakeSelection selected{nodes[i]};
    HYLE_RETURN_IF_ERROR(gd::RegionAccess::visit_retired(invocation,nodes[i],&inspect_take,&selected));
  }
  const bool successful=gd::RegionAccess::successful_outcome(invocation);
  // Recording the original whole-Graph success is truthful even if a later
  // withdrawal rejects. It neither consumes a reservation nor publishes bytes.
  if(successful)HYLE_RETURN_IF_ERROR(latch_append_success(invocation));
  HYLE_RETURN_IF_ERROR(gd::RegionAccess::release_projected_writes(invocation,nodes));
  for(std::size_t i=0;i<nodes.size();++i){
    TakeSelection selected{nodes[i]};
    HYLE_FATAL_ASSERT(gd::RegionAccess::visit_retired(invocation,nodes[i],&inspect_take,&selected).ok());
    outputs[i]=std::move(*selected.pages);
    if(selected.slot){selected.slot->cache={};selected.slot->writer_only=false;selected.slot->writer_queue={};}
  }
  return Status::Ok();
}
"""
assert text.count(anchor) == 1
text = text.replace(anchor, addition + anchor)
old = "} // namespace detail\n} // namespace hyle::graph::batch"
new = """} // namespace detail
Status take_appends(Invocation&invocation,std::span<const NodeId>nodes,
    std::span<PagedAppendPages>outputs)noexcept{return detail::take_many(invocation,nodes,outputs);}
} // namespace hyle::graph::batch"""
assert text.count(old) == 1
put(path, text.replace(old, new))

path = "engine/models/qwen35/main.cc"
text = source(path)
anchor = "      for (std::size_t layer = 0; layer < page_inventory.keys.size(); ++layer) {\n        for (const auto bank : {layer * 2, layer * 2 + 1}) {\n          step.appends[bank] = take(g::batch::take_append(run, step.nodes[bank])); step.bound[bank] = false;\n        }\n        auto key = take(step.appends[layer * 2].ready()), value = take(step.appends[layer * 2 + 1].ready());"
new = """      const auto append_banks = draft_bank + (has_mtp(phase.family->role) ? 2u : 0u);
      check(g::batch::take_appends(run, std::span(step.nodes.data(), append_banks),
          std::span(step.appends.data(), append_banks)));
      std::fill_n(step.bound.begin(), append_banks, std::uint8_t{});
      for (std::size_t layer = 0; layer < page_inventory.keys.size(); ++layer) {
        auto key = take(step.appends[layer * 2].ready()), value = take(step.appends[layer * 2 + 1].ready());"""
assert text.count(anchor) == 1
text = text.replace(anchor, new)
old = """      if (has_mtp(phase.family->role)) {
        for (std::size_t bank = draft_bank; bank < draft_bank + 2; ++bank) {
          step.appends[bank] = take(g::batch::take_append(run, step.nodes[bank])); step.bound[bank] = false;
        }
        auto key = take(step.appends[draft_bank].ready()), value = take(step.appends[draft_bank + 1].ready());"""
new = """      if (has_mtp(phase.family->role)) {
        auto key = take(step.appends[draft_bank].ready()), value = take(step.appends[draft_bank + 1].ready());"""
assert text.count(old) == 1
put(path, text.replace(old, new))

path = "tests/graph_batch/paged_append_graph_test.cc"
text = source(path)
anchor = "Status writer_only(c::Context&context"
helper = """Status take_pair(g::Invocation&invocation,g::NodeId key,g::NodeId value,
 gb::PagedAppendPages&returned_key,gb::PagedAppendPages&returned_value){
 const std::array nodes{key,value};std::array<gb::PagedAppendPages,2>outputs;
 const auto short_output=gb::take_appends(invocation,nodes,std::span(outputs).first(1));
 HYLE_RETURN_IF_ERROR(check(short_output.IsInvalidArgument() && !outputs[0].valid() && !outputs[1].valid(),
  "bulk append count rejection consumed an original transaction"));
 const std::array duplicate{key,key};const auto duplicated=gb::take_appends(invocation,duplicate,outputs);
 HYLE_RETURN_IF_ERROR(check(duplicated.IsInvalidArgument() && !outputs[0].valid() && !outputs[1].valid(),
  "bulk append duplicate rejection consumed an original transaction"));
 HYLE_ASSIGN_OR_RETURN(auto foreign_builder,g::GraphBuilder::create());
 HYLE_ASSIGN_OR_RETURN(auto foreign,foreign_builder.add_node(c::Operation::custom(Reject{}),{}));
 const std::array foreign_tail{key,foreign};const auto invalid=gb::take_appends(invocation,foreign_tail,outputs);
 HYLE_RETURN_IF_ERROR(check(invalid.IsInvalidArgument() && !outputs[0].valid() && !outputs[1].valid(),
  "bulk append foreign tail consumed its valid earlier transaction"));
 HYLE_RETURN_IF_ERROR(gb::take_appends(invocation,nodes,outputs));
 HYLE_RETURN_IF_ERROR(check(outputs[0].valid() && outputs[1].valid(),"bulk append lost original transactions"));
 returned_key=std::move(outputs[0]);returned_value=std::move(outputs[1]);return Status::Ok();
}
"""
assert text.count(anchor) == 1
text = text.replace(anchor, helper + anchor)
old = " HYLE_ASSIGN_OR_RETURN(auto returned_k,gb::take_append(invocation,kw));\n HYLE_ASSIGN_OR_RETURN(auto returned_v,gb::take_append(invocation,vw));"
new = " gb::PagedAppendPages returned_k,returned_v;HYLE_RETURN_IF_ERROR(take_pair(invocation,kw,vw,returned_k,returned_v));"
assert text.count(old) == 1
text = text.replace(old, new)
old = " HYLE_ASSIGN_OR_RETURN(auto returned_k,gb::take_append(invocation,kw));HYLE_ASSIGN_OR_RETURN(auto returned_v,gb::take_append(invocation,vw));"
assert text.count(old) == 2 # Keep exclusive-tail's original single-take coverage.
put(path, text.replace(old, new, 1))

records = []
diffs = []
for path, (original, candidate) in changes.items():
    target = CANDIDATE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    original_text = original.decode("utf-8")
    if "\r\n" in original_text and original_text.count("\r\n") == original_text.count("\n"):
        candidate = candidate.replace("\n", "\r\n")
    encoded = candidate.encode("utf-8")
    target.write_bytes(encoded)
    records.append({"path": path, "base_sha256": hashlib.sha256(original).hexdigest(),
                    "candidate_sha256": hashlib.sha256(encoded).hexdigest(),
                    "base_bytes": len(original), "candidate_bytes": len(encoded)})
    diffs.extend(difflib.unified_diff(original_text.splitlines(True),
                                    candidate.splitlines(True),
                                    fromfile="a/" + path, tofile="b/" + path))
(HERE / "candidate.patch").write_bytes("".join(diffs).encode("utf-8"))
(HERE / "manifest.json").write_text(json.dumps({"status": "DRAFT_NOT_APPLIED_NOT_BUILT",
    "files": records}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "DRAFT_NOT_APPLIED_NOT_BUILT", "files": len(records),
    "patch_bytes": (HERE / "candidate.patch").stat().st_size}))
