"""Run the existing leaf image with its runtime PATH, without compiler setup."""
import hashlib
import importlib.util
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_existing_m2_leaf', S / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
plan_path, plan = b.checked(2)
ready = b.read(S / 'link2/ready.json')
for key in ('image', 'compile', 'plan'):
    b.require(ready[key])
out = S / 'run3'
out.mkdir(exist_ok=False)
weight = plan['original_weight']
with Path(weight['path']).open('rb') as stream:
    stream.seek(weight['offset'])
    data = stream.read(weight['bytes'])
if len(data) != weight['bytes']:
    raise ValueError('Original weight range short read')
b.save(out / 'inputs.json', dict(plan=b.identity(plan_path),
    original_weight_range=dict(weight, actual_sha256=hashlib.sha256(data).hexdigest()),
    activation=plan['activation'], runner=b.identity(__file__),
    preceding_setup_failure='run2 stopped before native launch: its helper treated the image as a compiler. Compile2/link2 remain unchanged.'))
del data
env = os.environ.copy()
env['PATH'] = b.read(b.CURRENT / 'runtime-environment.json')['PATH']
q = b.load('_existing_process_runner', b.R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
process = q.execute(plan['native_command'], env, out / 'run', timeout=600)
summary = dict(process=process, passed=False, input_record=b.identity(out / 'inputs.json'),
    throughput_scope='fixed four-bank serial working-set approximation only')
if not process['exit'] and not process['timed_out']:
    report = b.read(out / 'run/stdout.log')
    summary.update(passed=report.get('passed') is True, actual=report,
        loaded_cublasLt=b.identity(report['loaded_cublasLt']))
b.save(out / 'summary.json', summary)
print(summary['passed'], process['exit'])
sys.exit(0 if summary['passed'] else process['exit'] or 1)
