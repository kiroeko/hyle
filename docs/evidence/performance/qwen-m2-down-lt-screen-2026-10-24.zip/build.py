"""One host TU/Lt leaf diagnostic, prepared offline; only root executes actions."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
SOURCE = S / 'm2_down_leaf.cc'
PROVIDER = R / 'src/compute_provider_cublas/cublas_provider.cc'
COMPILE = R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/records/compute_provider_cublas--cublas_provider/identity.json'
CURRENT = R / '.scratch/qwen-mtp-quality-20261022/current-refresh-20261024/hyle-link2'
MANIFEST = R / '.scratch/qwen-mtp-window-20261022/inputs/mtp/weights.tsv'
ACTIVATION = R / '.scratch/compute-execution-refactor-2026-10-18/qwen35-layer0-probe/candidate/prefill/04-down-proj-input.bf16'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
def require(row):
    if identity(row['path']) != row: raise ValueError('Changed actual input: ' + row['path'])


def prepare(attempt):
    lines = MANIFEST.read_text(encoding='utf-8-sig').splitlines()
    if lines[0] != 'HYLE_QWEN35_TEXT_MTP_V1' or lines[2] != '4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155':
        raise ValueError('Actual Qwen original manifest differs')
    rows = [line.split('\t') for line in lines[3:] if line.split('\t')[0] == 'model.language_model.layers.0.mlp.down_proj.weight']
    if len(rows) != 1 or rows[0][1:5] != ['BF16', '2', '2048', '6144']: raise ValueError('Actual down weight schema differs')
    weight = Path(lines[1]); offset, size = map(int, rows[0][5:])
    if size != 25165824 or weight.stat().st_size < offset + size: raise ValueError('Missing actual down payload range')
    if ACTIVATION.stat().st_size != 23 * 6144 * 2: raise ValueError('Cached original T23 activation extent differs')
    compile_recipe, link = read(COMPILE), read(CURRENT / 'link-plan.json')
    compiler, linker = compile_recipe['command'][0], link['command'][0]
    include = next(arg[len('/external:I'):] for arg in compile_recipe['command'] if arg.startswith('/external:I') and arg.endswith('include'))
    libraries = []
    for name in ('cuda.lib', 'cublasLt.lib'):
        found = [Path(arg) for arg in link['command'] if Path(arg).name.lower() == name.lower()]
        if len(found) != 1 or not found[0].is_file(): raise ValueError('Actual current import library missing: ' + name)
        libraries.append(found[0])
    out = S / f'compile{attempt}'; image_dir = S / f'link{attempt}'; image = image_dir / 'm2-down-leaf.exe'
    compile_command = [compiler, '/nologo', '/c', '/std:c++20', '/EHsc', '/O2', '/Ob2', '/MD', '/DNDEBUG', '/DNOMINMAX',
        '/permissive-', '/Zc:preprocessor', '/fp:precise', '/W4', '/WX', '/external:I' + include, '/external:W0',
        '/sourceDependencies', str(out / 'dependencies.json'), str(SOURCE), '/Fo' + str(out / 'probe.obj'), '/Fd' + str(out / 'probe.pdb')]
    link_command = [linker, '/NOLOGO', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', str(out / 'probe.obj'), *map(str, libraries),
        '/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map'))]
    path = S / f'plan{attempt}.json'
    value = dict(prepared_only=True, source=identity(SOURCE), tool=identity(__file__), product_provider=identity(PROVIDER),
        compile_recipe=identity(COMPILE), actual_current_link=identity(CURRENT / 'link-plan.json'),
        runtime_environment=identity(CURRENT / 'runtime-environment.json'), manifest=identity(MANIFEST),
        original_weight=dict(path=str(weight), whole_file_bytes=weight.stat().st_size, role=rows[0][0], dtype='BF16', shape=[2048, 6144],
            offset=offset, bytes=size, original_range_sha256='computed from this range only immediately before an authorized run; no full-model hash/copy'),
        activation=identity(ACTIVATION), activation_selected_range=[0, 24575],
        activation_note='First2 rows of a retained real layer0 T23 prefill down-input trace. It is not a freshly captured MTP activation.',
        layout=dict(A=[2, 6144], A_order='row', lda=6144, B=[6144, 2048], B_order='column', ldb=6144,
            original_W=[2048, 6144], C_D=[2, 2048], C_D_order='row', ldc=2048, ldd=2048, transpose=['N','N'], batch_count=1,
            data_type='BF16', compute='CUBLAS_COMPUTE_32F', scale='CUDA_R_32F', alpha=1, beta=0, alignment_bytes=16,
            workspace_cap_bytes=33554432, reduction='CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE'),
        choices='Separate production request1 baseline; bounded request3; at most3 total distinct complete configurations, same original M2 descriptors.',
        cache_scope='Four equal original24MiB GPU banks rotate j%4 in one serial64-leaf graph. Query actual L2 and require96MiB>2xL2. One host launch/trial. Working-set approximation only, no PMU cache-miss/absolute cold bandwidth/modelTPS claim.',
        math_gate='Independent actual BF16 F64 dot, fixed gamma(2K+4) F32/FTZ bound, outward BF16 RNE endpoints. No baseline-output oracle or observed-error tolerance.',
        libraries=[identity(p) for p in libraries], compile_command=compile_command, link_command=link_command,
        native_command=[str(image), str(weight), str(offset), str(ACTIVATION)],
        CXX_compiles_executed=0, links_executed=0, native_runs_executed=0, product_source_changes=0, SDK_builds=0, NVCC_builds=0, HTTP_requests=0,
        falsification='No distinct valid alternative or no lower cost in this fixed four-bank rotation closes this algorithm screen. A faster candidate remains only a micro result pending separate real-journey validation; it does not explain the current101ms difference by itself.')
    if path.exists():
        if read(path) != value: raise ValueError('Preserve immutable plan attempt')
    else: save(path, value)
    return path, value


def checked(attempt):
    path = S / f'plan{attempt}.json'; value = read(path)
    for key in ('source','tool','product_provider','compile_recipe','actual_current_link','runtime_environment','manifest','activation'): require(value[key])
    for row in value['libraries']: require(row)
    if Path(value['original_weight']['path']).stat().st_size != value['original_weight']['whole_file_bytes']:
        raise ValueError('Original wholefile extent changed')
    return path, value


def execute(command, out, runtime=None):
    helper = load('_m2_existing_host_environment', R / '.scratch/native-paged-effects-20261022/build_windows.py')
    env, _ = helper.b.environment(command, [], out)
    if runtime is not None: env['PATH'] = runtime['PATH']
    q = load('_m2_existing_execute', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    return q.execute(command, env, out / 'run', timeout=600)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare','compile','link','run')); parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt <= 0: raise ValueError('Positive attempt required')
    if args.action == 'prepare':
        path, _ = prepare(args.attempt); print(json.dumps(dict(plan=identity(path), CXX_compiles=0, links=0, native_runs=0, HTTP=0))); return 0
    plan_path, plan = checked(args.attempt)
    out = S / (args.action + str(args.attempt)); out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
    if args.action == 'compile':
        result = execute(plan['compile_command'], out)
        if result['exit'] or result['timed_out']: raise SystemExit(result['exit'] or 1)
        require(plan['source']); deps = read(out / 'dependencies.json')['Data']
        save(out / 'identity.json', dict(source=plan['source'], object=identity(out / 'probe.obj'), plan=identity(plan_path), process=result,
            dependencies=[identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]))
    elif args.action == 'link':
        compiled = read(S / f'compile{args.attempt}/identity.json'); require(compiled['source']); require(compiled['object'])
        for row in compiled['dependencies']: require(row)
        result = execute(plan['link_command'], out)
        if result['exit'] or result['timed_out']: raise SystemExit(result['exit'] or 1)
        save(out / 'ready.json', dict(image=identity(out / 'm2-down-leaf.exe'), plan=identity(plan_path), compile=identity(S / f'compile{args.attempt}/identity.json'), process=result))
    else:
        ready = read(S / f'link{args.attempt}/ready.json'); require(ready['image']); require(ready['compile']); require(ready['plan'])
        weight = plan['original_weight']; digest = hashlib.sha256()
        with Path(weight['path']).open('rb') as stream:
            stream.seek(weight['offset']); remaining = weight['bytes']
            while remaining:
                block = stream.read(min(remaining,1048576))
                if not block: raise ValueError('Original weight range short read')
                digest.update(block); remaining -= len(block)
        save(out / 'inputs.json', dict(plan=identity(plan_path), original_weight_range=dict(weight, actual_sha256=digest.hexdigest()), activation=plan['activation']))
        result = execute(plan['native_command'], out, read(CURRENT / 'runtime-environment.json'))
        summary = dict(process=result, passed=False, input_record=identity(out / 'inputs.json'), throughput_scope='fixed four-bank serial working-set approximation only')
        if not result['exit'] and not result['timed_out']:
            report = read(out / 'run/stdout.log')
            summary.update(passed=report.get('passed') is True, actual=report, loaded_cublasLt=identity(report['loaded_cublasLt']))
        save(out / 'summary.json', summary)
        if not summary['passed']: raise SystemExit(result['exit'] or 1)
    return 0


if __name__ == '__main__': sys.exit(main())
