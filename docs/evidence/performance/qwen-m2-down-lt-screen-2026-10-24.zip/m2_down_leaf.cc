// Standalone cold Lt choice diagnostic. No product/provider/model code changes.
// Same M2 A/B/Y layout and preference contract as cublas_provider.cc.
// Four identical24MiB banks form one bounded rotation approximation; no PMU
// cache-miss or whole-decode claim. One graph contains all64 serial leaves.
#include <cuda.h>
#include <cublasLt.h>
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

namespace {
constexpr std::size_t M=2,K=6144,N=2048,Workspace=32*1024*1024;
constexpr std::size_t Banks=4,WeightBytes=N*K*2;
constexpr int MaxChoices=3,Trials=5,Replays=64;
void require(bool v,const char *s){if(!v)throw std::runtime_error(s);}
void cu(CUresult r,const char *s){if(r!=CUDA_SUCCESS)throw std::runtime_error(std::string(s)+": CUDA="+std::to_string(int(r)));}
void lt(cublasStatus_t r,const char *s){if(r!=CUBLAS_STATUS_SUCCESS)throw std::runtime_error(std::string(s)+": Lt="+std::to_string(int(r)));}
std::vector<std::uint16_t> read(const std::filesystem::path &p,std::uint64_t offset,std::size_t words){
  std::ifstream f(p,std::ios::binary);require(bool(f),"cannot open original source");
  f.seekg(static_cast<std::streamoff>(offset));std::vector<std::uint16_t> v(words);
  f.read(reinterpret_cast<char*>(v.data()),static_cast<std::streamsize>(words*2));
  require(f.gcount()==static_cast<std::streamsize>(words*2),"short original source range");return v;
}
float bf(std::uint16_t v){return std::bit_cast<float>(std::uint32_t(v)<<16);}
std::uint16_t rne(float v){auto u=std::bit_cast<std::uint32_t>(v);return std::uint16_t((u+0x7fffu+((u>>16)&1u))>>16);}
double gamma(std::size_t count,double u){return double(count)*u/(1-double(count)*u);}
struct Interval {float low=0,high=0;double center=0,bound=0;};
// Actual BF16 operands; independent F64 dot. Fixed gamma operation-count bound,
// not a baseline-output oracle or a tolerance fitted to observed differences.
std::vector<Interval> oracle(const std::vector<std::uint16_t>&a,const std::vector<std::uint16_t>&w){
  const auto normal=[](std::uint16_t u){const float f=bf(u);return std::isfinite(f)&&(f==0||std::abs(f)>=std::numeric_limits<float>::min());};
  require(std::all_of(a.begin(),a.end(),normal)&&std::all_of(w.begin(),w.end(),normal),"oracle domain: finite normal/zero BF16 inputs");
  std::vector<Interval> out(M*N);
  for(std::size_t m=0;m<M;++m)for(std::size_t n=0;n<N;++n){
    double sum=0,absolute=0;
    for(std::size_t k=0;k<K;++k){const double p=double(bf(a[m*K+k]))*double(bf(w[n*K+k]));sum+=p;absolute+=std::abs(p);}
    require(absolute<double(std::numeric_limits<float>::max())/16,"oracle sum overflow domain");
    const double sum_upper=std::nextafter(absolute/(1-gamma(K,std::ldexp(1.0,-53))),std::numeric_limits<double>::infinity());
    const double f64=gamma(K,std::ldexp(1.0,-53))*sum_upper;
    // <=K products + <=K additions across F32 dot/split-K; compute-type
    // reduction only. F32 FTZ loss is bounded absolutely, no scaled partials.
    const double native=gamma(2*K+4,std::ldexp(1.0,-24))*sum_upper+
      (2*double(K)*std::numeric_limits<float>::min())/(1-(2*double(K)+4)*std::ldexp(1.0,-24));
    const double bound=std::nextafter(native+f64,std::numeric_limits<double>::infinity());
    const float low=bf(rne(std::nextafter(float(sum-bound),-std::numeric_limits<float>::infinity())));
    const float high=bf(rne(std::nextafter(float(sum+bound),std::numeric_limits<float>::infinity())));
    require(std::isfinite(low)&&std::isfinite(high),"oracle BF16 store overflow");
    require((low==0||std::abs(low)>=std::numeric_limits<float>::min())&&
            (high==0||std::abs(high)>=std::numeric_limits<float>::min()),"oracle BF16 subnormal result domain");
    out[m*N+n]={low,high,sum,bound};
  }return out;
}
struct Device {
  CUdevice device=0;CUcontext context=nullptr;CUstream stream=nullptr;
  CUdeviceptr a=0,y=0,workspace=0;std::array<CUdeviceptr,Banks> banks{};
  ~Device(){if(stream)(void)cuStreamSynchronize(stream);for(auto p:banks)if(p)(void)cuMemFree(p);for(auto p:{workspace,y,a})if(p)(void)cuMemFree(p);
    if(stream)(void)cuStreamDestroy(stream);if(context)(void)cuDevicePrimaryCtxRelease(device);}
};
struct Lt {
  cublasLtHandle_t handle=nullptr;cublasLtMatmulDesc_t op=nullptr;cublasLtMatmulPreference_t pref=nullptr;
  std::array<cublasLtMatrixLayout_t,3> layouts{};
  ~Lt(){for(auto x:layouts)if(x)(void)cublasLtMatrixLayoutDestroy(x);if(pref)(void)cublasLtMatmulPreferenceDestroy(pref);
    if(op)(void)cublasLtMatmulDescDestroy(op);if(handle)(void)cublasLtDestroy(handle);}
};
std::array<std::uint32_t,9> config(const cublasLtMatmulAlgo_t&a){
  std::array<std::uint32_t,9> result{};
  for(std::size_t i=0;i<result.size();++i){std::size_t written=0;
    if(i<7){lt(cublasLtMatmulAlgoConfigGetAttribute(&a,cublasLtMatmulAlgoConfigAttributes_t(i),&result[i],sizeof(result[i]),&written),"algorithm attribute");require(written==4,"unexpected algorithm attribute size");}
    else{std::uint16_t small=0;lt(cublasLtMatmulAlgoConfigGetAttribute(&a,cublasLtMatmulAlgoConfigAttributes_t(i),&small,sizeof(small),&written),"algorithm shape attribute");require(written==2,"unexpected shape attribute size");result[i]=small;}
  }return result;
}
struct Choice {
  cublasLtMatmulHeuristicResult_t selected{};std::array<std::uint32_t,9> key{};
  CUgraph graph=nullptr;CUgraphExec executable=nullptr;CUevent begin=nullptr,end=nullptr;
  std::array<double,Trials> milliseconds{},host_milliseconds{};std::size_t different_from_baseline=0;
  ~Choice(){if(begin)(void)cuEventDestroy(begin);if(end)(void)cuEventDestroy(end);if(executable)(void)cuGraphExecDestroy(executable);if(graph)(void)cuGraphDestroy(graph);}
};
std::string quote(const std::string&s){std::string o="\"";for(char c:s){if(c=='\\'||c=='\"')o+='\\';o+=c;}return o+'\"';}
} // namespace

int main(int argc,char**argv){try{
  require(argc==4,"usage: probe ORIGINAL_WEIGHT_FILE WEIGHT_BYTE_OFFSET ACTUAL_BF16_ACTIVATION_TRACE");
  std::size_t consumed=0;const auto offset=std::stoull(argv[2],&consumed);require(consumed==std::strlen(argv[2]),"invalid source offset");
  const auto weights=read(argv[1],offset,N*K),activation=read(argv[3],0,M*K);
  const auto expected=oracle(activation,weights);
  Device d;cu(cuInit(0),"init");cu(cuDeviceGet(&d.device,0),"device");cu(cuDevicePrimaryCtxRetain(&d.context,d.device),"primary");cu(cuCtxSetCurrent(d.context),"current");
  int l2_bytes=0;cu(cuDeviceGetAttribute(&l2_bytes,CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE,d.device),"actual L2 bytes");
  require(l2_bytes>0&&Banks*WeightBytes>2*std::size_t(l2_bytes),"four-bank working set must exceed twice actual L2");
  cu(cuStreamCreate(&d.stream,CU_STREAM_NON_BLOCKING),"stream");
  cu(cuMemAlloc(&d.a,M*K*2),"A");cu(cuMemAlloc(&d.y,M*N*2),"Y");cu(cuMemAlloc(&d.workspace,Workspace),"workspace");
  require(d.a%16==0&&d.y%16==0&&d.workspace%256==0,"actual pointer alignment");
  cu(cuMemcpyHtoD(d.a,activation.data(),M*K*2),"upload A");
  for(auto &bank:d.banks){cu(cuMemAlloc(&bank,WeightBytes),"B bank");require(bank%16==0,"actual B bank alignment");cu(cuMemcpyHtoD(bank,weights.data(),WeightBytes),"upload same original B");}
  Lt l;lt(cublasLtCreate(&l.handle),"Lt handle");lt(cublasLtMatmulDescCreate(&l.op,CUBLAS_COMPUTE_32F,CUDA_R_32F),"operation");
  constexpr std::array<std::uint64_t,3> rows{M,K,M},cols{K,N,N};constexpr std::array<std::int64_t,3> ld{K,K,N};
  constexpr std::array<cublasLtOrder_t,3> order{CUBLASLT_ORDER_ROW,CUBLASLT_ORDER_COL,CUBLASLT_ORDER_ROW};
  for(std::size_t i=0;i<3;++i){lt(cublasLtMatrixLayoutCreate(&l.layouts[i],CUDA_R_16BF,rows[i],cols[i],ld[i]),"layout");
    lt(cublasLtMatrixLayoutSetAttribute(l.layouts[i],CUBLASLT_MATRIX_LAYOUT_ORDER,&order[i],sizeof(order[i])),"layout order");}
  lt(cublasLtMatmulPreferenceCreate(&l.pref),"preference");
  lt(cublasLtMatmulPreferenceSetAttribute(l.pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&Workspace,sizeof(Workspace)),"workspace preference");
  const std::uint32_t reduction=CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE,align=16;
  lt(cublasLtMatmulPreferenceSetAttribute(l.pref,CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK,&reduction,sizeof(reduction)),"reduction preference");
  for(auto attribute:{CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES})
    lt(cublasLtMatmulPreferenceSetAttribute(l.pref,attribute,&align,sizeof(align)),"alignment preference");
  std::array<cublasLtMatmulHeuristicResult_t,MaxChoices+1> queried{};int count=0;
  lt(cublasLtMatmulAlgoGetHeuristic(l.handle,l.op,l.layouts[0],l.layouts[1],l.layouts[2],l.layouts[2],l.pref,1,&queried[0],&count),"production request1");
  require(count==1&&queried[0].state==CUBLAS_STATUS_SUCCESS,"production algorithm missing");
  lt(cublasLtMatmulAlgoGetHeuristic(l.handle,l.op,l.layouts[0],l.layouts[1],l.layouts[2],l.layouts[2],l.pref,MaxChoices,&queried[1],&count),"bounded request3");
  std::vector<std::unique_ptr<Choice>> choices;
  for(int i=0;i<=count&&choices.size()<std::size_t(MaxChoices);++i){const auto &candidate=queried[std::size_t(i)];if(candidate.state!=CUBLAS_STATUS_SUCCESS)continue;
    const auto key=config(candidate.algo);if(std::any_of(choices.begin(),choices.end(),[&](const auto&x){return x->key==key;}))continue;
    require(candidate.workspaceSize<=Workspace,"heuristic exceeded original workspace cap");
    require(key[2]<=1||key[3]==std::uint32_t(CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE),"candidate changed partial precision");
    cublasLtMatmulHeuristicResult_t checked{};
    lt(cublasLtMatmulAlgoCheck(l.handle,l.op,l.layouts[0],l.layouts[1],l.layouts[2],l.layouts[2],&candidate.algo,&checked),"algorithm check");
    require(checked.state==CUBLAS_STATUS_SUCCESS&&checked.workspaceSize<=candidate.workspaceSize,"algorithm workspace check differs");
    auto value=std::make_unique<Choice>();value->selected=candidate;value->key=key;choices.push_back(std::move(value));
  }
  require(!choices.empty(),"no legal original-layout algorithm");
  const float alpha=1,beta=0;
  const auto launch=[&](Choice&choice,std::size_t bank){lt(cublasLtMatmul(l.handle,l.op,&alpha,reinterpret_cast<void*>(d.a),l.layouts[0],reinterpret_cast<void*>(d.banks[bank]),l.layouts[1],
      &beta,reinterpret_cast<void*>(d.y),l.layouts[2],reinterpret_cast<void*>(d.y),l.layouts[2],&choice.selected.algo,reinterpret_cast<void*>(d.workspace),choice.selected.workspaceSize,d.stream),"same-M2 matmul");};
  std::vector<std::uint16_t> baseline;
  for(auto &choice:choices){launch(*choice,0);cu(cuStreamSynchronize(d.stream),"numeric retirement");std::vector<std::uint16_t> y(M*N);cu(cuMemcpyDtoH(y.data(),d.y,M*N*2),"actual BF16 Y");
    for(std::size_t i=0;i<y.size();++i){const float value=bf(y[i]);if(!std::isfinite(value)||value<expected[i].low||value>expected[i].high)
      throw std::runtime_error("independent F64/F32/BF16 interval failed at "+std::to_string(i)+" algorithm="+std::to_string(choice->key[0]));}
    if(baseline.empty())baseline=y;else for(std::size_t i=0;i<y.size();++i)choice->different_from_baseline+=y[i]!=baseline[i];
    launch(*choice,0);cu(cuStreamSynchronize(d.stream),"cold warmup retirement");
    cu(cuStreamBeginCapture(d.stream,CU_STREAM_CAPTURE_MODE_GLOBAL),"capture serial original M2 rotation");
    for(int leaf=0;leaf<Replays;++leaf)launch(*choice,std::size_t(leaf)%Banks);
    cu(cuStreamEndCapture(d.stream,&choice->graph),"finish capture");
    cu(cuGraphInstantiate(&choice->executable,choice->graph,0),"instantiate");cu(cuEventCreate(&choice->begin,CU_EVENT_DEFAULT),"begin event");cu(cuEventCreate(&choice->end,CU_EVENT_DEFAULT),"end event");
  }
  // Alternating choice order; one host launch per trial. Four equal original
  // banks exceed2x actual L2, but no PMU miss/absolute cold-bandwidth claim.
  for(int trial=0;trial<Trials;++trial)for(std::size_t step=0;step<choices.size();++step){
    const std::size_t index=(step+std::size_t(trial))%choices.size();auto &choice=*choices[index];
    const auto begin=std::chrono::steady_clock::now();cu(cuEventRecord(choice.begin,d.stream),"time begin");
    cu(cuGraphLaunch(choice.executable,d.stream),"one serial64-leaf graph");
    cu(cuEventRecord(choice.end,d.stream),"time end");cu(cuEventSynchronize(choice.end),"time retirement");
    const auto end=std::chrono::steady_clock::now();float milliseconds=0;cu(cuEventElapsedTime(&milliseconds,choice.begin,choice.end),"event duration");
    choice.milliseconds[std::size_t(trial)]=double(milliseconds)/Replays;
    choice.host_milliseconds[std::size_t(trial)]=std::chrono::duration<double,std::milli>(end-begin).count()/Replays;
  }
  char device_name[256]{};cu(cuDeviceGetName(device_name,int(sizeof(device_name)),d.device),"device name");
  HMODULE module=nullptr;char module_path[32768]{};
  require(GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
      reinterpret_cast<LPCSTR>(&cublasLtCreate),&module)!=0,"loaded Lt module");
  require(GetModuleFileNameA(module,module_path,DWORD(sizeof(module_path)))!=0,"loaded Lt path");
  std::cout<<std::setprecision(17)<<"{\"passed\":true,\"scope\":\"four-bank serial working-set approximation, no PMU cache-miss or real decode claim\",\"m\":2,\"k\":6144,\"n\":2048,\"workspace_cap\":"<<Workspace
    <<",\"cublasLt_version\":"<<cublasLtGetVersion()<<",\"loaded_cublasLt\":"<<quote(module_path)<<",\"device\":"<<quote(device_name)
    <<",\"weight_bank_count\":"<<Banks<<",\"weight_working_set_bytes\":"<<Banks*WeightBytes<<",\"actual_L2_bytes\":"<<l2_bytes
    <<",\"graph_leaves\":"<<Replays<<",\"host_graph_launches_per_trial\":1,\"trials\":"<<Trials<<",\"gate\":\"independent F64 dot + fixed gamma(2K+4) F32/FTZ bound + outward BF16 RNE endpoints\",\"choices\":[";
  for(std::size_t i=0;i<choices.size();++i){auto &choice=*choices[i];auto times=choice.milliseconds;std::sort(times.begin(),times.end());
    std::cout<<(i?",":"")<<"{\"baseline_request1\":"<<(i==0?"true":"false")<<",\"config\":[";
    for(std::size_t j=0;j<choice.key.size();++j)std::cout<<(j?",":"")<<choice.key[j];
    std::cout<<"],\"workspace_bytes\":"<<choice.selected.workspaceSize<<",\"BF16_values_different_from_baseline\":"<<choice.different_from_baseline<<",\"device_ms_per_leaf\":[";
    for(int j=0;j<Trials;++j)std::cout<<(j?",":"")<<choice.milliseconds[std::size_t(j)];
    std::cout<<"],\"host_ms_per_leaf\":[";for(int j=0;j<Trials;++j)std::cout<<(j?",":"")<<choice.host_milliseconds[std::size_t(j)];
    std::cout<<"],\"device_ms_median\":"<<times[Trials/2]<<"}";
  }std::cout<<"]}\n";return 0;
}catch(const std::exception&e){std::cerr<<"M2 leaf diagnostic failed: "<<e.what()<<'\n';return 1;}}
