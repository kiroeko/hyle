"""Offline closure of the sole instrumented run; never launches a process."""
from pathlib import Path
import hashlib
import json

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OUT = WORK / 'attempt1'

def read(path): return json.loads(path.read_bytes())
def pin(path):
    b=path.read_bytes()
    return {'path':str(path.resolve()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

s=read(OUT/'summary.json')
e=read(OUT/'run/paired-events.json')
parents={p['ordinal']:p for p in e['prepares']}
all_group=s['groups']['all']
parent_total=sum(v['total_ms'] for v in all_group['buckets'].values())+all_group['commands_route_publication_cleanup']['total_ms']
child_total=(sum(v['total_ms'] for v in s['range_summary']['recorded'].values())+
    s['range_summary']['reuse_lookup']['total_ms']+s['range_summary']['reuse_cleanup']['total_ms']+
    all_group['loop_control_EXCLUSIVE']['total_ms'])
assert abs(parent_total-all_group['whole_prepare_replay']['total_ms']) < 1e-10
assert abs(child_total-all_group['buckets']['range_loop_INCLUSIVE']['total_ms']) < 1e-10
for r in e['ranges']:
    p=parents[r['parent']]
    assert p['ticks'][5] <= r['ticks'][0] <= r['ticks'][7] <= p['ticks'][6]

records=[]
for r in e['ranges']:
    if r['outcome'] != 2: continue
    p=parents[r['parent']]
    records.append({'prepare_ordinal':r['parent'],'sequence_one_based':r['parent']+1,
        'original_prepared':p['original_prepared_fact'],
        'range_begin':r['begin'],'range_step_count':r['count'],'command_count':r['commands'],
        'range_class':'body' if r['count']==1269 else 'front',
        'range_wall_ms':(r['ticks'][7]-r['ticks'][0])/1e6,
        'lookup_setup_ms':(r['ticks'][1]-r['ticks'][0])/1e6,
        'begin_ms':(r['ticks'][2]-r['ticks'][1])/1e6,
        'dispatch_ms':(r['ticks'][3]-r['ticks'][2])/1e6,
        'end_native_build_ms':(r['ticks'][4]-r['ticks'][3])/1e6,
        'finish_wait_ms':(r['ticks'][5]-r['ticks'][4])/1e6,
        'key_publication_ms':(r['ticks'][6]-r['ticks'][5])/1e6,
        'range_cleanup_ms':(r['ticks'][7]-r['ticks'][6])/1e6})
save(OUT/'record-table.json',records)
by_class={}
for name in ['body','front']:
    selected=[r for r in records if r['range_class']==name]
    by_class[name]={'count':len(selected),
        **{key:sum(r[key] for r in selected) for key in records[0] if key.endswith('_ms')},
        'sequence_one_based':[r['sequence_one_based'] for r in selected]}
memo={
    'status':s['status'],'scope':'Exactly one instrumented current2a94 Hyle original K1/two-turn process. No Nsight, peer, additional benchmark or repeated sample.',
    'process':s['process'],'GPU':'RELEASED at terminal before offline parsing',
    'facts':{'complete':s['completeness'],'full_report_non_time_differences':s['non_time_difference_count'],
        'original_stderr_equal_after_clock_values_only':s['original_stderr_equal_after_clock_values_only'],
        'preparation_observation_mapping':'68 Graph prepare calls match all68 original prepared log rows in order, and every per-call recorded/reused count agrees. Two prefills are requested Commands with seen159;66 decodes requested PreferCapture seen255.',
        'recorded_ranges':s['recorded'],'reused_ranges':s['reused'],
        'new_compile_TUs':1,'other_absolute_link_inputs_exact':221,
        'compile':read(OUT/'ready.json')['processes']['compile'],
        'link':read(OUT/'ready.json')['processes']['link'],
        'dependency_check':read(OUT/'compile/dependency-check.json')},
    'parent_closure':{'prepare_replay_total_ms':all_group['whole_prepare_replay']['total_ms'],
        'disjoint_parent_sum_ms':parent_total,'child_plus_exclusive_control_matches_range_loop_ms':child_total,
        'cold_batch_total_ms':all_group['original_cold_batch']['total_ms'],
        'outside_prepare_replay_ms':all_group['outer_cold_minus_prepare_replay']['total_ms'],
        'warning':'Original cold_batch seconds are printed with finite precision; outside difference is same-call elapsed envelope, not CPU/GPU attribution.'},
    'groups':s['groups'],'range_summary':s['range_summary'],'record_class_totals':by_class,
    'largest_record_dispatch':max(records,key=lambda r:r['dispatch_ms']),
    'largest_record_end':max(records,key=lambda r:r['end_native_build_ms']),
    'decision':[
        'Actual body10 record dispatch22.6239ms and end_capture16.7556ms dominate the observed recording path. Front17 dispatch3.1813ms/end0.8714ms are separate. Counts are current-run facts, not old15body extrapolation.',
        'Graph Queue/prelude, dependency/input routes, cache qualification, publication and finish real-wait buckets are small here. No evidence justifies changing their permission/retirement contracts.',
        'Warm45 cold bindings9.3682ms (208.182us/episode; median214.4us) dominate the small prepare_replay portion, but cannot by themselves explain the historical roughly1.5ms algebraic whole-episode gap. The function already has revision/span reuse and still seals original readiness; this result does not justify a speculative dirty-bit mechanism.',
        'The strongest unresolved implementation boundary is now concrete: enqueue_segment_steps dispatch vs CommandCaptureAccess::end/native backend. Existing ggml provider timing is another process and cannot split this dispatch25.8052ms. End includes StreamEndCapture, eligible ExecUpdate or Instantiate, graph destruction and artifact/status ownership; this run cannot label individual calls instantiate/update or pure CPU.',
        'If another diagnostic is warranted later, a single backend-host end_capture split (EndCapture / eligible update / instantiate / destruction+artifact publication) would distinguish the17.6270ms. Do not run it automatically or infer recoverable time from this measurement.',
        'No product optimization or throughput claim follows from this instrumented process. No old provider15.2907ms, old Nsight capture walls or peer elapsed endpoints are subtracted.'],
    'source_anchors':[
        {'file':pin(ROOT/'src/graph/executable.cc'),'lines':[1444,1468,9493,9618,9750,9762,9833,9847,9859,9862,9880],
         'meaning':'Cold native/operation prepare hooks; original prepare_replay parent and capture child boundaries, original finish/retain/wait and key publication unchanged.'},
        {'file':pin(ROOT/'src/graph/submission.cc'),'lines':[371,415],
         'meaning':'Dispatch loops all selected emitting steps (region/operation/copy), not just ggml and not one invocation per kernel.'},
        {'file':pin(ROOT/'src/compute_backend_cuda/cuda_backend.cc'),'lines':[1271,1285,1312,1349,1374],
         'meaning':'Native end window combines StreamEndCapture, update/instantiate policy and immutable artifact/status lifetime work; no explicit GraphUpload here.'},
        {'file':pin(ROOT/'engine/models/qwen35/main.cc'),'lines':[3692,3821,3836,3847],
         'meaning':'Original cold_batch surrounds preceding layout/batch/input work in addition to prepare_replay.'}],
    'first_offline_failure':pin(OUT/'analysis-first-failure.json'),
    'pins':{'summary':pin(OUT/'summary.json'),'records':pin(OUT/'record-table.json'),
        'events':pin(OUT/'run/events.json'),'paired_events':pin(OUT/'run/paired-events.json'),
        'ready':pin(OUT/'ready.json'),'source_pins':pin(WORK/'source-pins.json'),
        'review':pin(WORK/'independent-review-architecture.json'),
        'source_patch':pin(WORK/'source.patch'),'runner':pin(WORK/'check.py'),
        'raw':s['raw']},
    'limits':['CPU elapsed contains original native API calls and possible waits; no GPU activity union measured.',
        'Parent range-loop includes children. Only parent exclusive control plus child buckets may be summed.',
        'Mode is requested mode, not proof of selected route. Original prepared replay and actual record/reuse facts remain authoritative.',
        'Normal exit and all counts/masks/overflow were checked. Clock overhead is not calibrated; timings are diagnostic, not a benchmark.',
        'No additional Model/GPU/compile/profiler process was launched to repair the initial offline Commands-mask assertion.']}
save(WORK/'memo.json',memo)
print(json.dumps({'memo':pin(WORK/'memo.json'),'records':pin(OUT/'record-table.json'),'status':memo['status']},indent=2))
