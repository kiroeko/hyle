"""Publish this completed diagnostic only; no inference/compiler subprocess."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
OUT=WORK/'attempt1'
BASE=ROOT/'.scratch/inference-current-closure-20261026'
STEM='mtp-graph-prepare-attribution-2026-10-26'
PUBLIC=ROOT/'docs/evidence/performance'

def read(path): return json.loads(path.read_bytes())
def digest(raw): return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pin(path): return {'path':str(path.resolve()),**digest(path.read_bytes())}
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def exact(row):
    assert digest(Path(row['path']).read_bytes())=={k:row[k] for k in ['bytes','sha256']}

def main():
    destination=PUBLIC/(STEM+'.zip')
    report_path=PUBLIC/(STEM+'.json')
    assert not destination.exists() and not report_path.exists(), 'Do not overwrite published evidence'
    s=read(OUT/'summary.json'); m=read(WORK/'memo.json'); ready=read(OUT/'ready.json')
    assert s['status']=='PASS_CURRENT_GRAPH_CLOCK_DIAGNOSTIC_NOT_TPS'
    assert s['non_time_difference_count']==0 and s['original_stderr_equal_after_clock_values_only']
    assert s['recorded']==27 and s['reused']==105
    assert [s['groups'][n]['count'] for n in ['prefill','decode_has_record','decode_no_record']]==[2,21,45]
    assert ready['baseline_image']['sha256']=='2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
    assert ready['absolute_inputs']==222 and ready['unchanged_absolute_inputs']==221
    assert all(s['completeness'][k]==0 for k in ['prepare_overflow','range_overflow'])
    for row in [*read(OUT/'link-inputs.json'),ready['image'],ready['source']]: exact(row)
    baseline=Path(next(row for row in read(BASE/'full-window/two-turn-timing/runs.json') if row['arm']=='hyle_mtp')['folder'])
    compact_groups={name:{'count':g['count'],'cold_batch_total_ms':g['original_cold_batch']['total_ms'],
        'prepare_replay_total_ms':g['whole_prepare_replay']['total_ms'],
        'outside_prepare_replay_ms':g['outer_cold_minus_prepare_replay']['total_ms'],
        'cold_bindings':g['buckets']['cold_bindings'],
        'range_loop_INCLUSIVE_ms':g['buckets']['range_loop_INCLUSIVE']['total_ms'] if g['buckets']['range_loop_INCLUSIVE']['count'] else None,
        'loop_control_EXCLUSIVE_ms':g['loop_control_EXCLUSIVE']['total_ms'] if g['loop_control_EXCLUSIVE']['count'] else None}
        for name,g in s['groups'].items()}
    report={'schema':'hyle-performance-evidence-v1',
        'status':'BOUNDED_CURRENT_GRAPH_PREPARE_ATTRIBUTION_COMPLETE_NOT_TPS','date':'2026-10-26',
        'scope':'One private Graph executable.cc host TU, exact current2a94 closure relink, one original K1 two-turn CUDA process. Fixed POD CPU-elapsed diagnostic only; no profiler or peer run.',
        'closure':{'baseline_image':ready['baseline_image'],'diagnostic_image':ready['image'],
            'source':ready['source'],'source_pins':ready['source_pins'],
            'graph_object':ready['graph_object'],'absolute_link_inputs':222,'unchanged_absolute_link_inputs':221,
            'current_project_dependency_count':86,'actual_dependency_count':255,
            'dependency_check':ready['dependency_check'],
            'native':ready['native'],'runtime':ready['runtime'],
            'current_build_evidence':pin(ROOT/'docs/evidence/research/inference-current-source-build-2026-10-26.json'),
            'current_window_evidence':pin(ROOT/'docs/evidence/performance/inference-current-window-2026-10-26.json')},
        'actual_processes':{**ready['processes'],'single_model_run':s['process'],
            'GPU_released_at_model_terminal_before_offline_analysis':True,
            'additional_app_core_provider_device_SDK_builds':0,'additional_model_processes':0},
        'completeness':s['completeness'],
        'work':{'baseline_command':pin(baseline/'command.json'),
            'full_JSON_non_time_difference_count':0,
            'original_stderr_equal_after_removing_only_diagnostic_lines_and_original_clock_values':True,
            'normalization':'Literal retained behavior.py functions; recursive fields whose names contain seconds/tokens_per_second/clock_unix/unix_ns/unix_ms are original clock exclusions. No work/ledger/RNG/cache metadata exclusions.',
            'prepare_log_mapping':'68 prepare calls align by actual original prepared-log order and exact per-call recorded/reused counts. Prefill2, recorded decode21, no-record decode45; do not call all68 decode.'},
        'boundaries':{'source_only_plan':pin(BASE/'next-cold-clock-boundaries.json'),
            'prepare_ticks':read(WORK/'plan.json')['prepare_ticks'],
            'range_ticks':read(WORK/'plan.json')['range_ticks'],
            'parent_children':'Parent range-loop is inclusive of children. Exclusive loop/control is computed only after subtracting all matching contained child intervals; never sum inclusive parent and children.',
            'mode_and_absent_ticks':'Mode is requested mode. Two original Commands prefills have seen159 and no range-loop ticks;66 decode preparations seen255. Reused ranges seen131; recorded ranges seen255. Missing ticks are unknown, never fabricated zero intervals.',
            'CPU_elapsed':'Buckets include original native API calls and real waits; no GPU union or pure-CPU classification is available.',
            'normal_exit_only':'Static dump owns only POD/stdio, no resources; actual normal-exit marker, attempted==finished, contiguous ordinals, stage masks, monotonic ticks and zero overflows checked.'},
        'groups':compact_groups,'parent_closure':m['parent_closure'],
        'range_summary':s['range_summary'],'record_class_totals':m['record_class_totals'],
        'largest_record_dispatch':m['largest_record_dispatch'],'largest_record_end':m['largest_record_end'],
        'first_offline_failure':read(OUT/'analysis-first-failure.json'),
        'findings':m['decision'][:-1],
        'old_provider_boundary':{'old_provider_total_ms':15.2907,
            'evidence':pin(ROOT/'docs/evidence/performance/new-hotspots-2026-10-26.json'),
            'rule':'Different process and historical703 closure. Never subtract15.2907ms from this run, nor old15-body Nsight/peer timings from current10-body native elapsed buckets.'},
        'follow_up':'Stopped after this archive. Further backend-end instrumentation or an optimization requires a separately selected next task; no candidate speed benefit follows here.',
        'reproduction':{'archive_offline':'Extract ZIP; python scripts/recompute.py EXTRACTED_DIRECTORY (stdlib only).',
            'original_build_run':'Exact compile/link/run commands, current input pins and private runner are archived. Only source patch changes src/graph/executable.cc; current original source SHA is in source-pins.json.',
            'raw_format':'Entire direct stdout/stderr retained, no Nsight truncation. Both initial offline failed parser and corrected analyzer retained; the model itself exited0 once.'},
        'limits':m['limits']+[
            'No throughput, current-vs-peer unit-cost, pure CPU or recoverable-time claim; no benchmark samples were added.',
            'prepare_replay excludes preceding Model layout/batch/input work. Same-call cold_batch minus prepare_replay is an unclassified upper-level envelope, printed at finite clock precision.',
            'Dispatch covers all selected region/operation/copy steps; it is not equivalent to ggml provider time or kernel-launch time. End combines native capture/update-or-instantiation and artifact lifetime work; no exact Update/Instantiate counts were measured.']}
    members={}; origins={}
    def add(name,path):
        assert name not in members and path.is_file()
        assert path.suffix.lower() not in {'.obj','.lib','.exe','.dll','.pdb','.bin','.gguf','.safetensors','.sqlite','.nsys-rep'}
        raw=path.read_bytes()
        assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})',raw),name
        members[name]=raw; origins[name]=str(path.resolve())
    for name in ['memo.json','plan.json','source.patch','source-pins.json','independent-review-architecture.json']:
        add('diagnostic/'+name,WORK/name)
    add('diagnostic/source-only-boundaries.json',BASE/'next-cold-clock-boundaries.json')
    for name in ['prepare_source.py','check.py','write_memo.py','recompute.py','archive.py']:
        add('scripts/'+name,WORK/name)
    for name in ['ready.json','plan.json','runtime.json','link-inputs.json','run-plan.json',
                 'preflight-device.txt','preflight-processes.json']:
        path=OUT/name
        if path.exists(): add('build/'+name,path)
    for stage in ['compile','link']:
        for name in ['command.json','running.json','process.json','stdout.log','stderr.log']:
            add('build/'+stage+'/'+name,OUT/stage/name)
    for name in ['dependencies.json','actual-dependencies.json','dependency-check.json']:
        add('build/compile/'+name,OUT/'compile'/name)
    for name in ['ready-current.json','runtime-current.json','link-inputs-current.json','object-map-current.json']:
        add('current-closure/'+name,BASE/name)
    for name in ['command.json','dependencies.json','identity-current.json']:
        add('current-closure/original-graph/'+name,BASE/'drift8/graph--executable_cc'/name)
    add('current-closure/original-link-command.json',BASE/'link-current/process/command.json')
    for name in ['command.json','running.json','process.json','stdout.log','stderr.log','events.json','paired-events.json','nontime-differences.json']:
        add('run/'+name,OUT/'run'/name)
    for name in ['summary.json','record-table.json','analysis-first-failed.py','analysis-first-failure.json','analysis-final-stdout.json']:
        add('analysis/'+name,OUT/name)
    add('reference/behavior.py',BASE/'behavior.py')
    for name in ['command.json','stdout.log','stderr.log','observation.json']:
        add('reference/'+name,baseline/name)
    members['report.json']=(json.dumps(report,indent=2)+'\n').encode()
    manifest={'schema':'hyle-archive-members-v1','members':{
        name:{**digest(raw),**({'origin':origins[name]} if name in origins else {})} for name,raw in members.items()},
        'exclusions':'No binaries, SDK, models, full source/dependency tree, SQLite or profiler databases. Exact source patch and dependency/input identities only.'}
    members['archive-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
    PUBLIC.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in members.items(): z.writestr(name,raw)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        for name,row in manifest['members'].items():
            assert digest(z.read(name))=={k:row[k] for k in ['bytes','sha256']}
    report['archive']={'path':destination.relative_to(ROOT).as_posix(),**digest(destination.read_bytes()),
        'member_count':len(members),'zip_CRC':'PASS','member_SHA256':'PASS',
        'contains_binaries_SDK_models_full_source_tree':False}
    save(report_path,report)
    save(WORK/'archive-verification.json',{'report':pin(report_path),'archive':pin(destination),
        'member_count':len(members),'zip_CRC':'PASS','member_SHA256':'PASS'})
    print(json.dumps(read(WORK/'archive-verification.json'),indent=2))

if __name__=='__main__': main()
