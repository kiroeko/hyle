"""Recompute the extracted evidence without a compiler, model, SDK or GPU.

Usage: python scripts/recompute.py [extracted_archive_directory]
"""
from pathlib import Path
import ast
import json
import re
import sys

D = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
def read(path): return json.loads((D / path).read_bytes())
def report(path):
    return json.loads(next(line for line in reversed((D/path).read_text().splitlines()) if line.startswith('{')))

namespace = {}
source = D / 'reference/behavior.py'
tree = ast.parse(source.read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)
    and n.name in ['normalize','differences']],type_ignores=[]),str(source),'exec'),namespace)
normalize,differences = namespace['normalize'],namespace['differences']
delta=differences(normalize(report('reference/stdout.log')),normalize(report('run/stdout.log')))
assert not delta
text=(D/'run/stderr.log').read_text()
lines=text.splitlines()
assert lines[-1]=='GRAPH_CLOCK_END normal_exit=1'
headers=[json.loads(line.removeprefix('GRAPH_CLOCK_BEGIN ')) for line in lines if line.startswith('GRAPH_CLOCK_BEGIN ')]
assert len(headers)==1
h=headers[0]
p=[json.loads(line.removeprefix('GRAPH_CLOCK_PREP ')) for line in lines if line.startswith('GRAPH_CLOCK_PREP ')]
r=[json.loads(line.removeprefix('GRAPH_CLOCK_RANGE ')) for line in lines if line.startswith('GRAPH_CLOCK_RANGE ')]
assert h['prepare_attempted']==h['prepare_finished']==len(p)==68
assert h['range_attempted']==h['range_finished']==len(r)==132
assert h['prepare_overflow']==h['range_overflow']==0
assert [v['ordinal'] for v in p]==list(range(len(p)))
assert [v['ordinal'] for v in r]==list(range(len(r)))
assert all(v['ok']==1 and (v['seen']==255 or (v['mode']==0 and v['seen']==159)) for v in p)
assert all((v['seen']==255 and v['outcome']==2 and v['reuse_kind']==0) or
           (v['seen']==131 and v['outcome']==1 and v['reuse_kind'] in [1,2]) for v in r)
def clocks(value): return re.sub(r'\b(\w*seconds)=\S+',r'\1=<TIME>',value)
original=''.join(line for line in text.splitlines(keepends=True) if not line.startswith('GRAPH_CLOCK_'))
assert clocks(original)==clocks((D/'reference/stderr.log').read_text())
facts=[]
for line in lines:
    if line.startswith('prepared T='):
        facts.append({key:float(value) if key.endswith('seconds') else int(value)
            for key,value in re.findall(r'\b(T|visible|capture_recorded|capture_reused|cold_batch_seconds)=([0-9.eE+-]+)',line)})
assert len(facts)==len(p)
for v,f in zip(p,facts):
    children=[c for c in r if c['parent']==v['ordinal']]
    assert len(children)==(0 if v['seen']==159 else v['range_count'])
    assert sum(c['outcome']==2 for c in children)==f['capture_recorded']
    assert sum(c['outcome']==1 for c in children)==f['capture_reused']
    for c in children:
        assert v['ticks'][5]<=c['ticks'][0]<=c['ticks'][7]<=v['ticks'][6]
    v['fact']=f
    v['loop_control_ns']=None if v['seen']==159 else v['ticks'][6]-v['ticks'][5]-sum(c['ticks'][7]-c['ticks'][0] for c in children)
    assert v['loop_control_ns'] is None or v['loop_control_ns']>=0
recorded=[v for v in r if v['outcome']==2]
reused=[v for v in r if v['outcome']==1]
assert len(recorded)==27 and len(reused)==105
parent_sum=sum(sum(v['ticks'][i+1]-v['ticks'][i] for i in range(7) if (v['seen']&(3<<i))==(3<<i))+
    (v['ticks'][7]-v['ticks'][4] if v['seen']==159 else 0) for v in p)
parent_total=sum(v['ticks'][7]-v['ticks'][0] for v in p)
assert parent_sum==parent_total
loop=sum(v['ticks'][6]-v['ticks'][5] for v in p if v['seen']==255)
child=sum(v['ticks'][7]-v['ticks'][0] for v in r)
control=sum(v['loop_control_ns'] or 0 for v in p)
assert loop==child+control
classes={}
for name,predicate in [('prefill',lambda v:v['fact']['T']>2),
        ('decode_has_record',lambda v:v['fact']['T']<=2 and v['fact']['capture_recorded']>0),
        ('decode_no_record',lambda v:v['fact']['T']<=2 and v['fact']['capture_recorded']==0)]:
    selected=[v for v in p if predicate(v)]
    classes[name]={'count':len(selected),
        'cold_batch_total_ms':sum(v['fact']['cold_batch_seconds'] for v in selected)*1000,
        'prepare_replay_ms':sum(v['ticks'][7]-v['ticks'][0] for v in selected)/1e6,
        'cold_bindings_ms':sum(v['ticks'][2]-v['ticks'][1] for v in selected)/1e6}
range_classes={}
for name,predicate in [('body',lambda v:v['count']==1269),('front',lambda v:v['count'] in [53,55])]:
    selected=[v for v in recorded if predicate(v)]
    range_classes[name]={'records':len(selected),
        'dispatch_ms':sum(v['ticks'][3]-v['ticks'][2] for v in selected)/1e6,
        'end_native_build_ms':sum(v['ticks'][4]-v['ticks'][3] for v in selected)/1e6}
expected=read('analysis/summary.json')
assert expected['status']=='PASS_CURRENT_GRAPH_CLOCK_DIAGNOSTIC_NOT_TPS'
assert abs(parent_total/1e6-expected['groups']['all']['whole_prepare_replay']['total_ms'])<1e-10
assert abs(loop/1e6-expected['groups']['all']['buckets']['range_loop_INCLUSIVE']['total_ms'])<1e-10
assert {n:g['count'] for n,g in classes.items()}=={'prefill':2,'decode_has_record':21,'decode_no_record':45}
assert range_classes['body']['records']==10 and range_classes['front']['records']==17
print(json.dumps({'status':'OFFLINE_RECOMPUTATION_PASS','full_non_time_differences':len(delta),
    'original_stderr_equal_clock_values_only':True,'completeness':h,
    'parent_total_and_disjoint_sum_ms':parent_total/1e6,
    'range_loop_and_children_plus_exclusive_control_ms':loop/1e6,
    'groups':classes,'record_classes':range_classes},indent=2))
