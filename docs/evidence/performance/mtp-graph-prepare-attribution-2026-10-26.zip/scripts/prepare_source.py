from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
REL = Path('src/graph/executable.cc')
EXPECTED = '6476518eaf59eef59d46fc1b0ad770024c0bee99a616663b1032ea33c2d8cf59'

def pin(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)

HELPER = r'''// Private, bounded observation only. No owner/resource or tensor content is kept.
namespace {
namespace graph_cold_clock {
constexpr std::size_t kPrepareCapacity = 512;
constexpr std::size_t kRangeCapacity = 2048;
struct PrepareEvent final {
  std::uint64_t ordinal = 0;
  std::uintptr_t invocation = 0, plan = 0;
  std::size_t range_count = 0;
  unsigned mode = 0, seen = 0, ok = 0;
  std::array<std::uint64_t, 8> ticks{};
};
struct RangeEvent final {
  std::uint64_t ordinal = 0, parent = 0;
  std::size_t begin = 0, count = 0, commands = 0, lane = 0;
  unsigned seen = 0, outcome = 0, reuse_kind = 0;
  std::array<std::uint64_t, 8> ticks{};
};
static_assert(std::is_trivially_copyable_v<PrepareEvent>);
static_assert(std::is_trivially_copyable_v<RangeEvent>);
static_assert(std::is_trivially_destructible_v<PrepareEvent>);
static_assert(std::is_trivially_destructible_v<RangeEvent>);
struct Store final {
  std::atomic<std::uint64_t> prepare_attempted{0}, prepare_finished{0};
  std::atomic<std::uint64_t> range_attempted{0}, range_finished{0};
  PrepareEvent prepares[kPrepareCapacity]{};
  RangeEvent ranges[kRangeCapacity]{};
};
Store data{};  // Defined before Dumper; destroyed after its normal-exit dump.
std::uint64_t now() noexcept {
  return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
      std::chrono::steady_clock::now().time_since_epoch()).count());
}
struct PrepareScope final {
  std::uint64_t ordinal;
  PrepareEvent *event = nullptr;
  PrepareScope(const void *invocation, const void *plan, std::size_t ranges,
               unsigned mode) noexcept
      : ordinal(data.prepare_attempted.fetch_add(1, std::memory_order_relaxed)) {
    if (ordinal < kPrepareCapacity) {
      event = &data.prepares[static_cast<std::size_t>(ordinal)];
      event->ordinal = ordinal;
      event->invocation = reinterpret_cast<std::uintptr_t>(invocation);
      event->plan = reinterpret_cast<std::uintptr_t>(plan);
      event->range_count = ranges;
      event->mode = mode;
      mark(0);
    }
  }
  void mark(unsigned index) noexcept {
    if (event) { event->ticks[index] = now(); event->seen |= 1U << index; }
  }
  void success() noexcept { if (event) event->ok = 1; }
  ~PrepareScope() {
    mark(7);
    data.prepare_finished.fetch_add(1, std::memory_order_relaxed);
  }
};
struct RangeScope final {
  RangeEvent *event = nullptr;
  RangeScope(std::uint64_t parent, std::size_t begin, std::size_t count,
             std::size_t commands, std::size_t lane) noexcept {
    const auto ordinal = data.range_attempted.fetch_add(1, std::memory_order_relaxed);
    if (ordinal < kRangeCapacity) {
      event = &data.ranges[static_cast<std::size_t>(ordinal)];
      event->ordinal = ordinal; event->parent = parent;
      event->begin = begin; event->count = count;
      event->commands = commands; event->lane = lane;
      mark(0);
    }
  }
  void mark(unsigned index) noexcept {
    if (event) { event->ticks[index] = now(); event->seen |= 1U << index; }
  }
  void reuse(unsigned kind) noexcept {
    mark(1);
    if (event) { event->outcome = 1; event->reuse_kind = kind; }
  }
  void outcome(unsigned value) noexcept { if (event) event->outcome = value; }
  ~RangeScope() {
    mark(7);
    data.range_finished.fetch_add(1, std::memory_order_relaxed);
  }
};
void ticks(const std::array<std::uint64_t, 8> &values) noexcept {
  std::fputc('[', stderr);
  for (std::size_t i = 0; i < values.size(); ++i)
    std::fprintf(stderr, "%s%llu", i ? "," : "",
                 static_cast<unsigned long long>(values[i]));
  std::fputc(']', stderr);
}
struct Dumper final {
  ~Dumper() {
    // Normal process exit after all submissions only; no owner or native API.
    const auto p = data.prepare_attempted.load(std::memory_order_relaxed);
    const auto r = data.range_attempted.load(std::memory_order_relaxed);
    std::fprintf(stderr,
        "GRAPH_CLOCK_BEGIN {\"prepare_attempted\":%llu,\"prepare_finished\":%llu,"
        "\"prepare_capacity\":%zu,\"prepare_overflow\":%llu,\"range_attempted\":%llu,"
        "\"range_finished\":%llu,\"range_capacity\":%zu,\"range_overflow\":%llu,\"store_bytes\":%zu}\n",
        static_cast<unsigned long long>(p),
        static_cast<unsigned long long>(data.prepare_finished.load(std::memory_order_relaxed)),
        kPrepareCapacity, static_cast<unsigned long long>(p > kPrepareCapacity ? p - kPrepareCapacity : 0),
        static_cast<unsigned long long>(r),
        static_cast<unsigned long long>(data.range_finished.load(std::memory_order_relaxed)),
        kRangeCapacity, static_cast<unsigned long long>(r > kRangeCapacity ? r - kRangeCapacity : 0), sizeof(Store));
    for (std::size_t i = 0; i < std::min<std::uint64_t>(p, kPrepareCapacity); ++i) {
      const auto &e = data.prepares[i];
      std::fprintf(stderr, "GRAPH_CLOCK_PREP {\"ordinal\":%llu,\"invocation\":%llu,\"plan\":%llu,"
          "\"range_count\":%zu,\"mode\":%u,\"seen\":%u,\"ok\":%u,\"ticks\":",
          static_cast<unsigned long long>(e.ordinal), static_cast<unsigned long long>(e.invocation),
          static_cast<unsigned long long>(e.plan), e.range_count, e.mode, e.seen, e.ok);
      ticks(e.ticks); std::fputs("}\n", stderr);
    }
    for (std::size_t i = 0; i < std::min<std::uint64_t>(r, kRangeCapacity); ++i) {
      const auto &e = data.ranges[i];
      std::fprintf(stderr, "GRAPH_CLOCK_RANGE {\"ordinal\":%llu,\"parent\":%llu,\"begin\":%zu,"
          "\"count\":%zu,\"commands\":%zu,\"lane\":%zu,\"seen\":%u,\"outcome\":%u,\"reuse_kind\":%u,\"ticks\":",
          static_cast<unsigned long long>(e.ordinal), static_cast<unsigned long long>(e.parent),
          e.begin, e.count, e.commands, e.lane, e.seen, e.outcome, e.reuse_kind);
      ticks(e.ticks); std::fputs("}\n", stderr);
    }
    std::fputs("GRAPH_CLOCK_END normal_exit=1\n", stderr);
    std::fflush(stderr);
  }
};
Dumper dumper;
} // namespace graph_cold_clock
} // namespace

'''

def main():
    raw = (ROOT / REL).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    before = WORK / 'before' / REL
    after = WORK / 'source' / REL
    assert not after.exists()
    newline = '\r\n' if b'\r\n' in raw else '\n'
    text = raw.decode('utf-8').replace('\r\n', '\n')
    text = once(text, '#include <algorithm>\n', '#include <algorithm>\n#include <atomic>\n#include <chrono>\n#include <cstdio>\n#include <type_traits>\n')
    begin = text.index('Status Invocation::prepare_replay(')
    end = text.index('\nReplayRoute Invocation::replay_route()', begin)
    f = text[begin:end]
    f = once(f, '  HYLE_RETURN_IF_ERROR(detail::begin_preparation(*state_));',
        '  graph_cold_clock::PrepareScope clock_prepare(state_, state_->plan,\n'
        '      state_->plan->capture_ranges.size(), static_cast<unsigned>(options.mode));\n'
        '  HYLE_RETURN_IF_ERROR(detail::begin_preparation(*state_));')
    f = once(f, '  Status bindings = prepare_invocation_bindings(*state_);',
        '  clock_prepare.mark(1);\n  Status bindings = prepare_invocation_bindings(*state_);\n  clock_prepare.mark(2);')
    f = once(f, '  // Reserve only the bounded number', '  clock_prepare.mark(3);\n  // Reserve only the bounded number')
    f = once(f, '  // Publish the replacement Queue/route', '  clock_prepare.mark(4);\n  // Publish the replacement Queue/route')
    f = once(f, '    state_->replay_prepared = true;\n    return Status::Ok();',
        '    state_->replay_prepared = true;\n    clock_prepare.success();\n    return Status::Ok();')
    f = once(f, '  std::size_t captured_command_count = 0;', '  clock_prepare.mark(5);\n  std::size_t captured_command_count = 0;')
    f = once(f, '    range.step_count = candidate.step_count;\n',
        '    range.step_count = candidate.step_count;\n'
        '    graph_cold_clock::RangeScope clock_range(clock_prepare.ordinal,\n'
        '        range.step_begin, range.step_count, candidate.command_count, segment.lane.ordinal());\n')
    f = once(f, '      captured_command_count += candidate.command_count;\n      continue;',
        '      captured_command_count += candidate.command_count;\n      clock_range.reuse(1);\n      continue;')
    f = once(f, '        captured_command_count += candidate.command_count;\n        continue;',
        '        captured_command_count += candidate.command_count;\n        clock_range.reuse(2);\n        continue;')
    # Three original unsupported fallbacks, preserve their different stage masks.
    f = f.replace('        continue;\n      }\n      unprepare_captures();',
                  '        clock_range.outcome(3);\n        continue;\n      }\n      unprepare_captures();')
    assert f.count('clock_range.outcome(3);') == 3
    f = once(f, '    Status begun = compute::detail::CommandCaptureAccess::begin(*extension, *sequence);',
        '    clock_range.mark(1);\n    Status begun = compute::detail::CommandCaptureAccess::begin(*extension, *sequence);\n    clock_range.mark(2);')
    f = once(f, '    Status recorded = enqueue_segment_steps(*state_, range, *sequence);',
        '    Status recorded = enqueue_segment_steps(*state_, range, *sequence);\n    clock_range.mark(3);')
    f = once(f, '        *extension, *sequence, state_->allocator, std::move(rebuild));\n    Status finished = finish_preparation(*sequence);',
        '        *extension, *sequence, state_->allocator, std::move(rebuild));\n    clock_range.mark(4);\n'
        '    Status finished = finish_preparation(*sequence);\n    clock_range.mark(5);')
    f = once(f, '    ++recorded_range_count;\n    captured_command_count += candidate.command_count;\n  }',
        '    ++recorded_range_count;\n    captured_command_count += candidate.command_count;\n'
        '    clock_range.mark(6);\n    clock_range.outcome(2);\n  }\n  clock_prepare.mark(6);')
    f = once(f, '  state_->replay_prepared = true;\n  return Status::Ok();',
        '  state_->replay_prepared = true;\n  clock_prepare.success();\n  return Status::Ok();')
    text = text[:begin] + HELPER + f + text[end:]
    new = text.replace('\n', newline).encode('utf-8')
    before.parent.mkdir(parents=True, exist_ok=True)
    after.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(raw)
    after.write_bytes(new)
    patch = ''.join(difflib.unified_diff(raw.decode().splitlines(True), new.decode().splitlines(True),
            fromfile='a/' + REL.as_posix(), tofile='b/' + REL.as_posix()))
    (WORK / 'source.patch').write_bytes(patch.encode())
    save(WORK / 'source-pins.json', {'files':[{'path':REL.as_posix(), 'before':pin(before), 'after':pin(after)}],
        'patch':pin(WORK/'source.patch'), 'newline_preserved':newline == '\r\n'})
    save(WORK / 'plan.json', {
        'status':'PRIVATE_SOURCE_ONLY', 'prepare_capacity':512, 'range_capacity':2048,
        'prepare_ticks':['queue/prelude begin','cold bindings begin','cold bindings end',
            'routes/inputs/reserve end','capture cache qualification end','range loop begin',
            'range loop end','scope exit after original preparation/candidate destructors'],
        'range_ticks':['key lookup/setup begin','begin capture begin OR successful reuse decision',
            'begin capture end','dispatch end','capture end/instantiate-update end',
            'sequence.finish + retained preparation completion + real wait end',
            'key/command publication end','range scope exit'],
        'outcome':{'0':'error or incomplete','1':'reuse','2':'recorded','3':'unsupported fallback'},
        'reuse_kind':{'0':'not reused','1':'retained active range','2':'saved variant'},
        'limits':['Parent range-loop is inclusive of child ranges; never add parent and child buckets.',
            'Only observed adjacent timestamps define disjoint intervals. Absent ticks remain unknown, not zero.',
            'No owners, tensor content, native API, hot allocation or hot I/O in instrumentation.',
            'Dump valid only on normal exit after submissions stopped; attempted/finished/overflow and masks must pass.',
            'One current Graph host TU, one exact current relink, at most one original K1 two-turn process after source review.',
            'Different-process old provider 15.29ms cannot be subtracted from this run. This is not a TPS measurement.']})
    print(json.dumps({'source':pin(after), 'patch':pin(WORK/'source.patch')}, indent=2))

if __name__ == '__main__':
    main()
