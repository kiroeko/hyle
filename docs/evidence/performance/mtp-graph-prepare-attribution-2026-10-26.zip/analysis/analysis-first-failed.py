"""One private Graph host TU and one original current K1 two-turn diagnostic."""
from pathlib import Path
import ast
import importlib.util
import json
import os
import re
import statistics
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BASE = ROOT / '.scratch/inference-current-closure-20261026'
OLD = BASE / 'drift8/graph--executable_cc'
spec = importlib.util.spec_from_file_location('retained_recipe', ROOT / '.scratch/inference-synchronous-step-report-20261025/check_host.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
pin, save, execute = helper.pin, helper.save, helper.execute

def read(path):
    return json.loads(path.read_bytes())

def exact(row):
    actual = pin(Path(row['path']))
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']

def prerequisites():
    ready = read(BASE / 'ready-current.json')
    assert ready['image']['sha256'] == '2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
    for key in ['image', 'native', 'runtime', 'link_inputs', 'command']:
        exact(ready[key])
    for row in read(BASE / 'link-inputs-current.json'):
        exact(row)
    identity = read(OLD / 'identity-current.json')
    for row in identity['current_project_dependencies']:
        exact(row)
    for row in read(WORK / 'source-pins.json')['files']:
        exact(row['before']); exact(row['after'])
    assert pin(ROOT / 'src/graph/executable.cc')['sha256'] == identity['source']['sha256']
    return ready, identity

def build():
    out = WORK / 'attempt1'
    assert not out.exists(), 'Preserve attempts, no automatic recompile'
    ready, identity = prerequisites()
    source = WORK / 'source/src/graph/executable.cc'
    command = list(read(OLD / 'command.json')['command'])
    compiler = command[0]
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER':compiler, 'CMAKE_CXX_COMPILER':compiler, 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    out.mkdir()
    stage = out / 'compile'
    obj = stage / 'unit.obj'
    assert command.count(identity['source']['path']) == 1
    command[command.index(identity['source']['path'])] = str(source)
    command[command.index('/sourceDependencies') + 1] = str(stage / 'dependencies.json')
    command = [('/Fo' + str(obj)) if arg.startswith('/Fo') else
               ('/Fd' + str(stage / 'unit.pdb')) if arg.startswith('/Fd') else arg for arg in command]
    save(out / 'plan.json', {'baseline_ready':pin(BASE / 'ready-current.json'),
        'original_compile':pin(OLD / 'command.json'), 'source_pins':pin(WORK / 'source-pins.json'),
        'instrumentation_plan':pin(WORK / 'plan.json'), 'new_TUs':1,
        'limits':'Only current Graph executable host TU changed; all other final2a94 inputs exact. No app/provider/core/device/SDK build.'})
    compiled = execute(command, env, stage, timeout=120)
    data = read(stage / 'dependencies.json')['Data']
    assert Path(data['Source']).resolve() == source.resolve()
    rows = [pin(Path(path)) for path in dict.fromkeys([data['Source'], *data['Includes']])]
    save(stage / 'actual-dependencies.json', rows)
    actual = {Path(row['path']).resolve():row for row in rows}
    expected = {Path(row['path']).resolve():row for row in identity['current_project_dependencies']}
    expected.pop((ROOT / 'src/graph/executable.cc').resolve())
    expected[source.resolve()] = pin(source)
    for path, wanted in expected.items():
        assert path in actual and actual[path]['sha256'] == wanted['sha256'], path
    self_rows = [row for row in rows if Path(row['path']).resolve().is_relative_to(ROOT)]
    assert {Path(row['path']).resolve() for row in self_rows} == set(expected), 'No undeclared project header/overlay'
    original_dependencies = read(OLD / 'dependencies.json')['Data']
    original_set = {Path(path).resolve() for path in original_dependencies['Includes']}
    assert original_set.issubset(set(actual)), 'Original actual headers still present'
    extra = [row for row in rows if Path(row['path']).resolve() not in original_set and Path(row['path']).resolve() != source.resolve()]
    assert all(not Path(row['path']).resolve().is_relative_to(ROOT) for row in extra)
    save(stage / 'dependency-check.json', {'all_current_self_dependencies_exact':True,
        'project_count':len(self_rows), 'actual_count':len(rows), 'additional_standard_headers':extra,
        'original_actual_headers_preserved':True})
    old_obj = identity['object']['path']
    original_link = read(BASE / 'link-current/process/command.json')['command']
    assert original_link.count(old_obj) == 1
    args = [str(obj) if arg == old_obj else arg for arg in original_link
            if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    before = read(BASE / 'link-inputs-current.json')
    after = [pin(Path(arg)) for arg in args[1:] if Path(arg).is_absolute() and Path(arg).suffix.lower() in ['.obj','.lib']]
    assert len(before) == len(after)
    assert sum(a != b for a,b in zip(before, after)) == 1
    assert [r for r in before if r['path'] != old_obj] == [r for r in after if r['path'] != str(obj)]
    save(out / 'link-inputs.json', after)
    image = out / 'link/hyle.exe'
    linked = execute([*args, '/OUT:' + str(image), '/IMPLIB:' + str(image.with_suffix('.lib')),
        '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent, timeout=120)
    native = Path(ready['native']['path'])
    os.link(native, image.parent / native.name)
    runtime = read(BASE / 'runtime-current.json')
    runtime['PATH'] = str(image.parent) + os.pathsep + runtime['PATH']
    runtime['original_runtime_record'] = pin(BASE / 'runtime-current.json')
    runtime['native_hardlink'] = pin(image.parent / native.name)
    save(out / 'runtime.json', runtime)
    prerequisites()
    result = {'status':'READY_CURRENT_GRAPH_HOST_TIMING_NO_RUN', 'image':pin(image),
        'graph_object':pin(obj), 'source':pin(source), 'source_pins':pin(WORK / 'source-pins.json'),
        'baseline_image':ready['image'], 'baseline_ready':pin(BASE / 'ready-current.json'),
        'runtime':pin(out / 'runtime.json'), 'native':ready['native'],
        'link_inputs':pin(out / 'link-inputs.json'), 'absolute_inputs':len(after),
        'unchanged_absolute_inputs':len(after)-1,
        'commands':{'compile':pin(stage / 'command.json'), 'link':pin(image.parent / 'command.json')},
        'actual_dependencies':pin(stage / 'actual-dependencies.json'),
        'dependency_check':pin(stage / 'dependency-check.json'), 'processes':{'compile':compiled,'link':linked},
        'limits':'Private metadata/timing instrumentation in current2a94 closure; no throughput or GPU activity classification.'}
    save(out / 'ready.json', result)
    print(json.dumps({k:result[k] for k in ['status','image','processes','absolute_inputs']}, indent=2))

def functions():
    path = BASE / 'behavior.py'
    tree = ast.parse(path.read_text())
    namespace = {}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['normalize','differences']], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace['normalize'], namespace['differences']

def report(path):
    return json.loads(next(line for line in reversed(path.read_text().splitlines()) if line.startswith('{')))

def run():
    out = WORK / 'attempt1'
    ready = read(out / 'ready.json')
    prerequisites()
    for key in ['image','graph_object','source','runtime','link_inputs']:
        exact(ready[key])
    for row in read(out / 'link-inputs.json'):
        exact(row)
    baseline = next(row for row in read(BASE / 'full-window/two-turn-timing/runs.json') if row['arm'] == 'hyle_mtp')
    folder = Path(baseline['folder'])
    command = [ready['image']['path'], *baseline['process']['command'][1:]]
    env = dict(os.environ)
    runtime = read(out / 'runtime.json')
    env['PATH'] = runtime['PATH']; env.update(runtime.get('configured_flags',{}))
    save(out / 'run-plan.json', {'baseline_command':pin(folder / 'command.json'),
        'baseline_stdout':pin(folder / 'stdout.log'), 'baseline_stderr':pin(folder / 'stderr.log'),
        'image':ready['image'], 'runtime':ready['runtime'], 'one_process':True,
        'watchdog_seconds':120, 'not_TPS':True, 'original_argv_unchanged':command[1:] == baseline['process']['command'][1:]})
    executed = execute(command, env, out / 'run', timeout=120)
    # GPU window ends at terminal; analysis below is entirely offline.
    print('GPU_TERMINAL_RELEASED', executed['pid'], executed['exit'], flush=True)
    analyze(executed, folder)

def stats(values):
    return {'count':len(values), 'total_ms':sum(values)/1e6,
        'mean_us':statistics.mean(values)/1e3 if values else None,
        'median_us':statistics.median(values)/1e3 if values else None,
        'min_us':min(values)/1e3 if values else None, 'max_us':max(values)/1e3 if values else None}

def analyze(executed=None, folder=None):
    out = WORK / 'attempt1'
    if executed is None:
        executed = read(out / 'run/process.json')
    if folder is None:
        folder = Path(next(row for row in read(BASE / 'full-window/two-turn-timing/runs.json') if row['arm'] == 'hyle_mtp')['folder'])
    stdout, stderr = out / 'run/stdout.log', out / 'run/stderr.log'
    text = stderr.read_text()
    lines = text.splitlines()
    heads = [json.loads(line[len('GRAPH_CLOCK_BEGIN '):]) for line in lines if line.startswith('GRAPH_CLOCK_BEGIN ')]
    assert len(heads) == 1 and lines[-1] == 'GRAPH_CLOCK_END normal_exit=1'
    head = heads[0]
    prepares = [json.loads(line[len('GRAPH_CLOCK_PREP '):]) for line in lines if line.startswith('GRAPH_CLOCK_PREP ')]
    ranges = [json.loads(line[len('GRAPH_CLOCK_RANGE '):]) for line in lines if line.startswith('GRAPH_CLOCK_RANGE ')]
    save(out / 'run/events.json', {'header':head,'prepares':prepares,'ranges':ranges})
    assert head['prepare_attempted'] == head['prepare_finished'] == len(prepares)
    assert head['range_attempted'] == head['range_finished'] == len(ranges)
    assert head['prepare_overflow'] == head['range_overflow'] == 0
    assert [r['ordinal'] for r in prepares] == list(range(len(prepares)))
    assert [r['ordinal'] for r in ranges] == list(range(len(ranges)))
    assert all(p['ok'] == 1 and p['seen'] == 255 for p in prepares)
    assert all((r['outcome'] == 1 and r['seen'] == 131 and r['reuse_kind'] in [1,2]) or
               (r['outcome'] == 2 and r['seen'] == 255 and r['reuse_kind'] == 0) for r in ranges)
    for row in [*prepares,*ranges]:
        observed = [t for i,t in enumerate(row['ticks']) if row['seen'] & (1 << i)]
        assert all(a <= b for a,b in zip(observed,observed[1:])), row
    normalize, differences = functions()
    delta = differences(normalize(report(folder / 'stdout.log')),normalize(report(stdout)))
    save(out / 'run/nontime-differences.json',delta)
    original_lines = [line for line in text.splitlines(keepends=True) if not line.startswith('GRAPH_CLOCK_')]
    def clocks(value): return re.sub(r'\b(\w*seconds)=\S+',r'\1=<TIME>',value)
    stderr_equal = clocks(''.join(original_lines)) == clocks((folder / 'stderr.log').read_text())
    facts = []
    for line in lines:
        if line.startswith('prepared T='):
            facts.append({key:float(value) if key.endswith('seconds') else int(value)
                for key,value in re.findall(r'\b(T|visible|capture_recorded|capture_reused|cold_batch_seconds)=([0-9.eE+-]+)',line)})
    assert len(prepares) == len(facts), 'Do not guess mapping of extra preparations'
    for p,f in zip(prepares,facts):
        children = [r for r in ranges if r['parent'] == p['ordinal']]
        assert len(children) == p['range_count']
        assert sum(r['outcome'] == 2 for r in children) == f['capture_recorded']
        assert sum(r['outcome'] == 1 for r in children) == f['capture_reused']
        p['original_prepared_fact'] = f
        p['classification'] = 'has_record' if f['capture_recorded'] else 'no_record'
        p['child_time_ns'] = sum(r['ticks'][7]-r['ticks'][0] for r in children)
        p['loop_exclusive_ns'] = p['ticks'][6]-p['ticks'][5]-p['child_time_ns']
        assert p['loop_exclusive_ns'] >= 0
    prep_names = ['queue_and_prelude','cold_bindings','routes_inputs_reservations',
        'cache_qualification','route_and_preloop','range_loop_INCLUSIVE','final_publish_cleanup']
    range_names = ['lookup_and_setup','begin_capture','dispatch','end_capture_native_build',
        'finish_retained_completion_real_wait','key_publication','range_cleanup']
    groups = {}
    for name,predicate in [('all',lambda p:True),('prefill',lambda p:p['original_prepared_fact']['T']>2),
            ('decode_has_record',lambda p:p['original_prepared_fact']['T']<=2 and p['classification']=='has_record'),
            ('decode_no_record',lambda p:p['original_prepared_fact']['T']<=2 and p['classification']=='no_record')]:
        selected = [p for p in prepares if predicate(p)]
        groups[name] = {'count':len(selected), 'whole_prepare_replay':stats([p['ticks'][7]-p['ticks'][0] for p in selected]),
            'original_cold_batch':stats([p['original_prepared_fact']['cold_batch_seconds']*1e9 for p in selected]),
            'buckets':{n:stats([p['ticks'][i+1]-p['ticks'][i] for p in selected]) for i,n in enumerate(prep_names)},
            'loop_control_EXCLUSIVE':stats([p['loop_exclusive_ns'] for p in selected])}
    recorded = [r for r in ranges if r['outcome'] == 2]
    reused = [r for r in ranges if r['outcome'] == 1]
    range_summary = {'recorded_count':len(recorded), 'reused_count':len(reused),
        'recorded':{n:stats([r['ticks'][i+1]-r['ticks'][i] for r in recorded]) for i,n in enumerate(range_names)},
        'reuse_lookup':stats([r['ticks'][1]-r['ticks'][0] for r in reused]),
        'reuse_cleanup':stats([r['ticks'][7]-r['ticks'][1] for r in reused])}
    save(out / 'run/paired-events.json',{'prepares':prepares,'ranges':ranges})
    summary = {'status':'PASS_CURRENT_GRAPH_CLOCK_DIAGNOSTIC_NOT_TPS' if not delta and stderr_equal else 'WORK_MISMATCH',
        'process':executed, 'baseline_image':read(BASE / 'ready-current.json')['image'],
        'ready':pin(out / 'ready.json'), 'completeness':head,
        'non_time_difference_count':len(delta),'original_stderr_equal_after_clock_values_only':stderr_equal,
        'original_prepared_count':len(facts),'recorded':len(recorded),'reused':len(reused),
        'groups':groups,'range_summary':range_summary,'raw':[pin(stdout),pin(stderr)],
        'events':pin(out / 'run/events.json'),'paired_events':pin(out / 'run/paired-events.json'),
        'limits':['CPU elapsed clocks may include native calls and real GPU waits; no GPU union measured.',
            'Parent range loop is INCLUSIVE of child buckets; use loop_control_EXCLUSIVE when combining.',
            'prepare_replay excludes preceding Model batch/layout and input binding; original cold_batch includes them.',
            'Provider15.29ms and old Nsight traces are different processes and cannot be subtracted from this run.',
            'One instrumented current original K1 two-turn process, no profiler/peer/throughput conclusion.']}
    save(out / 'summary.json',summary)
    print(json.dumps({k:summary[k] for k in ['status','process','completeness','non_time_difference_count','groups','range_summary']},indent=2))
    assert not delta and stderr_equal

if __name__ == '__main__':
    assert sys.argv[1:] in [['build'],['run'],['analyze']]
    {'build':build,'run':run,'analyze':analyze}[sys.argv[1]]()
