import argparse
import os
from pathlib import Path
import signal
import sys
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--mode', choices=('compute', 'graph'), required=True)
args = parser.parse_args()
root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source = root / 'native-a1329dd2'
builds = list((root / 'selected-m1-a41d43d5' / args.mode).glob('*/p1-build'))
assert len(builds) == 1, builds
build = builds[0]
log = root / ('m1-native-' + args.mode + '-run.log')
assert not log.exists(), 'Inspect the previous finite diagnostic attempt'
environment = dict(os.environ, PATH='/opt/homebrew/bin:' + os.environ['PATH'],
    MACOSX_DEPLOYMENT_TARGET='14.4', CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1',
    DYLD_LIBRARY_PATH='/opt/homebrew/opt/vulkan-loader/lib', VK_LOADER_LAYERS_DISABLE='~implicit~')
commands = [
    ['cmake', '--build', build, '--parallel', '2', '--target', 'hyle_' + args.mode + '_vulkan_native_cost_bench'],
    [sys.executable, root / 'vulkan-native-cost-diagnostic.py', '--source', source, '--build', build,
     '--output', root / ('m1-native-' + args.mode + '-a41d43d5'), '--profile', 'M1-MAC', '--mode', args.mode, '--snapshot', 'a41d43d531365a1fb8617d60113b37924e9a9864']]
with log.open('w') as stream:
    for command in commands:
        command = [str(x) for x in command]
        print(command, flush=True)
        started = time.monotonic()
        process = subprocess.Popen(command, cwd=source, env=environment, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=1200)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            raise RuntimeError('Finite diagnostic timeout; retained log requires inspection')
        print('exit', code, 'seconds', round(time.monotonic() - started, 2), flush=True)
        if code:
            print(log.read_text()[-6000:], flush=True)
            raise SystemExit(code)
print(log.read_text()[-6000:], flush=True)
