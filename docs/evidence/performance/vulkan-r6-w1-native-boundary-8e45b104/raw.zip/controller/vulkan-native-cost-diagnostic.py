"""Finite NATURAL_ROUTE collection via the existing runner and statistics APIs."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--profile', choices=('W1-WIN', 'M1-MAC'), required=True)
parser.add_argument('--snapshot', default='3894b72e3b4fbbda9457e2c31730e48bd0d43c49')
parser.add_argument('--mode', choices=('compute', 'graph'), required=True)
args = parser.parse_args()
source, build, output = args.source.resolve(), args.build.resolve(), args.output.resolve()
sys.path.insert(0, str(source / 'scripts'))
from hyle_perf import runner, stats
from hyle_perf.machine import (applied_macos_qos, evaluate_machine_profile,
    expected_child_policy, get_machine_profile, load_registry, probe_machine, sampling_mutex)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_bytes((json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def main():
    expected = args.snapshot
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
    windows = args.profile == 'W1-WIN'
    assert windows == (os.name == 'nt')
    if windows:
        import ctypes
        ctypes.windll.kernel32.SetErrorMode(0x8003)
    else:
        assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
    output.mkdir(exist_ok=False)
    raw = output / 'raw'
    raw.mkdir()
    tag = 'w1' if windows else 'm1'
    contract = json.loads((source / f'bench/contracts/{args.mode}-vulkan-ffn-{tag}-p1-v1.json').read_text())
    contract['id'] = args.mode + '-vulkan-native-boundary-diagnostic-' + tag
    contract['claim'] = 'NATURAL_ROUTE / NOT_COMPARABLE: same strict F32 math and checked fence, different cancellation/quarantine/output-lease responsibilities; no NI or algorithm ranking.'
    contract['strata'] = [x for x in contract['strata'] if x['target_variant'] == 'primary']
    ids = [x['id'] for x in contract['strata']]
    contract['controls'] = []
    contract['experiment']['sample_schedule'] = [15]
    contract['peers'] = [{'id': 'raw-native', 'revision': '456172ec733a135778adcd32d00e576a58232e45',
        'configuration': {'role': 'Independent original strict F32 shaders, fixed native buffers, recorded command, queue submit and checked fence wait.'}}]
    for workload in contract['workloads']:
        workload['pair']['peer'] = workload['pair']['peer'].replace('ggml shader lifecycle ', 'Raw Vulkan ')
        workload.update(required_strata=ids, required_controls=[], comparability='NOT_COMPARABLE',
                        gate_role='diagnostic', peer_id='raw-native')
        workload['ownership_topology']['peer'] = 'Fixed caller buffers and checked synchronous submit/fence; no async cancellation, abandoned-work quarantine or generated result leases.'
        workload['ownership_topology']['equivalence'] = 'Same complete F32 math and ready resident contents, deliberately different native service boundary.'
    extension = contract['extensions']['runner']
    extension['validators'] = []
    extension.pop('control_executable', None)
    extension['executables'] = [x for x in extension['executables'] if x['target_variant'] == 'primary']
    executable = extension['executables'][0]
    executable['id'] = args.mode + '-vulkan-native-boundary'
    executable['target'] = executable['stem'] = f'hyle_{args.mode}_vulkan_native_cost_bench'
    target = build / 'bin' / (executable['stem'] + ('.exe' if windows else ''))
    assert (build / 'bin' / f'hyle_vulkan_{args.mode}_aa.ready').read_text().split()[0] == 'PASS'
    spec = importlib.util.spec_from_file_location('vulkan_aa', source / 'bench/compute_route_vulkan/validate_aa.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if windows:
        module.windows_runtime(build)
    profile = get_machine_profile(load_registry(), args.profile)
    probe_args = {'paths': [('build', build)]}
    if not windows:
        probe_args['expected_qos'] = 'interactive'
    topology = extension['sampling_topology']
    before = probe_machine(**probe_args)
    gate = evaluate_machine_profile(profile, before, role='engineering', sampling_topology=topology)
    assert gate['gate'] == 'PASS', gate
    policy = expected_child_policy(profile, probe=before, sampling_topology=topology)
    write(output / 'diagnostic-input.json', contract)
    identity = {'candidate': expected, 'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
        'classification': 'NATURAL_ROUTE / NOT_COMPARABLE', 'executable': str(target), 'executable_sha256': sha(target),
        'script_sha256': sha(Path(__file__)), 'input_sha256': sha(output / 'diagnostic-input.json'),
        'cache_sha256': sha(build / 'CMakeCache.txt'), 'native_reference': module.reference_identity(build),
        'machine_gate': gate, 'probe_before': before, 'profile': profile, 'policy': policy,
        'gpu_before': module.gpu_snapshot(windows),
        'sample_budget': 'four order strata x 15 processes, M1/M16 per process, no escalation or ranking'}
    with sampling_mutex(profile) as lease:
        identity['sampling_mutex'] = lease.manifest_record()
        write(output / 'identity.json', identity)
        environment = runner._child_environment(extension['controlled_environment'],
            {'HYLE_BENCH_VERIFY_ONLY': '1'}, profile, policy)
        with runner._apply_sampling_policy(policy):
            oracle = subprocess.run([str(target)], env=environment, capture_output=True, timeout=180,
                                    creationflags=runner._creation_flags(policy))
        (output / 'oracle.log').write_bytes(oracle.stdout + oracle.stderr)
        assert oracle.returncode == 0, oracle.returncode
        begin = time.monotonic()
        with runner._apply_sampling_policy(policy):
            observations, paths = runner._collect_product_observations(contract, extension,
                {executable['id']: target}, profile, policy, runs=15,
                creationflags=runner._creation_flags(policy), raw_directory=raw)
        write(output / 'observations.json', [x.to_dict() for x in observations])
        summaries = []
        for workload in contract['workloads']:
            for stratum in ids:
                points = [x for x in observations if x.workload_id == workload['id'] and x.stratum_id == stratum]
                assert len(points) == 15
                summaries.append({'workload': workload['id'], 'stratum': stratum,
                    'ratio': stats.process_median_estimate(x.advantage_ratio for x in points).to_dict(),
                    'public_median_us': statistics.median(1e6 / x.candidate_value for x in points),
                    'native_median_us': statistics.median(1e6 / x.peer_value for x in points),
                    'paired_extra_median_us': statistics.median(1e6 / x.candidate_value - 1e6 / x.peer_value for x in points)})
        after = probe_machine(**probe_args)
        after_gate = evaluate_machine_profile(profile, after, role='engineering', sampling_topology=topology)
        assert after_gate['gate'] == 'PASS', after_gate
        assert sha(target) == identity['executable_sha256']
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
        write(output / 'summary.json', {'collection': 'PASS', 'classification': 'NATURAL_ROUTE / NOT_COMPARABLE',
            'ranking': None, 'noninferiority_gate': None, 'sample_escalation': False, 'strata': summaries,
            'wall_seconds': time.monotonic() - begin, 'probe_after': after, 'machine_gate_after': after_gate,
            'gpu_after': module.gpu_snapshot(windows), 'raw_sha256': {p.name: sha(p) for p in paths}})
    print(json.dumps({'mode': args.mode, 'collection': 'PASS', 'processes': len(paths), 'strata': summaries}), flush=True)


with applied_macos_qos(None if os.name == 'nt' else 'interactive'):
    main()
