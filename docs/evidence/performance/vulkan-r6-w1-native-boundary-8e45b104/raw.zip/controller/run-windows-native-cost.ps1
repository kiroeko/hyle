param([ValidateSet('compute','graph')][string]$Mode)
$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:PATH = 'C:/public/tools/glslang;' + $env:PATH
$env:HYLE_DEP_SOURCE_CACHE = 'C:/public/project-hyle/.deps'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VK_LOADER_LAYERS_DISABLE = '~implicit~'
$r6Root = 'C:/hyle-scratch/r6-vulkan-20260917'
$r6Build = "$r6Root/selected-w1-v2/$Mode/305895ce49352b4cc9bb/p1-build"
$r6Log = "$r6Root/w1-native-$Mode-run.log"
if (Test-Path -LiteralPath $r6Log) { throw 'Finite diagnostic attempt already exists; inspect before any retry' }
cmake --build $r6Build --target "hyle_${Mode}_vulkan_native_cost_bench" --parallel 2 *> $r6Log
if ($LASTEXITCODE -ne 0) { Get-Content $r6Log -Tail 30; exit $LASTEXITCODE }
python "$r6Root/vulkan-native-cost-diagnostic.py" --source "$r6Root/candidate-8e45b104" `
    --build $r6Build --output "$r6Root/w1-native-$Mode-3894b72e" --profile W1-WIN --mode $Mode *>> $r6Log
$r6Exit = $LASTEXITCODE
Get-Content $r6Log -Tail 3
exit $r6Exit
