"""Retain completed finite Vulkan native-boundary diagnostics without ranking them."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--profile', choices=('W1-WIN', 'M1-MAC'), required=True)
args = parser.parse_args()
root = args.root.resolve()
windows = args.profile == 'W1-WIN'
tag = 'w1' if windows else 'm1'
short = '3894b72e' if windows else 'a41d43d5'
snapshot = ('3894b72e3b4fbbda9457e2c31730e48bd0d43c49' if windows else
            'a41d43d531365a1fb8617d60113b37924e9a9864')
source = root / ('candidate-8e45b104' if windows else 'native-a1329dd2')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == snapshot
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


files, modes = {}, {}
for mode in ('compute', 'graph'):
    directory = root / (tag + '-native-' + mode + '-' + short)
    identity = json.loads((directory / 'identity.json').read_text())
    summary = json.loads((directory / 'summary.json').read_text())
    assert identity['candidate'] == snapshot
    assert summary['collection'] == 'PASS'
    assert summary['classification'] == 'NATURAL_ROUTE / NOT_COMPARABLE'
    assert summary['noninferiority_gate'] is None and summary['ranking'] is None
    assert summary['sample_escalation'] is False
    assert len(summary['strata']) == 8
    assert len(summary['raw_sha256']) == 60
    assert all(row['ratio']['sample_count'] == 15 for row in summary['strata'])
    assert sha(Path(identity['executable'])) == identity['executable_sha256']
    for name, digest in summary['raw_sha256'].items():
        matches = list((directory / 'raw').rglob(name))
        assert len(matches) == 1 and sha(matches[0]) == digest, name
    files.update({mode + '/' + p.relative_to(directory).as_posix(): p
                  for p in directory.rglob('*') if p.is_file()})
    selected = root / ('selected-w1-v2' if windows else 'selected-m1-a41d43d5') / mode
    builds = list(selected.glob('*/p1-build'))
    assert len(builds) == 1
    build = builds[0]
    ref = build / 'bench/compute_route_vulkan/reference-shaders'
    assert sha(ref / 'identity.json') == identity['native_reference']['manifest']
    assert sha(ref / 'reference_spirv.h') == identity['native_reference']['compiled_header']
    for p in ref.iterdir():
        if p.is_file():
            files[mode + '/reference-shaders/' + p.name] = p
    files[mode + '/build/CMakeCache.txt'] = build / 'CMakeCache.txt'
    map_dir = build / ('bench/compute_route_vulkan' if mode == 'compute' else 'bench/graph_route_vulkan')
    target_map = map_dir / ('hyle_' + mode + '_vulkan_native_cost_bench.map')
    assert target_map.is_file()
    files[mode + '/build/' + target_map.name] = target_map
    aa = build.parent / 'p1-evidence' / ('vulkan-' + mode + '-aa.json')
    assert json.loads(aa.read_text())['gate'] == 'PASS'
    files[mode + '/qualification/' + aa.name] = aa
    files['controller/' + tag + '-native-' + mode + '-run.log'] = root / (tag + '-native-' + mode + '-run.log')
    headlines = {}
    for row in summary['strata']:
        headlines.setdefault(row['workload'], []).append(row)
    modes[mode] = {workload: {
        'public_median_us_range': [min(x['public_median_us'] for x in rows), max(x['public_median_us'] for x in rows)],
        'native_median_us_range': [min(x['native_median_us'] for x in rows), max(x['native_median_us'] for x in rows)],
        'paired_extra_median_us_range': [min(x['paired_extra_median_us'] for x in rows), max(x['paired_extra_median_us'] for x in rows)],
        'interpretation': 'Range of four separate order-stratum medians; no pooled CI, equivalence or ranking.'}
        for workload, rows in headlines.items()}
for name in ('vulkan-native-cost-diagnostic.py', 'archive-native-cost.py',
             'run-windows-native-cost.ps1' if windows else 'run-air-native-cost.py'):
    files['controller/' + name] = root / name
out = root / ('archive-' + tag + '-native-' + short)
out.mkdir(exist_ok=False)
entries = {name: {'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
           for name, p in sorted(files.items())}
with zipfile.ZipFile(out / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, p in sorted(files.items()):
        z.write(p, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(out / 'raw.zip') as z:
    for name, row in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == row['sha256']
record = {'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'measurement_snapshot': snapshot, 'profile': args.profile,
    'collection': 'PASS', 'classification': 'NATURAL_ROUTE / NOT_COMPARABLE',
    'modes': modes, 'archive': {'file': 'raw.zip', 'sha256': sha(out / 'raw.zip'),
                              'entries': len(entries), 'per_entry_integrity': 'PASS'}}
(out / 'identity.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2), flush=True)
