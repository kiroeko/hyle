"""Completed actual-model consumers only; no new build/model run."""
from pathlib import Path
from array import array
import json,hashlib,sys
S=Path(__file__).resolve().parent;E=S.parent/'paged-exclusive-20261021'
attempt=int(sys.argv[1])if len(sys.argv)>1 else 2
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def stable(x):
 if isinstance(x,dict):return{k:stable(v)for k,v in x.items()if k!='seconds'and not k.endswith('_seconds')}
 if isinstance(x,list):return[stable(v)for v in x]
 return x
cases={};total=0;bf16=f32=0
for name,expected in [('single',18),('multi',72),('main',22),('pressure',30)]:
 a=S/f'{name}-run{attempt}';b=E/f'{name}-run1';assert read(a/'result.json')['exit']==read(b/'result.json')['exit']==0
 assert stable(read(a/'observation.json'))==stable(read(b/'observation.json'))
 av={p.relative_to(a/'trace').as_posix():p for p in(a/'trace').rglob('*')if p.name in('hidden.bf16','logits.f32')}
 bv={p.relative_to(b/'trace').as_posix():p for p in(b/'trace').rglob('*')if p.name in('hidden.bf16','logits.f32')}
 assert av.keys()==bv.keys()and len(av)==expected
 pairs=[]
 for rel,p in sorted(av.items()):
  raw=p.read_bytes();assert raw==bv[rel].read_bytes();typ='H'if p.suffix=='.bf16'else'I';mask=0x7f80 if typ=='H'else 0x7f800000
  words=array(typ);words.frombytes(raw);assert all((x&mask)!=mask for x in words)
  if typ=='H':bf16+=len(words)
  else:f32+=len(words)
  pairs.append(dict(relative=rel,current=identity(p),before=identity(bv[rel]),byte_equal=True,elements=len(words),nonfinite=0))
 total+=len(pairs);cases[name]=dict(current_result=identity(a/'result.json'),before_result=identity(b/'result.json'),all_nontime_observation_fields_equal=True,pairs=pairs)
assert total==142
out=dict(status='PASS',total_decision_vectors=total,all_byte_equal=True,bf16_elements=bf16,f32_elements=f32,cases=cases,scope='Fixed tested actual Qwen journeys, exact cache/Graph/restore/IDs/budget observations. No source-level implementation mirroring or new execution.')
(S/f'runtime-comparison{attempt}.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print('142 actual vectors byteequal and finite; nontime cache/state/work observations equal E.')
