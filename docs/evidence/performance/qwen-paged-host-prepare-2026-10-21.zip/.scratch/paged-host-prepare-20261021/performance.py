"""One completed-batch current/E/dense/peer window; no prefix-hit or multi-user claim."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/paged-prepare-20261021/performance.py').read_text(encoding='utf-8')
for old,new in [
 ("current=S / 'qwen-ready.json'","current=S / 'qwen-ready-attempt3.json'"),
 ("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'","before=R / '.scratch/paged-exclusive-20261021/qwen-ready-attempt1.json'"),
 ('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
  'Compare selected-append slot indexing and inline tail metadata to exact prior8a400 unique-tail E, original dense and matched llama.cpp; no kernel/math change;')]:
 assert source.count(old)==1;source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
