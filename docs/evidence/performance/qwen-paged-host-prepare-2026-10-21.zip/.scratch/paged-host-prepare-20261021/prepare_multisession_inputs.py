"""Extend only the three original D2 phases to32; checkpoint P128+D1 stays129."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1];P=R/'.scratch/qwen-prefix-20261021/inputs/plan.json'
M=R/'.scratch/multi-session-performance-20261021';O=M/'inputs/long';O.mkdir(parents=True,exist_ok=False)
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
plan=read(P);cases={};manifest=[];logical=generated=0
for name in ('seed','branch_a','branch_b','full_hit'):
 old=plan['cases'][name];out=O/name;out.mkdir();schedule=[];phases=[]
 for i,v in enumerate(old['phases'],1):
  ids=v['ids'].copy()
  if v['kind']=='decode'and len(ids)==2:ids=(ids*16)[:32]
  assert len(ids)==(32 if v['kind']=='decode'and len(v['ids'])==2 else len(v['ids']))
  file=out/f'{i}-{v["kind"]}.ids';file.write_text('\n'.join(map(str,ids))+'\n',encoding='utf-8')
  schedule.append(f'{v["kind"]} {file.name}\n');phases.append(dict(kind=v['kind'],ids=ids,source=identity(file)))
  logical+=len(ids);generated+=1 if v['kind']=='prompt'else len(ids)
 (out/'schedule.txt').write_text(''.join(schedule),encoding='utf-8');manifest.append(f'{name} {name}/schedule.txt\n')
 cases[name]=dict(schedule=identity(out/'schedule.txt'),phases=phases)
(O/'sessions.txt').write_text(''.join(manifest),encoding='utf-8')
assert logical==645 and generated==102
result=dict(source=identity(P),manifest=identity(O/'sessions.txt'),cases=cases,capacity=256,max_sessions=4,active_sequences=1,logical_processed_tokens=logical,logical_output_tokens=generated,
 expected_actual_prefill_tokens=161,expected_actual_decode_tokens=97,expected_graph_calls=101,expected_graph_tokens=258,expected_prefix_hits=3,expected_full_hits=1,expected_reused_tokens=387,
 limits='Four named sessions, serial turn cohort. Seed P128+D1 is actual129 checkpoint, A/B suffixes1/16, fullhit129 noGraph, seed secondturn16+32. Only originalD2 tapes repeated to32; fixed teacher-forced inputs, not free generation, simultaneous GPU batch or realistic serving throughput.')
(M/'inputs/plan.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Prepared shared-prefix long workload645logical/102output,258actualtokens/101Graph, original checkpoint129.')
