"""Host-only independent recomputation of this frozen finite window."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex
import statistics

S = Path(__file__).resolve().parent.parent
P = S / 'performance'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stat(values):
    values = [v for v in values if v is not None]
    return dict(count=len(values), min=min(values) if values else None,
                median=statistics.median(values) if values else None,
                max=max(values) if values else None, samples=values)


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def compact_stat(values):
    result = stat(values)
    result.pop('samples')
    return result


inputs = read(P / 'timing/inputs.json')
plan = inputs['plan']
manifest = Path(plan['manifest']['path'])
assert identity(manifest)['sha256'] == plan['manifest']['sha256']
schedule = []
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip():
        continue
    kind, file = shlex.split(line)
    ids_path = manifest.parent / file
    ids = [int(v) for v in ids_path.read_text(encoding='utf-8').split()]
    schedule.append(dict(kind='prefill' if kind == 'prompt' else kind,
                         ids=ids, source=identity(ids_path)))
assert [len(p['ids']) for p in schedule] == [256, 32] * 3
assert sum(len(p['ids']) for p in schedule) == 864
assert sum(1 if p['kind'] == 'prefill' else len(p['ids']) for p in schedule) == 99

rows, raw_artifacts, all_ids, checks = [], [], [], []
for entry in read(P / 'timing/runs.json'):
    folder = Path(entry['folder'])
    process = read(folder / 'result.json')
    assert process == entry['process'] and process['exit'] == 0
    assert not process['memory_only'] and not process['profiler']
    arm = entry['variant']
    assert process['image']['sha256'] == inputs['images'][arm]['sha256']
    command = process['command']
    assert command[command.index('--capacity') + 1] == '1024'
    assert Path(command[command.index('--schedule') + 1]) == manifest
    native_path = folder / ('peer-result.json' if arm == 'peer' else 'stdout.log')
    raw = read(native_path)
    assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
    assert raw['turn_count'] == 3 and raw['phase_count'] == 6
    if arm == 'peer':
        assert raw['context_capacity'] == 1024 and raw['requested_context_capacity'] == 1024
    else:
        assert raw.get('prefix_cache', 'off') == 'off'
    cursor = 0
    for n, (actual, expected) in enumerate(zip(raw['phases'], schedule)):
        assert actual['kind'] == expected['kind'] and actual['turn'] == n // 2 + 1
        assert actual['input_tokens'] == len(expected['ids'])
        assert actual['context_before'] == cursor
        cursor += len(expected['ids'])
        assert actual['context_after'] == cursor and actual['seconds'] > 0
    assert cursor == 864
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8')
    steps = []
    capture = []
    if arm == 'peer':
        steps = raw['steps']
        loading = raw['loading']
    else:
        for line in stderr.splitlines():
            if re.match(r'^round\d+_(prefill|decode\d+) ', line):
                name, *parts = line.split()
                fields = dict(v.split('=', 1) for v in parts)
                steps.append(dict(name=name, turn=int(re.match(r'round(\d+)', name)[1]),
                                  kind='prefill' if name.endswith('prefill') else 'decode',
                                  step_seconds=float(fields['step_seconds']),
                                  predicted_id=int(fields['next'])))
            if line.startswith('prepared '):
                fields = dict(v.split('=', 1) for v in line.split()[1:])
                capture.append((int(fields['capture_recorded']), int(fields['capture_reused'])))
        loading = {}
        for source, target in [('weights_load_seconds', 'model_load_seconds'),
                               ('model_seconds', 'model_seconds'),
                               ('shape_prepare_seconds', 'shape_prepare_seconds'),
                               ('startup_to_ready_seconds', 'startup_to_ready_seconds'),
                               ('first_token_elapsed_seconds', 'first_token_elapsed_seconds')]:
            values = re.findall(r'\b' + source + r'=([0-9.eE+-]+)', stderr)
            assert len(values) == 1
            loading[target] = float(values[0])
    assert len(steps) == 99
    predicted = raw.get('generated_ids', raw.get('predicted_ids'))
    assert len(predicted) == 99 and predicted == [x['predicted_id'] for x in steps]
    all_ids.append(predicted)
    prefills = [p for p in raw['phases'] if p['kind'] == 'prefill']
    decodes = [p for p in raw['phases'] if p['kind'] == 'decode']
    pwall = sum(p['seconds'] for p in prefills)
    dwall = sum(p['seconds'] for p in decodes)
    stable = [s for s in steps if s['kind'] == 'decode' and
              int(re.search(r'decode(\d+)$', s['name'])[1]) >= 7]
    assert len(stable) == 78
    rates = dict(prefill_tps=768 / pwall, full_decode_tps=96 / dwall,
                 session_output_tps=99 / raw['session_seconds'],
                 session_processed_tps=864 / raw['session_seconds'])
    observed_rounds = {}
    for phase in raw['phases']:
        values = dict(seconds=phase['seconds'], tps=phase['input_tokens'] / phase['seconds'])
        if phase['kind'] == 'decode':
            subset = [s for s in stable if s['turn'] == phase['turn']]
            values['stable_decode7_to32_tps'] = 26 / sum(s['step_seconds'] for s in subset)
        observed_rounds[phase['name']] = values
    row = dict(arm=arm, folder=str(folder), image=process['image'], rates=rates,
               prefill_wall_seconds=pwall, decode_wall_seconds=dwall,
               session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
               cold_output_tps=99 / raw['startup_total_seconds'],
               session_minus_phase_wall_seconds=raw['session_seconds'] - pwall - dwall,
               stable_decode7_to32_tps=78 / sum(s['step_seconds'] for s in stable),
               loading=loading, phases=observed_rounds,
               captures=dict(Counter(f'recorded{a}_reused{b}' for a, b in capture)))
    rows.append(row)
    for key, val in rates.items():
        old_key = dict(prefill_tps=None, full_decode_tps=None,
                       session_output_tps='output_tokens_per_second',
                       session_processed_tps='processed_tokens_per_second')[key]
        if old_key:
            assert math.isclose(val, entry['observation']['metrics'][old_key], rel_tol=1e-12)
    for name in observed_rounds:
        old = entry['observation']['rounds'][str(next(p['turn'] for p in raw['phases'] if p['name'] == name))]
        kind = 'prefill' if name.endswith('prefill') else 'decode'
        assert math.isclose(observed_rounds[name]['tps'], old[kind]['tokens_per_second'], rel_tol=1e-12)
    raw_artifacts.extend(identity(folder / n) for n in ['result.json', 'stdout.log', 'stderr.log'])
    if arm == 'peer':
        raw_artifacts.append(identity(native_path))
assert all(ids == all_ids[0] for ids in all_ids)

groups = {}
for arm in ['current', 'before', 'dense', 'peer']:
    sample = [r for r in rows if r['arm'] == arm]
    assert len(sample) == 3
    groups[arm] = dict(rates={k: stat([r['rates'][k] for r in sample]) for k in sample[0]['rates']},
                       session_seconds=stat([r['session_seconds'] for r in sample]),
                       startup_total_seconds=stat([r['startup_total_seconds'] for r in sample]),
                       cold_output_tps=stat([r['cold_output_tps'] for r in sample]),
                       stable_decode7_to32_tps=stat([r['stable_decode7_to32_tps'] for r in sample]),
                       loading={k: stat([r['loading'][k] for r in sample]) for k in sample[0]['loading'] if k.endswith('_seconds')},
                       phases={name: {k: stat([r['phases'][name][k] for r in sample]) for k in sample[0]['phases'][name]}
                               for name in sample[0]['phases']},
                       capture_patterns=[r['captures'] for r in sample])

memory = {}
fields = ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
          'gpu_shared_bytes', 'gpu_total_bytes']
for entry in read(P / 'memory/runs.json'):
    folder = Path(entry['folder']); process = read(folder / 'result.json')
    assert process == entry['process'] and process['exit'] == 0 and process['memory_only']
    arm = entry['variant']; assert process['image']['sha256'] == inputs['images'][arm]['sha256']
    command = process['command']
    assert command[command.index('--capacity') + 1] == '1024'
    assert Path(command[command.index('--schedule') + 1]) == manifest
    consumer_path = folder / ('peer-result.json' if arm == 'peer' else 'stdout.log')
    consumer = read(consumer_path)
    assert consumer['processed_tokens'] == 864 and consumer['generated_tokens'] == 99
    assert consumer.get('generated_ids', consumer.get('predicted_ids')) == all_ids[0]
    assert consumer['phase_count'] == 6 and consumer['turn_count'] == 3
    assert [(p['kind'],p['input_tokens'],p['context_before'],p['context_after']) for p in consumer['phases']] == [
        (p['kind'],len(p['ids']),sum(len(q['ids']) for q in schedule[:i]),sum(len(q['ids']) for q in schedule[:i+1])) for i,p in enumerate(schedule)]
    if arm == 'peer':
        assert consumer['context_capacity'] == consumer['requested_context_capacity'] == 1024
    else:
        assert consumer.get('prefix_cache','off') == 'off'
    raw_artifacts.extend(identity(folder / n) for n in ['stdout.log','stderr.log'])
    if arm == 'peer': raw_artifacts.append(identity(consumer_path))
    raw = read(folder / 'memory.json'); samples = raw['samples']
    assert all(b['timestamp_ns'] > a['timestamp_ns'] for a, b in zip(samples, samples[1:]))
    for sample in samples:
        dedicated, shared = sample['gpu_dedicated_bytes'], sample['gpu_shared_bytes']
        assert sample['gpu_total_bytes'] == (dedicated + shared if dedicated is not None and shared is not None else None)
    gaps = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(samples, samples[1:])]
    markers = {m['name']: m['timestamp_ns'] for m in process['markers']}
    phases = {}
    for i in range(1, 4):
        for kind in ['prefill', 'decode']:
            name = f'round{i}_{kind}'; begin, end = markers[name + '_begin'], markers[name + '_end']
            inside = [s for s in samples if begin <= s['timestamp_ns'] <= end]
            before = next((s for s in reversed(samples) if s['timestamp_ns'] <= begin), None)
            after = next((s for s in samples if s['timestamp_ns'] >= end), None)
            delta = {k: after[k] - before[k] if before and after and before[k] is not None and after[k] is not None else None for k in fields}
            phases[name] = dict(sample_count=len(inside), begin_ns=begin, end_ns=end,
                                sampled_peak_bytes={k: max((s[k] for s in inside if s[k] is not None), default=None) for k in fields},
                                null_sample_counts={k: sum(s[k] is None for s in inside) for k in fields},
                                bracket_delta_bytes=delta,
                                boundary_before_ns=before['timestamp_ns'] if before else None,
                                boundary_after_ns=after['timestamp_ns'] if after else None,
                                bracket_ages_ns=dict(before=begin-before['timestamp_ns'] if before else None,
                                                     after=after['timestamp_ns']-end if after else None))
    ready = markers.get('ready'); first = markers['round1_prefill_begin']
    ready_sample = next((s for s in reversed(samples) if ready is not None and ready <= s['timestamp_ns'] <= first), None)
    summary = read(folder / 'memory-summary.json')
    for name, phase in phases.items():
        assert phase['sample_count'] == summary['phase_windows'][name]['sample_count']
        assert phase['bracket_delta_bytes'] == summary['phase_windows'][name]['bracket_delta_bytes']
    memory[arm] = dict(folder=str(folder), requested_interval_seconds=raw['requested_interval_s'],
                       sample_count=len(samples), running_samples=sum(s['process_running'] for s in samples),
                       actual_sample_gaps_ms=compact_stat(gaps), sample_cost_ms=compact_stat([s['sample_duration_ns']/1e6 for s in samples]),
                       sampled_peak_bytes={k: max((s[k] for s in samples if s[k] is not None), default=None) for k in fields},
                       observed_OS_lifetime_high_water_bytes={k: max((s[k] for s in samples if s[k] is not None), default=None)
                           for k in ['os_peak_working_set_bytes', 'os_peak_commit_bytes']},
                       nonnull_samples={k: sum(s[k] is not None for s in samples) for k in fields},
                       null_samples={k: sum(s[k] is None for s in samples) for k in fields},
                       ready_baseline_bytes={k: ready_sample[k] if ready_sample else None for k in fields},
                       ready_baseline_unknown=ready_sample is None, phases=phases,
                       setup_error=raw['gpu_setup_error'], thread_error=raw['thread_error'],
                       unavailable_reasons=summary['unavailable_reasons'])
    raw_artifacts.extend(identity(folder / n) for n in ['result.json', 'memory.json', 'memory-summary.json'])

comparison = {}
for other in ['before', 'dense', 'peer']:
    comparison[other] = {}
    for metric in groups['current']['rates']:
        a, b = groups['current']['rates'][metric], groups[other]['rates'][metric]
        comparison[other][metric] = dict(current_vs_other_median_percent=100*(a['median']/b['median']-1),
                                        observed_ranges_overlap=max(a['min'], b['min']) <= min(a['max'], b['max']))

table = dict(status='frozen finite unprofiled comparison; host independently recomputed',
             workload='3*(256P+32D), capacity1024, same synthetic teacher-forced schedule,99 returned IDs; one process per sample',
             formulas=dict(prefill_tps='768 / sum(this process three prefill phase walls)',
                           full_decode_tps='96 / sum(this process three decode phase walls)',
                           session_output_tps='99 / this process after-ready session_seconds',
                           session_processed_tps='864 / this process session_seconds'),
             aggregation='Compute each process rate first; median/min/max over3 separate processes per arm. Never pool processes or divide by sums of phase medians.',
             images=inputs['images'], timing={a: dict(rates=groups[a]['rates'], loading=groups[a]['loading'],
                                                     session_seconds=groups[a]['session_seconds'],
                                                     startup_total_seconds=groups[a]['startup_total_seconds'],
                                                     cold_output_tps=groups[a]['cold_output_tps']) for a in groups},
             independent_memory={a: dict(samples=m['sample_count'], sampled_peak_bytes=m['sampled_peak_bytes'],
                                         requested_interval_seconds=m['requested_interval_seconds'],
                                         actual_sample_gaps_ms=m['actual_sample_gaps_ms'],
                                         sample_cost_ms=m['sample_cost_ms'],
                                         null_sample_counts=m['null_samples'], nonnull_sample_counts=m['nonnull_samples'],
                                         ready_baseline_unknown=m['ready_baseline_unknown'],
                                         ready_baseline_bytes=m['ready_baseline_bytes'],
                                         approximate_phase_deltas={name: dict(sample_count=v['sample_count'],
                                             gpu_dedicated_bytes=v['bracket_delta_bytes']['gpu_dedicated_bytes'],
                                             gpu_shared_bytes=v['bracket_delta_bytes']['gpu_shared_bytes'])
                                             for name, v in m['phases'].items()}) for a, m in memory.items()},
             comparison=comparison,
             limits=['Only3 timing processes per arm and1 independent memory process per arm; no statistical-significance claim.',
                     'Normal shared Windows desktop GPU window, not exclusive/fixed clocks. Preserve range overlap and window-specific background variation.',
                     'Memory samples are exact reported byte counters, but sampled maxima are lower bounds, not physical allocations. Dedicated/shared maxima are separate; total is maximum simultaneously observed sum.',
                     'Memory phase deltas use neighboring parent-time samples, not allocation attribution or exact boundary values. Missing ready/phase values remain null.',
                     f"Memory ready baselines unknown for{sum(m['ready_baseline_unknown'] for m in memory.values())}/4 arms: no sample in each such ready-to-prefill interval. Last-phase after brackets may include final-session cleanup; negative deltas are not proof of decode allocation release.",
                     'After-ready session TPS excludes weight loading; startup/load/ready/TTFT and cold startup_total_seconds are reported separately. Original per-engine host endpoints remain their recorded definitions, not interchangeable subphase costs. Independent memory or historical profiled time never enters timing denominators. Synthetic teacher-forced IDs are not free-running quality evidence.'])
table['conclusions'] = [
    'Same-window currentF versus priorE: aggregate prefill median%+.4f%%, full decode%+.4f%%, session-output%+.4f%%; overlapping observed ranges: %s. These are3-process observations, not a statistical-significance or universal-gain claim.' % (
        comparison['before']['prefill_tps']['current_vs_other_median_percent'],
        comparison['before']['full_decode_tps']['current_vs_other_median_percent'],
        comparison['before']['session_output_tps']['current_vs_other_median_percent'],
        ', '.join(k for k,v in comparison['before'].items() if v['observed_ranges_overlap'])),
    'CurrentF full-decode median versus dense%+.4f%% and versus peer%+.4f%%. Session-output median versus dense%+.4f%% and versus peer%+.4f%%; observed losses remain explicit and are not dismissed as timer resolution.' % (
        comparison['dense']['full_decode_tps']['current_vs_other_median_percent'],
        comparison['peer']['full_decode_tps']['current_vs_other_median_percent'],
        comparison['dense']['session_output_tps']['current_vs_other_median_percent'],
        comparison['peer']['session_output_tps']['current_vs_other_median_percent']),
    'Only2 source/object replacements (source2 main and append-index) distinguish currentF from inherited priorE closure;193 of195 input records are unchanged. The complete process measurements do not isolate either function self-cost.',
    'No new native trace for F and no profile time enters TPS. Old traces from different images/windows cannot establish the mechanism or predict the measured delta here.',
    'All12 timing processes and4 separate memory processes use the identical long schedule, capacity1024 and99 predicted IDs. Memory is one independent process per image/workload in this window. Exact observed bytes and nulls are preserved; sampled peaks, phase bracket deltas, driver granularity/migration/cache behavior do not identify physical allocations or causally attribute changes to this patch.'
]
table['labels'] = dict(current='F source2 fixed-tail/fresh-reserve and indexed append selected slots',
    before='E exclusive append + radix prior image',dense='retained dense consumer ff748694',peer='retained llama consumer9b259137')
save(P / 'public-table.json', table)
review = dict(status='host-only independent recomputation completed',
              source_inputs=[identity(P / p) for p in ['timing/runs.json', 'timing/summary.json', 'timing/inputs.json', 'memory/runs.json', 'memory/summary.json']],
              schedule=dict(manifest=identity(manifest), files=[p['source'] for p in schedule],
                            processed_tokens=864, prefill_tokens=768, decode_tokens=96, returned_tokens=99, capacity=1024),
              checks=dict(timing_processes=12, memory_processes=4, all_exit0=True, identical99_predictions_across_all_timing_and_memory_processes=True,
                          raw_stdout_or_peer_result_and_stderr_reparsed=True, each_timing_and_memory_process_capacity1024=True,
                          derived_session_and_phase_TPS_match_existing_runs=True,
                          independent_phase_memory_sample_counts_and_deltas_match_existing_summary=True),
              per_process=rows, per_round_summary={a: groups[a]['phases'] for a in groups},
              stable_decode_diagnostic={a: groups[a]['stable_decode7_to32_tps'] for a in groups},
              independent_memory=memory, comparison=comparison,
              conclusions=table['conclusions'],
              source_artifacts=raw_artifacts, public_table=identity(P / 'public-table.json'),
              recompute_script=identity(__file__),
              runtime_equality_review=identity(S / 'review/runtime-comparison.json'),
              background_snapshots=[identity(P / mode / name) for mode in ['timing', 'memory']
                  for name in ['window-before.json', 'window-after.json', 'window-before-gpu.stdout.log',
                               'window-after-gpu.stdout.log', 'window-before-compute_apps.stdout.log',
                               'window-after-compute_apps.stdout.log'] if (P / mode / name).exists()],
              independent_mechanism_evidence=dict(new_trace_available=False, boundary='No new native trace for F. Historical trace/kernel/launch counts belong to their own images and windows; no causal or profiled-duration TPS claim is made.'),
              fair_scope=table['limits'], activity=dict(builds=0, GPU_runs=0, product_edits=0))
save(S / 'review/performance-review.json', review)
for arm in groups:
    print(arm, {k: round(v['median'], 6) for k, v in groups[arm]['rates'].items()}, memory[arm]['sampled_peak_bytes'])
print(json.dumps(dict(public_table=identity(P / 'public-table.json'), review=identity(S / 'review/performance-review.json'))))
