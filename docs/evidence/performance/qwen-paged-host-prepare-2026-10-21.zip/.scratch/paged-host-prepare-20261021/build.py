"""One consumer owner against retained E; no Compute/Graph/SDK rebuild."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'.scratch/paged-exclusive-20261021'
sp=importlib.util.spec_from_file_location('e_helpers',E/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
b,c=h.b,h.c
def compile_owner(mode,attempt):
 h.S=S
 return h.compile_owner('main'if mode=='qwen'else mode,attempt)
def link(mode,attempt,owner_attempt,append_attempt):
 prior_path=E/f'{mode}-ready-attempt{2 if mode=="probe"else 1}.json';prior=c.read(prior_path);base=c.read(prior['link_plan']['path'])
 tag='main'if mode=='qwen'else'probe';records=[];record_paths=[];replacements={}
 if mode in ('qwen','probe'):
  rp=S/f'compile{owner_attempt}'/tag/'identity.json';rec=c.read(rp);records.append(rec);record_paths.append(rp)
  replacements[c.key(E/f'compile2/{tag}/{tag}.obj')]=rec['object']
 if append_attempt:
  rp=S/f'compile{append_attempt}/append/identity.json';rec=c.read(rp);records.append(rec);record_paths.append(rp)
  replacements[c.key(E/'compile1/append/append.obj')]=rec['object']
 assert records and all(h.same(rec['source'])and h.same(rec['object'])and all(h.same(x)for x in rec['dependencies'])for rec in records)
 assert all(h.same(x)for x in base['inputs'])
 assert all(sum(c.key(x['path'])==key for x in base['inputs'])==1 for key in replacements)
 out=S/f'{mode}-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/(mode+'.exe')
 inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
 command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(prior['link_plan']['path']),replaced_inputs=[dict(before=x,after=replacements[c.key(x['path'])])for x in base['inputs']if c.key(x['path'])in replacements],added_inputs=[],compiled_records=[b.identity(p)for p in record_paths],NVCC=0,SDK_builds=0))
 env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
 for dll in Path(prior['image']['path']).parent.glob('*.dll'):os.link(dll,out/dll.name)
 runtime=c.read(prior['runtime_environment']['path']);runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(p)for p in out.glob('*.dll')]
 if mode=='cpu'and 'CPU_native_overlay'in runtime:runtime['CPU_native_overlay']['destination']=b.identity(out/'hyle_ggml_cpu_append_hyca.dll')
 c.save(out/'runtime-environment.json',runtime)
 source=records[0]['source']if mode in ('qwen','probe')else prior['source']
 c.save(S/f'{mode}-ready-attempt{attempt}.json',dict(image=b.identity(image),source=source,fresh_sources=[rec['source']for rec in records],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),NVCC=0,SDK_builds=0))
 print('READY',mode,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=('qwen','probe','append','cpu','cuda'));p.add_argument('--attempt',type=int,default=1);p.add_argument('--owner-attempt',type=int,default=1);p.add_argument('--append-attempt',type=int,default=0);p.add_argument('--link',action='store_true');a=p.parse_args()
 if a.link:link(a.mode,a.attempt,a.owner_attempt,a.append_attempt)
 else:compile_owner(a.mode,a.attempt)
