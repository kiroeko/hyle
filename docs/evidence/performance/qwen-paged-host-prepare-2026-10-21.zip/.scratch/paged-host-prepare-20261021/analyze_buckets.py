"""Decompose the completed E timing window, no new execution/instrumentation."""
from pathlib import Path
import json,re,statistics
S=Path(__file__).resolve().parent;E=S.parent/'paged-exclusive-20261021'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=[]
for run in read(E/'performance/timing/runs.json'):
 if run['arm']!='hyle':continue
 current=None;turns={str(i):[]for i in range(1,4)}
 for line in(Path(run['folder'])/'stderr.log').read_text().splitlines():
  if line.startswith('prepared T='):current=dict(re.findall(r'(\w+)=([^\s]+)',line))
  match=re.match(r'round(\d+)_decode(\d+) tokens=',line)
  if match:
   assert current is not None and current['T']=='1'
   turns[match[1]].append(dict(index=int(match[2]),cold_seconds=float(current['cold_batch_seconds']),recorded=int(current['capture_recorded'])))
   current=None
 assert all(len(x)==32 for x in turns.values())
 phases={p['name']:p for p in run['observation']['raw']['phases']}
 cold=sum(x['cold_seconds']for turn in turns.values()for x in turn)
 wall=sum(phases[f'round{i}_decode']['seconds']for i in range(1,4))
 assert wall>cold
 rows.append(dict(arm=run['variant'],folder=run['folder'],full_decode_seconds=wall,cold_prepare_seconds=cold,
  remaining_seconds=wall-cold,cold_ms_per_token=cold/96*1000,full_ms_per_token=wall/96*1000,remaining_ms_per_token=(wall-cold)/96*1000,
  capture_recorded_calls=sum(bool(x['recorded'])for turn in turns.values()for x in turn),turns=turns))
groups={a:{k:dict(median=statistics.median([v[k]for v in rows if v['arm']==a]),min=min(v[k]for v in rows if v['arm']==a),max=max(v[k]for v in rows if v['arm']==a))for k in ('full_decode_seconds','cold_prepare_seconds','remaining_seconds','cold_ms_per_token','full_ms_per_token','remaining_ms_per_token')}for a in ('current','before','dense')}
comparison={}
for a in ('before','dense'):
 comparison[a]={k:groups['current'][k]['median']-groups[a][k]['median']for k in ('cold_ms_per_token','full_ms_per_token','remaining_ms_per_token')}
representatives={a:sorted((v for v in rows if v['arm']==a),key=lambda v:v['full_decode_seconds'])[1]for a in groups}
additive={}
for a in ('before','dense'):
 additive[a]={k:representatives['current'][k]-representatives[a][k]for k in ('cold_ms_per_token','full_ms_per_token','remaining_ms_per_token')}
 assert abs(additive[a]['cold_ms_per_token']+additive[a]['remaining_ms_per_token']-additive[a]['full_ms_per_token'])<1e-12
out=dict(status='Actual full96decode completed E processes, all32cold logs per turn included',rows=rows,groups=groups,separate_median_differences=comparison,representative_median_wall_runs=representatives,representative_additive_differences=additive,
 limits=['Buckets are logged wall times from original unprofiled programs, no new GPU run. Full decode phase wall is inclusive, cold preparation is a known subinterval.',
 'Within each actual process full=cold+remaining. Separately computed component medians need not sum. Additive differences use each arm process selected solely by median full-decode wall, with both components from that same process.',
 'This is an observed subinterval comparison, not a causal attribution to any function or a promise the bucket is removable.',
 'remaining includes input writes, replay prep, submit/wait/device/host token and other per-step work. Never label it pure GPU time.',
 'Peer does not expose this identical host bucket; no peer cold estimate. Finite3process desktop window only.'])
(S/'preparation-decomposition.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(groups=groups,representative_additive_differences=additive),indent=2))
