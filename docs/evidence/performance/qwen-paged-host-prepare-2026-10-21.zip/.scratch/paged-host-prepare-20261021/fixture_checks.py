from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/paged-capture-20261021/fixture_checks.py').read_text(encoding='utf-8')
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
