"""Render the completed single-session four-arm window; no model execution."""
from pathlib import Path
import json,re,statistics
S=Path(__file__).resolve().parent;R=S.parents[1]
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
t=read(S/'performance/public-table.json');rates=t['timing'];mem=t['independent_memory'];cmp=t['comparison'];arms=('current','before','dense','peer')
timing=read(S/'performance/timing/summary.json');memory=read(S/'performance/memory/summary.json')['groups']
f=lambda a,k:rates[a]['rates'][k]['median']
lines=['## 最新完整性能对比','','**2026-10-21，分页主机准备修复后的四臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN，无MTP／图片；三轮`256新增输入＋32 decode`，容量1024、最终上下文864。各3新进程交错测速，显存另各1进程旁采。同权重、固定teacher-forced输入和续算历史；关闭trace／诊断及单会话前缀目录。多人／命中场景单列。','',
'当前`e7a7597d…`，本批前独占尾页版`8a400ecf…`，原dense `ff748694…`，llama.cpp `9b259137…`／`d9e03f1074db…`。当前相对before只替换main／append两个对象；193个输入不变，195→195。公共API、数学、权重与Provider DLL保留，不将整体差异归因单个函数。','',
'| 指标 | 当前分页Hyle | 本批前paged | 原dense Hyle | llama.cpp |','| --- | ---: | ---: | ---: | ---: |']
def add(label,fn,digits=2):lines.append('| '+label+' | '+' | '.join(f'{fn(a):.{digits}f}'for a in arms)+' |')
for i in range(1,4):add(f'第{i}轮prefill tok/s',lambda a,i=i:timing['groups'][a]['phases'][f'round{i}_prefill']['median'])
for i in range(1,4):add(f'第{i}轮完整decode tok/s',lambda a,i=i:timing['groups'][a]['phases'][f'round{i}_decode']['median'])
for label,k in [('合计prefill tok/s（768／三段prefill总wall）','prefill_tps'),('完整decode tok/s（96／三段decode总wall）','full_decode_tps'),('综合输出 tok/s（99／会话wall）','session_output_tps')]:add(label,lambda a,k=k:f(a,k))
add('会话wall s',lambda a:rates[a]['session_seconds']['median'],5)
add('入口至末输出 s（含加载／冷准备）',lambda a:rates[a]['startup_total_seconds']['median'],5)
for label,k in [('启动至ready s','startup_to_ready_seconds'),('模型权重加载 s（非冷盘带宽）','model_load_seconds')]:add(label,lambda a,k=k:rates[a]['loading'][k]['median'],5)
for label,k in [('GPU dedicated全程观测峰 GiB','gpu_dedicated_bytes'),('GPU shared全程观测峰 GiB','gpu_shared_bytes'),('GPU同一采样点总量观测峰 GiB','gpu_total_bytes'),('进程working set观测峰 GiB','working_set_bytes'),('进程private commit观测峰 GiB','private_commit_bytes')]:add(label,lambda a,k=k:mem[a]['sampled_peak_bytes'][k]/(1<<30),3)
lines+=['',f"每进程分别求比值后取3进程中位。相对before，prefill **{cmp['before']['prefill_tps']['current_vs_other_median_percent']:+.2f}%**、decode **{cmp['before']['full_decode_tps']['current_vs_other_median_percent']:+.2f}%**、综合**{cmp['before']['session_output_tps']['current_vs_other_median_percent']:+.2f}%**。prefill范围重叠，decode／综合的3进程范围本窗不重叠，属于有限窗口中的小幅改善，不作稳定普遍收益承诺。相对llama，合计prefill高{cmp['peer']['prefill_tps']['current_vs_other_median_percent']:.2f}%，decode慢{-cmp['peer']['full_decode_tps']['current_vs_other_median_percent']:.2f}%、综合慢{-cmp['peer']['session_output_tps']['current_vs_other_median_percent']:.2f}%；相对原dense，decode慢{-cmp['dense']['full_decode_tps']['current_vs_other_median_percent']:.2f}%、综合慢{-cmp['dense']['session_output_tps']['current_vs_other_median_percent']:.2f}%，这些本窗范围不重叠。没有用跨窗绝对数计算收益。",'']
for label,k in [('decode','full_decode_tps'),('综合','session_output_tps')]:lines.append('current／before／dense／参考的'+label+'三进程范围：**'+'／'.join(f"{rates[a]['rates'][k]['min']:.2f}–{rates[a]['rates'][k]['max']:.2f}"for a in arms)+' tok/s**。')
buckets={a:{str(i):[]for i in range(1,4)}for a in ('current','before')}
for run in read(S/'performance/timing/runs.json'):
 if run['variant']not in buckets:continue
 pending=None
 for line in(Path(run['folder'])/'stderr.log').read_text().splitlines():
  if line.startswith('prepared T='):pending=dict(re.findall(r'(\w+)=([^\s]+)',line))
  match=re.match(r'round(\d+)_decode\d+ tokens=',line)
  if match:
   assert pending is not None
   if int(pending['capture_recorded'])==0:buckets[run['variant']][match[1]].append(float(pending['cold_batch_seconds'])*1000)
   pending=None
stats={a:{i:dict(count=len(v),median_ms=statistics.median(v),min_ms=min(v),max_ms=max(v))for i,v in turns.items()}for a,turns in buckets.items()}
assert all(x['count']==90 for turns in stats.values()for x in turns.values())
(S/'performance/preparation-buckets.json').write_text(json.dumps(dict(groups=stats,scope='Complete cold bucket for90zero-record calls per turn; actual descriptor upload/wait included. No individual function attribution.'),indent=2)+'\n',encoding='utf-8')
lines+=['','零重录调用的完整冷准备桶按轮取中位，current约'+'／'.join(f"{stats['current'][str(i)]['median_ms']:.3f}"for i in range(1,4))+'ms，before约'+'／'.join(f"{stats['before'][str(i)]['median_ms']:.3f}"for i in range(1,4))+'ms。每轮各90次，包含descriptor上传和等待，不是某个函数自身耗时或可全部消除的预算。','本批没有重采物理kernel trace。已确认的代码变化是每步12个单尾权vector改为固定单槽、只预留实际fresh writer容量、descriptor分组／成功发布扫描从全计划S缩到同Invocation的K个写页槽；权限与上传等待合同不变。','',
'下面是P1→D1→P2→D2→P3→D3阶段内dedicated观测峰GiB，缺样保持未知：']
for a in arms:
 values=[]
 for i in range(1,4):
  for kind in ('prefill','decode'):
   phase=memory[a]['phase_windows'].get(f'round{i}_{kind}');value=phase['values']['gpu_dedicated_bytes']['max']if phase else None;values.append('未知'if value is None else f'{value/(1<<30):.3f}')
 lines.append(a+'：**'+'→'.join(values)+'**。')
lines+=['','旁采请求10ms，实际间隔中位current／before／dense／参考约'+'／'.join(f"{mem[a]['actual_sample_gaps_ms']['median']:.2f}"for a in arms)+'ms。4个ready基线均未知；观测峰是采样下界，总量取同一采样点之和的峰。阶段边界可能跨入退出，负delta不作为推理显存节省。',
'12个测速与4个显存进程的99个预测ID均一致，另有142份真实向量及原生取消退休检查。当前与before dedicated／shared／同刻总量峰相同；页池容量未变。未固定时钟或独占GPU，不将小样本作为长期胜负或模型质量证明。',
'[本批源码、命令、数值／性能复算](../evidence/performance/qwen-paged-host-prepare-2026-10-21.json)。下一步是同完整状态、同命中边界的多会话对照，并优先处理其暴露的实际准备或计算慢项；MTP／图片及其它原生后端仍有实现工作。','']
p=R/'docs/developer/current-work.md';old=p.read_text(encoding='utf-8');assert old.count('## 最新完整性能对比')==1;p.write_text(old.split('## 最新完整性能对比')[0]+'\n'.join(lines),encoding='utf-8')
print('Updated complete F single-session four-item table.')
