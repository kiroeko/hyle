"""Exact stage-only leaves, written to root test.ps1 before execution."""
from pathlib import Path
import json,hashlib
S=Path(__file__).resolve().parent;R=S.parents[1]
def identity(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
targets=[]
for folder in sorted(S.glob('*-link*')):
 if folder.is_dir():
  for p in folder.iterdir():
   if p.is_file()and(p.suffix in ('.map','.lib','.exp')or(p.suffix=='.exe'and p!=S/'qwen-link3/qwen.exe')):targets.append(p)
for name in ('single','multi','main','pressure'):
 targets += [p for p in (S/f'{name}-run2/trace').rglob('*')if p.is_file()and p.name in ('hidden.bf16','logits.f32')]
assert len(targets)==len(set(targets))and all(p.resolve().is_relative_to(S)for p in targets)
plan=dict(targets=[identity(p)for p in targets],total_bytes=sum(p.stat().st_size for p in targets),receipt=str(R/'docs/evidence/performance/qwen-paged-host-prepare-2026-10-21.cleanup.json'),
 reason='Only superseded/host-fixture images, maps/import stubs and the superseded main-only run2 decision payload. Final run3 vectors and current Qwen3 retained. Relink commands/objects and source/failure/pass evidence retained.',
 kept=['Currente7a759 Qwen3, prior8a400/dense/llama matched images; final3 actual142 vectors and oracles, all changed objects, before/frozen source/commands/reviews, dependencies/SDK/models and new multi-session peer image. No recursive deletion or cross-stage deletion.'])
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=(R/'.scratch/paged-exclusive-20261021/cleanup-script.ps1').read_text(encoding='utf-8').replace('paged-exclusive-20261021','paged-host-prepare-20261021').replace('qwen-exclusive-radix-2026-10-21','qwen-paged-host-prepare-2026-10-21')
(R/'test.ps1').write_text(script,encoding='utf-8');(S/'cleanup-script.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(targets),bytes=plan['total_bytes'],script=identity(R/'test.ps1'),targets=[str(p.relative_to(R))for p in targets]),indent=2))
