"""Freeze two completed finite windows and the concrete next consumer seam."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];M=R/'.scratch/multi-session-performance-20261021'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def pack(stage,stem,extra):
 report=R/'docs/evidence/performance'/(stem+'.json');archive=report.with_suffix('.zip');assert not report.exists()and not archive.exists()
 allowed={'.json','.py','.ps1','.log','.diff','.patch','.txt','.md','.cc','.cpp','.h','.tsv','.xml'};paths={}
 for p in stage.rglob('*'):
  if p.is_file()and p.suffix in allowed and 'tmp'not in p.relative_to(stage).parts and '__pycache__'not in p.parts and p.name!='published.json':paths[p.relative_to(R).as_posix()]=p
 for p in extra:
  p=Path(p).resolve();paths[p.relative_to(R).as_posix()]=p
 inventory=[dict(archive_path=n,**identity(p))for n,p in sorted(paths.items())]
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for n,p in sorted(paths.items()):z.write(p,n)
  z.writestr('manifest.json',json.dumps(dict(files=inventory,scope='Exact selected source/before/diffs, cached-increment recipes/identities, actual commands/results/logs, fixed inputs and independent host recomputation.',excluded='No SDK/dependency/native libraries/model/exe/object/map or duplicate decision payloads. Current images, final regression vectors and source oracles remain retained scratch. Reconstructible trial/test images may be removed by exact recorded cleanup.'),indent=2))
 with zipfile.ZipFile(archive)as z:assert z.testzip()is None
 return report,archive,inventory
docs=[R/n for n in ('docs/developer/current-work.md','docs/developer/performance/decode.md','docs/architecture/graph-design.md')]
freeze=read(S/'implementation/source-freeze.json');assert len(freeze['files'])==2
for row in freeze['files']:assert identity(row['current']['path'])==row['current']and identity(row['frozen']['path'])==row['frozen']
for mode,n in [('timing',12),('memory',4)]:
 runs=read(S/f'performance/{mode}/runs.json');assert len(runs)==n and all(x['process']['exit']==0 for x in runs)
for name in ('single-run3','multi-run3','main-run3','pressure-run3','probe-run3','cpu-run1','cuda-run1'):assert read(S/name/'result.json')['exit']==0
numeric=read(S/'runtime-comparison3.json');assert numeric['total_decision_vectors']==142 and numeric['all_byte_equal']
report,archive,inventory=pack(S,'qwen-paged-host-prepare-2026-10-21',[*docs,*[Path(v['current']['path'])for v in freeze['files']]])
save(report,dict(date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),status='Two host preparation changes implemented, related CPU/CUDA/realQwen checks and one finite four-arm comparison complete. Broader goal remains active.',
 archive=identity(archive),archive_file_count=len(inventory),current_image=read(S/'qwen-ready-attempt3.json')['image'],current_ready=identity(S/'qwen-ready-attempt3.json'),
 source_freeze=identity(S/'implementation/source-freeze.json'),sources=freeze['files'],docs=[identity(p)for p in docs],
 implementation=['Single inherited tail per bank is inline in StepState, removing12 one-element vector allocations. Fresh writer vectors reserve only actual new pages; any failed tail reservation rolls back before COW fallback can allocate.',
 'Each original Invocation cold-links its exact selected append Slots once, using two private nonowning pointers per Slot and no extra registry/container/allocation. Descriptor match/occupied checks and successful-outcome latch traverseK selected append slots rather thanS full plan regions. No page permission/epoch/ready fact is cached.',
 'Original indexed node visitor/idle/native-retired/result/outcome gates remain. Full resolved old/new page mappings, Queue/resource/host/capacity equality, splitting, separate Invocation metadata, invalidation and actual upload wait unchanged. No public API, model math, native kernels, provider DLL or alternate executor changes.'],
 build=dict(successful_host_compiles=5,successful_links=8,NVCC=0,SDK_builds=0,closure='Exactlymain+append replaced,193 of195 inputs unchanged. Intermediate main-only images were checked but final3 alone supports final claims.',setup_correction='Initial CPU/CUDA link helper selected nonexistentE ready2 instead of ready1, so no link launched. Corrected recipe selector; final actual CPU/CUDA builds and runs pass. No failed native/compiler command or ignored red test.'),
 correctness=dict(vector_count=142,byte_equal=True,finite=True,independent_review=identity(S/'review/runtime-comparison.json'),native_retirement=read(S/'probe-run3/observation.json'),cpu=identity(S/'cpu-run1/result.json'),cuda=identity(S/'cuda-run1/result.json'),limits='WindowsCPU/CUDA tested shapes/journeys; not allOS/native backends, independent quality or simultaneous multiuser throughput.'),
 performance=dict(table=read(S/'performance/public-table.json'),independent_review=identity(S/'review/performance-review.json'),preparation_buckets=read(S/'performance/preparation-buckets.json'),
  conclusion='VsE same-window fullD+0.8086%,output+0.5465%,3process observed ranges nonoverlap; P+0.6094%rangesoverlap. StillD-3.3542%/output-1.0388%vspeer andD-3.0551%/output-2.7587%vsdense. Small desktop window, not universal/stable/causal function effect. No F new native trace. Memory peaks unchanged vsE.'),
 prior_window_latency_decomposition=identity(S/'preparation-decomposition.json'),
 new_real_workload='Matched multi-session shared-prefix comparison is separately published as qwen-multisession-prefix-2026-10-21.json. It exposes per-session execution-resource duplication; no per-token scanning or cache miss is assumed without evidence.',
 mtp_research=identity(R/'docs/evidence/research/qwen35-mtp-consumer-audit-2026-10-21.json'),
 cleanup_plan=identity(S/'cleanup-plan.json'),cleanup_script=identity(S/'cleanup-script.ps1'),
 remaining='Model-owned finite execution bundles borrowed by actual active episodes, isolated Session snapshots/tails/history, no stop closing a sibling loan, native-retirement-safe failure replacement; then matched remeasure. MTP/images/other-native/all-model architecture work remain incomplete.'))
save(S/'published.json',dict(files=[identity(report),identity(archive)],archive_files=len(inventory)))

for mode,n in [('timing',9),('memory',3)]:
 runs=read(M/f'performance/{mode}/runs.json');assert len(runs)==n and all(x['process']['exit']==0 for x in runs)
for name in ('hyle-probe1','peer-short-probe1','peer-long-probe1'):assert read(M/name/'summary.json')['passed']and read(M/name/'result.json')['exit']==0
peer=read(M/'peer-ready-attempt1.json');assert identity(peer['image']['path'])==peer['image']and identity(peer['source']['path'])==peer['source']
extra=[*docs,R/'.scratch/paged-exclusive-20261021/review/llama-multisession-comparison-design.json',R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/peer-continuation/peer_benchmark.cpp',R/'tools/qwen35_text/session_schedule.h',R/'tools/qwen35_text/schedule.h']
report,archive,inventory=pack(M,'qwen-multisession-prefix-2026-10-21',extra)
save(report,dict(date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),status='Actual matched complete-state multi-session prefix probes and finite9timing/3memory comparison complete; concrete execution-resource preparation seam located, not yet fixed.',
 archive=identity(archive),archive_file_count=len(inventory),input_plan=identity(M/'inputs/plan.json'),peer_ready=identity(M/'peer-ready-attempt1.json'),peer_source=peer['source'],peer_image=peer['image'],
 underlying_reference='Retainedd9e03 llama library/native dependencies and same320tensor BF16 GGUF, one new host consumer TU/link, no upstream edit/SDK/kernel/model copy. Explicit unified KV pool1024,5native sequenceIDs, perrequestlogicalcap256. Actual hybrid.seq_cp includes recurrent tail state sharing and deferred COW; no fake historical truncation.',
 probes={n:dict(receipt=identity(M/n/'result.json'),summary=read(M/n/'summary.json'))for n in ('hyle-probe1','peer-short-probe1','peer-long-probe1')},
 performance=dict(table=read(M/'performance/public-table.json'),independent_review=identity(M/'review/performance-review.json'),timing=identity(M/'performance/timing/summary.json'),memory=identity(M/'performance/memory/summary.json')),
 findings=['All12completed processes match102IDs/645logical/258actual tokens,101model calls,3hits/1fullhit/387reused. Same original129completeKV/conv/GDN checkpoint and distinctA/Bsuffix1/16 plus sourcecontinuation. No error run passed as success.',
 'CurrentFvsE P+0.7200%,D+2.3296%,output+2.0044%; vspeer P-39.7193%,D-1.7014%,output-8.6602%. Per-process ratios then medians. Logical548P and actual161P rates are separately reported; output102/globaljourney wall, never sum overlapping session walls.',
 'Mean full wall difference106.0624ms versuspeer decomposes additively intoP88.0131ms,D17.9270ms,betweenphase0.1222ms. About83%isP; no claim this is pure GPU or entirely removable.',
 'Rawchild preparation medians within current P:seed57.0563ms,A20.5066ms,B39.8485ms. Current code rebuilds Phase/Invocation/IO/workspace perSession evenactive1. A actualT1 Pwall34.9786ms versuspeer11.5724ms; B actualT16P55.9891 versus16.6654ms. These subintervals are inside phase walls and not added twice.'],
 limits=['Finite serialactive1 four-named-session teacher-forced workload,3freshprocesses perarm. Not formal server, simultaneousGPUbatch throughput, general model quality, arbitrary checkpoint density or full capacity/eviction sweep.',
 'Hyle pool1040 physical KV rows and110469168Bstatebacking, peer1024rowsand113590272Bcachebacking. Same logical context256/committedN4+candidate, not byte-identical provisioning. Reference wrapper does not prove Hyle-equivalent cancellation/failure rollback; successful runs only.',
 'Original intermediate precision and hostlogits transfer differences persist. Actual completecheckpoint source semantics and calculated work, not identical arithmetic peroperator or guarantee equivalent quality.',
 'Separate memory samples requested10ms; actual gaps reported. Parser retained ready markers but dropped per-session phase names, so exact P/D VRAM deltas remain unknown; adjacentready samples not phase baselines. No extra remeasurement, inventedzero, globalfree allocation attribution or sumofpeakssubstitution. Fix marker extraction in next changed-batch memory runner.'],
 next='Share finite Phase/Invocation/IO/workspace at Model scope according to actual executing concurrency; Session retains complete state/tails/history. Claim original episode before shared IO write and release only after commit/abort, actual native retirement and result reads. Preserve fresh shape preparation cost in request/overall endpoints and do not instantiate unused shapes merely to move costs into startup. Recompare this exact workload after implementation.'))
save(M/'published.json',dict(files=[identity(report),identity(archive)],archive_files=len(inventory)))
print(json.dumps(dict(host=read(S/'published.json'),multisession=read(M/'published.json')),indent=2))
