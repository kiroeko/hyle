"""Prepare32 only: current main control0c62 versus retained peer433e.

No model/compiler/profile/download subprocess is started by this module.
"""
from pathlib import Path
from collections import Counter
import ast
import copy
import hashlib
import json

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
OLD = R / '.scratch/inference-review-current-window-20261028'
BUILD = W.parent / 'model-candidate/attempt2'
ARMS = ('hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve(); h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20): h.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def exact(row):
    assert pin(row['path']) == row, row['path']


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def main():
    assert not (W / 'plan.json').exists()
    assert not any((W / f'{scenario}-{mode}').exists() for scenario, mode in GROUPS)
    ast.parse((W / 'window.py').read_text(encoding='utf-8-sig'))
    ready_path = BUILD / 'ready-control.json'; current = read(ready_path)
    assert current['role'] == 'control' and current['closure_inputs'] == 229
    assert current['image']['sha256'] == '0c6227e048997fbf9f830153664371558b40bf2fc011ff587772a525cf4b76d9'
    assert current['compiled']['source']['sha256'] == current['compiled']['snapshot']['sha256'] == '41199a68784ea521affc47542b62f01ba430faeaebc1d56e34ff6e403bc86a15'
    assert current['compiled']['process']['exit'] == current['process']['exit'] == 0
    for key in ('image', 'runtime', 'inputs', 'recipe', 'source_freeze', 'plan'): exact(current[key])
    for key in ('source', 'snapshot', 'object', 'command', 'dependencies', 'actual_dependencies'): exact(current['compiled'][key])
    inputs = read(current['inputs']['path'])
    assert len(inputs) == len({p['path'] for p in inputs}) == 229 and current['compiled']['object'] in inputs
    peer = read(OLD / 'peer-ready.json')
    exact(peer['image']); exact(peer['runtime_environment'])
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    previous = read(OLD / 'binding.json')
    for key in ('prompt', 'input_manifest', 'schedule', 'protocol', 'GGUF_metadata_receipt'): exact(previous[key])
    gguf = previous['GGUF_offline_metadata']
    for key in ('plain', 'full_mtp'):
        assert Path(gguf[key]['path']).stat().st_size == gguf[key]['bytes']
    assert gguf['plain']['tensors'] == 320 and gguf['full_mtp']['tensors'] == 335
    fixture = Path(previous['input_manifest']['path']).parent
    assert len((fixture / 'prompt.ids').read_text().split()) == 154
    assert (fixture / 'prompt.ids').read_text().split() == Path(previous['prompt']['path']).read_text().split()
    runtime_ready = dict(image=current['image'], instrumented=False,
        canonical_main=current['compiled']['snapshot'], runtime_environment=current['runtime'],
        link_inputs=current['inputs'], build=pin(ready_path), actual_dependencies=current['compiled']['actual_dependencies'],
        source_freeze=current['source_freeze'], closure_inputs=229, current_Model_object=current['compiled']['object'],
        scope='Main4ca9 ordinary unmodified a/b math, current ON229 SDK; N32 scratch candidate excluded.')
    save(W / 'ready.json', runtime_ready); save(W / 'peer-ready.json', peer)
    old_arms = read(OLD / 'arms.json')
    arms = dict(note='Fresh32: current main0c62 ordinary-auto/MTP K1 versus retained433e ordinary/MTP. Peer433e is not latest upstream.',
        arms={name: copy.deepcopy(old_arms['arms'][name]) for name in ARMS})
    for name, row in arms['arms'].items():
        row['ready'] = str(W / ('ready.json' if name.startswith('hyle') else 'peer-ready.json'))
    save(W / 'arms.json', arms)
    binding = dict(status='PREPARED_ONLY_NOT_RUN', Hyle=current, peer=peer,
        current_main_product_commit='4ca9', current_main_image=current['image'], excluded_scratch_N32_candidate=True,
        closure_inputs=229, current_shared_SDK='Successful optional-ATen ON closure reused, no new build.',
        previous_window_reference=pin(OLD / 'plan.json'), retained_previous_runner=pin(OLD / 'window.py'),
        runner=pin(W / 'window.py'),
        runner_amendment='Remove ordinary-off diagnostic arm and its comparison; 4-arm cardinality/order/counts. Keep process runner, full producer parser, endpoints, partition gate, within-arm non-time checks and PSAPI/PDH10ms. Summary additionally preserves cross-engine full actual work/IDs.',
        parser_amendment_reused=previous['parser_amendment_reused'],
        prompt=previous['prompt'], input_manifest=previous['input_manifest'], schedule=previous['schedule'],
        GGUF_offline_metadata=gguf, GGUF_metadata_receipt=previous['GGUF_metadata_receipt'], protocol=previous['protocol'],
        scopes=previous['scopes'], endpoint_and_sampler=previous['endpoint_and_sampler'],
        actual_auto_counts=previous['actual_auto_counts'], historical_samples_pooled=False,
        payload_copied=False, payload_hashed=False, model_or_compiler_processes_started=0,
        peer_version_scope='Frozen433e is an existing reference image, not latest upstream.',
        fairness_scope='Same original model family/prompt/quotas, natural greedy. Existing engines diverge around output18; retain actual IDs/acceptance/verified and committed rows, never force bitwise-equal work.',
        process_limits=dict(unique_model_processes=32, timing=24, independent_memory=8,
            retained_execute_timeout_seconds=900, GPU_concurrency=1, automatic_retries=0))
    save(W / 'binding.json', binding)
    ordinal = 0; groups = []
    for scenario, mode in GROUPS:
        old = read(OLD / f'{scenario}-{mode}-plan.json')
        group = copy.deepcopy(old)
        order = list(ARMS) if mode == 'memory' else [ARMS[(i + j) % 4] for j in range(3) for i in range(4)]
        rows = []
        for local, arm in enumerate(order, 1):
            template = next(row for row in old['commands'] if row['arm'] == arm)
            row = copy.deepcopy(template); folder = W / f'{scenario}-{mode}' / f'{local:02d}-{arm}'
            command = row['command']; ordinal += 1
            if arm.startswith('hyle'):
                command[0] = current['image']['path']
                row.update(image=current['image'], environment=current['runtime'], ready=pin(W / 'ready.json'))
                assert command[command.index('--decode-overlap') + 1] == ('auto' if arm == 'hyle_auto' else 'off')
                assert command[command.index('--sampling') + 1] == 'greedy'
            else:
                command[0] = peer['image']['path']; command[command.index('--output') + 1] = str(folder / 'consumer-result.json')
                row.update(image=peer['image'], environment=peer['runtime_environment'], ready=pin(W / 'peer-ready.json'))
                assert command[command.index('--model') + 1] == gguf['full_mtp' if arm == 'peer_mtp' else 'plain']['path']
            assert command[command.index('--mtp') + 1] == ('on' if arm.endswith('_mtp') else 'off')
            assert command[command.index('--capacity') + 1] == '1024'
            assert not any(arg in command for arg in ('--trace', '--decode-ids', '--ignore-eos', '--layer0-probe'))
            if scenario == 'single': assert command[command.index('--steps') + 1] == '64'
            else: assert command[command.index('--schedule') + 1] == binding['schedule']['path'] and '--steps' not in command
            restored = command.copy(); restored[0] = template['command'][0]
            if arm.startswith('peer'): restored[restored.index('--output') + 1] = template['command'][template['command'].index('--output') + 1]
            assert restored == template['command'], 'Only image/output locations change; same actual consumer arguments'
            row.update(ordinal=local, window_ordinal=ordinal, folder=str(folder))
            rows.append(row)
        assert Counter(row['arm'] for row in rows) == {arm: 3 if mode == 'timing' else 1 for arm in ARMS}
        assert group['memory_interval_seconds'] == 0.01 and not group['profiler'] and not group['warmup']
        group.update(commands=rows, arm_order=order, timing_processes=len(rows) if mode == 'timing' else 0,
            memory_processes=len(rows) if mode == 'memory' else 0, binding=pin(W / 'binding.json'),
            configuration=pin(W / 'arms.json'), canonical_main=current['compiled']['snapshot'],
            retained_plan=pin(OLD / f'{scenario}-{mode}-plan.json'), script=pin(W / 'window.py'),
            plan_only=True, current_window_comparison_only=True, historical_samples_pooled=False)
        save(W / f'{scenario}-{mode}-plan.json', group)
        groups.append(dict(scenario=scenario, mode=mode, processes=len(rows), order=order,
            plan=pin(W / f'{scenario}-{mode}-plan.json')))
    assert ordinal == 32
    plan = dict(status='PREPARED_NOT_RUN_NOT_COMPILED', processes=32, timing_processes=24,
        independent_memory_processes=8, groups=groups, ready=pin(ready_path), binding=pin(W / 'binding.json'),
        adapter=pin(W / 'window.py'), prepare_script=pin(__file__), scope=binding['scopes'], metrics=read(OLD / 'plan.json')['metrics'],
        future_commands=[['python', str(W / 'window.py'), 'run-one', s, m] for s, m in GROUPS],
        summary_command=['python', str(W / 'window.py'), 'summary'],
        constraints=['Prepare only; no model/compiler/GPU/download process.',
            '32 unique sequential native processes:24 timing+8 independent memory, no profiling/warmup/off diagnostic arm.',
            'Stop first native failure and preserve original attempts; parser errors repaired offline without replacement successful samples.',
            'Retained433e is not latest upstream; natural outputs/acceptance/rows may differ; retain complete work and output divergence.',
            'Only this fresh window supports current cross-engine comparisons; no old TPS pooling or causal gain claim.'])
    save(W / 'plan.json', plan)
    save(W / 'prepare-result.json', dict(status='PREPARED_32_NOT_RUN', plan=pin(W / 'plan.json'),
        image=current['image'], peer=peer['image'], commands=32, closure_inputs=229,
        compiler_processes=0, model_processes=0, GPU_processes=0))
    print('PREPARED_32_NOT_RUN:main0c62 versus peer433e,24timing+8independent memory;0native/CXX/GPU')


if __name__ == '__main__': main()
