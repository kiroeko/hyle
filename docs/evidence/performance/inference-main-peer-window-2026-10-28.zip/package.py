"""Offline-only lean evidence, invoked after all32 native processes complete.

No subprocess, build, profiler, download, benchmark rerun or source edit.
"""
from pathlib import Path
import hashlib
import json
import math
import zipfile

R = Path('C:/public/project-hyle/hyle')
W = Path(__file__).resolve().parent
DEST = R / 'docs/evidence/performance/inference-main-peer-window-2026-10-28'
ARMS = ('hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))
METRICS = ('prefill_tokens_per_second', 'full_decode_tokens_per_second',
           'session_output_tokens_per_second', 'session_processed_tokens_per_second')


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def main():
    summary = read(W / 'summary.json'); plan = read(W / 'plan.json'); binding = read(W / 'binding.json')
    assert summary['status'] == 'COMPLETE32_FOUR_ARMS_STABLE' and summary['processes'] == 32
    assert (plan['timing_processes'], plan['independent_memory_processes']) == (24, 8)
    for key in ('adapter', 'prepare_script', 'binding', 'ready'): exact(plan[key])
    current = binding['Hyle']; peer = binding['peer']
    assert current['role'] == 'control' and current['closure_inputs'] == 229 and binding['excluded_scratch_N32_candidate'] is True
    assert current['image']['sha256'] == '0c6227e048997fbf9f830153664371558b40bf2fc011ff587772a525cf4b76d9'
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    source_evidence_path = R / 'docs/evidence/performance/inference-small-projection-model-window-2026-10-28.json'
    source_evidence = read(source_evidence_path)
    assert source_evidence['images']['control']['image'] == current['image']
    assert source_evidence['images']['control']['source'] == current['compiled']['snapshot']
    assert source_evidence['images']['control']['inputs'] == current['inputs']
    records = []; metrics = []; memory = []; ratios = []
    for scenario, mode in GROUPS:
        group_plan = read(W / f'{scenario}-{mode}-plan.json')
        directory = W / f'{scenario}-{mode}'; group = read(directory / 'summary.json')
        runs = read(directory / 'runs.json'); expected = 12 if mode == 'timing' else 4
        assert group['processes'] == len(runs) == expected and group['within_arm_fixed_work_valid'] is True
        assert set(group['groups']) == set(ARMS)
        assert all(v['identical_complete_non_time_producer_report'] is True and not v['changes']
                   for v in group['within_arm_full_non_time_reports'].values())
        planned = {str(Path(e['folder']).resolve()): e for e in group_plan['commands']}
        for run in runs:
            folder = Path(run['folder']); entry = planned[str(folder.resolve())]
            process = read(folder / 'result.json'); command = read(folder / 'command.json')
            assert process['exit'] == 0 and not process.get('timeout') and not process.get('reader_errors')
            assert process['command'] == command['command'] == entry['command']
            assert process['arm'] == entry['arm'] and process['image'] == entry['image']
            assert process['memory_only'] is (mode == 'memory') and '--trace' not in process['command']
            gate = read(folder / 'timing-partition-gate.json'); assert gate['status'] == 'PASS' and gate['producer_values_unchanged'] is True
            raw = read(folder / 'consumer-result.json')
            p, d, total = (raw[k] for k in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
            assert all(math.isfinite(v) and v > 0 for v in (p, d, total))
            assert math.isclose(p + d, total, rel_tol=1e-5, abs_tol=2e-6)
            records.append(dict(scenario=scenario, mode=mode, arm=entry['arm'], ordinal=entry['ordinal'],
                window_ordinal=entry['window_ordinal'], folder=str(folder), pid=process['pid'],
                started_unix_ns=process['started_unix_ns'], finished_unix_ns=process['finished_unix_ns'],
                process=pin(folder / 'result.json'), producer_report=pin(folder / 'consumer-result.json')))
        if mode == 'timing':
            for arm in ARMS:
                values = group['groups'][arm]
                metrics.append(dict(scenario=scenario, arm=arm,
                    four_metrics={key: values[key] for key in METRICS},
                    complete_wall_seconds={key: values[key] for key in ('prefill_seconds', 'decode_seconds', 'session_seconds')},
                    startup={key: values[key] for key in ('weights_load_seconds', 'startup_to_ready_seconds',
                        'first_token_elapsed_seconds', 'startup_to_endpoint_seconds', 'cold_output_tokens_per_second')}))
            for role, hyle, reference in (('ordinary', 'hyle_auto', 'peer_plain'), ('mtp', 'hyle_mtp', 'peer_mtp')):
                ratios.append(dict(scenario=scenario, role=role,
                    hyle_over_peer_median={key: group['groups'][hyle][key]['median'] / group['groups'][reference][key]['median'] for key in METRICS}))
        else:
            for arm in ARMS:
                values = group['groups'][arm]
                memory.append(dict(scenario=scenario, arm=arm, sampled_peaks=values['sampled_peaks'],
                    ready_baseline=values['ready_baseline'], running_sample_count=values['running_sample_count'],
                    actual_sample_gaps_ms=values['actual_sample_gaps_ms'], null_sample_counts=values['null_sample_counts']))
    # A terminated Windows PID may be reused. The start plus planned ordinal
    # identifies the observation; PID alone must never reject a real run.
    assert len(records) == len({(v['pid'], v['started_unix_ns']) for v in records}) == len({v['window_ordinal'] for v in records}) == 32
    assert sorted(v['window_ordinal'] for v in records) == list(range(1, 33))
    assert len(summary['cross_engine_work']) == 4
    archive = {}
    for path in sorted(W.rglob('*')):
        if path.is_file() and path.suffix.lower() in ('.json', '.log', '.py') and '__pycache__' not in path.parts:
            assert path.name not in ('package-readback.json',)
            archive[path.relative_to(W).as_posix()] = path.read_bytes()
    # Reuse existing source provenance, without duplicating source/SDK/binaries
    # or adding earlier samples to the new32 raw observations.
    references = [pin(source_evidence_path), pin(source_evidence_path.with_suffix('.zip'))]
    for name, row in (('peer-source', peer['source']), ('peer-compiled-identity', peer['compiled_identity']), ('peer-link-plan', peer['link_plan'])):
        exact(row); archive['retained-provenance/' + name + Path(row['path']).suffix] = Path(row['path']).read_bytes()
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())],
                            self_hash='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json'] = manifest
    outzip, outjson = DEST.with_suffix('.zip'), DEST.with_suffix('.json')
    assert not outzip.exists() and not outjson.exists(), 'Never overwrite an evidence result'
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.performance.main-peer-window.v1', date='2026-10-28', status='COMPLETE32_MAIN_PEER_CURRENT_WINDOW',
        source_base_commit='4ca9', source_base_scope='Declared main source base; exact control image/source/ON229 input identities and referenced build evidence are authoritative.',
        main=dict(image=current['image'], source=current['compiled']['snapshot'], inputs=current['inputs'], closure_inputs=229,
            build_ready=plan['ready'], source_freeze=current['source_freeze'], scratch_N32_candidate_used=False),
        peer=dict(image=peer['image'], source=peer['source'], compiled_identity=peer['compiled_identity'], link_plan=peer['link_plan'],
            reference_scope='Existing frozen433e native core and multi-turn consumer. Not latest upstream; no current checkout revision inferred.',
            core_git_revision=None, core_git_revision_status='Retained ready does not directly state core git revision; image/consumer source/compiled/link identities preserve exact applicable reference.'),
        counts=dict(actual_model_processes=32, timing_processes=24, independent_memory_processes=8,
            timing_samples_per_arm_scenario=3, memory_samples_per_arm_scenario=1, CXX=0, links=0, downloads=0, automatic_retries=0),
        metrics=metrics, current_window_ratios=ratios, memory=memory, cross_engine_actual_work=summary['cross_engine_work'],
        process_index=records, process_identity='(PID,started_unix_ns) plus unique window_ordinal; Windows PID reuse permitted.',
        protocol=dict(plan=pin(W / 'plan.json'), summary=pin(W / 'summary.json'), binding=pin(W / 'binding.json'),
            endpoint_definitions=plan['metrics'], independent_memory_requested_interval_seconds=0.01,
            actual_unknown_null_values_unchanged=True, no_historical_samples_pooled=True),
        source_provenance_references=references,
        limits=['Only these fresh32 observations support the current cross-engine comparison. Previous windows or N32 A/B samples are not pooled or used as causal code-speedup evidence.',
            'Three timing samples per arm/scenario; descriptive medians/ranges, no statistical-significance claim.',
            'R1 two-turn is one resident session with two consecutive turns, not B2 or two users. C1024/N1/R1, P154 and original two-turn schedule, ordinary-auto and MTP K1.',
            'Natural generated outputs may diverge around output18. Exact output IDs, acceptance and actual target/draft/verified/committed rows remain visible; no forced equal-work, bitwise numerical or quality claim.',
            'Separate PSAPI/PDH samples, actual gaps and unavailable/null readings preserved. Ready absence is unknown, never zero. WS/private commit/GPU dedicated/shared remain separate; sampled peaks are lower bounds.',
            'Retained433e is not the latest llama.cpp. Main control0c62 uses current ON229; scratch N32 candidate is excluded. No compiler/profiler/download during the window.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as stream: stream.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as stream: stream.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
