"""Package only completed source/offline facts; never starts a native process."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

R = Path.cwd()
W = Path(__file__).resolve().parent
OUT = R/'docs/evidence/performance'
NAME = 'mtp-body-replay-design-2026-10-25'


def load(p):
    return json.loads(p.read_bytes())


def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


sources = {
    'src/graph/plan_state.h': [(1106, 1129), (1250, 1264)],
    'src/graph/executable.cc': [(1101, 1113), (1124, 1133), (1178, 1201), (8115, 8195), (9778, 9808)],
    'src/compute/resource_leases.cc': [(752, 758), (856, 877)],
    'engine/models/qwen35/session_state.h': [(68, 85)],
    'engine/models/qwen35/main.cc': [(2583, 2600), (4232, 4247), (4409, 4417)],
    'include/hyle/compute/detail/command_capture.h': [(12, 42)],
    'src/compute_backend_cuda/cuda_backend.cc': [(1311, 1348)],
}
source_pins, excerpts = {}, {}
for name, ranges in sources.items():
    path = R/name
    source_pins[name] = pin(path)
    lines = path.read_text(encoding='utf-8').splitlines()
    excerpts[name] = [dict(first_line=a, last_line=b,
                          text='\n'.join(f'{i}: {lines[i-1]}' for i in range(a, min(b, len(lines))+1)))
                      for a, b in ranges]
for name in ['submission', 'region_access', 'input_sources', 'resources', 'resource_report', 'constant_artifact']:
    source_pins[f'src/graph/{name}.cc'] = pin(R/f'src/graph/{name}.cc')
refs = [
    ('TensorRT-LLM', '46d9966b54d9d11998b712e732fb20f64d4d35c0', 'tensorrt_llm/_torch/pyexecutor/kv_cache/mamba_cache_manager.py'),
    ('TensorRT-LLM', '46d9966b54d9d11998b712e732fb20f64d4d35c0', 'tensorrt_llm/_torch/modules/mamba/mamba2_metadata.py'),
    ('TensorRT-LLM', '46d9966b54d9d11998b712e732fb20f64d4d35c0', 'tensorrt_llm/_torch/modules/mamba/gdn_mixer.py'),
    ('llama.cpp', '23b0202a189c44a54625aadcb37a946dd1d6278d', 'src/llama-memory-recurrent.cpp'),
    ('llama.cpp', '23b0202a189c44a54625aadcb37a946dd1d6278d', 'ggml/src/ggml-cuda/ggml-cuda.cu'),
]
reference_pins = []
for repo, commit, name in refs:
    p = R.parent/repo/name
    reference_pins.append(dict(repository=repo, independently_read_HEAD=commit,
                               file=name, bytes=p.stat().st_size,
                               sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(W/'source-pins.json').write_text(json.dumps(dict(scope='Read-only source reference, not new compiled inputs',
    sources=source_pins, local_reference_repositories=reference_pins), indent=2)+'\n', encoding='utf-8', newline='\n')
(W/'source-excerpts.json').write_text(json.dumps(excerpts, indent=2)+'\n', encoding='utf-8', newline='\n')
keys = load(W/'key-reconstruction.json')
counts = load(W/'opponent-counts.json')
files = [(W/name, name) for name in ['design.md', 'peer-state-contract.md', 'reconstruct_keys.py',
    'key-reconstruction.json', 'compare_capture_roles.py', 'opponent-counts.json', 'source-pins.json', 'source-excerpts.json', 'publish.py']]
for relative, archive in [
    ('.scratch/mtp-complete-binding-diff-20261025/records.json', 'inputs/complete-binding-records.json'),
    ('.scratch/mtp-complete-binding-diff-20261025/eligible-record-api-windows.json', 'inputs/eligible-record-api-windows.json'),
    ('.scratch/mtp-logical-call-trace-20261025/hyle/logical-records.json', 'inputs/hyle-logical-records.json'),
    ('.scratch/mtp-logical-call-trace-20261025/peer/logical-records.json', 'inputs/peer-logical-records.json'),
    ('.scratch/mtp-logical-call-trace-20261025/hyle/capture-actions.json', 'inputs/hyle-capture-actions.json'),
    ('.scratch/mtp-logical-call-trace-20261025/peer/capture-actions.json', 'inputs/peer-capture-actions.json'),
    ('.scratch/mtp-logical-call-trace-20261025/capture-action-summary.json', 'inputs/capture-action-summary.json'),
    ('.scratch/mtp-complete-binding-diff-20261025/eligible-boundary-surroundings.json', 'inputs/eligible-boundary-surroundings.json'),
]:
    files.append((R/relative, archive))
manifest = [dict(archive_path=name, **pin(path)) for path, name in files]
(W/'archive-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8', newline='\n')
files.append((W/'archive-manifest.json', 'archive-manifest.json'))
private_zip = W/'proof.zip'
with zipfile.ZipFile(private_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path, name in files:
        assert path.suffix.lower() not in ['.obj','.exe','.dll','.lib','.pdb','.exp']
        z.write(path, name)
with zipfile.ZipFile(private_zip) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)
public_zip = OUT/(NAME+'.zip')
public_zip.write_bytes(private_zip.read_bytes())
summary = dict(
    status='SOURCE_AND_EXISTING_TRACE_ONLY_NO_IMPLEMENTATION',
    generated_UTC=datetime.now(timezone.utc).isoformat(),
    scope='Offline/source results only. No new GPU/model/profile/build/download, product changes, or throughput measurements. Deeper performance work stopped per user priority.',
    reconstruction=dict(input=keys['input'], complete_body_queries=keys['body_queries'],
        complete_key_ports=keys['complete_key_ports_per_group'],
        original_record_set=keys['original_record_set'],
        actual_capacity2_reproduced=keys['original_capacity2_reproduces_all_actual_records'],
        simulations=[{k:v for k,v in keys[name].items() if k!='rows'} for name in [
            'original_capacity2','candidate_capacity3','theoretical_no_eviction_capacity66']],
        conclusion='Additional variant capacity gives no fewer recordings under the actual complete-key stream and real hard-clears; no native lifetime or resource proof implied.'),
    opponent_counts=dict(
        earlier_Hyle=dict(capture_records=32, instantiate=19, update=13, graphLaunch=132),
        later_Hyle_merged_seed=counts['arms']['hyle_later_seed_profile'],
        peer=dict(capture_records=7, target_captures=2, draft_captures=5, instantiate=2, update=7, graphLaunch=116,
                  ordered_capture_actions={'instantiate_then_update':2,'update_only':5}),
        peer_capture_by_role=counts['peer_capture_by_role'],
        earlier_logical_role_groups={arm:counts['arms'][arm+'_earlier_logical_profile']['groups'] for arm in ['hyle','peer']}),
    observation_windows=dict(body15_ms=78.431404, first_per_body_range2_ms=18.186282,
        other13_ms=60.245122, native_clear3_ms=11.597198, valid_key_address_miss10_ms=48.647924,
        warning='Descriptive API/capture windows only, not guaranteed removable cost or predicted speedup.'),
    conditional_state_IO_cost_gate=counts['conditional_state_IO_cost_gate'],
    implementation_readiness=dict(ready_safe_minimal_candidate=False,
        next_action='None in this batch. Functional and architecture work takes priority; concrete invalidation/ownership work is deferred.',
        rejected_here=['More retained variants for this logged stream', 'Ignoring physical offsets', 'Mixing new InvocationState layout with old cached TUs'],
        stopped_other_candidate='Small ingress CLOSED_NOT_MERGED; parent reported decode+0.006%, combined−0.38%, no stable gain.'),
    limits=counts['limits']+keys['limits']+[
        'Large fixed-state staging and indexed-pool/node-update/segmented options are source-level tradeoffs only; no product implementation or performance approval.',
        'No peer logical-call completion boundary equivalence is assumed. Hyle66 combined and peer65 target/draft calls have different T/work/acceptance and arithmetic precision.',
        'Archive keeps compact prior extracts and exact pins; original raw Nsight/sqlite/logs remain in their separately published parent batches. No raw activity data is regenerated here.'],
    sources=source_pins, local_reference_repositories=reference_pins,
    reproduction=dict(commands=[
        'python .scratch/mtp-body-variant-design-20261025/reconstruct_keys.py',
        'python .scratch/mtp-body-variant-design-20261025/compare_capture_roles.py'],
        requires='Existing pinned private raw SQLite/extracts at the original paths for count regeneration; archive contains the exact resulting API/capture actions and SQL.'),
    prior_public_evidence=[pin(OUT/'mtp-complete-binding-diff-2026-10-25.json'),
                           pin(OUT/'mtp-finish-phase-attribution-2026-10-25.json')],
    archive=dict(**pin(public_zip), members=len(files), testzip='PASS'), cleanup=dict(files=[], logical_bytes=0))
public_json = OUT/(NAME+'.json')
public_json.write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8', newline='\n')
(W/'publication.json').write_text(json.dumps(dict(public_json=pin(public_json), archive=pin(public_zip),
    members=len(files), testzip='PASS'), indent=2)+'\n', encoding='utf-8', newline='\n')
print((W/'publication.json').read_text())
