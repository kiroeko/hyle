# Matched peer state/capture: bounded source memo (stopped per updated priority)

No build, GPU, network, canonical/public evidence edits, or new candidate. This is an incomplete source comparison, not a new validation.

Matched closure: `.scratch/mtp-logical-call-trace-20261025/peer/ready.json` and `peer/link/command.json`: retained `llama.lib` from `.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/build/src`, native GGML libs from `.scratch/legacy-root/hyle-scratch/ggml-native-static/bin`. Its retained summary records llama commit `d9e03f1074dbd2979126d91dce1b5d304ec8394e`, GGML pin `456172ec733a135778adcd32d00e576a58232e45`; these contain previously recorded resource/cleanup patches, not a claim about latest upstream.

## Facts read before the stop

- Actual prior `peer/capture-actions.json`: 7 captures: target seq6/74 (2), draft seq7/19/35/67/75 (5); 2 instantiate+update, 5 update-only. CUDA API return codes are successful. These logs do not record the particular property triggering each recapture, so no per-event causal attribution is proved.
- `source/peer_multiturn.cc:273-297`: target context reserves `n_rs_seq=1` for MTP; draft has 0; target exports normalized hidden, draft consumes explicit token+host hidden rows. `:393-420` builds prior/carry host inputs, performs target verification, then trims and chooses committed carry/prior. That host staging is part of the actual peer path, unlike direct Hyle Snapshot input leases.
- Matched `source/src/llama-memory-recurrent.cpp:101-107`: per-layer r/s tensors are allocated as `mem_size*(1+n_rs_seq)` rows and kept in r_l/s_l. `:161-205`: partial removal permits a bounded rollback (1..n_rs_seq), with a single-use pending rollback index. `:443-445` requires trailing rollback tokens stay in the same ubatch. `:592-612` distinguishes exclusively owned sequence cell vs shared cell and selects/copies a new cell as required. This is persistent mutable sequence-bank semantics, not an exposed arbitrary immutable state-version/read-lease contract.
- Matched `source/src/models/qwen35.cpp:378-389,448`: obtains persistent r_l/s_l, builds convolution state and recurrent state from them, then runs recurrent attention. `source/src/llama-graph.cpp:2872,2965` identifies the KV-store construction; `:3466-3540` builds recurrent-state inputs. Exact KV input-index refresh/store and physical output addresses were not fully followed before the stop; do not claim every GDN/KV address is invariant.
- Actual native snapshot `.../source-4e1a7b2f39afe15d/src/ggml-cuda/ggml-cuda.cu:2639-2682`: graph key is first node pointer; unchanged nonzero UID bypasses property comparison; otherwise compare node structure plus source data pointers, sizes and strides. `:4483-4500`: require a stable second call before capture; property change resets warmup; stable warm calls reuse the instance. `:2685-2709,4430-4438`: recapture can update existing executable, reinstantiate only if ExecUpdate fails.

## Limited interpretation

Persistent banks plus explicit input staging can reduce address changes without necessarily needing as many graph variants. Reusing an existing executable after safe recapture is independently visible here; it does not prove launch-count reduction or throughput improvement for Hyle. Existing Hyle update/retirement mechanisms should be the comparison point, not deletion of identity/reader gates.

Peer's bounded sequence rollback is not equivalent to Hyle's immutable complete Snapshot, escaped old readers, expected-base atomic publication, cancellation/retirement, or arbitrary legal accepted-prefix repair. The selected consumer's trim/carry choice is evidence only for its actual synchronized K1 journey; EOS/quota/old-reader equivalence was not established in this narrow read. Do not import an in-place overwrite policy merely to reproduce its capture counts.

Stopped here on root's updated function/architecture-first direction. No additional implementation or experiment is proposed by this memo.
