"""Offline exact-equality reconstruction; unknown cells never count as hits."""
from pathlib import Path
from collections import Counter
import hashlib
import json

R = Path.cwd()
W = Path(__file__).resolve().parent
P = R / '.scratch/mtp-complete-binding-diff-20261025/records.json'
D = json.loads(P.read_bytes())
events = D['events']
groups = {e['saved']: (e['inv'], e['begin'], e['count']) for e in events
          if e['inv'] and e['saved'] and e['begin'] > 0}
width = {e['saved']: e['expected_ports'] for e in events
         if e['kind'] == 3 and e['saved'] in groups}
assert set(width) == set(groups) and set(width.values()) == {2031}
ports = {}
for p in D['ports']:
    ports.setdefault(p['event'], {})[p['flat']] = p

# Each entry is one complete physical tensor at one flattened key position.
# Equal cells are joined using the all-ports mismatch traversal. Actual changed
# cells carry the entire recorded TensorDesc/resource/handle/offset/span value.
parents, values = [], []
physical_ids = {}


def fresh():
    result = list(range(len(parents), len(parents) + 2031))
    parents.extend(result)
    values.extend([None] * len(result))
    return result


def root(x):
    while parents[x] != x:
        parents[x] = parents[parents[x]]
        x = parents[x]
    return x


def physical(p):
    # `diff` is the diagnostic row number, not part of a physical tensor.
    key = json.dumps({k: v for k, v in p.items() if k != 'diff'}, sort_keys=True)
    return physical_ids.setdefault(key, len(physical_ids))


def assign(x, value):
    x = root(x)
    assert values[x] is None or values[x] == value
    values[x] = value


def equal(a, b):
    a, b = root(a), root(b)
    if a == b:
        return
    assert values[a] is None or values[b] is None or values[a] == values[b]
    parents[b] = a
    if values[a] is None:
        values[a] = values[b]


def equate(a, b):
    for x, y in zip(a, b):
        equal(x, y)


live, active, current = {}, {}, {}
timeline = []
for e in events:
    saved, kind = e['saved'], e['kind']
    if saved not in groups:
        continue
    live.setdefault(saved, [None, None])
    if kind == 6:
        live[saved] = [None, None]
        active.pop(saved, None)
        timeline.append(('clear', saved, e['seq'], None))
    elif kind in (0, 5):
        key = (saved, e['seq'])
        assert key not in current
        current[key] = fresh()
        timeline.append(('query', saved, e['seq'], current[key]))
        if kind == 5:
            equate(current[key], active[saved])
    elif kind == 3:
        key = (saved, e['seq'])
        previous = live[saved][e['variant']]
        assert previous is not None and e['examined'] == e['expected_ports'] == 2031
        assert e['equal'] + e['changed'] == 2031 and not e['missing_old'] and not e['extra_old']
        changed = ports.get(e['i'], {})
        assert len(changed) == e['changed']
        for index, (a, b) in enumerate(zip(previous, current[key])):
            if index in changed:
                p = changed[index]
                assert p['flags'] == 16
                assign(a, physical(p['old']))
                assign(b, physical(p['new']))
            else:
                equal(a, b)
    elif kind == 4:
        equate(current[saved, e['seq']], live[saved][e['variant']])
        active[saved] = live[saved][e['variant']]
    elif kind == 9:
        live[saved][e['variant']] = current[saved, e['seq']]
        active[saved] = current[saved, e['seq']]


def compare(a, b):
    unknown = 0
    for x, y in zip(a, b):
        x, y = root(x), root(y)
        if x == y:
            continue
        if values[x] is not None and values[y] is not None:
            if values[x] != values[y]:
                return False
        else:
            unknown += 1
    return None if unknown else True


def simulate(capacity):
    cache, clock = {}, 0
    result = []
    for kind, saved, seq, key in timeline:
        if kind == 'clear':
            cache.pop(saved, None)
            continue
        clock += 1
        entries = cache.setdefault(saved, [None] * capacity)
        selected = None
        comparisons = []
        for i, entry in enumerate(entries):
            if entry is None:
                continue
            match = compare(entry[0], key)
            comparisons.append(match)
            if match is None:
                return dict(status='UNKNOWN_FULL_TUPLE_EQUALITY', capacity=capacity,
                            stop_at=dict(seq=seq, range=groups[saved][1:], candidate=i),
                            completed_queries=len(result), rows=result)
            if match:
                selected = i
                break
        hit = selected is not None
        if not hit:
            selected = next((i for i, entry in enumerate(entries) if entry is None), None)
            if selected is None:
                selected = min(range(capacity), key=lambda i: entries[i][1])
        entries[selected] = (key, clock)
        result.append(dict(seq=seq, range_begin=groups[saved][1], range_steps=groups[saved][2],
                           hit=hit, selected=selected, compared=len(comparisons)))
    return dict(status='EXACT_LOGGED_TUPLE_EQUALITY_SIMULATION', capacity=capacity,
                records=sum(not r['hit'] for r in result), hits=sum(r['hit'] for r in result), rows=result)


base, candidate, no_evict = simulate(2), simulate(3), simulate(66)
actual_record = {(e['seq'], e['begin']) for e in events if e['kind'] == 9 and e['saved'] in groups}
base_record = {(r['seq'], r['range_begin']) for r in base['rows'] if not r['hit']}
out = dict(status='EXISTING_LOG_EQUALITY_RECONSTRUCTION_ONLY',
           input=dict(path=P.relative_to(R).as_posix(), bytes=P.stat().st_size,
                      sha256=hashlib.sha256(P.read_bytes()).hexdigest()),
           body_groups=len(groups), body_queries=len(current), complete_key_ports_per_group=2031,
           complete_physical_cells=len(parents), connected_cells_with_literal_value=sum(values[root(x)] is not None for x in range(len(parents))),
           original_capacity2=base, candidate_capacity3=candidate,
           theoretical_no_eviction_capacity66=no_evict,
           original_record_set=sorted(actual_record),
           original_capacity2_reproduces_all_actual_records=base['status'].startswith('EXACT') and base_record == actual_record,
           limits=['Unknown complete-entry equality never counts as a hit or miss: simulation stops at the first unknown comparison.',
                   'Exact equality may be reconstructed symbolically from all equal positions plus complete changed Physical values; absolute values of invariant cells can remain unknown.',
                   'Every actual discard_keys is applied; hypothetical capacity does not suppress native/configuration/Queue invalidation.',
                   'This is an offline fixed-binding-stream counterfactual, not an executed artifact/lifetime/cost proof.'])
(W/'key-reconstruction.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps({k: v for k, v in out.items() if k not in ['original_capacity2','candidate_capacity3','theoretical_no_eviction_capacity66']}, indent=2))
for key in ['original_capacity2','candidate_capacity3','theoretical_no_eviction_capacity66']:
    print(key, {k: v for k, v in out[key].items() if k != 'rows'})
