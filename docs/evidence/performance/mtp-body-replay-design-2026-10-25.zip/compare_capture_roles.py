"""Existing Hyle/peer logical calls and real CUDA API counts, no native run."""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib
import json
import sqlite3

R = Path.cwd()
W = Path(__file__).resolve().parent
L = R / '.scratch/mtp-logical-call-trace-20261025'
F = R / '.scratch/mtp-finish-phase-20261025'
B = R / '.scratch/mtp-complete-binding-diff-20261025'
SQL = '''SELECT r.start,r.end,r.globalTid,r.correlationId,r.returnValue,s.value AS api
FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId
WHERE s.value LIKE '%StreamBeginCapture%' OR s.value LIKE '%StreamEndCapture%'
OR s.value LIKE '%GraphExecUpdate%' OR s.value LIKE '%GraphInstantiate%'
OR s.value LIKE '%GraphLaunch%' ORDER BY r.start'''


def load(p):
    return json.loads(p.read_bytes())


def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def summarize(apis):
    kinds = [('capture', 'StreamBeginCapture'), ('instantiate', 'GraphInstantiate'),
             ('update', 'GraphExecUpdate'), ('graphLaunch', 'GraphLaunch')]
    return {name: dict(count=sum(token in a['api'] for a in apis),
                       API_wall_ms=sum(a['end']-a['start'] for a in apis if token in a['api'])/1e6,
                       return_values=dict(Counter(str(a['returnValue']) for a in apis if token in a['api'])))
            for name, token in kinds}


out = dict(status='EXISTING_DATA_COUNTS_ONLY', SQL=SQL, arms={}, inputs={})
for arm in ['hyle', 'peer']:
    records_path = L/arm/'logical-records.json'
    records = load(records_path)
    c = sqlite3.connect('file:'+(L/arm/'trace1/trace.sqlite').as_posix()+'?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    apis = [dict(r) for r in c.execute(SQL)]
    c.close()
    rows, aggregate = [], defaultdict(list)
    for record in records:
        label = record['label'].split()[0]
        meta = record['meta']
        local = [a for a in apis if a['globalTid'] == record['globalTid']
                 and record['start_ns'] <= a['start'] and a['end'] <= record['end_ns']]
        row = dict(label=record['label'], meta=meta, counts=summarize(local),
                   wall_ms=record['cpu_range_ns']/1e6,
                   GPU_execution_union_ms=record['gpu_contained_union_ns']/1e6,
                   observed_eager_kernels=record['eager_kernels'])
        rows.append(row)
        aggregate[(label, meta.get('role'), meta.get('T', meta.get('target_T')), meta.get('draft_T'))].append((record, local))
    groups = []
    for key, group in aggregate.items():
        groups.append(dict(role=key[0], hyle_role=key[1], T=key[2], draft_T=key[3],
                           logical_calls=len(group), counts=summarize([a for _, local in group for a in local]),
                           no_graphLaunch_calls=[r['meta']['seq'] for r, local in group if not any('GraphLaunch' in a['api'] for a in local)],
                           source_matched_captured_launch_role_counts=dict(Counter(a['role'] for r, _ in group for a in r['captured_launches']))))
    capture = load(L/arm/'capture-actions.json')['actions']
    capture_windows = []
    for x in capture:
        assert x.get('end_capture') and x['events']
        capture_windows.append(dict(label=x['logical_label'], meta=x['meta'],
                                    actions=x['ordered_actions'],
                                    capture_through_last_native_API_ms=(x['events'][-1]['end']-x['begin']['start'])/1e6))
    out['arms'][arm+'_earlier_logical_profile'] = dict(groups=groups, all_API=summarize(apis),
        logical_rows=rows, capture_windows=capture_windows)
    out['inputs'][arm+'_logical_records'] = pin(records_path)
    out['inputs'][arm+'_capture_actions'] = pin(L/arm/'capture-actions.json')

# The later finish-phase profile contains the already-merged seed change.
joined = load(B/'eligible-record-api-windows.json')['all32']
nvtx = [json.loads(line) for line in (F/'extracts/nvtx.jsonl').read_text().splitlines()]
roots = [r for r in nvtx if r['label'] and r['label'].startswith('hyle/episode')]
runtime = [json.loads(line) for line in (F/'extracts/runtime.jsonl').read_text().splitlines()]
decode = [r for r in roots if 'target_T=2 ' in r['label']]
local = [a for a in runtime if any(r['globalTid'] == a['globalTid'] and r['start'] <= a['start'] and a['end'] <= r['end'] for r in decode)]
out['arms']['hyle_later_seed_profile'] = dict(logical_decode_calls=len(decode), all_decode_API=summarize(local),
    range_groups=[dict(role=label, capture_records=len(group),
                       native_action_counts=dict(Counter('instantiate' if 'Instantiate' in x['following_native_API']['api'] else 'update' for x in group)),
                       capture_through_native_API_ms=sum(x['capture_through_native_API_end_ms'] for x in group))
                  for label, group in [('small', [x for x in joined if x['range_begin']==0]), ('body', [x for x in joined if x['range_begin']>0])]])
peer_capture = out['arms']['peer_earlier_logical_profile']['capture_windows']
out['peer_capture_by_role'] = {role: dict(count=len(group), wall_ms=sum(x['capture_through_last_native_API_ms'] for x in group),
                                           seqs=[x['meta']['seq'] for x in group])
    for role, group in [(role, [x for x in peer_capture if x['label'].startswith('peer/'+role)])
                         for role in ['target_decode','draft_decode']]}
body = [x for x in joined if x['range_begin']>0]
valid_address = [x for x in body if x['seq'] not in [2,3,37,38,43]]
payload = 18*(36864+1048576)
copy_bytes = 66*2*payload
offset_window_ms = sum(x['capture_through_native_API_end_ms'] for x in valid_address)
out['conditional_state_IO_cost_gate'] = dict(
    boundary_bytes=payload, input_plus_selected_output_bytes_per_episode=2*payload,
    over66_episode_bytes=copy_bytes, max_three_work_bank_payload_bytes=3*payload,
    address_miss_records=len(valid_address), address_miss_observed_window_ms=offset_window_ms,
    optimistic_added_overhead_limit_ms_per_episode=offset_window_ms/66,
    equivalent_payload_only_decimal_GBps=copy_bytes/(offset_window_ms/1000)/1e9,
    ideal_all13_nonfirst_record_window_ms=sum(x['capture_through_native_API_end_ms'] for x in body if x['seq'] not in [2,3]),
    limit='Theoretical required cost gate only, not measured bandwidth, recoverable time, or projected speedup. GDN stable I/O alone cannot suppress native-argument hard invalidations.')
out['limits'] = [
    'Peer7 captures =2 target+5 draft. Two windows each Instantiate then Update, not9 recordings.',
    'Old Hyle logical trace is19Instantiate+13Update. Later merged-seed trace is13Instantiate+19Update; both32 captures. Do not pool their timing values.',
    'Hyle66 combined episodes use targetT2 all66 and draftT1×8/T2×58. Peer65 target calls useT2×64/T1×1; peer65 draft calls useT2×60/T1×5. Continuations and arithmetic precision differ.',
    'Hyle small/body ranges are not one-to-one logical peer draft/target graphs. Small includes draft/control and target ingress. GraphLaunch role annotation uses matched source/kernel signatures, not original Graph/node IDs.',
    'No graph launch is not automatically warmup: peer first uses, shape changes and tail can be eager. Source warmup does execute directly until properties stabilize; all observed eager work stays inside these logical windows.',
    'Logical NVTX completion boundaries differ between engines. API/capture windows are not complete episode prices and cannot be subtracted from unprofiled TPS.',
    'Driver table/original graph lineage remains unavailable; exact Update result/errorNode outputs and opaque executable bytes are unknown.'
]
out['inputs']['later_join'] = pin(B/'eligible-record-api-windows.json')
(W/'opponent-counts.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(peer_capture_by_role=out['peer_capture_by_role'],
                     later_seed=out['arms']['hyle_later_seed_profile'],
                     cost_gate=out['conditional_state_IO_cost_gate']), indent=2))
