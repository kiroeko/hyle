"""Scratch-only preparation timings; reused one-main-TU compile/link, no model run."""
from pathlib import Path
import argparse,hashlib,importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
F=R/'.scratch/qwen-mtp-quality-20261022/current-refresh-preparation/build.py'
if hashlib.sha256(F.read_bytes()).hexdigest()!='efe4ceff46b5b58a39d87621988fc9f7c9bc16e3969186221d28c7faa51809e2':raise ValueError('Existing builder changed')
spec=importlib.util.spec_from_file_location('_existing_q35_one_tu',F);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.P=S;c.S=S/'actual';c.SOURCE=S/'main.cc'
c.FLAT_SHA='3749aa7a5767faad27653b133aad83994a13126db2b4cd17ea4452780f4a973d'
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['compile','link']);args=p.parse_args()
 if args.action=='compile':c.compile_one(1)
 else:c.link(1,1)
