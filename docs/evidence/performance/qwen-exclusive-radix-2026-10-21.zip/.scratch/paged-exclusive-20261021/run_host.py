"""Only host tests. No model/context/native GPU enqueue."""
import importlib.util,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('e_build',S/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
mode=sys.argv[1];attempt=int(sys.argv[2])if len(sys.argv)>2 else 1
assert mode in ('radix','lease')
ready=h.c.read(S/f'{mode}-ready-attempt{attempt}.json');runtime=h.c.read(ready['runtime_environment']['path'])
env=os.environ.copy();env['PATH']=runtime['PATH']
out=S/f'{mode}-run{attempt}';out.mkdir(exist_ok=False)
args=[ready['image']['path']]
if mode=='lease':args+=['--gtest_filter=AppendLeases.*','--gtest_output=xml:'+str(out/'tests.xml')]
h.c.save(out/'image.json',ready['image']);h.c.execute('tests',args,env,out)
print('HOST_PASS',mode,flush=True)
