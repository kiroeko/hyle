from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
FILES = [
    "include/hyle/compute/detail/append_lease.h",
    "include/hyle/compute/detail/lease_access.h",
    "src/compute/resource_leases.cc",
]

def identity(path):
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}

records = []
diff = []
for relative in FILES:
    source = ROOT / relative
    before = STAGE / "before" / relative
    snapshot = STAGE / "source" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, snapshot)
    old = before.read_text(encoding="utf-8") if before.exists() else ""
    new = source.read_text(encoding="utf-8")
    diff.extend(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                   fromfile="before/" + relative, tofile="after/" + relative))
    records.append({"current": identity(source), "before": identity(before) if before.exists() else None,
                    "snapshot": identity(snapshot)})

(STAGE / "implementation.diff").write_text("".join(diff), encoding="utf-8", newline="")
checked = subprocess.run(["git", "diff", "--check", "--", *FILES], cwd=ROOT,
                         capture_output=True, text=True)
assert checked.returncode == 0, checked.stdout + checked.stderr
report = {
    "status": "Source implementation frozen; no compile, test, GPU, or performance execution by this owner.",
    "scope": FILES,
    "sources": records,
    "diff": identity(STAGE / "implementation.diff"),
    "diff_check": {"command": ["git", "diff", "--check", "--", *FILES],
                   "exit_code": checked.returncode, "output": checked.stdout + checked.stderr},
    "api": {
        "header": FILES[0],
        "handle": "move-only detail::AppendLease; one retained original LeaseBlock pointer",
        "members": ["valid", "generation", "epoch", "committed_bytes", "reserved_bytes", "capacity_bytes",
                    "reserve(bytes)", "view()", "publish()", "rollback()", "reset()"],
        "lease_access": ["publish_appendable(WriteLease&, prefix_bytes) -> AppendLeasePublication{prefix, appender}",
                         "identity(AppendLease)", "is_appendable_prefix(ReadLease)",
                         "validate_prefix(AppendLease, ReadLease)", "append_unique(LeaseUseBatch&, AppendLease)"],
        "full_initial_prefix": "No unused tail: appender is invalid; original append-mode marker remains immutable.",
        "full_after_append": "publish() retains the appender handle; typed page owner may reset it after full-page publication."
    },
    "invariants": [
        {"anchor": "src/compute/resource_leases.cc:279", "fact": "Conversion requires unique original whole-block writer, open domain, successful writes and zero actual native uses; all rejection leaves writer owned by caller."},
        {"anchor": "src/compute/resource_leases.cc:303", "fact": "Append-mode origin is checked separately from arbitrary legacy subviews; original readonly ranges are never widened."},
        {"anchor": "src/compute/resource_leases.cc:324", "fact": "One root-deduplicated append admission represents only Graph-proven ordered prefix readers/suffix writer. No independent ordinary root read is admitted while a reservation exists."},
        {"anchor": "src/compute/resource_leases.cc:159", "fact": "Completion terminal error updates the captured append epoch failure, while legacy writer errors retain their original whole-root failure."},
        {"anchor": "src/compute/resource_leases.cc:175", "fact": "Explicit native-use count decrements only through original use-episode release. Abandoned capability reservation is cleared only after the last actual native use releases."},
        {"anchor": "src/compute/resource_leases.cc:397", "fact": "Positive contiguous reservation starts at committed frontier, needs prior native uses zero, checks capacity/epoch overflow, and never changes allocation generation."},
        {"anchor": "src/compute/resource_leases.cc:415", "fact": "Mutable view exposes exact reserved suffix and must be obtained before F1 admission; no view during admitted native work."},
        {"anchor": "src/compute/resource_leases.cc:426", "fact": "Successful retired publish advances frontier and returns new bounded readonly prefix. Rollback never advances and remains available after close, but only after actual native retirement."}
    ],
    "integration_requirements": [
        "Graph validates exact root/generation/epoch/reserved span and prefix end<=committed frontier before append_unique; one append entry per root, no mixed ordinary WriteLease.",
        "Graph's original aggregate Completion must retain the use until all accepted work actually retires, including a later failed node or dropped public Completion.",
        "Typed arena's committed rows advance only after successful retired whole-Graph completion, never merely after a prefix copy.",
        "Get suffix view before append_unique. Publish and rollback require original native-use release, not Completion polling alone.",
        "AppendLease::reset abandons authority but never fabricates retirement. An old readonly prefix stays readable; unrelated native use waits until reservation cleanup."
    ],
    "abi": {
        "ordinary_public_handles": "resource_leases.h unchanged by this task; ordinary ReadLease/WriteLease handle layouts and whole-block permission contract retained.",
        "private_metadata": "LeaseBlock adds one-tail facts plus per-root actual native-use counter; LeaseUseEntry captures append epoch. Recompile resource_leases.cc; no preexisting exposed vtable layout changed.",
        "no_new_executor_or_range_map": True
    },
    "not_proven": ["Strict compilation", "Host tests", "CPU/CUDA Graph append integration", "Failure/cancellation actual-retirement runtime", "Performance"]
}
(STAGE / "source-freeze.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"freeze": identity(STAGE / "source-freeze.json"), "sources": [r["current"] for r in records]}, indent=2))
