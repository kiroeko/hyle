$ErrorActionPreference = 'Stop'
$repoRoot = 'C:\public\project-hyle\hyle'
$scratchPrefix = [IO.Path]::GetFullPath((Join-Path $repoRoot '.scratch\paged-exclusive-20261021')) + '\'
$planPath = Join-Path $repoRoot '.scratch\paged-exclusive-20261021\cleanup-plan.json'
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
$receiptPath = [IO.Path]::GetFullPath($plan.receipt)
if (Test-Path -LiteralPath $receiptPath) { throw 'This cleanup already has a receipt.' }
$expectedReceipt = Join-Path $repoRoot 'docs\evidence\performance\qwen-exclusive-radix-2026-10-21.cleanup.json'
if ($receiptPath -ne $expectedReceipt) { throw 'Unexpected cleanup receipt.' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($row in $plan.targets) {
    $resolved = [IO.Path]::GetFullPath($row.path)
    if (-not $resolved.StartsWith($scratchPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside scratch: $resolved" }
    if (-not $seen.Add($resolved)) { throw "Duplicate target: $resolved" }
    $item = Get-Item -LiteralPath $resolved
    if ($item.PSIsContainer -or $item.Length -ne $row.bytes) { throw "Target mismatch: $resolved" }
    if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Hash mismatch: $resolved" }
}
$removed = @()
foreach ($row in $plan.targets) {
    Remove-Item -LiteralPath $row.path -Force
    if (Test-Path -LiteralPath $row.path) { throw "Target remains: $($row.path)" }
    $removed += $row
}
$result = [ordered]@{
    status = 'completed'
    time_utc = [DateTime]::UtcNow.ToString('o')
    deleted_files = $removed.Count
    deleted_bytes = ($removed | Measure-Object -Property bytes -Sum).Sum
    targets = $removed
    reason = $plan.reason
    kept = $plan.kept
    recursive_delete = $false
    plan_sha256 = (Get-FileHash -LiteralPath $planPath -Algorithm SHA256).Hash.ToLowerInvariant()
    script_sha256 = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "Removed $($result.deleted_files) exact files, $($result.deleted_bytes) bytes; receipt $receiptPath"
