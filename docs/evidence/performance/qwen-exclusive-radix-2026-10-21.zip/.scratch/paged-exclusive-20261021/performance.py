"""One current/before/dense/peer window, same retained workload; no cache-hit timing claim."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
source=(R/'.scratch/paged-prepare-20261021/performance.py').read_text(encoding='utf-8')
for old,new in [
 ("current=S / 'qwen-ready.json'","current=S / 'qwen-ready-attempt1.json'"),
 ("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'","before=R / '.scratch/paged-capture-20261021/qwen-ready-attempt3.json'"),
 ('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
  'Compare bounded-prefix unique-tail append against captured-COW 7b854, original dense Hyle and matched llama.cpp; Radix directory off;')]:
 assert source.count(old)==1;source=source.replace(old,new)
exec(compile(source,str(Path(__file__).resolve()),'exec'),globals())
