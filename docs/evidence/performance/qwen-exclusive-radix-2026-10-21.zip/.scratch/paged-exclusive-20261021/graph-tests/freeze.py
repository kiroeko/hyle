from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[2]
FILES = ['tests/graph_batch/paged_append_graph_test.cc', 'tests/graph_batch/paged_append_cuda_consumer.cc']

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

sources, patch = [], []
for relative in FILES:
    path = R / relative
    old = S / 'before' / relative
    frozen = S / 'source' / relative
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(path.read_bytes())
    sources.append(dict(current=identity(path), frozen=identity(frozen), before=identity(old)))
    patch.extend(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(True),
        path.read_text(encoding='utf-8').splitlines(True), fromfile='before/' + relative, tofile='after/' + relative))
diff = S / 'implementation.diff'
diff.write_text(''.join(patch), encoding='utf-8')
report = dict(
    status='Two existing fixture TUs source-frozen for root incremental compile/run. No build/runtime pass claimed.',
    scope='Plain BF16 ordinary Graph append -> causal attention. Existing CPU and CUDA cases retained; no product/main/CMake changes or new executor.',
    sources=sources,
    read_API=[identity(R / p) for p in ['include/hyle/compute/paged_arena.h', 'include/hyle/graph/batch.h']],
    geometry=dict(requests=1, query_rows=1, query_heads=2, kv_heads=1, dimension=64,
        page_rows=4, physical_pages=6, arena_payload_bytes=3072, arena_capacity_bound_bytes=4096),
    public_journey=[
        'Original page0 is initialized with one .125 value row (zero K; unused V rows are NaN), then writer.publish_appendable(1) returns exactly 128-byte prefix readers and independent move-only idle tails.',
        'An ordinary Graph receives packed zero K/.5 V, fresh page2 and explicit empty tails: original COW produces two-row [.125,.5], causal output exact BF16(.3125). Only successful whole-Graph take/ready returns page2 idle appender.',
        'Move each original appender out of the returned owner, reserve_rows(1), then create(...,empty fresh,tails). Same physical page2 becomes three-row [.125,.5,.5], exact BF16(.375). Older two-row frames are retained throughout.',
        'A branch receives no tail authority and explicit fresh page3. Original COW copies the three committed rows plus .5, exact BF16(.40625). Full four-row publication returns no further idle tail.',
        'A separate ordinary ready-attention Graph reads the retained two-row frame after the physical page has three rows and the branch has four. It must still return .3125; the original one-row prefix remains exactly 128 bytes of .125.'
    ],
    cpu=dict(
        gtest='GraphPagedAppend.ExclusiveTailRollbackAndBoundedSnapshots',
        main='HYLE_APPEND_STANDALONE retains the original all() and then executes exclusive_tail().',
        new_graph_submits=dict(success=4, expected_failure=1),
        failure='After the fresh two-row snapshot, reserve the suffix and use the existing Reject provider after both real append nodes. Wait actual terminal, take both owners, require ready() rejection, rollback the original appenders, verify frontier remains 2, reserve again and retry the same-page Graph successfully.',
        bounds='Initial one-row bounded reader cannot authorize a two-row layout; old immutable first/second layouts are checked after continuation and COW.',
        numeric='All new output words compare exactly to BF16 of dyadic means; no tolerance relaxation.'
    ),
    cuda=dict(
        gtest='CudaPagedAppend.ExclusiveTailKeepsBoundedSnapshotsAndCapture',
        main='HYLE_APPEND_STANDALONE adds profile3; profiles0/1/2 retain original paths.',
        new_graph_submits=dict(success=4, expected_failure=0),
        reuse='The same original Invocation, input/output leases, physical arenas and native descriptor capacity span all three append episodes. RequireCapture remains strict: first recorded>0/reused0; second and branch recorded0/reused>0. Descriptor contents and permissions change, not carrier pointers.',
        old_helpers='metadata_graph optional exclusive=false preserves Q2/page2 defaults. The exclusive=true branch uses Q1/page4. metadata_run uploads exact active row prefixes and allocates output_description.required_bytes(); original defaults still upload256 query/128 K/128 V words and512 output bytes.',
        permission='After every take, submitting without rebinding/preparing must still return FailedPrecondition; unexpected acceptance is waited then failed. No stale recording is used as permission.',
        numeric='All new words are exact BF16(.3125/.375/.40625); old frame uses a normal ready reader, not private guard inspection.'
    ),
    limits=[
        'Source-only implementation; root must compile against the final current factory/API and execute CPU/CUDA fixtures.',
        'CPU failure recovery is tested after actual terminal retirement; this fixture does not newly claim asynchronous inflight rollback, cancellation preemption, encoded caches or native Apple/Vulkan append support.',
        'No automatic branch policy is manufactured: the caller with the unique tail selects same-page append; a branch without that authority follows the existing fresh COW path.',
        'No throughput or memory-saving claim follows from these finite numerical/permission tests.'
    ],
    actual_operations=dict(CXX=0, links=0, GPU_runs=0, SDK_builds=0)
)
save(S / 'report.json', report)
save(S / 'source-freeze.json', dict(status='Frozen fixtures, root build/runtime pending', files=sources,
    diff=identity(diff), report=identity(S / 'report.json'), generator=identity(__file__)))
print(json.dumps(dict(freeze=identity(S / 'source-freeze.json'), report=identity(S / 'report.json'), sources=sources), ensure_ascii=False))
