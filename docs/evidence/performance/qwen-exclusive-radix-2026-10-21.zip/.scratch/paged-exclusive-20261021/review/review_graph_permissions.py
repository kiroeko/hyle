from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent

def identity(relative):
    path = ROOT / relative
    raw = path.read_bytes()
    return {"path": relative, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

sources = ["src/graph/resources.cc", "src/graph/lease_submission.cc", "src/graph/submission_internal.h",
           "include/hyle/compute/detail/append_lease.h", "include/hyle/compute/detail/lease_access.h",
           "src/compute/resource_leases.cc"]
report = {
    "status": "Read-only source review complete for the identities recorded below; no blocking finding in the reviewed Graph permission integration. Not a compile or runtime pass.",
    "sources": [identity(path) for path in sources],
    "blocking_findings": [],
    "reviewed_contracts": [
        {"source": "src/graph/resources.cc:616", "fact": "Written projection validates exact original selected external-write singleton, shared-Queue selected readers and each original writer->reader dependency before binding. Existing bind_projected_impl still checks every actual physical consumer and rejects alias descendants/published capacity."},
        {"source": "src/graph/resources.cc:659", "fact": "Each append cap must be valid/reserved; its exact current view must be inside the original native bank. Duplicate cap roots and ordinary whole-page writer mixing reject. At least one original committed-prefix ReadLease for each cap root is required and validate_prefix bounds every matching old guard."},
        {"source": "src/graph/resources.cc:683", "fact": "Cold reserve precedes projection commit; fixed metadata covers all old guards, writer pointers, append pointers and original controls. Appender pointers borrow the original controller-owned move-only cap, not allocation capacity or slot metadata as authority."},
        {"source": "src/graph/lease_submission.cc:46", "fact": "Whole-group validation precedes F1 admissions: generation must match; ordinary write cannot mix with read/append; different cap objects for one root reject. Old read bounds pass validate_prefix. The second pass selects an append entry regardless of its position and makes exactly one append_unique admission per root rather than a separate ordinary read_unique."},
        {"source": "src/graph/resources.cc:1407", "fact": "New native admission still requires resource_control_ready, original observation/failed/closed gates. Appenders enter the same cold permission set as exact guards and actual control leases. If permission admission or cursor begin rejects, the local original LeaseUseBatch drops without native acceptance; it does not publish, widen or abandon the reserved cap."},
        {"source": "src/graph/resources.cc:1026", "fact": "Original aggregate remaining count waits for every accepted child retention release. Only the final release passes the collected terminal to the original F1 episode before publishing Invocation idle/failed. Accepted failure updates only the captured append epoch through LeaseUseEntry; zero-command rejection releases admission without inventing successful publication."},
        {"source": "src/graph/resources.cc:740", "fact": "Written-projection release requires actual retired work/results/observation. It removes anonymous page/control/writer/append bindings and clears the fixed projected binding. Native command preservation only preserves dormant metadata; rebind/reprepare is still required and existing stable-identity/selected-reader proof gates remain."},
        {"source": "src/compute/resource_leases.cc:324", "fact": "append_unique rejects closed domains, absent reservation, failed epoch or any existing actual native root use. Every original use release decrements explicit native_uses. publish and rollback cannot complete while any admitted use survives; close admits no new work while retired rollback/reset cleanup remains possible."}
    ],
    "ownership_and_epoch_boundary": [
        "Graph stores a borrowed pointer to the unique cap, exactly as the existing projected whole-page writer stores its original permission pointer. The owning PagedAppendPages controller must keep that object/current reservation stable until take/retirement; this review does not authorize caller mutation of a borrowed binding.",
        "LeasePermissionSet is a generic root admission mechanism. Actual suffix metadata, exact selected writer effects, original layout/frontier and whole-Graph successful-ready publication remain the typed append controller's obligations; this review does not infer them merely from matching root identities.",
        "Original allocation generation remains stable. Each append admission captures the separate epoch before native acceptance, and actual-retirement gates prevent reserve/rollback from advancing that epoch while an entry is live."
    ],
    "exceptions_and_limits": [
        "Cold permission-vector growth can reject before native acceptance. No new exception path or native synchronization was introduced by the reviewed group-selection logic.",
        "An accepted later Graph error must still reach the original aggregate terminal and real retention release. A dropped public Completion alone never constitutes permission retirement.",
        "Failed Invocation cannot execute again; recovering the retired appender through take/rollback and binding a fresh Invocation is the intended path. Closed lease domains permit only retired cleanup, not a successful new append publication.",
        "This owner performed no compilation, CPU fixture execution, GPU/native run, cancellation measurement, or performance measurement for this review."
    ],
    "focused_test_source": identity("tests/compute/resource_leases_test.cc"),
    "test_freeze": ".scratch/paged-exclusive-20261021/lease-tests/source-freeze.json"
}
target = STAGE / "graph-permissions-review.json"
target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
raw = target.read_bytes()
print(json.dumps({"path": target.relative_to(ROOT).as_posix(), "bytes": len(raw),
                  "sha256": hashlib.sha256(raw).hexdigest()}, indent=2))
