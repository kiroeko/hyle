"""Read-only recomputation of completed E vs C Qwen correctness consumers."""
from pathlib import Path
from array import array
from collections import Counter
import hashlib
import json
import re
import sys

R = Path(__file__).resolve().parents[3]
E = R / '.scratch/paged-exclusive-20261021'
C = R / '.scratch/paged-capture-20261021'
O = E / 'review'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def verify(record):
    value = identity(record['path'])
    assert value == record, (value, record)
    return value

def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items() if k != 'seconds' and not k.endswith('_seconds')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value

def differences(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b:
                result.append(dict(field=path + '/' + key, current=a.get(key), baseline=b.get(key)))
            else:
                result += differences(a[key], b[key], path + '/' + key)
        return result
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, path + '/' + str(i))]
    return [] if a == b else [dict(field=path, current=a, baseline=b)]

def command_key(argv):
    result = list(argv)
    result[0] = 'IMAGE'
    result[result.index('--trace') + 1] = 'TRACE'
    return result

prepared_re = re.compile(r'^prepared T=(\d+) visible=(\d+) replay=(\w+) .*?capture_recorded=(\d+) capture_reused=(\d+)$', re.M)

def native_work(directory, observation):
    text = (directory / 'stderr.log').read_text(encoding='utf-8-sig', errors='replace')
    prepared = [dict(rows=int(x[0]), visible=int(x[1]), route=x[2], recorded=int(x[3]), reused=int(x[4]))
                for x in prepared_re.findall(text)]
    sessions = observation.get('sessions', [observation])
    restore_calls = sum(x['restored_calls'] for x in sessions)
    restore_tokens = sum(x['restored_tokens'] for x in sessions)
    assert len(prepared) + restore_calls == observation['actual_graph_calls']
    assert sum(x['rows'] for x in prepared) + restore_tokens == observation['actual_graph_tokens']
    assert observation['actual_graph_calls'] == observation['generated_tokens'] - observation['prefix_full_hits'] + restore_calls
    assert observation['actual_graph_tokens'] == observation['processed_tokens'] - observation['reused_tokens'] + restore_tokens
    modes = Counter((x['route'], x['recorded'], x['reused']) for x in prepared)
    return dict(semantic_preparation_calls=len(prepared), semantic_preparation_tokens=sum(x['rows'] for x in prepared),
        restored_calls=restore_calls, restored_tokens=restore_tokens,
        total_actual_graph_calls=observation['actual_graph_calls'], total_actual_graph_tokens=observation['actual_graph_tokens'],
        preparations=prepared,
        preparation_modes=[dict(route=k[0], recorded=k[1], reused=k[2], count=v) for k, v in sorted(modes.items())],
        reconciliation='Prepared stderr records cover semantic evaluations, including suffix-only partial prefix hits, but omit quiet restoration replays. Add reported restored_calls/restored_tokens to reconcile actual Graph totals. Full cache hits have no preparation.')

def budget(observation):
    limit = observation['cache_committed_version_limit']
    live = observation['cache_live_snapshot_versions']
    peak = observation['cache_peak_committed_versions']
    assert 0 <= live <= limit and 0 <= peak <= limit
    result = {k: v for k, v in observation.items()
              if k.startswith(('cache_', 'prefix_')) and not k.endswith('_seconds') and not isinstance(v, (dict, list))}
    result['observed_live_and_committed_peak_within_limit'] = True
    if 'cache_requested_byte_limit' in observation:
        assert observation['cache_live_requested_bytes'] <= observation['cache_requested_byte_limit']
        assert observation['cache_peak_requested_bytes'] <= observation['cache_requested_byte_limit']
        assert observation['cache_shared_backing_bytes'] == observation['cache_live_requested_bytes']
        assert observation['prefix_entries'] <= observation['prefix_entry_capacity']
        assert observation['cache_retained_sessions'] <= observation['effective_cache_sessions']
        result['reported_managed_byte_and_directory_bounds_hold'] = True
    return result

assert sys.byteorder == 'little'
new_ready_path, old_ready_path = E / 'qwen-ready-attempt1.json', C / 'qwen-ready-attempt3.json'
new_ready, old_ready = read(new_ready_path), read(old_ready_path)
assert new_ready['source']['sha256'] != old_ready['source']['sha256']
image_facts = {}
for name, ready in [('current', new_ready), ('baseline', old_ready)]:
    image = Path(ready['image']['path'])
    image_facts[name] = dict(recorded=ready['image'], retained_file_checked=verify(ready['image']) if image.exists() else None)

finite = dict(bf16_elements=0, f32_elements=0, nonfinite_elements=0)
cases = {}
total = 0
for name, expected in [('single-run1', 18), ('multi-run1', 72), ('main-run1', 22), ('pressure-run1', 30)]:
    current, baseline = E / name, C / name
    new_result, old_result = read(current / 'result.json'), read(baseline / 'result.json')
    assert new_result['exit'] == old_result['exit'] == 0
    assert new_result['image'] == new_ready['image'] and old_result['image'] == old_ready['image']
    assert new_result['finished_unix_ns'] >= new_result['started_unix_ns']
    assert old_result['finished_unix_ns'] >= old_result['started_unix_ns']
    assert command_key(new_result['command']) == command_key(old_result['command'])
    assert new_result['throughput_evidence'] is False and old_result['throughput_evidence'] is False
    assert new_result['ready'] == identity(new_ready_path) and old_result['ready'] == identity(old_ready_path)
    x, y = read(current / 'observation.json'), read(baseline / 'observation.json')
    # Read raw process stdout as well as the runner's observation extraction.
    for directory, observation in [(current, x), (baseline, y)]:
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
               if line.lstrip().startswith('{')]
        assert raw[-1] == observation
    non_time_differences = differences(stable(x), stable(y))
    actual = {p.relative_to(current / 'trace').as_posix(): p for p in (current / 'trace').rglob('*')
              if p.name in ('hidden.bf16', 'logits.f32')}
    references = {p.relative_to(baseline / 'trace').as_posix(): p for p in (baseline / 'trace').rglob('*')
                  if p.name in ('hidden.bf16', 'logits.f32')}
    assert actual.keys() == references.keys() and len(actual) == expected
    tensors = []
    for relative in sorted(actual):
        aa, bb = actual[relative].read_bytes(), references[relative].read_bytes()
        assert aa == bb, (name, relative)
        kind = 'H' if actual[relative].suffix == '.bf16' else 'I'
        mask = 0x7f80 if kind == 'H' else 0x7f800000
        assert len(aa) == (4096 if kind == 'H' else 993280)
        values = array(kind)
        values.frombytes(aa)
        bad = sum((value & mask) == mask for value in values)
        assert bad == 0
        finite['bf16_elements' if kind == 'H' else 'f32_elements'] += len(values)
        finite['nonfinite_elements'] += bad
        tensors.append(dict(relative=relative, bytes=len(aa), current_sha256=hashlib.sha256(aa).hexdigest(),
            baseline_sha256=hashlib.sha256(bb).hexdigest(), elements=len(values), byte_equal=True, nonfinite=bad))
    hits = []
    current_hits = {p.relative_to(current / 'trace').as_posix(): p for p in (current / 'trace').rglob('cache-hit.json')}
    old_hits = {p.relative_to(baseline / 'trace').as_posix(): p for p in (baseline / 'trace').rglob('cache-hit.json')}
    assert current_hits.keys() == old_hits.keys()
    for relative, path in sorted(current_hits.items()):
        value = read(path)
        assert value == read(old_hits[relative])
        assert value['prefix_hit'] is True and value['graph_calls'] == 0 and value['tensor_payload_available'] is False
        assert not (path.parent / 'hidden.bf16').exists() and not (path.parent / 'logits.f32').exists()
        hits.append(dict(current=identity(path), baseline=identity(old_hits[relative]), contents=value))
    assert len(hits) == x['prefix_full_hits'] == y['prefix_full_hits']
    new_work, old_work = native_work(current, x), native_work(baseline, y)
    current_budget, baseline_budget = budget(x), budget(y)
    sessions = []
    for session in x.get('sessions', [x]):
        sessions.append({k: session[k] for k in ['visible_tokens', 'generated_ids', 'actual_graph_calls',
            'actual_graph_tokens', 'restored_calls', 'restored_tokens', 'prefix_hits', 'prefix_misses', 'prefix_full_hits', 'reused_tokens']}
            | dict(session_id=session.get('session_id', 'single'),
                phases=[{k: phase[k] for k in ['turn', 'kind', 'name', 'input_tokens', 'calls', 'context_before', 'context_after']}
                        for phase in session['phases']]))
    root_stats = {k: x[k] for k in ['processed_tokens', 'generated_tokens', 'actual_graph_calls', 'actual_graph_tokens',
        'prefix_hits', 'prefix_misses', 'prefix_full_hits', 'reused_tokens']}
    for k in ['session_count', 'dispatch_session_ids', 'evicted_session_ids', 'prefix_entries', 'prefix_evictions']:
        if k in x:
            root_stats[k] = x[k]
    if name in ('single-run1', 'multi-run1'):
        for directory in (current, baseline):
            summary = read(directory / 'summary.json')
            assert summary['passed'] is True and summary['vector_count'] == expected
    cases[name] = dict(current_trace_root=str(current / 'trace'), baseline_trace_root=str(baseline / 'trace'),
        receipts=dict(current=identity(current / 'result.json'), baseline=identity(baseline / 'result.json')),
        raw_stdout=dict(current=identity(current / 'stdout.log'), baseline=identity(baseline / 'stdout.log')),
        raw_stderr=dict(current=identity(current / 'stderr.log'), baseline=identity(baseline / 'stderr.log')),
        observations=dict(current=identity(current / 'observation.json'), baseline=identity(baseline / 'observation.json')),
        same_command_except_image_and_trace=True, exit_codes=[new_result['exit'], old_result['exit']],
        vector_count=len(tensors), byte_equal=True, tensors=tensors,
        all_non_timing_observation_fields_equal=not non_time_differences, non_timing_differences=non_time_differences,
        statistics=root_stats, sessions=sessions, full_hit_metadata=hits,
        current_work=new_work, baseline_work=old_work, work_and_preparation_counts_equal=new_work == old_work,
        current_budget=current_budget, baseline_budget=baseline_budget,
        budget_statistics_equal=current_budget == baseline_budget)
    total += len(tensors)

assert total == 142
assert finite == dict(bf16_elements=145408, f32_elements=17630720, nonfinite_elements=0)
assert all(case['all_non_timing_observation_fields_equal'] and case['work_and_preparation_counts_equal'] and
           case['budget_statistics_equal'] for case in cases.values())
full = next(s for s in cases['main-run1']['sessions'] if s['session_id'] == 'full_hit')
assert full['actual_graph_calls'] == full['actual_graph_tokens'] == 0
assert full['prefix_hits'] == full['prefix_full_hits'] == 1 and full['reused_tokens'] == full['visible_tokens'] == 129
assert full['generated_ids'] == [71163]
source_freeze = E / 'implementation/source-freeze.json'
frozen_sources = read(source_freeze)['files']
assert len(frozen_sources) == 20
link_plan = read(new_ready['link_plan']['path'])
compiled_main = []
for record in link_plan['compiled_records']:
    verify(record)
    value = read(record['path'])
    if value['source'] == new_ready['source']:
        compiled_main.append((record, value))
assert len(compiled_main) == 1
main_record, main = compiled_main[0]
verify(main['source']); verify(main['object'])
assert sum(row == main['object'] for row in link_plan['inputs']) == 1
frozen_main = next(row for row in frozen_sources if row['current'] == main['source'])
assert verify(frozen_main['frozen'])['sha256'] == main['source']['sha256']
compile_snapshot = Path(main_record['path']).parent / 'source/tools/qwen35_text/main.cc'
assert identity(compile_snapshot)['sha256'] == main['source']['sha256']
prefix_dependency = next(row for row in main['dependencies'] if Path(row['path']).name == 'prefix_cache.h')
verify(prefix_dependency)
frozen_prefix = next(row for row in frozen_sources if row['current'] == prefix_dependency)
assert verify(frozen_prefix['frozen'])['sha256'] == prefix_dependency['sha256']
probe_first, probe_final = E / 'probe-run1', E / 'probe-run2'
probe_ready_path = E / 'probe-ready-attempt2.json'
probe_ready, probe_receipt = read(probe_ready_path), read(probe_final / 'result.json')
assert probe_receipt['exit'] == 0 and probe_receipt['image'] == probe_ready['image']
assert Path(probe_receipt['ready']) == probe_ready_path
probe_result = [json.loads(line) for line in (probe_final / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
                if line.lstrip().startswith('{')][-1]
assert probe_result['status'] == 'PASS' and probe_result['same_page_exclusive_suffix'] is True
assert probe_result['old_kv_guards_and_bytes_unchanged'] is True
assert probe_result['dropped_live_public_completion'] is True
assert probe_result['cancel_means_native_preemption'] is False
assert probe_result['managed_bytes_while_native_pending'] == probe_result['managed_backing_bytes'] == 42418224
assert probe_result['resident_limit'] == 1 and probe_result['capacity'] == 256
assert probe_result['old_prefix_tokens'] == 129 and probe_result['cancelled_candidate_tokens'] == 130
assert read(probe_first / 'result.json')['exit'] == 1
report = dict(status='PASS: E vs C four completed Qwen consumers have 142 byte-identical finite hidden/logits artifacts. IDs, phase/dispatch, exact cache/Graph/restoration/budget and logged preparation statistics were recomputed equal, not assumed equal.',
    script=identity(__file__), current_ready=identity(new_ready_path), baseline_ready=identity(old_ready_path),
    image_facts=image_facts, recorded_sources=dict(current=new_ready['source'], baseline=old_ready['source']),
    source_scope='Main and private cache/math-permission implementation intentionally changed. No requirement that historical C canonical source paths hash to current E sources; no whole-source freeze gate copied from the old comparison.',
    selected_current_source_binding=dict(implementation_freeze=identity(source_freeze),
        implementation_source_count=len(frozen_sources), main_compile_identity=main_record,
        compiled_main_source=main['source'], actual_linked_main_object=main['object'],
        compile_snapshot=identity(compile_snapshot), final_frozen_main=frozen_main['frozen'],
        actual_compiled_radix_dependency=prefix_dependency, final_frozen_radix=frozen_prefix['frozen'],
        current_and_compile_and_final_frozen_main_match=True, compiled_radix_dependency_matches_current_and_final_freeze=True,
        scope='Selected current main TU and its actual prefix-cache include only. This does not claim to revalidate every source/dependency of all retained SDK inputs.'),
    current_link_plan=identity(new_ready['link_plan']['path']), baseline_link_plan=identity(old_ready['link_plan']['path']),
    baseline_independent_validation=identity(C / 'review/runtime-comparison.json'),
    cases=cases, total_vector_artifacts=total, hidden_and_logits_pairs=71, finite_counts=finite,
    full_hit_zero_graph=dict(case='main-run1', session=full,
        metadata=cases['main-run1']['full_hit_metadata'], no_hidden_or_logits_fabricated=True,
        terminal_live_versions=cases['main-run1']['current_budget']['cache_live_snapshot_versions'],
        observed_peak_committed_versions=cases['main-run1']['current_budget']['cache_peak_committed_versions'],
        committed_version_limit=cases['main-run1']['current_budget']['cache_committed_version_limit'],
        fixed_managed_shared_backing_bytes=cases['main-run1']['current_budget']['cache_shared_backing_bytes']),
    separate_probe_history=dict(
        first=dict(receipt=identity(probe_first / 'result.json'), exit=1, stderr=identity(probe_first / 'stderr.log'),
            note='First actual failure retained: root identified the old distinct-fresh-page-availability expectation as inapplicable after exclusive same-page continuation. It is not overwritten by the corrected run.'),
        final=dict(ready=identity(probe_ready_path), image=probe_ready['image'], source=probe_ready['source'],
            receipt=identity(probe_final / 'result.json'), stdout=identity(probe_final / 'stdout.log'),
            stderr=identity(probe_final / 'stderr.log'), exit=0, output=probe_result,
            scope='Independently read completed terminal and explicit native-probe assertions. This subagent did not rerun the probe or infer early physical release from directory deletion. The four Qwen images/observations compared above are unchanged by the probe-only correction.')),
    limits=[
        'Host-only reading of existing receipts, stdout, stderr, observation JSON and raw tensor files; zero build/link/GPU/model process and no product/raw-result changes.',
        '142 counts vector files across four completed processes (71 hidden/logits pairs), not 142 independent inputs or model-quality tests; canonical inputs recur across single and multi runs.',
        'Only hidden.bf16 and logits.f32 count. Route metadata and full-hit metadata are not numerical tensors. Finite checks cover decision outputs, not all internal recurrent/state values.',
        'Counters are consumer-reported and independently reconciled with semantic preparation records plus quiet restoration counters. No new driver allocation/physical memory sampling or private owner inspection was performed.',
        'Managed shared backing and observed live/committed-version peaks remain within their reported limits. These terminal/committed counters do not independently measure every transient candidate or prove driver/OS memory residency.',
        'Recorded/reused counts describe correctness-window preparations, not native kernel counts or full capturable-exclusive support. Equality of these counts is observed for these four traces; no blanket reuse or throughput claim follows.',
        'No timing comparison, quality result, arbitrary mid-prefill checkpoint, multi-inflight throughput or Apple/Vulkan exclusive path is claimed here. Corrected probe PASS is separately receipt-bound; it is not part of the142-vector equality count.'
    ], actual_operations=dict(CXX=0, links=0, GPU_runs=0, model_runs=0))
target = O / 'runtime-comparison.json'
target.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(target), total_vectors=total, finite=finite,
    statistics={name: case['statistics'] for name, case in cases.items()},
    all_non_timing_fields_equal=True, full_hit_zero_graph=full), indent=2))
