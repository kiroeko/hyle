"""Host-only independent recomputation of this frozen finite window."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex
import statistics

S = Path(__file__).resolve().parent.parent
P = S / 'performance'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def stat(values):
    values = [v for v in values if v is not None]
    return dict(count=len(values), min=min(values) if values else None,
                median=statistics.median(values) if values else None,
                max=max(values) if values else None, samples=values)


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def compact_stat(values):
    result = stat(values)
    result.pop('samples')
    return result


inputs = read(P / 'timing/inputs.json')
plan = inputs['plan']
manifest = Path(plan['manifest']['path'])
assert identity(manifest)['sha256'] == plan['manifest']['sha256']
schedule = []
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip():
        continue
    kind, file = shlex.split(line)
    ids_path = manifest.parent / file
    ids = [int(v) for v in ids_path.read_text(encoding='utf-8').split()]
    schedule.append(dict(kind='prefill' if kind == 'prompt' else kind,
                         ids=ids, source=identity(ids_path)))
assert [len(p['ids']) for p in schedule] == [256, 32] * 3
assert sum(len(p['ids']) for p in schedule) == 864
assert sum(1 if p['kind'] == 'prefill' else len(p['ids']) for p in schedule) == 99

rows, raw_artifacts, all_ids, checks = [], [], [], []
for entry in read(P / 'timing/runs.json'):
    folder = Path(entry['folder'])
    process = read(folder / 'result.json')
    assert process == entry['process'] and process['exit'] == 0
    assert not process['memory_only'] and not process['profiler']
    arm = entry['variant']
    assert process['image']['sha256'] == inputs['images'][arm]['sha256']
    command = process['command']
    assert command[command.index('--capacity') + 1] == '1024'
    assert Path(command[command.index('--schedule') + 1]) == manifest
    native_path = folder / ('peer-result.json' if arm == 'peer' else 'stdout.log')
    raw = read(native_path)
    assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
    assert raw['turn_count'] == 3 and raw['phase_count'] == 6
    if arm == 'peer':
        assert raw['context_capacity'] == 1024 and raw['requested_context_capacity'] == 1024
    else:
        assert raw.get('prefix_cache', 'off') == 'off'
    cursor = 0
    for n, (actual, expected) in enumerate(zip(raw['phases'], schedule)):
        assert actual['kind'] == expected['kind'] and actual['turn'] == n // 2 + 1
        assert actual['input_tokens'] == len(expected['ids'])
        assert actual['context_before'] == cursor
        cursor += len(expected['ids'])
        assert actual['context_after'] == cursor and actual['seconds'] > 0
    assert cursor == 864
    stderr = (folder / 'stderr.log').read_text(encoding='utf-8')
    steps = []
    capture = []
    if arm == 'peer':
        steps = raw['steps']
        loading = raw['loading']
    else:
        for line in stderr.splitlines():
            if re.match(r'^round\d+_(prefill|decode\d+) ', line):
                name, *parts = line.split()
                fields = dict(v.split('=', 1) for v in parts)
                steps.append(dict(name=name, turn=int(re.match(r'round(\d+)', name)[1]),
                                  kind='prefill' if name.endswith('prefill') else 'decode',
                                  step_seconds=float(fields['step_seconds']),
                                  predicted_id=int(fields['next'])))
            if line.startswith('prepared '):
                fields = dict(v.split('=', 1) for v in line.split()[1:])
                capture.append((int(fields['capture_recorded']), int(fields['capture_reused'])))
        loading = {}
        for source, target in [('weights_load_seconds', 'model_load_seconds'),
                               ('model_seconds', 'model_seconds'),
                               ('shape_prepare_seconds', 'shape_prepare_seconds'),
                               ('startup_to_ready_seconds', 'startup_to_ready_seconds'),
                               ('first_token_elapsed_seconds', 'first_token_elapsed_seconds')]:
            values = re.findall(r'\b' + source + r'=([0-9.eE+-]+)', stderr)
            assert len(values) == 1
            loading[target] = float(values[0])
    assert len(steps) == 99
    predicted = raw.get('generated_ids', raw.get('predicted_ids'))
    assert len(predicted) == 99 and predicted == [x['predicted_id'] for x in steps]
    all_ids.append(predicted)
    prefills = [p for p in raw['phases'] if p['kind'] == 'prefill']
    decodes = [p for p in raw['phases'] if p['kind'] == 'decode']
    pwall = sum(p['seconds'] for p in prefills)
    dwall = sum(p['seconds'] for p in decodes)
    stable = [s for s in steps if s['kind'] == 'decode' and
              int(re.search(r'decode(\d+)$', s['name'])[1]) >= 7]
    assert len(stable) == 78
    rates = dict(prefill_tps=768 / pwall, full_decode_tps=96 / dwall,
                 session_output_tps=99 / raw['session_seconds'],
                 session_processed_tps=864 / raw['session_seconds'])
    observed_rounds = {}
    for phase in raw['phases']:
        values = dict(seconds=phase['seconds'], tps=phase['input_tokens'] / phase['seconds'])
        if phase['kind'] == 'decode':
            subset = [s for s in stable if s['turn'] == phase['turn']]
            values['stable_decode7_to32_tps'] = 26 / sum(s['step_seconds'] for s in subset)
        observed_rounds[phase['name']] = values
    row = dict(arm=arm, folder=str(folder), image=process['image'], rates=rates,
               prefill_wall_seconds=pwall, decode_wall_seconds=dwall,
               session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
               cold_output_tps=99 / raw['startup_total_seconds'],
               session_minus_phase_wall_seconds=raw['session_seconds'] - pwall - dwall,
               stable_decode7_to32_tps=78 / sum(s['step_seconds'] for s in stable),
               loading=loading, phases=observed_rounds,
               captures=dict(Counter(f'recorded{a}_reused{b}' for a, b in capture)))
    rows.append(row)
    for key, val in rates.items():
        old_key = dict(prefill_tps=None, full_decode_tps=None,
                       session_output_tps='output_tokens_per_second',
                       session_processed_tps='processed_tokens_per_second')[key]
        if old_key:
            assert math.isclose(val, entry['observation']['metrics'][old_key], rel_tol=1e-12)
    for name in observed_rounds:
        old = entry['observation']['rounds'][str(next(p['turn'] for p in raw['phases'] if p['name'] == name))]
        kind = 'prefill' if name.endswith('prefill') else 'decode'
        assert math.isclose(observed_rounds[name]['tps'], old[kind]['tokens_per_second'], rel_tol=1e-12)
    raw_artifacts.extend(identity(folder / n) for n in ['result.json', 'stdout.log', 'stderr.log'])
    if arm == 'peer':
        raw_artifacts.append(identity(native_path))
assert all(ids == all_ids[0] for ids in all_ids)

groups = {}
for arm in ['current', 'before', 'dense', 'peer']:
    sample = [r for r in rows if r['arm'] == arm]
    assert len(sample) == 3
    groups[arm] = dict(rates={k: stat([r['rates'][k] for r in sample]) for k in sample[0]['rates']},
                       session_seconds=stat([r['session_seconds'] for r in sample]),
                       startup_total_seconds=stat([r['startup_total_seconds'] for r in sample]),
                       cold_output_tps=stat([r['cold_output_tps'] for r in sample]),
                       stable_decode7_to32_tps=stat([r['stable_decode7_to32_tps'] for r in sample]),
                       loading={k: stat([r['loading'][k] for r in sample]) for k in sample[0]['loading'] if k.endswith('_seconds')},
                       phases={name: {k: stat([r['phases'][name][k] for r in sample]) for k in sample[0]['phases'][name]}
                               for name in sample[0]['phases']},
                       capture_patterns=[r['captures'] for r in sample])

memory = {}
fields = ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
          'gpu_shared_bytes', 'gpu_total_bytes']
for entry in read(P / 'memory/runs.json'):
    folder = Path(entry['folder']); process = read(folder / 'result.json')
    assert process == entry['process'] and process['exit'] == 0 and process['memory_only']
    arm = entry['variant']; assert process['image']['sha256'] == inputs['images'][arm]['sha256']
    raw = read(folder / 'memory.json'); samples = raw['samples']
    assert all(b['timestamp_ns'] > a['timestamp_ns'] for a, b in zip(samples, samples[1:]))
    for sample in samples:
        dedicated, shared = sample['gpu_dedicated_bytes'], sample['gpu_shared_bytes']
        assert sample['gpu_total_bytes'] == (dedicated + shared if dedicated is not None and shared is not None else None)
    gaps = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(samples, samples[1:])]
    markers = {m['name']: m['timestamp_ns'] for m in process['markers']}
    phases = {}
    for i in range(1, 4):
        for kind in ['prefill', 'decode']:
            name = f'round{i}_{kind}'; begin, end = markers[name + '_begin'], markers[name + '_end']
            inside = [s for s in samples if begin <= s['timestamp_ns'] <= end]
            before = next((s for s in reversed(samples) if s['timestamp_ns'] <= begin), None)
            after = next((s for s in samples if s['timestamp_ns'] >= end), None)
            delta = {k: after[k] - before[k] if before and after and before[k] is not None and after[k] is not None else None for k in fields}
            phases[name] = dict(sample_count=len(inside), begin_ns=begin, end_ns=end,
                                sampled_peak_bytes={k: max((s[k] for s in inside if s[k] is not None), default=None) for k in fields},
                                null_sample_counts={k: sum(s[k] is None for s in inside) for k in fields},
                                bracket_delta_bytes=delta,
                                boundary_before_ns=before['timestamp_ns'] if before else None,
                                boundary_after_ns=after['timestamp_ns'] if after else None,
                                bracket_ages_ns=dict(before=begin-before['timestamp_ns'] if before else None,
                                                     after=after['timestamp_ns']-end if after else None))
    ready = markers.get('ready'); first = markers['round1_prefill_begin']
    ready_sample = next((s for s in reversed(samples) if ready is not None and ready <= s['timestamp_ns'] <= first), None)
    summary = read(folder / 'memory-summary.json')
    for name, phase in phases.items():
        assert phase['sample_count'] == summary['phase_windows'][name]['sample_count']
        assert phase['bracket_delta_bytes'] == summary['phase_windows'][name]['bracket_delta_bytes']
    memory[arm] = dict(folder=str(folder), requested_interval_seconds=raw['requested_interval_s'],
                       sample_count=len(samples), running_samples=sum(s['process_running'] for s in samples),
                       actual_sample_gaps_ms=compact_stat(gaps), sample_cost_ms=compact_stat([s['sample_duration_ns']/1e6 for s in samples]),
                       sampled_peak_bytes={k: max((s[k] for s in samples if s[k] is not None), default=None) for k in fields},
                       observed_OS_lifetime_high_water_bytes={k: max((s[k] for s in samples if s[k] is not None), default=None)
                           for k in ['os_peak_working_set_bytes', 'os_peak_commit_bytes']},
                       nonnull_samples={k: sum(s[k] is not None for s in samples) for k in fields},
                       null_samples={k: sum(s[k] is None for s in samples) for k in fields},
                       ready_baseline_bytes={k: ready_sample[k] if ready_sample else None for k in fields},
                       ready_baseline_unknown=ready_sample is None, phases=phases,
                       setup_error=raw['gpu_setup_error'], thread_error=raw['thread_error'],
                       unavailable_reasons=summary['unavailable_reasons'])
    raw_artifacts.extend(identity(folder / n) for n in ['result.json', 'memory.json', 'memory-summary.json'])

comparison = {}
for other in ['before', 'dense', 'peer']:
    comparison[other] = {}
    for metric in groups['current']['rates']:
        a, b = groups['current']['rates'][metric], groups[other]['rates'][metric]
        comparison[other][metric] = dict(current_vs_other_median_percent=100*(a['median']/b['median']-1),
                                        observed_ranges_overlap=max(a['min'], b['min']) <= min(a['max'], b['max']))

# Additional identity and step validation belongs to this E window, not C's
# prior main/source assertions or separately profiled native trace conclusions.
repo = S.parents[1]
before_ready_path = repo / '.scratch/paged-capture-20261021/qwen-ready-attempt3.json'
current_ready_path = S / 'qwen-ready-attempt1.json'
current_ready, before_ready = read(current_ready_path), read(before_ready_path)
assert current_ready['image']['sha256'] == inputs['images']['current']['sha256']
assert before_ready['image']['sha256'] == inputs['images']['before']['sha256']
for ready in [current_ready, before_ready]:
    for key in ['image', 'link_plan', 'runtime_environment']:
        assert identity(ready[key]['path'])['sha256'] == ready[key]['sha256']
current_link, before_link = read(current_ready['link_plan']['path']), read(before_ready['link_plan']['path'])
old_inputs = {x['path']: x for x in before_link['inputs']}
new_inputs = {x['path']: x for x in current_link['inputs']}
shared_paths = old_inputs.keys() & new_inputs.keys()
assert all(old_inputs[x] == new_inputs[x] for x in shared_paths)
changed_old = [x for p, x in old_inputs.items() if p not in new_inputs]
changed_new = [x for p, x in new_inputs.items() if p not in old_inputs]
for record in changed_new + changed_old:
    assert identity(record['path'])['sha256'] == record['sha256']
closure = dict(current_inputs=len(new_inputs), before_inputs=len(old_inputs),
               unchanged_inputs=len(shared_paths), removed=changed_old, added=changed_new,
               current_ready=identity(current_ready_path), before_ready=identity(before_ready_path),
               current_link_plan=identity(current_ready['link_plan']['path']),
               before_link_plan=identity(before_ready['link_plan']['path']),
               current_sources=current_ready['fresh_sources'],
               main_changed=current_ready['source']['sha256'] != before_ready['source']['sha256'])
assert closure['main_changed']
current_environment = read(current_ready['runtime_environment']['path'])
before_environment = read(before_ready['runtime_environment']['path'])
closure['same_runtime_search_PATH'] = current_environment['PATH'] == before_environment['PATH']
closure['current_staged_runtime'] = current_environment.get('staged_dlls', [])
closure['before_staged_runtime'] = before_environment.get('staged_dlls', [])
assert [x['sha256'] for x in closure['current_staged_runtime']] == [x['sha256'] for x in closure['before_staged_runtime']]
closure['native_modules_boundary'] = ('Link-plan inputs and recorded runtime search/staged DLL identities are checked. '
    'No new process module enumeration was taken by this review; staged CPU DLL is only a shared dependency, not a CPU attention proof. '
    'Mathematical provider/kernel inputs unchanged between E and C are identified by the retained common link entries; this does not claim an isolated one-function causal experiment.')

expected_steps = []
visible = 0
for n, phase in enumerate(schedule):
    turn = n // 2 + 1
    if phase['kind'] == 'prefill':
        visible += len(phase['ids'])
        expected_steps.append(dict(name=f'round{turn}_prefill', input_tokens=len(phase['ids']), visible_tokens=visible))
    else:
        for i in range(len(phase['ids'])):
            visible += 1
            expected_steps.append(dict(name=f'round{turn}_decode{i+1}', input_tokens=1, visible_tokens=visible))
assert len(expected_steps) == 99 and visible == 864
prepared_by_arm = {arm: [] for arm in groups}
process_checks = []
timing_runs = read(P / 'timing/runs.json')
for row, entry in zip(rows, timing_runs):
    folder = Path(entry['folder']); arm = entry['variant']
    command = entry['process']['command']
    assert '--trace' not in command and '--preparation-diagnostics' not in command
    assert '--session-schedules' not in command
    stdout = read(folder / ('peer-result.json' if arm == 'peer' else 'stdout.log'))
    if arm != 'peer':
        assert stdout['diagnostic'] is False
        assert stdout.get('prefix_cache', 'off') == 'off'
        if arm in ['current', 'before']:
            assert stdout['prefix_hits'] == stdout['prefix_full_hits'] == stdout['reused_tokens'] == 0
            assert stdout['actual_graph_calls'] == 99 and stdout['actual_graph_tokens'] == 864
        stderr = (folder / 'stderr.log').read_text(encoding='utf-8')
        steps = []
        prepared = []
        for line in stderr.splitlines():
            if re.match(r'^round\d+_(prefill|decode\d+) ', line):
                name, *parts = line.split(); fields = dict(v.split('=', 1) for v in parts)
                steps.append(dict(name=name, input_tokens=int(fields['tokens']), visible_tokens=int(fields['visible'])))
            elif line.startswith('prepared '):
                fields = dict(v.split('=', 1) for v in line.split()[1:])
                prepared.append(dict(T=int(fields['T']), visible=int(fields['visible']),
                                     cold_seconds=float(fields['cold_batch_seconds']),
                                     recorded=int(fields['capture_recorded']), reused=int(fields['capture_reused'])))
        assert steps == expected_steps and len(prepared) == 99
        round_buckets = {}
        offset = 0
        for turn in range(1, 4):
            prefill = prepared[offset]; decode = prepared[offset+1:offset+33]; offset += 33
            assert prefill['T'] == 256 and all(s['T'] == 1 for s in decode)
            pure_reuse = [s['cold_seconds'] for s in decode if s['recorded'] == 0 and s['reused'] > 0]
            round_buckets[f'round{turn}'] = dict(prefill=prefill, decode_first_two=decode[:2],
                decode_all_cold_ms=stat([s['cold_seconds']*1000 for s in decode]),
                decode_pure_reuse_cold_ms=stat([v*1000 for v in pure_reuse]),
                patterns=dict(Counter(f"recorded{s['recorded']}_reused{s['reused']}" for s in decode)))
        prepared_by_arm[arm].append(dict(folder=str(folder), rounds=round_buckets))
    else:
        assert [dict(name=s['name'], input_tokens=s['input_tokens'], visible_tokens=s['visible_tokens'])
                for s in stdout['steps']] == expected_steps
    process_checks.append(dict(folder=str(folder), image_sha256=entry['process']['image']['sha256'],
        all99_names_inputs_visible=True,
        predicted_ids_sha256=hashlib.sha256(json.dumps(all_ids[len(process_checks)], separators=(',', ':')).encode()).hexdigest()))

# Check memory arm predictions, same schedule/command and raw summary maxima as
# well as the phase counts and bracket deltas already recomputed above.
for entry in read(P / 'memory/runs.json'):
    arm, folder = entry['variant'], Path(entry['folder'])
    raw = read(folder / ('peer-result.json' if arm == 'peer' else 'stdout.log'))
    assert raw.get('generated_ids', raw.get('predicted_ids')) == all_ids[0]
    assert raw['processed_tokens'] == 864 and raw['generated_tokens'] == 99
    assert not raw.get('diagnostic', False)
    summary = read(folder / 'memory-summary.json')
    aliases = dict(working_set_bytes='sampled_max_working_set_bytes',
                   private_commit_bytes='sampled_max_private_commit_bytes',
                   gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes',
                   gpu_shared_bytes='sampled_peak_gpu_shared_bytes',
                   gpu_total_bytes='sampled_peak_gpu_total_bytes')
    assert all(memory[arm]['sampled_peak_bytes'][key] == summary['sampled_peaks'][alias]
               for key, alias in aliases.items())
    for name, phase in memory[arm]['phases'].items():
        assert all(phase['sampled_peak_bytes'][key] == summary['phase_windows'][name]['values'][key]['max']
                   for key in aliases)

GIB = 1024**3
phase_names = [f'round{turn}_{kind}' for turn in range(1, 4) for kind in ['prefill', 'decode']]
limits = [
    'This is one finite unprofiled desktop window:3 timing processes per arm and1 independent memory process per arm. No statistical-significance, fixed-clock, isolated-device or universal TPS claim.',
    'E current versus C before includes the unique-tail consumer/main and shared permission/arena implementation changes recorded in the closure. Mathematical model weights/provider kernels are retained; this is not an isolated one-line causal estimate.',
    'Radix/prefix directory is off; one sequential Session has3turns. No prefix-hit benefit, multi-user concurrency, COW sharing throughput or end-to-end model quality is certified.',
    'Same BF16 source weights, BF16 KV and teacher-forced inputs do not assert identical intermediate arithmetic between Hyle and peer. Peer retains original native greedy/sample-logits transfer; Hyle retains its original host-token endpoint. Identical99 predicted IDs do not establish full hidden/logit equality or model quality.',
    'Separate memory processes, diagnostic and profiling data never enter timing denominators. No prior C native trace counts/durations are inherited here.',
    'Dedicated/shared process counters are sampled reported residency/accounting, not physical allocation attribution. The sampled total peak is max of simultaneous sums, not sum of individual maxima. OS lifetime high-water fields are labeled separately.',
    'Phase deltas use neighboring parent-time samples; missing boundaries stay null and sampled peaks are lower bounds. Final after-phase brackets may include process cleanup. Actual sample interval and query cost are preserved.'
]
table = dict(status='E finite window independently recomputed from raw logs; all16 processes exit0',
    workload=dict(prefill=[256,256,256], decode=[32,32,32], capacity=1024,
                  processed_tokens=864, prefill_tokens=768, decode_tokens=96, returned_tokens=99,
                  prefix_directory='off', sessions=1, turns=3),
    formulas=dict(prefill_tps='768/sum(three phase-prefill wall seconds) in each process',
                  full_decode_tps='96/sum(three phase-decode wall seconds) in each process',
                  session_output_tps='99/session_seconds in each process',
                  session_processed_tps='864/session_seconds in each process',
                  per_round_tps='that phase input_tokens/that phase wall seconds',
                  cold_output_tps='99/startup_total_seconds in each process'),
    aggregation='Per-process rate first, then median/min/max of3 process rates per arm. No pooled process rates or average of phase TPS.',
    images=inputs['images'], timing=groups,
    memory_phase_order=phase_names,
    independent_memory={arm:dict(samples=m['sample_count'], sampled_peak_bytes=m['sampled_peak_bytes'],
        sampled_peak_GiB={key:(value/GIB if value is not None else None) for key,value in m['sampled_peak_bytes'].items()},
        actual_sample_gaps_ms=m['actual_sample_gaps_ms'], requested_interval_seconds=m['requested_interval_seconds'],
        sample_cost_ms=m['sample_cost_ms'], ready_baseline_unknown=m['ready_baseline_unknown'],
        ready_baseline_bytes=m['ready_baseline_bytes'],
        phase_gpu_dedicated_max_bytes=[m['phases'][name]['sampled_peak_bytes']['gpu_dedicated_bytes'] for name in phase_names],
        phase_gpu_dedicated_max_GiB=[m['phases'][name]['sampled_peak_bytes']['gpu_dedicated_bytes']/GIB
                                   if m['phases'][name]['sampled_peak_bytes']['gpu_dedicated_bytes'] is not None else None for name in phase_names],
        phase_gpu_shared_max_bytes=[m['phases'][name]['sampled_peak_bytes']['gpu_shared_bytes'] for name in phase_names],
        approximate_phase_deltas={name:dict(sample_count=v['sample_count'],
            gpu_dedicated_bytes=v['bracket_delta_bytes']['gpu_dedicated_bytes'],
            gpu_shared_bytes=v['bracket_delta_bytes']['gpu_shared_bytes']) for name,v in m['phases'].items()},
        phases=m['phases'], null_samples=m['null_samples'],
        observed_OS_lifetime_high_water_bytes=m['observed_OS_lifetime_high_water_bytes']) for arm,m in memory.items()},
    comparison=comparison, closure=closure, prepared_buckets=prepared_by_arm, limits=limits)
conclusions = []
for other in ['before', 'dense', 'peer']:
    conclusion = dict(comparator=other,
        median_changes_percent={metric:data['current_vs_other_median_percent'] for metric,data in comparison[other].items()},
        observed_ranges_overlap={metric:data['observed_ranges_overlap'] for metric,data in comparison[other].items()})
    conclusions.append(conclusion)
table['conclusions'] = conclusions
save(P / 'public-table.json', table)
review = dict(status='Host-only source/identity and independent raw-result recomputation completed; no reruns',
    source_inputs=[identity(P/name) for name in ['timing/inputs.json','timing/runs.json','timing/summary.json',
                                               'memory/inputs.json','memory/runs.json','memory/summary.json']],
    algorithm_provenance=identity(repo/'.scratch/paged-capture-20261021/review/recompute_performance.py'),
    driver=identity(S/'performance.py'), base_driver=identity(repo/'.scratch/paged-prepare-20261021/performance.py'),
    original_driver=identity(repo/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py'),
    schedule=dict(manifest=identity(manifest), files=[p['source'] for p in schedule],
                  total=864, outputs=99, phase_context_after=[256,288,544,576,832,864]),
    checks=dict(timing_processes=12, memory_processes=4, all_exit0=True, all16_process_predictions_equal=True,
                phase_contexts_and99step_names_inputs_visible=True,
                timing_separate_from_memory_and_trace=True, no_prefix_lookup_hits=True,
                actual_model_quality_acceptance=False, product_edits=0, builds=0, GPU_runs_by_reviewer=0),
    per_process=rows, per_process_step_checks=process_checks, groups=groups,
    independent_memory=memory, comparison=comparison, closure=closure,
    prepared_buckets=prepared_by_arm, conclusions=conclusions, fair_scope=limits,
    timer_contract=dict(current_main_snapshot=identity(S/'compile2/main/source/tools/qwen35_text/main.cc'),
        before_main_snapshot=identity(S/'graph/before/tools/qwen35_text/main.cc'),
        actual_main_identity=identity(S/'compile2/main/identity.json'),
        phase_session='First phase input-preparation start to last actual host-visible token endpoint. Includes intervening control and realtime phase markers; individual step reports are deferred beyond the session endpoint.',
        step='Includes actual preparation, submit/completion, host result and committed snapshot publication. Endpoint is captured before trace/report output. No trace/preparation-diagnostic flags in actual timing commands.',
        cold_vs_warm='Model/family compilation and startup-to-ready are separately reported; per-call preparation/capture remains inside each actual step and phase wall. No synthetic warmup or excluded first invocation.',
        prepared_log='Combined cold_batch_seconds is a measured outer preparation bucket, not native append function self-time or a reusable CPU cost attribution.'),
    raw_artifacts=raw_artifacts, public_table=identity(P/'public-table.json'), recompute_script=identity(__file__),
    background_snapshots=[identity(P/mode/name) for mode in ['timing','memory'] for name in
        ['window-before.json','window-after.json','window-before-gpu.stdout.log','window-after-gpu.stdout.log',
         'window-before-compute_apps.stdout.log','window-after-compute_apps.stdout.log'] if (P/mode/name).exists()])
save(S/'review/performance-review.json',review)
for arm in groups:
    print(arm,{key:round(value['median'],6) for key,value in groups[arm]['rates'].items()},
          'dedicatedGiB',memory[arm]['sampled_peak_bytes']['gpu_dedicated_bytes']/GIB,
          'sampleMedianMs',memory[arm]['actual_sample_gaps_ms']['median'])
print(json.dumps(dict(public_table=identity(P/'public-table.json'),review=identity(S/'review/performance-review.json'))))
