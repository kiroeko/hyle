"""Exact reconstructible stage leaves only; write root test.ps1 before deletion."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
def identity(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
targets=[]
for folder in sorted(S.glob('*-link*')):
 if not folder.is_dir():continue
 for p in folder.iterdir():
  if p.is_file()and(p.suffix in ('.map','.lib','.exp')or(p.suffix=='.exe'and p!=S/'qwen-link1/qwen.exe')):targets.append(p)
assert len(targets)==len(set(targets))and all(p.resolve().is_relative_to(S)for p in targets)
plan=dict(targets=[identity(p)for p in targets],total_bytes=sum(p.stat().st_size for p in targets),
 receipt=str(R/'docs/evidence/performance/qwen-exclusive-radix-2026-10-21.cleanup.json'),
 reason='Current Qwen image retained for next matched performance window. CPU/CUDA/host/probe images and linker output can be relinked from kept objects and exact commands; all success/failure identities and logs retained.',
 kept=['Current8a400 Qwen and prior7b854/dense/llama comparison images; all changed objects, source/before/diffs, vector regression payload/oracles, native libraries/SDK/dependency caches, exact compile/link/run commands, failure/pass receipts and independent reviews. No recursive delete, SDK/cache/model deletion or cross-stage image deletion.'])
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=(R/'.scratch/paged-capture-20261021/cleanup-script.ps1').read_text(encoding='utf-8').replace('paged-capture-20261021','paged-exclusive-20261021').replace('qwen-capturable-append-2026-10-21','qwen-exclusive-radix-2026-10-21')
(R/'test.ps1').write_text(script,encoding='utf-8');(S/'cleanup-script.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(files=len(targets),bytes=plan['total_bytes'],script=identity(R/'test.ps1'),targets=[str(p.relative_to(R))for p in targets]),indent=2))
