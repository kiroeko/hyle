"""Preserve only the current owners this stage changes; never copy SDKs or weights."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
paths=['include/hyle/graph/batch.h','include/hyle/graph/detail/region_access.h',
 'src/graph/resources.cc','src/graph/submission_internal.h','src/graph/lease_submission.cc',
 'src/graph_batch/paged_append.cc','tools/qwen35_text/main.cc','tools/qwen35_text/session_state.h']
rows=[]
for name in paths:
 p=R/name;v=p.read_bytes();dest=S/'graph/before'/name
 dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(v)
 rows.append(dict(path=name,bytes=len(v),sha256=hashlib.sha256(v).hexdigest()))
(S/'graph/before.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print('Saved exact8 changed-owner before sources; no SDK/model/archive copies.')
