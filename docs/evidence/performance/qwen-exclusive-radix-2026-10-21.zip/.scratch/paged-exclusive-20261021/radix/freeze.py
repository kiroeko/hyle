from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[2]
FILES = ['tools/qwen35_text/prefix_cache.h', 'tests/tools/qwen_prefix_cache_test.cc']

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

sources = []
patches = []
for relative in FILES:
    path = R / relative
    before = S / 'before' / relative
    frozen = S / 'source' / relative
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(path.read_bytes())
    sources.append(dict(current=identity(path), frozen=identity(frozen), before=identity(before) if before.exists() else None))
    patches.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True) if before.exists() else [],
        path.read_text(encoding='utf-8').splitlines(True), fromfile='before/' + relative, tofile='after/' + relative))
diff = S / 'implementation.diff'
diff.write_text(''.join(patches), encoding='utf-8')
header = (R / FILES[0]).read_text(encoding='utf-8').splitlines()
test = (R / FILES[1]).read_text(encoding='utf-8').splitlines()

def line(lines, text):
    return next(i + 1 for i, value in enumerate(lines) if text in value)

report = dict(
    status='Source implementation frozen; parent owns focused host compilation/run and model/GPU verification. No runtime pass claimed here.',
    scope='Consumer-private compressed radix index only. No main, Compute/Graph, provider, SDK, CMake, checkpoint exporter or executor changes.',
    sources=sources,
    read_contracts=[identity(R / p) for p in (
        'docs/evidence/research/radix-hybrid-prefix-cache-2026-10-21.json',
        'tools/qwen35_text/session_state.h', 'tools/qwen35_text/schedule.h')],
    preserved_contracts=[
        'lookup/publish/retains/Hit/ReplayPrefix signatures and evictions/size stay available; PrefixCache itself is explicitly noncopyable/nonmovable because Hits reference its stable owner.',
        'Snapshot is the original immutable complete KV plus conv/GDN state, length, next_id and model/math identity. The index neither manufactures state nor admits resource/native uses.',
        'Model/math pointer pair isolates roots using std::less<const void*> ordering; token edges compare exact IDs and never trust a hash collision.',
        'Only actual published payload boundaries in [minimum,target] are hits. A split structural node has no payload. A target/mismatch inside an edge falls back to the last eligible actual ancestor.',
        'Original ReplayPrefix source chunks/next_id are retained unchanged; publish validates all used chunks against the exact token prefix before any mutation.',
        'Multiple readonly Hits may pin the same entry. Counted pins forbid replacement/eviction until all Hits reset; directory eviction cannot revoke an escaped SnapshotRef or prove native retirement.',
        'Original finite VersionRef, state/page capacity and candidate admission remain owner responsibilities. Transient index references never create a distinct Snapshot version.',
        'Operations are externally serialized at phase boundaries; cache outlives Hits, model outlives snapshots. No locks, per-token LRU lookup or GPU work are added.'
    ],
    representation_and_bounds=dict(
        layout='One compressed forest with sorted domain vector, ordered sibling links, stable pool node/entry indices, and one intrusive payload LRU. No second payload cache or persistent auxiliary state map.',
        stable_proof='For P payloads in D nonempty domains, nonroot nonpayload branching nodes B <= P-D; payload-free unary nodes collapse and empty leaves/roots disappear. Nodes=P+B+D <=2P.',
        commit_scratch='Cold arrays hold E+1 payload slots, 2E+2 nodes and E+1 domain records. A publish stages the new boundary before deleting a preselected unpinned victim. During that no-fail interval P<=E+1, so even an internal victim that frees no payload-node cannot exhaust nodes. Public size returns <=E.',
        failure='All vectors allocate/reserve during construction. Publish history checks, existing pinned-key rejection and no-evictable rejection precede mutation. Commit copies/moves shared owners and fixed-capacity metadata only; no allocation is required after mutation begins. Constructor allocation failure never yields an object.',
        complexity='Domain lookup O(log D); exact edge token comparisons O(L) total along one path. Ordered sibling lookup may visit O(E) siblings in the worst case, so lookup is O(L+E), not a claim of strict O(L). It avoids the old per-entry O(E*L) repeated token comparison.',
        lru='Touch/unlink O(1) intrusive links. Eviction can walk O(E) pinned entries; no vector find/erase/shift for payload LRU. Domain insert/remove is cold O(D); retains remains O(E).',
        retained_token_memory='Edges hold TokenPlanRef slices; an edge can retain a whole longer token plan. Node count is bounded, not a claim that retained token bytes shrink to edge length.'
    ),
    host_fixture=dict(
        path=FILES[1],
        default='Four GTest cases under QwenPrefixCache; root may register/build with existing host dependencies later.',
        standalone='Define HYLE_PREFIX_CACHE_STANDALONE=1 for a standalone main. It rejects every ordinary heap new during the valid split/publish/domain/prune phase; no native model execution.',
        checks=[
            'Exact multi-edge split/no-state fallback, real shorter/branch boundary, minimum/target, hash collision, model/math namespaces, actual two-chunk replay and invalid replay no-mutation.',
            'Two simultaneous Hits on one readonly snapshot, one-reset still pinned, all-pinned admission/replacement rejection, moved Hit, LRU and escaped snapshot ownership.',
            '800 deterministic inserts across capacity 1/5 and three domains; exact result/LRU/capacity compared with independent linear boundary oracle, covering internal payload eviction and pool-slot reuse.',
            'Fixed-capacity commit with allocation rejection, including divergence split, new internal payload, full eviction, different domain and final pruning.'
        ],
        caveat='Metadata-only Snapshot host fixtures verify index/owner policy; they do not pretend to contain real initialized KV/GDN leases or sign native permission/reuse.',
        execution='Not compiled or run by this subagent; parent requested unified builds.'
    ),
    required_followups=[
        'Root compiles the focused host fixture and current Qwen main TU that includes the changed private header; no Compute/Graph SDK ABI refresh is implied.',
        'Use the existing real prefix pressure/canonical isolated-state comparisons to verify model numerical behavior; do not infer a GPU throughput benefit from a host index replacement.',
        'Mid-prefill checkpoints need actual whole recurrent state export at the requested depth and a legal finite suffix child. This patch adds neither and does not claim full RadixAttention/continuous batching or arbitrary split-point reuse.'
    ],
    anchors=dict(
        pools_and_domains=line(header, 'struct Node final'),
        compressed_insert=line(header, 'std::size_t insert_path('),
        lru_and_prune=line(header, 'void unlink_lru('),
        counted_hit=line(header, 'class Hit final'),
        bounded_cold_capacity=line(header, 'explicit PrefixCache('),
        exact_lookup=line(header, 'Hit lookup('),
        validated_publish=line(header, 'bool publish('),
        exact_fixture=line(test, 'void exact_boundaries_and_domains()'),
        pin_fixture=line(test, 'void shared_pins_and_lru()'),
        churn_fixture=line(test, 'void bounded_tree_reuse()'),
        allocation_fixture=line(test, 'void allocation_free_commit()')
    ),
    actual_operations=dict(product_CXX=0, host_fixture_CXX=0, links=0, SDK_builds=0, GPU_runs=0, network_calls=0)
)
save(S / 'report.json', report)
save(S / 'source-freeze.json', dict(status='Frozen source, no build/runtime claim', files=sources,
    diff=identity(diff), report=identity(S / 'report.json'), generator=identity(__file__)))
print(json.dumps(dict(freeze=identity(S / 'source-freeze.json'), report=identity(S / 'report.json'), sources=sources), ensure_ascii=False))
