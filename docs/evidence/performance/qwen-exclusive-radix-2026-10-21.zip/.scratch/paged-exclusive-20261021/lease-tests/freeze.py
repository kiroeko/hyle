from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
RELATIVE = "tests/compute/resource_leases_test.cc"

def identity(path):
    raw = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}

source = ROOT / RELATIVE
before = STAGE / "before" / RELATIVE
snapshot = STAGE / "source" / RELATIVE
snapshot.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(source, snapshot)
diff = difflib.unified_diff(before.read_text(encoding="utf-8").splitlines(keepends=True),
                          source.read_text(encoding="utf-8").splitlines(keepends=True),
                          fromfile="before/" + RELATIVE, tofile="after/" + RELATIVE)
(STAGE / "implementation.diff").write_text("".join(diff), encoding="utf-8", newline="")
checked = subprocess.run(["git", "diff", "--check", "--", RELATIVE], cwd=ROOT,
                         capture_output=True, text=True)
assert checked.returncode == 0, checked.stdout + checked.stderr
report = {
    "status": "Four focused host test cases added; frozen source only, not compiled or executed by this owner.",
    "source": identity(source), "before": identity(before), "snapshot": identity(snapshot),
    "diff": identity(STAGE / "implementation.diff"),
    "filter": "AppendLeases.*",
    "cases": [
        {"name": "AppendLeases.BoundedPrefixCannotWidenOrPromoteAndFullPageHasNoTail",
         "checks": "Rejected publication preserves original writer; copied prefix cannot widen/promote even when sole reader; full initial page has no appender; ordinary legacy subview does not qualify as append-origin."},
        {"name": "AppendLeases.ReservedSuffixRequiresQualifiedUseAndKeepsOldReaderBounded",
         "checks": "Prior original native use prevents reserve; invalid extents leave epoch unchanged; exact suffix address/extent; ordinary native readers reject while qualified append_unique admits; actual release precedes publish; old prefix remains bounded and generation stable."},
        {"name": "AppendLeases.FailedEpochWaitsForActualReleaseThenRollbackCanRetryAndClose",
         "checks": "Dropped failed Completion retains original episode; terminal error alone cannot permit rollback; after actual release failed publish rejects, rollback restores original prefix admission and new epoch succeeds; closed domain permits retired rollback but rejects new view/publication/reserve."},
        {"name": "AppendLeases.AbandonedTailWaitsForOriginalNativeRetirement",
         "checks": "Resetting pending cap cannot clear reservation/return backing; original retained Completion release allows only committed prefix native use and never restores ordinary whole-block write authority."}
    ],
    "fake_runtime": "Reuses this file's original PendingUse/kPending Completion helper. No sleep, native backend, or hardware ordering claim; same-Graph DAG qualification belongs to Graph integration tests.",
    "graph_group_review": {
        "source": identity(ROOT / "src/graph/lease_submission.cc"),
        "entry_definition": identity(ROOT / "src/graph/submission_internal.h"),
        "blocking_findings": [],
        "facts": [
            "All root groups validate generation and ordinary write/read/append mixing before trusted F1 admission.",
            "Every old ReadLease in an append group passes LeaseAccess::validate_prefix against the selected unique authority.",
            "Admission chooses an append entry whether it sorts first or later; duplicate same-cap references collapse to one root use, different cap pointers for one root reject.",
            "Graph exact suffix/root/epoch and writer-to-reader DAG proof remains a prerequisite outside this generic permission collection; this review does not certify those broader changes."
        ]
    },
    "existing_target": "tests/compute/CMakeLists.txt hyle_compute_test already contains resource_leases_test.cc; no CMake edit or extra target.",
    "diff_check": {"exit_code": checked.returncode, "output": checked.stdout + checked.stderr},
    "not_run": ["CXX compilation", "Host fixture execution", "GPU/native test", "Graph integration", "Performance"]
}
(STAGE / "source-freeze.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": identity(STAGE / "source-freeze.json"), "source": identity(source)}, indent=2))
