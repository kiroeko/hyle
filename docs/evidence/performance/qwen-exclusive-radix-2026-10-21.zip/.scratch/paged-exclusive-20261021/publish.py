"""Bounded exact source/command/numeric/performance evidence; no SDK/model/object payload."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
report=R/'docs/evidence/performance/qwen-exclusive-radix-2026-10-21.json';archive=report.with_suffix('.zip')
assert not report.exists()and not archive.exists()
freeze=read(S/'implementation/source-freeze.json');assert len(freeze['files'])==20
for row in freeze['files']:assert identity(row['current']['path'])==row['current']and identity(row['frozen']['path'])==row['frozen']
numeric=read(S/'review/runtime-comparison.json');table=read(S/'performance/public-table.json')
assert read(S/'single-run1/summary.json')['vector_count']==18 and read(S/'multi-run1/summary.json')['vector_count']==72
for name in ('single-run1','multi-run1','main-run1','pressure-run1','cpu-run1','cuda-run1','probe-run2'):
 assert read(S/name/'result.json')['exit']==0
for name in ('radix-run2','lease-run1','lease-legacy-run1'):assert read(S/name/'tests.result.json')['exit']==0
probe=read(S/'probe-run2/observation.json');assert probe['status']=='PASS'and probe['old_kv_guards_and_bytes_unchanged']and probe['same_page_exclusive_suffix']
assert probe['managed_bytes_while_native_pending']==probe['managed_backing_bytes']==42418224
runs=read(S/'performance/timing/runs.json')+read(S/'performance/memory/runs.json')
assert len(runs)==16 and all(x['process']['exit']==0 for x in runs)
assert all(x['observation']['predicted_ids']==runs[0]['observation']['predicted_ids']for x in runs)
assert len(runs[0]['observation']['predicted_ids'])==99
sources=[row['current']['path']for row in freeze['files']]
docs=['docs/developer/current-work.md','docs/developer/performance/decode.md','docs/architecture/compute-design.md','docs/architecture/graph-design.md','tools/qwen35_text/README.md']
allowed={'.json','.py','.ps1','.log','.diff','.patch','.txt','.md','.cc','.h','.cu','.tsv','.xml'}
paths={}
for p in S.rglob('*'):
 if p.is_file()and p.suffix in allowed and 'tmp'not in p.relative_to(S).parts and '__pycache__'not in p.parts and p.name!='published.json':paths[p.relative_to(R).as_posix()]=p
for p in map(Path,sources+[str(R/n)for n in docs]):paths[p.relative_to(R).as_posix()]=p
for rel in ('.scratch/paged-capture-20261021/build.py','.scratch/paged-retirement-20261021/build.py','.scratch/paged-prepare-20261021/performance.py'):
 paths[rel]=R/rel
inventory=[dict(archive_path=n,**identity(p))for n,p in sorted(paths.items())]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for n,p in sorted(paths.items()):z.write(p,n)
 z.writestr('manifest.json',json.dumps(dict(files=inventory,scope='20 changed sources and before/diffs, actual strict host compile/link/run commands, failures and passes, all16 performance processes, host-only independent vector/performance recomputation, exact cleanup plan/script.',excluded='No model/SDK/native library/exe/object/map or duplicate raw vector payloads. Actual142 vector payloads, current and prior matched Qwen images and regression oracles remain in retained scratch. Host/probe images may be relinked from kept objects after the recorded cleanup.'),indent=2))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
save(report,dict(date='2026-10-21',created_utc=datetime.now(timezone.utc).isoformat(),
 status='Unique-tail append and bounded consumer Radix implemented and current Windows CPU/CUDA/Qwen checks complete; one four-arm performance window complete. No new throughput gain established. Other-native full consumers, matched multi-session performance, MTP/images and remaining architecture/performance work are not complete.',
 archive=identity(archive),archive_file_count=len(inventory),source_freeze=identity(S/'implementation/source-freeze.json'),
 current_ready=identity(S/'qwen-ready-attempt1.json'),current_image=read(S/'qwen-ready-attempt1.json')['image'],
 source_identities=[identity(p)for p in sources+[str(R/n)for n in docs]],
 implementation=[
 'Private AppendLease owns one original root/generation, bounded committed prefix and a unique suffix authority. Ordinary ReadLease/WriteLease contract/layout is unchanged. No duplicate page pool, interval permission map, alternate executor or provider/model whitelist.',
 'Fresh typed page publish_appendable returns an immutable bounded ReadLease and move-only PagedPageAppender. Only monotone consecutive suffix may be reserved. Legacy whole-page ready guards cannot promote to append authority; old readers never widen. Full-page commit consumes the tail.',
 'Original Graph permissions validate every old bounded read against the actual original tail; one root receives exactly one qualified append admission covering its suffix and old prefix read. Whole writers cannot mix with append. Existing actual Queue/Completion/reaper lifetime remains authoritative, failed suffix affects only its append epoch.',
 'PagedAppendPages validates exact old/new layouts and reserved row ranges before moving callers. Fresh targets use original COW; tails write only reserved suffix. The native wire and CUDA leaf are unchanged; no NVCC needed. Whole-Graph success plus true retirement precedes publication; retired failure rolls back without changing old reader bounds.',
 'Qwen Session alone owns12 tail authorities matching its exact committed head. Prefix Hits/Snapshots do not copy authority; branches without a tail use original COW. All state/KV results are assembled before atomically replacing the visible head. No change to state pool backing reservations or speculative prefix checkpoint generation.',
 'Consumer PrefixCache is now one bounded compressed radix forest with exact token edges/model+math domains, payload LRU and counted readonly pins. Structure-only splits have no state. Cold arrays include bounded atomic commit scratch; lookup worst O(L+E) versus previous repeated O(E*L) token comparisons, not strict O(L). Valid mutations allocate no ordinary heap after construction.',
 'The new host directory fixture is registered through existing project correctness CMake helper, conditional on Compute batch/Graph/mem products. Default GTest registration was edited but not regenerated or built via CMake this stage; equivalent standalone fixture compiled/run with retained strict flags.'],
 build=dict(host_compile_successes=12,host_compile_failure=1,links_success=7,link_failure=1,NVCC=0,SDK_builds=0,
  closure='Current versus C195inputs unchanged in count:189 identical and6 exact replacements (leases,arena,submission,resources,append,consumer main). Current native kernels/provider DLL unchanged. Cached source dependencies and object identities retained; no blanket current-source freshness claim for all unchanged cached factors.'),
 correctness=dict(total_decision_vectors=142,all_byte_equal=True,all_finite=True,
  independent_review=identity(S/'review/runtime-comparison.json'),canonical=[identity(S/n/'summary.json')for n in ('single-run1','multi-run1')],
  host_tests=dict(append_lease=4,original_lease_and_copy_handoff=13,radix_cases=4,radix_oracle_mutations=800,
   results=[identity(S/n/'tests.result.json')for n in ('lease-run1','lease-legacy-run1','radix-run2')]),
  graph_fixtures=dict(CPU=identity(S/'cpu-run1/result.json'),CUDA=identity(S/'cuda-run1/result.json'),
   checks='Original fresh/COW and alias/DAG cases retained; new same-tail BF16 cases, old bounded snapshot bytes/math, failure->actual retirement->rollback retry, no-tail COW; CUDA strict reused same Invocation capture with0record on subsequent calls.'),
  actual_native_retirement=dict(result=identity(S/'probe-run2/result.json'),observation=probe),
  unchanged_observations='All four model-run non-time observations including ID, cache/pin/LRU, dispatch, fullhit0Graph, Graph work, replay/restore and page/version/byte budgets independently recomputed equal to C, not assumed from unchanged semantics.',
  limits='Current WindowsCPU fallback/CUDA exact tested model journeys. No allOS/native backend certification, simultaneous GPU serving throughput, arbitrary checkpoint density, every intermediate tensor proof or independent model quality acceptance.'),
 performance=dict(table=table,independent_review=identity(S/'review/performance-review.json'),
  timing=identity(S/'performance/timing/summary.json'),memory=identity(S/'performance/memory/summary.json'),
  scope='Three turns256newprompt+32decode,ctx1024,864inputs/96decode/99returned IDs;3fresh interleaved timing per arm and1 separate sampled-memory per arm. Prefix directory off: no Radix-hit or multi-user throughput claim. Each process ratio before median.',
  conclusion='Versus C before: P-1.7879%,D-0.1787%,session-0.8084%,all ranges overlap: no throughput benefit proven. Versus llama: aggregateP+17.1529%,D-4.6398%,session-1.8516%,nonoverlapping samples in this finite window. Current/before sampled dedicated peak equal; fixed preallocated page pool not reduced.',
  no_new_native_trace=True,previous_native_trace_is_historical_only=True,
  limits='One desktop finite window, no GPU isolation/fixed clocks. No cross-window absolute-value gain estimate. Sampled memory peaks are lower bounds,readyoccupancy unknown. Descriptor preparation bucket includes upload/wait and is not individual function attribution.'),
 failures_and_corrections=[
 'Incremental submission recipe lookup first selected an identity record without command: setup KeyError,no compiler launch. Reused retained compatible Graph compile flags,strict compile then passed; setup failure not called compile failure.',
 'Actual main compile1 rejected move-return helper instantiated for Result<T&>. The helper now uses reference-collapsing cast T&&; main compile2 and actual consumers pass.',
 'First Radix link replaced ggml native-main implementation object instead of actual consumer qwen.obj, producing duplicate main/undefined bridge symbols. Replaced actual exact consumer object; final all6 owner replacements and189 unchanged inputs independently verified. No library/Provider code changed to hide this tooling error.',
 'First retirement probe required candidate page to become a fresh whole-page writer after cancellation. Under exclusive append it is intentionally still owned by old committed prefix; assertion failed. Probe2 instead proves same physical tail, all old KV guard bounds and complete bytes unchanged, no whole-page acquisition while old readers remain, and fresh acquisition only after final old readers release. Original native-block/cancel/dropCompletion checks retained; failed run kept.'],
 architecture_review=identity(S/'review/graph-permissions-review.json'),
 known_remaining=[
 'Current paged D still slower than original dense and llama in this window; unique-tail feature is correct but no speed win measured. Separate single-session latency, prefix reuse benefit and multi-user aggregate throughput.',
 'Host permission/layout/publication work still scales with retained page footprint; current StepState also allocates12 separate single-tail vectors. Reduce repeated work/short-lived allocation through actual common ownership, without extending stale permissions.',
 'Descriptor upload owns real F1 storage and Completion retirement and currently waits in preparation. Investigate legal dependency reuse or upload overlap; do not report the entire cold bucket as removable.',
 'Radix index works only at actual complete KV/conv/GDN snapshot boundaries. More useful checkpoint placement must fit version/page/byte quotas and finite shape domain; branch nodes are not synthetic state.',
 'OtherOS/native append consumers and encoded writes, matched multi-session performance, actual MTP draft/verify/state recovery and image encoder/projector, remaining multi-model routing and architecture audits.'],
 cleanup_plan=identity(S/'cleanup-plan.json'),cleanup_script=identity(S/'cleanup-script.ps1'),
 previous_evidence=['docs/evidence/performance/qwen-capturable-append-2026-10-21.json','docs/evidence/research/radix-hybrid-prefix-cache-2026-10-21.json','docs/evidence/correctness/qwen-prefix-reuse-2026-10-21.json'],
 next='Reduce confirmed host metadata/permission preparation cost; then matched complete multi-session/prefix workload, continue real MTP/images and architecture coverage. Goal stays active, no claim all remaining work is validation.'))
save(S/'published.json',dict(files=[identity(report),identity(archive)],archive_files=len(inventory),uncompressed_bytes=sum(x['bytes']for x in inventory)))
print(json.dumps(read(S/'published.json'),indent=2))
