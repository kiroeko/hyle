"""Prepare or explicitly run the retained 32-process complete peer window.

Only run-one/resume-one start model processes; prepare performs file checks and
emits commands. No compile, peer rebuild, download or automatic retry exists.
  python window.py prepare
  python window.py run-one single timing
  python window.py run-one single memory
  python window.py run-one two-turn timing
  python window.py run-one two-turn memory
  python window.py summary
"""
from pathlib import Path
from collections import Counter
import copy
import importlib.util
import math
import os
import sys

sys.dont_write_bytecode = True
BATCH = Path(__file__).resolve().parent
R = BATCH.parents[1]
W = BATCH / 'peer-window'
OLD = R / '.scratch/inference-small-projection-20261028/current-peer-window'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


legacy = module('paired_m2_retained_peer_window', OLD / 'window.py')
base, protocol = legacy.base, legacy.protocol
ARMS, GROUPS = legacy.ARMS, legacy.GROUPS
old_analyze = legacy.analyze
# Reuse the exact original process runner, marker adapter, PSAPI/PDH sampler,
# producer normalization, single/two-turn parsers and within-arm full oracle.
legacy.W = W
protocol.D = W


def exact(item):
    assert base.identity(item['path']) == item, item['path']


def save_new(path, value):
    assert not path.exists(), 'Preserve existing metadata/attempt: ' + str(path)
    base.save(path, value)


def prepare():
    assert not (W / 'plan.json').exists(), 'Window already prepared'
    assert not any((W / (s + '-' + m)).exists() for s, m in GROUPS)
    peer = base.read(OLD / 'peer-ready.json')
    if not Path(peer['image']['path']).is_file():
        raise SystemExit('Frozen peer image is missing: ' + peer['image']['path'] +
                         '; no peer build or download will be attempted.')
    exact(peer['image'])
    exact(peer['runtime_environment'])
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    normal = base.read(BATCH / 'normal-product-ready.json')
    image = normal['image']
    exact(image)
    assert normal['smoke_passed'] is True and normal['instrumented'] is False
    assert Path(image['path']).resolve() == (R / '.scratch/build-compute-v2-dev/bin/hyle.exe').resolve()
    exact(normal['build'])
    exact(normal['loaded_runtime'])
    for source_pin in normal['source_pins']: exact(source_pin)
    prior = base.read(OLD / 'binding.json')
    for name in ('prompt', 'input_manifest', 'schedule', 'GGUF_metadata_receipt', 'protocol'):
        exact(prior[name])
    for name in ('plain', 'full_mtp'):
        row = prior['GGUF_offline_metadata'][name]
        assert Path(row['path']).is_file(), 'Missing frozen peer payload: ' + row['path']
        assert Path(row['path']).stat().st_size == row['bytes']
    assert len(Path(prior['prompt']['path']).read_text().split()) == 154
    runtime_reference = normal['runtime_environment']
    exact(runtime_reference)
    environment = base.read(runtime_reference['path'])
    environment['PATH'] = str(Path(image['path']).parent) + ';' + environment['PATH']
    W.mkdir(exist_ok=True)
    save_new(W / 'runtime-environment.json', environment)
    current = dict(image=image, instrumented=False,
        runtime_environment=base.identity(W / 'runtime-environment.json'),
        normal_product_binding=base.identity(BATCH / 'normal-product-ready.json'),
        normal_build=normal['build'], loaded_runtime=normal['loaded_runtime'],
        canonical_main=base.identity(R / 'engine/models/qwen35/main.cc'),
        scope='Normal Release shared hyle product from CMake engine+cpu;cuda, source/image/actual loaded-runtime pinned after smoke; no manual CLI or retained SDK substitution.')
    save_new(W / 'ready.json', current)
    save_new(W / 'peer-ready.json', peer)
    arms = copy.deepcopy(base.read(OLD / 'arms.json'))
    arms['note'] = 'Normal default-product ordinary-auto/MTP-auto greedyK1 fullV versus frozen peer433e; fresh samples only.'
    for name, row in arms['arms'].items():
        row['ready'] = str(W / ('ready.json' if name.startswith('hyle') else 'peer-ready.json'))
        if name.startswith('hyle'):
            row['command'][row['command'].index('--decode-overlap') + 1] = 'auto'
    save_new(W / 'arms.json', arms)
    binding = dict(status='PREPARED_ONLY_NOT_RUN', Hyle=current, peer=peer,
        retained_window=base.identity(OLD / 'window.py'), runner=base.identity(__file__),
        previous_window_plan=base.identity(OLD / 'plan.json'),
        prompt=prior['prompt'], input_manifest=prior['input_manifest'], schedule=prior['schedule'],
        GGUF_offline_metadata=prior['GGUF_offline_metadata'], GGUF_metadata_receipt=prior['GGUF_metadata_receipt'],
        protocol=prior['protocol'], endpoint_and_sampler=prior['endpoint_and_sampler'],
        policy='Both Hyle roles request decode-overlap auto; greedy MTP K1. Frozen peer commands unchanged.',
        fairness='Same P154/64-return budget, C1024/N1/R1, natural greedy and real two-turn schedule. Preserve actual IDs/acceptance/rows; no cross-engine equal-work claim.',
        memory='Retained 10ms-requested Windows PSAPI/PDH; missing ready/counter samples stay unknown/null, sampled peaks are lower bounds.',
        limits=dict(model_processes=32, timing=24, independent_memory=8, GPU_concurrency=1,
                    automatic_retries=0, profiler=False, warmup=False),
        historical_samples_pooled=False, compiler_processes_started=0, model_processes_started=0)
    save_new(W / 'binding.json', binding)
    groups = []
    ordinal = 0
    for scenario, mode in GROUPS:
        reference = OLD / (scenario + '-' + mode + '-plan.json')
        group = copy.deepcopy(base.read(reference))
        for row in group['commands']:
            original = row['command'].copy()
            command, arm = row['command'], row['arm']
            folder = W / (scenario + '-' + mode) / (f"{row['ordinal']:02d}-" + arm)
            if arm.startswith('hyle'):
                command[0] = image['path']
                command[command.index('--decode-overlap') + 1] = 'auto'
                assert command[command.index('--sampling') + 1] == 'greedy'
                if arm == 'hyle_mtp':
                    assert command[command.index('--mtp-max-drafts') + 1] == '1'
                row.update(image=image, environment=current['runtime_environment'], ready=base.identity(W / 'ready.json'))
            else:
                command[0] = peer['image']['path']
                command[command.index('--output') + 1] = str(folder / 'consumer-result.json')
                row.update(image=peer['image'], environment=peer['runtime_environment'], ready=base.identity(W / 'peer-ready.json'))
            # Prove no workload argument drift beyond the requested MTP auto.
            restored = command.copy()
            restored[0] = original[0]
            if arm.startswith('peer'):
                restored[restored.index('--output') + 1] = original[original.index('--output') + 1]
            elif arm == 'hyle_mtp':
                restored[restored.index('--decode-overlap') + 1] = original[original.index('--decode-overlap') + 1]
            assert restored == original
            assert command[command.index('--capacity') + 1] == '1024'
            assert command[command.index('--mtp') + 1] == ('on' if arm.endswith('_mtp') else 'off')
            if scenario == 'single':
                assert command[command.index('--steps') + 1] == '64'
            else:
                assert '--steps' not in command and command[command.index('--schedule') + 1] == prior['schedule']['path']
            ordinal += 1
            row.update(folder=str(folder), window_ordinal=ordinal)
        assert Counter(row['arm'] for row in group['commands']) == {arm: 3 if mode == 'timing' else 1 for arm in ARMS}
        assert group['memory_interval_seconds'] == 0.01 and not group['profiler'] and not group['warmup']
        group.update(binding=base.identity(W / 'binding.json'), configuration=base.identity(W / 'arms.json'),
            script=base.identity(__file__), canonical_main=current['canonical_main'], retained_plan=base.identity(reference),
            plan_only=True, historical_samples_pooled=False)
        save_new(W / (scenario + '-' + mode + '-plan.json'), group)
        groups.append(dict(scenario=scenario, mode=mode, processes=len(group['commands']),
            plan=base.identity(W / (scenario + '-' + mode + '-plan.json'))))
    assert ordinal == 32
    save_new(W / 'plan.json', dict(status='PREPARED_NOT_RUN_FROZEN_IMAGES', processes=32,
        timing_processes=24, independent_memory_processes=8, groups=groups,
        candidate=image, peer=peer['image'], binding=base.identity(W / 'binding.json'),
        runner=base.identity(__file__), original_endpoints_sampler_parser=True, hyle_overlap='both-auto',
        metrics=base.read(OLD / 'plan.json')['metrics'], historical_samples_pooled=False,
        future_commands=[['python', str(Path(__file__).resolve()), 'run-one', s, m] for s, m in GROUPS],
        summary_command=['python', str(Path(__file__).resolve()), 'summary']))
    print('PREPARED32: candidate versus frozen433e; both Hyle auto; 24timing+8independent memory; zero processes started.')


def parse(folder, arm, configuration):
    observation = legacy.original_parse(folder, arm, configuration)
    raw = base.read(Path(folder) / 'consumer-result.json')
    prefill, decode, session = (raw[k] for k in ('prefill_seconds', 'decode_seconds', 'session_seconds'))
    assert all(isinstance(v, (int, float)) and math.isfinite(v) and v > 0 for v in (prefill, decode, session))
    assert math.isclose(prefill + decode, session, rel_tol=1e-5, abs_tol=2e-6)
    base.save(Path(folder) / 'timing-partition-gate.json', dict(status='PASS', prefill_seconds=prefill,
        decode_seconds=decode, session_seconds=session, tolerance=dict(relative=1e-5, absolute_seconds=2e-6),
        producer_values_unchanged=True))
    if arm.startswith('hyle'):
        assert raw['decode_overlap'] is True and raw['live_committed_versions'] == 0
        assert 0 < raw['overlap_successor_publications'] <= raw['overlap_successor_submissions']
        base.save(Path(folder) / 'relay-evidence.json', legacy.relay_evidence(raw, folder))
    return observation


def analyze(output):
    value = old_analyze(output)
    value['limits'] = [entry for entry in value['limits']
                       if not entry.startswith('Current ordinary-auto performs real relay;')]
    value['limits'].append('Both current Hyle roles request auto and prove actual successor publication; preserve final availability/refusals and natural work. Frozen peer433e is not latest upstream.')
    runs = base.read(Path(output) / 'runs.json')
    value['both_hyle_auto_relay'] = {arm: [legacy.relay_evidence(
        base.read(Path(row['folder']) / 'consumer-result.json'), row['folder'])
        for row in runs if row['arm'] == arm] for arm in ('hyle_auto', 'hyle_mtp')}
    base.save(Path(output) / 'summary.json', value)
    return value


legacy.parse = parse
legacy.analyze = analyze
base.plan = legacy.fixed_plan
base.parse_result = parse
base.analyze = analyze


def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    if action == 'summary':
        legacy.summary()
        return
    assert action in ('run-one', 'resume-one', 'analyze-one')
    scenario, mode = sys.argv[2:]
    assert (scenario, mode) in GROUPS
    protocol.WORKLOAD = scenario
    output = W / (scenario + '-' + mode)
    if action == 'run-one':
        assert base.read(W / 'plan.json')['status'] == 'PREPARED_NOT_RUN_FROZEN_IMAGES'
        assert not output.exists(), 'Preserve every attempt; no automatic rerun'
        os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        value = base.run(W / 'arms.json', mode, output)
    elif action == 'resume-one':
        os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
        value = legacy.resume_one(output, mode)
    else:
        value = analyze(output)
    print(value['status'], value['processes'], flush=True)


if __name__ == '__main__':
    main()
