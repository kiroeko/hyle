"""Read existing window evidence only; stdout is JSON (--json) or an eight-row table."""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent / 'peer-window'
ARMS = ('hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = tuple((s, m) for s in ('single', 'two-turn') for m in ('timing', 'memory'))
ZERO = ('draft_vocabulary_requested_rows', 'draft_vocabulary_rows',
        'draft_vocabulary_weight_bytes', 'draft_vocabulary_map_bytes')
TIME = ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms')


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def non_time(x):
    # Exactly the retained W13 predicate used by the existing complete oracle.
    if isinstance(x, list):
        return [non_time(v) for v in x]
    if isinstance(x, dict):
        return {k: non_time(v) for k, v in x.items() if not any(s in k for s in TIME)}
    return x


def digest(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def changes(a, b, at='$'):
    if type(a) is not type(b):
        return [at]
    if isinstance(a, dict):
        return [p for k in sorted(set(a) | set(b)) for p in
                ([at + '.' + k] if k not in a or k not in b else changes(a[k], b[k], at + '.' + k))]
    if isinstance(a, list):
        return [at] if len(a) != len(b) else [p for i, (x, y) in enumerate(zip(a, b)) for p in changes(x, y, f'{at}[{i}]')]
    return [] if a == b else [at]


def check_modules(folder, process):
    p = folder / 'loaded-modules.json'
    if not p.exists():
        return dict(folder=str(folder), complete=False, errors=['missing module sidecar'])
    x = read(p)
    errors = list(x['errors'])
    rows = x['observed_unique_modules']
    snapshots = x['snapshots']
    ids = {m['id'] for m in rows}
    observed_ids = {i for s in snapshots for i in s['module_ids']}
    if x['pid'] != process['pid'] or x['target_process_exit_observed'] is not True:
        errors.append('PID mismatch or target exit not observed')
    if ids != observed_ids or not rows:
        errors.append('empty/inconsistent module path observations')
    if x['hash_begin_unix_ns'] < process['finished_unix_ns']:
        errors.append('file hashing preceded original execute completion')
    for s in snapshots:
        errors.extend(s['errors'])
    for m in rows:
        f = m.get('post_exit_file')
        if not os.path.isabs(m['observed_absolute_path']):
            errors.append(dict(module=m['id'], error='non-absolute observed path'))
        if not f or not os.path.isabs(f['path']) or not re.fullmatch('[0-9a-f]{64}', f.get('sha256', '')) or f.get('stat_stable_during_hash') is not True:
            errors.append(dict(module=m['id'], error=m.get('post_exit_hash_error', 'missing/unstable post-exit identity')))
    image_seen = any(os.path.normcase(m['observed_absolute_path']) == os.path.normcase(process['image']['path']) for m in rows)
    if not image_seen:
        errors.append('exact process image path not observed')
    return dict(folder=str(folder), pid=x['pid'], snapshots=len(snapshots), unique_paths=len(rows),
        exact_image_path_observed=image_seen, complete=not errors, errors=errors,
        limits='Finite live PSAPI paths plus post-exit disk hashes; neither complete loader tracing nor mapped-byte proof. No rehash substitutes current files for historical identities.')


def check():
    required = [W / 'summary.json', W / 'plan.json'] + [W / (s + '-' + m) / n for s, m in GROUPS for n in ('summary.json', 'runs.json')]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        return dict(status='PENDING_NO_COMPLETE_WINDOW', expected_processes=32, missing=missing)
    final = read(W / 'summary.json')
    errors, modules, table, stability, work = [], [], [], [], []
    summaries, reports, folders = {}, {}, set()
    counts = dict(timing=0, memory=0, hyle_default_vocabulary_checked=0)
    for scenario, mode in GROUPS:
        output = W / (scenario + '-' + mode)
        summary, runs = read(output / 'summary.json'), read(output / 'runs.json')
        summaries[(scenario, mode)] = summary
        expect = 12 if mode == 'timing' else 4
        if len(runs) != expect or summary['processes'] != expect or not summary['within_arm_fixed_work_valid']:
            errors.append(f'{scenario}/{mode}: count or existing complete oracle failed')
        for arm in ARMS:
            selected = [r for r in runs if r['arm'] == arm]
            if len(selected) != (3 if mode == 'timing' else 1):
                errors.append(f'{scenario}/{mode}/{arm}: wrong sample count')
        for run in runs:
            folder = Path(run['folder'])
            if str(folder) in folders or folder.resolve().parent != output.resolve():
                errors.append(f'{folder}: duplicate/outside new window')
            folders.add(str(folder))
            p, raw = read(folder / 'result.json'), read(folder / 'consumer-result.json')
            counts[mode] += 1
            if p != run['process'] or p.get('exit') != 0 or p.get('timeout') or p.get('reader_errors') or not p.get('finished_unix_ns') or p['memory_only'] != (mode == 'memory'):
                errors.append(f'{folder}: process not terminal PASS/exact or wrong mode')
            reports.setdefault((scenario, run['arm']), []).append((mode, folder, raw, run['observation']))
            if run['arm'].startswith('hyle'):
                counts['hyle_default_vocabulary_checked'] += 1
                if any(type(raw.get(k)) is not int or raw[k] != 0 for k in ZERO):
                    errors.append(f'{folder}: full vocabulary zero diagnostic missing/nonzero')
                if raw.get('decode_overlap') is not True or not 0 < raw.get('overlap_successor_publications', 0) <= raw.get('overlap_successor_submissions', 0) or raw.get('live_committed_versions') != 0:
                    errors.append(f'{folder}: missing actual relay or live version invariant')
                if '--mtp-draft-vocabulary' in p['command']:
                    errors.append(f'{folder}: explicit draft vocabulary option present')
            if mode == 'memory':
                modules.append(check_modules(folder, p))
            elif (folder / 'loaded-modules.json').exists():
                errors.append(f'{folder}: timing process has unexpected module observer evidence')
    for scenario in ('single', 'two-turn'):
        for arm in ARMS:
            selected = reports[(scenario, arm)]
            facts = [non_time(r[2]) for r in selected]
            diff = [dict(folder=str(r[1]), changed_paths=changes(facts[0], f)) for r, f in zip(selected[1:], facts[1:]) if f != facts[0]]
            stability.append(dict(scenario=scenario, arm=arm, reports=len(selected), complete_non_time_stable=not diff, first_sha256=digest(facts[0]), differences=diff))
            if diff:
                errors.append(f'{scenario}/{arm}: full non-time facts vary across timing/memory processes')
            raw, observation = selected[0][2:]
            work.append(dict(scenario=scenario, arm=arm, exported_work=observation['work'],
                actual_relay={k: raw[k] for k in raw if k.startswith('overlap_successor_')},
                actual_generated_tokens=raw['generated_tokens'], requested_outputs=raw.get('requested_output_tokens', raw.get('requested_steps')),
                generated_ids_sha256=digest(raw['generated_ids'])))
            timing = summaries[(scenario, 'timing')]['groups'][arm]
            memory = summaries[(scenario, 'memory')]['groups'][arm]
            ready = memory['ready_baseline']
            sample = ready['sample']
            ready_bytes = sample.get('gpu_dedicated_bytes') if sample is not None and not ready['unknown'] else None
            table.append(dict(scenario=scenario, arm=arm,
                prefill_tps=timing['prefill_tokens_per_second']['median'], decode_tps=timing['full_decode_tokens_per_second']['median'],
                session_output_tps=timing['session_output_tokens_per_second']['median'],
                dedicated_peak_bytes=memory['sampled_peaks']['sampled_peak_gpu_dedicated_bytes'],
                ready_dedicated_bytes=ready_bytes, ready_dedicated_unknown=ready_bytes is None))
    if len(folders) != 32 or counts != dict(timing=24, memory=8, hyle_default_vocabulary_checked=16) or final['status'] != 'COMPLETE32_FOUR_ARMS_STABLE':
        errors.append('whole-window status/cardinality mismatch')
    return dict(status='CHECK_FAILED' if errors else 'COMPLETE32_CHECKS_PASS' if all(x['complete'] for x in modules) else 'COMPLETE32_CORE_PASS_MODULE_GAPS',
        counts=counts, errors=errors, table=table, non_time_stability=stability, actual_work=work, memory_modules=modules,
        non_time_exclusions=list(TIME),
        limits=['Timing medians use three fresh processes; independent memory peaks are sampled lower bounds and are not TPS samples.',
            'Ready VRAM remains unknown when the existing real-marker sampler has no valid sample; no peak, logical budget or first sample is substituted.',
            'Actual target/draft/acceptance/relay work and natural output divergence remain explicit; no cross-engine equality, quality, significance or latest-upstream claim.'])


if __name__ == '__main__':
    try:
        value = check()
    except Exception as exc:
        value = dict(status='CHECK_ERROR_PRESERVE_EVIDENCE', error=repr(exc))
    if '--json' in sys.argv:
        print(json.dumps(value, indent=2, ensure_ascii=False))
    else:
        print(value['status'])
        if 'table' in value:
            print('case | arm | prefill tok/s | decode tok/s | session out/s | dedicated peak MiB | ready dedicated')
            for x in value['table']:
                peak = 'unknown' if x['dedicated_peak_bytes'] is None else f"{x['dedicated_peak_bytes']/1048576:.2f}"
                ready = 'unknown' if x['ready_dedicated_unknown'] else f"{x['ready_dedicated_bytes']/1048576:.2f} MiB"
                print(f"{x['scenario']} | {x['arm']} | {x['prefill_tps']:.2f} | {x['decode_tps']:.2f} | {x['session_output_tps']:.2f} | {peak} | {ready}")
            print('processes:', value['counts'], '; core errors:', len(value['errors']), '; module gaps:', sum(not m['complete'] for m in value['memory_modules']))
        else:
            print(json.dumps({k: v for k, v in value.items() if k != 'status'}, ensure_ascii=False))
    raise SystemExit(0 if value['status'] == 'COMPLETE32_CHECKS_PASS' else 2)
