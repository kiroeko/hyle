"""Read-only historical peer provenance checks; no build or model process."""
import difflib, hashlib, io, json, pathlib, re, subprocess, tarfile

R = pathlib.Path(__file__).resolve().parents[2]
W = pathlib.Path(__file__).resolve().parent
H = R / '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'
N = R / '.scratch/legacy-root/hyle-scratch/ggml-native-static'
S = N / 'src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
P = R / '.scratch/qwen-mtp-final-window-20261024/peer-link1'
G = pathlib.Path('C:/public/project-hyle/llama.cpp')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    p=pathlib.Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def check_id(x):
    y=ident(x['path'])
    assert (y['bytes'],y['sha256'])==(x['bytes'],x['sha256']), x['path']
    return y
ready=read(P/'ready.json'); link=read(P/'link-plan.json')
check_id(ready['image'])
inputs=[check_id(x) for x in link['inputs']]
host=read(H/'host-snapshot.json'); commit=host['commit']
archive=subprocess.check_output(['git','-C',str(G),'archive',commit,'--',*host['selected_paths']])
assert hashlib.sha256(archive).hexdigest()==host['archive_sha256']
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
    raw_host={m.name:t.extractfile(m).read() for m in t if m.isfile()}
for x in host['files']:
    p=H/'source'/x['path']; b=p.read_bytes()
    assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'] and b==raw_host[x['path']], str(p)
db=read(N/'compile_commands.json')
prefix='C:/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d/'
names={x['file'][len(prefix):] for x in db if x['file'].startswith(prefix)}
ggml_archive=subprocess.check_output(['git','-C',str(G),'archive',commit,'--','ggml'])
with tarfile.open(fileobj=io.BytesIO(ggml_archive)) as t:
    raw={m.name.removeprefix('ggml/'):t.extractfile(m).read() for m in t if m.isfile()}
tree_changes=[]
for name,a in raw.items():
    b=(S/name).read_bytes()
    if a!=b:
        tree_changes.append(dict(path=name,raw_sha256=hashlib.sha256(a).hexdigest(),retained_sha256=hashlib.sha256(b).hexdigest()))
assert {x['path'] for x in tree_changes}=={'.gitignore','CMakeLists.txt','src/ggml.c','src/ggml-cpu/ggml-cpu.c','src/ggml-cuda/common.cuh','src/ggml-cuda/ggml-cuda.cu'}
changed=[]; patch=[]
for name in sorted(names|{'src/ggml-cuda/common.cuh'}):
    a=raw[name]; b=(S/name).read_bytes()
    if a!=b:
        changed.append(dict(path=name,raw_sha256=hashlib.sha256(a).hexdigest(),retained_sha256=hashlib.sha256(b).hexdigest(),compiled_tu=name in names))
        patch.extend(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='d9e03:ggml/'+name,tofile='retained-source4e1a/'+name))
audit=read(H/'native-reuse-audit.json')
assert changed==audit['changed_sources']
assert len(names)==169
assert ''.join(patch).encode()==(H/'retained-native-resource.patch').read_bytes()
math=read(H/'math-input-identities.json')
for x in math['libraries']: check_id(x)
for x in math['abi_headers']: check_id(x['selected'])
for key in ['compile_database','cmake_cache']: check_id(math[key])
receipt=read(H/'receipt.json')
host_objects=[check_id(x) for x in receipt['current_host_objects'] if pathlib.Path(x['path']).exists()]
missing_objects=[x['path'] for x in receipt['current_host_objects'] if not pathlib.Path(x['path']).exists()]
dumpbin=pathlib.Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe')
deps=subprocess.check_output([str(dumpbin),'/dependents',str(P/'peer.exe')],text=True)
(W/'peer-static-dependents.txt').write_text(deps,encoding='utf-8')
imports=re.findall(r'^\s+([\w.-]+\.dll)\s*$',deps,re.M|re.I)
maptext=(P/'peer.map').read_text(errors='replace')
modules=sorted(set(re.findall(r'\s([^\s]+:[^\s]+\.obj)\s*$',maptext,re.M)))
assert not any('hyle_' in x.lower() for x in modules)
owners={name:sum(x.startswith(name+':') for x in modules) for name in ['llama','ggml','ggml-base','ggml-cpu','ggml-cuda','cudart']}
out=dict(status='PASS_HISTORICAL_CORE_IDENTIFIED_RUNTIME_LOAD_HASHES_UNKNOWN',image=ready['image'],llama_host_commit=commit,
         ggml_raw_pin=host['ggml_pin'],source_archive_sha256=host['archive_sha256'],host_snapshot_files_verified=len(host['files']),
         full_ggml_tree_files_verified=len(raw),full_ggml_tree_changes=tree_changes,
         native_tus_verified=len(names),native_unmodified_tus=len(names)-3,changed_sources=changed,resource_patch=ident(H/'retained-native-resource.patch'),
         link_inputs_verified=inputs,abi_headers_verified=len(math['abi_headers']),host_object_receipts_rehashed=len(host_objects),missing_historical_objects=missing_objects,
         archive_owners=owners,static_imports=imports,actual_loaded_vendor_dll_paths_and_hashes='unknown: historical peer-ready/runtime records pin environment, not PSAPI loaded-module images',
         source_current_checkout_head_not_binary_version=subprocess.check_output(['git','-C',str(G),'rev-parse','HEAD'],text=True).strip(),
         scope='Independent source/archive/library/receipt readback plus PE/map inspection. No compile, link, inference, version execution, profiler, or download.')
(W/'peer-provenance.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:out[k] for k in ['status','llama_host_commit','ggml_raw_pin','host_snapshot_files_verified','native_tus_verified','native_unmodified_tus','host_object_receipts_rehashed','archive_owners','missing_historical_objects']},indent=2))
