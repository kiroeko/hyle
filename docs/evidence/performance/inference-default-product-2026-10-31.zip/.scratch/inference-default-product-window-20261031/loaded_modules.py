"""Low-frequency per-PID PSAPI module observations for independent memory runs."""
import ctypes
from ctypes import wintypes as wt
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time

K = ctypes.WinDLL('kernel32', use_last_error=True)
P = ctypes.WinDLL('psapi', use_last_error=True)
K.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
K.OpenProcess.restype = wt.HANDLE
K.CloseHandle.argtypes = [wt.HANDLE]
K.CloseHandle.restype = wt.BOOL
K.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
K.WaitForSingleObject.restype = wt.DWORD
P.EnumProcessModulesEx.argtypes = [wt.HANDLE, ctypes.POINTER(wt.HMODULE), wt.DWORD, ctypes.POINTER(wt.DWORD), wt.DWORD]
P.EnumProcessModulesEx.restype = wt.BOOL
P.GetModuleFileNameExW.argtypes = [wt.HANDLE, wt.HMODULE, wt.LPWSTR, wt.DWORD]
P.GetModuleFileNameExW.restype = wt.DWORD


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


class Capture:
    def __init__(self, interval=0.25):
        self.interval = interval
        self.stop_event = threading.Event()
        self.thread = None
        self.handle = None
        self.pid = None
        self.snapshots = []
        self.modules = {}
        self.errors = []
        self.exited_at_stop = None

    def start(self, pid):
        self.pid = int(pid)
        # Only the known target PID; no system-wide enumeration or GPU API.
        self.handle = K.OpenProcess(0x400 | 0x10 | 0x100000, False, self.pid)
        if not self.handle:
            self.errors.append(dict(api='OpenProcess', winerror=ctypes.get_last_error(), unix_ns=time.time_ns()))
            return
        self.thread = threading.Thread(target=self._loop, name='loaded-module-paths', daemon=True)
        self.thread.start()

    def _snapshot(self):
        row = dict(begin_perf_ns=time.perf_counter_ns(), begin_unix_ns=time.time_ns(), module_ids=[], errors=[])
        items = (wt.HMODULE * 4096)()
        needed = wt.DWORD()
        if not P.EnumProcessModulesEx(self.handle, items, ctypes.sizeof(items), ctypes.byref(needed), 3):
            row['errors'].append(dict(api='EnumProcessModulesEx', winerror=ctypes.get_last_error()))
        elif needed.value > ctypes.sizeof(items):
            row['errors'].append(dict(api='EnumProcessModulesEx', error='fixed buffer exhausted; no partial enumeration claimed', required_bytes=needed.value))
        else:
            for item in items[:needed.value // ctypes.sizeof(wt.HMODULE)]:
                buf = ctypes.create_unicode_buffer(32768)
                n = P.GetModuleFileNameExW(self.handle, item, buf, len(buf))
                if not n or n >= len(buf) - 1:
                    row['errors'].append(dict(api='GetModuleFileNameExW', winerror=ctypes.get_last_error(), path_truncated=bool(n)))
                    continue
                path = buf.value
                if not os.path.isabs(path):
                    row['errors'].append(dict(api='GetModuleFileNameExW', error='non-absolute path', path=path))
                    continue
                key = os.path.normcase(path)
                item = self.modules.setdefault(key, dict(id=len(self.modules), observed_absolute_path=path,
                    first_snapshot=len(self.snapshots), last_snapshot=len(self.snapshots)))
                item['last_snapshot'] = len(self.snapshots)
                row['module_ids'].append(item['id'])
        row['end_perf_ns'] = time.perf_counter_ns()
        self.snapshots.append(row)

    def _loop(self):
        try:
            while not self.stop_event.is_set():
                if K.WaitForSingleObject(self.handle, 0) == 0:
                    break
                self._snapshot()
                self.stop_event.wait(self.interval)
        except Exception as exc:
            self.errors.append(dict(api='module-observer-thread', error=repr(exc), unix_ns=time.time_ns()))

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join()
            self.thread = None
        if self.handle:
            self.exited_at_stop = K.WaitForSingleObject(self.handle, 0) == 0
            K.CloseHandle(self.handle)
            self.handle = None

    def result(self, hash_files=True):
        self.stop()
        rows = sorted(self.modules.values(), key=lambda x: x['id'])
        hash_start = time.time_ns()
        if hash_files and self.exited_at_stop is True:
            for row in rows:
                path = Path(row['observed_absolute_path'])
                try:
                    before = path.stat()
                    with path.open('rb') as stream:
                        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                    after = path.stat()
                    row['post_exit_file'] = dict(path=str(path.resolve()), bytes=after.st_size, sha256=digest,
                        stat_stable_during_hash=(before.st_size, before.st_mtime_ns)==(after.st_size, after.st_mtime_ns),
                        mtime_ns=after.st_mtime_ns)
                except Exception as exc:
                    row['post_exit_hash_error'] = repr(exc)
        elif hash_files:
            self.errors.append(dict(error='Process exit not observed; post-exit hashing not performed'))
        return dict(schema='hyle.windows.loaded-modules.memory-sidecar.v1', pid=self.pid,
            interval_seconds=self.interval, target_process_exit_observed=self.exited_at_stop,
            snapshots=self.snapshots, observed_unique_modules=rows, errors=self.errors,
            hash_begin_unix_ns=hash_start, hash_end_unix_ns=time.time_ns(), hash_files_requested=hash_files,
            throughput_evidence=False, ready_vram_inferred=False,
            limits=['Finite per-PID PSAPI snapshots, not a complete loader-event trace; short-lived modules may be missed.',
                'Paths are actually returned by the target process module API; imports/PATH/current disk files are not substituted.',
                'Post-exit hashes identify those observed paths at hash time, not a dump or proof of mapped bytes at load time.',
                'Independent memory runs have additional 250ms-requested module observation overhead; no timing-process denominator uses them.',
                'No memory-sampler/reducer math, producer markers, ready marker, GPU synchronization or tensor access is added.'])


def install(runner):
    original_execute = runner.execute
    original_load_probe = runner.load_probe

    def execute(folder, arm, command, environment, memory):
        if not memory:
            return original_execute(folder, arm, command, environment, memory)
        capture = Capture()
        original_probe = original_load_probe()

        class Probe(original_probe):
            def start(self, pid):
                result = super().start(pid)
                capture.start(pid)
                return result

        runner.load_probe = lambda: Probe
        try:
            return original_execute(folder, arm, command, environment, memory)
        finally:
            runner.load_probe = original_load_probe
            # Original execute has already waited, stopped its sampler and written
            # its timings before any file hashing or sidecar serialization here.
            value = capture.result()
            if Path(folder).is_dir():
                write_new(Path(folder) / 'loaded-modules.json', value)
    runner.execute = execute
    return runner


if __name__ == '__main__':
    assert sys.argv[1:] == ['self-check']
    capture = Capture()
    capture.start(os.getpid())
    time.sleep(0.3)
    result = capture.result(hash_files=False)
    paths = {os.path.normcase(x['observed_absolute_path']) for x in result['observed_unique_modules']}
    assert os.path.normcase(str(Path(sys.executable).resolve())) in paths
    assert len(result['snapshots']) >= 1 and not result['errors']
    result.update(status='PASS_SELF_PYTHON_PID_ONLY', model_processes_started=0, GPU_calls=0)
    write_new(Path(__file__).parent / 'module-observer-self-check.json', result)
    print(json.dumps(dict(status=result['status'], snapshots=len(result['snapshots']), unique_modules=len(paths), model_processes_started=0)))
