"""Seal existing normal-product default-full-V evidence; no build/model/API calls."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-default-product-build-20261031'
D = W / 'peer-window'
P = R / '.scratch/qwen-mtp-final-window-20261024/peer-link1'
H = R / '.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'
OUT = R / 'docs/evidence/performance/inference-default-product-2026-10-31.json'
ZIP = OUT.with_suffix('.zip')
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p)
    with p.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=p.resolve().relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=sha)


def save_new(p, x):
    with Path(p).open('x', encoding='utf-8') as stream:
        json.dump(x, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')


assert not OUT.exists() and not ZIP.exists()
ready = read(W / 'normal-product-ready.json')
check = read(W / 'completed-window-check.json')
summary = read(D / 'summary.json')
assert summary['status'] == 'COMPLETE32_FOUR_ARMS_STABLE'
assert check['status'] == 'COMPLETE32_CORE_PASS_MODULE_GAPS' and not check['errors']
assert check['counts'] == dict(timing=24, memory=8, hyle_default_vocabulary_checked=16)
assert all(x['complete_non_time_stable'] and x['reports'] == 4 for x in check['non_time_stability'])
assert sum(not x['complete'] for x in check['memory_modules']) == 2
assert all(x['first_differing_output_1based'] == 19 for x in summary['cross_engine_work'])
sources = []
for x in ready['source_pins']:
    actual = pin(x['path'])
    assert (actual['bytes'], actual['sha256']) == (x['bytes'], x['sha256'])
    sources.append(actual)
assert len(sources) == 18
table, comparisons, processes = [], [], []
for scenario in ('single', 'two-turn'):
    timing = read(D / (scenario + '-timing') / 'summary.json')
    memory = read(D / (scenario + '-memory') / 'summary.json')
    for arm in ('hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp'):
        t, m = timing['groups'][arm], memory['groups'][arm]
        c = next(x for x in check['table'] if x['scenario'] == scenario and x['arm'] == arm)
        assert c['decode_tps'] == t['full_decode_tokens_per_second']['median']
        assert c['ready_dedicated_unknown'] and c['ready_dedicated_bytes'] is None
        table.append(dict(scenario=scenario, arm=arm,
            prefill_tokens_per_second=t['prefill_tokens_per_second'],
            full_decode_tokens_per_second=t['full_decode_tokens_per_second'],
            session_output_tokens_per_second=t['session_output_tokens_per_second'],
            prefill_seconds=t['prefill_seconds'], decode_seconds=t['decode_seconds'], session_seconds=t['session_seconds'],
            independent_memory=dict(sampled_peaks=m['sampled_peaks'], ready_baseline=m['ready_baseline'],
                sample_count=m['sample_count'], sample_gaps_ms=m['actual_sample_gaps_ms'],
                setup_error=m['setup_error'], thread_error=m['thread_error'], lower_bound=True)))
    for role, left, right in (('ordinary', 'hyle_auto', 'peer_plain'), ('MTP', 'hyle_mtp', 'peer_mtp')):
        comparisons.append(dict(scenario=scenario, role=role, hyle=left, peer=right,
            median_relative_percent={k: 100 * (timing['groups'][left][k]['median'] / timing['groups'][right][k]['median'] - 1)
                for k in ('prefill_tokens_per_second', 'full_decode_tokens_per_second', 'session_output_tokens_per_second')}))
    for mode in ('timing', 'memory'):
        for row in read(D / (scenario + '-' + mode) / 'runs.json'):
            p = Path(row['folder']) / 'result.json'
            value = read(p)
            assert value['exit'] == 0 and value['finished_unix_ns'] and not value.get('timeout') and not value['reader_errors']
            processes.append(dict(scenario=scenario, mode=mode, arm=row['arm'], pid=value['pid'], exit=0,
                started_unix_ns=value['started_unix_ns'], finished_unix_ns=value['finished_unix_ns'], result=pin(p)))
assert len(processes) == 32
body = dict(schema='hyle.performance.normal-default-product-window.v1', status=check['status'],
    workload=dict(prompt_ids=154, output_tokens_per_turn=64, turns=[1, 2], capacity=1024,
        backend='cuda', sampling='greedy', Hyle_decode_overlap='auto', MTP_max_drafts=1,
        draft_vocabulary='default full vocabulary; no explicit subset', model_identity='4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe',
        counts=dict(timing=24, independent_memory=8, total=32), timing_samples_per_arm_scenario=3,
        independent_memory_samples_per_arm_scenario=1, retries=0, profile=False),
    normal_product=dict(ready=pin(W / 'normal-product-ready.json'), image=ready['image'],
        build=read(Path(ready['build']['path'])), configuration=read(B / 'verification-summary.json')['configuration'],
        source_pins=sources, loaded_runtime=pin(B / 'loaded-runtime.json'), smoke=pin(B / 'smoke-summary.json'),
        source_patch=pin(B / 'build-attempt2-product.diff'), shared_export_source_change=pin(B / 'shared-export-fix/source-change.json'),
        build_history=read(B / 'verification-summary.json')['build_attempts'],
        shared_correctness_reference='docs/evidence/correctness/inference-shared-graph-batch-2026-10-31.json'),
    peer=dict(image=read(P / 'ready.json')['image'], llama_host_commit='d9e03f1074dbd2979126d91dce1b5d304ec8394e',
        ggml_raw_pin='456172ec733a135778adcd32d00e576a58232e45', patched=True, latest_upstream=False,
        provenance=pin(W / 'peer-provenance.json'), note='Frozen custom matched-input consumer; resource-patched GGML plus build/gitignore changes. Historical loaded-vendor-DLL identities unknown; this new window has finite actual module-path snapshots and post-exit file hashes.'),
    endpoints=dict(prefill='Original producer prefill interval; protocol prefill_tokens_per_second.',
        decode='Original protocol full_decode_tokens_per_second median; first prefill output excluded from decode numerator as in retained protocol.',
        session='Original complete natural session interval; session_output_tokens_per_second.',
        fields='Metric names and raw seconds remain distinct; no instrumented timing or submit-only endpoint.'),
    table=table, relative_medians=comparisons, processes=processes,
    correctness=dict(all_32_terminal_exit0=True, Hyle_default_vocabulary_four_fields_int0=16,
        complete_non_time_stability=check['non_time_stability'], non_time_exclusions=check['non_time_exclusions'],
        actual_work=check['actual_work'], cross_engine_output_divergence=[{k: x[k] for k in
            ('scenario', 'role', 'common_output_prefix', 'first_differing_output_1based')} for x in summary['cross_engine_work']],
        note='Full original reports and all generated IDs retained; natural output divergence precludes equal-continuation/quality equivalence claims.'),
    memory=dict(ready_unknown_all_8=True, sampled_peaks_are_lower_bounds=True,
        module_sidecars=check['memory_modules'], partial_module_snapshots=2,
        note='Two retained EnumProcessModulesEx error299 observations. Other snapshots and post-exit hashes retained; not complete loader tracing or mapped-byte proof. No import/PATH/current-file substitution.'),
    hardware=read(B / 'hardware-toolchain.json'),
    history=dict(native_failures=0, producer_parser_failures=0, auto_retries=0,
        preparation='Normal build retained one vcvars preparation failure and first shared Graph_batch C2375; corrected source/export evidence belongs to referenced shared correctness package.',
        check_nonzero='Completion checker returns nonzero for the two module observation gaps; all core/native checks pass.',
        transcription='One informal message misstated the two-turn MTP decimals; checker and protocol summary were identical and remain unchanged.'),
    limits=['One Windows RTX4070, BF16 Qwen3.5-2B cached input, one/two natural turns. No all-model/all-device claim.',
        'Three timing samples per arm/scenario; no statistical significance or stable/general performance claim.',
        'Memory-only processes include low-frequency module enumeration; they are excluded from every throughput statistic.',
        'All ready VRAM values remain unknown. Sampled dedicated/shared/total peaks are distinct lower bounds; no budget or first sample substitutes ready memory.',
        'Frozen peer is identified historical d9e+patched456172, not latest upstream. Cross-engine outputs first differ at token19 and actual rows/acceptance differ.',
        'No new optimization, full-goal completion, download, reference build, profile or additional model run in evidence sealing.'])
save_new(W / 'summary-draft.json', body)
files = set()


def add(p):
    p = Path(p).resolve()
    assert p.is_relative_to(R)
    assert p.is_file(), str(p)
    assert p.suffix.lower() not in ('.dll', '.exe', '.lib', '.obj', '.pdb', '.sqlite', '.gguf', '.bin', '.safetensors')
    files.add(p)


for p in D.rglob('*'):
    if p.is_file() and p.name != 'observation.json':
        add(p)  # runs.json already retains each complete observation; no duplicate per-run copy needed.
for name in ('normal-product-ready.json', 'completed-window-check.json', 'summary-draft.json',
             'window.py', 'loaded_modules.py', 'check-completed-window.py', 'publish-evidence.py',
             'module-observer-proof.json', 'module-observer-self-check.json', 'window-before-module-sidecar.py',
             'check-peer-provenance.py', 'peer-provenance.json', 'peer-provenance.md', 'peer-static-dependents.txt'):
    add(W / name)
for name in ('prepared.json', 'environment.json', 'hardware-toolchain.json', 'loaded-runtime.json',
             'smoke-summary.json', 'verification-summary.json', 'source-freeze-build-attempt2.json',
             'build-attempt2-product.diff', 'preparation-attempt1-failure.json', 'shared-export-fix/source-change.json',
             'shared-export-fix/batch.h.before', 'configure/attempt1/CMakeCache.txt'):
    add(B / name)
for attempt in ('attempt1', 'attempt2'):
    for name in ('command.json', 'process.json', 'result.json'):
        if (B / 'build' / attempt / name).is_file():
            add(B / 'build' / attempt / name)
for case in ('help', 'tiny-cpu-ordinary', 'tiny-cuda-mtp-k1'):
    for p in (B / 'checks' / case / 'attempt1').iterdir():
        if p.is_file(): add(p)
for x in ready['source_pins']: add(x['path'])
for p in (P / 'ready.json', P / 'link-plan.json', P / 'link.result.json', P / 'runtime-environment.json',
          R / '.scratch/qwen-mtp-final-window-20261024/compile1/peer/identity.json',
          R / '.scratch/qwen-mtp-final-window-20261024/source/peer_multiturn.cc',
          H / 'host-snapshot.json', H / 'math-input-identities.json', H / 'native-reuse-audit.json',
          H / 'retained-native-resource.patch', H / 'receipt.json', H / 'commands.json', H / 'build/CMakeCache.txt'):
    add(p)
for name in ('.scratch/inference-small-projection-20261028/current-peer-window/window.py',
             '.scratch/mtp-performance-convergence-20261025/baseline/window.py', '.scratch/qwen-mtp-window-20261022/window.py',
             '.scratch/qwen-mtp-final-window-20261024/turns.py', '.scratch/qwen-mtp-quality-20261022/current-window/performance.py',
             '.scratch/inference-current-review-profile-20261027/analyze.py', '.scratch/shared-execution-20261021/observer.py',
             '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multiturn/multiturn_run.py',
             '.scratch/architecture-refactor-2026-10-18/qwen-gpu-comparison/memory-probe/memory_probe.py',
             '.scratch/qwen-mtp-window-20261022/inputs/prompt.ids', '.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt',
             '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'):
    add(R / name)
manifest = [pin(p) for p in sorted(files)]
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files): z.write(p, p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(ZIP) as z:
    assert len(z.namelist()) == len(manifest) + 1 and len(set(z.namelist())) == len(z.namelist())
    for x in manifest:
        b = z.read(x['path'])
        assert len(b) == x['bytes'] and hashlib.sha256(b).hexdigest() == x['sha256'] and b == (R / x['path']).read_bytes()
body['archive'] = dict(**pin(ZIP), members=len(manifest) + 1, full_readback_and_source_bytes=True)
save_new(OUT, body)
save_new(W / 'archive-receipt.json', body['archive'])
print(json.dumps(dict(summary=pin(OUT), archive=body['archive'])))
