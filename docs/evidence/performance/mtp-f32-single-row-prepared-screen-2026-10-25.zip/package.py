from pathlib import Path
import hashlib
import json
import re
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]


def read(p):
    return json.loads(p.read_text())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n")


def pin(p):
    return {"path": p.relative_to(R).as_posix(), "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


baseline = R / ".scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp"
old_lines = (baseline / "stderr.log").read_text().splitlines()
candidate_lines = (W / "run-app/stderr.log").read_text().splitlines()
norm = lambda line: re.sub(r"\s*\b\w*seconds=\S+", "", line)
screen = read(W / "screen/summary.json")
runs = read(W / "screen/runs.json")
assert len(runs) == 8 and screen["timing_processes"] == 6 and screen["independent_memory_processes"] == 2
capture = []
for record in runs:
    folder = R / record["folder"]
    lines = (folder / "stderr.log").read_text().splitlines()
    reference = old_lines if record["arm"] == "control" else candidate_lines
    assert list(map(norm, lines)) == list(map(norm, reference)), record["folder"]
    prepared = [dict(re.findall(r"(\w+)=([^ ]+)", line)) for line in lines if line.startswith("prepared ")]
    totals = {"recorded": sum(int(x["capture_recorded"]) for x in prepared),
              "reused": sum(int(x["capture_reused"]) for x in prepared)}
    assert totals == ({"recorded": 32, "reused": 100} if record["arm"] == "control" else {"recorded": 21, "reused": 45})
    capture.append({"folder": record["folder"], "arm": record["arm"], "mode": record["mode"],
                    "exit": record["exit"], "stderr_non_time_equal_to_own_reference": True, **totals})
save(W / "screen/capture-comparison.json", capture)
summary = read(W / "proof-summary.json")
summary["status"] = "CLOSED_NOT_MERGED_BOUNDED_DECODE_SCREEN_NEGATIVE"
summary["screen"] = pin(W / "screen/summary.json")
summary["screen_samples"] = pin(W / "screen/runs.json")
summary["screen_capture"] = pin(W / "screen/capture-comparison.json")
summary["decision"] = {
    "recommendation": "CLOSE_NOT_MERGED; stop repeating and do not start a formal comparison window",
    "decode_relative_percent": screen["comparisons"]["decode_output_tokens_per_second"]["candidate_relative_percent"],
    "combined_relative_percent": screen["comparisons"]["combined_output_tokens_per_second"]["candidate_relative_percent"],
    "prefill_relative_percent": screen["comparisons"]["prefill_tokens_per_second"]["candidate_relative_percent"],
    "decode_ranges_overlap": screen["comparisons"]["decode_output_tokens_per_second"]["ranges_overlap"],
    "combined_ranges_overlap": screen["comparisons"]["combined_output_tokens_per_second"]["ranges_overlap"],
    "reason": "Numerics/capture behavior passed, but the same-work original real-two-turn decode and combined medians regressed in this finite screen; fewer ranges/kernels and the positive prefill observation do not establish useful decode benefit.",
    "limits": "Only three observations per timing arm and one independent memory process per arm, not statistical significance or a latest peer comparison. Native launch/API costs and the cause of the negative result were not profiled. No additional sampling warranted by this screen."}
summary["analysis_corrections"] = [
    "Initial message incorrectly inferred recorded32->16/reused100->50 from two ranges becoming one. Actual per-line totals are32/100->21/45: ten episodes formerly recorded only one constituent while reusing the other; merged capture rerecords the whole range.",
    "First offline source preparer assumed CRLF and stopped before compilation; corrected to preserve actual LF/CRLF. This is a private preparation issue, not a product failure.",
    "First capture-test compile failed on private runtime size_t extent narrowing; source/log preserved, explicit I64 extent conversion fixed it without changing product code."]
save(W / "proof-summary.json", summary)
extensions = {".json", ".log", ".xml", ".py", ".d", ".patch", ".cc", ".cu", ".h"}
files = sorted(p for p in W.rglob("*") if p.is_file() and p.suffix.lower() in extensions)
# The retained baseline reference is an actual existing run; no rerun or source-body copy.
extras = [baseline / name for name in ("command.json", "result.json", "stdout.log", "stderr.log")]
archive = W / "proof.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files:
        z.write(p, p.relative_to(W).as_posix())
    for p in extras:
        z.write(p, "original-baseline/" + p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(Path(n).suffix.lower() in {".obj", ".exe", ".lib", ".exp", ".dll", ".pdb"} for n in z.namelist())
    result = {"archive": pin(archive), "entries": len(z.namelist()),
              "summary": pin(W / "proof-summary.json"), "zip_crc_pass": True,
              "no_binary_sdk_or_weights": True, "gpu_released": True}
save(W / "package.json", result)
print(json.dumps(result))
