"""Offline source/joint-key review only; never compiles or starts CUDA work."""
from pathlib import Path
from collections import Counter, defaultdict
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def pin(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


relative = Path("src/compute_provider_cuda/collectives.cu")
source = ROOT / relative
before = source.read_bytes()
needle = b"if (rows > 1 && program.width > kArgTileItems) {"
newline = b"\r\n" if b"\r\n" in before else b"\n"
replacement = (b"if ((rows > 1 || std::is_same_v<T, float>) &&" + newline +
               b"        program.width > kArgTileItems) {")
assert before.count(needle) == 1
after = before.replace(needle, replacement)
for base, content in (("before", before), ("source", after)):
    destination = OUT / base / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(content)
patch = "".join(difflib.unified_diff(
    before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
    fromfile="a/" + relative.as_posix(), tofile="b/" + relative.as_posix()))
(OUT / "source.patch").write_bytes(patch.encode())

event_path = ROOT / ".scratch/mtp-capture-seed-20261025/events.json"
events = json.loads(event_path.read_text())["events"]
keys = {}
epochs = defaultdict(int)
calls = defaultdict(dict)
for event in events:
    invocation = event["inv"]
    key = (invocation, event["begin"], event["count"], event["selected"])
    if event["kind"] == 1 and any(event[x] for x in ("keys", "commands", "storage", "live")):
        epochs[invocation] += 1
    if event["kind"] == 31:
        keys[key] = event["i"]
    if event["kind"] not in (11, 31):
        continue
    role = "target" if event["count"] == 1269 else (
        "draft" if event["count"] in (53, 55) else None)
    if role is not None:
        calls[event["seq"]][role] = {
            "record_token": keys.get(key), "slot": event["selected"],
            "invocation": invocation, "epoch": epochs[invocation]}
windows = []
for start, end in ((17, 35), (46, 68)):
    rows = []
    for sequence, roles in sorted(calls.items()):
        if start <= sequence <= end and roles.keys() == {"draft", "target"}:
            draft, target = roles["draft"], roles["target"]
            assert draft["invocation"] == target["invocation"]
            assert draft["epoch"] == target["epoch"]
            assert draft["record_token"] is not None and target["record_token"] is not None
            rows.append({"sequence": sequence,
                         "invocation": draft["invocation"], "epoch": draft["epoch"],
                         "joint_record_tokens": [draft["record_token"], target["record_token"]],
                         "slots": [draft["slot"], target["slot"]]})
    windows.append({"sequence_bounds": [start, end], "paired_calls": len(rows),
                    "joint_keys": len({tuple(x["joint_record_tokens"]) for x in rows}),
                    "slot_pairs": dict(Counter(str(x["slots"]) for x in rows)),
                    "calls": rows})
save("joint-keys.json", {
    "status": "EXISTING_DATA_ONLY", "events": pin(event_path), "windows": windows,
    "identity_scope": "record tokens, invocation IDs and slots are local to this one original process",
    "limit": "Two stable observed windows each need two joint keys. This is not a proof of all future merged bindings, workspace addresses, layouts or models."})

native_recipe = ROOT / ".scratch/qwen-batch-profile-20261022/compile3/native/identity.json"
native = json.loads(native_recipe.read_text())
assert native["source"]["sha256"] == hashlib.sha256(before).hexdigest()
save("plan.json", {
    "status": "PRIVATE_SOURCE_AND_PLAN_ONLY_NOT_COMPILED_NOT_RUN",
    "source_before": pin(source), "source_candidate": pin(OUT / "source" / relative),
    "patch": pin(OUT / "source.patch"), "native_recipe": pin(native_recipe),
    "original_native_object": pin(Path(native["object"]["path"])),
    "scope": "Only wide F32 single ordered-row TopK1 changes to the existing two-stage prepared tile path. Existing multi-row path and every non-F32 single-row path remain unchanged.",
    "unchanged": ["F32 input/value output and I32 index output", "ArgBest comparator", "both existing fixed kernels", "original-value reread", "Provider ABI and Program layout", "capture/owner/variant qualification", "head precision, scores, acceptance and Model math"],
    "source_contract": {
        "order": "numeric values beat NaN for both largest/smallest; unequal numerics use requested direction; ties including signed zero, equal infinities and all NaNs choose smallest original index",
        "associativity": "ArgBest selects one extremum under that index-completed order; chunking changes no arithmetic reduction or sort meaning",
        "bits": "arg_finish rereads original T bytes after choosing the index, so comparison NaN quieting cannot rewrite the published payload/sign",
        "tail": "arg_tiles bounds each loop by min(first+2048,width); INT32_MAX is the identity and cannot beat any valid index; every configured tile has at least one input",
        "layout": "dense inner1 uses original byte loads; otherwise existing Layout.read maps original logical axis/strides; rows1 implies all non-axis extents have product1",
        "workspace": "ceil(width/2048)*sizeof(ArgPair<float>), 256-byte rounded once in configure; vocabulary248320 gives122 partials/976 bytes rounded1024; caller Invocation owns it",
        "capture": "collectives_provider runtime and capture-binding inspector already derive prepared/capturable status from arg_tiles; no provider change required"
    },
    "bounded_checks_after_parent_gpu_grant": [
        {"stage": "build", "work": "Compile only private collectives.cu using original nvcc13.3 sm89 recipe. Reuse unchanged host collectives_provider object and retained native-seed Graph closure; no SDK rebuild."},
        {"stage": "numeric", "work": "One original collectives_test.cc host TU; run SingleRowTopOneDenseAndGenericLayoutsKeepStableOriginalBits and VocabularyBfloatTopOneMatchesCastFloatAcrossBlocks. Private test-only delta adds F32 wide8193 padded/zero-stride cases and an all-signaling-NaN payload pattern; preserve original stable_sort oracle and byte comparisons. Existing width8193 and vocabulary248320 cover partial tail tiles."},
        {"stage": "capture", "work": "One original topk_test.cc host TU; parameterize existing WideTopOnePreparedCaptureKeepsInvocationWorkspaceIsolated over rows1/3. Retain two queues, two Invocation workspaces, old lane output, require-capture and zero rerecord on replay. In OtherTopKProgramsKeepManagedReplayContract replace the newly-supported F32 row1 width8193 case with row1 width2048; keep small-row and K>1 negative cases. No new test framework."},
        {"stage": "application", "work": "After numeric/capture pass, one original clean K1 real two-turn process, same app/report/argv/runtime/weights and native-seed Graph objects. Compare every original non-time ID/work/ledger/RNG/report field; inspect existing record/reuse range counts. No peer, TPS window or profiler."}
    ],
    "falsification": ["Any index/value-bit/oracle/canary mismatch closes or fixes only a demonstrated defect before app work", "Any capture/workspace lifetime failure stops app run", "A merged route requiring more keys or repeated recording is not excused by these existing two-key observations", "No performance benefit is claimed from kernel/API counts or private diagnostic walltime"],
    "known_test_expectation_change": "tests/graph_route_cuda/topk_test.cc:389 explicitly expects F32 row1 width8193 to be managed; that case must be changed in the private test before running, never mislabeled as a product regression",
    "references": [pin(ROOT / "src/compute_provider_cuda/collectives_provider.cc"), pin(ROOT / "tests/compute_provider_cuda/collectives_test.cc"), pin(ROOT / "tests/compute_provider_cuda/collectives_test_support.h"), pin(ROOT / "tests/graph_route_cuda/topk_test.cc")],
    "no_new_gpu_process": True, "no_compile": True, "no_http": True,
})
print(json.dumps({"plan": str(OUT / "plan.json"), "candidate": pin(OUT / "source" / relative),
                  "windows": [{k: w[k] for k in ("sequence_bounds", "paired_calls", "joint_keys", "slot_pairs")} for w in windows]}))
