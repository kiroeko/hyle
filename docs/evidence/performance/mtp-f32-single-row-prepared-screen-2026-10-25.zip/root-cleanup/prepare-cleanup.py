from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'test.ps1'
text = path.read_text('utf-8-sig')
flag = 'RemoveClosedF32TopOneBinaries'
assert flag not in text
start = text.index('if ($RemoveMtpNativeSupersededBinaries) {')
end = text.index('\nif ($RemovePublishedMlxOrdinaryBinaries)', start)
block = text[start:end]
replacements = {
    'RemoveMtpNativeSupersededBinaries': flag,
    'nativeTask': 'f32TopOneTask',
    'MTP native superseded': 'closed F32 TopK1',
    '.scratch/mtp-native-seed-candidate-20261025': '.scratch/mtp-single-row-prepared-20261025',
    '$f32TopOneTaskPlan.deletion_executed': '$f32TopOneTaskPlan.deletion_executed',
    '.files.Count -ne 10': '.files.Count -ne 11',
    '305729649L': '303158869L',
    'docs/evidence/performance/mtp-native-rebuild-seed-2026-10-25.json':
        'docs/evidence/performance/mtp-f32-single-row-prepared-screen-2026-10-25.json',
}
for old, new in replacements.items():
    block = block.replace(old, new)
text = text.replace('[switch]$RemoveMtpNativeSupersededBinaries)',
                    '[switch]$RemoveMtpNativeSupersededBinaries, [switch]$' + flag + ')', 1)
insertion = text.index('\nif ($RemoveMtpNativeSupersededBinaries)')
text = text[:insertion] + '\n' + block + text[insertion:]
with path.open('w', encoding='utf-8', newline='') as output:
    output.write(text.replace('\r\n', '\n').replace('\n', '\r\n'))
print('Prepared exact 11-file closed-candidate cleanup in test.ps1; no deletion executed.')
