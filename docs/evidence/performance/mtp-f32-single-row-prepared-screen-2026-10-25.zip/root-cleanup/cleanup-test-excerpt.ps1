param([switch]$Apply, [switch]$RemoveClosedF32TopOneBinaries)
if ($RemoveClosedF32TopOneBinaries) {
  $ErrorActionPreference = 'Stop'
  $f32TopOneTaskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
  if ($f32TopOneTaskRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected closed F32 TopK1 workspace' }
  $f32TopOneTaskBase = [IO.Path]::GetFullPath((Join-Path $f32TopOneTaskRoot '.scratch/mtp-single-row-prepared-20261025'))
  $f32TopOneTaskPlan = Get-Content -LiteralPath (Join-Path $f32TopOneTaskBase 'cleanup-candidates.json') -Raw | ConvertFrom-Json
  $f32TopOneTaskReceipt = Join-Path $f32TopOneTaskBase 'cleanup-removed.json'
  if ((Test-Path -LiteralPath $f32TopOneTaskReceipt) -or $f32TopOneTaskPlan.deletion_executed -or $f32TopOneTaskPlan.files.Count -ne 11 -or $f32TopOneTaskPlan.logical_bytes -ne 303158869L) { throw 'closed F32 TopK1 cleanup inventory changed/already executed' }
  $f32TopOneTaskProof = Get-Content -LiteralPath (Join-Path $f32TopOneTaskRoot 'docs/evidence/performance/mtp-f32-single-row-prepared-screen-2026-10-25.json') -Raw | ConvertFrom-Json
  $f32TopOneTaskArchive = Join-Path $f32TopOneTaskRoot $f32TopOneTaskProof.archive.path
  if ((Get-FileHash -LiteralPath $f32TopOneTaskArchive -Algorithm SHA256).Hash -ne $f32TopOneTaskProof.archive.sha256) { throw 'Published closed F32 TopK1 evidence differs' }
  $f32TopOneTaskActive = @(Get-CimInstance Win32_Process | Select-Object -ExpandProperty ExecutablePath)
  $f32TopOneTaskTargets = @(foreach ($entry in $f32TopOneTaskPlan.files) {
    $f32TopOneTaskPath = [IO.Path]::GetFullPath((Join-Path $f32TopOneTaskRoot $entry.path))
    if (!$f32TopOneTaskPath.StartsWith($f32TopOneTaskBase+'\',[StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetExtension($f32TopOneTaskPath) -notin @('.exe','.obj','.exp','.lib','.dll')) { throw 'closed F32 TopK1 target outside exact binary scope' }
    $f32TopOneTaskResolved = (Resolve-Path -LiteralPath $f32TopOneTaskPath).Path
    if ($f32TopOneTaskResolved -ne $f32TopOneTaskPath -or $f32TopOneTaskActive -contains $f32TopOneTaskPath) { throw 'closed F32 TopK1 target changed or active' }
    for ($f32TopOneTaskParent=$f32TopOneTaskPath; $f32TopOneTaskParent; $f32TopOneTaskParent=[IO.Path]::GetDirectoryName($f32TopOneTaskParent)) {
      if ((Get-Item -LiteralPath $f32TopOneTaskParent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'closed F32 TopK1 cleanup path has reparse point' }
    }
    $f32TopOneTaskItem = Get-Item -LiteralPath $f32TopOneTaskPath
    if ($f32TopOneTaskItem.PSIsContainer -or $f32TopOneTaskItem.Length -ne $entry.bytes -or
        (Get-FileHash -LiteralPath $f32TopOneTaskPath -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'closed F32 TopK1 target differs from recorded binary' }
    $f32TopOneTaskFile = [IO.File]::Open($f32TopOneTaskPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
    $f32TopOneTaskFile.Dispose()
    [pscustomobject]@{path=$f32TopOneTaskPath;bytes=$entry.bytes;sha256=$entry.sha256}
  })
  $f32TopOneTaskResult = [ordered]@{applied=[bool]$Apply;files=$f32TopOneTaskTargets;logical_bytes=$f32TopOneTaskPlan.logical_bytes;physical_bytes_freed_unknown=$true}
  $f32TopOneTaskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $f32TopOneTaskBase 'cleanup-preview.json') -Encoding utf8
  if ($Apply) {
    foreach ($entry in $f32TopOneTaskTargets) { Remove-Item -LiteralPath $entry.path }
    foreach ($entry in $f32TopOneTaskTargets) { if (Test-Path -LiteralPath $entry.path) { throw 'closed F32 TopK1 binary still present' } }
    $f32TopOneTaskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $f32TopOneTaskReceipt -Encoding utf8
  }
  [ordered]@{files=$f32TopOneTaskTargets.Count;logical_bytes=$f32TopOneTaskPlan.logical_bytes;applied=[bool]$Apply} | ConvertTo-Json
  exit 0
}

