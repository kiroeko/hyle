from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
public = root / 'docs/evidence/performance/mtp-f32-single-row-prepared-screen-2026-10-25.json'
data = json.loads(public.read_text('utf-8'))
receipt_path = base / 'cleanup-removed.json'
receipt = json.loads(receipt_path.read_text('utf-8-sig'))
assert receipt['applied'] and len(receipt['files']) == 11
assert receipt['logical_bytes'] == 303158869
for item in receipt['files']:
    path = Path(item['path'])
    assert path.is_relative_to(base) and not path.exists()
script = (root / 'test.ps1').read_text('utf-8-sig')
start = script.index('if ($RemoveClosedF32TopOneBinaries) {')
end = script.index('\nif ($RemoveMtpNativeSupersededBinaries)', start)
(base / 'cleanup-test-excerpt.ps1').write_text(
    'param([switch]$Apply, [switch]$RemoveClosedF32TopOneBinaries)\n' + script[start:end],
    encoding='utf-8')
followup = dict(status='COMPLETED_CLOSED_CANDIDATE_BINARIES_REMOVED',
                files=11, logical_bytes_removed=303158869,
                physical_bytes_freed_unknown=True,
                command_preview='.\\test.ps1 -RemoveClosedF32TopOneBinaries',
                command_apply='.\\test.ps1 -RemoveClosedF32TopOneBinaries -Apply',
                kept='All source, patches, raw logs, commands, reports, memory samples, baseline seed image, SDK inputs and weights.',
                validation='Resolved repository-contained exact file paths, ordinary files/no reparse ancestors, inactive process, size/SHA256 and exclusive-open checks for every item before removal.',
                note='No product source changes or new build/model/profile process.')
followup_path = base / 'cleanup-followup.json'
followup_path.write_text(json.dumps(followup, indent=2) + '\n', encoding='utf-8')
archive = root / data['archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == data['archive']['sha256']
with zipfile.ZipFile(archive, 'a', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name in ('prepare-cleanup.py', 'record-cleanup.py', 'cleanup-test-excerpt.ps1',
                 'cleanup-removed.json', 'cleanup-followup.json'):
        target = 'root-cleanup/' + name
        assert target not in stream.namelist()
        stream.write(base / name, target)
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    entries = len(stream.infolist())
    assert len(set(stream.namelist())) == entries
data['cleanup_execution'] = followup
data['archive'].update(bytes=archive.stat().st_size,
                       sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
data['root_archive_entries_after_cleanup'] = entries
public.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(files=11, logical_bytes=303158869, archive_entries=entries,
                     archive_sha256=data['archive']['sha256']), indent=2))
