"""Offline comparison of the already completed finite checks."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / ".scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp"


def read(p):
    return json.loads(p.read_text())


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n")


def pin(p):
    return {"path": p.relative_to(R).as_posix(), "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


def report(p):
    text = p.read_text()
    return json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0]


def normalize(value):
    if isinstance(value, list):
        return [normalize(x) for x in value]
    if isinstance(value, dict):
        return {k: normalize(x) for k, x in value.items() if not any(
            t in k for t in ["seconds", "tokens_per_second", "clock_unix", "unix_ns", "unix_ms"])}
    return value


def difference(old, new, path=""):
    if type(old) != type(new):
        return [{"field": path, "old": old, "new": new}]
    if isinstance(old, dict):
        out = []
        for key in sorted(old.keys() | new.keys()):
            if key not in old or key not in new:
                out.append({"field": path + "." + key, "old": old.get(key), "new": new.get(key)})
            else:
                out.extend(difference(old[key], new[key], path + "." + key))
        return out
    if isinstance(old, list):
        if len(old) != len(new):
            return [{"field": path + ".length", "old": len(old), "new": len(new)}]
        return [d for i, (a, b) in enumerate(zip(old, new)) for d in difference(a, b, path + f"[{i}]")]
    return [] if old == new else [{"field": path, "old": old, "new": new}]


old = report(B / "stdout.log")
current = report(W / "run-app/stdout.log")
diff = difference(normalize(old), normalize(current))
assert not diff
save(W / "report-comparison.json", {"old": old, "candidate": current,
    "differences": diff, "excluded_fields": "Only original seconds/TPS/clock fields; no capture or work fields hidden"})

a = (B / "stderr.log").read_text().splitlines()
b = (W / "run-app/stderr.log").read_text().splitlines()
assert len(a) == len(b)
strip_time = lambda line: re.sub(r"\s*\b\w*seconds=\S+", "", line)
changes = [{"line": i, "old": strip_time(x), "new": strip_time(y)}
           for i, (x, y) in enumerate(zip(a, b), 1) if strip_time(x) != strip_time(y)]


def preparations(lines):
    return [{k: int(v) if v.isdigit() else v
             for k, v in re.findall(r"(\w+)=([^ ]+)", line) if not k.endswith("seconds")}
            for line in lines if line.startswith("prepared ")]


pa, pb = preparations(a), preparations(b)
assert len(pa) == len(pb) == 68
for x, y in zip(pa, pb):
    unchanged = lambda z: {k: v for k, v in z.items() if k not in ("replay", "capture_recorded", "capture_reused")}
    assert unchanged(x) == unchanged(y)
    if x["T"] == 2:
        assert x["replay"] == "hybrid" and y["replay"] == "captured"
        assert x["capture_recorded"] + x["capture_reused"] == 2
        assert y["capture_recorded"] == int(x["capture_recorded"] != 0)
        assert y["capture_reused"] == int(x["capture_recorded"] == 0)
    else:
        assert x == y
workspace = [x for x in changes if x["old"].startswith("compiled T=")]
assert len(workspace) == 1
assert "workspace/slot=5758720" in workspace[0]["old"]
assert "workspace/slot=5746944" in workspace[0]["new"]
assert re.sub(r"workspace/slot=\d+", "workspace/slot=<bytes>", workspace[0]["old"]) == re.sub(
    r"workspace/slot=\d+", "workspace/slot=<bytes>", workspace[0]["new"])
assert all(x["old"].startswith(("prepared ", "compiled T=")) for x in changes)
labels = lambda lines: [s for s in lines if s.startswith(("generation_session ", "generation_batch "))]
assert labels(a) == labels(b)
capture = {arm: {"calls": len(rows), "recorded": sum(x["capture_recorded"] for x in rows),
                 "reused": sum(x["capture_reused"] for x in rows),
                 "routes": dict(Counter(x["replay"] for x in rows))}
           for arm, rows in (("old", pa), ("candidate", pb))}
save(W / "stderr-comparison.json", {"stderr_lines": len(a), "all_non_time_changes": changes,
    "prepared": {"old": pa, "candidate": pb}, "capture_totals": capture,
    "generation_labels_equal": True, "unexplained_changes": []})
tests = {}
for group in ("numeric", "capture"):
    xml = ET.parse(W / ("run-" + group) / "results.xml").getroot()
    assert xml.get("tests") == "2" and xml.get("failures") == "0" and xml.get("errors") == "0"
    assert not list(xml.iter("skipped"))
    tests[group] = {"tests": 2, "failures": 0, "skipped": 0,
                    "cases": [x.get("classname") + "." + x.get("name") for x in xml.iter("testcase")],
                    "process": read(W / ("run-" + group) / "process.json")}
files = []
for folder in ["compile-native", "compile-direct", "compile-graph", "compile-graph2", "link-tests", "link-app"]:
    for p in sorted((W / folder).iterdir()):
        if p.is_file() and p.suffix.lower() in (".obj", ".exe", ".exp", ".lib", ".pdb", ".dll"):
            files.append(pin(p))
save(W / "cleanup-candidates.json", {"status": "RETAIN_PENDING_PARENT_DECISION_NO_DELETE", "files": files,
    "count": len(files), "logical_bytes": sum(x["bytes"] for x in files)})
summary = {"status": "FINITE_NUMERIC_CAPTURE_AND_APPLICATION_PASS_PRIVATE_NOT_MERGED",
    "gpu_released": True, "profiler": False, "performance_window": False,
    "canonical_mutations": 0, "sdk_builds": 0, "HTTP": 0,
    "build": pin(W / "build-summary.json"), "source_patch": pin(W / "source.patch"),
    "test_patch": pin(W / "test-only.patch"), "tests": tests,
    "application": {"process": read(W / "run-app/process.json"), "all_non_time_report_differences": diff,
        "all_non_time_stderr_changes_classified": True, "capture": capture,
        "workspace_per_T2_slot_old": 5758720, "workspace_per_T2_slot_new": 5746944,
        "generation_labels_equal": True,
        "work": {k: current[k] for k in ("generated_tokens", "actual_graph_calls", "prefill_target_rows", "verified_target_rows", "actual_target_rows", "actual_draft_rows", "consumed_drafts")}},
    "first_failure": read(W / "build-summary.json")["first_failure"],
    "limits": ["One application behavioral process, not a throughput comparison; raw timing retained but not used to claim speedup.",
        "Correction to initial message: total21 recordings and45 reuses, not an assumed half of32/100. Ten original episodes recorded only one of two ranges; a merged range must be rerecorded when either constituent changed.",
        "Existing replay reports prove one captured range per T2 episode; no new CUDA API trace verifies native launch counts or individual API time.",
        "Independent stable-sort/bit oracle and original two-queue workspace replay checks cover the listed cases; no all-model or all-shape certification.",
        "Private F32 wide single-row gate only. BF16/FP16/I32 single-row route and head precision remain unchanged."],
    "cleanup": pin(W / "cleanup-candidates.json")}
save(W / "proof-summary.json", summary)
print(json.dumps({"status": summary["status"], "capture": capture, "cleanup_count": len(files),
                  "cleanup_logical_bytes": sum(x["bytes"] for x in files)}))
