"""Three incremental TUs plus retained closure links; no runtime/GPU command."""
from pathlib import Path
import argparse
import difflib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location(
    "retained_helpers", ROOT / ".scratch/mtp-extraction-regression-20261024/check.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

RECIPES = {
    "native": ROOT / ".scratch/qwen-batch-profile-20261022/compile3/native/identity.json",
    "direct": ROOT / ".scratch/architecture-refactor-2026-10-18/cccl-single-row-topk/checks/20261019T185912-host/direct-test-identity.json",
    "graph": ROOT / ".scratch/qwen-topone-prepared-20261022/compile1/graph-test/identity.json",
}
SOURCES = {
    "native": "src/compute_provider_cuda/collectives.cu",
    "direct": "tests/compute_provider_cuda/collectives_test.cc",
    "graph": "tests/graph_route_cuda/topk_test.cc",
}
BASE = ROOT / ".scratch/mtp-native-seed-candidate-20261025"
APP = ROOT / ".scratch/mtp-performance-convergence-20261025/baseline/compile/unit.obj"
OLD_NATIVE = Path(b.read(RECIPES["native"])["object"]["path"])


def key(value):
    return str(value).lower().replace("\\", "/")


def prepare_tests():
    changed = []
    for relative in [SOURCES["direct"], SOURCES["graph"]]:
        original = (ROOT / relative).read_bytes()
        text = original.decode().replace("\r\n", "\n")
        if relative == SOURCES["direct"]:
            assert text.count("0xffc002cdU") == 1
            text = text.replace("0xffc002cdU", "0xff800123U")
            anchor = "  // Adjacent non-dense and broadcast domains must keep the generic iterator."
            assert text.count(anchor) == 1
            text = text.replace(anchor,
                "  // Wide single-row generic layouts exercise the prepared F32 path.\n"
                "  topk<float>(owner, row, 0, 1, 1);\n"
                "  topk<float>(owner, row, 0, 2, 1);\n" + anchor)
        else:
            start = text.index("TEST(CudaDefaultGraph, WideTopOnePreparedCaptureKeepsInvocationWorkspaceIsolated)")
            end = text.index("TEST(CudaDefaultGraph, OtherTopKProgramsKeepManagedReplayContract)")
            body = text[start:end]
            anchor = "  constexpr std::size_t rows = 3, width = 8193;"
            assert body.count(anchor) == 1 and body.endswith("}\n\n")
            body = body.replace(anchor,
                "  constexpr std::size_t width = 8193;\n"
                "  for (const std::size_t rows : {1U, 3U}) {\n"
                "    SCOPED_TRACE(rows);")
            body = body.replace("std::array<std::int64_t, 2>{rows, width}",
                                "std::array<std::int64_t, 2>{static_cast<std::int64_t>(rows), width}")
            body = body[:-3] + "  }\n}\n\n"
            text = text[:start] + body + text[end:]
            assert text.count("Case{1, 8193, 1}") == 1
            text = text.replace("Case{1, 8193, 1}", "Case{1, 2048, 1}")
        newline = "\r\n" if b"\r\n" in original else "\n"
        content = text.replace("\n", newline).encode()
        for base, data in (("before", original), ("source", content)):
            path = HERE / base / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        changed.append("".join(difflib.unified_diff(
            original.decode().splitlines(keepends=True), content.decode().splitlines(keepends=True),
            fromfile="a/" + relative, tofile="b/" + relative)))
    (HERE / "test-only.patch").write_bytes("".join(changed).encode())
    for relative in ["src/compute_provider_cuda/collectives.h",
                     "tests/compute_provider_cuda/collectives_test_support.h",
                     "tests/compute_provider_native/half_test_support.h"]:
        target = HERE / "source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT / relative).read_bytes())
    b.save(HERE / "test-source-pins.json", [
        b.pin(HERE / "source" / relative) for relative in SOURCES.values()])


def build(tag, attempt):
    original = b.read(RECIPES[tag])["command"]
    source = HERE / "source" / SOURCES[tag]
    folder = HERE / ("compile-" + tag + (str(attempt) if attempt != 1 else ""))
    if tag == "native":
        flags = []
        skip = False
        for word in original[1:]:
            if skip:
                skip = False
            elif word in ("-c", "-MT", "-MF", "-o"):
                skip = True
            else:
                flags.append(word)
        command = [original[0], *flags, "-c", str(source), "-MT", str(folder / "unit.obj"),
                   "-MF", str(folder / "native.d"), "-o", str(folder / "unit.obj")]
    else:
        flags = []
        skip = False
        for word in original[1:]:
            if skip:
                skip = False
                continue
            if word == "/sourceDependencies":
                skip = True
            elif not (word.lower().endswith((".cc", ".cpp")) or word.lower().startswith(("/fo", "/fd"))):
                flags.append(word)
        command = [original[0], *flags, "/sourceDependencies", str(folder / "dependencies.json"),
                   str(source), "/Fo" + str(folder / "unit.obj"), "/Fd" + str(folder / "unit.pdb")]
        assert "/W4" in command and "/WX" in command
    source_pin = b.pin(source)
    compiler = b.read(RECIPES["direct"])["command"][0]
    b.execute(command, folder, b.environment(compiler), 240)
    assert b.pin(source) == source_pin
    if tag == "native":
        dependencies = [source, HERE / "source/src/compute_provider_cuda/collectives.h",
                        ROOT / "src/compute_backend_cuda/device_status_kernel.h"]
    else:
        deps = b.read(folder / "dependencies.json")["Data"]
        dependencies = list(dict.fromkeys([Path(deps["Source"]), *(Path(x) for x in deps["Includes"])]))
    b.save(folder / "identity.json", {"source": source_pin, "object": b.pin(folder / "unit.obj"),
        "recipe": b.pin(RECIPES[tag]), "dependencies": [b.pin(p) for p in dependencies],
        "sdk_builds": 0, "gpu_run": False})


def link(mode, graph_attempt):
    original = b.args(BASE / "link2/command.json")
    command = []
    hits = 0
    for word in original:
        if word.lower().startswith(("/out:", "/implib:", "/pdb:", "/map:")):
            continue
        if key(word) == key(OLD_NATIVE):
            hits += 1
            command.append(str(HERE / "compile-native/unit.obj"))
        elif mode == "tests" and key(word) == key(APP):
            continue
        else:
            command.append(word)
    assert hits == 1
    if mode == "tests":
        assert sum(key(x) == key(APP) for x in original) == 1
        command.extend(str(HERE / ("compile-" + tag + (str(graph_attempt) if tag == "graph" and graph_attempt != 1 else "")) / "unit.obj") for tag in ("direct", "graph"))
        command.extend(str(ROOT / ".scratch/build-compute-v2-dev/lib" / name)
                       for name in ("gtest.lib", "gtest_main.lib"))
    folder = HERE / ("link-" + mode)
    image = folder / ("tests.exe" if mode == "tests" else "hyle.exe")
    command.extend(["/OUT:" + str(image), "/IMPLIB:" + str(image.with_suffix(".lib"))])
    for word in command:
        if Path(word).is_absolute() and word.lower().endswith((".obj", ".lib")):
            assert Path(word).is_file(), word
    b.execute(command, folder, b.environment(b.read(RECIPES["direct"])["command"][0]), 120)
    native = BASE / "link2/hyle_ggml_cpu_gdn_scale_v3.dll"
    os.link(native, folder / native.name)
    b.save(folder / "identity.json", {"image": b.pin(image), "native": b.pin(folder / native.name),
        "base_command": b.pin(BASE / "link2/command.json"),
        "objects": [b.pin(Path(word)) for word in command if word.lower().endswith(".obj")],
        "gpu_run": False})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare-tests", "native", "direct", "graph", "link-tests", "link-app"))
    parser.add_argument("--attempt", type=int, default=1)
    args = parser.parse_args()
    if args.mode == "prepare-tests":
        prepare_tests()
    elif args.mode.startswith("link-"):
        link(args.mode.removeprefix("link-"), args.attempt)
    else:
        build(args.mode, args.attempt)
