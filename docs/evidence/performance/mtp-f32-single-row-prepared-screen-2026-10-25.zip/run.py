from pathlib import Path
import datetime
import importlib.util
import os
import sys

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / ".scratch/mtp-performance-convergence-20261025/baseline"
spec = importlib.util.spec_from_file_location("helpers", R / ".scratch/mtp-extraction-regression-20261024/check.py")
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
mode = sys.argv[1]
env = os.environ.copy()
env.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1")
summary = b.read(W / "build-summary.json")
if mode in ("numeric", "capture"):
    image = summary["tests"]
    group = 0 if mode == "numeric" else 1
    command = [str(R / image["path"]), "--gtest_filter=" + summary["next_filters"][group],
               "--gtest_output=xml:" + str(W / ("run-" + mode) / "results.xml")]
else:
    assert mode == "app"
    for group in ("numeric", "capture"):
        assert b.read(W / ("run-" + group) / "process.json")["exit"] == 0
    image = summary["app"]
    command = b.args(B / "two-turn-timing/02-hyle_mtp/command.json")
    command[0] = str(R / image["path"])
assert b.pin(R / image["path"])["sha256"] == image["sha256"]
env["PATH"] = str(Path(command[0]).parent) + ";" + b.read(B / "runtime.json")["PATH"]
b.save(W / (mode + "-start.json"), {
    "start_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "image": image, "scope": "Finite correctness/capture check; no TPS or profiler"})
b.execute(command, W / ("run-" + mode), env, 120)
