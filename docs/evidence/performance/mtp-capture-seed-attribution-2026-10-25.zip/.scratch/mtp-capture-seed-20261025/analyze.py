from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, re

W = Path(__file__).resolve().parent
R = W.parents[1]

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')

def report(path):
    text = path.read_text(encoding='utf8')
    return json.JSONDecoder().raw_decode(text[text.index('{"source_id"'):])[0]

def normalize(value):
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items()
                if not any(t in k for t in ('seconds', 'tokens_per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value

def diffs(a, b, path=''):
    if type(a) != type(b):
        return [path + ':type']
    if isinstance(a, dict):
        return ([path + '/' + k + ':key' for k in a.keys() ^ b.keys()] +
                [d for k in a.keys() & b.keys() for d in diffs(a[k], b[k], path + '/' + k)])
    if isinstance(a, list):
        return ([path + ':length'] if len(a) != len(b) else
                [d for i, (x, y) in enumerate(zip(a, b)) for d in diffs(x, y, path + '/' + str(i))])
    return [] if a == b else [path]

stderr = (W / 'run2/stderr.log').read_text(encoding='utf8')
events = [{k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
          for line in stderr.splitlines() if line.startswith('SEED_EVENT ')]
header = [{k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
          for line in stderr.splitlines() if line.startswith('SEED_POD ')]
assert len(header) == 1 and header[0]['events'] == len(events)
assert header[0]['overflow'] == 0
assert [v['i'] for v in events] == list(range(len(events)))
assert header[0]['logical_sequence'] == 68

baseline = R / '.scratch/mtp-performance-convergence-20261025/baseline/two-turn-timing/02-hyle_mtp/stdout.log'
nvtx = R / '.scratch/mtp-logical-call-trace-20261025/hyle/trace1/native-stdout.log'
raw = report(W / 'run2/stdout.log')
comparison = {name: dict(path=pin(path), non_time_differences=diffs(normalize(report(path)), normalize(raw)))
              for name, path in [('formal_clean_baseline', baseline), ('previous_NVTX_Hyle_run', nvtx)]}
assert all(not value['non_time_differences'] for value in comparison.values()), comparison

# Invocation/range identity is only local to this process. Full event order is preserved.
histories = defaultdict(list)
records = []
for event in events:
    key = (event['inv'], event['begin'], event['count'])
    history = histories[key]
    if event['kind'] == 30:
        previous = next((v for v in reversed(history) if v['kind'] == 31), None)
        since = [v for v in history if previous is None or v['i'] > previous['i']]
        before = next((v for v in reversed(since) if v['kind'] == 10), None)
        eviction = next((v for v in reversed(since) if v['kind'] == 12), None)
        after = next((v for v in reversed(since) if v['kind'] == 14), None)
        explicit = [v for v in since if v['kind'] == 1]
        loss = [v for v in explicit if v['keys'] or v['commands'] or v['storage'] or v['live']]
        nonordinary = [v for v in since if v['kind'] == 2 and not v['aux']]
        if event['aux']:
            classification = 'retired_rebuild_seed_available'
        elif previous is None:
            classification = 'first_record_for_invocation_range'
        elif loss:
            classification = 'previous_record_cleared_by_explicit_invalidation'
        elif nonordinary:
            classification = 'previous_record_cleared_by_nonordinary_invalidation'
        elif eviction and eviction['commands'] & (1 << eviction['selected']):
            classification = 'selected_retired_commands_recycle_declined'
        elif eviction and not eviction['keys'] & (1 << eviction['selected']):
            classification = 'unfilled_selected_variant_no_rebuild_seed'
        else:
            classification = 'unresolved_no_seed'
        records.append(dict(record=event, classification=classification,
                            earlier_explicit_loss=any(v['kind'] == 1 and
                                (v['keys'] or v['commands'] or v['storage'] or v['live'])
                                for v in history),
                            prior_record=previous, before_selection=before,
                            selected_eviction=eviction, after_optional_recycle=after,
                            explicit_invalidation_events=explicit,
                            explicit_loss_events=loss,
                            nonordinary_invalidation_events=nonordinary))
    history.append(event)

save(W / 'events.json', dict(header=header[0], events=events))
save(W / 'records.json', records)
summary = dict(
    status='ONE_CORRECTED_DIAGNOSTIC_PASS_OFFLINE_CLASSIFIED',
    process=read(W / 'run2/process.json'),
    scope='One Hyle original greedy K1 real-two-turn process. No Nsight, peer, TPS or numerical/quality claim. No product edits.',
    inputs_and_image=pin(W / 'ready4.json'),
    event_header=header[0], event_kinds=dict(Counter(str(v['kind']) for v in events)),
    recording_calls=len(records),
    actual_rebuild_seed=dict(Counter(str(v['record']['aux']) for v in records)),
    classification=dict(Counter(v['classification'] for v in records)),
    no_seed_subclasses=dict(
        first_range_records=sum(v['classification'] == 'first_record_for_invocation_range' for v in records),
        second_variant_fill_before_any_explicit_loss=sum(v['classification'] == 'unfilled_selected_variant_no_rebuild_seed' and not v['earlier_explicit_loss'] for v in records),
        first_record_after_explicit_loss=sum(v['classification'] == 'previous_record_cleared_by_explicit_invalidation' for v in records),
        second_variant_refill_after_explicit_loss=sum(v['classification'] == 'unfilled_selected_variant_no_rebuild_seed' and v['earlier_explicit_loss'] for v in records),
        calculation='The 9 unfilled variants split 4 initial fills and 5 refills after a native invalidation. The current window therefore has 8 initial two-variant fills and 11 seedless records following explicit clears; this is not a recoverable-time estimate.'),
    selected_work={k: raw[k] for k in ['source_id', 'text_tensors', 'mtp_tensors',
        'original_device_weight_bytes', 'generated_tokens', 'actual_graph_calls',
        'prefill_graph_calls', 'decode_graph_calls', 'prefill_target_rows',
        'verified_target_rows', 'actual_target_rows', 'committed_target_rows',
        'prefill_draft_rows', 'actual_draft_rows', 'draft_rounds', 'consumed_drafts']},
    non_time_work_comparison=comparison,
    raw_report=pin(W / 'run2/stdout.log'),
    raw_events=pin(W / 'run2/stderr.log'),
    classification_details=pin(W / 'records.json'),
    limitations=[
        'No CUDA API result hook in this process. Prior separate NVTX run had 13 successful updates and 19 instantiate-without-update records; exact counts can agree but native object identity is not cross-run joined.',
        'The events identify Graph invalidation/variant/rebuild-storage decisions, not which provider native plan field changed.',
        'A missing seed after explicit invalidation is not proof that retaining it across provider mutable-resource release is safe.',
        'Diagnostic process wall time is not a performance sample.'
    ],
    preserved_failures=[
        dict(path='compile', outcome='Strict compile failed: private NVTX include leaked Windows interface macro; fixed with push/pop macro.'),
        dict(path='run1', outcome='Actual model exit0 but inline Dumper emitted no events; instrument failure, not zero events.'),
        dict(path='compile3', outcome='Strict C4335 warning from private helper CRCRLF encoding; fixed raw-byte newline normalization.'),
    ],
)
save(W / 'summary.json', summary)
print(json.dumps({k: summary[k] for k in ['event_header', 'recording_calls', 'actual_rebuild_seed', 'classification']}, indent=2))
for v in records:
    e=v['record'];p=v['prior_record'];before=v['before_selection'];ev=v['selected_eviction']
    print(f"seq={e['seq']:2} range={e['begin']}+{e['count']} seed={e['aux']} prior={p['seq'] if p else '-'} class={v['classification']} loss={[(x['i'],x['seq'],x['step'],x['keys'],x['commands'],x['live']) for x in v['explicit_loss_events']]} select={ev['selected'] if ev else '-'} beforekeys={before['keys'] if before else '-'}")
