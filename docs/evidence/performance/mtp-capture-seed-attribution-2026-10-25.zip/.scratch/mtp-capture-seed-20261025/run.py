from pathlib import Path
import json,os,importlib.util,datetime
R=Path.cwd();W=Path(__file__).resolve().parent;B=R/'.scratch/mtp-performance-convergence-20261025/baseline'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(W/'ready2.json');assert b.pin(Path(ready['image']['path']))==ready['image']
for pin in ready['sources']:assert b.pin(Path(pin['path']))==pin
cmd=b.args(B/'two-turn-timing/02-hyle_mtp/command.json');cmd[0]=ready['image']['path']
env=os.environ.copy();env['PATH']=str(W/'link2')+';'+b.read(B/'runtime.json')['PATH'];env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
b.save(W/'run-start.json',dict(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),ready=b.pin(W/'ready2.json'),scope='OnePODdiagnostic,noprofileorTPS',runtime=b.pin(B/'runtime.json')))
b.execute(cmd,W/'run1',env,120)
