from pathlib import Path
import datetime, hashlib, json, re, zipfile

R = Path.cwd()
W = Path(__file__).resolve().parent
P = R / 'docs/evidence/performance/mtp-capture-seed-attribution-2026-10-25'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def save(p, v):
    p.write_text(json.dumps(v, indent=2) + '\n', encoding='utf8')

summary = read(W / 'summary.json')
assert summary['process']['exit'] == 0
assert summary['event_header']['overflow'] == 0
assert all(not v['non_time_differences'] for v in summary['non_time_work_comparison'].values())
canonical = R / 'src/graph/executable.cc'
private = W / 'source/executable.cc'
strip = re.sub(r'// SEED_POD_BEGIN\n.*?// SEED_POD_END\n', '', private.read_text(), flags=re.S)
assert strip == canonical.read_text()
ready = read(W / 'ready4.json')
for p in ready['sources']:
    actual = Path(p['path'])
    assert actual.stat().st_size == p['bytes']
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == p['sha256']
cleanup = [pin(p) for d in ['compile2', 'link2', 'compile4', 'link4']
           for p in (W / d).iterdir()
           if p.is_file() and p.suffix.lower() in ['.obj', '.exe', '.exp', '.lib', '.dll', '.pdb', '.map']]
save(W / 'cleanup-candidates.json', dict(files=cleanup, count=len(cleanup),
    logical_bytes=sum(p['bytes'] for p in cleanup), deletion_executed=False,
    scope='This private batch only. No source/logs, models, SDK, shared closure or original app objects.'))
summary.update(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    throughput_evidence=False, quality_evidence=False, numerical_evidence=False,
    actual_model_processes=2, corrected_diagnostic_processes=1,
    GPU_released=True, SDK_builds=0, HTTP=0, product_edits=0,
    canonical_Graph_unchanged=pin(canonical), private_Graph=pin(private),
    dump_helper=pin(W / 'seed_probe.h'),
    source_equivalence=read(W / 'equivalence.json'),
    final_build=dict(compile=read(W / 'compile4/process.json'), link=read(W / 'link4/process.json')),
    original_compile_failures=dict(first_macro=read(W / 'compile/process.json'),
        private_newline=read(W / 'compile3/process.json')),
    first_no_dump_process=read(W / 'run1/process.json'),
    previous_logical_call_evidence=pin(R / 'docs/evidence/performance/mtp-logical-call-attribution-2026-10-25.json'),
    API_claim_scope='This run observed Graph rebuild-seed validity, not CUDA API return codes. The earlier independent NVTX run is the source of 13 successful Update / 19 Instantiate-without-Update observations. No time from the two processes is subtracted.',
    cleanup=read(W / 'cleanup-candidates.json'))
save(W / 'proof-summary.json', summary)
files = [p for p in W.rglob('*') if p.is_file() and '__pycache__' not in p.parts
         and p.suffix.lower() in ['.py', '.h', '.cc', '.json', '.patch', '.log']
         and p.name != 'publication.json']
references = [R / '.scratch/mtp-logical-call-trace-20261025/logical_trace.h',
              R / '.scratch/mtp-logical-call-trace-20261025/hyle/ready.json',
              R / '.scratch/mtp-logical-call-trace-20261025/hyle/link/command.json',
              R / '.scratch/mtp-performance-convergence-20261025/baseline/runtime.json']
references += [R / v['path']['path'] for v in summary['non_time_work_comparison'].values()]
archive = P.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(set(files + references)):
        z.write(path, path.relative_to(R).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert all(Path(n).suffix.lower() not in ['.exe', '.obj', '.lib', '.dll', '.pdb', '.exp'] for n in names)
summary['archive'] = dict(**pin(archive), entries=len(names), CRC_pass=True,
    binaries_included=False, weights_or_SDK_included=False)
save(P.with_suffix('.json'), summary)
publication = dict(public=pin(P.with_suffix('.json')), archive=pin(archive),
    entries=len(names), cleanup_count=len(cleanup), cleanup_logical_bytes=sum(p['bytes'] for p in cleanup))
save(W / 'publication.json', publication)
print(json.dumps(publication, indent=2))
