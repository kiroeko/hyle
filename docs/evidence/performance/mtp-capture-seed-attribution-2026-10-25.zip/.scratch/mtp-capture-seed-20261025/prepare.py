from pathlib import Path
import hashlib,json,re,difflib
R=Path.cwd();W=Path(__file__).resolve().parent
source=R/'src/graph/executable.cc';before=source.read_text(encoding='utf8');assert hashlib.sha256(source.read_bytes()).hexdigest()=='8652cbd963069623860074e3bf874bb8574a31e27b1f3f6a945f7b37484b95bc';s=before
def add(anchor,payload,before=False):
 global s
 assert s.count(anchor)==1,(anchor[:80],s.count(anchor));tag='// SEED_POD_BEGIN\n'+payload+'\n// SEED_POD_END\n';s=s.replace(anchor,tag+anchor if before else anchor+tag)
header=r'''#pragma once
#pragma push_macro("interface")
#include "../mtp-logical-call-trace-20261025/logical_trace.h"
#pragma pop_macro("interface")
#include <array>
#include <cstdint>
#include <cstdio>
namespace seed_pod {
struct Event { unsigned long long seq=0;std::uintptr_t invocation=0;std::uint32_t kind=0,begin=0,count=0,step=0,selected=0,active=0,last=0,keys=0,commands=0,storage=0,qualified=0,preserves=0,live=0,aux=0; };
inline std::array<Event,8192> events{};inline std::size_t count=0,overflow=0;
inline void note(std::uintptr_t inv,std::uint32_t kind,std::uint32_t begin,std::uint32_t n,std::uint32_t step,std::uint32_t selected,std::uint32_t active,std::uint32_t last,std::uint32_t keys,std::uint32_t commands,std::uint32_t storage,std::uint32_t qualified,std::uint32_t preserves,std::uint32_t live,std::uint32_t aux) noexcept {
 if(count==events.size()){++overflow;return;}events[count++]={logical_trace::sequence,inv,kind,begin,n,step,selected,active,last,keys,commands,storage,qualified,preserves,live,aux};
}
struct Dump final {~Dump(){std::fprintf(stderr,"SEED_POD events=%zu capacity=%zu overflow=%zu logical_sequence=%llu\n",count,events.size(),overflow,logical_trace::sequence);for(std::size_t j=0;j<count;++j){const auto&v=events[j];std::fprintf(stderr,"SEED_EVENT i=%zu seq=%llu inv=%llu kind=%u begin=%u count=%u step=%u selected=%u active=%u last=%u keys=%u commands=%u storage=%u qualified=%u preserves=%u live=%u aux=%u\n",j,v.seq,static_cast<unsigned long long>(v.invocation),v.kind,v.begin,v.count,v.step,v.selected,v.active,v.last,v.keys,v.commands,v.storage,v.qualified,v.preserves,v.live,v.aux);}}};Dump dump;
}
'''
(W/'seed_probe.h').write_text(header,encoding='utf8')
add('namespace hyle::graph {\n','#include "'+str(W/'seed_probe.h').replace('\\','/')+'"',before=True)
snapshot=r'''void seed_snapshot(detail::InvocationState &invocation, const detail::CaptureRebuildRange *saved,
    std::uint32_t kind, std::uint32_t step=UINT32_MAX, std::uint32_t selected=UINT32_MAX, std::uint32_t aux=0) noexcept {
  if (!saved) return;
  std::uint32_t keys=0,commands=0,live=0;
  for (std::size_t j=0;j<2;++j){if(saved->variants[j].key_valid)keys|=1u<<j;if(saved->variants[j].commands.valid())commands|=1u<<j;}
  for(const auto &r:invocation.captured_ranges)if(r.step_begin==saved->step_begin&&r.step_count==saved->step_count&&r.commands.valid())++live;
  seed_pod::note(reinterpret_cast<std::uintptr_t>(&invocation),kind,saved->step_begin,saved->step_count,step,selected,saved->active_variant,saved->last_used,keys,commands,saved->storage.valid(),saved->qualification_valid,saved->preserves_private_arguments,live,aux);
}
'''
add('void discard_capture_variants(detail::CaptureRebuildRange &saved) noexcept {\n',snapshot,before=True)
add('        saved.storage.reset();\n        discard_capture_variants(saved);\n','        seed_snapshot(invocation, &saved, 1, selected_step);',before=True)
add('    if (auto *saved = capture_storage(invocation, range.step_begin, range.step_count)) {\n','      seed_snapshot(invocation, saved, 2, selected_step, UINT32_MAX, ordinary);')
add('        variant.commands = std::move(invocation.captured_ranges[index].commands);\n','        seed_snapshot(invocation, saved, 20, selected_step);')
add('        saved->storage = compute::detail::CommandCaptureAccess::recycle_after_retirement(\n            std::move(invocation.captured_ranges[index].commands));\n','        seed_snapshot(invocation, saved, 21, selected_step);')
add('    auto *saved = capture_storage(*state_, range.step_begin, range.step_count);\n','    seed_snapshot(*state_, saved, 10);')
add('        selected_variant = index;\n        break;\n','        seed_snapshot(*state_, saved, 11, UINT32_MAX, index);',before=True)
add('      auto &evicted = saved->variants[selected_variant];\n','      seed_snapshot(*state_, saved, 12, UINT32_MAX, selected_variant);')
add('      evicted.key_valid = false;\n','      seed_snapshot(*state_, saved, 14, UINT32_MAX, selected_variant);',before=True)
add('    auto captured = compute::detail::CommandCaptureAccess::end(\n','    seed_snapshot(*state_, saved, 30, UINT32_MAX, selected_variant, rebuild.valid());',before=True)
add('    ++recorded_range_count;\n','    seed_snapshot(*state_, saved, 31, UINT32_MAX, selected_variant, stable_identity);')
restore=re.sub(r'// SEED_POD_BEGIN\n.*?// SEED_POD_END\n','',s,flags=re.S);assert restore==before
(W/'source').mkdir(exist_ok=False);(W/'source/executable.cc').write_text(s,encoding='utf8',newline='\n');(W/'source.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='canonical8652/executable.cc',tofile='privatePOD/executable.cc')),encoding='utf8')
(W/'equivalence.json').write_text(json.dumps(dict(canonical_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),private_sha256=hashlib.sha256((W/'source/executable.cc').read_bytes()).hexdigest(),insertion_only=True,stripped_full_source_equal=True,capacity=8192,hot_allocation=False,no_refs_retained=True,no_device_or_math_change=True,events={1:'explicitreset_before_clear',2:'active_range_invalidation_before_action_aux=ordinary',10:'saved_before_variant_selection',11:'variant_hit',12:'selected_eviction_before_recycle',14:'after_optional_eviction_recycle_before_keyclear',20:'ordinary_parked_commands',21:'ordinary_recycle_result',30:'before_nativeend_aux=actual_rebuild.valid',31:'recorded_native_range'}),indent=2)+'\n');print('PREPARED_INSERTION_ONLY')
