from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;p=W/'seed_probe.h';before=p.read_bytes();(W/'seed_probe-second.h').write_bytes(before)
old='};inline Dump dump;';new='};Dump dump;';text=before.decode();assert text.count(old)==1;p.write_text(text.replace(old,new),encoding='utf8')
prepare=W/'prepare.py';s=prepare.read_text();assert s.count(old)==1;prepare.write_text(s.replace(old,new),encoding='utf8')
(W/'dumper-correction.json').write_text(json.dumps(dict(first_actual_process='run1/process.json',first_actual_exit=0,seed_output_observed=False,correction='Same singleGraphTU: inlineglobalDumper made noninline soCrtglobalinitializer/atexit cannot rely oninlinevariableODRuse. PODevent logic/math/algorithm unchanged.',before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Privateinstrumentationcorrection, notproductbug. NoGPUyet.'),indent=2)+'\n')
