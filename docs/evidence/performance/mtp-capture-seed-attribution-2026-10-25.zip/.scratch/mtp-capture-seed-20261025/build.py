from pathlib import Path
import importlib.util,json,os,sys
R=Path.cwd();W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
C=R/'.scratch/mtp-performance-convergence-20261025/current-cuda';H=R/'.scratch/mtp-logical-call-trace-20261025/hyle'
suffix=sys.argv[1]if len(sys.argv)>1 else'';compile_dir=W/('compile'+suffix);link_dir=W/('link'+suffix)
old=b.args(C/'product-0/command.json');flags=[];skip=False
for a in old[1:]:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd'))or a.lower().endswith(('.cc','.cpp')):continue
 flags.append(a)
cmd=[old[0],*flags,str(W/'source/executable.cc'),'/sourceDependencies',str(compile_dir/'dependencies.json'),'/Fo'+str(compile_dir/'unit.obj')]
env=b.environment(old[0]);b.execute(cmd,compile_dir,env,90)
deps=b.read(compile_dir/'dependencies.json')['Data'];pins=[b.pin(Path(x))for x in [deps['Source'],*deps['Includes']]if Path(x).is_relative_to(R)]
b.save(compile_dir/'source-pins.json',pins)
link=b.args(H/'link/command.json');args=[];replaced=0
for a in link[1:]:
 if a.lower()==str(C/'product-0/unit.obj').lower():args.append(str(compile_dir/'unit.obj'));replaced+=1
 elif not a.lower().startswith(('/out:','/pdb:','/map:','/implib:')):args.append(a)
assert replaced==1
b.execute([link[0],*args,'/OUT:'+str(link_dir/'hyle.exe'),'/IMPLIB:'+str(link_dir/'hyle.lib')],link_dir,env,90)
os.link(H/'link/hyle_ggml_cpu_gdn_scale_v3.dll',link_dir/'hyle_ggml_cpu_gdn_scale_v3.dll')
for pin in pins:assert b.pin(Path(pin['path']))==pin
b.save(W/('ready'+suffix+'.json'),dict(image=b.pin(link_dir/'hyle.exe'),sources=pins,app=b.pin(H/'compile/unit.obj'),retained_link=b.pin(H/'link/command.json'),new_TUs=1,SDK_builds=0,GPU_runs=0))
print('GRAPH_BUILT',flush=True)
