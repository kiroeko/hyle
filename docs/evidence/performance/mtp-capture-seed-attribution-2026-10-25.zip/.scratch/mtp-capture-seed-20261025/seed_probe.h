#pragma once
#pragma push_macro("interface")
#include "../mtp-logical-call-trace-20261025/logical_trace.h"
#pragma pop_macro("interface")
#include <array>
#include <cstdint>
#include <cstdio>
namespace seed_pod {
struct Event { unsigned long long seq=0;std::uintptr_t invocation=0;std::uint32_t kind=0,begin=0,count=0,step=0,selected=0,active=0,last=0,keys=0,commands=0,storage=0,qualified=0,preserves=0,live=0,aux=0; };
inline std::array<Event,8192> events{};inline std::size_t count=0,overflow=0;
inline void note(std::uintptr_t inv,std::uint32_t kind,std::uint32_t begin,std::uint32_t n,std::uint32_t step,std::uint32_t selected,std::uint32_t active,std::uint32_t last,std::uint32_t keys,std::uint32_t commands,std::uint32_t storage,std::uint32_t qualified,std::uint32_t preserves,std::uint32_t live,std::uint32_t aux) noexcept {
 if(count==events.size()){++overflow;return;}events[count++]={logical_trace::sequence,inv,kind,begin,n,step,selected,active,last,keys,commands,storage,qualified,preserves,live,aux};
}
struct Dump final {~Dump(){std::fprintf(stderr,"SEED_POD events=%zu capacity=%zu overflow=%zu logical_sequence=%llu\n",count,events.size(),overflow,logical_trace::sequence);for(std::size_t j=0;j<count;++j){const auto&v=events[j];std::fprintf(stderr,"SEED_EVENT i=%zu seq=%llu inv=%llu kind=%u begin=%u count=%u step=%u selected=%u active=%u last=%u keys=%u commands=%u storage=%u qualified=%u preserves=%u live=%u aux=%u\n",j,v.seq,static_cast<unsigned long long>(v.invocation),v.kind,v.begin,v.count,v.step,v.selected,v.active,v.last,v.keys,v.commands,v.storage,v.qualified,v.preserves,v.live,v.aux);}}};Dump dump;
}
