from pathlib import Path
import importlib.util,json,os,sys,difflib,hashlib,subprocess
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OLD=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1'
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def args(p):
 x=load(p);return x.get('command',x)if isinstance(x,dict)else x
def prepare():
 source=R/'engine/models/qwen35/main.cc';text=source.read_text();assert b.pin(source)['sha256']=='9b73fe9afe325d139072a94632e26d739e2b3cb48b411320c0c5bed320e9b9e9'
 declaration='''
struct PrivatePreparationRow {
  unsigned role=0; bool generation=false; std::size_t requests=0,input_rows=0,slot=0,prior_uses=0,recorded=0,reused=0;
  double layout=0,batch=0,replay=0,prepare=0,submit=0,finish=0,total=0;
};
std::vector<PrivatePreparationRow> private_preparation_rows;
void private_emit_preparations(){
  std::cerr<<std::setprecision(17);
  for(const auto &row:private_preparation_rows)
    std::cerr<<"private_preparation role="<<row.role<<" generation="<<row.generation<<" requests="<<row.requests
      <<" input_rows="<<row.input_rows<<" slot="<<row.slot<<" prior_uses="<<row.prior_uses<<" recorded="<<row.recorded<<" reused="<<row.reused
      <<" layout_seconds="<<row.layout<<" batch_seconds="<<row.batch<<" replay_seconds="<<row.replay
      <<" prepare_seconds="<<row.prepare<<" submit_seconds="<<row.submit<<" finish_seconds="<<row.finish<<" total_seconds="<<row.total
      <<" deferred_until_after_original_run_endpoint=1 throughput_evidence=0\\n";
}
'''
 anchor='using Clock = std::chrono::steady_clock;';assert text.count(anchor)==1
 text=text.replace(anchor,anchor+'\n'+declaration,1)
 old='  model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role); model.submit_evaluations();'
 new='''  PreparationObservation private_preparation;
  const auto private_start=Clock::now();
  model.prepare_evaluations(std::span(inputs.data(), inputs.size()), &private_preparation, role);
  const auto private_prepared=Clock::now();
  const auto private_recorded=model.active_step->capture_recorded,private_reused=model.active_step->capture_reused;
  model.submit_evaluations();
  const auto private_submitted=Clock::now();'''
 assert text.count(old)==1;text=text.replace(old,new,1)
 old='    for (auto &call : calls) observe_generation_commits(*call.request);\n    throw;\n  }\n}\n\nvoid publish_generation_prompt'
 new='''    for (auto &call : calls) observe_generation_commits(*call.request);
    throw;
  }
  const auto private_finished=Clock::now();
  private_preparation_rows.push_back({static_cast<unsigned>(role),generation,calls.size(),calls[0].ids().size(),
      private_preparation.slot,private_preparation.phase_slot_prior_uses,private_recorded,private_reused,
      private_preparation.layout_seconds,private_preparation.batch_prepare_seconds,private_preparation.replay_prepare_seconds,
      std::chrono::duration<double>(private_prepared-private_start).count(),
      std::chrono::duration<double>(private_submitted-private_prepared).count(),
      std::chrono::duration<double>(private_finished-private_submitted).count(),
      std::chrono::duration<double>(private_finished-private_start).count()});
}

void publish_generation_prompt'''
 assert text.count(old)==1;text=text.replace(old,new,1)
 (D/'main.cc').write_text(text,encoding='utf-8');(D/'source.patch').write_text(''.join(difflib.unified_diff(source.read_text().splitlines(True),text.splitlines(True),fromfile='canonical/main.cc',tofile='private/main.cc')),encoding='utf-8')
 (D/'probe.cc').write_text('#include "main.cc"\nint main(int argc,char**argv){qwen35::private_preparation_rows.reserve(1024);const auto status=qwen35::run(argc,argv);qwen35::private_emit_preparations();return status;}\n',encoding='utf-8')
 b.save(D/'source-pins.json',dict(canonical=b.pin(source),overlay=b.pin(D/'main.cc'),patch=b.pin(D/'source.patch'),probe=b.pin(D/'probe.cc'),scope='Only private deferred timers/flat POD rows around original common prepare/submit/finish. No graph/math/resource/RNG changes. Not throughput evidence.'))

def compile_one(source,recipe,folder,extra=()):
 original=args(recipe);cmd=[original[0]];skip=False
 for word in original[1:]:
  if skip:skip=False;continue
  if word=='/sourceDependencies':skip=True;continue
  low=word.lower().replace('\\','/')
  if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
  if low.startswith('/i')and '/.scratch/'in low and low.endswith('/source'):continue
  cmd.append(word)
 cmd.extend(extra);cmd+=[str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(folder/'unit.obj')]
 assert[w for w in cmd if w.lower().endswith(('.cc','.cpp'))]==[str(source)]
 before={str(p):b.pin(p)for base in('include','src/graph','src/graph_batch','engine/inference','engine/models/qwen35')for p in(R/base).rglob('*')if p.is_file()and p.suffix in('.h','.cc')}
 b.execute(cmd,folder,b.environment(cmd[0]),240)
 deps=[Path(p).resolve()for p in load(folder/'dependencies.json')['Data']['Includes']];pins=[b.pin(p)for p in deps if p.is_relative_to(R)]
 changed=[row['path']for row in pins if row['path']in before and before[row['path']]!=row]
 b.save(folder/'source-pins.json',dict(source=b.pin(source),actual_dependencies=pins,changed_during_compile=changed));assert not changed
 return folder/'unit.obj'
def build():
 audit=load(D/'closure-audit.json');chosen=['src/graph/executable.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc'];replacements={}
 for i,rel in enumerate(chosen):
  row=next(r for r in audit['changed']if Path(r['source']['path'])==R/rel);obj=compile_one(R/rel,Path(row['record']),D/('product-'+str(i)))
  replacements[row['object']]=str(obj)
 app=compile_one(D/'probe.cc',OLD/'compile-command.json',D/'app',('/I'+str(R/'engine/models/qwen35'),'/I'+str(R)))
 report=compile_one(R/'engine/reporting/execution_report.cc',OLD/'compile-command.json',D/'report',('/I'+str(R)))
 old_app=str(OLD/'test.obj');link=[]
 for word in args(OLD/'link-command.json'):
  if word==old_app or word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:')):continue
  link.append(replacements.get(word,word))
 link+=[str(app),str(report),'/OUT:'+str(D/'link/hyle.exe')]
 b.execute(link,D/'link',b.environment(link[0]),120)
 native=OLD/'hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,D/'link'/native.name)
 b.save(D/'ready.json',dict(image=b.pin(D/'link/hyle.exe'),native=b.pin(D/'link'/native.name),replacements=replacements,source=b.read(D/'source-pins.json'),scope='Current BF16 app/report and4 current actual Graph/batch/CUDA-region TUs. Retained unchanged native BF16 templates and other compatible old provider objects. Not all quant modes or blanket full-SDK current-source certification.',SDK_builds=0,HTTP=0))

def run(name):
 ready=load(D/'ready.json');assert b.pin(Path(ready['image']['path']))==ready['image']
 mtp='mtp'in name;two='two-turn'in name;folder=D/name;assert not folder.exists()
 env=b.environment(args(OLD/'compile-command.json')[0]);env['PATH']=str(D/'link')+';'+load(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 cmd=[str(D/'link/hyle.exe'),'--backend','cuda','--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),'--capacity','1024','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','auto','--sampling','greedy','--mtp','on'if mtp else'off']
 if mtp:cmd+=['--mtp-max-drafts','1']
 cmd+=['--schedule',str(R/'.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt')]if two else['--steps','4']
 b.execute(cmd,folder,env,180)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='run':run(sys.argv[2])
 else:globals()[action]()
