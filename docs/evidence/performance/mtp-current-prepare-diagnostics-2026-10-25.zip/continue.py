from pathlib import Path
import difflib,importlib.util,sys
sys.dont_write_bytecode=True
D=Path('.scratch/mtp-performance-convergence-20261025/current-cuda').resolve();spec=importlib.util.spec_from_file_location('current',D/'check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=(D/'main.cc').read_text();assert s.count('  PreparationObservation private_preparation;')==1;s=s.replace('  PreparationObservation private_preparation;','  inference::PreparationObservation private_preparation;')
(D/'main2.cc').write_text(s,encoding='utf-8');(D/'probe2.cc').write_text((D/'probe.cc').read_text().replace('#include "main.cc"','#include "main2.cc"'),encoding='utf-8')
(D/'source2.patch').write_text(''.join(difflib.unified_diff((m.R/'engine/models/qwen35/main.cc').read_text().splitlines(True),s.splitlines(True),fromfile='canonical/main.cc',tofile='private/main2.cc')),encoding='utf-8')
m.b.save(D/'source2-pins.json',dict(canonical=m.b.pin(m.R/'engine/models/qwen35/main.cc'),overlay=m.b.pin(D/'main2.cc'),patch=m.b.pin(D/'source2.patch'),probe=m.b.pin(D/'probe2.cc'),first_instrumentation_failure='Bare PreparationObservation not available outside Model; private namespace qualification only. Original failure source/compile preserved.',scope='Deferred private preparation timers only; no throughput evidence or graph/math/state change.'))
app=m.compile_one(D/'probe2.cc',m.OLD/'compile-command.json',D/'app2',('/I'+str(m.R/'engine/models/qwen35'),'/I'+str(m.R)))
report=m.compile_one(m.R/'engine/reporting/execution_report.cc',m.OLD/'compile-command.json',D/'report',('/I'+str(m.R)))
audit=m.load(D/'closure-audit.json');replacements={}
for i,rel in enumerate(['src/graph/executable.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.cc','src/graph_provider_ggml_cuda/ggml_cuda_region.cc']):
 row=next(r for r in audit['changed']if Path(r['source']['path'])==m.R/rel);replacements[row['object']]=str(D/('product-'+str(i))/'unit.obj')
link=[replacements.get(w,w)for w in m.args(m.OLD/'link-command.json')if w!=str(m.OLD/'test.obj')and not w.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
link+=[str(app),str(report),'/OUT:'+str(D/'link/hyle.exe')];m.b.execute(link,D/'link',m.b.environment(link[0]),120)
import os
native=m.OLD/'hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,D/'link'/native.name)
m.b.save(D/'ready.json',dict(image=m.b.pin(D/'link/hyle.exe'),native=m.b.pin(D/'link'/native.name),replacements=replacements,source=m.b.read(D/'source2-pins.json'),scope='Current BF16 app/report and4 current actual Graph/batch/CUDA-region TUs. Retained unchanged native BF16 templates and other compatible old provider objects. Not all quant modes or blanket full-SDK current-source certification.',SDK_builds=0,HTTP=0))
