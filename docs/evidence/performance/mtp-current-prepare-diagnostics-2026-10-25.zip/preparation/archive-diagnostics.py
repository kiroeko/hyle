from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;R=D.parents[1];C=D/'current-cuda'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
s=read(C/'summary.json')
assert s['state']=='bounded_current_BF16_entries_and_preparation_diagnostics_passed'
assert all(v['process']['exit']==0 and not v['process']['timeout']for v in s['runs'].values())
assert all(not v['exported_work_differences']for v in s['runs'].values()if 'last24'in v)
archive=R/'docs/evidence/performance/mtp-current-prepare-diagnostics-2026-10-25.zip'
allowed={'.json','.cc','.h','.py','.log','.patch','.txt','.md'}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(C.rglob('*')):
  if p.is_file()and p.suffix in allowed and p.name!='live.json':z.write(p,p.relative_to(C).as_posix())
 for p in[D/'preparation.md',D/'preparation.json',Path(__file__)]:z.write(p,'preparation/'+p.name)
with zipfile.ZipFile(archive)as z:
 assert not any(Path(n).suffix.lower()in{'.exe','.obj','.lib','.dll','.pdb','.safetensors'}for n in z.namelist())
reports={}
for name,row in s['runs'].items():
 report=row['report'];work={key:report[key]for key in['generated_tokens','actual_graph_calls','actual_target_rows','live_committed_versions']}
 if report['mtp']:work.update({key:report[key]for key in['actual_draft_rows','draft_rounds','agreements','verified_target_rows']})
 reports[name]=dict(process=row['process'],work=work)
 if 'last24'in row:reports[name].update(last24=row['last24'],exported_work_differences=row['exported_work_differences'])
e=dict(state=s['state'],date=s['date'],scope=s['scope'],image=s['image'],input_adaptation=s['input_adaptation'],runs=reports,
 first_failures=s['first_failures'],IO_scope=s['IO_scope'],throughput_evidence=False,memory_evidence=False,
 conclusions=['Two actual entry checks and two separate two-turn diagnostics passed. Same exported work and MTP60/66 acceptance as the dated Oct24 window.',
  'Tail prepare+submit wall share is 4.191% ordinary and4.238% MTP in these diagnostic calls. It is neither measured total host cost nor an achievable speedup.',
  'finish includes GPU wait, completion and publication; default post-endpoint stderr and private clock overhead remain explicit.',
  'No current peer gap follows from these single diagnostic samples. Reestablish a contemporaneous clean ordinary/MTP baseline before choosing the major hotspot.'],
 next_action='Build a clean current consumer and use the existing single/two-turn ordinary/MTP four-arm12+4 protocol. Then attribute actual remaining GPU target/draft and host gaps; split replay only when its bounded cost warrants it.',
 retained_artifacts='Current working image/reporting+four refreshed Graph objects retained for the next baseline/profile. No SDK or weight copy; diagnostic source/first failures/logs archived.',
 archive=pin(archive),source_summary=pin(C/'summary.json'),SDK_builds=0,HTTP=0,product_performance_changes=0)
target=R/'docs/evidence/performance/mtp-current-prepare-diagnostics-2026-10-25.json'
target.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=pin(target),archive=pin(archive)),ensure_ascii=False))
