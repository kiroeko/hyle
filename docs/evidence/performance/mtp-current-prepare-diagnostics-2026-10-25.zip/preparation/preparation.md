# 下一阶段 CUDA 性能收敛准备（2026-10-25，只读）

- 本次没有编译、模型运行、benchmark、GPU profile、HTTP或SDK构建。实际GPU盘点：RTX4070 12GiB、driver617.14、CUDA13.3.73；MSVC14.50.35717。瞬时GPU占用不作为正式空闲或固定频率证明。
- 当前main身份、现存输入、peer及命令的精确pin见同目录 preparation.json；canonical main为8dfff214…，不是旧性能镜像。

## 最近真正测过的基线

正式窗口仍是2026-10-24，来源 docs/evidence/performance/qwen-mtp-single-and-multiturn-2026-10-24.json。

|负载|Hyle普通decode|peer普通decode|Hyle MTP decode|peer MTP decode|
|---|---:|---:|---:|---:|
|P154、单轮64输出|98.093|101.998|120.508|135.747|
|同一会话P154追加两轮、各64输出|98.082|101.590|125.465|139.519|

单位tok/s；各负载12个交错新进程测速，另4进程旁采内存。两轮prefill Hyle普通/MTP=3301.684/2792.392、peer=2410.144/2245.021；综合Hyle=92.967/114.806、peer=93.534/123.383。不能把此表当当前架构完成后的速度。
两轮Hyle MTP接受60/66、target验证132行；peer接受61/64、65次decode调用、129验证行，续文不同。普通公共差距与MTP额外工作必须分开，不用接受率粗暴折算全部墙差。

## 可以原样复用的输入、peer和计量

- 真实完整源 `C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors` 存在，4,548,221,488B。现有V1文本320角色/3,763,655,360B；MTP335角色/3,885,311,680B，identity4068044d…；不重做权重。
- `.scratch/qwen-mtp-window-20261022/inputs/{text,mtp}` 与原prompt.ids均在；P154。当前loader仍支持原V1；整源SHA本次没有重新扫描。
- 原两轮schedule `.scratch/qwen-mtp-final-window-20261024/natural-inputs/performance64.txt`：prompt154/generate64重复两次，C1024/N1/R1、prefixoff、direct、replayauto、greedy/EOS；MTP显式K1。
- peer `.scratch/qwen-mtp-final-window-20261024/peer-link1/peer.exe` 存在，原SHA433e7051…、同固定native core；原320/335 BF16 GGUF和双轮驱动保持。原peer不重建；原ready/runtime/link命令详见JSON。
- 原single/two-turn12+4计量和原PSAPI/PDH观察器可复用；旧脚本有不可变image pin，不能替换文件冒充新结果。新入口只重绑定当前image/当前report解析，原端点与四项口径保持。

## 最小增量构建与必须补齐的闭包边界

- 可复用完整应用link记录 `.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/link-command.json`，217个OBJ/LIB全部存在；其compile-command.json提供完整原CUDA+CPU宏/包含路径/优化与/W4/WX配置。
- 不运行旧 `build_geometry_cuda_check2.py`：它还是1TU旧接线，未纳入新的reporting.cc，也没有显式新CLI/runtime选择。旧image f0c744…不能当当前。
- 必须新编：一个正常CLI consumer TU（include当前main、调用qwen35::run）＋ `engine/reporting/execution_report.cc`；删除原test.obj，加入两新OBJ、无gtest，保其他原完整IO/资源/native闭包。运行显式 `--backend cuda --sampling greedy`；只有MTP臂加 `--mtp-max-drafts 1`。
- 217闭包仍pin旧Q30 graph_batch--batch/paged_append与ownerless executable。先按实际源/私有头记录选择已有current generic对象，必要只增量刷新真实不同TU；不能宣布“全部当前”或盲目只换main。CPU+CUDA factory最近224输入测试闭包也全在，但它是gtest closure，不应原封不动当正式应用。
- 原native CPU companion `geometry-cuda-current1/hyle_ggml_cpu_gdn_scale_v3.dll` SHA6652209e…保同目录硬链接；CUDA原库/runtime按原environment；不复制SDK、不拉Torch/权重、不重编native模板。

## 首个有界定位动作（待根确认架构阶段结束）

1. 先形成上述当前可用image，跑原P154＋4仅做入口/计账检查；随后当前普通与K1各一个真实两轮诊断进程，复用现有PreparationObservation，保每回合slot、prior uses、role、layout/batch/replay、submit、finish及完整工作行数。所有诊断日志在原host端点后输出，单独标非TPS；不强迫两臂输出一致。
2. 先回答公共host准备是否仍占可观测墙时：main.cc prepare_evaluations:3560–3790；现有batch桶涵盖 reset_configuration、layout/append元数据准备与绑定，replay桶含合法失效/record/reuse。若仍显著，再只给 src/graph_batch/batch.cc:935 prepare_all 的reset/config/metadata等待、src/graph/executable.cc:9448 prepare_replay加私有分段，区分CPU工作和等待；不先删除等待、epoch或读者权限。
3. 若该公共成本仍真热，首个实现候选仅是纯整数页表准备scratch：target new_ids/old_query、draft query/old_ptr/next_ptr/old_ids/next_ids现在仍局部vector；main:3475/3640处与原InputPreparationScratch共同边界自然。先证明分配/构造实际占比，再冷reserve/reuse；保串行carrier guard、不同target/draft寿命，绝不缓存NodeLayout/PagedArenaRead/lease/ready。若占比很小就关闭，不承诺这能填10%MTP差距。

## 已有事实约束下一步

- 旧最后24轮prepare中位560.55µs（layout102.55/batch151.5/replay238.3）、submit92.85µs；finish含GPU等待，中位不能相加，也不能用旧版数值推当前收益。
- 旧MTP图738kernel＋135次D2D/39.73MB，copy活动0.137ms；36次1MiB GDN独立快照不能直接删，既有同容量/旧读者反证保留。最后24轮无新增allocation/instantiate；不再假设每token分配原生图。
- 只有MTP仍慢时，另列draft→target→修复/发布/小结果回读的实际段与target/draft总行；不能从普通共同慢项、旧92.466%投影GPU占比或graph-launch计数推出MTP主因。
- Top1、行拆、Lt、typed-MMVF和默认快照复制候选本轮均已关闭；不重开。完成当前普通/MTP的定点归因后，再依原12+4单轮/两轮四臂协议更新正式速度与空间，禁止和Oct24合池归因架构提速。

根已确认：RequestWindow的native-program-fixed/archive/route.lib与native-region-fixed2/compile/unit.obj仅属Vulkan，不可替换CUDA闭包。当前仍先完成共同turn progress架构切片；本准备到此停止，正式性能保持pending，不再继续缓存考古。
