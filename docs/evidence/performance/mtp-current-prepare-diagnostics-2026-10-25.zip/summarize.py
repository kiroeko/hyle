from pathlib import Path
import json,statistics,hashlib
R=Path.cwd();D=R/'.scratch/mtp-performance-convergence-20261025/current-cuda';old=json.loads((R/'docs/evidence/performance/qwen-mtp-single-and-multiturn-2026-10-24.json').read_text())['windows']['two_turns']['actual_work'];out={}
for kind in ['plain-entry2','mtp-entry','plain-two-turn','mtp-two-turn']:
 r=[json.loads(s)for s in(D/kind/'stdout.log').read_text().splitlines()if s.startswith('{')][-1]
 record=dict(process=json.loads((D/kind/'process.json').read_text()),report=r)
 if'two-turn'in kind:
  rows=[]
  for line in(D/kind/'stderr.log').read_text().splitlines():
   if line.startswith('private_preparation '):rows.append({k:float(v)if k.endswith('_seconds')else int(v)for k,v in(w.split('=',1)for w in line.split()[1:])})
  decoded=[p for p in rows if p['generation']];tail=decoded[-24:]
  scalar=['layout_seconds','batch_seconds','replay_seconds','prepare_seconds','submit_seconds','finish_seconds','total_seconds']
  median={k:statistics.median(p[k]for p in tail)for k in scalar};sums={k:sum(p[k]for p in tail)for k in scalar}
  reference=old['hyle_mtp'if'mtp'in kind else'hyle_plain']['exported_work'];expected_keys=['actual_graph_calls','actual_target_rows','verified_target_rows','generated_decode_tokens','prefill_target_rows','pending_flushed_tokens','turn_count'];expected_keys+=['actual_draft_rows','prefill_draft_rows','draft_rounds','agreements']if'mtp'in kind else[]
  workdiff={k:[reference[k],r[k]]for k in expected_keys if reference[k]!=r[k]};assert not workdiff
  if'mtp'in kind:assert reference['accepted_drafts']==r['consumed_drafts']==60
  record.update(diagnostics=rows,last24=dict(rows=24,median_seconds=median,sum_seconds=sums,capture_recorded=sum(p['recorded']for p in tail),capture_reused=sum(p['reused']for p in tail),prepare_bucket_wall_share=sums['prepare_seconds']/sums['total_seconds'],prepare_plus_submit_bucket_wall_share=(sums['prepare_seconds']+sums['submit_seconds'])/sums['total_seconds']),same_Oct24_exported_work_fields=expected_keys,same_Oct24_accepted60='mtp'in kind,exported_work_differences=workdiff)
 assert r['live_committed_versions']==0 and r['generated_tokens']==(128 if'two-turn'in kind else 4)
 out[kind]=record
summary=dict(state='bounded_current_BF16_entries_and_preparation_diagnostics_passed',date='2026-10-25',image=json.loads((D/'ready.json').read_text()),input_adaptation=json.loads((D/'input-adaptation.json').read_text()),runs=out,first_failures=[dict(stage='private app compile',record='app/process.json',cause='Missing namespace qualifier for instrumentation-only PreparationObservation, corrected only in private main2.cc/app2. No product source change.'),dict(stage='first plain entry',record='plain-entry/process.json',cause='Old V1 manifest is not supported by current prepared V2 input. Rebound to existing V2 after exact335-role source-range/codec and P154 equality; no model work in first failure.')],scope='Current selected BF16 math app/report and4 truly changed Graph/batch/CUDA-region source TUs, existing native BF16 templates/compatible provider closure. No blanket current SDK or new quant-mode certification. Four actual processes:2short entries+2separate two-turn diagnostic processes, no peer run/profile/formal TPS window.',throughput_evidence=False,memory_evidence=False,SDK_builds=0,HTTP=0,product_changes=0,next_action='Only split current prepare_replay CPU/driver work at existing begin/preparation bindings, validate transfer routes, provider cold prepare and capture qualification/record/reuse boundaries before any optimization. This is largest current host preparation sub-bucket; do not remove permissions, epochs or waits. Retain ordinary vs MTP accounting and actual work; finish includes GPU wait and is not host-only. No Top1/MMVF/Lt/copy reopen.')
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(state=summary['state'],short_entries=[out[k]['report']['generated_tokens']for k in ['plain-entry2','mtp-entry']],tail24={k:{'median_us':{a:round(v*1e6,2)for a,v in out[k]['last24']['median_seconds'].items()},'prepare_wall_share':out[k]['last24']['prepare_bucket_wall_share'],'prepare_plus_submit_wall_share':out[k]['last24']['prepare_plus_submit_bucket_wall_share'],'recorded':out[k]['last24']['capture_recorded'],'reused':out[k]['last24']['capture_reused']}for k in ['plain-two-turn','mtp-two-turn']}),indent=2))

