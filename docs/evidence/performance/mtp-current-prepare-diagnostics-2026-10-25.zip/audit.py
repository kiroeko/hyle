from pathlib import Path
import hashlib,json
R=Path.cwd();D=R/'.scratch/mtp-performance-convergence-20261025/current-cuda';LINK=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/link-command.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def canonical(p):
 p=Path(p).resolve()
 if any(p.is_relative_to(R/d)for d in('src','include','engine')):return p
 text=p.as_posix()
 for marker,base in[('/src/',R/'src'),('/engine/',R/'engine'),('/hyle/',R/'include/hyle')]:
  if marker in text:
   q=base/text.rsplit(marker,1)[1]
   if q.is_file():return q
 return None
cache={}
def sha(p):
 p=str(p)
 if p not in cache:cache[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 return cache[p]
rows=[];unknown=[]
for arg in read(LINK):
 p=Path(arg)
 if not p.is_absolute()or p.suffix.lower()!='.obj':continue
 candidates=[p.parent/'identity.json',p.parent/'records'/p.stem/'identity.json']
 found=None
 for path in candidates:
  if not path.is_file():continue
  rec=read(path)
  if isinstance(rec,dict)and isinstance(rec.get('object'),dict)and Path(rec['object'].get('path','')).resolve()==p.resolve():found=(path,rec);break
 if not found:unknown.append(str(p));continue
 path,rec=found;changes=[]
 for pin in[rec.get('source',{}),*rec.get('dependencies',[])]:
  if 'path'not in pin or'sha256'not in pin:continue
  actual=canonical(pin['path'])
  if actual and sha(actual)!=pin['sha256']:changes.append(dict(path=actual.relative_to(R).as_posix(),before=pin['sha256'],after=sha(actual)))
 rows.append(dict(object=str(p),record=str(path),source=rec.get('source'),changed=changes))
result=dict(link=str(LINK),recorded=len(rows),unknown=unknown,changed=[r for r in rows if r['changed']],unchanged=[r for r in rows if not r['changed']],scope='Direct object recorded self-source/header identities only; archives and unrecorded native templates not blanket current certification.')
(D/'closure-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(recorded=len(rows),unknown=len(unknown),changed=[dict(source=r['source']['path'],files=[c['path']for c in r['changed']])for r in result['changed']]),indent=2))
