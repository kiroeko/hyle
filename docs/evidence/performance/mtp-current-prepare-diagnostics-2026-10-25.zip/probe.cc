#include "main.cc"
int main(int argc,char**argv){qwen35::private_preparation_rows.reserve(1024);const auto status=qwen35::run(argc,argv);qwen35::private_emit_preparations();return status;}
