from pathlib import Path
import argparse
import difflib
import hashlib
import importlib.util
import json
import os
import statistics
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[2]
OLD = R / '.scratch/qwen-mtp-final-window-20261024/typed-mmvf-m2-proposal'
ACT = R / '.scratch/compute-execution-refactor-2026-10-18/qwen35-layer0-probe/ffn-slice/candidate/prefill/07-post-attn-norm.bf16'
WEIGHT = Path('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors')
OFFSET = 1084498960
BYTES = 25165824

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, value): Path(p).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def pin(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def require(p): assert pin(p['path']) == p, p['path']
def module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def prepare():
    assert not (D / 'plan.json').exists(), 'Preserve original plan.'
    retained = read(OLD / 'commands1.json')
    for row in retained['sources'].values(): require(row)
    require(retained['owning_kernel'])
    host_old = (OLD / 'm2_typed_leaf.cc').read_text()
    native_old = (OLD / 'typed_mmvf_m2.cu').read_text()
    assert host_old.count('M=2,K=6144,N=2048') == 1
    assert host_old.count(r'\"k\":6144,\"n\":2048') == 1
    assert native_old.count('K = 6144, N = 2048') == 1
    host = host_old.replace('M=2,K=6144,N=2048', 'M=2,K=2048,N=6144').replace(r'\"k\":6144,\"n\":2048', r'\"k\":2048,\"n\":6144')
    native = native_old.replace('K = 6144, N = 2048', 'K = 2048, N = 6144')
    start, end = 'double gamma(', '\nstruct Device {'
    assert host_old[host_old.index(start):host_old.index(end)] == host[host.index(start):host.index(end)]
    (D / 'm2_wide_leaf.cc').write_text(host, encoding='utf-8')
    (D / 'typed_mmvf_m2_wide.cu').write_text(native, encoding='utf-8')
    patch = ''.join(difflib.unified_diff(host_old.splitlines(True), host.splitlines(True), fromfile=str(OLD / 'm2_typed_leaf.cc'), tofile=str(D / 'm2_wide_leaf.cc')))
    patch += ''.join(difflib.unified_diff(native_old.splitlines(True), native.splitlines(True), fromfile=str(OLD / 'typed_mmvf_m2.cu'), tofile=str(D / 'typed_mmvf_m2_wide.cu')))
    (D / 'source.patch').write_text(patch, encoding='utf-8')
    assert ACT.stat().st_size == 23 * 2048 * 2
    with WEIGHT.open('rb') as f:
        f.seek(OFFSET); data = f.read(BYTES)
    assert len(data) == BYTES
    original_range = dict(path=str(WEIGHT), offset=OFFSET, bytes=BYTES, sha256=hashlib.sha256(data).hexdigest())
    del data
    activation = pin(ACT)
    with ACT.open('rb') as f: selected = f.read(8192)
    commands = {}
    for tag, filename in [('host', 'm2_wide_leaf.cc'), ('native', 'typed_mmvf_m2_wide.cu')]:
        cmd = list(retained[tag]); oldsource = retained['sources'][tag]['path']
        assert cmd.count(oldsource) == 1
        cmd[cmd.index(oldsource)] = str(D / filename)
        if tag == 'host':
            cmd[cmd.index('/sourceDependencies') + 1] = str(D / 'host/dependencies.json')
            cmd = ['/Fo' + str(D / 'host/probe.obj') if a.startswith('/Fo') else '/Fd' + str(D / 'host/probe.pdb') if a.startswith('/Fd') else a for a in cmd]
        else:
            for flag, value in [('-MT', D / 'native/typed.obj'), ('-MF', D / 'native/dependencies.d'), ('-o', D / 'native/typed.obj')]:
                assert cmd.count(flag) == 1; cmd[cmd.index(flag) + 1] = str(value)
            cmd = ['-Xcompiler=-Fd' + str(D / 'native/typed.pdb') + ',-FS' if a.startswith('-Xcompiler=-Fd') else a for a in cmd]
        commands[tag] = cmd
    link = read(OLD / 'link2-command.json')['command']
    link = [str(D / 'host/probe.obj') if a == str(OLD / 'host1/probe.obj') else str(D / 'native/typed.obj') if a == str(OLD / 'native1/typed.obj') else a for a in link if not a.upper().startswith(('/OUT:', '/MAP:', '/PDB:', '/IMPLIB:'))]
    link += ['/OUT:' + str(D / 'link/m2-wide.exe'), '/MAP:' + str(D / 'link/m2-wide.map')]
    commands['link'] = link
    commands['run'] = [str(D / 'link/m2-wide.exe'), str(WEIGHT), str(OFFSET), str(ACT)]
    plan = dict(scope='One leaf screen only; no consumer integration, model, SDK, download or dual epilogue.',
        shape=dict(M=2, N=6144, K=2048), dtype='BF16 A/W/Y + F32 accumulation + one BF16 RNE final store',
        choices=['Lt_production_request1', 'whole_M2_typed_MMVF'], bank_count=4,
        weight_bytes_per_bank=BYTES, working_set_bytes=4*BYTES, graph_leaves=64, trials=5,
        choice_order='Rotates by trial; original unchanged two-choice protocol.',
        source_weight=dict(role='model.language_model.layers.0.mlp.gate_proj.weight', dtype='BF16', shape=[6144,2048], original_range=original_range),
        activation=dict(full_trace=activation, trace_shape=[23,2048], selected_shape=[2,2048], selected_byte_range=[0,8191], selected_sha256=hashlib.sha256(selected).hexdigest(),
            role='Actual original BF16 model layer0 post_attention_layernorm output, directly consumed by both gate/up projections.',
            limitation='Retained T23 prefill first2 rows, not freshly captured current T2 verifier activations. Leaf exploration cannot claim current model/decode performance.',
            trace_source=pin(R / '.scratch/compute-execution-refactor-2026-10-18/qwen35-layer0-probe/ffn-slice/01-main.cc'),
            trace_summary=pin(R / '.scratch/compute-execution-refactor-2026-10-18/qwen35-layer0-probe/summary.json')),
        independent_gate_unchanged=True, oracle='Independent F64 dot + original fixed gamma(2K+4) F32/FTZ bound + outward BF16 RNE endpoints; no baseline oracle/tolerance tuning.',
        original_commands=pin(OLD / 'commands1.json'), successful_link_template=pin(OLD / 'link2-command.json'),
        owning_kernel=retained['owning_kernel'], native_recipe=retained['native_recipe'],
        sources={tag:pin(D/filename)for tag,filename in [('host','m2_wide_leaf.cc'),('native','typed_mmvf_m2_wide.cu')]},
        commands=commands, actual_compile_scope='Exactly one host .cc and one CUDA .cu; only shape constants and JSON shape metadata differ from old leaf. Native kernel body, math gate, 4bank/64leaf/5trial method unchanged.',
        runtime=read(R / '.scratch/qwen-mtp-final-window-20261024/m2-down-leaf-proposal/plan2.json')['runtime_environment'])
    require(plan['runtime'])
    save(D / 'plan.json', plan)
    print(json.dumps(dict(plan=str(D/'plan.json'),state='prepared_not_compiled',activation=activation['path'],compile_tus=2)))

def execute(action):
    plan = read(D / 'plan.json')
    for p in plan['sources'].values(): require(p)
    require(plan['owning_kernel']); require(plan['runtime'])
    if action == 'build':
        b = module('retained_environment', R / '.scratch/mtp-extraction-regression-20261024/check.py')
        env = b.environment(plan['commands']['host'][0])
        env['PATH'] = str(Path(plan['commands']['native'][0]).parent) + os.pathsep + env['PATH']
        for tag in ('host','native','link'):
            out = D / tag; out.mkdir(exist_ok=False)
            b.execute(plan['commands'][tag], out / 'process', env, 240)
        save(D/'ready.json',dict(image=pin(D/'link/m2-wide.exe'),plan=pin(D/'plan.json'),host_object=pin(D/'host/probe.obj'),native_object=pin(D/'native/typed.obj'),SDK_builds=0))
        print('READY',flush=True)
    else:
        ready = read(D/'ready.json'); require(ready['image']); require(ready['plan'])
        require(plan['activation']['full_trace'])
        with WEIGHT.open('rb') as f: f.seek(OFFSET); data=f.read(BYTES)
        assert hashlib.sha256(data).hexdigest()==plan['source_weight']['original_range']['sha256']; del data
        out = D/'run1'; out.mkdir(exist_ok=False)
        q = module('retained_process', R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
        env=os.environ.copy();env.update(PATH=read(plan['runtime']['path'])['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
        result=q.execute(plan['commands']['run'],env,out/'process',timeout=120)
        summary=dict(passed=False,process=result,plan=pin(D/'plan.json'),scope=plan['scope'])
        if result['exit']==0 and not result['timed_out']:
            actual=read(out/'process/stdout.log')
            assert(actual['m'],actual['n'],actual['k'])==(2,6144,2048)
            assert actual['graph_leaves']==64 and actual['trials']==5 and actual['weight_bank_count']==4
            base,candidate=actual['choices']; assert[base['kind'],candidate['kind']]==plan['choices']
            assert all(c['BF16_outputs_checked']==12288 for c in actual['choices'])
            med0=statistics.median(base['device_ms_per_leaf']);med1=statistics.median(candidate['device_ms_per_leaf'])
            positive=med1<med0 and max(candidate['device_ms_per_leaf'])<min(base['device_ms_per_leaf'])
            summary.update(passed=actual['passed'],actual=actual,positive_leaf=positive,
                device_time_reduction_percent=(1-med1/med0)*100,
                decision='Report positive leaf to root; no consumer integration authorized.' if positive else 'Close this leaf candidate; no further samples or tuning.',
                limitations=[plan['activation']['limitation'],'Four identical original weight banks rotate working set; no PMU cache-miss/absolute cold bandwidth claim.','Profiled current role totals are descriptive, not promised recoverable wall time.'])
        save(out/'summary.json',summary)
        print(json.dumps(summary),flush=True)
        assert summary['passed'],'First run failure preserved; do not automatically retry.'

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','build','run']);args=parser.parse_args()
    if args.action=='prepare': prepare()
    else:execute(args.action)
