"""One offline decomposition of the existing last24 captured T2 targets."""
from pathlib import Path
import collections
import hashlib
import json
import sqlite3
import statistics
import zipfile

D = Path(__file__).resolve().parent
R = D.parents[2]
ARCHIVE = R / 'docs/evidence/performance/mtp-current-cost-attribution-2026-10-25.zip'
SQL_TARGETS = '''SELECT correlationId,MIN(start),COUNT(*)
 FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE COALESCE(graphId,0)>0
 GROUP BY correlationId HAVING COUNT(*)=? ORDER BY MIN(start)'''
SQL_KERNELS = '''SELECT k.start,k.end,s.value,k.gridX,k.gridY,k.gridZ
 FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.demangledName
 WHERE k.correlationId=? ORDER BY k.start'''
SQL_COPIES = '''SELECT start,end,bytes FROM CUPTI_ACTIVITY_KIND_MEMCPY
 WHERE correlationId=? ORDER BY start'''
SQL_MEMSETS = '''SELECT start,end FROM CUPTI_ACTIVITY_KIND_MEMSET
 WHERE correlationId=? ORDER BY start'''

def pin(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def summarize(values):
    return dict(count=len(values), mean=statistics.mean(values),
                median=statistics.median(values), min=min(values), max=max(values))

def union(intervals):
    merged=[]
    for start,end in sorted(intervals):
        if merged and start<=merged[-1][1]: merged[-1][1]=max(merged[-1][1],end)
        else: merged.append([start,end])
    return sum(end-start for start,end in merged)

archive=zipfile.ZipFile(ARCHIVE)
arms={}
for arm,kernel_count,wide,narrow,head in [
    ('hyle_mtp',738,(8,48,1),(8,16,1),(8,1940,1)),
    ('peer_mtp',727,(192,1,1),(64,1,1),(7760,1,1))]:
    name=next(n for n in archive.namelist() if '/'+arm+'/' in n and n.endswith('trace.sqlite'))
    raw=archive.read(name)
    db=sqlite3.connect(':memory:'); db.deserialize(raw)
    all_targets=db.execute(SQL_TARGETS,(kernel_count,)).fetchall()
    selected=all_targets[-24:]
    assert len(selected)==24
    values=collections.defaultdict(list);names=collections.defaultdict(set)
    observed_counts=collections.defaultdict(set)
    for cid,_,_ in selected:
        kernels=db.execute(SQL_KERNELS,(cid,)).fetchall()
        assert len(kernels)==kernel_count
        copies=db.execute(SQL_COPIES,(cid,)).fetchall()
        memsets=db.execute(SQL_MEMSETS,(cid,)).fetchall()
        groups=collections.defaultdict(int);counts=collections.Counter()
        for start,end,kernel,x,y,z in kernels:
            matrix=any(t in kernel for t in ('gemm','gemv','mul_mat_f','mul_mat_vec_f'))
            key='other_kernels'
            if matrix:
                grid=x,y,z
                key='N6144_K2048' if grid==wide else 'N2048_mixedK' if grid==narrow else 'vocabulary_head' if grid==head else 'other_matrix'
                names[key].add(kernel)
            groups[key]+=end-start;counts[key]+=1
        assert counts['N6144_K2048']==66 and counts['N2048_mixedK']==66
        assert counts['vocabulary_head']==1 and counts['other_matrix']==54
        groups['two_main_body_groups']=groups['N6144_K2048']+groups['N2048_mixedK']
        groups['all_kernel_activity']=sum(end-start for start,end,*_ in kernels)
        groups['copy_activity']=sum(end-start for start,end,_ in copies)
        intervals=[(start,end) for start,end,*_ in kernels+copies+memsets]
        groups['busy_union']=union(intervals)
        groups['gpu_span']=max(end for _,end in intervals)-min(start for start,_ in intervals)
        groups['within_graph_unoccupied']=groups['gpu_span']-groups['busy_union']
        for key,value in groups.items():values[key].append(value/1e6)
        for key,value in counts.items():observed_counts[key].add(value)
        values['copy_bytes'].append(sum(size for _,_,size in copies))
        values['copy_count'].append(len(copies))
    arms[arm]=dict(archive_member=name,sqlite_bytes=len(raw),sqlite_sha256=hashlib.sha256(raw).hexdigest(),
        captured_target_count=len(all_targets),selected_target_count=24,
        selected_correlation_ids=[cid for cid,_,_ in selected],
        first_selected_kernel_start_ns=selected[0][1],
        ms={key:summarize(value)for key,value in values.items() if key not in ('copy_bytes','copy_count')},
        copy_bytes=summarize(values['copy_bytes']),copy_count=summarize(values['copy_count']),
        kernel_counts_per_graph={key:sorted(value)for key,value in observed_counts.items()},
        matrix_kernel_names={key:sorted(value)for key,value in names.items()})
    db.close()

h,p=(arms[name]['ms'] for name in ('hyle_mtp','peer_mtp'))
deltas={key:dict(H_mean_ms=h[key]['mean'],P_mean_ms=p[key]['mean'],
    H_minus_P_mean_ms=h[key]['mean']-p[key]['mean'],
    H_median_ms=h[key]['median'],P_median_ms=p[key]['median'])for key in h}
assert abs(sum(deltas[key]['H_minus_P_mean_ms'] for key in
    ('N6144_K2048','N2048_mixedK','vocabulary_head','other_matrix','other_kernels'))-
    deltas['all_kernel_activity']['H_minus_P_mean_ms'])<1e-12
result=dict(status='offline_complete_no_new_candidate',source=pin(Path(__file__)),archive=pin(ARCHIVE),
    scope='Each own process last24 captured T2 target launches, matched by actual kernel count and runtime correlationId. No cross-process timestamp subtraction.',
    SQL=dict(targets=SQL_TARGETS,kernels=SQL_KERNELS,copies=SQL_COPIES,memsets=SQL_MEMSETS),
    grouping=dict(N6144_K2048='66 physical projections:24gate+24up+18GDNqkv;Hgrid(8,48,1) directLt,peergrid(192,1,1) nativeMMF.',
        N2048_mixedK='66 physical projections:24down K6144 plus42 K2048 GDNz/out+attentiono;Hgrid(8,16,1),peergrid(64,1,1). Deliberately not split further.',
        vocabulary_head='One target vocabulary projection per graph;Hgrid(8,1940,1),peergrid(7760,1,1). Separate captured draft graphs are excluded.',
        other_matrix='54 smaller/Q projections; retained asone actual group,not a new candidate.',
        source_anchors=['main.cc:2369,2425-2430,2448-2473,877-884','V2 manifest GGGAGGGAGGGAGGGAGGGAGGGA andoriginalBF16 Wgeometry','default_policy.cc:49-52,119-157']),
    arms=arms,comparison=deltas,
    correction='Earlier H4.122/P4.257ms was only each last single target. It does not describe the24target window. Earlier6.734/6.387ms was allcapturedtarget mean activity;10.876/10.425ms was allcapturedtarget median busyunion. Do not mix them or subtract medians as additive budgets.',
    conclusion='In this consistent warm24 window,N6144/K2048 explains the two-main-body-group positive mean difference;N2048mixedK offsets it slightly. Stop further shape subdivision. The newly screened whole-M2 MMVF leaf is already closed and no implementation candidate is opened.',
    limits=['Hyle body BF16 A/W/Y withF32 accumulation differs from peer nativeMMF BF16 W +F32 A/Y; equal geometry is not identical numerical arithmetic or a promise of recoverable wall time.',
        'Different natural continuations/accepts/context lengths:24 ownprocess target calls are not token-aligned pairedsamples. All selected calls are T2,not wholedecode.',
        'Kernelactivitysums are additive descriptively;busyunion includes overlaps withcopy/memset. Group medians do not sum to median total. Within-graph emptyspace is not purehosttime.',
        'Capturedonly decomposition intentionally excludes eager target/draft. Wholetrace peer has3 uncapturedtarget and11 uncaptureddraft calls;H66/P62 capturedtarget counts are not logicalcall totals.',
        'Peer zero capturedgraph D2D does not mean zero totaltransfer: original eager/intergraph D2H remains outside these pertargetgraph buckets; no complete-transfer advantage claimed.',
        'BothMTP traces reportedCUPTI invalidGraph/NodeID queries(H250/P692),driver13.4 unsupported fallback13.3. Runtime correlation andobserved signatures support these buckets,not completeoriginal graphlineage certification.',
        'No new GPU,compiler,model,download,profiler,PMU,formalTPSsample or productedit. No new candidate.'])
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],comparison=deltas),indent=2))
