from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent; B=D.parent; R=B.parents[1]; L=B/'m2-wide-leaf'
P=R/'docs/evidence/performance/mtp-body-route-attribution-2026-10-25.json'; Z=P.with_suffix('.zip')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
assert not P.exists()and not Z.exists()
body=read(D/'result.json'); native=read(D/'native-api.json'); leaf=read(L/'proof-summary.json'); cleanup=read(L/'cleanup-candidates.json')
assert cleanup['count']==4 and cleanup['logical_bytes']==1559263
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    with zipfile.ZipFile(L/'proof.zip')as source:
        assert source.testzip()is None
        for member in source.namelist(): out.writestr('leaf/'+member,source.read(member))
    for p in sorted(D.iterdir()):
        if p.is_file(): out.write(p,'body/'+p.name)
result=dict(status='bounded_body_attribution_and_leaf_screen_complete_no_product_change',date='2026-10-25',
    baseline='docs/evidence/performance/mtp-current-single-and-multiturn-2026-10-25.json',
    source_trace='docs/evidence/performance/mtp-current-cost-attribution-2026-10-25.json',
    body=body,native_API=native,leaf=dict(proof=leaf,result=read(L/'run1/summary.json'),route_review=read(L/'route-review.json')),
    provider_source_review=dict(source=pin(R/'src/compute_provider_ggml_cuda/tensor_program.cc'),
        facts=['MatMul support accepts same BF16 A/W/Y and F32 accumulation;M1 has direct typed BF16 vector lowering.',
               'M2 retains BF16 A, uses ggml_mul_mat F32 internal Y and as_output BF16 Cast. Merely preferring that provider does not select original F32-activation MMF; native dispatcher uses cuBLAS for non-F32 src1.',
               'Explicitly widening small A could reach original MMF and preserve original output BF16 Cast. No measured benefit supports introducing those extra casts in this batch.',
               'Direct typed MMF requires type propagation through dispatch/input/output templates; it is not an existing switch or accepted implementation. No new API or vendor algorithm fork is introduced.'],
        anchors=['tensor_program.cc:371-381,741-775,1119-1133','third_party/ggml_cuda_runtime/patches.json final dispatcher','native mmf.cu:14-31 and mmf.cuh:51,125,208,282']),
    decisions=['Close wide-M2 typed MMVF: five intervals overlap, only0.95% median difference; no consumer integration or further repeats.',
               'Do not infer all-window speed from a last single target. Same warm24 grouping localizes most body activity difference to66 N6144/K2048 projections.',
               'Runtime API returns for13GraphExecUpdate calls are0; out-result and native lineage remain unknown. No evidence of API-error fallback for those13calls.',
               'Retain original canonical route, BF16 boundaries, default K1 and complete comparison endpoints. This batch establishes attribution and negative screens, not a tokens/s improvement.'],
    limits=['Warm target groups are each process own last24 captured T2 targets; they are not aligned cross-process timestamps or complete eager decode.',
            'BF16 versus F32 activation/output carriers, different continuations/contexts and driver/tool graph-ID warnings remain; activity differences are not recoverable speed promises.',
            'The numerical leaf uses true original post-attention-normalized input from a T23 prefill, first two rows; it is not a current T2 verifier input.',
            'Leaf C4819 warnings and13BF16 output bit differences are preserved; both fixed numerical gates pass, no full-model quality or bitwise claim.',
            'CUDA driver table is absent; returnValue0 is an API fact, not a recovered UpdateResult structure. Runtime intervals are not added to driver/kernel/coldgap durations.'],
    archive=pin(Z),archive_layout=dict(leaf='Original leaf proof payloads under leaf/',body='Offline scripts/results/SQL under body/'),
    leaf_cleanup=dict(performed=False,inventory=cleanup,policy='Root test.ps1 exact-file preview/Apply; shared caches, sources, commands, data and original clean baseline retained.'),
    new_model_processes=0,new_leaf_processes=1,new_SDK_builds=0,new_HTTP=0,new_product_changes=0,GPU_released=True)
P.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(public=pin(P),archive=pin(Z))))
