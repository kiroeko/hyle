"""One private provider object plus the already tested CUDA leaf in current2a94."""
import ast
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[2]
B=R/'.scratch/inference-current-closure-20261026'
OLD=R/'.scratch/dense-linear-f32-20261024/cublas'
spec=importlib.util.spec_from_file_location('local_host_recipe',R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
pin,save,execute=h.pin,h.save,h.execute
def read(p): return json.loads(p.read_bytes())
def exact(row):
    got=pin(Path(row['path']))
    assert got['bytes']==row['bytes'] and got['sha256']==row['sha256'],row['path']
def prerequisites():
    ready=read(B/'ready-current.json')
    assert ready['image']['sha256']=='2a94f0b297d00825c6470138c6daf472868161ff76a0dea15477f0c57b58b7a6'
    for key in ('image','native','runtime','link_inputs','command'): exact(ready[key])
    for row in read(B/'link-inputs-current.json'): exact(row)
    pins=read(W/'source-pins.json')
    for row in pins['files']: exact(row['before']);exact(row['after'])
    for key in ('native_leaf_object','native_leaf_source','native_leaf_header'):exact(pins[key])
    identity=read(OLD/'identity.json')
    assert identity['source']==pins['files'][0]['before']
    return ready,identity,pins
def build():
    ready,identity,pins=prerequisites()
    out=W/'attempt1'
    assert not out.exists()
    out.mkdir()
    command=list(identity['command'])
    compiler=command[0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    source=Path(pins['files'][0]['after']['path'])
    stage=out/'compile';obj=stage/'unit.obj'
    assert command.count(identity['source']['path'])==1
    command[command.index(identity['source']['path'])]=str(source)
    command[command.index('/sourceDependencies')+1]=str(stage/'dependencies.json')
    command=[('/Fo'+str(obj)) if arg.startswith('/Fo') else ('/Fd'+str(stage/'unit.pdb')) if arg.startswith('/Fd') else arg for arg in command]
    original_dep=read(OLD/'dependencies.json')['Data']
    before_headers=[pin(Path(p)) for p in dict.fromkeys(original_dep['Includes'])]
    save(out/'precompile-dependencies.json',before_headers)
    compiled=execute(command,env,stage,timeout=120)
    dep=read(stage/'dependencies.json')['Data']
    actual=[pin(Path(p)) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
    save(stage/'actual-dependencies.json',actual)
    got={Path(row['path']).resolve():row for row in actual}
    assert {Path(p).resolve() for p in dep['Includes']}=={Path(p).resolve() for p in original_dep['Includes']}
    for row in before_headers:
        assert got[Path(row['path']).resolve()]['sha256']==row['sha256']
    oldobj=identity['object']['path']
    original=read(B/'link-current/process/command.json')['command']
    assert original.count(oldobj)==1
    args=[str(obj) if arg==oldobj else arg for arg in original if not arg.lower().startswith(('/out:','/pdb:','/implib:','/map:'))]
    native=pins['native_leaf_object']['path']
    assert native not in args
    args.append(native)
    after=[pin(Path(a)) for a in args if Path(a).is_absolute() and Path(a).suffix.lower() in ('.obj','.lib')]
    before=read(B/'link-inputs-current.json')
    assert len(after)==len(before)+1
    assert [x for x in before if x['path']!=oldobj]==[x for x in after if x['path'] not in (str(obj),native)]
    save(out/'link-inputs.json',after)
    image=out/'link/hyle.exe'
    linked=execute([*args,'/OUT:'+str(image),'/IMPLIB:'+str(image.with_suffix('.lib')),'/PDB:'+str(image.with_suffix('.pdb'))],env,image.parent,timeout=120)
    dll=Path(ready['native']['path']);os.link(dll,image.parent/dll.name)
    runtime=read(B/'runtime-current.json');runtime['PATH']=str(image.parent)+os.pathsep+runtime['PATH']
    runtime['original_runtime_receipt']=pin(B/'runtime-current.json')
    save(out/'runtime.json',runtime)
    result={'status':'READY_PRIVATE_EXACT_M2_TYPED_MMF_NO_RUN','image':pin(image),
      'baseline_ready':pin(B/'ready-current.json'),'baseline_image':ready['image'],
      'source_pins':pin(W/'source-pins.json'),'source':pin(source),'host_object':pin(obj),
      'native_object':pins['native_leaf_object'],'original_native_runtime':ready['native'],
      'runtime':pin(out/'runtime.json'),'actual_dependencies':pin(stage/'actual-dependencies.json'),
      'link_inputs':pin(out/'link-inputs.json'),'absolute_inputs':len(after),'unchanged_absolute_inputs':len(before)-1,
      'processes':{'compile':compiled,'link':linked},'new_host_TUs':1,'new_CUDA_TUs':0,'SDK_builds':0,
      'limits':'Private only; no public operation or GGML ABI change. Existing exact M2 BF16 qualifications only; other operations retain Lt. Bit differences may alter continuation and acceptance.'}
    save(out/'ready.json',result)
    print(json.dumps(result,indent=2))
def functions():
    path=B/'behavior.py';tree=ast.parse(path.read_text());ns={}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('normalize','differences')],type_ignores=[]),str(path),'exec'),ns)
    return ns['normalize'],ns['differences']
def report(path):return json.loads(next(line for line in reversed(path.read_text().splitlines()) if line.startswith('{')))
def run():
    ready=read(W/'attempt1/ready.json')
    for key in ('image','source','source_pins','host_object','native_object','runtime','link_inputs'):exact(ready[key])
    for row in read(W/'attempt1/link-inputs.json'):exact(row)
    baseline=next(row for row in read(B/'full-window/two-turn-timing/runs.json') if row['arm']=='hyle_mtp')
    folder=Path(baseline['folder'])
    command=[ready['image']['path'],*baseline['process']['command'][1:]]
    runtime=read(W/'attempt1/runtime.json');env=dict(os.environ)
    env['PATH']=runtime['PATH'];env.update(runtime.get('configured_flags',{}))
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    save(W/'attempt1/run-plan.json',{'baseline_command':pin(folder/'command.json'),
      'baseline_stdout':pin(folder/'stdout.log'),'baseline_stderr':pin(folder/'stderr.log'),
      'normalization':pin(B/'behavior.py'),'original_argv_unchanged':command[1:]==baseline['process']['command'][1:],
      'image':ready['image'],'runtime':ready['runtime'],'one_original_K1_two_turn_process':True,'not_TPS':True,
      'independent_source_review':'Architecture reviewer message confirmed actual168c4050 source no blocker; ROOT explicitly authorized run without waiting for memo file.'})
    process=execute(command,env,W/'attempt1/run',timeout=120)
    print('GPU_TERMINAL_RELEASED',process['pid'],process['exit'],flush=True)
    normalize,differences=functions()
    actual,old=report(W/'attempt1/run/stdout.log'),report(folder/'stdout.log')
    delta=differences(normalize(old),normalize(actual))
    save(W/'attempt1/run/non-time-differences.json',delta)
    clocks=lambda text:re.sub(r'\b(\w*seconds)=\S+',r'\1=<TIME>',text)
    stderr_equal=clocks((W/'attempt1/run/stderr.log').read_text())==clocks((folder/'stderr.log').read_text())
    summary={'status':'PASS_SAME_ORIGINAL_WORK' if not delta and stderr_equal else 'NON_TIME_WORK_DIFFERENCES_RECORDED',
      'process':process,'ready':pin(W/'attempt1/ready.json'),'image':ready['image'],'baseline_image':ready['baseline_image'],
      'non_time_difference_count':len(delta),'stderr_equal_after_only_original_clock_values_removed':stderr_equal,
      'non_time_differences':pin(W/'attempt1/run/non-time-differences.json'),
      'actual_work':{k:actual[k] for k in ('generated_tokens','actual_graph_calls','prefill_target_rows','verified_target_rows')},
      'baseline_work':{k:old[k] for k in ('generated_tokens','actual_graph_calls','prefill_target_rows','verified_target_rows')},
      'raw':[pin(W/'attempt1/run/stdout.log'),pin(W/'attempt1/run/stderr.log')],
      'GPU_released':True,'paired_screen_authorized_here':False,'new_leaf_samples':0,'product_edits':0}
    save(W/'attempt1/summary.json',summary)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':{'build':build,'run':run}[sys.argv[1]]()
