"""Adapt retained screen source without importing its autorun module."""
from pathlib import Path
import ast
import hashlib
import json

W=Path(__file__).resolve().parent
R=W.parents[2]
original=R/'.scratch/inference-synchronous-step-report-20261025/screen.py'
text=original.read_text()
def replace(a,b):
    global text
    assert text.count(a)==1,a
    text=text.replace(a,b)
replace("C = R / '.scratch/mtp-fixed-hidden-output-20261025/integrated'", "C = R / '.scratch/inference-current-closure-20261026'")
replace("control, candidate = read(C / 'ready.json'), read(W / 'cuda/ready.json')", "control, candidate = read(C / 'ready-current.json'), read(W / 'attempt1/ready.json')")
replace("original = read(B / 'two-turn-timing/02-hyle_mtp/command.json')['command']", "original = read(C / 'full-window/two-turn-timing/02-hyle_mtp/command.json')['command']")
replace("    app=candidate['app'], report=candidate['report'], runtime=pin(C / 'runtime.json'),\n    source_review=pin(W / 'product-pins.json'),\n    independent_review=pin(W / 'independent-review.json'),\n    original_command=pin(B / 'two-turn-timing/02-hyle_mtp/command.json'),", "    candidate_ready=pin(W / 'attempt1/ready.json'), runtime=pin(C / 'runtime-current.json'),\n    source_review=pin(W / 'source-pins.json'),\n    independent_review=pin(W / 'independent-review-architecture.json'),\n    original_command=pin(C / 'full-window/two-turn-timing/02-hyle_mtp/command.json'),")
replace("scope='Bounded frozen-be3 Hyle K1 two-turn report-only control/candidate screen; first pair '", "scope='Bounded current2a94 vs private31e189 exact-M2 typed-MMF Hyle K1 two-turn screen; first pair '")
replace("read(C / 'runtime.json')['PATH']", "read(C / 'runtime-current.json')['PATH']")
replace("            'Private synchronous step-report TU candidate; no canonical merge or full peer window.',", "            'Private exact dense BF16 M2 K2048 N6144 MMF provider candidate; all other operations original Lt. No canonical merge or peer window.',")
target=W/'screen.py'
assert not target.exists()
ast.parse(text)
target.write_text(text,encoding='utf-8')
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(W/'screen-recipe.json').write_text(json.dumps({'retained_source':pin(original),'adapted_source':pin(target),
 'math_statistic_and_clock_exclusions_unchanged':True,'new_model_samples':8,
 'timing_order':['control','candidate','candidate','control','control','candidate'],
 'memory_order':['control','candidate'],'autorun_module_imported':False},indent=2)+'\n',encoding='utf-8')
print(json.dumps(pin(target)))
