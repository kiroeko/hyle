"""Incremental host/three native owners of the paired MMVF header; no SDK rebuild."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('paired_projection_build_helpers',A/'typed-gating-suffix/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--native-only',action='store_true');args=p.parse_args()
    out=S/'checks/native1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    paths={arm:A/'quant-route-followup/checks/host1'/(arm+'-link-plan.json') for arm in ('cpu','tests','qwen')}
    bases={arm:c.read(path) for arm,path in paths.items()};meta=h.h.metadata(bases)
    owners={arm:{Path(meta[c.key(row['path'])]['source_path']).name:dict(meta[c.key(row['path'])],old_object=row)
        for row in base['inputs'] if c.key(row['path']) in meta} for arm,base in bases.items()}
    rows=[]
    for name in (() if args.native_only else ('ggml_cuda_region.cc','ggml_cuda_provider.cc','executable.cc')):
        owner=owners['qwen'][name];source=Path(owner['source_path']);tag=source.stem
        command=b.host_command(owner['command'],source,tag,out)
        command=['/FI'+str(S/'provider-version.h') if a.lower().startswith('/fi') and Path(a[3:]).name=='provider-version.h' else a for a in command]
        rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=command,object=str(out/(tag+'.obj')),source_name=name))
    for name in ('ggml-cuda.cu','unary.cu','mmvf.cu'):
        owner=owners['qwen'][name];source=S/'native-source/src/ggml-cuda'/name;tag=source.stem
        recipe=[];skip=False
        for arg in owner['command']:
            if skip:skip=False
            elif arg in ('-ccbin','--compiler-bindir'):skip=True
            elif not (arg.startswith(('-ccbin=','--compiler-bindir=')) or arg.startswith('-I') and ('.scratch' in arg or 'reference-windows' in arg)):recipe.append(arg)
        command=b.native_command(recipe,source,tag,out)
        command[1:1]=['-I'+str(S/'native-source'/rel) for rel in ('src/ggml-cuda','src','include')]
        rows.append(dict(tag=tag,kind='native',source=b.identity(source),command=command,object=str(out/(tag+'.obj')),source_name=name))
    recipe=c.read(A/'bf16-grouped-bank/checks/native1/grouped-test-identity.json')['command']
    if not args.native_only:
        source=ROOT/'tests/graph_provider_ggml_cuda/paired_projection_test.cc';tag='paired-projection-test'
        rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=b.host_command(recipe,source,tag,out),object=str(out/(tag+'.obj'))))
    # The real cached image inventory lacks these old shared-MMVF neighbors.
    for relative,tag in ([] if args.native_only else [('tests/graph_route_cuda/stable_silu_test.cc','dual-projection-neighbors'),
                         ('tests/compute_provider_ggml_cuda/bfloat_matvec_test.cc','bfloat-matvec-neighbors')]):
        source=ROOT/relative;command=b.host_command(recipe,source,tag,out)
        command[1:1]=['/external:I'+str(S/'native-source'/part) for part in ('include','src')]
        rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=command,object=str(out/(tag+'.obj')),extra_test=True))
    if not args.native_only:
        owner=owners['cpu']['region_provider_test.cc'];source=Path(owner['source_path']);tag='region-provider-test'
        rows.append(dict(tag=tag,kind='host',source=b.identity(source),command=b.host_command(owner['command'],source,tag,out),object=str(out/(tag+'.obj')),source_name=source.name))
    frozen=[]
    for name in (('native-source-freeze.json','native-header-closure.json','native-product-source-freeze.json','provider-version.h') if args.native_only else ('native-source-freeze.json','native-header-closure.json','native-product-source-freeze.json','graph-product-source-freeze.json','core-product-source-freeze.json','provider-version.h')):
        frozen.append(b.identity(S/name))
    for name in (('native-product-source-freeze.json',) if args.native_only else ('native-product-source-freeze.json','graph-product-source-freeze.json','core-product-source-freeze.json')):
        for row in c.read(S/name)['files']:
            frozen.extend((row['after'],row['snapshot']))
    frozen.extend(row['source'] for row in rows)
    frozen.extend(dict(path=row.get('source',row['path']),bytes=row['bytes'],sha256=row['sha256']) for row in c.read(S/'native-header-closure.json')['headers'])
    plan=dict(compile=rows,base_paths={k:str(v) for k,v in paths.items()},frozen=frozen,links={},host_TUs=sum(r['kind']=='host' for r in rows),native_TUs=sum(r['kind']=='native' for r in rows),SDK_rebuild=False,consumer_main_reused=True)
    plan_path=out/('native-only-plan.json' if args.native_only else 'plan.json')
    c.save(plan_path,plan)
    if not args.native_only:c.save(S/'latest-plan.json',dict(plan=str(plan_path)))
    print('PAIRED_PROJECTION_PLAN',len(rows),flush=True)
    if not args.build:return
    def check():
        for row in frozen:assert b.same(row),row['path']
    for base in bases.values():
        for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(bases['qwen']['command'],[r['path'] for r in bases['qwen']['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check();receipt_path=out/(row['tag']+'-identity.json')
        if args.resume and receipt_path.exists():
            old=c.read(receipt_path)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        if row['kind']=='host':
            deps=c.read(out/(row['tag']+'-deps.json'))['Data'];paths=[deps['Source'],*deps['Includes']]
        else:
            paths=[row['source']['path']]
            for line in (out/(row['tag']+'.d')).read_text(encoding='utf-8').splitlines()[1:]:
                value=line.strip().removesuffix('\\').strip().replace('\\ ',' ')
                if value:paths.append(value)
        result=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in dict.fromkeys(paths)])
        c.save(receipt_path,result);return row['tag'],result
    finished={};errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as error:errors.append(repr(error))
    c.save(out/('native-only-compile-summary.json' if args.native_only else 'compile-summary.json'),dict(passed=not errors,errors=errors))
    if errors:raise RuntimeError(errors)
    if args.native_only:
        print('PAIRED_NATIVE_OWNERS_BUILT',len(rows),flush=True);return
    for arm,base in bases.items():
        replacements={c.key(owners[arm][row['source_name']]['old_object']['path']):finished[row['tag']]['object'] for row in rows if 'source_name' in row and row['source_name'] in owners[arm]}
        lookup={c.key(r['path']):r for r in base['inputs']};lookup.update({c.key(r['path']):r for r in replacements.values()})
        command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if arm=='tests':
            assert 'paired_projection_test.cc' not in owners[arm]
            for tag in ('paired-projection-test','dual-projection-neighbors','bfloat-matvec-neighbors'):
                obj=finished[tag]['object'];command.insert(1,obj['path']);lookup[c.key(obj['path'])]=obj
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len(set(c.key(row['path']) for row in inputs))
        for row in inputs:assert b.same(row),row['path']
        check();prior_path=out/(arm+'-link-plan.json');image_path=out/(arm+'-image.json')
        unchanged=(args.resume and prior_path.exists() and image_path.exists() and c.read(prior_path)==dict(command=command,inputs=inputs) and b.same(c.read(image_path)))
        if unchanged:print('REUSE_LINK',arm,flush=True)
        else:c.execute(arm+'-link',command,env,out)
        check();c.save(prior_path,dict(command=command,inputs=inputs));c.save(image_path,b.identity(image))
        plan['links'][arm]=dict(command=command,inputs=inputs,image=str(image))
    c.save(out/'plan.json',plan);c.save(out/'summary.json',dict(passed=True,host_TUs=7,native_TUs=3,SDK_rebuild=False,consumer_main_reused=True))
    print('PAIRED_PROJECTION_BUILT',out,flush=True)

if __name__=='__main__':main()
