"""Conservative full-FFN liveness precedes pairing, as in native encode."""
from pathlib import Path
import difflib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('paired_native_source', S/'prepare_native.py')
n = importlib.util.module_from_spec(spec)
spec.loader.exec_module(n)
R = n.ROOT
NAME = 'src/ggml-cuda/ggml-cuda.cu'
HISTORY = S/'before-cold-ffn-priority-correction'


def main():
    assert not HISTORY.exists(), 'Correction already recorded'
    products = json.loads((S/'native-product-source-freeze.json').read_text())
    previous = json.loads((S/'native-source-freeze.json').read_text())
    for row in products['files']:
        path = R/row['name']
        assert n.identity(path) == row['after'], row['name']
        out = HISTORY/'product'/row['name']
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(path.read_bytes())
    for name in ['native-source-freeze.json','native-product-source-freeze.json',
                 'native-implementation-review.json','provider-version.h',
                 'source-combined-manifest.json','native-changes.diff','native-product-changes.diff']:
        out = HISTORY/name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes((S/name).read_bytes())
    for prefix in ['native-source','manifest-target-source']:
        out = HISTORY/prefix/NAME
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes((S/prefix/NAME).read_bytes())

    manifest = json.loads(n.PATCH.read_text())
    row = next(row for row in manifest['files'] if row['path'] == NAME)
    source = n.replay(row).decode()
    changes = []

    def edit(old, new):
        nonlocal source
        assert source.count(old) == 1, old[:100]
        source = source.replace(old, new, 1)
        changes.append(dict(before=old, after=new))

    old = '''static bool ggml_cuda_match_bf16_dual_projection(const ggml_cgraph * graph, int begin,
        int device, ggml_cuda_bf16_dual_projection_match & match) {'''
    new = '''static bool ggml_cuda_match_bf16_dual_projection(const ggml_cgraph * graph, int begin,
        int device, ggml_cuda_bf16_dual_projection_match & match, bool require_bound = true) {'''
    edit(old, new)
    old = '''    if (!ggml_cuda_bf16_dual_projection_closed(graph, begin, count, weight_view) ||
            !ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate, up, silu, dst, device)) {'''
    new = '''    // Cold liveness accepts a conservative structural superset: it never
    // grants execution eligibility or dereferences an unbound payload. Encode
    // retains the original precise device/layout/pointer checks below.
    if (!ggml_cuda_bf16_dual_projection_closed(graph, begin, count, weight_view) ||
            (require_bound && !ggml_cuda_can_fuse_bf16_dual_matvec_silu_mul(gate, up, silu, dst, device))) {'''
    edit(old, new)
    old = '''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        ggml_cuda_bf16_paired_projection_match pair;
        if (ggml_cuda_match_bf16_paired_projection(cgraph, i, cuda_ctx->device, false, pair)) {'''
    new = '''#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
        // Match encoder priority before considering the two-output prefix.
        // The original complete FFN also needs its raw reads held through Mul;
        // otherwise gallocr may reuse a dead projection input for that output.
        ggml_cuda_bf16_dual_projection_match full;
        if (cgraph->nodes[i]->op == GGML_OP_MUL_MAT &&
                cgraph->nodes[i]->type == GGML_TYPE_BF16 &&
                ggml_cuda_match_bf16_dual_projection(cgraph, i, cuda_ctx->device, full, false)) {
            for (const auto * read : {full.gate->src[0], full.up->src[0],
                                     full.gate->src[1], full.up->src[1]}) {
                keep(read, i + full.count - 1);
            }
            continue;
        }
        ggml_cuda_bf16_paired_projection_match pair;
        if (ggml_cuda_match_bf16_paired_projection(cgraph, i, cuda_ctx->device, false, pair)) {'''
    edit(old, new)
    row['edits'].extend(changes)
    row['after_sha256'] = n.sha(source.encode())
    assert n.replay(row) == source.encode()
    n.PATCH.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    combined = S/'source-combined-manifest.json'
    n.load('prepare_cuda_iq1_manifest').derive(n.UPSTREAM, S/'mixed-cpu-manifest.json',
        n.PATCH, R/'third_party/ggml_cuda_runtime/iq1-patches.json', combined)
    combined_row = next(row for row in json.loads(combined.read_text())['files'] if row['path'] == NAME)
    composed = n.replay(combined_row)
    (S/'native-source'/NAME).write_bytes(composed)
    (S/'manifest-target-source'/NAME).write_bytes(source.encode())
    (S/'cold-priority-correction.diff').write_text(''.join(difflib.unified_diff(
        (HISTORY/'native-source'/NAME).read_text().splitlines(True), composed.decode().splitlines(True),
        fromfile='before-correction/'+NAME,tofile='after-correction/'+NAME)), encoding='utf-8',newline='\n')
    for before in previous['files']:
        if before['name'] == NAME:
            before['after'] = n.identity(S/'native-source'/NAME)
            before['manifest_target_after'] = n.identity(S/'manifest-target-source'/NAME)
            before['added_edits'] += len(changes)
        else:
            assert n.identity(S/'native-source'/before['name']) == before['after']
    previous['product_after'] = n.identity(n.PATCH)
    previous['composition_inputs'][-1] = n.identity(combined)
    previous['correction_generator'] = n.identity(Path(__file__))
    previous['cold_priority_correction'] = dict(
        before=n.identity(HISTORY/'native-source-freeze.json'),
        diff=n.identity(S/'cold-priority-correction.diff'),
        reason='Root found pair cold continue could suppress full-FFN terminal read retention. Original full-FFN had no dedicated cold keep, so this also closes that older liveness gap. Cold structural liveness is conservative; encode still uses original strict bound eligibility.',
        only_new_native_compile_owner=NAME)
    diff = ''.join(''.join(difflib.unified_diff((S/'native-before'/v['name']).read_text().splitlines(True),
        (S/'native-source'/v['name']).read_text().splitlines(True),fromfile='before/'+v['name'],tofile='after/'+v['name'])) for v in previous['files'])
    (S/'native-changes.diff').write_text(diff,encoding='utf-8',newline='\n')
    previous['diff'] = n.identity(S/'native-changes.diff')
    n.save(S/'native-source-freeze.json', previous)
    print('CORRECTED MAIN', n.sha(composed))


if __name__ == '__main__':
    main()
