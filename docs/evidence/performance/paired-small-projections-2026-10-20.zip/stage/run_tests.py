"""Affected generic contraction and shared-MMVF neighbors; no all-library matrix."""
import argparse
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired_projection_tests',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('--destination',default='tests');p.add_argument('--arm',choices=['all','cpu','tests'],default='all');args=p.parse_args()
assert Path(args.destination).name==args.destination and args.destination.startswith('tests')
out=S/args.destination;out.mkdir(exist_ok=False);results={}
cpu=['GraphRegions.ProviderCanQueryContractibilityIncludingControlEdges','GraphRegions.ProviderContractibilityUsesOnlyCandidateSpan',
     'GraphRegions.CompilesAContractibleNonContiguousNodeSet','GraphRegions.SchedulesAContractedNodeSetAfterItsExternalPredecessor',
     'GraphRegions.ExcludesARegionThatWouldCycleWithAnAcceptedRegion','GraphRegions.DeclinedNonContiguousRegionExecutesLeafFallbacks',
     'GraphRegions.RejectsDuplicateAndForeignProposalNodes','GraphRegions.EffectOrderingCannotLeaveAndReenterAContractedRegion']
gpu=['GgmlCudaPairedProjection.*','GgmlCudaDualProjection.*','GgmlCudaBfloatMatvec.*',
     'CudaGroupedShared.SmallTokenDirectAndGraphKeepFloatActivationAndSubnormalBits',
     'CudaGroupedShared.OriginalBfloatBankHasNoWidenedBankAndDynamicDirectReuses64Submissions']
for arm,filters,count in [('cpu',cpu,8),('tests',gpu,12)]:
    if args.arm not in ('all',arm):continue
    current=out/arm;current.mkdir();(current/'tmp').mkdir();build=S/'checks/native1'
    image=c.read(build/(arm+'-image.json'));assert b.same(image);link=c.read(build/(arm+'-link-plan.json'))
    env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],current)
    c.save(current/'inputs.json',dict(image=image,filters=filters,expected_cases=count,runtime=runtime))
    try:c.execute('tests',[image['path'],'--gtest_filter='+':'.join(filters),'--gtest_output=xml:'+str(current/'results.xml')],env,current)
    finally:
        cases=ET.parse(current/'results.xml').findall('.//testcase') if (current/'results.xml').exists() else []
        failures=[dict(name=r.attrib['classname']+'.'+r.attrib['name'],details=[f.text for f in r.findall('failure')]) for r in cases if r.find('failure') is not None]
        skipped=sum(r.find('skipped') is not None for r in cases);passed=len(cases)==count and not failures and not skipped
        result=dict(passed=passed,cases=len(cases),skipped=skipped,failures=failures,image=image,actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases])
        c.save(current/'summary.json',result);results[arm]=result
        c.save(out/'summary.json',dict(passed=len(results)==(2 if args.arm=='all' else 1) and all(r['passed'] for r in results.values()),arms=results))
    assert passed
print('PAIRED_PROJECTION_TESTS',sum(r['cases'] for r in results.values()),'passed',flush=True)
