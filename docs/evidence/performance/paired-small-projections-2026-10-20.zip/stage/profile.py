"""One physical whole-model trace, separate from unprofiled throughput."""
import argparse
import collections
import csv
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
spec=importlib.util.spec_from_file_location('paired_profile_common',A/'cold-prepare-review/profile.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
b,c=p.b,p.c
args=argparse.ArgumentParser();args.add_argument('--analyze-only',action='store_true');opt=args.parse_args()
out=S/'profile';stem=out/'capture';build=S/'checks/native1'
image=c.read(build/'qwen-image.json');assert b.same(image);link=c.read(build/'qwen-link-plan.json')
numeric=c.read(S/'correctness/summary.json');assert numeric['passed'] and numeric['observation']['image']==image
old=c.read(A/'cold-prepare-review/profile/plan.json');command=old['consumer_command'].copy();command[0]=image['path']
assert '--trace' not in command
if not opt.analyze_only:
    out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
    nsys=old['commands']['profile'][0]
    commands=dict(profile=[nsys,'profile','--trace=cuda','--sample=none','--cpuctxsw=none',
        '--cuda-trace-all-apis=true','--cuda-graph-trace=node:host-only','--discard-environment=true','--output='+str(stem),*command],
        export=[nsys,'export','--type=sqlite','--output='+str(stem)+'.sqlite',str(stem)+'.nsys-rep'],
        stats=[nsys,'stats','--report=cuda_gpu_kern_sum','--format=csv','--output='+str(stem),str(stem)+'.sqlite'])
    c.save(out/'plan.json',dict(image=image,commands=commands,consumer_command=command,runtime=runtime,
        link=b.identity(build/'qwen-link-plan.json'),baseline=b.identity(A/'cold-prepare-review/profile/capture.sqlite'),
        correctness=b.identity(S/'correctness/summary.json'),script=b.identity(Path(__file__)),profiler=True,throughput_claim=False))
    for tag,argv in commands.items():c.execute(tag,argv,env,out)
data=p.trace(stem.with_suffix('.sqlite'))
official=collections.Counter()
with (out/'capture_cuda_gpu_kern_sum.csv').open(encoding='utf-8-sig',newline='') as f:
    for row in csv.DictReader(f):official[row['Name']]+=int(row['Instances'].replace(',',''))
assert official==collections.Counter(row['name'] for row in data['kernels'])
tokens=sorted((r for r in data['copies'] if r['copyKind']==2 and r['bytes']==4),key=lambda r:r['end']);assert len(tokens)==32
def paired(name):
    args=p.symbols.template_arguments(name,'mul_mat_vec_f')
    return len(args)==11 and args[-1].replace(' ','') in ('true','1','(bool)1','bool(1)') and p.symbols.dtype(args[0])=='bf16'
phases=[]
for index in range(1,32):
    lo,hi=tokens[index-1]['end'],tokens[index]['end']
    kernels=[r for r in data['kernels'] if lo<r['start'] and r['end']<=hi]
    assert not any(r['start']<hi and r['end']>lo and not (lo<r['start'] and r['end']<=hi) for r in data['kernels'])
    runtime=[r for r in data['runtime'] if lo<r['start'] and r['end']<=hi]
    phases.append(dict(index=index,**p.summarize_kernels(kernels),paired_projection=sum(paired(r['name']) for r in kernels),
        graph_launches=sum(p.api_name(r['name'])=='cudaGraphLaunch' for r in runtime),
        graph_kernel_nodes=sum(bool(r.get('graphNodeId')) for r in kernels)))
warm=phases[6:];assert len(warm)==25
for kind,value in data['streams'].items():(out/('target.'+kind+'.log')).write_text(value,encoding='utf-8')
targets=[json.loads(line) for line in data['streams'].get('stdout','').splitlines() if line.startswith('{') and 'generated_ids' in line]
assert len(targets)==1 and targets[0]['generated_ids']==numeric['observation']['generated_ids']
assert targets[0]['decode_input_ids']==c.read(S/'performance-prepared/plan.json')['fixed']['decode_input_ids']
passed=all(r['kernels']==596 and r['paired_projection']==18 and r['graph_launches']==1 and sum(r['casts'].values())==55 for r in warm)
c.save(out/'diagnostics.json',data['diagnostics'])
c.save(out/'summary.json',dict(passed=passed,decode7=warm[0],warm_phases=warm,all_phases=phases,
    paired_symbols=dict(collections.Counter(r['name'] for r in data['kernels'] if paired(r['name']))),
    official_CSV_SQLite_symbol_counts_equal=True,target_predictions_and_tape_equal=True,
    before_kernel_reference=614,current_kernels=warm[0]['kernels'],current_casts=55,
    diagnostics=data['diagnostics'],throughput_claim=False,
    limits='One actual instrumented process against retained previous trace for structural counts only. Profiler driver compatibility warnings retained. No clock normalization, throughput from kernel sums, independent quality or peak-memory acceptance.'))
assert passed
print('PAIRED_PROJECTION_PHYSICAL',warm[0],flush=True)
