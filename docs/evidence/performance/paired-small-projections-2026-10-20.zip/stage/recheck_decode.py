"""One bounded B/C/C/B followup with coarse whole-GPU clock telemetry."""
import importlib.util
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired_decode_followup',S/'compare.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
r=h.r.rotation.r;b,c=r.b,r.c
plan=c.read(S/'performance-prepared/plan.json');out=S/'decode-followup';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
for row in plan['frozen']+list(plan['images'].values()):r.require_same(row)
build=c.read(plan['build_plan']['path']);env,runtime=r.runtime_environment(build,c.read(r.PEER_PLAN),out)
requests={arm:next(x for x in plan['requests'] if x['arm']==arm) for arm in ('baseline','current')}
monitor_command=[shutil.which('nvidia-smi'),'--query-gpu=timestamp,pstate,clocks.sm,clocks.mem,power.draw,temperature.gpu,utilization.gpu,memory.used',
                 '--format=csv,noheader,nounits','--loop-ms=200']
assert monitor_command[0]
c.save(out/'inputs.json',dict(images=plan['images'],order=['baseline','current','current','baseline'],runtime=runtime,
    reason='First9-process window shows large later fluctuations in all arms; retain it and do not pool or select favorable samples.',
    profiler=False,compilation=False,external_monitor=True,monitor_command=monitor_command,
    monitor_limit='Coarse whole-card samples, may perturb timing. No per-process GPU attribution or exact decode clock markers.'))
with (out/'gpu-clock.csv').open('wb') as stdout, (out/'gpu-clock.stderr.log').open('wb') as stderr:
    monitor=subprocess.Popen(monitor_command,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    c.save(out/'monitor-live.json',dict(pid=monitor.pid,started=time.time(),command=monitor_command))
    runs=[]
    try:
        for i,arm in enumerate(['baseline','current','current','baseline'],1):
            request={**requests[arm],'tag':f'{i:02d}-{arm}'}
            for row in plan['images'].values():r.require_same(row)
            process=r.execute(request['tag'],request['command'],env,out);observed=r.hyle_result(out,request,plan)
            runs.append(dict(arm=arm,tag=request['tag'],pid=process['pid'],exit=process['exit'],started=process['started'],finished=process['finished'],**observed))
            c.save(out/'runs.json',runs)
    finally:
        monitor.terminate();monitor.wait(timeout=5)
        c.save(out/'monitor-terminal.json',dict(pid=monitor.pid,exit=monitor.returncode,finished=time.time(),terminated_after_runs=True))
groups={arm:{key:dict(samples=[x['metrics'][key] for x in runs if x['arm']==arm],
    median=statistics.median(x['metrics'][key] for x in runs if x['arm']==arm)) for key in r.COMMON_METRICS} for arm in ('baseline','current')}
c.save(out/'summary.json',dict(completed=True,processes=4,groups=groups,same_predictions=all(x['same_baseline_predictions'] for x in runs),
    current_over_baseline={key:groups['current'][key]['median']/groups['baseline'][key]['median'] for key in r.COMMON_METRICS},
    external_monitor=True,limits='Two processes per image, one post-profile B/C/C/B window with coarse GPU telemetry. Keep separate from original9; no significance, clock-normalized or exclusive-GPU causality claim.'))
print('PAIRED_DECODE_FOLLOWUP_COMPLETE',flush=True)
