"""Publish the generic two-output route, common scratch fix and measured limits."""
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('paired_projection_publish',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
build=S/'checks/native1';plan=c.read(build/'plan.json')
assert c.read(build/'summary.json')['passed']
for row in plan['frozen']:assert b.same(row),row['path']
for arm in ('cpu','tests','qwen'):
    assert b.same(c.read(build/(arm+'-image.json')))
    for row in c.read(build/(arm+'-link-plan.json'))['inputs']:assert b.same(row),row['path']
tests=c.read(S/'tests/summary.json');numeric=c.read(S/'correctness/summary.json');profile=c.read(S/'profile/summary.json')
perf=c.read(S/'performance-rotation/summary.json');followup=c.read(S/'decode-followup/summary.json')
assert tests['passed'] and sum(r['cases'] for r in tests['arms'].values())==20
assert numeric['passed'] and numeric['observation']['equal_vectors']==64
assert profile['passed'] and profile['decode7']['kernels']==596 and profile['decode7']['paired_projection']==18
assert perf['terminal_zero']==9 and perf['same_baseline_predictions_all9'] and followup['completed'] and followup['same_predictions']
product=[]
for name in ('native-product-source-freeze.json','graph-product-source-freeze.json','core-product-source-freeze.json'):
    product.extend(row['after']['path'] for row in c.read(S/name)['files'])
docs=['docs/architecture/compute-design.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/evidence/performance/qwen35-full-cuda-2026-10-19/README.md']
paths=list(dict.fromkeys([*product,*[str(ROOT/name) for name in docs]]))
c.execute('diff-check',['git','diff','--check','--',*paths],dict(os.environ),S)
zone=dt.timezone(dt.timedelta(hours=8));first=c.read(S/'performance-rotation/01-baseline.result.json');last=c.read(S/'performance-rotation/09-baseline.result.json')
report=dict(date_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    result='Generic same-logical-A two-output BF16/F32acc vector MatMul cold candidate, preserving both original stores. Original MMVF dot/reduction reused with independent final BF16 RNE stores; no model switch, weight copy, public operation or executor.',
    sources={name:c.read(S/name) for name in ('native-product-source-freeze.json','graph-product-source-freeze.json','core-product-source-freeze.json','native-source-freeze.json')},
    reviews={name:c.read(S/name) for name in ('native-independent-review.json','graph-independent-review.json','cold-priority-correction-independent-review.json')},
    contract='Same A ValueId, plain BF16 dense vector M1/evenK, F32 accumulation, two transposed dense W with equal positive N. Cached NVIDIA/MMVF geometry and launch bounds, initially N<=device SM count. Both outputs remain visible; different logical A even at the same address is not a match. Large/multitoken/other-layout/dtype/quantized domains keep original leaves.',
    lifecycle='Common contraction checks nonadjacent data/control legality. Full FFN proposed/encoded first. Actual A and both W storage roots remain live through the relevant terminal. Encode rechecks exact CUDA owner/device/span/alignment,3 read x2 write and output-output overlaps. Capture and results use existing Invocation/Queue/Completion.',
    general_complexity='The common noncontiguous contraction helper clears/allocates only the candidate ordinal span rather than the full Graph. Duplicate/foreign/entry/control-cycle semantics unchanged; one69-node offset query fixture proves small spans need no heap allocation. Candidate sorting is O(P log P); total validation includes actual candidate interval/edges and is not claimed universally O(P log P).',
    cold_ffn_correction='Review found the old full-FFN carrier lacked its own cold read-root keep and the new pair could take an earlier terminal. Added a conservative structural full-FFN cold match before the pair, keeping its four read references through final Mul. Bound encode admission unchanged. Earlier native source/review superseded and retained; no GPU execution of the first source.',
    build=dict(product_CXX=3,test_CXX=4,native_unique_TUs=3,native_compile_attempts=4,SDK_builds=0,consumer_main_object_reused=True,
        current_images={arm:c.read(build/(arm+'-image.json')) for arm in ('cpu','tests','qwen')},native_header_closure=c.read(S/'native-header-closure.json')),
    correctness=dict(tests=tests,full_model=numeric,
        math='Public F32acc permits a different reduction tree; final BF16 and nonfinite semantics preserved. New four finite/cancellation/subnormal/nonfinite corpora report zero raw leaf differences, old exact FFN rounding witnesses remain unchanged, and actual64 model vectors are byte-equal. This is not independent model-quality acceptance.',
        neighbor_change='Published/ExtraReader old FFN test now permits a real two-output pair with exact member/policy/copy checks; unsupported geometry/logical-A cases still require CuBLAS, and numerical oracle is unchanged.'),
    physical=profile,
    workspace=dict(prefill_per_slot_before=26910720,prefill_per_slot_after=26910720,decode_per_slot_before=1811712,decode_per_slot_after=1807616,
                   limit='Explicit Graph workspace only; no new whole-process or GPU peak-memory measurement.'),
    performance=dict(window_beijing=dict(start=dt.datetime.fromtimestamp(first['started'],zone).isoformat(),end=dt.datetime.fromtimestamp(last['finished'],zone).isoformat()),
        rotation=perf,followup=followup,analysis=c.read(S/'perf-review.json'),stable_decode_gain_established=False,
        observation='First9 warm median+1.0838%, full31+0.4225%; later slow samples occur in all arms. Separate clock-monitored B/C/C/B warm+0.2700%, full31-0.0356%. No samples removed or pooled; gains are smaller than variation, so no stable decode speedup is claimed.'),
    remaining='Broader model/profile/quantized fusion routes, startup/resource work and other platform journeys remain. The small-row hardware restriction is an engineering default, not a universal measured crossover. MTP/mmproj and overall architecture goal remain unfinished.')
files={};allowed={'.py','.cc','.h','.cu','.cuh','.json','.diff','.log','.txt','.xml','.csv','.sqlite','.nsys-rep','.ps1'}
for path in S.rglob('*'):
    if not path.is_file() or path.suffix not in allowed:continue
    rel=path.relative_to(S)
    if any(part in ('tmp','__pycache__') for part in rel.parts):continue
    if len(rel.parts)==1 and path.name in ('summary.json','archive-manifest.json','publication.json','cleanup-plan.json','cleanup-receipt.json'):continue
    files['stage/'+rel.as_posix()]=path
for path in paths:files['product/'+Path(path).relative_to(ROOT).as_posix()]=Path(path)
manifest=[]
for name,path in sorted(files.items()):
    data=path.read_bytes();manifest.append(dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
public=ROOT/'docs/evidence/performance';archive=public/'paired-small-projections-2026-10-20.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,path in sorted(files.items()):z.write(path,name)
    z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        data=z.read(row['name']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
report['archive']=dict(**b.identity(archive),payloads=len(manifest),crc_verified=True,payload_sha256_verified=True)
report_path=archive.with_suffix('.json');c.save(report_path,report);c.save(S/'summary.json',report);c.save(S/'archive-manifest.json',manifest)
c.save(S/'publication.json',dict(report=b.identity(report_path),archive=report['archive']))
print('PAIRED_PROJECTION_PUBLISHED',report['archive']['bytes'],len(manifest),flush=True)
