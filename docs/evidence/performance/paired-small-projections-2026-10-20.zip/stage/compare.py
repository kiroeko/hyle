"""Same retained original BF16 main; no profiler or compilation during rotation."""
import argparse
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paired_projection_rotation',S.parent/'qwen-current-retest/compare.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.S=r.rotation.STAGE=S;r.r.PREPARED=S/'performance-prepared'
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');a=p.parse_args()
    if a.run:r.rotation.run(r.r.PREPARED/'plan.json',S/'performance-rotation')
    else:
        old=S.parent/'quant-route-followup/checks/host1';image=r.c.read(old/'qwen-image.json');assert r.b.same(image)
        peer=r.c.read(S.parent/'qwen-current-retest/retest-plan.json')['retained_llama_image']
        r.c.save(S/'retest-plan.json',dict(retained_old_image=image,retained_llama_image=peer))
        r.prepare(S/'checks/native1/plan.json')
        plan=r.c.read(r.r.PREPARED/'plan.json');plan['baseline']='Immediately previous cold-preparation/FP8-Cast b1803abb image; same original BF16 main, weights, public precision and tape. Current adds generic same-A two-output small BF16 projection and bounded contraction scratch.'
        plan['frozen'].append(r.b.identity(Path(__file__)));r.c.save(r.r.PREPARED/'plan.json',plan)
