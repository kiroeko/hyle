"""Extend the original MMVF carrier; materialize only the native source closure."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
UPSTREAM = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
PATCH = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
NAMES = ['src/ggml-cuda/mmvf.cuh', 'src/ggml-cuda/unary.cu',
         'src/ggml-cuda/ggml-cuda.cu', 'src/ggml-cuda/mmvf.cu']


def sha(b):
    return hashlib.sha256(b).hexdigest()


def identity(p):
    b = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(b), sha256=sha(b))


def save(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8')


def replay(row):
    d = (UPSTREAM / row['path']).read_bytes().replace(b'\r\n', b'\n')
    assert sha(d) == row['before_sha256'], row['path']
    for e in row['edits']:
        old, new = e['before'].encode(), e['after'].encode()
        assert d.count(old) == 1, (row['path'], old[:90])
        d = d.replace(old, new, 1)
    assert sha(d) == row['after_sha256'], row['path']
    return d


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'src/compute_ggml_runtime' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    assert not (STAGE / 'native-source-freeze.json').exists(), 'Already frozen'
    before_patch = STAGE / 'before/third_party/ggml_cuda_runtime/patches.json'
    assert before_patch.read_bytes() == PATCH.read_bytes(), 'Product changed'
    manifest = json.loads(PATCH.read_text())
    rows = {r['path']: r for r in manifest['files']}
    original = {n: replay(rows[n]).decode() for n in NAMES}
    source = dict(original)
    edits = {n: [] for n in NAMES}

    def edit(name, old, new):
        assert source[name].count(old) == 1, (name, old[:120])
        source[name] = source[name].replace(old, new, 1)
        edits[name].append(dict(before=old, after=new))

    header, unary, host, mmvf = NAMES
    old = '// The new NVIDIA F32-ID specialization preserves subnormal operands and\n'
    new = '''// Same-A projections retain both original public outputs. Geometry uses
// only cached native caps; metadata and bound storage are checked separately.
bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows);
bool ggml_cuda_supports_bf16_paired_matvec(const ggml_tensor * first, const ggml_tensor * second, int device);
bool ggml_cuda_can_fuse_bf16_paired_matvec(const ggml_tensor * first, const ggml_tensor * second,
                                        int device, bool require_bound);
void ggml_cuda_op_bf16_paired_matvec(ggml_backend_cuda_context & ctx,
                                    const ggml_tensor * first, ggml_tensor * second);

''' + old
    edit(header, old, new)
    # One compile-time output mode on the original body, never a copied dot.
    prefix = 'typename Epilogue = void, bool strict_f32_ids = false>'
    assert source[header].count(prefix) == 3
    for signature in [
        'template <typename T, typename type_acc, int ncols_dst, int block_size, bool has_fusion = false, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void, bool strict_f32_ids = false>',
        'template<typename T, typename type_acc, int ncols_dst, int block_size, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void, bool strict_f32_ids = false>',
        'template <typename T, typename type_acc, int ncols_dst, bool is_multi_token_id = false, typename Y = float, typename Dst = float, typename Epilogue = void, bool strict_f32_ids = false>']:
        edit(header, signature, signature.replace('strict_f32_ids = false>', 'strict_f32_ids = false, bool paired_output = false>'))
    edit(header, '        const int ids_stride) {\n', '        const int ids_stride, Dst * peer_dst_ptr) {\n')
    old = '    float value = sumf[tid];\n\n'
    new = '''    if constexpr (paired_output) {
        static_assert(has_fusion && ncols_dst == 1 && !is_multi_token_id && !strict_f32_ids);
        static_assert(std::is_same_v<T, nv_bfloat16> && std::is_same_v<type_acc, float> &&
                      std::is_same_v<Y, nv_bfloat16> && std::is_same_v<Dst, nv_bfloat16> &&
                      std::is_void_v<Epilogue>);
        // Both independent public projection boundaries use the original dot
        // and reduction above. No activation, product or earlier BF16 round.
        dst[tid*stride_col_dst + row] = __float2bfloat16_rn(sumf[tid]);
        peer_dst_ptr[tid*stride_col_dst + row] = __float2bfloat16_rn(sumf_gate[tid]);
        return;
    }

''' + old
    edit(header, old, new)
    old = '        const dim3 & block_dims, const dim3 & block_nums, const int nbytes_shared, const int ids_stride, const cudaStream_t stream) {'
    edit(header, old, old.replace('stream) {', 'stream, Dst * peer_dst) {'))
    old = '    if constexpr (!std::is_void_v<Epilogue>) {\n        static_assert(ncols_dst == 1 && !is_multi_token_id);'
    new = '''    if constexpr (paired_output) {
        static_assert(ncols_dst == 1 && !is_multi_token_id && !strict_f32_ids && std::is_void_v<Epilogue>);
        GGML_ASSERT(peer_dst && fusion.gate && !ids && !fusion.x_bias && !fusion.gate_bias &&
                    !fusion.x_scale && !fusion.gate_scale);
        ggml_cuda_kernel_launch(mul_mat_vec_f<T, type_acc, ncols_dst, block_size, true,
            is_multi_token_id, Y, Dst, Epilogue, strict_f32_ids, true>, launch_params,
            x, y, ids, fusion, dst, ncols, nchannels_y, stride_row, stride_col_y, stride_col_dst,
            channel_ratio, stride_channel_x, stride_channel_y, stride_channel_dst,
            sample_ratio, stride_sample_x, stride_sample_y, stride_sample_dst, ids_stride, peer_dst);
    } else if constexpr (!std::is_void_v<Epilogue>) {
        static_assert(ncols_dst == 1 && !is_multi_token_id);'''
    edit(header, old, new)
    # The three original kernel launches pass a typed null pointer. Their
    # template defaults preserve the previous arithmetic and output stores.
    for text in [
        'sample_ratio, stride_sample_x, stride_sample_y, stride_sample_dst, ids_stride);']:
        assert source[header].count(text) == 3
        for _ in range(3):
            # Context includes each distinct original kernel template.
            pos = source[header].index(text)
            start = source[header].rfind('ggml_cuda_kernel_launch(', 0, pos)
            old = source[header][start:pos + len(text)]
            edit(header, old, old.replace(text, text.replace('ids_stride);', 'ids_stride, static_cast<Dst *>(nullptr));')))
    old = '        const int64_t nsamples_or_ntokens, const int64_t ids_stride, cudaStream_t stream) {'
    edit(header, old, old.replace('stream) {', 'stream, Dst * peer_dst = nullptr) {'))
    for block in (32, 64, 96, 128, 160, 192, 224, 256):
        old = f'''mul_mat_vec_f_switch_fusion<T, type_acc, ncols_dst, {block}, is_multi_token_id, Y, Dst, Epilogue, strict_f32_ids>
                (x, y, ids, fusion, dst, ncols/2, nchannels_y_fd, stride_row, stride_col_y/2, stride_col_dst,
                 channel_ratio_fd, stride_channel_x, stride_channel_y, stride_channel_dst,
                 sample_ratio_fd, stride_sample_x, stride_sample_y, stride_sample_dst, block_dims, block_nums, nbytes_shared, ids_stride, stream);'''
        new = old.replace('Epilogue, strict_f32_ids>', 'Epilogue, strict_f32_ids, paired_output>').replace('ids_stride, stream);', 'ids_stride, stream, peer_dst);')
        edit(header, old, new)

    carrier = '''
/* Same-A BF16 projections with two real independent public outputs. */
bool ggml_cuda_supports_bf16_paired_matvec(const ggml_tensor * first,
        const ggml_tensor * second, int device) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(first, second, device);
    return false;
#else
    if (!first || !second || first == second || first->view_src || second->view_src ||
            first->op != GGML_OP_MUL_MAT || second->op != GGML_OP_MUL_MAT ||
            ggml_get_op_params_i32(first, 0) != GGML_PREC_F32 ||
            ggml_get_op_params_i32(second, 0) != GGML_PREC_F32 ||
            !first->src[0] || !first->src[1] || !second->src[0] ||
            first->src[1] != second->src[1]) return false;
    for (int s = 2; s < GGML_MAX_SRC; ++s) {
        if (first->src[s] || second->src[s]) return false;
    }
    const auto * w0 = first->src[0];
    const auto * w1 = second->src[0];
    const auto * x = first->src[1];
    for (const auto * tensor : {w0, w1, x, first, second}) {
        if (tensor->type != GGML_TYPE_BF16 || !ggml_is_contiguous(tensor) ||
                tensor->ne[2] != 1 || tensor->ne[3] != 1) return false;
    }
    const auto k = w0->ne[0], n = w0->ne[1];
    if (k <= 0 || n <= 0 || !ggml_are_same_shape(w0, w1) ||
            x->ne[0] != k || x->ne[1] != 1 || first->ne[0] != n || first->ne[1] != 1 ||
            !ggml_are_same_shape(first, second) ||
            !ggml_cuda_supports_bf16_paired_projection_geometry(device, uint64_t(k), uint64_t(n))) return false;
    const int cc = ggml_cuda_info().devices[device].cc;
    return ggml_cuda_should_use_mmvf(w0->type, cc, w0->ne, w0->nb, 1) &&
           ggml_cuda_should_use_mmvf(w1->type, cc, w1->ne, w1->nb, 1);
#endif
}

void ggml_cuda_op_bf16_paired_matvec(ggml_backend_cuda_context & ctx,
        const ggml_tensor * first, ggml_tensor * second) {
    GGML_ASSERT(ggml_cuda_can_fuse_bf16_paired_matvec(first, second, ctx.device, true));
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    const auto * w0 = first->src[0];
    const auto * w1 = second->src[0];
    const auto * x = first->src[1];
    const auto bytes = sizeof(nv_bfloat16);
    ggml_cuda_mm_fusion_args_device fusion{};
    fusion.gate = w1->data;
    launch_mul_mat_vec_f_cuda<nv_bfloat16, float, 1, false,
        nv_bfloat16, nv_bfloat16, void, false, true>(
            static_cast<const nv_bfloat16 *>(w0->data),
            static_cast<const nv_bfloat16 *>(x->data), nullptr, fusion,
            static_cast<nv_bfloat16 *>(first->data), w0->ne[0], w0->ne[1],
            w0->nb[1] / bytes, x->nb[1] / bytes, first->nb[1] / bytes,
            1, 1, 1, w0->nb[2] / bytes, x->nb[2] / bytes, first->nb[2] / bytes,
            1, 1, w0->nb[3] / bytes, x->nb[3] / bytes, first->nb[3] / bytes,
            1, 0, ctx.stream(), static_cast<nv_bfloat16 *>(second->data));
#else
    GGML_UNUSED_VARS(ctx, first, second);
#endif
}
'''
    anchor = '''#else
    GGML_UNUSED_VARS(ctx, gate_mm, up_mm, silu, dst);
#endif
}
'''
    edit(unary, anchor, anchor + carrier)

    geometry = '''
// Small-row eligibility is cold native geometry, never a model/shape list.
bool ggml_cuda_supports_bf16_paired_projection_geometry(int device, uint64_t inner, uint64_t rows) {
#if defined(GGML_USE_HIP) || defined(GGML_USE_MUSA)
    GGML_UNUSED_VARS(device, inner, rows);
    return false;
#else
    const auto & info = ggml_cuda_info();
    if (device < 0 || device >= info.device_count || !inner || (inner & 1) || !rows ||
            inner > uint64_t(INT_MAX) || rows > uint64_t(INT_MAX) / inner) return false;
    const auto & caps = info.devices[device];
    const auto & limits = ggml_cuda_launch_limits[device];
    if (!GGML_CUDA_CC_IS_NVIDIA(caps.cc) || !fast_bf16_hardware_available(caps.cc) ||
            caps.warp_size != 32 || caps.nsm <= 0 || rows > uint64_t(caps.nsm) ||
            limits[0] <= 0 || rows > uint64_t(limits[0]) || limits[1] < 1 ||
            ggml_cuda_mmvq_grid_y[device] < 1 || limits[2] < 256 ||
            caps.smpb < 2 * 32 * sizeof(float)) return false;
    const int64_t ne[GGML_MAX_DIMS] = {int64_t(inner), int64_t(rows), 1, 1};
    const size_t nb[GGML_MAX_DIMS] = {sizeof(nv_bfloat16), size_t(inner) * sizeof(nv_bfloat16),
        size_t(inner * rows) * sizeof(nv_bfloat16), size_t(inner * rows) * sizeof(nv_bfloat16)};
    return ggml_cuda_should_use_mmvf(GGML_TYPE_BF16, caps.cc, ne, nb, 1);
#endif
}

// Both outputs survive. Only the actual external reads and output storage
// need proof; no first-output escape or single-use rule applies to this pair.
bool ggml_cuda_can_fuse_bf16_paired_matvec(const ggml_tensor * first,
        const ggml_tensor * second, int device, bool require_bound) {
    if (!ggml_cuda_supports_bf16_paired_matvec(first, second, device)) return false;
    if (!require_bound) return true;
    const ggml_tensor * const tensors[] = {first->src[0], second->src[0], first->src[1], first, second};
    uintptr_t begin[5] = {}, end[5] = {};
    for (int j = 0; j < 5; ++j) {
        const auto * tensor = tensors[j];
        const auto * root = tensor;
        while (root->view_src) root = root->view_src;
        const auto buffer = tensor->buffer ? tensor->buffer : root->buffer;
        if (!tensor->data || !buffer || !ggml_backend_buffer_is_cuda(buffer) ||
                (root->buffer && root->buffer != buffer)) return false;
        const auto * owner = static_cast<const ggml_backend_cuda_buffer_context *>(buffer->context);
        if (!owner || owner->device != device || !owner->dev_ptr) return false;
        const uintptr_t base = reinterpret_cast<uintptr_t>(owner->dev_ptr);
        begin[j] = reinterpret_cast<uintptr_t>(tensor->data);
        const size_t bytes = ggml_nbytes(tensor), capacity = ggml_backend_buffer_get_size(buffer);
        const size_t alignment = j < 3 ? alignof(nv_bfloat162) : alignof(nv_bfloat16);
        if (begin[j] % alignment || begin[j] < base || begin[j] - base > capacity ||
                bytes > capacity - (begin[j] - base) || bytes > UINTPTR_MAX - begin[j]) return false;
        end[j] = begin[j] + bytes;
    }
    for (int read = 0; read < 3; ++read) {
        for (int out = 3; out < 5; ++out) {
            if (begin[read] < end[out] && begin[out] < end[read]) return false;
        }
    }
    return end[3] <= begin[4] || end[4] <= begin[3];
}

'''
    anchor = '// Device limits are captured in the original cold device-info initialization.\n'
    edit(host, anchor, geometry + anchor)
    matcher = '''struct ggml_cuda_bf16_paired_projection_match {
    const ggml_tensor * first = nullptr;
    ggml_tensor * second = nullptr;
    int count = 0;
};

static bool ggml_cuda_match_bf16_paired_projection(const ggml_cgraph * graph, int begin,
        int device, bool require_bound, ggml_cuda_bf16_paired_projection_match & match) {
    match = {};
    if (begin < 0 || graph->n_nodes - begin < 2) return false;
    const auto * first = graph->nodes[begin];
    int count = 2;
    auto * second = graph->nodes[begin + 1];
    if (second->op == GGML_OP_TRANSPOSE) {
        const auto * view = second;
        const auto * src = view->src[0];
        if (graph->n_nodes - begin < 3 || !src || src->op != GGML_OP_NONE ||
                view->view_src != src || view->view_offs != 0 ||
                view->type != GGML_TYPE_BF16 || src->type != view->type ||
                view->ne[0] != src->ne[1] || view->ne[1] != src->ne[0] ||
                view->nb[0] != src->nb[1] || view->nb[1] != src->nb[0] ||
                view->ne[2] != src->ne[2] || view->ne[3] != src->ne[3] ||
                view->nb[2] != src->nb[2] || view->nb[3] != src->nb[3]) return false;
        for (int s = 1; s < GGML_MAX_SRC; ++s) if (view->src[s]) return false;
        second = graph->nodes[begin + 2];
        if (second->src[0] != view) return false;
        count = 3;
    }
    if (!(first->flags & GGML_TENSOR_FLAG_COMPUTE) ||
            !(second->flags & GGML_TENSOR_FLAG_COMPUTE) ||
            !ggml_cuda_can_fuse_bf16_paired_matvec(first, second, device, require_bound)) return false;
    match = {first, second, count};
    return true;
}

'''
    anchor = 'static bool ggml_cuda_match_bf16_l2_core(const ggml_cgraph * graph, int begin,\n'
    edit(host, anchor, matcher + anchor)
    anchor = '''        // Retain actual BF16/F32 reads through the terminal mixed store.
'''
    deps = '''        ggml_cuda_bf16_paired_projection_match pair;
        if (ggml_cuda_match_bf16_paired_projection(cgraph, i, cuda_ctx->device, false, pair)) {
            keep(pair.first->src[0], i + pair.count - 1);
            keep(pair.second->src[0], i + pair.count - 1);
            keep(pair.first->src[1], i + pair.count - 1);
            continue;
        }
'''
    edit(host, anchor, deps + anchor)
    anchor = '''            return match.count - 1;
        }
    }
#endif

    // Keep the native F32 program as the fallback.'''
    replace = '''            return match.count - 1;
        }
        // Complete FFN above keeps priority. Both pair results remain real
        // outputs; this follows the original first-node fusion encoder.
        ggml_cuda_bf16_paired_projection_match pair;
        if (ggml_cuda_match_bf16_paired_projection(cgraph, i, cuda_ctx->device, true, pair)) {
            ggml_cuda_op_bf16_paired_matvec(*cuda_ctx, pair.first, pair.second);
            return pair.count - 1;
        }
    }
#endif

    // Keep the native F32 program as the fallback.'''
    edit(host, anchor, replace)

    for name in NAMES:
        if edits[name]:
            rows[name]['edits'].extend(edits[name])
            rows[name]['after_sha256'] = sha(source[name].encode())
            assert replay(rows[name]) == source[name].encode(), name
    PATCH.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    target = {side: {} for side in ('before', 'source')}
    composed = {side: {} for side in ('before', 'source')}
    mixed = STAGE / 'mixed-cpu-manifest.json'
    load('prepare_mixed_cpu_manifest').derive(UPSTREAM,
        ROOT / 'third_party/ggml_runtime/patches.json', ROOT / 'third_party/ggml_cpu_runtime/patches.json', mixed)
    composer = load('prepare_cuda_iq1_manifest')
    iq1 = ROOT / 'third_party/ggml_cuda_runtime/iq1-patches.json'
    for side, product in [('before', before_patch), ('source', PATCH)]:
        combined = STAGE / (side + '-combined-manifest.json')
        composer.derive(UPSTREAM, mixed, product, iq1, combined)
        only = {r['path']: r for r in json.loads(product.read_text())['files']}
        all_rows = {r['path']: r for r in json.loads(combined.read_text())['files']}
        for name in NAMES:
            target[side][name] = replay(only[name])
            composed[side][name] = replay(all_rows[name])
            p = STAGE / ('native-' + side) / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(composed[side][name])
            p = STAGE / ('manifest-target-' + side) / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(target[side][name])
    # Reuse only the accepted 90-header native closure, not a source/SDK copy.
    previous = STAGE.parent / 'typed-gating-suffix/native-source'
    headers = []
    for p in sorted(previous.rglob('*')):
        if p.is_file() and p.suffix in ('.h', '.cuh'):
            rel = p.relative_to(previous)
            out = STAGE / 'native-source' / rel
            if str(rel).replace('\\', '/') != header:
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(p.read_bytes())
            headers.append(dict(path=str(rel).replace('\\', '/'), **{k:v for k,v in identity(out).items() if k != 'path'}, source=str(out.resolve()), changed=p.read_bytes() != out.read_bytes()))
    save(STAGE / 'native-header-closure.json', dict(headers=headers, canonical=str((STAGE/'native-source').resolve()), note='Reused accepted v31 native header closure, replacing only mmvf.cuh. No SDK or shared cache copy.'))
    changes = ''.join(''.join(difflib.unified_diff(composed['before'][n].decode().splitlines(True), composed['source'][n].decode().splitlines(True), fromfile='before/'+n,tofile='after/'+n)) for n in NAMES)
    (STAGE / 'native-changes.diff').write_text(changes, encoding='utf-8', newline='\n')
    save(STAGE / 'native-source-freeze.json', dict(
        scope='Native source only. Original source + mixed CPU + current CUDA manifest + independent IQ1. No build/GPU execution.',
        product_before=identity(before_patch), product_after=identity(PATCH),
        files=[dict(name=n, before=identity(STAGE/'native-before'/n),after=identity(STAGE/'native-source'/n),manifest_target_before=identity(STAGE/'manifest-target-before'/n),manifest_target_after=identity(STAGE/'manifest-target-source'/n), added_edits=len(edits[n])) for n in NAMES],
        diff=identity(STAGE/'native-changes.diff'), composition_inputs=[identity(p) for p in [mixed, iq1, STAGE/'before-combined-manifest.json',STAGE/'source-combined-manifest.json']],
        source_generator=identity(Path(__file__)), native_header_closure=identity(STAGE/'native-header-closure.json'),
        compiled=False,GPU_executed=False))
    print('NATIVE SOURCES FROZEN')
    for name in NAMES:
        print(name, sha(composed['source'][name]))


if __name__ == '__main__':
    main()
