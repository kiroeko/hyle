from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


path = STAGE / 'graph-product-source-freeze.json'
report = json.loads(path.read_text())
names = ['src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
         'tests/graph_provider_ggml_cuda/paired_projection_test.cc',
         'tests/graph_provider_ggml_cuda/CMakeLists.txt',
         'tests/graph_route_cuda/stable_silu_test.cc']
rows, diff = [], []
for name in names:
    product = ROOT / name
    before = STAGE / 'before' / name
    snapshot = STAGE / 'source' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(product.read_bytes())
    rows.append(dict(product=name, before=identity(before) if before.exists() else None,
                     after=identity(product), snapshot=identity(snapshot)))
    diff.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],
                                    product.read_text().splitlines(True),
                                    fromfile='before/' + name, tofile='after/' + name))
(STAGE / 'graph-changes.diff').write_text(''.join(diff))
report['files'] = rows
report['changes'] = identity(STAGE / 'graph-changes.diff')
report['native_private_api']['header'] = identity(ROOT / 'src/compute_provider_ggml_cuda/program.h')
report['tests']['cases'] = 5
report['tests']['ffn_orders'] = ['gate -> SiLU -> up -> Multiply', 'gate -> up -> SiLU -> Multiply']
report['tests']['ffn_priority_scope'] = 'Both compile-selection topologies; existing three FFN cases remain the numerical execution neighbor. No physical launch claim from CompileReport.'
report['tests']['existing_neighbor_change'] = 'Only Published/ExtraReader may retain the original two observable MatMul outputs through pair6/policy5 or original cuBLAS leaves. Foreign-A/oddK/dense-RHS still require cuBLAS. Original numerical checks are unchanged.'
report['history'] = str(STAGE / 'before-ffn-order-correction')
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(freeze=identity(path), changes=identity(STAGE / 'graph-changes.diff'),
                      files=[dict(product=row['product'], sha256=row['after']['sha256']) for row in rows])))
