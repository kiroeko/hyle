#pragma once
#include "common.cuh"
#include "numerical_contract.h"

#define CUDA_ROPE_BLOCK_SIZE 256

void ggml_cuda_op_rope(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_rope_back(ggml_backend_cuda_context & ctx, ggml_tensor * dst);

void ggml_cuda_op_rope_fused(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * set_rows);

void ggml_cuda_op_rms_norm_mul_rope_fused(ggml_backend_cuda_context & ctx, ggml_tensor * rms_norm, ggml_tensor * mul, ggml_tensor * rope, ggml_tensor * set_rows);

// Kept separate from inverse-factor/YaRN RoPE, including all old fusers.
inline bool ggml_cuda_is_hyle_explicit_rope(const ggml_tensor * node) {
    return node && node->op == GGML_OP_ROPE &&
        ggml_get_op_params_i32(node, hyle::compute::ggml_cuda::internal::kExplicitRopeContractParam) ==
            hyle::compute::ggml_cuda::internal::kExplicitRopeContract;
}

bool ggml_cuda_supports_hyle_explicit_rope(const ggml_tensor * dst, int device, bool require_bound);
void ggml_cuda_op_hyle_explicit_rope(ggml_backend_cuda_context & ctx, ggml_tensor * dst);
