#include "common.cuh"

void ggml_cuda_op_ssm_conv(ggml_backend_cuda_context & ctx, ggml_tensor * dst, ggml_tensor * bias_add_node = nullptr, ggml_tensor * silu_dst = nullptr);

// Metadata-only qualification of original F32 and private BF16 samples.
bool ggml_cuda_supports_ssm_conv(const ggml_tensor * dst);
