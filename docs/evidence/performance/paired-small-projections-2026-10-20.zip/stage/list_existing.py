"""Inspect the real cached test binary before choosing neighbor fixtures."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pair_existing_cases',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
base=S.parent/'quant-route-followup/checks/host1';link=c.read(base/'tests-link-plan.json');image=c.read(base/'tests-image.json');assert b.same(image)
out=S/'neighbors-inventory';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
env,runtime=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
c.execute('existing',[image['path'],'--gtest_list_tests'],env,out)
cases=[];suite=''
for line in (out/'existing.stdout.log').read_text(encoding='utf-8').splitlines():
    if line and not line.startswith(' ') and line.endswith('.'):
        suite=line.strip()
    elif line.startswith('  ') and suite:
        cases.append(suite+line.strip().split(' #')[0])
wanted=[r for r in cases if r.startswith(('GgmlCudaDualProjection.','GgmlCudaBfloatMatvec.','CudaGroupedShared.','GgmlCudaTypedGatingSilu.'))]
c.save(out/'summary.json',dict(image=image,total_cases=len(cases),wanted_cases=wanted,runtime=runtime))
print('EXISTING_NEIGHBORS',wanted,flush=True)
