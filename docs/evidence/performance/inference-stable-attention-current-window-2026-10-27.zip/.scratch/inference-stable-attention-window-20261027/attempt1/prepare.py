"""Prepare exactly forty retained complete-window commands; never execute one."""
from pathlib import Path
from collections import Counter
import ast
import copy
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[2]
OLD = R / '.scratch/inference-continuous-wave-window-20261027/attempt2'
BUILD = R / '.scratch/inference-stable-attention-20261027'
ARMS = ('hyle_plain', 'hyle_auto', 'hyle_mtp', 'peer_plain', 'peer_mtp')
GROUPS = (('single', 'timing'), ('single', 'memory'), ('two-turn', 'timing'), ('two-turn', 'memory'))


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    assert pin(row['path']) == row, row['path']


def save(path, value):
    path = Path(path)
    assert not path.exists(), ('Do not replace a previous preparation/attempt', str(path))
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())


def main():
    assert not any((W / f'{scenario}-{mode}').exists() for scenario, mode in GROUPS)
    assert not (W / 'plan.json').exists()
    runner = (W / 'window.py').read_bytes()
    assert runner == (OLD / 'window.py').read_bytes(), 'Retain all original endpoint/parser/sampler logic'
    ast.parse(runner.decode('utf-8-sig'))
    ast.parse(Path(__file__).read_text(encoding='utf-8-sig'))
    current = read(BUILD / 'ready-cli.json')
    assert current['image']['sha256'] == 'd9a2fe2cda2736cbb5ddb7a01366b36d1f7409045ff2cde2fd78d4e7f3337391'
    for row in (current['image'], current['runtime'], current['inputs'], current['plan']):
        exact(row)
    frozen = read(current['plan']['path'])
    baseline = read(frozen['baseline']['path'])
    exact(frozen['baseline']); exact(baseline['compiled']['snapshot'])
    inputs = read(current['inputs']['path']); original = read(baseline['inputs']['path'])
    assert len(inputs) == len(original) == 224
    replacements = [(a, b) for a, b in zip(original, inputs) if a != b]
    assert len(replacements) == 3
    assert {b['sha256'] for _, b in replacements} == {row['object']['sha256'] for row in current['compiled'].values()}
    assert baseline['compiled']['object'] in inputs, 'Model is unchanged, no diagnostic wrapper'
    peer = read(OLD / 'peer-ready.json')
    exact(peer['image']); exact(peer['runtime_environment'])
    assert peer['image']['sha256'] == '433e7051f4c36d0d9b2297dc378631546b7e3c44630cda0653cba2d1ec6bbe8e'
    prior_binding = read(OLD / 'binding.json')
    gguf = prior_binding['GGUF_offline_metadata']
    for kind in ('plain', 'full_mtp'):
        item = gguf[kind]
        assert Path(item['path']).stat().st_size == item['bytes']
    assert gguf['plain']['tensors'] == 320 and gguf['full_mtp']['tensors'] == 335
    assert 'qwen35.nextn_predict_layers' not in gguf['plain']['metadata']
    assert gguf['full_mtp']['metadata']['qwen35.nextn_predict_layers'] == 1
    for name in ('prompt', 'input_manifest', 'schedule', 'protocol', 'GGUF_metadata_receipt'):
        exact(prior_binding[name])
    prompt = Path(prior_binding['prompt']['path']).read_text().split()
    fixture = Path(prior_binding['input_manifest']['path']).parent
    assert len(prompt) == 154 and prompt == (fixture / 'prompt.ids').read_text().split()

    ready = copy.deepcopy(read(OLD / 'ready.json'))
    ready.update(image=current['image'], canonical_main=baseline['compiled']['snapshot'],
        runtime_environment=current['runtime'], link_inputs=current['inputs'],
        build=pin(BUILD / 'ready-cli.json'), actual_dependencies=baseline['compiled']['actual_dependencies'],
        replacement_product_dependencies={key: row['actual_dependencies'] for key, row in current['compiled'].items()},
        instrumented=False)
    save(W / 'ready.json', ready)
    save(W / 'peer-ready.json', peer)
    arms = copy.deepcopy(read(OLD / 'arms.json'))
    for name, row in arms['arms'].items():
        row['ready'] = str(W / ('ready.json' if name.startswith('hyle') else 'peer-ready.json'))
    arms['note'] = 'Current stable-attention five-arm window; only new internally compared samples, no historical pooling.'
    save(W / 'arms.json', arms)
    binding = dict(status='PREPARED_ONLY_ROOT_SCHEDULING_BEFORE_RUN',
        Hyle=current, reused_Model=baseline['compiled'], inherited_Model_ready=frozen['baseline'],
        product_replacements=[dict(original=a, current=b) for a, b in replacements],
        peer=peer, retained_previous_protocol=pin(OLD / 'plan.json'),
        retained_previous_runner=pin(OLD / 'window.py'), current_runner=pin(W / 'window.py'),
        runner_bytes_identical=True, parser_amendment_reused=pin(OLD / 'parser-amendment.json'),
        prompt=prior_binding['prompt'], input_manifest=prior_binding['input_manifest'],
        schedule=prior_binding['schedule'], GGUF_offline_metadata=gguf,
        GGUF_metadata_receipt=prior_binding['GGUF_metadata_receipt'], protocol=prior_binding['protocol'],
        scopes=dict(N=1, R=1, C=1024, prompt_rows_per_turn=154,
            maximum_output_ids_per_turn=64, scenarios=['single', 'two-turn'],
            sampling='original greedy', prefix_cache=False, MTP_K=1),
        endpoint_and_sampler='Original complete producer endpoints and markers; 10ms requested independent PSAPI/PDH sampler; unknown/null readiness remains unknown/null.',
        actual_auto_counts='Require actual publications>0; retain actual submissions/publications/discards/refusals/final_available. No old59/1 or new110/0 count is assumed.',
        historical_samples_pooled=False, payload_copied=False, payload_hashed=False,
        model_or_compiler_processes_started=0)
    save(W / 'binding.json', binding)

    groups = []
    ordinal = 0
    for scenario, mode in GROUPS:
        previous = read(OLD / f'{scenario}-{mode}-plan.json')
        expected = list(ARMS) if mode == 'memory' else [ARMS[(i + j) % 5] for j in range(3) for i in range(5)]
        assert previous['arm_order'] == expected
        group = copy.deepcopy(previous)
        rows = []
        for old in previous['commands']:
            row = copy.deepcopy(old)
            arm = row['arm']; folder = W / f'{scenario}-{mode}' / f"{row['ordinal']:02}-{arm}"
            row['folder'] = str(folder)
            command = row['command']
            if arm.startswith('hyle'):
                command[0] = current['image']['path']
                row.update(image=current['image'], environment=current['runtime'], ready=pin(W / 'ready.json'))
                assert command[command.index('--decode-overlap') + 1] == ('auto' if arm == 'hyle_auto' else 'off')
            else:
                command[0] = peer['image']['path']
                command[command.index('--output') + 1] = str(folder / 'consumer-result.json')
                row.update(image=peer['image'], environment=peer['runtime_environment'], ready=pin(W / 'peer-ready.json'))
                assert command[command.index('--model') + 1] == gguf['full_mtp' if arm == 'peer_mtp' else 'plain']['path']
            assert command[command.index('--mtp') + 1] == ('on' if arm.endswith('_mtp') else 'off')
            assert command[command.index('--capacity') + 1] == '1024'
            assert not any(flag in command for flag in ('--trace', '--decode-ids', '--ignore-eos', '--layer0-probe'))
            if scenario == 'single':
                assert command[command.index('--steps') + 1] == '64'
            else:
                assert command[command.index('--schedule') + 1] == binding['schedule']['path'] and '--steps' not in command
            # Mechanically prove work flags/input/sampling byte-for-byte equal.
            restore = command.copy(); restore[0] = old['command'][0]
            if arm.startswith('peer'):
                restore[restore.index('--output') + 1] = old['command'][old['command'].index('--output') + 1]
            assert restore == old['command']
            ordinal += 1
            assert row['window_ordinal'] == ordinal
            rows.append(row)
        assert Counter(row['arm'] for row in rows) == {arm: 3 if mode == 'timing' else 1 for arm in ARMS}
        assert group['memory_interval_seconds'] == 0.01 and not group['profiler'] and not group['warmup']
        group.update(commands=rows, binding=pin(W / 'binding.json'), configuration=pin(W / 'arms.json'),
            canonical_main=baseline['compiled']['snapshot'], retained_plan=pin(OLD / f'{scenario}-{mode}-plan.json'),
            plan_only=True, current_window_comparison_only=True, historical_samples_pooled=False)
        save(W / f'{scenario}-{mode}-plan.json', group)
        groups.append(dict(scenario=scenario, mode=mode, processes=len(rows),
            order=expected, plan=pin(W / f'{scenario}-{mode}-plan.json')))
    assert ordinal == 40
    plan = dict(status='PREPARED_NOT_RUN_NOT_COMPILED', processes=40, timing_processes=30,
        independent_memory_processes=10, groups=groups,
        ready=pin(BUILD / 'ready-cli.json'), binding=pin(W / 'binding.json'), adapter=pin(W / 'window.py'),
        prepare_script=pin(Path(__file__)), scope=binding['scopes'], metrics=read(OLD / 'plan.json')['metrics'],
        future_commands=[['python', str(W / 'window.py'), 'run-one', scenario, mode] for scenario, mode in GROUPS],
        summary_command=['python', str(W / 'window.py'), 'summary'],
        constraints=['Metadata preparation only; root schedules after numerical components complete.',
            'No historical samples/control pooling; compare only this new five-arm window.',
            'Three timing plus one independent memory process per arm/scenario; no replacement samples.',
            'Same complete producer endpoints, P+D partition, full within-arm non-time reports, IDs/work checks and 10ms PSAPI/PDH/null rules.',
            'Original target-only GGUF for ordinary peer, full target+MTP GGUF only for peer MTP.',
            'Actual auto relay counters/fallback are retained, not constrained to old 59/1 or new 110/0.',
            'Keep original failure/raw logs; stop on first genuine failure, no automatic model retry.',
            'No new CXX/NVCC/SDK/peer/download/model payload copying or profiling.'])
    save(W / 'plan.json', plan)
    save(W / 'prepare-result.json', dict(status='PREPARED_40_NOT_RUN', plan=pin(W / 'plan.json'),
        image=current['image'], runner_unchanged=True, commands=40,
        compiler_processes=0, model_processes=0, GPU_processes=0))
    print('PREPARED_40_NOT_RUN: 30 timing + 10 independent memory; original runner unchanged; 0 model/CXX/GPU')


if __name__ == '__main__':
    main()
