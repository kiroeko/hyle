"""Reuse the exact finite 6 timing + 2 memory B2 runner in this new directory."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
old = W.parents[1]/'.scratch/inference-b2-current-window-20261026/run.py'
spec = importlib.util.spec_from_file_location('retained_b2_window', old)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.D = W
if __name__ == '__main__': m.main()
