"""Publish the completed finite B2 window; explicit small files, no native work."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
W = Path(__file__).resolve().parent
R = W.parents[1]
O = R/'.scratch/inference-b2-current-window-20261026'
D = R/'docs/evidence/performance/inference-b2-reusable-state-2026-10-26'


def read(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.file_digest(p.open('rb'), 'sha256').hexdigest())
def save(p, x):
    with Path(p).open('x', encoding='utf-8') as f: json.dump(x, f, indent=2); f.write('\n')
def stats_only(x): return {k:v for k,v in x.items() if k != 'samples'}


def publish():
    s = read(W/'summary.json'); plan = read(W/'plan.json'); pins = read(W/'pins.json')
    assert s['status'] == 'COMPLETE_8_WITH_FULL_WITHIN_ARM_WORK_STABLE' and len(s['runs']) == 8
    assert all(x['process']['exit'] == 0 for x in s['runs'])
    memory = {}
    for arm, x in s['memory'].items():
        memory[arm] = dict(sample_count=x['sample_count'], running_sample_count=x['running_sample_count'],
            peaks_bytes=x['sampled_peaks'], peaks_GiB={k:v/2**30 for k,v in x['sampled_peaks'].items()},
            actual_sample_gaps_ms=stats_only(x['actual_sample_gaps_ms']),
            sample_cost_ms=stats_only(x['sample_cost_ms']), null_sample_counts=x['null_sample_counts'],
            ready_baseline=x['ready_baseline'], unavailable_reasons=x['unavailable_reasons'],
            setup_error=x['setup_error'], thread_error=x['thread_error'],
            phase_window_sample_counts={k:v['sample_count'] for k,v in x['phase_windows'].items()},
            exact_phase_boundaries=False)
    summary = dict(status=s['status'], date='2026-10-26', hardware='NVIDIA GeForce RTX 4070, CUDA compute capability 8.9, reported VRAM 12281 MiB',
        hyle_image=pins['images']['hyle'], peer_image=pins['images']['peer'],
        formal_current_model=pins['canonical_model_now'], peer_revision='d9e03f1074dbd2979126d91dce1b5d304ec8394e, retained resource-patched native closure; not latest upstream',
        build=dict(new_formal_Model_TUs=1, retained_formal_entry=True, absolute_link_inputs=224,
            reused='Immediately preceding current CUDA2 weights and functional closure; current Graph resources plus eight prior neutral leaf replacements, unchanged native/vendor/report.',
            SDK_native_weight_report_compiles=0, ready=pin(W/'ready.json')),
        workload=dict(sessions=2, turns_per_session=3, capacity=1024, active_sequences=2, prefix_cache='off',
            sampling='greedy', mtp='off', teacher_forced=True, ordinary_noninstrumented=True,
            processed_and_actual_graph_tokens=1728, prefill_rows=1536, decode_rows=192, returned_decisions=198, graph_calls=99),
        window=dict(timing_order=plan['timing_order'], memory_order=plan['memory_order'],
            unmonitored_timing_processes=6, independent_memory_processes=2, extra_behavior_warmup_profiler_processes=0,
            processes=[dict(arm=x['arm'], mode=x['mode'], index=x['index'], pid=x['process']['pid'], exit=x['process']['exit']) for x in s['runs']]),
        timing=s['metrics'], comparisons=s['comparisons'], timing_contract=plan['step_timing_contract'], memory=memory,
        work_checks=dict(exact_fixed_tapes_and_geometry=True, physical_episode_order_equal=s['physical_episode_order_equal'],
            complete_within_arm_nontime_differences=s['within_arm_complete_nontime_differences'],
            cross_engine_returned_ID_differences=len(s['cross_engine_output_differences']),
            historical_returned_ID_differences=[x['historical_output_differences'] for x in s['runs']],
            normalized_clock_paths_and_global_devicefree_telemetry_explicitly_audited=True,
            resources_routes_work_not_excluded=True, quality_acceptance=False),
        scope_limits=plan['fairness_limits'], old_samples_pooled=False,
        attribution='Current Hyle versus retained peer in this same eight-process window. Earlier source/SDK and desktop-window differences prevent attributing cross-window changes solely to this batch or its two optimizations.',
        failures_in_this_B2_window=0, preceding_functional_attempts='Preserved separately under inference-reusable-state-20261026, including initial Graph and CUDA-only warning failures; this performance packet does not relabel them.',
        raw_summary=pin(W/'summary.json'))
    save(W/'compact-summary.json', summary)
    files = []
    def add(p):
        p = Path(p).resolve(); assert p.is_file(), str(p)
        assert p.suffix.lower() in ('.json','.py','.log','.cc','.h','.txt','.ids','.tsv'), str(p)
        if p not in files: files.append(p)
    for name in ['publish.py','build.py','freeze-window.py','run.py','build-plan.json','source-freeze.json',
        'link-inputs.json','runtime.json','ready.json','plan.json','pins.json','expected-work.json','runner-ready.json',
        'execution-binding.json','phase-parser-binding.json','runs.json','run-state.json','summary.json',
        'compact-summary.json','cross-engine-output-differences.json','hyle-nontime-baseline.json','peer-nontime-baseline.json',
        'window-before.json','window-before-gpu.stdout.log','window-before-gpu.stderr.log',
        'window-before-compute_apps.stdout.log','window-before-compute_apps.stderr.log',
        'window-after.json','window-after-gpu.stdout.log','window-after-gpu.stderr.log',
        'window-after-compute_apps.stdout.log','window-after-compute_apps.stderr.log']:
        add(W/name)
    for stage in ['compile','link']:
        for name in ['command.json','process.json','stdout.log','stderr.log']: add(W/stage/name)
    add(W/'compile/actual-dependencies.json')
    for job in plan['commands']:
        folder = Path(job['folder'])
        for name in ['command.json','result.json','stdout.log','stderr.log','normalization-audit.json',
            'complete-nontime-report.json','historical-nontime-differences.json','historical-output-differences.json',
            'within-arm-nontime-differences.json','observation.json']: add(folder/name)
        if job['arm'] == 'peer': add(folder/'peer-result.json')
        if job['mode'] == 'memory':
            add(folder/'memory.json'); add(folder/'memory-summary.json')
    for name in ['run.py','runner-ready.json','parser-correction.json']: add(O/name)
    for row in pins['harness'].values(): add(row['path'])
    add(pins['peer_source_identity_632']['path'])
    for name in ['old_peer_ready','peer_link_plan_632','v2_manifest']: add(pins[name]['path'])
    e = read(W/'expected-work.json')
    add(e['manifest']['path']); add(e['schedule']['path'])
    for row in e['tapes']: add(row['file']['path'])
    frozen = {str(Path(x['path']).resolve()).lower():x for x in read(W/'source-freeze.json')}
    for name in ['engine/models/qwen35/main.cc','engine/models/qwen35/driver.h',
        'engine/models/qwen35/session_state.h','engine/models/qwen35/session_transfer.h',
        'engine/inference/reusable_output_storage.h','engine/inference/state_transfer.h',
        'engine/inference/sampling_graph.h','engine/inference/batch_dispatch.h',
        'engine/inference/request_loop.h','engine/reporting/execution_report.cc','engine/main.cc']:
        q = R/name
        if str(q.resolve()).lower() in frozen: assert pin(q)['sha256'] == frozen[str(q.resolve()).lower()]['sha256']
        add(q)
    archive = D.with_suffix('.zip'); output = D.with_suffix('.json')
    assert not archive.exists() and not output.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files: z.write(p,str(p.relative_to(R)).replace('\\','/'))
    assert archive.stat().st_size < 2_000_000
    summary['archive'] = pin(archive)
    summary['archive_file_count'] = len(files)
    summary['archive_excludes'] = ['EXE','OBJ','PDB','SDK/vendor binaries or source trees','weights/model payloads','old timing samples','full directory walks']
    summary['archived_files'] = [pin(p) for p in files]
    save(output, summary)
    print(json.dumps(dict(summary=pin(output),archive=pin(archive),files=len(files))),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['publish']: publish()
    else: print(__doc__)
