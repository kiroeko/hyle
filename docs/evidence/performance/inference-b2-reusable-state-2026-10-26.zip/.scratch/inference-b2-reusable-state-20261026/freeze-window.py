"""Pin current CLI and cached fixed B2 work; no model, sampler, or build action."""
from pathlib import Path
import hashlib
import json
import sys
W = Path(__file__).resolve().parent
R = W.parents[1]
O = R/'.scratch/inference-b2-current-window-20261026'


def read(p): return json.loads(Path(p).read_bytes())
def pin(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.file_digest(p.open('rb'), 'sha256').hexdigest())
def save(name, x):
    with (W/name).open('x', encoding='utf-8') as f: json.dump(x, f, indent=2); f.write('\n')


def freeze():
    ready = read(W/'ready.json')
    p = read(O/'pins.json')
    p['images'] = {'hyle':ready['image'], 'peer':p['images']['peer']}
    for k,v in [('hyle_ready',W/'ready.json'),('hyle_actual_dependencies',W/'compile/actual-dependencies.json'),
                ('hyle_link_inputs',W/'link-inputs.json'),('hyle_runtime',W/'runtime.json')]: p[k] = pin(v)
    p['hyle_source_pins'] = dict(files=[dict(frozen=x) for x in read(W/'source-freeze.json')])
    p['canonical_model_now'] = pin(R/'engine/models/qwen35/main.cc')
    p['canonical_sampling_now'] = pin(R/'engine/inference/sampling_graph.h')
    p['hyle_link_contract'] = dict(absolute_inputs=224, current_CUDA_case_closure=223,
        remove_test_Model_entry=1, add_formal_Model=1, add_unchanged_formal_entry=1,
        current_weights_and_core_reused=True, newly_compiled_TUs=1)
    p['hyle_live_project_dependency_drift'] = []
    p['current_scope'] = 'Current canonical frozen Model and current CUDA weights/resources/retention neutral leaves, not the historical private Model. Retained native/vendor closure identified by actual link inputs; no latest-upstream assertion.'
    save('pins.json', p)
    save('expected-work.json', read(O/'expected-work.json'))
    plan = read(O/'plan.json')
    plan['directory'] = str(W)
    plan['decision'] = 'One current canonical CUDA formal Model TU with retained unchanged entry and current functional CUDA closure. Root authorized this 8-process window after Windows8 and CUDA3 tiny PASS.'
    plan['hyle_scope'] = p['current_scope']
    plan['pins_file'] = str(W/'pins.json'); plan['expected_work_file'] = str(W/'expected-work.json')
    for job in plan['commands']:
        job['folder'] = str(W/'runs'/Path(job['folder']).name)
        job['command'][0] = p['images'][job['arm']]['path']
        if job['arm'] == 'peer': job['command'][job['command'].index('--result')+1] = str(Path(job['folder'])/'peer-result.json')
        else: job['runtime_environment'] = pin(W/'runtime.json')
    plan['fairness_limits'] = [x for x in plan['fairness_limits'] if not x.startswith('No product changes')]
    plan['fairness_limits'].append('Only this new same-window current Hyle versus retained peer is a comparison; cross-window changes cannot be attributed solely to caller-state reuse or this batch. No old samples pooled.')
    plan['step_timing_contract'] = dict(
        formal_step_seconds='Per-session resolved call start through its finish endpoint, including waiting for its shared batch; StepObservation.step_seconds in retained stderr. Do not add two sessions for aggregate throughput.',
        aggregate_phase='Sum wave.seconds by kind; each shared wave once, includes all result/checkpoint publication to wave endpoint.',
        batch_seconds='Batch before make-room/prepare/submit/finish through first member endpoint; distinct from whole wave and not substituted for it.',
        combined='Returned decisions / journey wall: Hyle interleaved_seconds versus peer session_seconds. Keep producer load/ready/startup endpoints separately.')
    plan['runner_handoff']['path'] = str(W/'run.py')
    plan['runner_handoff']['command'] = ['python','-B',str(W/'run.py'),'run']
    save('plan.json', plan)
    prior = read(O/'runner-ready.json')
    save('runner-ready.json', dict(status='FROZEN_NOT_RUN', files=[pin(q) for q in
        [W/'run.py',W/'freeze-window.py',W/'plan.json',W/'pins.json',W/'expected-work.json',O/'run.py']],
        legacy_phase_code_sha256=prior['legacy_phase_code_sha256'],
        reuse='Import the old guarded runner, redirect only its output/metadata directory. Existing actual process/sampler/phase-parser implementation preserved.',
        process_count=8,source_build=pin(W/'ready.json')))
    print(json.dumps(pin(W/'runner-ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['freeze']: freeze()
    else: print(__doc__)
