"""Root-authorized formal CUDA B2: one Model TU, retained entry/current closure."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-reusable-state-20261026/cuda2'
spec = importlib.util.spec_from_file_location('cached', R/'.scratch/inference-stream-padding-20261026/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = m.b


def build():
    assert b.read(B/'run-summary.json')['status'] == 'THREE_FINITE_PROCESSES_EXIT_ZERO'
    assert not (W/'ready.json').exists() and not (W/'compile').exists()
    source = R/'engine/models/qwen35/main.cc'
    recipe = B/'compile/model/command.json'
    command = m.command(recipe, source, W/'compile')
    assert all(x in command for x in ('/O2', '/W4', '/WX', '/DHYLE_COMPUTE_CUDA=1', '/DGGML_USE_CUDA'))
    assert not any(x in command for x in ('/DHYLE_COMPUTE_CPU=1', '/DHYLE_COMPUTE_VULKAN=1'))
    frozen = m.c.closure([source], [recipe])
    b.save(W/'source-freeze.json', frozen)
    entry = R/'.scratch/inference-current-closure-20261026/engine/entry/unit.obj'
    entry_dependencies = b.read(entry.parent/'actual-dependencies.json')
    for row in entry_dependencies: b.exact(row)
    before = b.read(B/'link-inputs.json')
    assert len(before) == 223 and all(Path(x['path']).is_file() for x in before)
    old_model = B/'compile/model/unit.obj'
    assert sum(b.key(x['path']) == b.key(old_model) for x in before) == 1
    b.save(W/'build-plan.json', dict(source=b.pin(source), recipe=b.pin(recipe), command=command,
        source_freeze=b.pin(W/'source-freeze.json'), baseline_ready=b.pin(B/'ready.json'),
        baseline_inputs=b.pin(B/'link-inputs.json'), entry=b.pin(entry), entry_dependencies=entry_dependencies,
        CUDA_functional_summary=b.pin(B/'run-summary.json'), compiled_TUs=1,
        weight_report_SDK_native_compiles=0, macro_contract='CUDA-only same as current weights'))
    helper = b.helper()
    env = helper.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':command[0],
        'CMAKE_CXX_COMPILER':command[0], 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    compiled = helper.execute(command, env, W/'compile', timeout=180)
    dep = b.read(W/'compile/dependencies.json')['Data']
    actual = [b.pin(q) for q in dict.fromkeys([dep['Source'], *dep['Includes']])]
    own = {b.key(x['path']):x for x in frozen}
    for row in actual:
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
            assert own[b.key(p)]['sha256'] == row['sha256'], str(p)
    b.save(W/'compile/actual-dependencies.json', actual)
    for row in frozen: b.exact(row)
    obj = b.pin(W/'compile/unit.obj')
    image = W/'link/hyle.exe'
    args, replaced = [], 0
    for arg in b.read(B/'link/command.json')['command']:
        if b.key(arg) == b.key(old_model): arg = obj['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert replaced == 1 and not any(b.key(x) == b.key(entry) for x in args)
    args.append(str(entry))
    linked = helper.execute(args, env, W/'link', timeout=120)
    inputs = [obj if b.key(x['path']) == b.key(old_model) else x for x in before]+[b.pin(entry)]
    assert len(inputs) == 224
    b.save(W/'link-inputs.json', inputs)
    runtime = b.read(B/'runtime.json')
    b.exact(runtime['native'])
    alias = image.parent/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    b.save(W/'runtime.json', runtime)
    b.save(W/'ready.json', dict(status='FORMAL_CUDA_BUILT_NOT_RUN', image=b.pin(image),
        app=obj, source_freeze=b.pin(W/'source-freeze.json'), actual_dependencies=b.pin(W/'compile/actual-dependencies.json'),
        link_inputs=b.pin(W/'link-inputs.json'), runtime=b.pin(W/'runtime.json'),
        compile=compiled, link=linked, compiled_TUs=1, other_TU_SDK_native_compiles=0))
    print('B2_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['build']: build()
    else: print(__doc__)
