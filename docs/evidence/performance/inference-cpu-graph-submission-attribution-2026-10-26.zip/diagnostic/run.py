"""Sole P154/16 Graph submission observation; no timing screen or retry."""
from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,threading,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent;R=B.parents[1];out=W/'run';out.mkdir()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
ready=read(W/'ready.json');assert pin(ready['image']['path'])==ready['image'];rt=read(W/'runtime.json')
command=list(read(B/'poll-default1/behavior1/command.json')['command']);command[0]=ready['image']['path']
save(out/'command.json',dict(command=command,cwd=str(R),timeout_seconds=180))
env=os.environ.copy();env['PATH']=rt['PATH'];env.update(rt.get('configured_flags',{}));env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
k=ctypes.WinDLL('kernel32',use_last_error=True);qpc=k.QueryPerformanceCounter;qpc.argtypes=[ctypes.POINTER(ctypes.c_longlong)];qpc.restype=ctypes.c_int;freq=ctypes.c_longlong();assert k.QueryPerformanceFrequency(ctypes.byref(freq))
markers=[]
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 started=time.perf_counter();process=subprocess.Popen(command,cwd=R,env=env,stdout=stdout,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
 save(out/'running.json',dict(pid=process.pid));print('MODEL_START PID',process.pid,flush=True)
 def collect():
  for line in iter(process.stderr.readline,b''):
   if line.startswith(b'memory_phase='):
    a=time.perf_counter_ns();tick=ctypes.c_longlong();ok=qpc(ctypes.byref(tick));z=time.perf_counter_ns()
    markers.append(dict(line=line.decode().strip(),receive_perf_before_ns=a,receive_perf_after_ns=z,receive_qpc=tick.value,qpc_ok=bool(ok)))
   stderr.write(line)
  process.stderr.close()
 collector=threading.Thread(target=collect);collector.start();timeout=False
 try:code=process.wait(timeout=180)
 except subprocess.TimeoutExpired:process.kill();process.wait();code=-999;timeout=True
 collector.join()
result=dict(pid=process.pid,exit=code,timed_out=timeout,wall_seconds=time.perf_counter()-started)
save(out/'process.json',result);save(out/'phase-receive.json',dict(qpc_frequency=freq.value,markers=markers,clock='QPC bridge to perf_counter_ns; marker timestamps are receipt times, not exact producer fprintf times.'))
print('MODEL_TERMINAL',json.dumps(result),flush=True)
assert code==0,result
actual=read(out/'stdout.log');control=read(B/'poll-default1/behavior1/stdout.log')
time_keys={'seconds','unix_ms','unix_ns','clock_unix'}
def normalize(x):
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items() if k not in time_keys and not k.endswith('_seconds') and not k.endswith('tokens_per_second')}
 if isinstance(x,list):return [normalize(v) for v in x]
 return x
def diff(a,b,path='$'):
 if type(a)!=type(b):return [dict(path=path,before=a,after=b)]
 if isinstance(a,dict):
  rows=[]
  for key in a.keys()|b.keys():
   if key not in a or key not in b:rows.append(dict(path=path+'.'+key,before=a.get(key),after=b.get(key)))
   else:rows+=diff(a[key],b[key],path+'.'+key)
  return rows
 if isinstance(a,list):
  if len(a)!=len(b):return [dict(path=path,before_length=len(a),after_length=len(b))]
  return [row for i,(x,y) in enumerate(zip(a,b)) for row in diff(x,y,path+f'[{i}]')]
 return [] if a==b else [dict(path=path,before=a,after=b)]
differences=diff(normalize(control),normalize(actual));save(out/'nontime-diff.json',differences)
save(out/'summary.json',dict(status='WORK_PASS_OBSERVATION_ANALYSIS_PENDING' if not differences else 'WORK_DIFFERENCE_STOP',process=result,normal_reference=pin(B/'poll-default1/behavior1/stdout.log'),full_nontime_differences=len(differences),clock_keys_only_excluded=True,image=ready['image'],source_pins=pin(W/'source-pins.json'),model_processes=1,throughput_claim=False))
assert not differences,differences[:10]
print('FULL_NONTIME_0DIFF CPU_RELEASED',flush=True)
