"""One private Graph submission TU; replace only its actual8ebb link object."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;B=W.parent;R=B.parents[1];CONTROL=B/'poll-default1'
spec=importlib.util.spec_from_file_location('submission_build_tools',B/'check_build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read=b.read;pin=b.pin;save=b.save
recipe=R/'.scratch/inference-current-closure-20261026/headers79/graph--submission_cc/command.json'
old=read(recipe)['command'];cmd=[];skip=False
for a in old:
 if skip:skip=False;continue
 if a.lower()=='/sourcedependencies':skip=True;continue
 if a.lower().startswith(('/fo','/fd')) or a.lower().endswith(('.cc','.cpp')):continue
 cmd.append(a)
source=W/'source/src/graph/submission.cc';assert pin(source)['sha256']==read(W/'source-pins.json')['after']['sha256'];out=W/'compile'
cmd += [str(source),'/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'unit.obj'),'/Fd'+str(out/'unit.pdb')]
compiled=b.h.execute(cmd,b.env(cmd),out,timeout=120)
d=read(out/'dependencies.json')['Data'];deps=[pin(p) for p in dict.fromkeys([d['Source'],*d['Includes']])];save(out/'actual-dependencies.json',deps)
old=read(CONTROL/'link/command.json')['command'];newobject=pin(out/'unit.obj');oldobject=pin(R/'.scratch/inference-current-closure-20261026/headers79/graph--submission_cc/unit.obj');seen=0;cmd=[];out=W/'link';image=out/'hyle.exe'
for a in old:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if b.key(a)==b.key(oldobject['path']):seen+=1;a=newobject['path']
 cmd.append(a)
assert seen==1
inputs=[]
for p in read(CONTROL/'link-inputs.json'):
 assert pin(p['path'])==p,p['path']
 inputs.append(newobject if b.key(p['path'])==b.key(oldobject['path']) else p)
save(W/'link-inputs.json',inputs)
cmd += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
linked=b.h.execute(cmd,b.env(cmd),out,timeout=120)
rt=read(CONTROL/'runtime.json');native=Path(rt['native']['path']);target=out/Path(rt['native_hardlink']['path']).name;os.link(native,target);rt['native_hardlink']=pin(target);save(W/'runtime.json',rt)
ready=dict(status='BUILT_NOT_RUN',image=pin(image),compile=compiled,link=linked,source=pin(source),source_pins=pin(W/'source-pins.json'),actual_dependencies=pin(W/'compile/actual-dependencies.json'),link_inputs=pin(W/'link-inputs.json'),runtime=pin(W/'runtime.json'),original_ready=pin(CONTROL/'ready.json'),replacement=dict(before=oldobject,after=newobject),all_other_link_inputs_unchanged=True,model_runs=0)
save(W/'ready.json',ready);print('READY',json.dumps(ready['image']),flush=True)
