from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time,zipfile
route,mode,attempt=sys.argv[1:4];assert route in ['cuda','apple'] and mode in ['static','shared']
air=sys.platform=='darwin';assert air==(route=='apple')
base=Path('/Users/kiro/hyle-scratch/compute-unified' if air else '/root/hyle-scratch/compute-unified')
canonical=Path('/mnt/c/public/project-hyle/hyle') if not air else None
source=base/('source-c8874688' if air else 'source-7a7b4c3b')
resume_install='--resume-after-build' in sys.argv
resume='--resume-consumer' in sys.argv or resume_install
tag=f'{route}-{mode}-{attempt}';out=(base/'g07-sdk-evidence' if air else canonical/'.scratch/inference-gaps/g07-sdk')/tag
folder=base/'g07-sdk'/tag
if not resume:out.mkdir(parents=True,exist_ok=False);folder.mkdir(parents=True,exist_ok=False)
producer=base/f'{"a" if air else "l"}-cpu-{route}/selected-graph/{mode}-sdk-build'
package=(base/'g07-input-9.zip') if air else canonical/'.scratch/inference-gaps/g07-input-9.zip'
cmake='/opt/homebrew/bin/cmake' if air else 'cmake';ninja='/opt/homebrew/bin/ninja' if air else 'ninja'
env=os.environ.copy();env['PATH']=('/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' if air else '/usr/local/cuda-13.3/bin:')+env['PATH']
if not air:env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),route=route,mode=mode,attempt=attempt,candidate='b483b8939e9c1d28a98eee3a6ecd13b3fd45fc88',producer=str(producer),folder=str(folder),max_jobs=4 if air else 2,stages=[])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(tag,stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
def verify(prefix,consumer,build,fixtures,headers,manifest):
 actual=json.loads((build/'compile_commands.json').read_text());assert len(actual)==len(fixtures)+len(headers)
 assert all(str(source) not in x['command'] and str(producer) not in x['command'] and str(prefix/'include') in x['command'] for x in actual)
 (out/'consumer-commands.json').write_text(json.dumps(actual,indent=2))
 for name in fixtures:run(name,[str(build/name)])
 if not air:
  for name in fixtures:
   result=subprocess.check_output(['ldd',str(build/name)],env=env,text=True);(out/(name+'-ldd.log')).write_text(result)
   assert 'not found' not in result and str(producer) not in result and str(base/'g06-final-sdk') not in result
 r['headers']=[dict(path=p,sha256=sha(prefix/'include/hyle'/p)) for p in headers]
 r['consumers']=[dict(name=name,source_path=path,source_sha256=sha(consumer/path),artifact=str(build/name),artifact_sha256=sha(build/name)) for name,path in fixtures.items()]
 owner='compute_route_apple' if air else 'compute_provider_torch_cuda'
 artifacts=[p for p in (prefix/'lib').glob('libhyle_'+owner+'*') if p.is_file() and not p.is_symlink()];assert artifacts
 r['owner_artifacts']=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in artifacts]
 assert all(sha(source/i['path'])==i['sha256'] for i in manifest['inputs'])
 r['state']='RELOCATED_SDK_PUBLIC_CONSUMERS_AND_HEADERS_PASS';save();print(tag,r['state'],flush=True)
def install_and_consume(manifest):
 staging=folder/'staging';prefix=folder/'relocated'
 if air:
  previous=base/f'g06-final-sdk/apple-{mode}-1/relocated'
  if previous.is_dir():
   run('clone-qualified-sdk',['/bin/cp','-cR',str(previous),str(staging)])
   probe=next(p for p in (previous/'lib').glob('libhyle*') if p.is_file() and not p.is_symlink())
   assert (staging/'lib'/probe.name).stat().st_ino!=probe.stat().st_ino
   r['apfs_clone']='Independent CoW inode snapshot; no hardlinks or reverse source copy.'
  else:r['sdk_base']='Fresh install from current qualified producer; the disposable old G06 prefix was removed earlier.'
 run('install',[cmake,'--install',str(producer),'--prefix',str(staging)])
 staging.rename(prefix);assert not staging.exists()
 consumer=folder/'consumer';consumer.mkdir();copied=set()
 def copy(relative):
  if relative in copied:return
  p=source/relative;assert p.resolve().is_relative_to(source.resolve()) and not relative.startswith('src/')
  data=p.read_bytes();dest=consumer/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);copied.add(relative)
  for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode('utf-8'),re.M):
   q=(p.parent/include).resolve();assert q.is_relative_to(source.resolve()) and not q.is_relative_to(source/'src'),(relative,include)
   copy(q.relative_to(source).as_posix())
 fixtures={'packed':'tests/'+('compute_route_apple' if air else 'compute_provider_torch_cuda')+'/packed_resident_consumer.cc','weights':f'samples/package/compute/{route}_weights/main.cc','joint':f'samples/package/graph/cpu_{route}/main.cc'}
 for p in fixtures.values():copy(p)
 headers=['compute/apple.h','compute/apple_weights.h','compute/model_ops.h','graph/cpu_apple.h'] if air else ['compute/providers/torch_cuda.h','compute/backends/cuda.h','compute/model_ops.h','compute/prepared_operation.h','graph/cpu_cuda.h']
 for i,name in enumerate(headers):
  assert sha(prefix/'include/hyle'/name)==sha(source/'include/hyle'/name)
  (consumer/f'header-{i}.cc').write_text('#include <hyle/'+name+'>\n')
 body='cmake_minimum_required(VERSION 3.25)\nproject(g07_public_sdk LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\n'
 for name,path in fixtures.items():
  body+=f'add_executable({name} "{path}")\ntarget_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::compute hyle::graph)\ntarget_compile_options({name} PRIVATE -Wall -Wextra -Wpedantic -Werror)\nhyle_stage_runtime({name})\n'
 body+='add_library(headers OBJECT '+' '.join(f'header-{i}.cc' for i in range(len(headers)))+')\ntarget_compile_features(headers PRIVATE cxx_std_23)\ntarget_compile_options(headers PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries(headers PRIVATE hyle::compute hyle::graph)\n'
 (consumer/'CMakeLists.txt').write_text(body);(out/'consumer.cmake').write_text(body)
 build=folder/'consumer-build';args=[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
 if not air:args+=['-DCMAKE_CXX_COMPILER=/usr/bin/g++-14','-DCUDAToolkit_ROOT=/usr/local/cuda-13.3']
 run('consumer-configure',args);run('consumer-build',[cmake,'--build',str(build),'--parallel','4' if air else '2'])
 verify(prefix,consumer,build,fixtures,headers,manifest)
if resume_install:
 r=json.loads((out/'result.json').read_text());assert r['state']=='SETUP_FAIL' and any(x['stage']=='build' and x['exit_code']==0 for x in r['stages'])
 started=time.monotonic()-r['elapsed_seconds'];r['prior_setup_failure']=r.pop('error');r['resume_reason']='Original SDK clone prefix was already cleaned up; preserve completed producer and use a normal fresh install. No reconfigure, rebuild or budget reset.'
 manifest=json.loads((out/'input-manifest.json').read_text());assert all(sha(source/i['path'])==i['sha256'] for i in manifest['inputs'])
 install_and_consume(manifest);raise SystemExit(0)
if resume:
 assert not air
 r=json.loads((out/'result.json').read_text());assert r['state']=='FAIL' and r['stages'][-1]['stage']=='consumer-build'
 started=time.monotonic()-r['elapsed_seconds'];r['prior_consumer_failure']='Public test called a Provider factory not directly linked by the shared public facade; switch only this test to the normal public CUDA Context. Product and installed prefix unchanged.'
 manifest=json.loads((out/'input-manifest.json').read_text());prefix=folder/'relocated';consumer=folder/'consumer';build=folder/'consumer-build'
 fixtures={'packed':'tests/compute_provider_torch_cuda/packed_resident_consumer.cc','weights':'samples/package/compute/cuda_weights/main.cc','joint':'samples/package/graph/cpu_cuda/main.cc'}
 headers=['compute/providers/torch_cuda.h','compute/backends/cuda.h','compute/model_ops.h','compute/prepared_operation.h','graph/cpu_cuda.h']
 p=canonical/fixtures['packed'];r['fixture_update']=dict(path=fixtures['packed'],previous_sha256=sha(consumer/fixtures['packed']),current_sha256=sha(p),canonical_revision=subprocess.check_output(['git','-C',str(canonical),'rev-parse','HEAD'],text=True).strip())
 (consumer/fixtures['packed']).write_bytes(p.read_bytes());save()
 run('consumer-build-resume',[cmake,'--build',str(build),'--parallel','2'])
 verify(prefix,consumer,build,fixtures,headers,manifest);raise SystemExit(0)
try:
 assert source.is_dir() and not (source/'.git').exists()
 r['identity']={name:subprocess.check_output(cmd,env=env,text=True).strip() for name,cmd in ([('model',['/usr/sbin/sysctl','-n','hw.model']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])] if air else [('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['nvcc','--version']),('gpu',['/usr/lib/wsl/lib/nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'])])}
 if air:assert r['identity']['model']=='Mac16,12'
 with zipfile.ZipFile(package) as z:
  manifest=json.loads(z.read('input-manifest.json'));changed=[]
  for item in manifest['inputs']:
   rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
   data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256'];p=source/rel
   if not p.exists() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);changed.append(item['path'])
  (out/'input-manifest.json').write_text(json.dumps(manifest,indent=2))
 r['snapshot_head']=manifest['candidate'];r['synced_paths']=changed
 registry=json.loads((source/'docs/implementation/module-status.json').read_text())
 assert all(next(x for x in registry['modules'] if x['module']==name)['state']=='CANDIDATE' for name in ['compute_provider_torch_cuda','compute_route_apple'])
 args=[cmake,'-S',str(source),'-B',str(producer),'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_COMPONENTS=compute;graph']
 args+=['-UCMAKE_PROJECT_INCLUDE'] if air else ['-DCMAKE_PROJECT_INCLUDE='+str(canonical/'.scratch/inference-gaps/g07_cuda_profile.cmake')]
 run('configure',args);run('manifest',[ninja,'-C',str(producer),'build.ninja'])
 commands=json.loads(subprocess.check_output([ninja,'-C',str(producer),'-t','compdb'],env=env,text=True))
 shipping=[x for x in commands if x['file'].startswith(str(source/'src')+'/')];assert shipping and all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
 (out/'shipping-commands.json').write_text(json.dumps(shipping,indent=2))
 if air:
  build_manifest=out/'preview.ninja';build_manifest.write_bytes((producer/'build.ninja').read_bytes())
 else:
  helper=canonical/'.scratch/inference-gaps/g04-g05/ce28_shipping_native_reuse_wsl.py'
  label='g07-sdk-'+attempt
  run('native-reuse',['python3',str(helper),mode,label])
  reuse=helper.parent/f'ce28-{mode}-native-reuse-{label}'
  proof=json.loads((reuse/'result.json').read_text());assert proof['state']=='PASS_146_SHIPPING_OBJECTS_NATIVE_NINJA_NO_WORK'
  r['native_reuse']=proof;build_manifest=reuse/'reuse.ninja'
 targets=['hyle_compute','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',f'hyle_graph_route_cpu_{route}',f'hyle_compute_route_{route}',f'hyle_graph_route_{route}']
 if not air:targets+=['hyle_compute_provider_torch_cuda']
 dry=subprocess.check_output([ninja,'-C',str(producer),'-f',str(build_manifest),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
 cuda=[x for x in dry.splitlines() if 'Building CUDA object' in x];r['cuda_edges']=cuda;r['build_edges']=len(dry.splitlines());save()
 assert len(cuda)<=1 and all('compute_provider_torch_cuda' in x for x in cuda),cuda
 assert 'Re-running CMake' not in dry
 run('build',[ninja,'-C',str(producer),'-f',str(build_manifest),'-j','4' if air else '2',*targets])
 install_and_consume(manifest)
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
