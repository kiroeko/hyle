"""Seal the fixed18 G08 delivery configurations without rerunning old tests."""
from pathlib import Path
import hashlib,json,zipfile

root=Path(__file__).resolve().parents[2];base=root/'evidence/delivery';scratch=root/'.scratch/inference-gaps'
candidate='5103c13d8ed119b06aa64e799f9768aea45ab913';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
passing={'RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_RUNTIME_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS'}
cases=[];prior=[]
def accept(platform,r,origin):
    assert r['state'] in passing and r['candidate']==candidate,(platform,r['route'],r['mode'],r['state'])
    assert len(r['consumers'])==(3 if r['route']=='cpu' else 6)
    assert len(r['independent_headers'])==(8 if r['route']=='cpu' else 13 if r['route']=='cuda' else 11)
    if r['mode']!='source':assert len(r['random123_license'])>=2
    cases.append(dict(platform=platform,route=r['route'],mode=r['mode'],state=r['state'],source_snapshot=r['source_snapshot'],elapsed_seconds=r['elapsed_seconds'],result_origin=origin,consumers=r['consumers'],independent_headers=r['independent_headers']))
def archived(directory,record,entries):
    path=base/directory/record;r=json.loads(path.read_text());raw=r.get('raw_archive',r.get('raw'));archive=path.parent/raw['path'];assert sha(archive)==raw['sha256']
    prior.append(dict(receipt=path.relative_to(root).as_posix(),sha256=sha(path),raw=raw))
    with zipfile.ZipFile(archive) as z:
        for platform,entry in entries:accept(platform,json.loads(z.read(entry)),dict(receipt=path.relative_to(root).as_posix(),archive_entry=entry))
archived('inference-g08-air-sdk-checkpoint','receipt.json',[('air',r+'-'+m+'-1/result.json') for r in ['apple','vulkan'] for m in ['shared','static','source']])
archived('inference-g08-windows-cpu-sdk-checkpoint','receipt.json',[('windows','result.json')])
archived('inference-g08-windows-cpu-sdk-checkpoint','remaining.json',[('windows','static/result.json'),('windows','source/result.json')])
archived('inference-g08-cuda-sdk-checkpoint','receipt.json',[('windows','windows-shared/result.json'),('wsl','wsl-static/result.json')])
matrix=scratch/'g08-remaining-sdk-matrix-1';original=json.loads((matrix/'result.json').read_text())
assert original['state'] in ['ALL_SEVEN_DELIVERY_CONFIGS_PASS','FAIL_WITH_ALL_CONFIGS_OBSERVED'] and len(original['cases'])==7,'Original serial matrix is not yet terminal'
fresh=[('wsl','cuda','shared'),('wsl','cuda','source'),('windows','cuda','static'),('windows','cuda','source'),('windows','vulkan','shared'),('windows','vulkan','static'),('windows','vulkan','source')]
folders=[]
for platform,route,mode in fresh:
    folder=scratch/('g08-sdk-windows' if platform=='windows' else 'g08-sdk')/(route+'-'+mode+'-1');r=json.loads((folder/'result.json').read_text())
    accept(platform,r,dict(archive_entry=platform+'-'+route+'-'+mode+'/result.json'))
    for row in r['consumers']:
        binary=Path('//wsl.localhost/Ubuntu-24.04'+row['path']) if platform=='wsl' else Path(row['path'])
        assert sha(binary)==row['sha256'],('current fresh consumer artifact changed',str(binary))
    folders.append((platform+'-'+route+'-'+mode,folder))
keys={(x['platform'],x['route'],x['mode']) for x in cases};assert len(keys)==len(cases)==18
expected={(p,r,m) for p,r in [('windows','cpu'),('windows','cuda'),('windows','vulkan'),('wsl','cuda'),('air','apple'),('air','vulkan')] for m in ['source','static','shared']};assert keys==expected
out=base/'inference-g08-sdk-final';out.mkdir(exist_ok=False)
proofs=[scratch/'g08-posix-source-native-reuse-1',scratch/'g08-posix-source-native-reuse-2',scratch/'g08-posix-source-cuda-edge-audit',scratch/'g04-g05/ce28-shared-native-reuse-g08-sdk-1']
proofs+=sorted(scratch.glob('g08-windows-static-native-reuse-*'))+sorted(scratch.glob('g08-windows-source-native-reuse-*'))
with zipfile.ZipFile(out/'raw.zip','x',zipfile.ZIP_DEFLATED) as z:
    for name,folder in folders+[('original-serial-matrix',matrix)]+[('native-proofs/'+p.name,p) for p in proofs]:
        assert folder.is_dir(),str(folder)
        for p in folder.rglob('*'):
            if p.is_file():z.write(p,name+'/'+p.relative_to(folder).as_posix())
    for name in ['g08_sdk.py','g08_sdk_windows.py','g08_windows_cuda_native_reuse.py','g08_posix_source_native_reuse.py','g08_shipping_cuda_profile.cmake','g08_remaining_sdk_matrix.py','g08_seal_sdk_final.py']:
        z.write(scratch/name,'private-helpers/'+name)
receipt=dict(schema='hyle.inference-g08-sdk-final/v1',verdict='ALL_18_SOURCE_STATIC_SHARED_DELIVERIES_PASS',candidate=candidate,configs=18,cases=cases,prior_evidence=prior,
    raw=dict(path='raw.zip',sha256=sha(out/'raw.zip'),bytes=(out/'raw.zip').stat().st_size),
    original_matrix=dict(state=original['state'],cases=original['cases'],elapsed_seconds=original['elapsed_seconds']),
    retained_failure='Original WSL source helper assumed one historical unary object profile but found two. Both candidates were subsequently checked by exact input bytes, original Ninja commands and dependency freshness; exactly one qualified. The original48.571s remain. A second pre-build guard admitted only two CUDA TUs; actual source delivery needed ten exact Hyle dependency TUs (new/missing objects, device-status/native-batch header updates and old command drift). Ninja explanations and exact canonical source inputs were audited before admitting them. Both failures and cumulative same-tree cost remain; no product change, source reset or native-object timestamp/content mutation.',
    runtime='Windows PE imports/staged Hyle DLL hashes and isolated PATH; POSIX ldd and Air actual dyld probes as separately archived. External validated LibTorch SDK/cache remains required by the existing distribution contract. Windows is not actual loaded-module tracing; host and device risk qualifications are separate records.',
    scope='Exactly six supported profiles x source/static/shared. Public CPU/native Direct/Graph, joint and existing three Mem regression consumers;8/11/13 independent public headers. Binary SDK relocation and Random123 license/NOTICE installation checked; source embeds the pinned in-tree licensed implementation. Prior eleven configurations reuse immutable execution evidence; seven fresh final consumer binaries are rehashed here. No new risk run, P1 or full-engine claim.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(verdict=receipt['verdict'],configs=len(cases),archive_bytes=receipt['raw']['bytes'])))
