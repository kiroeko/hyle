from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[2];label,package=sys.argv[1:3]
out=root/'.scratch/inference-gaps'/f'g08-remaining-sdk-matrix-{label}';out.mkdir(exist_ok=False)
prior=json.loads((root/'.scratch/inference-gaps/g08-sdk-windows/cuda-shared-1/result.json').read_text())
assert prior['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS'
started=time.monotonic();r=dict(state='RUNNING',pid=os.getpid(),serial=True,cases=[],
    scope='Seven remaining frozen G08 source/static/shared delivery configurations only; independent failures are retained and later configurations still observed.')
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
cases=[('wsl','cuda','shared'),('wsl','cuda','source'),('windows','cuda','static'),('windows','cuda','source'),
       ('windows','vulkan','shared'),('windows','vulkan','static'),('windows','vulkan','source')]
for platform,route,mode in cases:
    key=f'{platform}-{route}-{mode}';log=out/(key+'.log')
    if platform=='windows':
        cmd=[sys.executable,'-X','utf8',str(root/'.scratch/inference-gaps/g08_sdk_windows.py'),route,mode,label]
        if route=='cuda':cmd+=['--native-reuse-auto']
        path=root/f'.scratch/inference-gaps/g08-sdk-windows/{route}-{mode}-{label}/result.json'
    else:
        cmd=['wsl','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g08_sdk.py',route,mode,label,package]
        path=root/f'.scratch/inference-gaps/g08-sdk/{route}-{mode}-{label}/result.json'
    assert not path.exists(),str(path)
    with log.open('wb') as stream:
        p=subprocess.Popen(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
        r.update(stage=key,child_pid=p.pid);save();print(key,p.pid,flush=True);code=p.wait()
    result=json.loads(path.read_text()) if path.exists() else dict(state='NO_RESULT')
    r['cases'].append(dict(platform=platform,route=route,mode=mode,exit_code=code,state=result['state'],result=str(path),log=str(log)))
    r.pop('child_pid',None);save();print(key,code,result['state'],flush=True)
r['state']='ALL_SEVEN_DELIVERY_CONFIGS_PASS' if all(x['exit_code']==0 and x['state'] in ['PUBLIC_SOURCE_CONSUMERS_HEADERS_RUNTIME_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_RUNTIME_PASS','RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_LICENSE_PASS','PUBLIC_SOURCE_CONSUMERS_HEADERS_PASS'] for x in r['cases']) else 'FAIL_WITH_ALL_CONFIGS_OBSERVED'
save();print(r['state'],flush=True)
