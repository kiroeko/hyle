from pathlib import Path
import hashlib,json,subprocess,sys,time
root=Path('/mnt/c/public/project-hyle/hyle')
build=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/source-build')
label=sys.argv[1];out=root/'.scratch/inference-gaps'/f'g08-posix-source-native-reuse-{label}'
out.mkdir(exist_ok=False);started=time.monotonic();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=dict(state='SETUP',build=str(build))
def save():r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
try:
    commands=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],text=True))
    unary=next(x for x in commands if x['file'].endswith('/src/ggml-cuda/unary.cu'))
    current=Path(unary['file'].split('/src/ggml-cuda/')[0])
    precise=current.parent/'CMakeFiles/ggml-cuda-precise-unary.dir'
    objects=sorted(p for p in precise.rglob('unary.cu.o') if current.name not in p.parts)
    assert objects
    expected=json.loads((root/'.scratch/inference-gaps/g04-g05/cuda-host-san/ggml-cuda-reuse-proof.json').read_text())['modes']['asan']
    for name,digest in expected['derived_dependencies']:assert sha(current/name)==digest,name
    for name,digest in expected['canonical_dependencies']:assert sha(root/name)==digest,name
    trials=[];qualified=[]
    for object_file in objects:
        old=current.parent/object_file.relative_to(precise).parts[0]
        trial=dict(old_source=str(old));trial_dir=out/old.name;trial_dir.mkdir()
        different=[name for name,digest in expected['derived_dependencies'] if not (old/name).is_file() or sha(old/name)!=digest]
        if different:trial.update(state='INPUT_MISMATCH',different=different);trials.append(trial);continue
        lines=(build/'build.ninja').read_text().splitlines(keepends=True);result=[];mapped=[];i=0;old_unary=new_unary=None
        while i<len(lines):
            line=lines[i]
            if line.startswith('build ') and '.cu.o:' in line and ('/CMakeFiles/ggml-cuda.dir/' in line or '/CMakeFiles/ggml-cuda-precise-unary.dir/' in line):
                block=[line];i+=1
                while i<len(lines) and lines[i].startswith('  '):block.append(lines[i]);i+=1
                before=''.join(block);after=before.replace(current.name,old.name)
                a=before.splitlines()[0][6:].split(': ',1)[0];b=after.splitlines()[0][6:].split(': ',1)[0]
                assert (build/b).is_file(),b
                if a!=b:new_unary,old_unary=a,b
                mapped.append(dict(output=b,sha256=sha(build/b),before=before,after=after));result.append(after)
            else:result.append(line);i+=1
        assert len(mapped)==146 and old_unary and new_unary
        preview=trial_dir/'reuse.ninja';preview.write_text(''.join(result).replace(new_unary,old_unary))
        dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*[x['output'] for x in mapped]],text=True)
        (trial_dir/'object-check.log').write_text(dry)
        passed='Building CUDA object' not in dry and 'Re-running CMake' not in dry
        trial['state']='ORIGINAL_COMMANDS_AND_DEPENDENCIES_FRESH' if passed else 'COMMAND_OR_DEPENDENCY_MISMATCH'
        trials.append(trial)
        if passed:qualified.append((old,preview,mapped,dry))
    r['old_profile_trials']=trials
    assert len(qualified)==1,trials
    old,selected,mapped,dry=qualified[0]
    preview=out/'reuse.ninja';preview.write_bytes(selected.read_bytes())
    (out/'object-check.log').write_text(dry)
    (out/'mapped-edges.json').write_text(json.dumps(mapped,indent=2)+'\n')
    r.update(state='PASS_146_POSIX_SOURCE_NATIVE_OBJECTS_INPUTS_AND_ORIGINAL_COMMANDS_FRESH',old_derived_source=str(old),current_derived_source=str(current),
        verified_derived_inputs=242,verified_canonical_inputs=5,native_objects=146,
        original_manifest_sha256=sha(build/'build.ninja'),reuse_manifest_sha256=sha(preview),
        scope='Private source-build-only adaptation of the existing shipping reuse proof. Same original object commands and dependency freshness; no source/object content or timestamp mutation.')
    save();print(json.dumps(r))
except BaseException as error:r.update(state='FAIL',error=repr(error));save();raise
