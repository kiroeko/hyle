#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_error" for configuration "Release"
set_property(TARGET hyle::_factor_error APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_error PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_error.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_error )
list(APPEND _cmake_import_check_files_for_hyle::_factor_error "${_IMPORT_PREFIX}/lib/libhyle_error.a" )

# Import target "hyle::_factor_time" for configuration "Release"
set_property(TARGET hyle::_factor_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_time PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_time.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_time )
list(APPEND _cmake_import_check_files_for_hyle::_factor_time "${_IMPORT_PREFIX}/lib/libhyle_time.a" )

# Import target "hyle::_factor_platform" for configuration "Release"
set_property(TARGET hyle::_factor_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform "${_IMPORT_PREFIX}/lib/libhyle_platform.a" )

# Import target "hyle::_factor_platform_thread" for configuration "Release"
set_property(TARGET hyle::_factor_platform_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_thread PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_thread )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_thread "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.a" )

# Import target "hyle::_factor_platform_fs" for configuration "Release"
set_property(TARGET hyle::_factor_platform_fs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_fs PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform_fs.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_fs )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_fs "${_IMPORT_PREFIX}/lib/libhyle_platform_fs.a" )

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_mem.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/libhyle_mem.a" )

# Import target "hyle::_factor_mem_vm" for configuration "Release"
set_property(TARGET hyle::_factor_mem_vm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem_vm PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_mem_vm.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem_vm )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem_vm "${_IMPORT_PREFIX}/lib/libhyle_mem_vm.a" )

# Import target "hyle::_factor_simd" for configuration "Release"
set_property(TARGET hyle::_factor_simd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_simd PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_simd.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_simd )
list(APPEND _cmake_import_check_files_for_hyle::_factor_simd "${_IMPORT_PREFIX}/lib/libhyle_simd.a" )

# Import target "hyle::_factor_container" for configuration "Release"
set_property(TARGET hyle::_factor_container APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_container PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_container.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_container )
list(APPEND _cmake_import_check_files_for_hyle::_factor_container "${_IMPORT_PREFIX}/lib/libhyle_container.a" )

# Import target "hyle::_factor_sched" for configuration "Release"
set_property(TARGET hyle::_factor_sched APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_sched PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_sched.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_sched )
list(APPEND _cmake_import_check_files_for_hyle::_factor_sched "${_IMPORT_PREFIX}/lib/libhyle_sched.a" )

# Import target "hyle::_factor_io_core" for configuration "Release"
set_property(TARGET hyle::_factor_io_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_io_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_io_core.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_io_core )
list(APPEND _cmake_import_check_files_for_hyle::_factor_io_core "${_IMPORT_PREFIX}/lib/libhyle_io_core.a" )

# Import target "hyle::_factor_compute" for configuration "Release"
set_property(TARGET hyle::_factor_compute APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute "${_IMPORT_PREFIX}/lib/libhyle_compute.a" )

# Import target "hyle::_factor_graph" for configuration "Release"
set_property(TARGET hyle::_factor_graph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph "${_IMPORT_PREFIX}/lib/libhyle_graph.a" )

# Import target "hyle::_factor_compute_provider_ggml" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml.a" )

# Import target "hyle::_factor_compute_ops" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ops APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ops PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ops )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ops "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.a" )

# Import target "hyle::_factor_compute_backend_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_backend_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_backend_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_backend_cpu.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_backend_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_backend_cpu "${_IMPORT_PREFIX}/lib/libhyle_compute_backend_cpu.a" )

# Import target "hyle::_factor_compute_provider_native" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_native PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_native.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_native )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_native "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_native.a" )

# Import target "hyle::_factor_compute_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_cpu.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_cpu "${_IMPORT_PREFIX}/lib/libhyle_compute_route_cpu.a" )

# Import target "hyle::_factor_graph_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu.a" )

# Import target "hyle::_factor_compute_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_vulkan "${_IMPORT_PREFIX}/lib/libhyle_compute_route_vulkan.a" )

# Import target "hyle::_factor_graph_route_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_vulkan "${_IMPORT_PREFIX}/lib/libhyle_graph_route_vulkan.a" )

# Import target "hyle::_factor_compute_provider_ggml_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml_vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml_vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml_vulkan "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml_vulkan.a" )

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.a" )

# Import target "hyle::_factor_compute_provider_iree_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_iree_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_iree_vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_iree_vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_iree_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_iree_vulkan "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_iree_vulkan.a" )

# Import target "hyle::_factor_graph_route_cpu_vulkan" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu_vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu_vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu_vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu_vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu_vulkan "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu_vulkan.a" )

# Import target "hyle::_factor_compute_stream" for configuration "Release"
set_property(TARGET hyle::_factor_compute_stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_stream PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_stream.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_stream )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_stream "${_IMPORT_PREFIX}/lib/libhyle_compute_stream.a" )

# Import target "hyle::_factor_compute_state" for configuration "Release"
set_property(TARGET hyle::_factor_compute_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_state PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_state.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_state )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_state "${_IMPORT_PREFIX}/lib/libhyle_compute_state.a" )

# Import target "hyle::_factor_compute_batch" for configuration "Release"
set_property(TARGET hyle::_factor_compute_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_batch PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_batch.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_batch "${_IMPORT_PREFIX}/lib/libhyle_compute_batch.a" )

# Import target "hyle::_factor_graph_batch" for configuration "Release"
set_property(TARGET hyle::_factor_graph_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_batch PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_batch.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_batch "${_IMPORT_PREFIX}/lib/libhyle_graph_batch.a" )

# Import target "hyle::_mimalloc" for configuration "Release"
set_property(TARGET hyle::_mimalloc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_mimalloc PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmimalloc_static.a"
  )

list(APPEND _cmake_import_check_targets hyle::_mimalloc )
list(APPEND _cmake_import_check_files_for_hyle::_mimalloc "${_IMPORT_PREFIX}/lib/libmimalloc_static.a" )

# Import target "hyle::_ggml_ggml" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml "${_IMPORT_PREFIX}/lib/libggml.a" )

# Import target "hyle::_ggml_ggml-base" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-base PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml-base.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-base )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-base "${_IMPORT_PREFIX}/lib/libggml-base.a" )

# Import target "hyle::_ggml_ggml-cpu" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml-cpu.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-cpu )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-cpu "${_IMPORT_PREFIX}/lib/libggml-cpu.a" )

# Import target "hyle::_ggml_ggml-vulkan" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-vulkan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-vulkan PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml-vulkan.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-vulkan )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-vulkan "${_IMPORT_PREFIX}/lib/libggml-vulkan.a" )

# Import target "hyle::_iree_iree_runtime_unified" for configuration "Release"
set_property(TARGET hyle::_iree_iree_runtime_unified APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_iree_iree_runtime_unified PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libiree_runtime_unified.a"
  )

list(APPEND _cmake_import_check_targets hyle::_iree_iree_runtime_unified )
list(APPEND _cmake_import_check_files_for_hyle::_iree_iree_runtime_unified "${_IMPORT_PREFIX}/lib/libiree_runtime_unified.a" )

# Import target "hyle::_iree_flatcc_parsing" for configuration "Release"
set_property(TARGET hyle::_iree_flatcc_parsing APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_iree_flatcc_parsing PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libflatcc_parsing.a"
  )

list(APPEND _cmake_import_check_targets hyle::_iree_flatcc_parsing )
list(APPEND _cmake_import_check_files_for_hyle::_iree_flatcc_parsing "${_IMPORT_PREFIX}/lib/libflatcc_parsing.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
