#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_error" for configuration "Release"
set_property(TARGET hyle::_factor_error APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_error PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_error.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_error.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_error )
list(APPEND _cmake_import_check_files_for_hyle::_factor_error "${_IMPORT_PREFIX}/lib/libhyle_error.0.1.0.dylib" )

# Import target "hyle::_factor_time" for configuration "Release"
set_property(TARGET hyle::_factor_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_time PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_time.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_time.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_time )
list(APPEND _cmake_import_check_files_for_hyle::_factor_time "${_IMPORT_PREFIX}/lib/libhyle_time.0.1.0.dylib" )

# Import target "hyle::_factor_platform" for configuration "Release"
set_property(TARGET hyle::_factor_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_platform.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform "${_IMPORT_PREFIX}/lib/libhyle_platform.0.1.0.dylib" )

# Import target "hyle::_factor_platform_thread" for configuration "Release"
set_property(TARGET hyle::_factor_platform_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_thread PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_platform_thread.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_thread )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_thread "${_IMPORT_PREFIX}/lib/libhyle_platform_thread.0.1.0.dylib" )

# Import target "hyle::_factor_platform_fs" for configuration "Release"
set_property(TARGET hyle::_factor_platform_fs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_platform_fs PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_platform_fs.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_platform_fs.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_platform_fs )
list(APPEND _cmake_import_check_files_for_hyle::_factor_platform_fs "${_IMPORT_PREFIX}/lib/libhyle_platform_fs.0.1.0.dylib" )

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_mem.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_mem.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/libhyle_mem.0.1.0.dylib" )

# Import target "hyle::_factor_mem_vm" for configuration "Release"
set_property(TARGET hyle::_factor_mem_vm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem_vm PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_mem_vm.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_mem_vm.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem_vm )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem_vm "${_IMPORT_PREFIX}/lib/libhyle_mem_vm.0.1.0.dylib" )

# Import target "hyle::_factor_simd" for configuration "Release"
set_property(TARGET hyle::_factor_simd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_simd PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_simd.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_simd.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_simd )
list(APPEND _cmake_import_check_files_for_hyle::_factor_simd "${_IMPORT_PREFIX}/lib/libhyle_simd.0.1.0.dylib" )

# Import target "hyle::_factor_container" for configuration "Release"
set_property(TARGET hyle::_factor_container APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_container PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_container.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_container.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_container )
list(APPEND _cmake_import_check_files_for_hyle::_factor_container "${_IMPORT_PREFIX}/lib/libhyle_container.0.1.0.dylib" )

# Import target "hyle::_factor_sched" for configuration "Release"
set_property(TARGET hyle::_factor_sched APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_sched PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_sched.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_sched.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_sched )
list(APPEND _cmake_import_check_files_for_hyle::_factor_sched "${_IMPORT_PREFIX}/lib/libhyle_sched.0.1.0.dylib" )

# Import target "hyle::_factor_io_core" for configuration "Release"
set_property(TARGET hyle::_factor_io_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_io_core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_io_core.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_io_core.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_io_core )
list(APPEND _cmake_import_check_files_for_hyle::_factor_io_core "${_IMPORT_PREFIX}/lib/libhyle_io_core.0.1.0.dylib" )

# Import target "hyle::_factor_compute" for configuration "Release"
set_property(TARGET hyle::_factor_compute APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute "${_IMPORT_PREFIX}/lib/libhyle_compute.0.1.0.dylib" )

# Import target "hyle::_factor_graph" for configuration "Release"
set_property(TARGET hyle::_factor_graph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_container"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph "${_IMPORT_PREFIX}/lib/libhyle_graph.0.1.0.dylib" )

# Import target "hyle::_factor_compute_provider_ggml" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_backend_cpu;hyle::_factor_compute_batch;hyle::_factor_compute_ops;hyle::_factor_compute_ggml_runtime;hyle::_factor_error;hyle::_factor_mem;hyle::_factor_simd"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_provider_ggml.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml.0.1.0.dylib" )

# Import target "hyle::_factor_compute_ops" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ops APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ops PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_ops.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ops )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ops "${_IMPORT_PREFIX}/lib/libhyle_compute_ops.0.1.0.dylib" )

# Import target "hyle::_factor_compute_backend_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_backend_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_backend_cpu PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_backend_cpu.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_backend_cpu.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_backend_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_backend_cpu "${_IMPORT_PREFIX}/lib/libhyle_compute_backend_cpu.0.1.0.dylib" )

# Import target "hyle::_factor_compute_provider_native" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_native PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_mem;hyle::_factor_platform;hyle::_factor_simd;hyle::_factor_compute_backend_cpu;hyle::_factor_compute_ops;torch;torch_cpu;c10"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_native.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_provider_native.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_native )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_native "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_native.0.1.0.dylib" )

# Import target "hyle::_factor_compute_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_cpu PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_provider_native;hyle::_factor_compute_provider_ggml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_cpu.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_route_cpu.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_cpu "${_IMPORT_PREFIX}/lib/libhyle_compute_route_cpu.0.1.0.dylib" )

# Import target "hyle::_factor_graph_route_cpu" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_provider_native;hyle::_factor_compute_provider_ggml"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph_route_cpu.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu.0.1.0.dylib" )

# Import target "hyle::_factor_compute_route_apple" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_apple APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_apple PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_container;hyle::_factor_platform_thread;hyle::_factor_compute_provider_ggml_metal"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_apple.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_route_apple.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_apple )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_apple "${_IMPORT_PREFIX}/lib/libhyle_compute_route_apple.0.1.0.dylib" )

# Import target "hyle::_factor_graph_route_apple" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_apple APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_apple PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_graph_batch"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_apple.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph_route_apple.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_apple )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_apple "${_IMPORT_PREFIX}/lib/libhyle_graph_route_apple.0.1.0.dylib" )

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem;hyle::_factor_platform"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_ggml_runtime.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.0.1.0.dylib" )

# Import target "hyle::_factor_compute_provider_ggml_metal" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_ggml_metal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_ggml_metal PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_compute_ops;hyle::_factor_compute_ggml_runtime;hyle::_factor_error;hyle::_factor_mem"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml_metal.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_provider_ggml_metal.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_ggml_metal )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_ggml_metal "${_IMPORT_PREFIX}/lib/libhyle_compute_provider_ggml_metal.0.1.0.dylib" )

# Import target "hyle::_factor_graph_route_cpu_apple" for configuration "Release"
set_property(TARGET hyle::_factor_graph_route_cpu_apple APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_route_cpu_apple PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_error;hyle::_factor_mem;hyle::_factor_compute_backend_cpu;hyle::_factor_graph_route_cpu"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu_apple.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph_route_cpu_apple.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_route_cpu_apple )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_route_cpu_apple "${_IMPORT_PREFIX}/lib/libhyle_graph_route_cpu_apple.0.1.0.dylib" )

# Import target "hyle::_factor_compute_stream" for configuration "Release"
set_property(TARGET hyle::_factor_compute_stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_stream PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "hyle::_factor_sched;hyle::_factor_time"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_stream.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_stream.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_stream )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_stream "${_IMPORT_PREFIX}/lib/libhyle_compute_stream.0.1.0.dylib" )

# Import target "hyle::_factor_compute_state" for configuration "Release"
set_property(TARGET hyle::_factor_compute_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_state PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_state.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_state.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_state )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_state "${_IMPORT_PREFIX}/lib/libhyle_compute_state.0.1.0.dylib" )

# Import target "hyle::_factor_compute_batch" for configuration "Release"
set_property(TARGET hyle::_factor_compute_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_batch PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_batch.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_compute_batch.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_batch "${_IMPORT_PREFIX}/lib/libhyle_compute_batch.0.1.0.dylib" )

# Import target "hyle::_factor_graph_batch" for configuration "Release"
set_property(TARGET hyle::_factor_graph_batch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_graph_batch PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_graph_batch.0.1.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libhyle_graph_batch.0.1.0.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_graph_batch )
list(APPEND _cmake_import_check_files_for_hyle::_factor_graph_batch "${_IMPORT_PREFIX}/lib/libhyle_graph_batch.0.1.0.dylib" )

# Import target "hyle::_mlx_native" for configuration "Release"
set_property(TARGET hyle::_mlx_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_mlx_native PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmlx.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libmlx.dylib"
  )

list(APPEND _cmake_import_check_targets hyle::_mlx_native )
list(APPEND _cmake_import_check_files_for_hyle::_mlx_native "${_IMPORT_PREFIX}/lib/libmlx.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
