from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');matrix=base/'g09-sdk/matrix.json'
assert json.loads(matrix.read_text())['state']=='AIR_SIX_DELIVERIES_PASS'
os.nice(10);env=dict(os.environ,DYLD_PRINT_LIBRARIES='1',HYLE_VULKAN_VALIDATION='0');cases=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=base/'g09-sdk/air-sdk-checkpoint.zip';assert not archive.exists()
for route in ['apple','vulkan']:
 for mode in ['static','shared','source']:
  tag=f'{route}-{mode}-1';out=base/'g09-sdk'/tag/'evidence';r=json.loads((out/'result.json').read_text())
  assert r['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS','SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS']
  if mode=='source':assert r['original_parent_restored']
  for b in r['binaries']:assert sha(Path(b['path']))==b['sha256']
  if mode!='source':
   prefix=Path(r['relocated_prefix'])
   assert not prefix.with_name('staging').exists()
   for item in r['sdk_files']:assert sha(prefix/item['path'])==item['sha256'],item['path']
  artifact=next(x for x in r['binaries'] if Path(x['path']).name=='g09_contracts');binary=Path(artifact['path'])
  audit={'state':'RUNNING','case':tag,'binary':artifact,'command':[str(binary)],'loaded_hyle_libraries':[]};started=time.monotonic()
  with (out/'runtime-contracts.log').open('wb') as log:p=subprocess.run([str(binary)],env=env,stdout=log,stderr=subprocess.STDOUT)
  audit.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-started)
  text=(out/'runtime-contracts.log').read_text(errors='replace')
  assert p.returncode==0,(tag,text[-4000:])
  allowed=Path(r['producer']) if mode=='source' else Path(r['relocated_prefix'])
  for line in text.splitlines():
   if line.startswith('dyld[') and '/libhyle' in line and '.dylib' in line:
    path=Path(line.split()[-1]);assert path.resolve().is_relative_to(allowed.resolve()),(tag,str(path),str(allowed))
    audit['loaded_hyle_libraries'].append({'path':str(path),'sha256':sha(path)})
  if mode!='static':assert audit['loaded_hyle_libraries'],tag
  audit['state']='RUNTIME_PATH_ISOLATION_PASS';(out/'runtime-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
  cases.append({'tag':tag,'result':r,'runtime':audit});print(tag,audit['state'],flush=True)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
 for case in cases:
  out=base/'g09-sdk'/case['tag']/'evidence'
  for path in sorted(out.rglob('*')):
   if path.is_file() and 'bin' not in path.relative_to(out).parts:z.write(path,case['tag']+'/'+path.relative_to(out).as_posix())
  if case['result']['mode']!='source':
   prefix=Path(case['result']['relocated_prefix'])
   for path in sorted((prefix/'lib/cmake').rglob('*')):
    if path.is_file():z.write(path,case['tag']+'/sdk-exports/'+path.relative_to(prefix).as_posix())
 for name in ['matrix.json','matrix-initial.json']:z.write(base/'g09-sdk'/name,'matrix/'+name)
 for path in sorted((base/'g09-sdk-inputs').glob('*.py')):z.write(path,'runner/'+path.name)
 z.write(base/'g09-sdk-inputs/inputs.json','inputs/full-canonical-manifest.json')
 z.writestr('summary.json',json.dumps({'state':'SIX_AIR_DELIVERIES_AND_RUNTIME_ISOLATION_PASS','cases':cases,
   'actual_cumulative_seconds':sum(x['result']['elapsed_seconds']+x['runtime']['elapsed_seconds'] for x in cases),'cost_reset':False},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'state':'SIX_AIR_DELIVERIES_AND_RUNTIME_ISOLATION_PASS','archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size}),flush=True)
