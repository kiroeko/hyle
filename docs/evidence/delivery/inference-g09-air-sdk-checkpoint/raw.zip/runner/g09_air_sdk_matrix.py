from pathlib import Path
import json,subprocess,sys,time
base=Path('/Users/kiro/hyle-scratch/compute-unified');out=base/'g09-sdk/matrix.json'
assert not out.exists()
first=json.loads((base/'g09-sdk/apple-static-1/evidence/result.json').read_text())
assert first['state']=='RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS'
r={'state':'RUNNING','serial':True,'cases':[{'route':'apple','mode':'static','state':first['state'],'elapsed_seconds':first['elapsed_seconds']}],'selected_platform':'Mac16,12 actual Air; no Windows/WSL heavy job concurrent'}
started=time.monotonic()
for route,mode in [('apple','shared'),('apple','source'),('vulkan','static'),('vulkan','shared'),('vulkan','source')]:
    code=subprocess.call([sys.executable,str(base/'g09-sdk-inputs/g09_air_sdk.py'),route,mode])
    record=base/f'g09-sdk/{route}-{mode}-1/evidence/result.json'
    row=json.loads(record.read_text()) if record.is_file() else {}
    r['cases'].append({'route':route,'mode':mode,'exit_code':code,'state':row.get('state'),'elapsed_seconds':row.get('elapsed_seconds')})
    r['matrix_elapsed_seconds']=time.monotonic()-started;out.write_text(json.dumps(r,indent=2)+'\n')
    if code:break
r['state']='AIR_SIX_DELIVERIES_PASS' if len(r['cases'])==6 and all(x['state'] in ['RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS','SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS'] for x in r['cases']) else 'FINITE_FAILURE_REVIEW_REQUIRED'
out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
