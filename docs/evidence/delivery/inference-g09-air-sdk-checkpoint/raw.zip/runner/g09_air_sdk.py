from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified')
route,mode=sys.argv[1:3]
assert sys.platform=='darwin' and route in ['apple','vulkan'] and mode in ['source','static','shared']
source=base/'source-c8874688';inputs=base/'g09-sdk-inputs';resume='--resume-preflight' in sys.argv
assert not resume or (route=='vulkan' and mode=='static')
tag=f'{route}-{mode}-1';folder=base/'g09-sdk'/tag;folder.mkdir(parents=True,exist_ok=resume)
out=folder/'evidence';out.mkdir(exist_ok=resume);producer=base/f'a-cpu-{route}/selected-graph'/('source-build' if mode=='source' else mode+'-sdk-build')
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+os.environ.get('PATH',''),
         HYLE_VULKAN_VALIDATION='0',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
os.nice(10);cmake='/opt/homebrew/bin/cmake';ninja='/opt/homebrew/bin/ninja';started=time.monotonic()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((inputs/'inputs.json').read_text());assert manifest['head'].startswith('bc6ad5c4b')
r={'state':'SETUP','pid':os.getpid(),'route':route,'mode':mode,'stages':[],'producer':str(producer),'max_jobs':4,'nice':os.nice(0),
   'candidate':'3524413272cb52d06af5e64d634edbfef09b9864','product_code_commit':'e09f30925c6dba5cf4540669fd3b4874f45bb158',
   'source_snapshot':{k:manifest[k] for k in ['head','tree','archive_sha256']},
   'scope':'G09 fixed public Graph contracts, original joint pipeline and G06 pending direct consumer through source embedding or independently relocated SDK, public headers. No sanitizer/device/overlap/P1 claim.'}
parent_file=None;original_parent=None
if resume:
    retained=json.loads((out/'result.json').read_text())
    assert retained['state']=='SETUP_FAIL' and retained['stage']=='producer-manifest' and retained['error']=="FileNotFoundError(2, 'No such file or directory')"
    assert not any(x['stage']=='producer-build' for x in retained['stages'])
    (out/'retained-initial-result.json').write_bytes((out/'result.json').read_bytes())
    r=retained;r['pid']=os.getpid();r['retained_preflight_error']=r.pop('error')
    r['preflight_correction']='Old helper expects embedded source hyle/_deps layout, not root SDK _deps. SDK dry-run is checked first and uses its already qualified generator input. Original failed preflight/cumulative cost retained; no product change.'
    started=time.monotonic()-r['elapsed_seconds']

def save():
    r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')

def write_changed(p,data):
    if isinstance(data,str):data=data.encode()
    if not p.is_file() or p.read_bytes()!=data:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)

def run(stage,args):
    stamp=time.monotonic();r.update(state='RUNNING',stage=stage);save();print(tag,stage,flush=True)
    with (out/(stage+'.log')).open('wb') as log:
        p=subprocess.Popen([str(x) for x in args],env=env,stdout=log,stderr=subprocess.STDOUT);r['child_pid']=p.pid;save()
        while True:
            try:code=p.wait(timeout=1800);break
            except subprocess.TimeoutExpired:
                r.setdefault('time_extensions',[]).append({'stage':stage,'pid':p.pid,'seconds':1800});save()
    r.pop('child_pid',None);r['stages'].append({'stage':stage,'command':[str(x) for x in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print((out/(stage+'.log')).read_text(errors='replace')[-12000:],flush=True);raise SystemExit(code)

def checked_build(build,targets,label):
    run(label+'-manifest',[ninja,'-C',build,'build.ninja'])
    preview=out/(label+'-preview.ninja');preview.write_bytes((build/'build.ninja').read_bytes())
    if route=='vulkan' and build==producer:
        # Same finite data-only helper; handle root SDK versus embedded layout.
        # Bind every static reference DATA hash to the earlier accepted G09 host
        # proof before treating the static tree itself as the donor.
        original=base/'g06-final-host-air/reuse_current_vulkan_generated.py'
        prior=base/'g09-vulkan-host-asan-1/generated-reuse-g09-asan-1.json'
        qualification=json.loads(prior.read_text())
        assert qualification['state']=='PASS_CURRENT_INPUT_GENERATED_SHADER_DATA_REUSE_ONLY'
        for row in qualification['copied']:assert sha(Path(row['source']))==row['sha256'],row['source']
        prefix='hyle/' if mode=='source' else ''
        helper=original.read_text().replace("own_source=build/f'hyle/src/", "own_source=build/f'"+prefix+"src/")
        helper=helper.replace("own_generated=build/'hyle/src/", "own_generated=build/'"+prefix+"src/")
        helper=helper.replace("own_cfg=build/f'hyle/_deps/", "own_cfg=build/f'"+prefix+"_deps/")
        helper=helper.replace("f'hyle/_deps/gg-{identity}/src/vulkan-shaders-gen-stamp/'", "f'"+prefix+"_deps/gg-{identity}/src/vulkan-shaders-gen-stamp/'")
        (out/'original-generated-helper.py').write_bytes(original.read_bytes());(out/'selected-layout-generated-helper.py').write_text(helper)
        scope={};exec(compile(helper,str(out/'selected-layout-generated-helper.py'),'exec'),scope)
        r[label+'_generated_shader_reuse']=scope['apply'](build,preview,out,'g09-sdk-'+mode)
        r[label+'_generated_shader_reuse']['prior_qualified_152_data_hash_binding']={'path':str(prior),'sha256':sha(prior),'all_current_donor_hashes_match':True}
    dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
    (out/(label+'-dry-run.log')).write_text(dry)
    r[label+'_build_edges']=len(dry.splitlines());save()
    assert len(dry.splitlines())<150 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry and 'Generate vulkan shaders' not in dry,dry
    commands=json.loads(subprocess.check_output([ninja,'-C',str(build),'-t','compdb'],env=env,text=True))
    shipping=[x for x in commands if x.get('file','').startswith(str(source/'src')+'/')]
    assert all('HYLE_TESTING' not in x['command'] and '-fsanitize=' not in x['command'] for x in shipping)
    if build==producer:assert shipping
    (out/(label+'-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
    run(label+'-build',[ninja,'-C',build,'-f',preview,'-j','4',*targets])

try:
    r['identity']={k:subprocess.check_output(v,env=env,text=True).strip() for k,v in {'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],
        'system':['sw_vers'],'compiler':['xcrun','clang++','--version'],'metal':['xcrun','-sdk','macosx','metal','--version']}.items()}
    assert r['identity']['model']=='Mac16,12'
    assert sha(inputs/'source.zip')==manifest['archive_sha256']
    with zipfile.ZipFile(inputs/'source.zip') as z:
        changed=[]
        for item in manifest['files']:
            rel=Path(item['path']);assert not rel.is_absolute() and '..' not in rel.parts
            data=z.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
            p=source/rel;assert p.resolve().is_relative_to(source.resolve())
            if not p.is_file() or p.read_bytes()!=data:write_changed(p,data);changed.append(item['path'])
    r['synced_paths']=changed
    registry=json.loads((source/'docs/implementation/module-status.json').read_text())
    owners=[x for x in registry['modules'] if x.get('record','').endswith('inference-g09-joint-pipeline.md')]
    assert len(owners)==4 and all(x['state']=='CANDIDATE' and x['candidate']==r['candidate'] for x in owners)
    (out/'source-inputs.json').write_bytes((inputs/'inputs.json').read_bytes())
    if mode!='source':
        if not resume:run('producer-configure',[cmake,'-S',source,'-B',producer,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON',
            '-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_SANITIZER=off','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu;'+route,
            '-DHYLE_STATIC='+('ON' if mode=='static' else 'OFF'),'-UCMAKE_PROJECT_INCLUDE'])
        targets=['hyle_compute','hyle_compute_ops','hyle_compute_batch','hyle_compute_state','hyle_compute_stream','hyle_graph','hyle_graph_batch',
            f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}']
        checked_build(producer,targets,'producer')
        staging=folder/'staging';prefix=folder/'relocated'
        run('install',[cmake,'--install',producer,'--prefix',staging]);staging.rename(prefix);assert not staging.exists()
        consumer=folder/'consumer';consumer.mkdir();build=folder/'consumer-build'
        r['relocated_prefix']=str(prefix)
    else:
        cache=(producer/'CMakeCache.txt').read_text();home=next(x.split('=',1)[1] for x in cache.splitlines() if x.startswith('CMAKE_HOME_DIRECTORY:'))
        consumer=Path(home);parent_file=consumer/'CMakeLists.txt';original_parent=parent_file.read_bytes()
        (out/'original-parent.cmake').write_bytes(original_parent);build=producer;prefix=None
    fixtures={'g09_contracts':f'tests/graph/cpu_{route}_contracts.cc','g09_pipeline':'tests/graph/native_joint_pipeline.cc',
              'g09_pending':'tests/compute_batch/pending_paged_receiver_native_consumer.cc'}
    copied=set()
    def copy(relative):
        if relative in copied:return
        p=(source/relative).resolve();assert p.is_relative_to(source.resolve()) and relative.split('/')[0] in ['tests','samples'],relative
        data=p.read_bytes();write_changed(consumer/relative,data);copied.add(relative)
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',data.decode(),re.M):
            if not inc.startswith('hyle/'):copy((p.parent/inc).resolve().relative_to(source.resolve()).as_posix())
    for relative in fixtures.values():copy(relative)
    r['fixture_inputs']=[{'path':x,'sha256':sha(consumer/x)} for x in sorted(copied)]
    headers=['graph/cpu.h',f'graph/cpu_{route}.h']
    for i,h in enumerate(headers):
        if prefix:assert sha(prefix/'include/hyle'/h)==sha(source/'include/hyle'/h)
        write_changed(consumer/f'g09-header-{i}.cc','#include <hyle/'+h+'>\n')
    body='cmake_minimum_required(VERSION 3.25)\nproject(g09_public_delivery LANGUAGES CXX)\n'
    if mode=='source':
        for key,value in [('HYLE_COMPONENTS','compute;graph'),('HYLE_COMPUTE_ROUTES','cpu;'+route),('HYLE_BUILD_TESTS','OFF'),('HYLE_BUILD_BENCH','OFF'),('HYLE_INSTALL','OFF'),('HYLE_TEST_INSTRUMENTATION','OFF')]:
            body+=f'set({key} "{value}" CACHE '+('STRING' if key in ['HYLE_COMPONENTS','HYLE_COMPUTE_ROUTES'] else 'BOOL')+' "" FORCE)\n'
        body+='add_subdirectory("'+str(source)+'" hyle)\n'
    else:body+='find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)\n'
    for name,relative in fixtures.items():
        body+=f'add_executable({name} "{relative}")\ntarget_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime({name})\n'
        body+=f'set_target_properties({name} PROPERTIES RUNTIME_OUTPUT_DIRECTORY "{out}/bin")\n'
    body+='target_compile_definitions(g09_pending PRIVATE HYLE_PENDING_NATIVE_JOINT_GRAPH=1)\n'
    if route=='apple':body+='target_compile_definitions(g09_pipeline PRIVATE HYLE_G09_APPLE=1)\ntarget_compile_definitions(g09_pending PRIVATE HYLE_PENDING_RECEIVER_APPLE=1)\n'
    body+='add_library(g09_headers OBJECT g09-header-0.cc g09-header-1.cc)\ntarget_compile_features(g09_headers PRIVATE cxx_std_23)\ntarget_link_libraries(g09_headers PRIVATE hyle::compute hyle::graph)\n'
    write_changed(consumer/'CMakeLists.txt',body);(out/'consumer.cmake').write_text(body)
    args=[cmake,'-S',consumer,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    if prefix:args+=['-DCMAKE_PREFIX_PATH='+str(prefix)]
    else:args+=['-DHYLE_STATIC=OFF','-DHYLE_SANITIZER=off','-UCMAKE_PROJECT_INCLUDE']
    run('consumer-configure',args);checked_build(build,[*fixtures,'g09_headers'],'consumer')
    actual=[x for x in json.loads((build/'compile_commands.json').read_text()) if Path(x['file']).resolve() in [*(consumer/x for x in fixtures.values()),*(consumer/f'g09-header-{i}.cc' for i in range(2))]]
    assert len(actual)==5,len(actual)
    for row in actual:
        command=row['command'];assert str(source/'src') not in command and '-fsanitize=' not in command and 'HYLE_TESTING' not in command
        if prefix:assert str(source) not in command and str(producer) not in command and str(prefix/'include') in command,command
        else:assert str(source/'include') in command,command
    (out/'public-consumer-commands.json').write_text(json.dumps(actual,indent=2)+'\n')
    for name in fixtures:
        binary=out/'bin'/name;run(name,[binary])
        deps=subprocess.check_output(['otool','-L',str(binary)],text=True);(out/(name+'-dependencies.log')).write_text(deps)
        if prefix:assert str(producer) not in deps and str(source) not in deps,deps
        r.setdefault('binaries',[]).append({'path':str(binary),'sha256':sha(binary)})
    if prefix:r['sdk_files']=[{'path':p.relative_to(prefix).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(prefix.rglob('*')) if p.is_file()]
    r['public_header_inputs']=[{'path':h,'sha256':sha((prefix/'include/hyle' if prefix else source/'include/hyle')/h)} for h in headers]
    for item in manifest['files']:assert sha(source/item['path'])==item['sha256'],item['path']
    r['state']='SOURCE_PUBLIC_CONSUMERS_HEADERS_PASS' if mode=='source' else 'RELOCATED_SDK_PUBLIC_CONSUMERS_HEADERS_PASS';save();print(tag,r['state'],r['elapsed_seconds'],flush=True)
except BaseException as error:
    if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(error));save()
    raise
finally:
    if parent_file is not None and original_parent is not None:
        parent_file.write_bytes(original_parent);r['original_parent_restored']=sha(parent_file)==hashlib.sha256(original_parent).hexdigest();save()
