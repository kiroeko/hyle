import hashlib, json, subprocess
from pathlib import Path
root = Path("/root/hyle-scratch/util-runtime-v4")
runs = []
for args in ([], ["fail"]):
    command = [str(root / "forwarding-probe"), *args]
    result = subprocess.run(command, capture_output=True, text=True)
    runs.append({"command": command, "returncode": result.returncode,
                 "stdout": result.stdout, "stderr": result.stderr})
report = {"candidate_commit": "6145023f31590f0f175845470d6f4da32e8df1ee",
          "probe_sha256": hashlib.sha256(Path("/mnt/c/public/project-hyle/_validation/util-runtime-v4/forwarding-probe.cc").read_bytes()).hexdigest(),
          "runs": runs}
(root / "forwarding-probe-result.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
