import hashlib, importlib.util, json, os, platform, re, shutil, subprocess, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("selector", "scripts/validation-select.py")
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
machine = sys.argv[1]
if os.name == "nt":
    compiler = Path(shutil.which("cl")).resolve()
    version = subprocess.run([str(compiler)], capture_output=True, text=True).stderr
    match = re.search(r"(19\.\d+\.\d+)", version)
    if not match:
        raise RuntimeError(version)
    roots = [Path(p) for p in os.environ["INCLUDE"].split(";") if p and Path(p).is_dir()]
    vc = Path(os.environ["VCToolsInstallDir"])
    sdk = Path(os.environ["WindowsSdkDir"])
    sdk_version = os.environ["WindowsSDKVersion"].rstrip("/\\")
    libs = [vc / "lib/x64/msvcprt.lib", vc / "lib/x64/vcruntime.lib",
            sdk / "Lib" / sdk_version / "ucrt/x64/ucrt.lib"]
    backend = [compiler.parent / name for name in ("c1xx.dll", "c2.dll", "link.exe")]
    compiler_id, compiler_version, stdlib = "MSVC", match.group(1), "MSVC STL + UCRT"
    flags = { "CMAKE_CXX_FLAGS": "/DWIN32 /D_WINDOWS /GR /EHsc",
              "CMAKE_CXX_FLAGS_RELEASE": "/O2 /Ob2 /DNDEBUG" }
else:
    compiler = Path(shutil.which(os.environ["CXX"])).resolve()
    version = subprocess.run([str(compiler), "-v"], capture_output=True, text=True, check=True).stderr
    headers = subprocess.run([str(compiler), "-E", "-x", "c++", "-v", "/dev/null"],
                             capture_output=True, text=True, check=True).stderr
    search = headers.split("#include <...> search starts here:", 1)[1].split("End of search list.", 1)[0]
    roots = [Path(line.strip()).resolve() for line in search.splitlines() if "/c++/" in line]
    flags = {"CMAKE_CXX_FLAGS": "", "CMAKE_CXX_FLAGS_RELEASE": "-O3 -DNDEBUG"}
    if sys.platform == "darwin":
        sdk = Path(subprocess.check_output(["xcrun", "--show-sdk-path"], text=True).strip())
        libs = [sdk / "usr/lib/libc++.tbd"]
        backend = [compiler]
        compiler_id = "AppleClang"
        compiler_version = re.search(r"clang version (\d+\.\d+\.\d+)", version).group(1)
        stdlib = "libc++ / " + str(sdk)
    else:
        libs = [Path(subprocess.check_output([str(compiler), "-print-file-name=libstdc++.so"], text=True).strip()).resolve()]
        backend = [Path(subprocess.check_output([str(compiler), "-print-prog-name=cc1plus"], text=True).strip()).resolve()]
        compiler_id = "GNU"
        compiler_version = subprocess.check_output([str(compiler), "-dumpfullversion"], text=True).strip()
        stdlib = "libstdc++"
if not roots: raise RuntimeError("no standard library headers bound")
context = {
    "toolchain": {"id": version.strip(), "compiler_path": str(compiler), "compiler_id": compiler_id,
                  "compiler_version": compiler_version, "compiler_sha256": sha(compiler),
                  "compiler_files": {str(p): sha(p) for p in backend},
                  "stdlib": {"id": stdlib, "files": {str(p): sha(p) for p in libs},
                             "include_roots": {str(p): selector.directory_digest(p) for p in roots}},
                  "flags": flags,
                  "cmake": subprocess.check_output(["cmake", "--version"], text=True).strip()},
    "machine_profile": {"id": machine, "host": platform.uname()._asdict()}
}
Path(sys.argv[2]).write_text(json.dumps(context, indent=2), encoding="utf-8")
print("bound", machine, compiler_id, compiler_version, len(roots), "header roots")
