import importlib.util, json
from pathlib import Path
root = Path(r"C:\public\project-hyle\hyle")
spec = importlib.util.spec_from_file_location("hyle_loc", root / "scripts/loc-report.py")
loc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(loc)
commit, files = loc.tracked_commit_files(root, "6145023f31590f0f175845470d6f4da32e8df1ee")
scopes, module_files = loc.module_scope("util-runtime", files)
own = loc.files_under(files, loc.SELF_WITHOUT_TESTS_ROOTS)
cloc = loc.find_cloc()
measured = loc.cloc_measure_commit_sets(cloc, root, commit,
    [(files, None), (own, loc.NATIVE_LANGUAGES), (module_files, loc.NATIVE_LANGUAGES)])
result = {"snapshot_commit": commit, "cloc_version": loc.cloc_version(cloc, root),
          "metrics": [{"id": name, "code": count, "files": nfiles}
                      for name, (count, nfiles) in zip(
                          ["repository_code", "self_without_tests", "module_implementation"], measured)],
          "module": "util-runtime", "module_paths": scopes,
          "self_paths": list(loc.SELF_WITHOUT_TESTS_ROOTS),
          "self_languages": list(loc.NATIVE_LANGUAGES),
          "repository_policy": "all Git tracked files, all cloc recognized languages"}
Path(r"C:\public\project-hyle\_validation\util-runtime-v4\loc-three-metrics.json").write_text(
    json.dumps(result, indent=2), encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
