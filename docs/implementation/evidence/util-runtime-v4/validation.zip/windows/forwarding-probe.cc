#include <cstdio>
#include <cstdlib>
#include <exception>
#include <type_traits>
#include "hyle/util/registry.h"

struct Argument {
  static inline bool fail_move = false;
  static inline int moves = 0;
  Argument() = default;
  Argument(const Argument&) = delete;
  Argument(Argument&&) {
    ++moves;
    if (fail_move) throw 7;
  }
};
struct Factory {
  int* operator()(const Argument&) const noexcept { return nullptr; }
};
static_assert(std::is_nothrow_invocable_r_v<int*, const Factory&, Argument>);
int main(int argc, char**) {
  hyle::util::Registry<int*, Argument> registry;
  if (!registry.register_creator("factory", Factory{}).ok()) return 1;
  auto creator = registry.freeze().find("factory")->creator;
  std::set_terminate([] { std::_Exit(86); });
  Argument::fail_move = argc > 1;
  (void)creator(Argument{});
  std::printf("moves inside borrowed creator: %d\n", Argument::moves);
  return 0;
}
